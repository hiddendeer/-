/**
 * Leaflet 示例配置文件：包含示例的分类、名称、缩略图、文件路径
 */
var identification = {
    name: "Leaflet"
};
var exampleConfig = {
    "maps": {
        name: "地图操作",
        name_en: "Map Operations",
        content: {
            "map-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "地图初始化",
                    name_en: "Init map",
                    thumbnail: "a_maps_loader.png",
                    fileName: "01_mapLoader"
                }, {
                    name: "地图销毁",
                    name_en: "destroy map",
                    thumbnail: "a_maps_destroy.png",
                    fileName: "01_mapDestroy"
                }, {
                    name: "地图缩放",
                    name_en: "map zoom",
                    thumbnail: "a_maps_zoom.png",
                    fileName: "01_mapZoom"
                }, {
                    name: "地图叠加",
                    name_en: "overlay tile layer",
                    thumbnail: "a_maps_layers.png",
                    fileName: "01_mapLayers"

                }, {
                    name: "设置中心",
                    name_en: "planar coordinate system",
                    thumbnail: "a_maps_center.png",
                    fileName: "01_mapCenter"
                }, {
                    name: "多地图实例",
                    name_en: "multi map",
                    thumbnail: "23_multimap.png",
                    fileName: "23_multi_map"
                }, {
                    name: "园区切换",
                    name_en: "switch map",
                    thumbnail: "a_maps_loader.png",
                    fileName: "23_switch_map"
                }, {
                    name: "填充图层",
                    name_en: "filled layer",
                    thumbnail: "01_mapFilledLayer.png",
                    fileName: "01_mapFilledLayer"
                }]
            }
        }
    },
     "markers": {
        name: "图标操作",
        name_en: "Marker Operation",
        content: {
            "markers-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "普通图标",
                    name_en: "ID query",
                    thumbnail: "a_add_marker.png",
                    fileName: "02_addMarker"
                }, {
                    name: "闪烁图标",
                    name_en: "SQL query",
                    thumbnail: "a_add_flash_marker.png",
                    fileName: "02_addFlashMarker"
                },{
                    name: "图标属性修改",
                    name_en: "geometry query",
                    thumbnail: "a_maps_center.png",
                    fileName: "02_updateMarker"
                },{
                    name: "聚合图标",
                    name_en: "cluster marker",
                    thumbnail: "cluster_marker.png",
                    fileName: "02_clusterMarker"
                },{
                    name: "高性能图标",
                    name_en: "graphic Marker",
                    thumbnail: "graphicMarker.png",
                    fileName: "02_addGraphicMarker"
                },{
                    name: "显示与隐藏图层",
                    name_en: "opacity marker",
                    thumbnail: "02_setOpacity.png",
                    fileName: "02_setOpacity"
                }]
            }
        }
    },
    "popups": {
        name: "提示框操作",
        name_en: "Popup Operations",
        content: {
            "popups-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "提示框",
                    name_en: "popups",
                    thumbnail: "a_add_popup.png",
                    fileName: "03_addPopup"
                }]
            }
        }
    },
    "measure": {
        name: "地图测量",
        name_en: "measure",
        content: {
            "route-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "距离测量",
                    name_en: "service area",
                    thumbnail: "12_measure_length.png",
                    fileName: "12_measure_length"
                }, {
                    name: "面积测量",
                    name_en: "closest facilities",
                    thumbnail: "12_measure_area.png",
                    fileName: "12_measure_area"
                }]
            }
        }
    },
    "indoor": {
        name: "室内地图",
        name_en: "indoor outdoor swith",
        content: {
            "indoor-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "室内地图切换",
                    name_en: "buffer",
                    thumbnail: "a_indoor_map2.png",
                    fileName: "04_indoorMap"
                }
//注释原因：所有新项目都采用地图加载方式而非数据绘制方式
                // , {
                //     name: "室内对象高亮",
                //     name_en: "buffer-geometry",
                //     thumbnail: "a_maps_roomstyle.png",
                //     fileName: "04_indoorMapRoomStyle"
                // }, {
                //     name: "自定义室内样式",
                //     name_en: "buffer-geometry",
                //     thumbnail: "a_indoor_map_color.png",
                //     fileName: "04_indoorMapCustomColor"
                // }
                ]
            }
        }
    },
    "route": {
        name: "路径描绘与规划",
        name_en: "Route and draw",
        content: {
            "route-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "轨迹描绘",
                    name_en: "service area",
                    thumbnail: "a_custom_path.png",
                    fileName: "05_drawCustomPath"
                }, {
                    name: "路径规划",
                    name_en: "closest facilities",
                    thumbnail: "a_findClosestFacilitiesService.jpg",
                    fileName: "05_findClosestFacilitiesService"
                },{
                    name: "路径规划(跳过点)",
                    name_en: "closest facilities(SkipPoints)",
                    thumbnail: "a_findClosestFacilitiesService.jpg",
                    fileName: "05_findPathAvoidPoint"
                }, {
                    name: "室内路径规划",
                    name_en: "Indoor path",
                    thumbnail: "05_indoorPathService.png",
                    fileName: "05_indoorPathService"
                },{
                    name: "路径导航",
                    name_en: "navigation",
                    thumbnail: "20_navigation.png",
                    fileName: "20_navigation"
                }, {
                    name: "室内路径导航",
                    name_en: "inner navigation",
                    thumbnail: "20_navigation_inner.png",
                    fileName: "20_navigation_inner"
                }, {
                    name: "语音播报",
                    name_en: "speech",
                    thumbnail: "21_speech.jpg",
                    fileName: "21_speech"
                }, {
                    name: "室内位置映射",
                    name_en: "indoorMapping",
                    thumbnail: "24_indoorMapping.png",
                    fileName: "24_indoorMapping"
                }]
            }
        }
    },
    "heatmap": {
        name: "热力图操作",
        name_en: "heatmap operations",
        content: {
            "heatmap-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "热力图生成",
                    name_en: "heatmap generate",
                    thumbnail: "a_heat_map.png",
                    fileName: "06_heatMap"
                },{
                    name: "热力圈选",
                    name_en: "heatmap select",
                    thumbnail: "a_heat_map_select.png",
                    fileName: "06_heatMapSelect"
                }]
            }
        }
    },
    "bounder": {
        name: "周界操作",
        name_en: "bounder operations",
        content: {
            "bounder-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "周界显隐",
                    name_en: "density",
                    thumbnail: "a_show_border.png",
                    fileName: "07_showBorder"
                },{
                    name: "区域划分",
                    name_en: "zone",
                    thumbnail: "07_showZones.png",
                    fileName: "07_showZones"
                }]
            }
        }
    },
    "data": {
        name: "数据查询",
        name_en: "query data",
        content: {
            "data-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "SQL查询",
                    name_en: "sql query",
                    thumbnail: "08_dataquery.png",
                    fileName: "08_dataquery"
                },{
                    name: "建筑查询",
                    name_en: "building query",
                    thumbnail: "08_buildingquery.png",
                    fileName: "08_buildingquery"
                },{
                    name: "空间查询",
                    name_en: "contains query",
                    thumbnail: "08_buildingquery.png",
                    fileName: "08_containQuery"
                },{
                    name: "地址->经纬度",
                    name_en: "address to position",
                    thumbnail: "08_geocode.png",
                    fileName: "08_geocode"
                },{
                    name: "经纬度->地址",
                    name_en: "position->address",
                    thumbnail: "08_geodecode.png",
                    fileName: "08_geodecode"
                }]
            }
        }
    },
    "pointmanage": {
        name: "打点操作",
        name_en: "point manage",
        content: {
            "data-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "打点工具",
                    name_en: "point manage",
                    thumbnail: "11_point_manage.png",
                    fileName: "11_point_manage_tools"
                }]
            }
        }
    },
    "spatial": {
        name: "空间分析",
        name_en: "analysis",
        content: {
            "route-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "缓冲分析",
                    name_en: "service area",
                    thumbnail: "13_spatial_buffer.png",
                    fileName: "13_spatial_buffer"
                }, {
                    name: "质心分析",
                    name_en: "closest facilities",
                    thumbnail: "13_spatial_centerofmass.png",
                    fileName: "13_spatial_centerofmass"
                }, {
                    name: "贝塞尔分析",
                    name_en: "closest facilities",
                    thumbnail: "13_spatial_bezierSpline.png",
                    fileName: "13_spatial_bezierSpline"
                }, {
                    name: "差分分析",
                    name_en: "closest facilities",
                    thumbnail: "13_spatial_diff.png",
                    fileName: "13_spatial_diff"
                },{
                    name: "叠加分析",
                    name_en: "closest facilities",
                    thumbnail: "13_spatial_intersect.png",
                    fileName: "13_spatial_intersect"
                },{
                    name: "点线距离",
                    name_en: "closest facilities",
                    thumbnail: "13_spatial_pointdist.png",
                    fileName: "13_spatial_pointdist"
                }]
            }
        }
    },
    "event": {
        name: "鼠标事件",
        name_en: "system event",
        content: {
            "event-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "地图事件",
                    name_en: "map event",
                    thumbnail: "a_maps_loader.png",
                    fileName: "09_eventMap"
                },{
                    name: "图标事件",
                    name_en: "marker event",
                    thumbnail: "a_event_marker.png",
                    fileName: "09_eventMarker"
                },{
                    name: "建筑事件",
                    name_en: "building event",
                    thumbnail: "a_event_building.png",
                    fileName: "09_eventBuilding"
                },{
                    name: "圈选事件",
                    name_en: "select event",
                    thumbnail: "09_eventSelect.png",
                    fileName: "09_eventSelect"
                }]
            }
        }
    },
    "draw": {
        name: "图形绘制",
        name_en: "draw operations",
        content: {
            "draw-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "绘制和编辑几何区域",
                    name_en: "map event",
                    thumbnail: "a_draw_geometry.png",
                    fileName: "10_drawGeometry"
                }]
            }
        }
    },
    "security": {
        name: "安全相关",
        name_en: "security",
        content: {
            "security-default": {
                name: "查看演示",
                name_en: "Map service",
                content: [{
                    name: "　设备监控范围",
                    name_en: "monitor range",
                    thumbnail: "a_monitor.jpg",
                    fileName: "monitorRange"
                }]
            }
        }
    }
//注释原因：专题图只有J区数据才有
    // "thematic": {
    //     name: "专题图",
    //     name_en: "thematic",
    //     content: {
    //         "thematic-default": {
    //             name: "查看演示",
    //             name_en: "Server thematic",
    //             content: [{
    //                 name: "等级符号专题图",
    //                 name_en: "Graduated symbol thematic",
    //                 thumbnail: "graduated.jpg",
    //                 fileName: "graduatedSymbol"
    //             },{
    //                 name: "分段专题图",
    //                 name_en: "Range thematic",
    //                 thumbnail: "range.jpg",
    //                 fileName: "rangeThematic"
    //             }]
    //         }
    //     }
    // }
};

/**
 *key值：为exampleConfig配置的key值或者fileName值
 *      （为中间节点时是key值，叶结点是fileName值）
 *value值：fontawesome字体icon名
 *不分层
 */
var sideBarIconConfig = {
    "maps": "fa-map",
    "markers": "fa-map-marker",
    "data": "fa-cloud",
    "heatmap": "fa-heart",
    "bounder": "fa-lemon-o",
    "popups": "fa-font-awesome",
    "event": "fa-magic",
    "control": "fa-sliders",
    "route": "fa-level-up",
    "indoor": "fa-home",
    "viz": "fa-map",
    "draw": "fa-edit",
    "security": "fa-user",
    "pointmanage": "fa-thumb-tack",
    "spatial": "fa-line-chart",
    "measure": "fa-sliders",
    "thematic": "fa-star"
};

/**
 *key值：为exampleConfig配置的key值
 *value值：fontawesome字体icon名
 *与sideBarIconConfig的区别：sideBarIconConfig包括侧边栏所有层级目录的图标，exampleIconConfig仅包括一级标题的图标
 */
var exampleIconConfig = {
    "maps": "fa-map",
    "markers": "fa-map-marker",
    "data": "fa-cloud",
    "heatmap": "fa-heart",
    "bounder": "fa-lemon-o",
    "popups": "fa-font-awesome",
    "event": "fa-magic",
    "control": "fa-sliders",
    "route": "fa-level-up",
    "indoor": "fa-home",
    "viz": "fa-map",
    "draw": "fa-edit",
    "security": "fa-user",
    "pointmanage": "fa-thumb-tack",
    "spatial": "fa-line-chart",
    "measure": "fa-sliders",
    "thematic": "fa-star"
};
window.leafletExampleConfig = exampleConfig;
