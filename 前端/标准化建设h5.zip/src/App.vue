<script>
export default {
    // 此处globalData为了演示其作用，不是uView框架的一部分
    globalData: {
        username: "Eagle",
    },
    onLaunch() {
        // plus.navigator.setFullscreen(true); //隐藏状态栏(应用全屏:只能隐藏状态栏，标题栏和虚拟返回键都还可以显示)
        // if (window.plus) {
        //     this.plusReady();
        // } else {
        //     document.addEventListener("plusready", this.plusReady, false);
        // }
    },

    // onLaunch() {
    // 	// 1.1.0版本之前关于http拦截器代码，已平滑移动到/common/http.interceptor.js中
    // 	// 注意，需要在/main.js中实例化Vue之后引入如下(详见文档说明)：
    // 	// import httpInterceptor from '@/common/http.interceptor.js'
    // 	// Vue.use(httpInterceptor, app)
    // 	// process.env.VUE_APP_PLATFORM 为通过js判断平台名称的方法，结果分别如下：
    // 	/**
    // 	 * h5，app-plus(nvue下也为app-plus)，mp-weixin，mp-alipay......
    // 	 */
    // 	let userInfo = uni.getStorageSync('userInfo');
    // 	if (userInfo) {
    // 		//存在则关闭启动页进入首页
    // 		uni.navigateTo({
    // 			url: "/"
    // 		})

    // 	} else {
    // 		//不存在则跳转至登录页
    // 		uni.reLaunch({
    // 			url: "/pages/login/login",
    // 		})
    // 	}
    // },
    onShow: function () {
        console.log("App Show");
    },

    mounted() {
        // var userAgent = navigator.userAgent;
        // if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
        // 	// ，在页面中插入 style ：使标题隐藏
        // 	let style = document.createElement('style');
        // 	    style.type = 'text/css';
        // 	    style.innerHTML="uni-page-head,.uni-page-head{display:none;}";
        // 	    document.getElementsByTagName('head').item(0).appendChild(style);
        // }
    },

    methods: {
        // plusReady() {
        //     // 在这里调用plus api
        //     plus.navigator.setFullscreen(true); //隐藏状态栏(应用全屏:只能隐藏状态栏，标题栏和虚拟返回键都还可以显示)
        // },
    },
};
</script>

<style lang="scss">
@import "uview-ui/index.scss";

uni-modal {
    z-index: 19999 !important;
}
body {
    background: #f3f4f6;
    // margin-top: 30px;
    // padding-top: 30px;
}
</style>
