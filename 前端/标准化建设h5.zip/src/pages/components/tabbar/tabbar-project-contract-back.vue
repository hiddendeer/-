
<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-project-contract-back",
		data() {
			return {
				list: [{
						pagePath:"/pages/project/projectContractBack/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "回款管理",
						customIcon: false,
						
					},
					{
						pagePath: "/pages/project/projectContractBack/history",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "回款历史",
					}
				],
			}
		},
		created() {
		}
	}
</script>

