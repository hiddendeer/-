<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-target",
		data() {
			return {
				list: [{
						pagePath:"/pages/site/planTarget/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "安全生产目标",
						customIcon: false,
						
					},
					{
						pagePath: "/pages/site/planTarget/targetList",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "目标达成情况",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

