<template>
    <eagle-tabbar :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-danger-simple",
    data() {
        return {
            list: [{
                pagePath: "/pages/danger/dangerCheckSimple/home",
                iconPath: "home",
                selectedIconPath: "home-fill",
                text: "首页",
                customIcon: false,
            }, {
                pagePath: "/pages/danger/dangerCheckSimple/detail",
                iconPath: "camera",
                selectedIconPath: "camera-fill",
                text: "随手拍",
                customIcon: false,
                params: "?source=simple"
            },
          
            {
                pagePath: "/pages/danger/dangerCheckSimple/list",
                iconPath: "grid",
                selectedIconPath: "grid-fill",
                text: "隐患清单",
                params: "?source=simple"
            },
            {
                pagePath: "/pages/danger/dangerCheckSimple/report",
                iconPath: "file-text",
                selectedIconPath: "file-text-fill",
                text: "报告",
                params: "?source=simple"
            },
            {
                //pagePath: "/pages/danger/dangerCheckSimple/set",

                pagePath: "/pages/user/userSetting/userModuleSet",
                iconPath: "setting",
                selectedIconPath: "setting-fill",
                text: "参数设置",
                params: "?moduleCode=DangerCheckSimple&source=simple"
            }
            ],
        }
    },
    created() {
    }
}
</script>

