<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name: "tabbar-host-index",
		data() {
			return {
				list: [{
						pagePath: `pages/site/siteIndex/index`,
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "首页",
						params:"?modulesId=host"
					},
					{
						pagePath: "/pages/project/projectConsultation/myList",
						iconPath: "account",
						selectedIconPath: "account-fill",
						text: "项目列表",
						customIcon: false,
						params:"?modulesId=host"
					},
					{
						// pagePath: `/pages/host/hostMain/siteReport?enterpriseCode=${this.$route.query.enterpriseCode ?? ""}&projectId=${this.$route.query.projectId ?? ""}&modulesId=host`,
						pagePath: `pages/site/housekeeper/index`,
						iconPath: "calendar",
						selectedIconPath: "calendar-fill",
						text: "报表中心",
						params:"?modulesId=host"
					},
				],
			};
		},
		created() {},
	};
</script>
