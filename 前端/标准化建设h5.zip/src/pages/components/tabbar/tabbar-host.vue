<template>
    <eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-host",
    data() {
        return {
            list: [
                {
                    pagePath: `pages/site/siteIndex/index`,
                    iconPath: "home",
                    selectedIconPath: "home-fill",
                    text: "首页",
                    params: "?modulesId=host",
                },
                {
                    pagePath: `pages/host/hostMain/hostMainIndex?enterpriseCode=${
                        this.$route.query.enterpriseCode ?? ""
                    }&projectId=${
                        this.$route.query.projectId ?? ""
                    }&modulesId=host`,
                    iconPath: "coupon",
                    selectedIconPath: "coupon-fill",
                    text: "项目主页",
                    // params:"?source=simple"
                },
                // {
                //     pagePath:
                //         "/pages/project/projectConsultation/myList?modulesId=host",
                //     iconPath: "account",
                //     selectedIconPath: "account-fill",
                //     text: "项目列表",
                //     customIcon: false,
                // },
                {
                    pagePath: `/pages/host/hostMain/siteReport?enterpriseCode=${
                        this.$route.query.enterpriseCode ?? ""
                    }&projectId=${
                        this.$route.query.projectId ?? ""
                    }&modulesId=host`,
                    iconPath: "photo",
                    selectedIconPath: "photo-fill",
                    text: "台账一览",
                    // params:"?source=simple"
                },
            ],
        };
    },
    created() {},
};
</script>

