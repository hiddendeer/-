<template>
	<eagle-tabbar :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-duty-file",
		data() {
			return {
				list: [{
						pagePath:"/pages/site/dutyFile/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "待签字",
						customIcon: false,
					},
					{
						pagePath: "/pages/site/dutyFile/listMain",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "现行",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

