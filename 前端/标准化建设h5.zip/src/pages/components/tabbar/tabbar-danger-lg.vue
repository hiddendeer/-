<template>
    <eagle-tabbar :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-danger-simple",
    data() {
        return {
            list: [
                {
                    pagePath: "/pages/danger/dangerLG/list",
                    iconPath: "camera",
                    selectedIconPath: "camera-fill",
                    text: "依据",
                    customIcon: false,
                },
                {
                    pagePath: "/pages/danger/dangerCheckSimple/list",
                    iconPath: "grid",
                    selectedIconPath: "grid-fill",
                    text: "检查清单",
                    params: "?source=lg"
                },
                {
                    pagePath: "/pages/danger/dangerCheckSimple/report",
                    iconPath: "file-text",
                    selectedIconPath: "file-text-fill",
                    text: "报告",
                    params: "?source=lg"
                },
                {
                    pagePath: "/pages/user/userSetting/userModuleSet",
                    iconPath: "setting",
                    selectedIconPath: "setting-fill",
                    text: "参数设置",
                    params: "?moduleCode=DangerCheckSimple&source=lg"
                }
               
            ],
        }
    },
    created() {
      
    }
}
</script>

