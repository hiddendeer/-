<template>
    <eagle-tabbar :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-danger-simple",
    data() {
        return {
            list: [
                {
                    pagePath: "/pages/danger/dangerTemplate/mylist",
                    iconPath: "camera",
                    selectedIconPath: "camera-fill",
                    text: "检查表",
                    customIcon: false,
                },

                {
                    pagePath: "/pages/danger/dangerCheckTemp/list",
                    iconPath: "grid",
                    selectedIconPath: "grid-fill",
                    text: "检查清单"
                },
                {
                    pagePath: "/pages/danger/dangerCheckSimple/report",
                    iconPath: "file-text",
                    selectedIconPath: "file-text-fill",
                    text: "报告",
                    params: "?source=template"
                },
                {
                    pagePath: "/pages/user/userSetting/userModuleSet",
                    iconPath: "setting",
                    selectedIconPath: "setting-fill",
                    text: "参数设置",
                    params: "?moduleCode=DangerCheckSimple&source=template"
                }
              
            ],
        }
    },
    created() {
       
    }
}
</script>

