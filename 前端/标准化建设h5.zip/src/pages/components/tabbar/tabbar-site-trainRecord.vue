<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-trainRecord",
		data() {
			return {
				list: [{
						pagePath:"/pages/site/trainRecord/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "三级安全培训记录",
						customIcon: false,
						
					},
					{
						pagePath: "/pages/site/trainRecord/otherlist",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "其他安全培训记录",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

