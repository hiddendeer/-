<template>
	<eagle-tabbar :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-danger-simple",
		data() {
			return {
				list: [{
						pagePath:"/pages/site/equipment/home",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "首页",
						customIcon: false,
					},
					{
						pagePath: "/pages/site/equipment/list",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "设备列表",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

