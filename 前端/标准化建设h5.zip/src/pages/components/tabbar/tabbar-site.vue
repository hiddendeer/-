<template>
    <eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-site",
    data() {
        return {
            list: [
                {
                    pagePath: "/pages/host/hostMain/index",
                    iconPath: "home",
                    selectedIconPath: "home-fill",
                    text: "主页",
                    customIcon: false,
                },
                {
                    pagePath: "/pages/host/hostMain/siteReport",
                    iconPath: "file-text",
                    selectedIconPath: "file-text-fill",
                    text: "台账一览",
                    // params:"?source=simple"
                },
            ],
        };
    },
    created() {},
};
</script>

