<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-project-invoice",
		data() {
			return {
				list: [{
						pagePath:"/pages/project/projectContractInvoice/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "开票管理",
						customIcon: false,
						
					},
					{
						pagePath: "/pages/project/projectContractInvoice/history",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "开票历史",
					}
				],
			}
		},
		created() {
		}
	}
</script>

