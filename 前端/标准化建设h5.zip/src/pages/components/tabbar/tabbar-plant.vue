<template>
    <eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-site",
    data() {
        return {
            list: [
                {
                    pagePath: "/pages/factoryInPlant/index",
                    iconPath: "home",
                    selectedIconPath: "home-fill",
                    text: "主页",
                    customIcon: false,
                },
            ],
        };
    },
    created() {},
};
</script>

