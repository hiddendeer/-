<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-safe-cost",
		data() {
			return {
				list: [{
						pagePath:"/pages/site/safeCost/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "安全经费投入计划",
						customIcon: false,
						
						
					},
					{
						pagePath: "/pages/site/safeCost/listRecord",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "安全费用记录",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

