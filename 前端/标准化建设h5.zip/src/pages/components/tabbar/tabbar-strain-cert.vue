<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-target",
		data() {
			return {
				list: [{
						pagePath:"/pages/train/cert/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "证书管理",
						customIcon: false,
						
					},
					{
						pagePath: "/pages/train/supplier/list",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "培训机构清单",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

