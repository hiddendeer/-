<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name: "tabbar-danger-index",
		data() {
			return {
				list: [{
						// pagePath: `pages/host/hostMain/hostIndex?enterpriseCode=${this.$route.query.enterpriseCode ?? ""}&projectId=${this.$route.query.projectId ?? ""}&modulesId=host`,
						pagePath: `pages/site/siteIndex/index`,
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "主页",
						params:"?modulesId=dangerJg"
					},
					{
						pagePath: "/pages/project/projectConsultation/myList",
						iconPath: "account",
						selectedIconPath: "account-fill",
						text: "项目列表",
						customIcon: false,
						params:"?modulesId=dangerJg"
					},
					{
						// pagePath: `/pages/host/hostMain/siteReport?enterpriseCode=${this.$route.query.enterpriseCode ?? ""}&projectId=${this.$route.query.projectId ?? ""}&modulesId=host`,
						pagePath: `pages/site/ServiciosIndex/index`,
						iconPath: "calendar",
						selectedIconPath: "calendar-fill",
						text: "报表中心",
						params:"?modulesId=dangerJg"
					},
				],
			};
		},
		created() {},
	};
</script>
