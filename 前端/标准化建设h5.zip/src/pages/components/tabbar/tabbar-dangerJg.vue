<template>
    <eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
export default {
    name: "tabbar-dangerJg",
    data() {
        return {
            list: [
                {
                    pagePath: ` /pages/site/siteIndex/index?modulesId=dangerJg`,
                    iconPath: "home",
                    selectedIconPath: "home-fill",
                    text: "首页",
                    customIcon: false,
                },
                {
                    pagePath:
                        "/pages/project/projectConsultation/myList?modulesId=dangerJg",
                    iconPath: "file-text",
                    selectedIconPath: "file-text-fill",
                    text: "项目列表",
                    customIcon: false,
                },
                {
                    pagePath: `pages/host/hostMain/hostIndex?enterpriseCode=${
                        this.$route.query.enterpriseCode ?? ""
                    }&projectId=${
                        this.$route.query.projectId ?? ""
                    }&modulesId=dangerJg`,
                    iconPath: "coupon",
                    selectedIconPath: "coupon-fill",
                    text: "项目主页",
                    customIcon: false,
                },
                // {
                //     pagePath:
                //         "pages/project/projectServiceLog/list?modulesId=dangerJg",
                //     iconPath: "warning",
                //     selectedIconPath: "warning-fill",
                //     text: "服务日志",
                // },
                // {
                //     pagePath: "/pages/host/hostMain/siteReport",
                //     iconPath: "file-text",
                //     selectedIconPath: "file-text-fill",
                //     text: "台账一览",
                //     // params:"?source=simple"
                // },
            ],
        };
    },
    created() {},
};
</script>

