<template>
	<eagle-tabbar :height="100" :list="list"></eagle-tabbar>
</template>

<script>
	export default {
		name:"tabbar-site-fire-equipment",
		data() {
			return {
				list: [{
						pagePath:"/pages/site/fireEquipment/list",
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: "消防器材清单",
						customIcon: false,
						
					},
					{
						pagePath: "/pages/site/fireCheckTask/list",
						iconPath: "grid",
						selectedIconPath:"grid-fill",
						text: "点检异常清单",
						params:"?source=simple"
					}
				],
			}
		},
		created() {
		}
	}
</script>

