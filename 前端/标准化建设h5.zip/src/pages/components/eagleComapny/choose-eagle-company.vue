<template name="choose-eagle-company">
    <u-form-item class="eagle-choose-input" :label="label" ref="uFormItem" :label-position="labelPositionVal" :required="required" :prop="prop" :label-width="labelWidth">
        <!-- <u-input :placeholder="placeholder" :value="names" @click="funDialogShow" :disabled="true">
        </u-input>
        <view>
            <u-icon name="arrow-right" color="#e1e1e1" size="28"></u-icon>
        </view> -->
        <view class="choose-input-view" @click="funDialogShow">
            <span class="input-placeholder" v-if="!$slots.default&&!value">{{placeholderVal}}</span>
            <span v-else>
                <span v-if="$slots.default">
                    <slot></slot>
                </span>
                <span v-else>{{names}}</span>
            </span>
        </view>
        <u-button class="choose-input-btn" type="primary" @click="funDialogShow">
            <u-icon size="12" name="plus"></u-icon>{{btnName}}
        </u-button>
        <popup-choose-company ref="companyChoose" @callBackChoosedData="afterChooseEnt"></popup-choose-company>

    </u-form-item>
    <!-- </view>
    </view> -->

</template>

<script>
import popupChooseCompany from "@/pages/project/projectCompany/components/popup-choose-company";
export default {
    name: "choose-eagle-company",
    components: { popupChooseCompany },
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        names: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        placeholder: {
            type: String,
            default: "请选择被检查单位",
        },
        label: {
            type: String,
            default: "被检查单位",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        btnName: {
            type: String,
            default() {
                return "选择";
            },
        },
    },
    data() {
        return {
            labelPositionVal: "",
            placeholderVal: "",
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this.codes = nVal;
            }
        },
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请选择" + this.title;
    },
    methods: {
        funDialogShow() {
            this.$refs.companyChoose.show();
        },
        // setValues(codes, names) {
        //     this.$emit("update:names", names);
        //     this.$emit("input", codes);
        //     this.$emit("change", codes, names);
        // },

        callBackChoosedData(choosedData) {
            this.$emit("callBackChoosedData", choosedData);
        },

        clear() {
            this.codes = "";
            //	this.names = ''
            this.$emit("update:names", "");
            this.$emit("input", "");
            this.$emit("change", "", "");
            this.$emit("callBackChoosedData", "");
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.value) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage = _this.placeholder;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage === _this.placeholder
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
        afterChooseEnt(data) {
            this.$emit("update:names", data.name);
            this.$emit("input", data.code);
            this.$emit("change", data);
        },
    },
};
</script>

<style lang="scss">
.uni-date-clear {
    position: absolute;
    top: 10px;
}
</style>
