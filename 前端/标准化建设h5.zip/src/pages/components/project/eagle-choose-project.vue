<template>
	<view>
		<u-form-item :label="title" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
			<u-input :placeholder="placeholderVal" :value="names" @click="funDialogShow" :disabled="true"></u-input>
			<view v-show="codes" class="uni-date__icon-clear" @click.stop="clear">
				<uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
			</view>
		</u-form-item>
		<popup-project :show.sync="dialogShow" v-model="codes" :names.sync="myNames"   @change="setValues"></popup-project>
	</view>
</template>

<script> 
	import popupProject from "@/pages/components/project/popup-project.vue";
	export default {
		name: "eagle-choose-project",
		components: {
			'popup-project': popupProject
		},
		props: {
			value: {
				type: [String, Number],
				default: ''
			},
			labelPosition: {
				type: String,
				default: ""
			},
			labelWidth: {
				type: String,
				default: ''
			},
			title: {
				type: String,
				default () {
					return ''
				}
			},
			required: {
				type: [Boolean],
				default () {
					return false
				}
			},
			placeholderVal: {
				type: String,
				default: '请选择项目'
			},
			names: {
				type: String,
				default () {
					return ''
				}
			},
		},
		data() {
			return {
				dialogShow: false,
				codes:this.value,
				myNames:this.names,
				labelPositionVal: ""
			};
		},
		computed: {},
		created() {
		},
		watch: {
			value(nVal, oVal) {
				if (nVal != oVal) {
					this.codes=nVal;
				}
			}
		},
		created() {
			this.labelPositionVal = this.labelPosition ? this.labelPosition : this.consts.constLabelPosition;
		},
		methods: {
			funDialogShow() {
				this.dialogShow = true;
			},
			setValues(codes, names) {
				this.$emit('update:names', names);
				this.$emit('input', codes);
				this.$emit('change', codes, names);
			},
			clear()
			{
				this.codes="";
				this.$emit('update:names', "");
				this.$emit('input', "");
				this.$emit('change', "", "");
			}
		}
	}
</script>

<style lang="scss">

</style>
