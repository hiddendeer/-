<template>
    <u-popup v-model="showPopup" mode="right" height="100%" length="100%">
        <eagle-head title="回款设置" @close="close"></eagle-head>

        <eagle-form :boolInitData="false" :autoCreate="false" v-model="model" ref="eagleForm" :out-height='100'>
            <eagle-container>
                <eagle-input v-model="model.cTotalPrice" disabled title="合同总金额" prop="cTotalPrice">
                </eagle-input>
                <eagle-input v-model="model.rate" required title="回款比例(%)" prop="rate" @input="calculateRate">
                </eagle-input>
                <eagle-input v-model="model.totalPrice" type="number" :isNumber="true" required title="应回款金额" prop="totalPrice" @blur="calculateTotalPrice" @input="numDxsCheck(model, 2, 'totalPrice')">
                </eagle-input>
                <eagle-date v-model="model.payDate" title="回款期限" prop="payDate" required />
                <eagle-input v-model="model.remarks" title="备注" prop="remarks">
                </eagle-input>
            </eagle-container>
        </eagle-form>

        <eagle-bottom-view class="view-botton">
            <u-button class="choose-btn bottom-btn" type="primary" @click="submit">确定</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
    </u-popup>
</template>

<script>
export default {
    name: "popup-project-contract-dts",
    props: {
        // showPopup: {
        //     type: Boolean,
        //     default() {
        //         return false;
        //     },
        // },
    },
    data() {
        return {
            model: {
                rate: 0,
                totalPrice: 0,
                invoicePrice: 0,
                receivePrice: 0,
                payDate: "",
                remarks: "",
                cTotalPrice: "",
                index: null,
            },
            showPopup: false,
        };
    },
    computed: {},
    watch: {},
    created() {},
    methods: {
        submit() {
            this.calculateTotalPrice();
            if (!this.valid()) {
                return;
            }

            if (
                this.model.rate == "" ||
                this.model.rate == "0" ||
                this.model.rate == 0
            ) {
                this.$refs.uToast.show({
                    title: "请输入应回款金额",
                    type: "error",
                });
                return;
            }

            if (
                this.model.totalPrice == "" ||
                this.model.totalPrice == "0" ||
                this.model.totalPrice == 0
            ) {
                this.$refs.uToast.show({
                    title: "请输入应回款金额",
                    type: "error",
                });
                return;
            }
            if (this.model.rate > 100) {
                this.$refs.uToast.show({
                    title: "应回款金额不能大于合同金额",
                    type: "error",
                });
                return;
            }

            if (this.model.payDate.length == 10) {
                this.model.payDate = this.model.payDate + " 00:00:00";
            }

            // if(this.model.totalPrice>this.model.cTotalPrice){
            if (
                parseFloat(this.model.totalPrice) >
                parseFloat(this.model.cTotalPrice)
            ) {
                this.$refs.uToast.show({
                    title: "应回款金额不能大于合同金额",
                    type: "error",
                });
                return;
            }

            this.$emit("contractCallBack", this.model);
            this.close();
        },
        show(config, index, totalPrice) {
            this.showPopup = true;
            if (config && config.rate) {
                var newModel = {};
                newModel = this.utils.deepMerge(config, newModel);

                this.model = newModel;
                this.model.index = index;
            } else {
                this.model.rate = 0;
                this.model.totalPrice = 0;
                this.model.invoicePrice = 0;
                this.model.receivePrice = 0;
                this.model.payDate = "";
                this.model.remarks = "";
                this.model.index = null;
            }

            this.model.cTotalPrice = totalPrice;
        },
        close() {
            // this.$emit("update:showPopup", false);
            this.showPopup = false;
        },

        calculateRate() {
            if (this.model.rate == "") {
                this.model.totalPrice = "";
            } else {
                this.model.totalPrice =
                    (this.model.rate * this.model.cTotalPrice) / 100;
                this.model.totalPrice = this.model.totalPrice.toFixed(2);
            }

            console.log(
                "calculateRate - rate=" +
                    this.model.rate +
                    ",totalPrice=" +
                    this.model.totalPrice
            );
        },

        calculateTotalPrice() {
            if (this.model.totalPrice == "") {
                this.model.rate = "";
            } else {
                this.model.rate =
                    (this.model.totalPrice / this.model.cTotalPrice) * 100;

                this.model.rate = this.model.rate.toFixed(2);
            }
        },

        getGetAllChildElement(childrens, array) {
            let _this = this;
            childrens.forEach((x) => {
                array = array.concat(x.$children);
                //array.push(x.$children);
                array = _this.getGetAllChildElement(x.$children, array);
            });
            return array;
        },

        valid() {
            let result = true;
            //var children = this.$refs.uForm.$children[0].$children;
            let array = [];

            array = this.getGetAllChildElement(
                this.$refs.eagleForm.$children,
                array
            );
            if (array.length > 0) {
                for (var i = 0; i < array.length; i++) {
                    if (array[i].$options.propsData.required) {
                        let el = array[i].$emit.apply(
                            array[i],
                            ["valid"].concat()
                        );
                        if (typeof el.valid === "function") {
                            let flag = el.valid();
                            result = result ? flag : result;
                        }
                    }
                }
            }
            return result;
        },
        numDxsCheck(form, ws, key) {
            let _this = this;

            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },
    },
};
</script>

<style lang="scss">
.view-botton {
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>
