<template>
    <view class="rxlc-step">
        <view class="rxlc-content">
            <view class="content-list" v-for="(item, index) in stepsList" :key="index">
                <view class="content-list-lt">
                    <view class="list-icon-title">
                        <view class="">
                            <view class="lt-icon-box1">
                                <view class="lt-icon-box">
                                    <view class="lt-icon" :class="{ 'active': item.status == 100 }"></view>
                                    <view class="lt-text">{{ item.taskName }}</view>
                                </view>
                                <view class="list-content">日志{{ item.logCount || 0 }}次</view>
                            </view>
                            <view class="list-content1" v-if="detailsShow">
                                {{ item.finishChnName || "" }} {{ item.finishDate | dateFormat }}
                            </view>
                        </view>
                        <view class="list-right" style="margin-right: 20rpx;" @click="addLog(item)">日志</view>
                        <view class="list-right" v-show="item.status != 100" @click="handleFinish(item)">完成</view>
                    </view>
                    <view class="white-line" :class="{ 'd-none': index + 1 === stepsList.length, 'active': item.status == 100 }">
                    </view>
                </view>
            </view>
        </view>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>

<script>
export default {
    props: {
        stepsList: {
            type: Array,
            default: () => [],
        },
        stepsCurent: {
            type: Number,
            default: 0,
        },
        detailsShow: {
            type: Boolean,
            default: false,
        },
        enterpriseCode: {
            type: String,
            default: "",
        },
        projectId: {
            type: String,
            default: "",
        },
    },
    methods: {
        addLog(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/project/projectServiceLog/detail",
                {
                    taskCode: item.code,
                    enterpriseCode: this.enterpriseCode ?? "",
                    projectId: this.projectId ?? "",
                    modulesId: this.$route.query.modulesId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        finish(item) {
            let _this = this;
            this.common
                .post("/site/projectConsultationTask/finish?code=" + item.code)
                .then((res) => {
                    if (res.code == 200) {
                        _this.$refs.uToast.show({
                            title: "任务成功",
                            type: "success",
                            callback: function () {
                                _this.$emit("finishCall");
                            },
                        });
                    }
                });
            item.show = false;
        },

        handleFinish(item) {
            var _this = this;

            this.$refs.eagleConfirm.showConfirm({
                content: "确认是否完成该服务进度？",
                confirm: function () {
                    _this.finish(item);
                },
                cancel: function () {
                    // _this.$refs.uToast.show({
                    //     title: "取消",
                    //     type: "error",
                    // });
                },
            });
        },
    },
};
</script>

<style scoped lang="scss">
.rxlc-step {
    width: 100%;
    // padding: 16px 18px 20px 17px;
    box-sizing: border-box;

    .rxlc-content {
        width: 100%;
        border-radius: 20rpx;
        position: relative;

        .content-list {
            width: 100%;
            display: table;

            .content-list-lt {
                display: table-cell;
                position: relative;
                color: #333333;
                font-family: Noto Sans S Chinese Medium;
                font-size: 32rpx;

                .list-icon-title {
                    display: -webkit-inline-box;
                    height: 120rpx;
                    justify-content: space-between;
                    align-items: center;
                    padding: 20rpx 40rpx;

                    .lt-icon-box {
                        display: flex;
                        align-items: center;
                    }

                    .lt-icon {
                        width: 30rpx;
                        height: 30rpx;
                        border-radius: 50%;
                        background: #cccccc;
                        margin-right: 14rpx;
                        z-index: 999;

                        &.active {
                            background: #7ac756;
                        }
                    }

                    .lt-text {
                        display: table-cell;
                        width: 220rpx;
                        font-weight: 550;
                        font-size: 28rpx;
                        line-height: 36rpx;
                    }

                    .list-content {
                        color: #333333;
                        font-size: 28rpx;
                        width: 200rpx;
                    }

                    .list-right {
                        color: #1684fc;
                        font-size: 28rpx;
                        border-bottom: 2rpx solid #1684fc;
                        box-sizing: border-box;
                    }
                }

                .white-line {
                    width: 4rpx;
                    height: 100%;
                    position: absolute;
                    top: 50rpx;
                    left: 52rpx;
                    background: #cccccc;
                    z-index: 888;

                    &.active {
                        background: #7ac756;
                    }
                }

                .d-none {
                    display: none;
                }
            }
        }
    }

    .lt-icon-box1 {
        display: flex;
    }

    .list-content1 {
        margin: 10rpx 0 0 44rpx;
        font-size: 26rpx;
    }
}
</style>
