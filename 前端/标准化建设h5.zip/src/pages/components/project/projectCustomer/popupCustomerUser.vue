<template>
    <u-popup v-model="showPopup" mode="right" height="100%" length="100%">
        <eagle-head title="客户联系人" @close="close"></eagle-head>
        <view>
            <eagle-form :boolInitData="false" v-model="model" ref="eagleForm" :out-height='100'>
                <eagle-container>
                    <eagle-input v-model="model.contact" required title="客户联系人" prop="contact" />
                    <eagle-input v-model="model.mobile" required title="联系方式" prop="mobile" />
                    <eagle-input v-model="model.post" title="岗位" prop="post" />
                    <eagle-input v-model="model.email" title="邮箱" prop="email" />
                    <eagle-input v-model="model.remarks" title="备注" prop="remarks" type="textarea" />
                </eagle-container>
            </eagle-form>

            <eagle-bottom-view>
                <u-button class="bottom-btn" type="primary" @click="submit()">保存</u-button>
            </eagle-bottom-view>
        </view>

        <u-toast ref="uToast" />
    </u-popup>
</template>

<script>
import eagleInput from "../../../../components/eagle-input/eagle-input.vue";
export default {
    components: { eagleInput },
    name: "popup-customer-user",
    props: {
        // showPopup: {
        //     type: Boolean,
        //     default() {
        //         return false;
        //     },
        // },
    },
    data() {
        return {
            model: {
                contact: "",
                mobile: "",
                post: "",
                email: "",
                code: "",
                index: null,
            },
            showPopup: false,
        };
    },
    computed: {},
    watch: {},
    created() {},
    methods: {
        submit() {
            if (this.model.contact == "") {
                this.$refs.uToast.show({
                    title: "请输入客户联系人",
                    type: "error",
                });
                return;
            }

            if (this.model.mobile == "") {
                this.$refs.uToast.show({
                    title: "请输入联系方式",
                    type: "error",
                });
                return;
            }

            var newModel = {};
            newModel = this.utils.deepMerge(newModel, this.model);
            this.$emit("customerCallBack", newModel);
            this.close();
        },
        show(config, indexValue) {
            this.showPopup = true;
            if (config && config.contact) {
                var newModel = {};
                newModel = this.utils.deepMerge(config, newModel);
                newModel.indexValue = indexValue;
                this.model = newModel;
            } else {
                this.model.contact = "";
                this.model.mobile = "";
                this.model.post = "";
                this.model.email = "";
                this.model.code = "";
                this.model.remarks = "";
                this.model.indexValue = null;
            }
        },
        close() {
            // this.$emit("update:showPopup", false);
            this.showPopup = false;
        },
    },
};
</script>

<style lang="scss">
</style>
