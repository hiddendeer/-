<template>
    <u-popup v-model="show" mode="right" height="100%" length="100%">
        <!-- <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);">
                <div class="uni-page-head-hd">
                    <div class="uni-page-head-btn" @click="close">
                        <i class="uni-btn-icon" style="color: rgb(0, 0, 0); font-size: 27px;"></i>
                    </div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                        选择项目
                    </div>
                </div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head> -->
        <eagle-head title='请选择项目' @close='close'></eagle-head>
        <view>
            <eagle-page-list :controller="controller" :dataType="dataType" :showCheck="true" @initList="_initList"
                :margin-bottom="50" v-show="!showDetail">
                <view slot="search">
                    <view class="search">
                        <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled"
                            :show-action="false" @clear="search"></eagle-search>
                    </view>
                </view>
                <view slot="list" class="list-wrap">
                    <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                        <view class="uni-media-cell-content" @tap="choose(item, true)">
                            <view class="uni-media-list">
                                <view class="uni-media-list-body">
                                    <view class="uni-media-list-text-top">{{ item.ProjectName }}</view>
                                </view>
                                <u-checkbox v-model="item.checked" @click.stop.native="choose(item, false)"
                                    shape="circle">
                                </u-checkbox>
                            </view>
                        </view>
                    </view>
                </view>
            </eagle-page-list>
            <view class="choosed-view" v-show="showDetail">
                <view class="uni-media-cell" v-for="(item, index) in choosedData" :key="item.ID">
                    <view class="uni-media-cell-content">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body" @tap="choose(item, false)">
                                {{ item.ProjectName }}
                            </view>
                            <view class="uni-date__icon-clear" @click.stop="clear(item, index)">
                                <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
            <view class="view-choose-botton">
                <view class="choose-item" v-if="choosedNum > 0">
                    <text>已选择:</text>
                    <text class="choose-num" @click="funShowDetail">{{ choosedNum }}个项目</text>
                </view>
                <u-button class="choose-btn" type="primary" @click="submit">确定</u-button>
            </view>
        </view>
    </u-popup>
</template>

<script>
export default {
    name: "popup-project",
    props: {
        value: {
            type: String,
            default() {
                return "";
            },
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
        show: {
            type: Boolean,
            default() {
                return false;
            },
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            controller: "ProjectConsultation",
            dataType: "DangerCheck",
            searchValue: "",
            data: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,
            choosedNum: 0,
            queryParams: {},
            detailHeigh: 0,
            chooseVal: "",
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this._initChoosedData();
            }
        },
    },
    created() {
        let _that = this;
        this._initChoosedData();
    },
    mounted() {
        this.search();
    },
    methods: {
        _initChoosedData() {
            if (this.chooseVal != this.value) {
                this.choosedData = [];
                if (this.value) {
                    let arry = this.value.split(",");
                    let arryName = this.names.split(",");
                    for (let i = 0; i < arry.length; i++) {
                        this.choosedData.push({
                            ProjectCode: arry[i],
                            ProjectName: arryName[i],
                        });
                    }
                    this.choosedNum = this.choosedData.length;
                }
            }
        },
        _initList(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (
                        this.choosedData[j].ProjectCode == list[i].ProjectCode
                    ) {
                        list[i].checked = true;
                    }
                }
            }
            this.data = list;
        },
        close() {
            // this.dialogShow = false;
            this.$emit("update:show", false);
        },
        search() {
            this.queryParams.SearchValue = this.searchValue;
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        choose(obj, update) {
            let _this = this;
            if (update) {
                obj.checked = !obj.checked;
            }
            this.choosedData = [];
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (!_this.isMult) {
                    if (item.ProjectCode != obj.ProjectCode) {
                        item.checked = false;
                    }
                }
                if (item.checked) {
                    _this.choosedData.push(item);
                }
            }
            this.choosedNum = this.choosedData.length;
        },
        submit() {
            let codeArry = [];
            let nameArry = [];
            this.choosedData.forEach(function (item) {
                codeArry.push(item.ProjectCode);
                nameArry.push(item.ProjectName);
            });
            let codes = codeArry.join(",");
            let names = nameArry.join(",");
            this.chooseVal = userNames;
            this.$emit("input", codes);
            this.$emit("update:names", names);
            this.$emit("change", codes, names);
            this.close();
        },
        clear(obj, index) {
            this.choosedData.splice(index, 1);
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];

                if (item.ProjectCode == obj.ProjectCode) {
                    item.checked = false;
                }
            }
            this.choosedNum = this.choosedData.length;
            if (this.choosedNum == 0) {
                this.showDetail = false;
            }
        },
        funShowDetail() {
            this.showDetail = !this.showDetail;
        },
    },
};
</script>

<style lang="scss">
.uni-media-cell {
    margin: 0;
}

.uni-media-list-text-top {
    line-height: 100rpx;
    text-indent: 20rpx;
}
</style>
