<template>
    <view class="host-container">
        <eagle-container>
            <view class="host-header">
                <view class="host-header-item">
                    <view class="company-name single-line">{{ project.projectName }}</view>
                    <view class="company-address">地址:{{ project.serviceName }}</view>
                    <view class="company-opp">
                        <view class="" style="display: flex;align-items: center;">
                            <view class="" style="width: 300rpx;margin-right: 50rpx;">
                                <view class="circleShow">
                                    单位对接人:{{ project.projectContact }}
                                </view>
                            </view>
                            <view class="" style="display: flex;align-items: center;width: 300rpx;white-space: nowrap;">
                                联系电话:<view class="phone circleShow">{{ project.projectMobile }}</view>
                            </view>
                        </view>
                    </view>
                    <view class="company-res">
                        <view class="company-res1">
                            <view class="left">项目负责人</view>
                            <view class="right">{{ project.mainChnName }}</view>
                        </view>
                        <view class="company-res2 circleShow" v-show="project.partChnName">项目参与人:{{ project.partChnName
                        }}
                        </view>
                    </view>
                </view>
            </view>
        </eagle-container>
        <eagle-container title="服务工具">
            <u-line :hair-line='false' />
            <uni-grid style="margin-top: 10px;" :column="3" :show-border="false" :square="false">
                <uni-grid-item v-for="(item, index) in menuList" :index="index" :key="index">
                    <view class="grid-item-box" @click="goTo(item)">
                        <image class="image" :src="item.src" mode="aspectFill" style="border-radius: 10px;" />
                        <text class="text">{{ item.label }}</text>
                    </view>
                </uni-grid-item>
            </uni-grid>
        </eagle-container>
        <view class="subsection">
            <u-subsection mode='subsection' active-color='#2979FF' :list="radioList" :current="sectionCurrent"
                :height='60' :bold='false' @change="handlerSectionChange">
            </u-subsection>
        </view>
        <eagle-container>
            <view v-if="sectionCurrent === 0">
                <scroll-view scroll-y="true" class="menu-show">
                    <template v-if="taskList.length > 0">
                        <view class="example-body div-progress-list">
                            <template v-for="item in taskList">
                                <view class="view-progress">
                                    <v-circle :percent="item | getPercentage"
                                        :bgcolor="item.overvueDates > 0 || item.overvuePercent > 0 ? '#ff0000' : '#0088ff'">
                                    </v-circle>
                                    <view class="div-progress-font">
                                        <template v-if="item.finishCnt == 0">
                                            <div v-if="item.totalCnt > 0" class="div-total-font">0/{{ item.totalCnt }}
                                            </div>
                                            <div v-else>待完成</div>
                                        </template>
                                        <template v-else>
                                            <div v-if="item.totalCnt > 0" class="div-total-font">{{ item.finishCnt }}/{{
                                                    item.totalCnt
                                            }}</div>
                                            <div v-else>{{ item.finishCnt }}次</div>
                                        </template>
                                    </view>
                                    <view class="div-taskName"> {{ getTaskName(item.taskName) }}</view>
                                </view>
                            </template>
                        </view>
                    </template>
                    <template v-else>
                        <u-empty text="暂无数据" mode="list"></u-empty>
                    </template>
                </scroll-view>
            </view>
            <view v-if="sectionCurrent === 1">
                <scroll-view scroll-y="true" class="menu-show">
                    <view style="padding: 20rpx 40rpx;">
                        <template v-if="logList.length > 0">
                            <u-time-line>
                                <u-time-line-item nodeTop="15" v-for="(item, index) in logList" :key='index'>
                                    <template v-slot:content>
                                        <view @click='handlerViewClick(item)'>
                                            <view class="line-item-title">
                                                <view style="margin-right: 30rpx;">{{ item.serviceDate | dateFormat }}
                                                </view>
                                            </view>
                                            <view class="line-item-content">
                                                <view class="line-item-content-item">
                                                    <!-- <view class="left">{{item.createDate|timeFormat}}</view> -->
                                                    <view class="left">{{ item.serviceChnName || "" }}</view>
                                                </view>
                                                <view class="">
                                                    <view v-if="item.projectConsultationTaskLogDtsList.length > 0">
                                                        服务内容：
                                                        <template
                                                            v-for="(children, index) in item.projectConsultationTaskLogDtsList">
                                                            {{ (index + 1) }} : {{ children.taskName }}；
                                                        </template>
                                                    </view>
                                                    其他服务：{{ item.serviceConclusion }}
                                                </view>
                                            </view>
                                        </view>

                                    </template>
                                </u-time-line-item>
                            </u-time-line>
                        </template>
                        <template v-else>
                            <u-empty text="暂无数据" mode="list"></u-empty>
                        </template>
                    </view>
                </scroll-view>
            </view>
        </eagle-container>
        <eagle-fab v-if="sectionCurrent === 1" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'>
        </eagle-fab>
    </view>
</template>

<script>
import MySetps from "@/pages/components/project/mySteps.vue";
import circle from "../../../components/circle/circle.vue";
export default {
    name: "project-main-index",
    components: {
        MySetps,
        "v-circle": circle,
    },
    //菜单列表
    props: {},
    data() {
        return {
            project: {
                enterpriseName: "",
                serviceName: "",
                projectContact: "",
                projectMobile: "",
                mainChnName: "",
                partChnName: "",
            },
            menuList: [],
            hostMenuList: [
                {
                    src: "../../../static/img/AppIcon/home_grid_base1.png",
                    url: "/pages/host/ent/basicResearch/index",
                    label: "基础调研",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_building1.png",
                    url: "pages/host/ent/building/list",
                    label: "现场调研",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_danger.png",
                    label: "隐患排查",
                    text: 0,
                    url: "/pages/host/danger/index",
                },
                // {
                // 	url: '../../../static/img/AppIcon/home_grid_map.png',
                // 	label: '应急演练',
                // 	text: 0
                // },
                {
                    src: "../../../static/img/AppIcon/home_grid_meeting.png",
                    label: "安全会议",
                    url: "pages/host/response/meeting/list",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_response.png",
                    label: "安全投入",
                    url: "pages/host/response/productCost/index",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_train.png",
                    label: "教育培训",
                    url: "pages/host/hostTrainPlan/list",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_main.png",
                    label: "台账一览",
                    url: "/pages/host/hostMain/siteReport",
                    text: 0,
                },
            ],
            dangerJgMenuList: [
                {
                    src: "../../../static/img/AppIcon/home_grid_task.png",
                    url: "/pages/dangerJg/task/list",
                    label: "隐患任务",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_dangerJgVerify.png",
                    url: "/pages/dangerJg/dangerJgVerify/index",
                    label: "隐患复查",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_verifyReportList.png",
                    label: "检查报告",
                    text: 0,
                    url: "/pages/dangerJg/report/verifyReportList",
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_checkEnterprise.png",
                    label: "总结报告",
                    text: 0,
                    url: "/pages/dangerJg/report/projectReportList",
                },
                {
                    src: "../../../static/img/AppIcon/home_grid_projectReportList.png",
                    url: "/pages/dangerJg/checkEnterprise/list",
                    label: "被检查单位",
                    text: 0,
                },
                {
                    src: "../../../static/img/AppIcon/project_setting.png",
                    url: "/pages/dangerJg/setting/index",
                    label: "项目参数",
                    text: 0,
                },
            ],
            logCount: 0,
            radioList: [{ name: "服务进度" }, { name: "服务日志" }],
            sectionCurrent: 0,
            logList: [],
            taskList: [],
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            clickShow: true,
            modulesId: ""
        };
    },
    filters: {
        getPercentage(item) {
            let finishPresent = 0;
            if (item.totalCnt == 0 && item.finishCnt > 0) {
                finishPresent = 100;
            }
            if (item.finishPresent > 0) {
                finishPresent = item.finishPresent;
            }
            if (item.finishPresent > 100) {
                finishPresent = 100;
            }
            if (
                item.finishPresent == 0 &&
                (item.overvueDates > 0 || item.overvuePercent > 0)
            ) {
                finishPresent = 100;
            }

            return finishPresent;
        },
    },
    created() {
        this.modulesId = this.$route.query.modulesId
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        if (this.$route.query.sectionCurrent) {
            this.sectionCurrent = Number(this.$route.query.sectionCurrent);
        }
        // this.search();
    },
    mounted() {
        //
    },
    methods: {
        search() {
            this.initData();
            this.initTaskCard();
            this.intitLogCard();
        },
        initData() {
            let _this = this;
            this.common
                .get(
                    "site/projectConsultation/getDataByCode/" +
                    this.queryParams.projectId,
                    {}
                )
                .then(function (res) {
                    if (res.code == 200) {
                        let data = res.data;
                        _this.project = data;
                        switch (data.serviceType) {
                            case "C":
                                _this.menuList = _this.hostMenuList;
                                break;
                            case "A":
                                _this.menuList = _this.dangerJgMenuList;
                                break;
                            default:
                                break;
                        }
                    } else {
                        //失败提示
                    }
                });
        },
        initTaskCard() {
            var _this = this;
            this.common
                .get(
                    "/site/projectConsultationTask/getTaskListByMainCode?code=" +
                    this.queryParams.projectId
                )
                .then((res) => {
                    if (res.code == 200) {
                        //  console.log("res.data: ", res.data);
                        _this.taskList = res.data;
                        //计算完成数 status==100表示完成
                        let arr = [];
                        arr = res.data.filter((item) => {
                            return item.status === 100;
                        });
                        this.radioList[0].name = `服务进度`;
                    }
                });
        },
        intitLogCard() {
            var _this = this;
            this.common
                .get(
                    "/site/projectConsultationTaskLog/getPageData?projectCode=" +
                    this.queryParams.projectId
                )
                .then((res) => {
                    if (res.code == 200) {
                        // _this.logList = res.data;
                        // _this.logCount = res.data.length;
                        // console.log("res.data: ", res.data);
                        this.radioList[1].name = `服务日志`;
                        this.$nextTick(() => {
                            _this.logList = res.data;
                        });
                        // console.log("this.logList: ", this.logList);
                    }
                });
        },
        handlerSectionChange(index) {
            this.sectionCurrent = index;
        },

        handlerViewClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/project/projectServiceLog/view",
                {
                    id: item.id,
                    enterpriseCode: this.queryParams.enterpriseCode ?? "",
                    projectId: this.queryParams.projectId ?? "",
                    modulesId: this.$route.query.modulesId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/project/projectServiceLog/detail",
                {
                    enterpriseCode: this.queryParams.enterpriseCode ?? "",
                    projectId: this.queryParams.projectId ?? "",
                    modulesId: this.$route.query.modulesId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        goTo(item) {
            let linkUrl = this.common.getLinkUrl(item.url, {
                enterpriseCode: this.queryParams.enterpriseCode ?? "",
                projectId: this.queryParams.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },
        getTaskName(taskName) {
            if (taskName.length > 6) {
                return taskName.substring(0, 6) + "...";
            } else {
                return taskName;
            }
        },
    },
};
</script>

<style scoped lang='scss'>
.host-container {
    width: 100vw;
    // height: 100vh;
    overflow: hidden;

    .circleShow {
        width: 100%;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .host-header {
        width: 100%;
        display: flex;
        justify-content: center;

        .host-header-item {
            padding: 15rpx;
            box-sizing: border-box;
            width: 100%;
            height: 250rpx;
            background: #ffffff;
            border-radius: 14rpx;

            .company-name {
                font-size: 40rpx;
                font-weight: 600;
                padding: 8rpx;
                box-sizing: border-box;
            }

            .company-address,
            .company-opp {
                font-size: 24rpx;
                padding: 8rpx;
                box-sizing: border-box;
                color: #a5a5a5;

                .phone {
                    color: #2979ff;
                }
            }

            .company-res {
                display: flex;
                font-size: 24rpx;
                padding: 8rpx;
                // justify-content: space-between;
                align-items: center;

                .company-res1 {
                    display: flex;
                    border: 1rpx solid #f99941;
                    border-radius: 10rpx;
                    margin-right: 50rpx;

                    view {
                        padding: 5rpx;
                        box-sizing: border-box;
                    }

                    .left {
                        width: 160rpx;
                        color: #f99941;
                        padding: 5rpx 10rpx;
                        box-sizing: border-box;
                        text-align: center;
                    }

                    .right {
                        min-width: 100rpx;
                        background-color: #f99941;
                        color: #ffffff;
                        padding: 5rpx 10rpx;
                        box-sizing: border-box;
                        text-align: center;
                    }
                }

                .company-res2 {
                    flex: 1;
                    color: #d0b66c;
                    // margin-right: 50rpx;
                }

                .details {
                    font-size: 30rpx;
                    color: #2979ff;
                }
            }
        }
    }

    .grid-item-box {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 10px 0;

        // position: relative;
        .image {
            width: 100rpx;
            height: 100rpx;
        }

        .text {
            font-size: 28rpx;
            margin-top: 10rpx;
        }
    }

    .subsection {
        margin-top: 15rpx;
        margin-left: 10px;
        margin-right: 10px;
        background: #fff;
    }

    .menu-show {
        width: 100%;
        // height: calc(100vh - 560px);
        margin-bottom: 5rpx;
    }

    .menu-hidden {
        width: 100%;
        height: calc(100vh - 320px);
    }

    .icon-arrow-up {
        width: 100%;
        height: 60rpx;
        text-align: center;
    }

    .line-item-title {
        display: flex;
        justify-content: flex-start;
        margin-bottom: 25rpx;
    }

    .line-item-content {
        width: 100%;
        background: #f1f1f1;
        padding: 30rpx 20rpx;
        box-sizing: border-box;
        color: #666;

        .line-item-content-item {
            display: flex;
            margin-bottom: 15rpx;

            .left {
                width: 200rpx;
                height: 60rpx;
                line-height: 60rpx;
                text-align: center;
                background: #31bdb4;
                padding: 0px 5px;
                // border-top-left-radius: 10rpx;
                // border-bottom-left-radius: 10rpx;
                border-radius: 10rpx;
                color: #ffffff;
                font-weight: 600;
                overflow: hidden;
                white-space: nowrap;

                text-overflow: ellipsis;

                -o-text-overflow: ellipsis;
            }

            .right {
                width: 150rpx;
                height: 60rpx;
                line-height: 60rpx;
                text-align: center;
                border: 1px solid #31bdb4;
                box-sizing: border-box;
                color: #31bdb4;
                font-weight: 600;
                border-top-right-radius: 10rpx;
                border-bottom-right-radius: 10rpx;
            }
        }
    }

    .view-text {
        /**
		思路：
		1.设置inline-block属相
		2.强制不换行
		3.固定高度
		4.隐藏超出部分
		5.显示“……”
	  */
        display: inline-block;
        white-space: nowrap;
        width: 65%;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .div-progress-list {
        display: flex;
        flex-wrap: wrap;
        margin-top: 15px;
    }

    .view-progress {
        width: 50%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        margin-bottom: 10px;
        position: relative;

        .div-progress-font {
            position: absolute;
            top: 20%;
            width: 50px;
            text-align: center;
            font-size: 12px;
            z-index: 9;
        }

        .div-taskName {
            margin-top: 10px;
        }
    }
}
</style>
