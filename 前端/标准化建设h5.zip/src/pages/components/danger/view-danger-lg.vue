<template name="view-danger-lg">
    <view class="view-danger-lg">
        <u-popup v-model="dialogShowVal" mode="bottom" height="100%">
            <eagle-head @close="dialogShowVal=false">检查项</eagle-head>
            <eagle-form v-model="model" ref="eagleForm" :boolInitData="false">
                <eagle-container>
                    <view v-if="isEdit">
                        <eagle-input type="textarea" title="依据来源" key="gistSource" v-model="model.gistSource" />
                        <eagle-input type="textarea" title="法律责任" key="legalLiability" v-model="model.legalLiability" />
                        <eagle-input type="textarea" title="法律原文" key="originalText" v-model="model.originalText" />
                    </view>
                    <view v-if="!isEdit">
                        <eagle-text title="依据来源" key="gistSource" v-model="model.gistSource" />
                        <eagle-text title="法律责任" key="legalLiability" v-model="model.legalLiability" />
                        <eagle-text title="法律原文" key="originalText" v-model="model.originalText" />
                    </view>
                </eagle-container>
            </eagle-form>
            <eagle-bottom-view>
                <u-button type="default" v-if="!isEdit" class="bottom-btn" @click="dialogShowVal=false">返回</u-button>
                <u-button type="primary" v-if="isEdit" class="bottom-btn" @click="confirmForm">确定</u-button>
            </eagle-bottom-view>
        </u-popup>
    </view>
</template>

<script> 
export default {
    name: "view-danger-lg",
    components: {
        // 'popup-danger-type': popupDangerType,
        // 'choose-danger-lg': chooseDangerLg,
        // 'view-danger-lg': viewDangerLg
    },
    props: {},
    data() {
        return {
            dialogShowVal: false,
            model: {},
            tempModel: {},
            isEdit: false,
            dangerTypeDialog: false,
            checkDatas: {},
        };
    },
    watch: {},
    created() {
        this.initParams();
    },
    methods: {
        confirmForm() {
            for (let key in this.model) {
                this.tempModel[key] = this.model[key];
            }
            //=this.model;
            this.dialogShowVal = false;
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("hidden_danger_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.checkDatas.checkType = res.data;
                        console.log(
                            "_this.checkDatas.checkType:",
                            _this.checkDatas.checkType
                        );
                    }
                });
        },
        show(config) {
            this.model = this.utils.deepClone(config.model);
            this.tempModel = config.model;
            this.isEdit = config.isEdit;
            this.dialogShowVal = true;
        },
        showDangerType() {
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.model.hiddenCode = obj.dCode;
            this.model.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeName = obj.dType == "1" ? "基础管理" : "现场管理";
            this.model.hiddenTypeCode = obj.dType;
            this.dangerTypeDialog = false;
        },
    },
};
</script>

<style lang="scss">
</style>
