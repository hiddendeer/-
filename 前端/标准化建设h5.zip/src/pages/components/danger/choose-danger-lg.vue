<template name="choose-danger-lg">
    <view class="choose-danger-lg">
        <u-popup v-model="dialogShowVal" mode="bottom" height="100%">
            <uni-page-head uni-page-head-type="default">
                <div class="uni-page-head" style="background-color:rgb(27, 118, 209); color:rgb(255, 255, 255);">
                    <div class="uni-page-head-hd">
                        <div class="uni-page-head-btn" @click="dialogShowVal=false">
                            <i class="uni-btn-icon" style="color: rgb(255, 255, 255); font-size: 27px;"></i>
                        </div>
                    </div>
                    <div class="uni-page-head-bd">
                        <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                            选择检查依据
                        </div>
                    </div>
                </div>
                <div class="uni-placeholder"></div>
            </uni-page-head>
            <view>
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.keywords.value"> </eagle-search>
                </view>
            </view>
            <eagle-page-list ref="eaglePageList" data-type="Public" @initList="_initList" :pageSize="10" controller="site/dangerlg" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="false">

                <view slot="list" class="list-wrap">
                    <view class="uni-media-cell" v-for="(item, index) in data" :key="index">
                        <!-- 	<view class="uni-media-cell-content" :key="index"> -->
                        <view class="uni-media-list">
                            <view class="uni-media-list-body">
                                <!-- 	<eagle-girdrow-base :isTitle="true">
									{{item.checkTaskName}}
								</eagle-girdrow-base> -->
                                <eagle-girdrow-base class="item">
                                    <view>
                                        <text>[关键词]{{item.keyword}}</text>
                                    </view>
                                    <view>
                                        <text>[整改建议]{{item.correctiveAdvise}} </text>
                                    </view>
                                    <view class="item_child">
                                        <view v-for="(citem,cindex) in item.hiddenDangerList" :key="index+'_'+cindex">
                                            <text>[隐患描述]{{citem.hiddenDangerDesc}} </text>
                                            <view class="tool-bars">
                                                <view class="left-tool-bars">
                                                    <view class="tool-bars-item" style="position: relative; " @click="chooseSingerConfirm(item,citem)" v-if="opType===2">
                                                        <img src="@/static/img/AppIcon/activity_login_addeq.png" style="position: absolute;height: 32rpx;" />
                                                        <span style="margin-left: 34rpx;">选择</span>
                                                    </view>
                                                    <view class="tool-bars-item" v-if="opType===1">
                                                        <u-upload :custom-btn="true" :header="uploadHead" @on-choose-complete="chooseDataUpload(item,citem)" :action="action" :ref="'historyFrequency-uUpload-'+index+'-'+cindex" @on-success="onUploadSuccess" :show-tips="false" :max-count="1" :show-progress="false" :show-upload-list="false">
                                                            <view slot="addBtn" style="position: relative; " class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
                                                                <img src="@/static/img/AppIcon/icon_camera.png" style="position: absolute;height: 40rpx;" />
                                                                <span style="margin-left: 40rpx;">拍照</span>
                                                            </view>
                                                        </u-upload>
                                                    </view>
                                                </view>
                                            </view>

                                            <!-- <view><u-button @click="chooseImg" >选择图片</u-button></view> -->
                                        </view>
                                    </view>
                                </eagle-girdrow-base>
                            </view>
                        </view>
                    </view>
                </view>
            </eagle-page-list>
            <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
        </u-popup>
    </view>
</template>

<script>
export default {
    name: "choose-danger-lg",
    props: {},
    data() {
        return {
            opType: 0, //1 依据查,2检查表检查,3随手拍
            uploadHead: {
                Authorization: "",
            },
            action: "/prod-api/file/upload",
            dialogShowVal: false,
            searchValue: {
                //dataType:"Public"
            },
            conditions: {
                keywords: {
                    value: "",
                    operate: "like",
                },
            },
            data: [],
            clearabled: true,
            chooseModel: {},
            chooseModelChild: {},
            model: {},
        };
    },

    watch: {},
    created() {
        var token = uni.getStorageSync("token");
        this.uploadHead.Authorization = "Bearer " + token;
    },
    mounted() {
        this.search();
    },
    methods: {
        onUploadSuccess(res, index, lists, name) {
            if (res.code == 200) {
                let model = {};
                model.attachs = res.data.filePath;
                this.setModel(model, this.chooseModel, this.chooseModelChild);
                this.dialogShowVal = false;
                this.$emit("choosed", model, this.opType);
            }
        },
        show(config) {
            this.dialogShowVal = true;
            this.opType = config.opType;
            this.model = config.model;
        },
        search() {
            let _this = this;
            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.searchValue,
            });
        },
        setModel(model, obj, citem) {
            let _this = this;
            model.itemName = obj.correctiveAdvise;
            model.originalText = obj.originalText;
            model.legalLiability = obj.legalLiability;
            model.gistSource = obj.gistSource;
            model.correctiveAdvise = obj.correctiveAdvise;
            model.hiddenCode = citem.dCode;
            model.hiddenName = citem.dfullName.replace(">", "-");
            model.hiddenTypeCode =
                citem.dfullName.split("-")[0] === "基础管理" ? "1" : "2";
            model.hiddenTypeName = citem.dfullName.split("-")[1];
            model.hiddenDangerDesc = citem.hiddenDangerDesc;
            model.hiddenDangerTypeCode =
                citem.hiddenDangerTypeName == "一般隐患" ? "1" : "2";
        },
        _initList(list) {
            this.data = list;
        },
        chooseDataUpload(item, citem) {
            this.chooseModel = item;
            this.chooseModelChild = citem;
        },
        chooseSingerConfirm(obj, citem) {
            let _this = this;
            if (_this.model && _this.model.hiddenDangerDesc) {
                _this.$refs.eagleConfirm.showConfirm({
                    content: "是否覆盖此数据？",
                    confirm: function () {
                        _this.setModel(_this.model, obj, citem);
                        _this.$emit("choosed", obj, _this.opType);
                        _this.dialogShowVal = false;
                    },
                });
            } else {
                _this.setModel(_this.model, obj, citem);
                _this.$emit("choosed", obj, _this.opType);
                _this.dialogShowVal = false;
            }
        },
    },
};
</script>

<style lang="scss">
.choose-danger-lg {
    .container {
        padding-bottom: 10rpx;
    }
}
</style>
