<template>
    <view>
        <u-popup v-model="dialogShowVal" mode="bottom" height="100%">
            <uni-page-head uni-page-head-type="default">
                <div class="uni-page-head" style="background-color:rgb(27, 118, 209); color:rgb(255, 255, 255);">
                    <div class="uni-page-head-hd">
                        <div class="uni-page-head-btn" @click="clickClose">
                            <i class="uni-btn-icon" style="color: rgb(255, 255, 255); font-size: 27px;"></i>
                        </div>
                    </div>
                    <div class="uni-page-head-bd">
                        <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                            选择隐患分类
                        </div>
                    </div>
                </div>
                <div class="uni-placeholder"></div>
            </uni-page-head>
            <view class="danger-type">
                <view class="container">
                    <view class="title-container">
                        <view class="title">
                            现场管理
                        </view>
                    </view>
                    <view class="tags">
                        <view class="button" v-for="(item,index) in array2" :key="index" @click="click(item)" :style="[elActiveColor(item)]">
                            {{item.dName}}
                        </view>
                    </view>
                </view>
                <view class="container">
                    <view class="title-container">
                        <view class="title">基础管理</view>
                    </view>
                    <view class="tags">
                        <view class="button" v-for="(item,index) in array1" :key="index" @click="click(item)" :style="[elActiveColor(item)]">
                            {{item.dName}}
                        </view>
                    </view>
                </view>
            </view>
        </u-popup>
    </view>
</template>

<script>
export default {
    name: "popup-danger-type",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        // names:{
        // 	type:[String, Number],
        // 	default: ''
        // },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        disabledValues: {
            type: String,
            default() {
                return "";
            },
        },
        checkedValues: {
            type: String,
            default() {
                return "";
            },
        },
        activeColor: {
            type: String,
            default() {
                return "#2979ff";
            },
        },
        shape: {
            type: String,
            default() {
                return "square";
            },
        },
        labelDisabled: false,
        max: {
            type: [Number, String],
            default() {
                return 999;
            },
        },

        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        height: {
            type: String,
            default: "20px",
        },

        dialogShow: {
            type: Boolean,
            default() {
                return false;
            },
        },
        itemType: {
            type: [Number, String],
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            dialogShowVal: this.dialogShow,
            array: [],
            array1: [],
            array2: [],
            Name: this.title,
            textVal: "",
            defaultVal: this.value,
            volidMessageVal: "",
            placeholderVal: "",
            labelPositionVal: "",
            errorMessageVal: "",
        };
    },
    computed: {},
    watch: {
        dialogShowVal(nVal, oVal) {
            if (oVal != nVal) {
                this.dialogShowVal = nVal;
                this.$emit("update:dialogShow", this.dialogShowVal);
            }
        },
        dialogShow(nVal, oVal) {
            if (nVal !== oVal) {
                this.dialogShowVal = nVal;
            }
        },
    },
    created() {
        this.initData();
    },
    methods: {
        initData() {
            let _that = this;
            this.common
                .get("site/dangerTemplate/getDangerType/1")
                .then(function (res) {
                    if (res.code === 200) {
                        _that.array = res.data;
                        _that.array1 = res.data.filter((x) => x.dType === "1");
                        _that.array2 = res.data.filter((x) => x.dType === "2");
                    }
                });
        },
        clickClose() {
            this.dialogShowVal = false;
            this.$emit("close");
        },
        click(item) {
            this.dialogShowVal = false;
            this.textVal =
                (item.dType === "1" ? "基础管理-" : "现场管理-") + item.DName;
            //this.$emit('update:names', this.textVal);
            this.$emit("input", item.dCode);
            this.$emit("change", item);
        },
        elActiveColor(item) {
            if (item.dCode === this.value) {
                return {
                    color: this.activeColor,
                };
            }
            return {};
        },
    },
};
</script>

<style lang="scss">
.danger-type {
    background: #fff;

    .container {
        padding-bottom: 10rpx;
    }

    .title-container {
        height: 75rpx;
        background-color: #e8f1f8;
        padding-left: 10rpx;
        line-height: 75rpx;
    }

    .title {
        padding-left: 5rpx;
        border-left: 10rpx solid #00c3e0;
        font-size: 36rpx;
        font-weight: 600;
    }

    .tags {
        display: -webkit-inline-box;
        display: -webkit-inline-flex;
        display: inline-flex;
        align-content: flex-start;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
    }

    .button {
        display: flexbox;
        margin-top: 10rpx;
        margin-left: 6rpx;
        width: 240rpx;
        text-align: left;
        overflow: hidden;
        font-size: 26rpx;
        height: 70rpx;
        line-height: 70rpx;
        white-space: nowrap;
        text-align: center;
        justify-content: center;
        border: 2rpx solid #eaeff3;
        border-radius: 10rpx;
    }
}
</style>
