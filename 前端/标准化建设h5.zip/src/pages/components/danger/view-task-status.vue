<template>
	<view :class="{'fr':fr}">
		<text :class="{'grid-status-color-base':value==30,'grid-status-color-danger':value==10,'grid-status-color-success':value==100}">{{getTaskStatusName(value)}}</text>
	</view>
</template>

<script>
	import dangerCommon from "@/pages/danger/method/method.js";
	export default {
		name: "view-task-status",
		props: {
			value: {
				type:[String, Number],
				default: ''
			},
			fr: {
				type:Boolean,
				default: false
			},
		},
		data() {
			return {
			};
		},
		
		methods:{
			getTaskStatusName()
			{
				return dangerCommon.getTaskStatusName(this.value);
			}
		}
		
	}
</script>
