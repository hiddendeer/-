<template>
	<view>
		<u-row class="center-board-row">
			<u-form :size="formConf.size" :label-position="formConf.labelPosition" :disabled="formConf.disabled"
				:label-width="formConf.labelWidth+'px'">
				<div class="card-span" v-for="(card,index) in dataList" id="card-span">
					<div class="title-span">
						<div
							style="width: 5px;height: 25rpx; background: #a7a7a7;margin-right: 10rpx;border-radius: 10rpx;">
						</div>
						<view class="">{{card.label}}</view>
					</div>
					<u-collapse>
						<u-collapse-item @change="itemChange" :index="index" :open="card.open"
							:disabled="card.disabled">
							<draggable class="drawing-board" :list="card.drawingList" :animation="340"
								group="componentsGroup">
								<draggable-item v-for="(element, index) in card.drawingList" :key="element.renderKey"
									:drawing-list="card.drawingList" :element="element" :index="index"
									:form-conf="formConf" />
							</draggable>
							<u-button @click="editFunc">编辑</u-button>
							<u-button>保存</u-button>
						</u-collapse-item>
					</u-collapse>
				</div>
			</u-form>
		</u-row>
	</view>
</template>

<script>
	import draggable from 'vuedraggable'
	import DraggableItem from '@/components/DraggableItem'
	import request from "@/common/request.js";
	import common from "@/common/common.js";
	export default {
		components: {
			draggable,
			DraggableItem
		},
		data() {
			return {
				formConf: {
					formRef: 'elForm',
					formModel: 'formData',
					size: 'medium',
					labelPosition: 'right',
					labelWidth: 100,
					formRules: 'rules',
					gutter: 15,
					disabled: false,
					span: 24,
					formBtns: true
				},
				dataList: [{
					groupId: 0,
					label: "基本信息",
					open: false,
					drawingList: [{
							ComponetsType: "mostCommon",
							title: "企业名称",
							vModel: "EnterpriseName",
							tag: "eagle-input",
							tagIcon: "input",
							placeholder: "请输入企业名称",
							style: {
								width: "100%"
							},
							clearable: false,
							maxlength: 10,
							"show-word-limit": false,
							readonly: false,
							disabled: false,
							required: true,
							defaultValue: "文库",
							regList: [],
							changeTag: true,
							formId: 102,
							span: 24,
							layout: "colFormItem"
						},
						{
							ComponetsType: "mostCommon",
							title: "营业执照",
							vModel: "attachs",
							tag: "eagle-upload",
							tagIcon: "upload",
							style: {
								width: "100%"
							},
							clearable: false,
							"show-word-limit": false,
							readonly: false,
							disabled: false,
							required: true,
							defaultValue: "",
							regList: [],
							changeTag: true,
							formId: 102,
							span: 24,
							layout: "colFormItem",
							name: 'file',
						}
					]
				}, {
					"groupId": 1,
					label: "管理人员信息",
					open: false,
					drawingList: [{
						ComponetsType: "mostCommon",
						title: "统一社会信用代码",
						vModel: "creditCode",
						tag: "eagle-input",
						tagIcon: "input",
						placeholder: "请输入统一社会信用代码",
						style: {
							width: "100%"
						},
						clearable: true,
						maxlength: 10,
						"show-word-limit": false,
						readonly: false,
						disabled: false,
						required: true,
						regList: [],
						changeTag: true,
						formId: 103,
						span: 24,
						layout: "colFormItem"
					}]
				}, {
					"groupId": 2,
					label: "风险管理信息",
					open: false,
					drawingList: [{
						ComponetsType: "mostCommon",
						title: "安全责任人",
						vModel: "personSecurity",
						tag: "eagle-input",
						tagIcon: "input",
						placeholder: "请输入安全责任人",
						style: {
							width: "100%"
						},
						clearable: true,
						required: true,
						formId: 104,
						span: 24,
						layout: "colFormItem"
					}]
				}, {
					"groupId": 3,
					label: "关键风险点",
					open: false,
					drawingList: []
				}, {
					"groupId": 4,
					label: "特殊作业人员或设备信息",
					open: false,
					drawingList: [{
						formId: 101,
						layout: "colFormItem",
						ComponetsType: "mostCommon",
						tagIcon: "input",
						style: {
							width: "100%"
						},
						title: "所在地区",
						tag: "eagle-city-group",
						placeholder: "选择所在地区",
						required: true,
						vModel: "mapPosition",
						span: 24,
					}]
				}],
				EnterpriseName: 'sdfsfsdfsdf',
				creditCode: "123213213"
			}
		},
		created() {
			request({
				url: `/system/template/getTemplateByType/${1}`,
				method: 'get',
			})
		},
		mounted() {
			console.log(window);
			console.log($('#card-span'));
		},
		methods: {
			itemChange(item) {
				for (var i = 0; i < this.dataList.length; i++) {
					if (item.index === i) {
						this.dataList[i].open = true;
					} else {
						this.dataList[i].open = false;
					}
				}
			},
			editFunc(){
				common.postBase64().then((res)=>{
					console.log("com"+res.data)
				})
				// 初始化
				console.log('Hello world signature1');
				// serve.signature().then(res=> {
				// 	console.log(JSON.stringify(res));
				// })
				console.log('Hello world signature2');
			}
		}
	}
</script>

<style lang="scss" scoped>
	.title-span {
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	/deep/.u-collapse-head {
		padding: 0;
	}

	/deep/.u-icon-wrap {
		margin-top: -25px;
	}

	/deep/.u-form-item--left__content--required {
		left: -6px;
	}

	.center-board-row {
		background-color: #f3f4fa;
	}

	.u-form {
		width: 100%;
		margin: 10px;
	}

	.card-span {
		background-color: #FFFFFF;
		margin-bottom: 10px;
		padding: 10px;
		border-radius: 10px
	}
</style>
