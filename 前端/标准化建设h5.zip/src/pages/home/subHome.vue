<template>
    <view class="warp">
        <view class="example-body">
            <uni-grid :column="3" :show-border="false" :square="false" @change="change">
                <uni-grid-item v-for="(item ,index) in list" :index="index" :key="index">
                    <view class="grid-item-box">
                        <image class="image" :src="item.icon" mode="aspectFill" />
                        <text class="text">{{item.menuName}}</text>
                        <!-- <view v-if="item.badge" class="grid-dot">
							<uni-badge :text="item.badge" :type="item.type" />
							<uni-badge :text="item.badge" type="primary"></uni-badge>
						</view> -->
                    </view>
                </uni-grid-item>
            </uni-grid>
        </view>
    </view>
</template>


<script>
export default {
    components: {},
    data() {
        return {
            parentId: null,
            dynamicList: [],
            list: [],
        };
    },
    onLoad(data) {
        this.parentId = data.parentId;
    },
    created() {
        this.setMenu();
    },
    methods: {
        setMenu() {
            let data = { parentId: this.parentId };
            this.common.post("/system/phoneMenu/list", data).then((result) => {
                this.list = result.data;
            });
        },
        change(e) {
            let { index } = e.detail;

            if (this.list[index].path) {
                let url = this.list[index].path;
                this.base.navigateTo(url);
            } else {
                let url =
                    "/pages/home/subHome?parentId=" + this.list[index].menuId;
                this.base.navigateTo(url);
            }
            // uni.showToast({
            // 	title: `点击第${index+1}个宫格`,
            // 	icon: 'none'
            // })
        },
        add() {
            if (this.dynamicList.length < 9) {
                this.dynamicList.push({
                    url: `/static/c${this.dynamicList.length + 1}.png`,
                    text: `Grid ${this.dynamicList.length + 1}`,
                    color:
                        this.dynamicList.length % 2 === 0 ? "#f5f5f5" : "#fff",
                });
            } else {
                uni.showToast({
                    title: "最多添加9个",
                    icon: "none",
                });
            }
        },
        del() {
            this.dynamicList.splice(this.dynamicList.length - 1, 1);
        },
    },
};
</script>

<style lang="scss">
// @import '@/common/uni-nvue.scss';

.image {
    width: 50rpx;
    height: 50rpx;
}

.text {
    font-size: 26rpx;
    margin-top: 10rpx;
}

.example-body {
    /* #ifndef APP-NVUE */
    display: block;
    /* #endif */
}

.grid-dynamic-box {
    margin-bottom: 15px;
}

.grid-item-box {
    flex: 1;
    // position: relative;
    /* #ifndef APP-NVUE */
    display: flex;
    /* #endif */
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 15px 0;
}

.grid-dot {
    position: absolute;
    top: 5px;
    right: 15px;
}
.swiper {
    height: 420px;
}
</style>


