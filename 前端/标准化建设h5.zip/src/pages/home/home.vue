<template>
    <view class="warp">
        <view class="example-body">
            <view class="module-block" v-for="(item ,index) in list" :index="index" :key="index">
                <view class="home-title">{{item.menuName}}</view>

                <uni-grid :column="3" :show-border="false" :square="false">
                    <uni-grid-item v-for="(ditem ,dIndex) in item.childs" :index="dIndex" :key="dIndex">
                        <view class="grid-item-box" @click="goto(ditem.path)">
                            <image class="image" :src="ditem.icon" mode="aspectFill" />
                            <text class="text">{{ditem.menuName}}</text>
                        </view>
                    </uni-grid-item>
                </uni-grid>
            </view>
        </view>
    </view>
</template>


<script>
export default {
    components: {},
    data() {
        return {
            dynamicList: [],
            list: [],
        };
    },
    created() {
        this.setMenu();
    },
    methods: {
        setMenu() {
            // let data = { parentId : 0 };
            this.common
                .get("/system/phoneMenu/selectPhoneMenu", {})
                .then((result) => {
                    this.list = result.data;
                });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
    },
};
</script>

<style lang="scss" scoped>
.home-title {
    line-height: 30px;
    font-weight: bold;
    text-indent: 20px;
}
.module-block {
    margin: 10px;
    border-bottom: 1px solid #ddd;
}
.image {
    width: 70rpx;
    height: 70rpx;
}

.text {
    font-size: 28rpx;
    margin-top: 10rpx;
}

.example-body {
    /* #ifndef APP-NVUE */
    display: block;
    /* #endif */
}

.grid-dynamic-box {
    margin-bottom: 15px;
}

.grid-item-box {
    flex: 1;
    // position: relative;
    /* #ifndef APP-NVUE */
    display: flex;
    /* #endif */
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 15px 0;
}

.grid-dot {
    position: absolute;
    top: 5px;
    right: 15px;
}
.swiper {
    height: 420px;
}
</style>


