<template>
    <view class="wrap login-content">
        <view v-if="!isGuan">
            <u-form :model="model" ref="uForm" :errorType="errorType">
                <u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="account" label-width="150" :label-position="labelPosition" label="手机号" prop="username">
                    <u-input :border="border" placeholder="请输入手机号" v-model="model.username" maxlength="10000" type="text"></u-input>
                </u-form-item>
                <u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="lock" label-width="150" :label-position="labelPosition" label="密码" prop="password">
                    <u-input :password-icon="true" :border="border" type="password" v-model="model.password" placeholder="请输入密码"></u-input>
                </u-form-item>

            </u-form>
            <u-button @click="submit">登录</u-button>
        </view>
        <view v-else>
            <view class="warnin-btn">
                <u-icon name="minus-circle" color="#777" size="170"></u-icon>
            </view>
            <view class="warnin-mes">您的账号已在其他设备登录，当前鉴权已失效。请重新登录后再次进入应用。</view>
            <view class="warnin-btn">
                <u-button size="medium" @click="close()">关闭</u-button>
            </view>
        </view>
    </view>
</template>

<script>
import { mapMutations } from "vuex";
import {
    handleLogin,
    authToken,
    setCookie,
} from "@/api/auth.js";
export default {
    data() {
        return {
            model: {
                username: "",
                password: "",
                remember: false,
                companyId: "",
            },
            rules: {
                username: [
                    {
                        required: true,
                        message: "请输入手机号",
                        // 可以单个或者同时写两个触发验证方式
                        trigger: "change",
                    },
                ],
                password: [
                    {
                        required: true,
                        message: "请输入密码",
                        trigger: "change",
                    },
                ],
            },
            border: false,
            check: false,
            labelPosition: "left",
            errorType: ["message"],
            isGuan: false,
        };
    },
    onLoad() {
        // if (process.env.VUE_APP_ENV === "development") {
        //     console.log(process.env.VUE_APP_ENV);
        //     console.log(process.env.VUE_APP_BASE_API);
        // } else if (process.env.VUE_APP_ENV === "production") {
        //     console.log(process.env.VUE_APP_ENV);
        //     console.log(process.env.VUE_APP_TITLE);
        //     console.log(process.env.VUE_APP_BASE_API);
        // } else if (process.env.VUE_APP_ENV === "staging") {
        //     console.log(process.env.VUE_APP_ENV);
        //     console.log(process.env.VUE_APP_BASE_API);
        // }
    },
    created() {
        var envP = process.env.VUE_APP_ENV;
        if (envP == "production") {
            var userAgent = navigator.userAgent;
            if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
                this.isGuan = true;
            }
        }
    },
    computed: {
        borderCurrent() {
            return this.border ? 0 : 1;
        },
    },
    onReady() {
        this.$refs.uForm.setRules(this.rules);
    },
    methods: {
        submit() {
            this.$refs.uForm.validate((valid) => {
                if (valid) {
                    console.log("验证通过");
                    let data = {
                        username: this.model.username,
                        password: this.model.password,
                    };
                    handleLogin(data, function (res) {
                        if (res.code == 200) {
                            uni.reLaunch({
                                url: "/pages/tabBar/element-list/element-list",
                            });
                        }
                    });
                } else {
                    console.log("验证失败");
                }
            });
        },
        close() {
            serve.onClose();
        },
        // ...mapMutations(['login'])
    },
};
</script>

<style scoped lang="scss">
.wrap {
    padding: 30rpx;
}
.login-content {
    .warnin-mes {
        color: #777;
        line-height: 36px;
        text-indent: 25px;
        font-size: 16px;
        margin-top: 36px;
    }
    .warnin-btn {
        text-align: center;
        margin-top: 10px;
    }
}
</style>
