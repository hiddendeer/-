var dangerCommon = {
	getTaskStatusName: function (val) {
		if (val) {
			switch (val) {
				case 10:
					return "进行中";
				case 30:
					return "待复查";
				case 100:
					return "复查通过";
			}
		}
		return "";
	},

}

export default dangerCommon