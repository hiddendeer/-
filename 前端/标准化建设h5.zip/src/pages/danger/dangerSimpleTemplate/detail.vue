<template>
    <view class="danger-simple-template-detail">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <uni-page-head uni-page-head-type="default">
                <div class="uni-page-head" style="background-color:rgb(27, 118, 209); color:rgb(255, 255, 255);">
                    <div class="uni-page-head-hd">
                        <div class="uni-page-head-btn" @click="showDialog=false">
                            <i class="uni-btn-icon" style="color: rgb(255, 255, 255); font-size: 27px;"></i>
                        </div>
                    </div>
                    <div class="uni-page-head-bd">
                        <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                            检查表检查
                        </div>
                    </div>
                </div>
                <div class="uni-placeholder"></div>
            </uni-page-head>
            <view>
                <view class="statistics">
                </view>
                <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="tempModel" ref="eagleForm" :out-height='110'>
                    <view v-for="(item,index) in model" :key="index">
                        <view class="item">
                            <view class="item-title" @click="showContent(index)">
                                <view style="width: 100%;">
                                    {{item.groupTitle}} |
                                    共{{ item.checkTaskDetails.length }}个项目
                                </view>
                                <view class="u-input__right-icon u-flex">
                                    <u-icon :name="itemShowArray[index]?'arrow-up':'arrow-down' " size="26" color="#c0c4cc">
                                    </u-icon>
                                </view>
                            </view>
                            <view class="item-container" v-if="itemShowArray[index]">
                                <view class="citem" v-for="(citem,cindex) in item.checkTaskDetails" :key="cindex">
                                    <view class="citem-title">{{citem.templateItemName}}</view>
                                    <view class="button-pannel">
                                        <view class="button-item Y " :class="citem.checkResult==='Y'?'checked':''" @click="checkStatus(citem,'Y')">符合</view>
                                        <view class="button-item N" :class="citem.checkResult==='N'?'checked':''" @click="checkStatus(citem,'N')">不符合</view>
                                        <view class="button-item NA" :class="citem.checkResult==='NA'?'checked':''" @click="checkStatus(citem,'NA')">不适用</view>
                                    </view>

                                    <view v-if="citem.checkResult==='NA'">
                                        <eagle-input :key="'remarks'+index+'_'+cindex" type="textarea" title="备注" prop="Remarks" v-model="citem.remarks" />
                                    </view>

                                    <view v-if="citem.checkResult==='Y'">
                                        <eagle-upload title="图片" :key="'attachsYes'+index+'_'+cindex" v-if="isEdit" prop="attachsYes" v-model="citem.attachsYes" />

                                        <eagle-input :key="'checkRemark'+index+'_'+cindex" type="textarea" title="检查情况" prop="checkRemark" v-model="citem.checkRemark" />
                                    </view>
                                    <view v-if="citem.checkResult==='N'">

                                        <eagle-upload :isNeedEdit="true" title="隐患图片" key="attachs" prop="attachs" v-model="citem.attachs" required />

                                        <eagle-input v-if=" setModel.hiddenDangerArea==='true'" type="textarea" title="隐患区域" required v-model="citem.correctiveArea" />
                                        <view v-if="setModel.gistSource==='true'" style="text-align: right;">
                                            <span style="color:#2979ff;margin-left: 10rpx;" @click="hdChooseLg(citem)">选择依据</span>
                                            <span style="color:#2979ff;margin-right: 20rpx;margin-left: 20rpx;" @click="showDetail(citem)">{{ "编辑依据" }}</span>
                                        </view>
                                        <eagle-input v-if="setModel.hiddenDangerDesc==='true'" type="textarea" title="隐患描述" required v-model="citem.hiddenDangerDesc" />
                                        <eagle-choose v-if="setModel.hiddenCode==='true'" title="隐患分类" v-model="citem.hiddenName" required :select-open="dangerTypeDialog" @click="showDangerType(model)">
                                        </eagle-choose>
                                        <eagle-radios v-if=" setModel.hiddenDangerTypeCode==='true' && checkDatas.checkType.length>0" title="隐患性质" required :data-source="checkDatas.checkType" v-model="citem.hiddenDangerTypeCode" />
                                        <eagle-input v-if=" setModel.correctiveMeasure==='true'" type="textarea" title="整改措施" v-model="citem.correctiveMeasure" />
                                        <eagle-date v-if="setModel.correctiveDeadline==='true' " label-width="100px" key="correctiveDeadline" title="整改期限" v-model="citem.correctiveDeadline" />
                                        <eagle-input v-if=" setModel.correctiveDeptName==='true'" type="textarea" title="整改部门" v-model="citem.correctiveDeptName" />
                                        <eagle-input v-if=" setModel.correctiveUserChName==='true'" type="textarea" title="整改人" v-model="citem.correctiveUserChName" />
                                    </view>

                                </view>
                            </view>
                        </view>
                    </view>
                </eagle-form>
                <eagle-bottom-view v-if="isEdit">
                    <u-button type="primary" class="bottom-btn" @click="post()">保存并返回</u-button>
                </eagle-bottom-view>
                <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog=false" v-model="itemData.hiddenCode" @change="changeDangeType"></popup-danger-type>
            </view>

            <choose-danger-lg ref="chooseDangerLg"></choose-danger-lg>
            <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        </u-popup>
        <u-toast ref="uToast" />
    </view>
</template>
<script>
import popupDangerType from "../../components/danger/popup-danger-type.vue";

import chooseDangerLg from "@/pages/components/danger/choose-danger-lg";
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
export default {
    components: {
        "popup-danger-type": popupDangerType,
        "choose-danger-lg": chooseDangerLg,
        "view-danger-lg": viewDangerLg,
    },
    name: "danger-simple-template-detail",
    data() {
        return {
            dangerTypeDialog: false,
            tempModel: {}, //没用的 只是为了给form bind个对象
            showDialog: false,
            control: "DangerCheckTemp",
            param: {
                templateCode: "",
            },
            isEdit: false,
            model: [],
            itemData: {},
            totalCount: 0,
            itemShowArray: [],
            checkDatas: {
                checkType: [],
                correctiveType: [
                    {
                        id: 1,
                        name: "立即整改",
                    },
                    {
                        id: 2,
                        name: "限时整改",
                    },
                ],
            },
            setModel: {},
        };
    },
    created() {
        this.initParams();
    },
    methods: {
        initParams() {
            var _this = this;
            this.common
                .getModuleSettins("danger_check_simple")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.setModel = res.data;
                    }
                });
            this.common
                .getCustomDict("danger_simple_danger_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.checkDatas.checkType = res.data;
                        console.log(_this.checkDatas.checkType);
                    }
                });
        },
        hdChooseLg(item) {
            this.$refs.chooseDangerLg.show({
                opType: 2,
                model: item,
            });
        },
        showDetail(item) {
            let config = {
                isEdit: true,
                model: item,
            };
            this.$refs.viewDangerLg.show(config);
        },
        postVolid() {
            let _this = this;
            let message = "";
            _this.model.forEach((x, index) => {
                if (message) return false;
                x.checkTaskDetails.forEach((p, cindex) => {
                    if (message) return false;
                    if (p.checkResult == "N") {
                        let no = index + 1 + "." + (cindex + 1);
                        if (!p.attachs) {
                            message = `第${no}项;请上传隐患图片`;
                            return false;
                        }
                        if (
                            _this.setModel.correctiveArea === "true" &&
                            !p.correctiveArea
                        ) {
                            message = `第${no}项;请输入隐患区域`;
                            return false;
                        }
                        if (
                            _this.setModel.hiddenDangerDesc === "true" &&
                            !p.hiddenDangerDesc
                        ) {
                            message = `第${no}项;请输入隐患描述`;
                            return false;
                        }
                        if (
                            _this.setModel.hiddenCode === "true" &&
                            !p.hiddenName
                        ) {
                            message = `第${no}项;请选择隐患分类`;
                            return false;
                        }
                        if (
                            _this.setModel.hiddenDangerTypeCode === "true" &&
                            !p.hiddenDangerTypeCode
                        ) {
                            message = `第${no}项;请选择隐患性质`;
                            return false;
                        }
                    }
                });
            });
            if (message) {
                _this.$refs.uToast.show({
                    title: message,
                    type: "error",
                });
                return false;
            }
            return true;
        },

        post() {
            let _this = this;
            _this.$refs.eagleForm.post({
                url: "danger/simpleCheck/saveCheckItems",
                model: _this.model,
                needValid: false,
                validCallback: function () {
                    return _this.postVolid();
                },
                successCallback: function (res) {
                    _this.showDialog = false;
                    _this.$emit("saved");
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },

        showDangerType(obj) {
            this.itemData = obj;
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.itemData.hiddenCode = obj.dCode;
            this.itemData.hiddenName = obj.dFullName.replace(">", "-");
            this.itemData.hiddenTypeCode = obj.dType;
            this.itemData.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.dangerTypeDialog = false;
        },
        setCheckResult(item, result) {
            item.checkResult = item.checkResult === result ? "" : result;
        },
        show(options) {
            this.itemShowArray[0] = true;
            this.showDialog = true;
            this.param.templateCode = options.templateCode;
            //this.param.taskCode = options.taskCode;
            this.isEdit = options["isEdit"];
            console.log(this.isEdit);
            this.initParams();
            this.getModel();
        },
        showContent(index) {
            this.$set(
                this.itemShowArray,
                index,
                this.itemShowArray[index] ? false : true
            );
        },
        getModel() {
            var _this = this;
            this.common
                .get(
                    `danger/simpleCheck/getCheckItems/${_this.param.templateCode}`
                )
                .then((res) => {
                    _this.model = res.data;
                    _this.totalCount = res.data.length;
                });
        },

        checkStatus(obj, op) {
            if (this.isEdit) {
                if (obj.checkResult == op) {
                    obj.checkResult = "";
                } else obj.checkResult = op;
            }
        },

        goto(url) {
            this.base.navigateTo(url);
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-simple-template-detail {
    background-color: #ffffff;

    .statistics {
        margin-top: 30rpx;
        padding: 0 30rpx;
    }

    .form-content {
        .item {
            .item-title {
                display: flex;
                background-color: #2979ff;
                line-height: 35px;
                margin: 10px -30px;
                padding: 0px 30px;
                font-size: 16px;
                font-weight: 600;
                color: #ffffff;
                -webkit-box-flex: 1;
                -webkit-flex: 1;
                flex: 1;

                .arrow-up-fill {
                    text-align: right;
                }
            }

            .citem {
                padding: 10px 0px;
            }
        }
    }

    .button-pannel {
        width: 100%;
        display: inline-flex;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;

        .button-item {
            margin-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            border: 1px solid #dfe4ec;
            width: 28%;
            /* height: 30px; */
            border-radius: 5px;
            line-height: 30px;
        }

        .button-item.Y.checked {
            border: 1rpx solid #19be6b;
            background-color: #19be6b;
            color: #ffffff;
        }

        .button-item.NA.checked {
            border: 1rpx solid #ff976a;
            background-color: #ff976a;
            color: #ffffff;
        }

        .button-item.N.checked {
            border: 1rpx solid red;
            background-color: red;
            color: #ffffff;
        }
    }
}

// .view-botton {
// 	padding: 20rpx;
// }
</style>
