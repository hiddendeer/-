<template>
	<view>
		<handCheckDetail ref="handCheckDetail" @saved="saved">
		</handCheckDetail>
	</view>
</template>

<script>
	import handCheckDetail from '../components/handCheckDetail'
	export default {
		components: {
			handCheckDetail
		},
		data() {
			return {
				model: {},
				id: "0",
				controller: "danger/simpleCheck"
			}

		},
		created() {
			this.id = this.$route.query.id?this.$route.query.id:"0" ;
		},
		onReady() {
			this.showHandCheckDetail()
		},
		methods: {
			saved(){
				
			},			
			// getModel() {
			// 	let _this = this;
			// 	let funName = "getData";
			// 	if (!_this.id || _this.id == "0") {
			// 		funName = "initData";
			// 	}
			// 	_this.common.get(`${_this.controller}/${funName}/${_this.id}`).then(function(res) {
			// 		_this.model = res.data;
			// 		_this.showHandCheckDetail();

			// 	})
			// },
			showHandCheckDetail() {
				this.$refs.handCheckDetail.show({
					model: this.model,
					op:3,
					id:this.id
				});
			}
		}
	}
</script>

<style>

</style>
