<template>
    <view class="hand-check-detail">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">{{title}}</eagle-head>
            <view>
                <view class="statistics">
                </view>
                <eagle-form class="form-content" :control="controller" :boolInitData="false" v-model="model" ref="eagleForm" :out-height='110'>
                    <view class="item">
                        <view class="item-container">
                            <!-- <view class="citem"> -->
                            <u-form-item v-if="opType==0" label="隐患来源" label-position="top" prop="originType">
                                <view style="font-size: 14px;">
                                    {{model.originType|paramsFormat(checkDatas.checkSource)}}
                                </view>
                            </u-form-item>
                            <u-form-item v-if="opType==0" label="检查人" label-position="top" prop="originType">
                                <view style="font-size: 14px;">
                                    {{model.createChnName}}
                                </view>
                            </u-form-item>
                            <u-form-item v-if="opType==0" label="检查时间" label-position="top" prop="originType">
                                <view style="font-size: 14px;">
                                    {{utils.dateFormat(model.createDate,"yyyy-mm-dd")}}
                                    <!-- {{model.originType|paramsFormat(checkDatas.checkSource)}} -->
                                </view>
                            </u-form-item>

                            <view class="citem-title" v-if="model.originType===3">{{model.templateItemName}}
                            </view>
                            <view class="button-pannel" v-if="model.originType===3">
                                <view class="button-item Y " @click="handleChangeResult('Y')" :class="model.checkResult==='Y'?'checked':''">符合</view>
                                <view class="button-item N" @click="handleChangeResult('N')" :class="model.checkResult==='N'?'checked':''">不符合</view>
                                <view class="button-item NA" @click="handleChangeResult('NA')" :class="model.checkResult==='NA'?'checked':''">不适用
                                </view>
                            </view>
                            <view v-if="model.checkResult==='NA'">
                                <eagle-input type="textarea" key="remarks" :disabled="opType==0" title="备注" prop="remarks" placeholder="请输入备注" v-model="model.remarks" />
                            </view>

                            <view v-if="model.checkResult==='Y'">
                                <eagle-upload title="图片" v-if="opType==1" key="attachsYes" prop="attachsYes" v-model="model.attachsYes" />
                                <eagle-display-image title="图片" key="display_attachsYes" v-if="opType!==1" prop="attachsYes" v-model="model.attachsYes">
                                </eagle-display-image>
                                <eagle-input :disabled="opType==0" key="checkRemark" type="textarea" title="检查情况" v-model="model.checkRemark" />
                            </view>

                            <view v-if="model.checkResult==='N'">

                                <eagle-upload :isNeedEdit="true" title="隐患图片" v-if="opType!==0" key="attachs" prop="attachs" v-model="model.attachs" required />
                                <eagle-display-image title="隐患图片" v-if="opType===0" key="display_attachs" prop="attachs" v-model="model.attachs" required />
                                <eagle-input v-if=" setModel.hiddenDangerArea==='true'" :disabled="opType===0" type="textarea" title="隐患区域" required v-model="model.correctiveArea" />

                                <eagle-input v-if="setModel.hiddenDangerDesc==='true'" :disabled="opType===0" type="textarea" title="隐患描述" required v-model="model.hiddenDangerDesc" />
                                <eagle-input v-if=" setModel.correctiveMeasure==='true'" :disabled="opType===0" type="textarea" title="整改措施" v-model="model.correctiveMeasure">
                                    <template slot="topBotton">
                                        <view v-if="setModel.gistSource==='true'" style="text-align: right;">
                                            <span v-if="opType!==0" style="color:#2979ff;margin-left: 10rpx;" @click="hdChooseLg()">选择依据</span>
                                            <span style="color:#2979ff;margin-left: 20rpx;" @click="showDetail()">{{opType!==0?"编辑依据":"查看依据"}}</span>
                                        </view>
                                    </template>
                                </eagle-input>
                                <eagle-choose v-if="setModel.hiddenCode==='true'" :disabled="opType===0" title="隐患分类" v-model="model.hiddenName" required :select-open="dangerTypeDialog" @click="showDangerType(model)">
                                </eagle-choose>
                                <eagle-radios v-if=" setModel.hiddenDangerTypeCode==='true' && checkDatas.checkType.length>0" :disabled="opType===0" title="隐患性质" required :data-source="checkDatas.checkType" v-model="model.hiddenDangerTypeCode" />

                                <eagle-date v-if="setModel.correctiveDeadline==='true' " label-width="100px" :disabled="opType===0" key="correctiveDeadline" title="整改期限" v-model="model.correctiveDeadline" />
                                <eagle-input v-if=" setModel.correctiveDeptName==='true'" :disabled="opType===0" type="textarea" title="整改部门" v-model="model.correctiveDeptName" />
                                <eagle-input v-if=" setModel.correctiveUserChName==='true'" :disabled="opType===0" type="textarea" title="整改人" v-model="model.correctiveUserChName" />
                            </view>
                        </view>
                        <!-- </view> -->
                    </view>
                </eagle-form>
                <eagle-bottom-view v-if="opType!==0">
                    <u-button type="primary" class="bottom-btn" @click="post()">
                        保存并返回
                    </u-button>
                </eagle-bottom-view>
                <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog=false" v-model="model.hiddenCode" @change="changeDangeType"></popup-danger-type>
            </view>
            <choose-danger-lg ref="chooseDangerLg"></choose-danger-lg>
            <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        </u-popup>
        <u-toast ref="uToast" />
    </view>
</template>
<script>
import chooseDangerLg from "@/pages/components/danger/choose-danger-lg";
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type";
// import Template from "../dangerTemplate/template.vue";
export default {
    //
    components: {
        "popup-danger-type": popupDangerType,
        "choose-danger-lg": chooseDangerLg,
        "view-danger-lg": viewDangerLg,
    },
    name: "hand-check-detail",
    data() {
        return {
            title: "隐患",
            opType: 0, // 0 查看,1编辑,2整改,3随手拍,4 依据查
            dangerTypeDialog: false,
            showDialog: false,
            controller: "danger/simpleCheck",
            taskCode: "",
            isEdit: false,
            model: {},
            itemData: {},
            totalCount: 0,
            itemShowArray: [],
            checkDatas: {
                checkSource: [
                    {
                        id: 1,
                        name: "随手拍",
                    },
                    {
                        id: 2,
                        name: "依据检查",
                    },
                    {
                        id: 3,
                        name: "检查表检查",
                    },
                ],
                checkType: [],
                correctiveType: [
                    {
                        id: 1,
                        name: "立即整改",
                    },
                    {
                        id: 2,
                        name: "限时整改",
                    },
                ],
            },
            tempModel: {}, //依据查model
            setModel: {},
        };
    },
    created() {
        this.initParams();
    },
    methods: {
        hdChooseLg(item) {
            this.$refs.chooseDangerLg.show({
                opType: this.opType !== 0 && this.opType !== 2 ? 2 : 1,
                model: this.model,
            });
        },
        showDetail(item) {
            let config = {
                isEdit: this.opType !== 0 && this.opType !== 2,
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },

        handleChangeResult(result) {
            if (this.opType === 1) this.model.checkResult = result;
        },
        post() {
            let _this = this;
            _this.$refs.eagleForm.post({
                //url: `site/dangerCheckTaskDetail/${_this.opType==2?"rectify":"save"}`,
                model: _this.model,
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.$emit("saved");
                    _this.showDialog = false;
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        initParams() {
            var _this = this;
            this.common
                .getModuleSettins("danger_check_simple")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.setModel = res.data;
                    }
                });
            this.common
                .getCustomDict("danger_simple_danger_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.checkDatas.checkType = res.data;
                        console.log(_this.checkDatas.checkType);
                    }
                });
        },
        showDangerType() {
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.model.hiddenCode = obj.dCode;
            this.model.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.model.hiddenTypeCode = obj.dType;
            this.dangerTypeDialog = false;
        },
        show(options) {
            this.showDialog = true;
            this.taskCode = options.taskCode;
            this.opType = options.op;
            switch (options.op) {
                case 0:
                    this.title = "隐患详情";
                    break;
                case 1:
                    this.title = "隐患编辑";
                    break;
                case 2:
                    this.title = "隐患整改";
                    break;
                case 3:
                    this.title = "随手拍";
                    break;
                case 4:
                    this.tempModel = options.lg;
                    this.title = "依据检查";
                    break;
            }

            this.getModel(options.id, this.taskCode);
        },
        getModel(id, taskCode) {
            var _this = this;
            if (id && id > 0) {
                this.common
                    .get(`${_this.controller}/getData/` + id)
                    .then((res) => {
                        _this.model = res.data;
                    });
            } else {
                //this.title = "随手拍";
                this.common
                    .get(`${_this.controller}/initData/0`)
                    .then((res) => {
                        _this.model = res.data;
                        _this.model.originType = 1;
                        _this.model.mainCode = taskCode;
                        _this.model.checkResult = "N";

                        _this.model.correctiveType = _this.model.correctiveType
                            ? _this.model.correctiveType
                            : null;
                        if (_this.opType == 4) {
                            //依据查
                            _this.model.originType = 2;
                            _this.model.attachs = _this.tempModel.attachs;
                            for (let x in _this.tempModel) {
                                if (
                                    _this.tempModel[x] ||
                                    _this.tempModel[x] == 0
                                )
                                    _this.model[x] = _this.tempModel[x];
                            }
                        }
                    });
            }
        },

        goto(url) {
            this.base.navigateTo(url);
        },
    },
};
</script>
<style lang="scss" scoped>
.hand-check-detail {
    background-color: #ffffff;

    .statistics {
        margin-top: 30rpx;
        padding: 0 30rpx;
    }

    .form-content {
        .item {
            .item-title {
                display: flex;
                background-color: #2979ff;
                line-height: 35px;
                margin: 10px -30px;
                padding: 0px 30px;
                font-size: 16px;
                font-weight: 600;
                color: #ffffff;
                -webkit-box-flex: 1;
                -webkit-flex: 1;
                flex: 1;

                .arrow-up-fill {
                    text-align: right;
                }
            }

            .citem {
                padding: 10px 0px;
            }
        }
    }

    .button-pannel {
        width: 100%;
        display: inline-flex;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;

        .button-item {
            margin-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            border: 1px solid #dfe4ec;
            width: 28%;
            /* height: 30px; */
            border-radius: 5px;
            line-height: 30px;
        }

        .button-item.Y.checked {
            border: 1rpx solid #19be6b;
            background-color: #19be6b;
            color: #ffffff;
        }

        .button-item.NA.checked {
            border: 1rpx solid #ff976a;
            background-color: #ff976a;
            color: #ffffff;
        }

        .button-item.N.checked {
            border: 1rpx solid red;
            background-color: red;
            color: #ffffff;
        }
    }
}

.view-botton {
    padding: 20rpx;
}
</style>
