<template>
    <view>
        <view class="head">
            <image class="bg-set" src="@/static/img/danger/dangersimplecheck/danger-simple-top-bg.png"></image>
            <!-- <image class="content-set" @click="goto(5)"
				src="@/static/img/danger/dangersimplecheck/danger-simple-set.png"></image> -->
        </view>
        <view class="content">
            <image class="content-canmera" @click="goto(2)" src="@/static/img/danger/dangersimplecheck/danger-simple-photo.png"></image>
            <view class="content-card">
                <view class="content-title"><text>随手拍</text></view>
                <view><text class="content-sub-title">随时随地 记录隐患</text></view>
                <view class="icon-card">
                    <view class="card error">
                        <view class="num">{{model.dangerNum}}</view>
                        <view class="des">发现隐患数</view>
                    </view>
                    <view class="card primary">
                        <view class="num">{{model.monthDangerNum}}</view>
                        <view class="des">本月隐患数</view>
                    </view>
                    <view class="card warning">
                        <view class="num">{{model.reportNum}}</view>
                        <view class="des">生成报告数</view>
                    </view>
                </view>
            </view>
            <view class="title">常用操作</view>
            <view class="content-link">
                <view class="content-link-card" @click="goto(2)">
                    <view>
                        <view class="link-title">关于随手拍</view>
                        <eagle-girdrow-base style="font-size: 28rpx;">了解随时拍功能、流程</eagle-girdrow-base>
                    </view>
                    <view>
                        <u-icon name="camera" size="50"></u-icon>
                    </view>
                </view>
                <view class="content-link-card right-card" @click="goto(5)">
                    <view>
                        <view class="link-title ">参数设定</view>
                        <eagle-girdrow-base style="font-size: 28rpx;">设定需要的隐患属性</eagle-girdrow-base>
                    </view>
                    <view>
                        <u-icon name="setting" size="50"></u-icon>
                    </view>
                </view>
                <view class="content-link-card" @click="goto(3)">
                    <view>
                        <view class="link-title ">隐患清单</view>
                        <eagle-girdrow-base style="font-size: 28rpx;">查看历史发现隐患</eagle-girdrow-base>
                    </view>
                    <view>
                        <u-icon name="grid" size="50"></u-icon>
                    </view>
                </view>
                <view class="content-link-card right-card" @click="goto(4)">
                    <view>
                        <view class="link-title">隐患报告历史</view>
                        <eagle-girdrow-base style="font-size: 28rpx;">查看历史生成报告</eagle-girdrow-base>
                    </view>
                    <view>
                        <u-icon name="file-text" size="50"></u-icon>
                    </view>
                </view>
                </u-row>
            </view>
            <view class="title">数据报表</view>
            <view class="chart1">
                <view class="detail-title">隐患推移图</view>
                <view style="height:250rpx;">
                    <qiun-data-charts type="line" ref="chart1" :opts="line" :ontouch="true" :chartData="chartData">
                    </qiun-data-charts>
                </view>
            </view>
        </view>
        <tabbar-danger-simple class="tabber-danger"></tabbar-danger-simple>
    </view>
</template>
<script>
import tabbarDangerSimple from "@/pages/components/tabbar/tabbar-danger-simple.vue";
export default {
    name: "danger_simple_list",
    components: {
        "tabbar-danger-simple": tabbarDangerSimple,
    },
    data() {
        return {
            model: {
                dangerNum: 0,
                monthDangerNum: 0,
                reportNum: 0,
            },
            chartData: {
                categories: [
                    "1月",
                    "2月",
                    "3月",
                    "4月",
                    "5月",
                    "6月",
                    "7月",
                    "8月",
                    "9月",
                    "10月",
                    "11月",
                    "12月",
                ],
                series: [],
            },
            line: {
                type: "line",
                canvas2d: false,
                update: true,
                yAxis: {
                    disableGrid: true,
                    splitNumber: 2,
                    disableGrid: false,
                },
                extra: {
                    line: {
                        type: "straight",
                        width: 2,
                    },
                },
            },
        };
    },
    created() {
        this.getInitData();
    },
    onReady() {},
    mounted() {},
    methods: {
        getInitData() {
            var url = "/danger/simple/getDangerCheckSimpleHomeEntity";
            // var url = "/DangerCheckSimple/GetDangerCheckSimpleHomeEntity";
            var _this = this;
            this.common.get(url).then(function (res) {
                if (res.success) {
                    var danger = {
                        name: "隐患数",
                        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    };
                    var data = res.data;
                    _this.model.dangerNum = data.DangerNum;
                    _this.model.monthDangerNum = data.MonthDangerNum;
                    _this.model.reportNum = data.ReportNum;
                    if (data.List && data.List.length > 0) {
                        data.List.forEach(function (item) {
                            danger.data[item.Month - 1] = item.DangerNum;
                        });
                    }
                    _this.chartData.series.push(danger);
                }
            });
        },
        goto(index) {
            var url = "/pages/danger/dangerCheckSimple/detail?source=simple";
            switch (index) {
                case 5:
                    url =
                        "/pages/danger/dangerCheckSimple/set?source=simple&moduleCode=DangerCheckSimple";
                    break;
                case 4:
                    url =
                        "/pages/danger/dangerCheckSimple/report?source=simple";
                    break;
                case 3:
                    url = "/pages/danger/dangerCheckSimple/list?source=simple";
                    break;
                    break;
            }
            this.base.navigateTo(url);
        },
    },
};
</script>

<style lang="scss">
.bg-set {
    width: 100%;
    height: auto;
}

.content-canmera {
    position: absolute;
    width: 170rpx;
    height: 170rpx;
    z-index: 99;
    right: 80rpx;
    top: -40rpx;
}

.content-set {
    position: absolute;
    width: 40rpx;
    height: 40rpx;
    z-index: 99;
    right: 15rpx;
    top: 15rpx;
}

.title {
    font-size: $font-lg;
    line-height: 80rpx;
    margin-top: 20rpx;
}

.content {
    padding: 30rpx;
    position: relative;
    margin-top: -70rpx;
}

.content-card {
    background: #fff;
    padding: $spacing-base;
    border-radius: $border-radius-middle;
}

.content-link {
    width: 100%;
    font-size: $font-base;
}

.content-link-card {
    display: flex;
    background: #ffffff;
    padding: $spacing-sm;
    display: inline-flex;
    margin: $spacing-sm 0;
    border-radius: $border-radius-base;
    width: 48%;
}

.right-card {
    margin-left: 4%;
}

.content-title {
    font-size: $font-v-lg;
    font-weight: bold;
    margin-top: 20rpx;
}

.content-sub-title {
    color: $font-color-light;
    line-height: 60rpx;
    font-size: $font-sm;
}

.icon-card {
    display: flex;
    color: #eee;
}

.icon-card .card {
    flex: 1;
    padding: 10rpx;
    margin: 6rpx;
    text-align: center;
    border-radius: 10rpx;
}

.card .num {
    font-size: $font-v-lg;
    line-height: $font-v-lg;
}

.link-title {
    width: 240rpx;
    color: $font-color-dark;
}

.card .des {
    font-size: $font-sm;
}

.icon-card .error {
    background: #fa3534;
}

.icon-card .primary {
    background: #2979ff;
}

.icon-card .warning {
    background: #ff9900;
}

.content-link-card .u-icon {
    padding-top: 20rpx;
    padding-left: 10rpx;
}

.chart1 {
    background: #fff;
    border-radius: $border-radius-base;
}

.detail-title {
    font-weight: bold;
    line-height: 70rpx;
    text-indent: 20rpx;
    font-size: $font-base;
}

page {
    background: #f3f4f6;
}

/deep/uni-page-wrapper {
    background: #f3f4f6;
}

/deep/ uni-image > img {
    height: auto;
    position: inherit;
    opacity: inherit;
    top: auto;
}
</style>
