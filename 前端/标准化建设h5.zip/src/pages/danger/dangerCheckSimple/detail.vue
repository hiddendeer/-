<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='outHeight' :errorType="errorType">
            <eagle-upload :isNeedEdit="true" title="隐患图片" prop="attachs" v-model="model.attachs" required />
            <eagle-input v-if="setModel.hiddenDangerArea==='true'" type="textarea" required title="隐患区域" prop="hiddenDangerArea" v-model="model.hiddenDangerArea" />
            <eagle-input v-if="setModel.hiddenDangerDesc ==='true' " type="textarea" title="隐患描述" prop="hiddenDangerDesc" required v-model="model.hiddenDangerDesc" />

            <eagle-input v-if="setModel.correctiveAdvise==='true'" type="textarea" title="整改建议" prop="correctiveAdvise" required v-model="model.correctiveAdvise">
                <template slot="topButton">
                    <view class="check-view">
                        <view @click="checkLg">选择依据</view>
                    </view>
                </template>
            </eagle-input>
            <eagle-radio-group v-if="setModel.lgdCode==='true'&&pmLGDArray.length>0" ID="Value" Name="Name" @change="dangerLGDChange" title="隐患分类" required prop="ldgCode" :data-source="pmLGDArray" v-model="model.ldgCode" />
            <eagle-input v-if="setModel.gistSource==='true'" type="textarea" title="依据来源" v-model="model.gistSource" prop="gistSource" />
            <eagle-radio-group required v-if="setModel.hiddenDangerType==='true'&&pmTypeArray.length>0" ID="id" Name="name" @change="dangerTypeChange" title="隐患性质" prop="hiddenDangerType" :data-source="pmTypeArray" v-model="model.hiddenDangerType" />
            <eagle-input v-if="setModel.legalLiability==='true'" type="textarea" title="法律责任" v-model="model.legalLiability" prop="legalLiability" />
            <eagle-input v-if="setModel.originalText==='true'" type="textarea" title="法律原文" v-model="model.originalText" prop="originalText" />
            <eagle-date v-if="setModel.correctiveDate==='true'" title="整改期限" v-model="model.correctiveDate" prop="correctiveDate" />
            <eagle-input v-if="setModel.correctiveDeptName==='true'" title="整改部门" v-model="model.correctiveDeptName" prop="correctiveDeptName" />
            <eagle-input v-if="setModel.correctiveChnName==='true'" title="整改人" v-model="model.correctiveChnName" prop="correctiveChnName" />
        </eagle-form>
        <!-- <view v-if="source=='simple'||model.Source=='simple'"> -->
        <view>
            <eagle-bottom-view marginBottom="100rpx">
                <u-button type="primary" class="bottom-btn" @click="post('2')">保存并返回</u-button>
                <u-button type="success" class="bottom-btn" @click="post('1')">保存并继续</u-button>
            </eagle-bottom-view>
            <u-toast ref="uToast" />
            <tabbar-danger-simple class="tabber-danger"></tabbar-danger-simple>
        </view>
        <view v-if="source=='lg'||model.Source=='lg'">
            <eagle-bottom-view>
                <u-button type="primary" class="bottom-btn" @click="post('3')">保存</u-button>
            </eagle-bottom-view>
            <!-- <tabbar-danger-lg class="tabber-danger"></tabbar-danger-lg> -->
        </view>
    </view>

</template>
<script>
import tabbarDangerSimple from "@/pages/components/tabbar/tabbar-danger-simple.vue";
import tabbarDangerLG from "@/pages/components/tabbar/tabbar-danger-lg.vue";
// import Template from "../dangerTemplate/template.vue";
// import common from "@/common/common.js";
// import popupDangerType from '@/pages/components/danger/popup-danger-type.vue'

export default {
    name: "danger_simple_list",
    components: {
        // 'popup-danger-type': popupDangerType,
        "tabbar-danger-lg": tabbarDangerLG,
        "tabbar-danger-simple": tabbarDangerSimple,
    },
    data() {
        Template;
        return {
            screenHeight: "", //视口高度
            model: {},
            errorType: ["message"],
            control: "danger/simpleCheck",
            labelWidth: "240px",
            pmTypeArray: [],
            pmLGDArray: [],
            scrollHeight: 500,
            popupdangerTypeShow: false,
            selectOpen: false,
            rules: {},
            source: "",
            setModel: [],
            checkItem: {},
            outHeight: 145,
        };
    },
    created() {
        let _this = this;
        this.source = this.$route.query.source;
        console.log("this.source=>:", this.source);

        _this.common
            .getModuleSettins("danger_check_simple")
            .then(function (res) {
                _this.setModel = res.data;
            });

        this.common
            .getCustomDict("danger_simple_danger_type")
            .then(function (res) {
                _this.pmTypeArray = res.data;
            });

        this.model.ID = this.$route.query.id;
    },
    onReady() {
        var _this = this;
        _this.$refs.eagleForm.setRules(this.rules);
        _this.initParams();
        // _this.initData();
    },
    mounted() {},
    methods: {
        checkLg() {
            let url = this.common.getLinkUrl({
                url: "/pages/danger/dangerLG/list?optiontype=1",
                animationType: "pop-in",
                animationDuration: 200,
            });
            this.base.navigateTo(url);
        },
        dangerTypeChange(val, obj) {
            this.model.hiddenDangerType = val;
            this.model.hiddenDangerTypeName = obj.Name;
        },
        dangerLGDChange(val, obj) {
            this.model.ldgCode = val;
            this.model.lgdName = obj.Name;
        },
        initCallBack(data) {
            let strResult = localStorage.getItem("currentSimpleModel");
            localStorage.removeItem("currentSimpleModel");
            if (strResult) {
                let result = JSON.parse(strResult);
                this.model.lgCode = result.lgCode;
                this.model.gistSource = result.gistSource;
                this.model.correctiveAdvise = result.correctiveAdvise;
                this.model.legalLiability = result.legalLiability;
                this.model.originalText = result.originalText;
                this.model.hiddenDangerDesc = result.hiddenDangerDesc;
                this.model.lghdCode = result.lghdCode;
                this.model.attachs = result.attachs;
                if (this.source) {
                    this.model.Source = this.source;
                } else {
                    this.source = this.model.Source;
                }
                if (this.source == "lg") {
                    this.outHeight = 45;
                } else {
                    this.outHeight = 99;
                }
            }
        },
        initParams() {
            // var _this = this;
            // common.getparamsList("hiddenDangerType").then(function(res) {
            // 	_this.pmTypeArray = res.data;
            // })
        },
        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    if (op == "2") {
                        let url =
                            "/pages/danger/dangerCheckSimple/list?source=simple";
                        _this.base.navigateTo(url);
                    } else if (op == "1") {
                        _this.$refs.eagleForm.get("init");
                    } else if (op == "3") {
                        let pages = getCurrentPages();
                        let prevPage = pages[pages.length - 2]; //上一个页面
                        if (typeof prevPage.$vm.CheckLgFun === "function") {
                            prevPage.$vm.CheckLgFun(obj);
                        }
                        _this.base.navigateBack();
                    }
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        CheckLgFun(obj) {
            this.model.lgCode = obj.lgCode;
            this.model.hiddenDangerDesc = obj.hiddenDangerDesc;
            this.model.lghdCode = obj.lghdCode;
            this.model.gistSource = obj.gistSource;
            this.model.legalLiability = obj.legalLiability;
            this.model.originalText = obj.originalText;
            this.model.correctiveAdvise = obj.correctiveAdvise;
        },
    },
};
</script>

<style lang="scss">
.check-view {
    text-align: right;
    position: absolute;
    width: 100%;
    padding-top: 12rpx;
    padding-right: 30px;
    color: rgb(18, 150, 219);
    z-index: 99999;
}

/deep/ .u-tabbar__content {
    border-top: none;
}
</style>
