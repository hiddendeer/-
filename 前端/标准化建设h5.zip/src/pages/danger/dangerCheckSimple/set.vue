<template>
	<view>
		<eagle-form @initCallBack="initCallBack" ref="eagleForm" action="init" :initUrl="initUrl" :boolInitData="true"
			:control="control" v-model="model"  :out-height='100' :errorType="errorType">

			<template v-for="(item,index) in model.Options">
				<eagle-switch :title="item.KeyTitle" :key="index" v-model="item.Value"
					  :active-color="settings.activeColor"
					:label-width="settings.labelWidth" :label-position="settings.labelPosition" :size="settings.size" />
					<view v-if="item.Value && item.DataType==='array'">
					<view class="options_line">选项</view>
					<template v-for="(citem,cindex) in item.Params"   class="options_item">
						<view :key="cindex" style="display: flex; border-bottom: 1px solid #e0dada4d;">
						<view class="item_xb" >{{cindex+1}}</view>	<u-input v-model="citem.Name"></u-input>
							<u-button size="mini" type="error" class="rmv_btn" style="margin-top: 12rpx;">移除</u-button>
						</view>

					</template>
					<u-button @click="pushItem(item.Params)">新增选项</u-button>
				</view>
			</template> 
			</eagle-form>
		<view class="view-botton">
			<u-button type="success" class="bottom-btn"  @click="post()">保存</u-button>
		</view>
		<u-toast ref="uToast" />
		<tabbar-danger-simple class="tabber-danger"></tabbar-danger-simple>
	</view>

</template>
<script>
	import tabbarDangerSimple from "@/pages/components/tabbar/tabbar-danger-simple.vue";
	export default {
		components: {
			'tabbar-danger-simple': tabbarDangerSimple,
		},
		data() {
			return {
				settings: {
					activeColor: "#19be6b",
					labelWidth: "90%",
					labelPosition: "left",
					size: 40,

				},
				initUrl: "/UserModuleOption/GetSettings?moduleCode=DangerCheckSimple",
				model: {},
				errorType: ['message'],
				control: "UserModuleOption",
				labelWidth: '240px',
				scrollHeight: 500,
				rules: {}
			};
		},

		onReady() {
			var _this = this;
			_this.$refs.eagleForm.setRules(this.rules);

		},
		mounted() {
			// this.resetTableHeight();
		},
		methods: {
			initCallBack(val) {
				console.log(val);
			}, 
			pushItem(item) {
				item.push({
					Name: '',
					ModuleOptionCode: '',
					Value: '',
					IsDefault: false
				});
			},
			post() {
				let _this = this;
				this.$refs.eagleForm.post(				
				{				
					url:"/UserModuleOption/SaveSettings",
					needValid: false, 
					successCallback: function(res) {					
						console.log(res)						
					},
					errorCallback: function(res) {
						console.log(res);
					}
				});	
				//SaveSettings
				//console.log(this.model);
			}
		}
	}
</script>

<style lang="scss">
	.options_line {
		background-color: #e0dada4d;
		margin: 0 -30px;
		padding: 5px 30px;
		font-size: 11px;
	}
	.item_xb{
		    line-height: 38px;
		   color: #1514146b;
		    margin-right: 2px;
	}
</style>
