<template>
    <view>
        <eagle-form :boolInitData="false" v-model="model" ref="eagleForm" :out-height='50' :errorType="errorType" v-show="!showDetail">
            <scroll-view id="divMyScroll" class="scroll-Y file-content" scroll-y="true" v-bind:style="{ height: fileHeight+'px'}" style="margin:5px 0px 5px 0px;" show-scrollbar="true">
                <view v-for="(item,index) in fileList" :key="index">
                    <eagle-grid-attach title="文件" v-model="item.attach"></eagle-grid-attach>
                </view>
            </scroll-view>
            <view class="sign-block">
                <view>
                    <u-icon name="info-circle" color="white" size="28" style="margin-right: 5px;"></u-icon>
                    必须由对应负责人签署，禁止代签
                </view>
                <view>我已经审阅制度，同意发布实施</view>
            </view>

            <eagle-input title="签署人姓名" v-model="model.name" required></eagle-input>
            <eagle-date title="签署日期" v-model="model.signDate" required></eagle-date>
            <view class="choose-item">
                <text>已签名:</text>
                <text class="choose-num" @click="funShowDetail">{{model.signPicList.length}}个</text>
            </view>
            <view>
                <u-button @click="editFunc">点击名</u-button>
            </view>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">提交</u-button>
        </eagle-bottom-view>
        <u-popup v-model="showDetail" mode="bottom" height="80%" length="100%">
            <view class="uni-media-cell-content">
                <view style="padding:0 10px" class="uni-media-list" v-for="(item, index) in model.signPicList" :key="item.ID">
                    <view class="uni-media-list-body">
                        <u-image width="200px" height="70px" :src="item"></u-image>
                    </view>
                    <view class="uni-date__icon-clear" style="line-height: 70px;" @click.stop="clear(item,index)">
                        <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                    </view>
                </view>
            </view>
        </u-popup>
    </view>
</template>

<script>
import common from "@/common/common.js";

export default {
    components: {},
    data() {
        return {
            model: {
                name: "",
                signDate: new Date(),
                codes: "",
                signPics: "",
                signPicList: [
                    // "http://139.196.228.32:9000/eagle/4bb3761ac4835e1967bd085fa7187dfa/20211106/c88d2f08-a25c-4ecd-b7cb-f2217a5f216c.png",
                    // "http://139.196.228.32:9000/eagle/4bb3761ac4835e1967bd085fa7187dfa/20211106/c88d2f08-a25c-4ecd-b7cb-f2217a5f216c.png",
                ],
            },
            errorType: ["message"],
            menuSysType: "",
            fileList: [],
            codes: "",
            fileHeight: 200,
            showDetail: false,
        };
    },
    mounted() {},
    created() {
        this.menuSysType = this.$route.query.menuSysType;
        this.model.codes = this.$route.query.codes;
        this.resetHeight();
        this.initData();
    },
    onReady() {},
    mounted() {},
    methods: {
        resetHeight() {
            let _this = this;
            //this.model.ID = this.$route.query.id;
            uni.getSystemInfo({
                success: function (res) {
                    var windowHeight = res.windowHeight;
                    _this.fileHeight =
                        windowHeight - 70 - 45 - 45 - 100 - 100 - 40; //屏幕高度-蓝色标题高度-行1高度-行2高度-提示高度-附件高度（暂定100，根据实际签名所占高度调整）
                },
            });
        },
        initData() {
            switch (this.menuSysType) {
                case "SiteGuideline":
                    var url =
                        "/site/guidelineFile/getListByCodes/" +
                        this.model.codes;
                    var _this = this;
                    this.common.get(url, {}).then(function (res) {
                        if (res.code == 200 && res.data.length > 0) {
                            var arryData = [];
                            res.data.forEach(function (item) {
                                arryData.push({
                                    attach: item.unsignAttach,
                                });
                            });
                            _this.fileList = arryData;
                        }
                    });
                    break;
                case "SiteDuty":
                    var url =
                        "/site/dutyEditFile/getListByCodes/" + this.model.codes;
                    var _this = this;
                    this.common.get(url, {}).then(function (res) {
                        if (res.code == 200 && res.data.length > 0) {
                            var arryData = [];
                            res.data.forEach(function (item) {
                                arryData.push({
                                    attach: item.attachs,
                                });
                            });
                            _this.fileList = arryData;
                        }
                    });
                    break;
                default:
                    break;
            }
        },
        post() {
            var _this = this;
            if (!this.model.signPicList || this.model.signPicList.length == 0) {
                uni.showToast({
                    title: "请先签名",
                    icon: "error",
                });
                return false;
            }
            if (!this.model.name) {
                uni.showToast({
                    title: "请先输入签字人",
                    icon: "error",
                });
                return false;
            }
            if (!this.model.signDate) {
                uni.showToast({
                    title: "请先输入签字日期",
                    icon: "error",
                });
                return false;
            }
            var url = "";
            switch (_this.menuSysType) {
                case "SiteGuideline":
                    url = "/site/guidelineFile/saveSignDoc";
                    break;
                case "SiteDuty":
                    url = "/site/dutyEditFile/saveSignDoc";
                    break;
                default:
                    break;
            }
            this.model.signPics = this.model.signPicList.join(",");
            this.common.post(url, this.model).then(function (res) {
                if (res.code == 200) {
                    let backUrl = "";
                    switch (_this.menuSysType) {
                        case "SiteGuideline":
                            backUrl =
                                "/pages/site/guidelineFile/list?isSingSucc=Y";
                            break;
                        case "SiteDuty":
                            backUrl =
                                "/pages/site/dutyFile/listMain?isSingSucc=Y";
                            break;
                        default:
                            break;
                    }
                    _this.base.navigateTo(backUrl);
                }
            });
        },
        editFunc() {
            var _this = this;
            common.postBase64().then((res) => {
                if (res.code == 200 && res.data.length > 0) {
                    _this.model.signPicList = res.data;
                } else {
                    _this.showToast("签名失败");
                    _this.model.signPicList = [];
                }
            });
        },
        clear(index) {
            this.model.signPicList.splice(index, 1);
        },
        funShowDetail() {
            if (this.model.signPicList.length > 0)
                this.showDetail = !this.showDetail;
        },
    },
};
</script>
<style>
.file-content {
    line-height: 30px;
}

.sign-block {
    padding: 5px 0px 5px 0px;
    background-color: #ff9900;
    text-align: center;
    line-height: 30px;
    color: white;
    border-radius: 5px;
}

.choose-item {
    display: inline-block;
    line-height: 80rpx;
}

.choosed-view {
    margin-bottom: 50rpx;
}
.choose-num {
    color: #2979ff;
}
</style>
