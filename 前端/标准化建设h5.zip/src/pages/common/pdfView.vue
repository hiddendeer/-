<template>
    <view>
        <eagle-pdf-view v-if="isPdf || isVideo" :url="url" :title="title" :summary="title"></eagle-pdf-view>
        <img class="u-preview-image viedo-content" v-else-if="isImage" :src="url" />
        <!-- <video class="viedo-content" :src="url" v-else-if="isVideo"></video> -->
        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    data() {
        return {
            url: "",
            isPdf: false,
            isImage: false,
            isVideo: false,
            title: "",
        };
    },

    created() {
        var _this = this;
        if (this.$route.query.url) {
            this.url = this.$route.query.url;
            this.title = this.$route.query.title || '';
        } else if (this.$route.query.code) {
            this.common
                .get("/file/getDataByAttCode/" + this.$route.query.code)
                .then((res) => {
                    _this.isPdf = false;
                    _this.isImage = false;
                    if (res.code == 200 && res.data) {
                        var data = res.data;
                        if (_this.isImageFun(data.attExt)) {
                            _this.url = data.attFilePath;
                            _this.isImage = true;
                        } else if (_this.isVideoFun(data.attExt)) {
                            _this.url = data.attFilePath;
                            _this.isVideo = true;
                        } else {
                            if (data.status == 1) {
                                _this.$refs.uToast.show({
                                    title: "文件在转换中请稍后再试",
                                    type: "error",
                                });
                            } else if (data.status == 10) {
                                _this.url = data.attMiddlePath;
                                _this.isPdf = true;
                            } else if (data.status == -1 || data.status == 50) {
                                _this.$refs.uToast.show({
                                    title: "文件无法预览,请在电脑上端下载源文件查看",
                                    type: "error",
                                });
                            }
                        }
                        _this.title = data.attName;
                    } else {
                        _this.$refs.uToast.show({
                            title: "文件不存在请联系管理员检查后再试",
                            type: "error",
                        });
                    }
                });
        }
    },
    methods: {
        back() {
            this.common.navigateBack(-1);
        },
        isImageFun(suffix) {
            var imglist = ["png", "jpg", "jpeg", "bmp", "gif"];
            let result = imglist.some(function (item) {
                return item == suffix;
            });
            return result;
        },
        isVideoFun(suffix) {
            var list = ["mp4", "MP4"];
            let result = list.some(function (item) {
                return item == suffix;
            });
            return result;
        },
    },
};
</script>

<style lang="scss">
.u-preview-image {
    max-width: 100%;
    margin: 10px auto;
}

.viedo-content {
    width: 100%;
}
</style>
