<template>
    <view class="">
        <view class="chart-item">
            <view class="header-title">
                <view>
                    人员项目排行榜
                </view>
                <view @click="handpersolel()">
                    更多
                </view>
            </view>
            <qiun-data-charts type="bar" :chartData="chartDataone" background="none" />
        </view>
        <view class="chart-item">
            <view class="header-title">
                <view>
                    企业隐患排行
                </view>
                <view @click="handriskranking()">
                    更多
                </view>
            </view>
            <view class="">
                <text :class="hiddenTroubleIndex == 0 ? class1 : class2" @click="hiddenTrouble(0)">重大隐患</text>
                <text :class="hiddenTroubleIndex == 1 ? class1 : class2" @click="hiddenTrouble(1)">未整改隐患</text>
                <text :class="hiddenTroubleIndex == 2 ? class1 : class2" @click="hiddenTrouble(2)">隐患总数量</text>
            </view>
            <qiun-data-charts type="bar" :chartData="chartDatatwo" background="none" />
        </view>
        <view class="chart-item">
            <view class="header-title">
                <view>
                    关键风险分布
                </view>
                <!-- <view>
					更多
				</view> -->
            </view>
            <qiun-data-charts :opts="pieOpts" type="pie" :chartData="chartDatathree" background="none" />
        </view>
        <view class="chart-item">
            <view class="header-title">
                <view>
                    超过60天未服务项目一览表
                </view>
                <!-- <view>
					更多
				</view> -->
            </view>
            <view class="table_box">
                <u-table>
                    <u-tr>
                        <u-th width="60%">车辆种类</u-th>
                        <u-th width="25%">未服务天数</u-th>
                        <u-th width="15%">负责人</u-th>
                    </u-tr>
                    <u-tr v-for="(item, index) in model.M7">
                        <u-td width="60%">{{ item.enterprise_name }}</u-td>
                        <u-td width="25%">{{ item.daydiff }}天</u-td>
                        <u-td width="15%">{{ item.main_chn_name }}</u-td>
                    </u-tr>
                    <!-- <u-tr>            
						<u-td width="60%">江苏园区苏达机械有限公式</u-td>
						<u-td width="25%">180天</u-td>
						<u-td width="15%">李四</u-td>
					</u-tr>           
					<u-tr>            
						<u-td width="60%">江苏苏达机械有限公式</u-td>
						<u-td width="25%">160天</u-td>
						<u-td width="15%">王五</u-td>
					</u-tr>           
					<u-tr>            
						<u-td width="60%">江苏苏达机械有限公式</u-td>
						<u-td width="25%">140天</u-td>
						<u-td width="15%">刘能</u-td>
					</u-tr>          
					<u-tr>            
						<u-td width="60%">江苏苏达机械有限公式</u-td>
						<u-td width="25%">120天</u-td>
						<u-td width="15%">张三</u-td>
					</u-tr> -->
                </u-table>
            </view>
        </view>
    </view>
</template>

<script>
export default {
    props: {
        //value {Object}  传入的表单数据对象 赋值给model
        value: {
            type: Object,
            default() {
                return {};
            },
        },
    },

    data() {
        return {
            model: this.value,
            hiddenTroubleIndex: 0,
            class1: "tab-text1",
            class2: "tab-text",
            chartDataone: {},
            chartDatatwo: {},
            chartDatathree: {},
            pieOpts: {
                legend: {
                    position: "bottom",
                    float: "center",
                    lineHeight: 15,
                    fontSize: 12,
                },
            },
        };
    },
    watch: {
        value(nVal, oVal) {
            if (this.model !== nVal) {
                this.model = nVal;
                this.updatewithView();
            }
        },
    },
    created() {
        if (this.model.M3) {
            this.updatewithView();
        }
    },
    methods: {
        hiddenTrouble(index) {
            let dIndex = this.hiddenTroubleIndex;
            this.hiddenTroubleIndex = index;

            if (dIndex != this.hiddenTroubleIndex) {
                this.updateHiddenTrouble();
            }
        },
        handriskranking() {
            let url = "pages/host/homepage/riskranking/riskranking";
            this.base.navigateTo(url);
        },
        handpersolel() {
            let url = "pages/host/homepage/personnel/personnel";
            this.base.navigateTo(url);
        },
        updatewithView() {
            // M2 项目清单
            // M3 人员项目排行榜
            // M4 企业隐患排行
            // M5 关键风险分布
            // M6 项目日志
            // M7 长期未服务项目
            let projectList = [];
            projectList = this.model.M3;

            let ProjectCategories = [];
            let numList = [];

            if (projectList.length < 5) {
                for (let i = 0; i < projectList.length; i++) {
                    let item = projectList[i];
                    ProjectCategories.push(item.user_name);
                    numList.push(item.num);
                }
            } else {
                for (let i = 0; i < 5; i++) {
                    let item = projectList[i];
                    ProjectCategories.push(item.user_name);
                    numList.push(item.num);
                }
            }

            this.chartDataone = {
                categories: ProjectCategories,
                series: [
                    {
                        name: "项目数量",
                        data: numList,
                    },
                ],
            };

            // M5 关键风险分布

            let list = [];
            list = this.model.M5;

            let seriesList = [];
            for (let i = 0; i < list.length; i++) {
                let item = list[i];
                let model = {};
                model.name = item.dict_label;
                model.value = item.num;
                seriesList.push(model);
            }

            (this.chartDatathree = {
                series: [
                    {
                        data: seriesList,
                    },
                ],
            }),
                this.updateHiddenTrouble();
        },

        updateHiddenTrouble() {
            let list = [];
            list = this.model.M4;

            let categories = [];
            let numList = [];
            if (list.length < 5) {
                for (let i = 0; i < list.length; i++) {
                    let item = list[i];
                    let enterprise_name = this.common.sixDigitString(
                        item.enterprise_name
                    );

                    categories.push(enterprise_name);

                    if (this.hiddenTroubleIndex == 0) {
                        numList.push(item.hiddenNum);
                    } else if (this.hiddenTroubleIndex == 1) {
                        numList.push(item.NotCorrectiveNum);
                    } else if (this.hiddenTroubleIndex == 2) {
                        numList.push(item.num);
                    }
                }
            } else {
                for (let i = 0; i < 5; i++) {
                    let item = list[i];
                    let enterprise_name = this.common.sixDigitString(
                        item.enterprise_name
                    );
                    categories.push(enterprise_name);
                    if (this.hiddenTroubleIndex == 0) {
                        numList.push(item.hiddenNum);
                    } else if (this.hiddenTroubleIndex == 1) {
                        numList.push(item.NotCorrectiveNum);
                    } else if (this.hiddenTroubleIndex == 2) {
                        numList.push(item.num);
                    }
                }
            }

            this.chartDatatwo = {
                categories: categories,
                series: [
                    {
                        name: "隐患数量",
                        data: numList,
                    },
                ],
            };
        },

        getEnterpriseName(name) {
            if (name) {
                if (name.length <= 6) {
                    return name;
                } else {
                    name = name.slice(0, 6); //截取第二个到第四个之间的字符 cd
                    name = name + "...";
                    return name;
                }
            } else {
                return "";
            }
        },
    },
};
</script>

<style lang="scss">
.chart-item {
    margin: 20px;
    border: 1px solid #cccccc;
    border-radius: 10px;
}

.header-title {
    padding: 10px 10px 10px 20px;
    font-size: 16px;
    font-weight: 700;
    display: flex;
    justify-content: space-between;
}

.tab-text {
    display: inline-block;
    width: 90px;
    height: 30px;
    text-align: center;
    line-height: 28px;
    border: 1rpx solid #cccccc;
    border-radius: 20px;
    margin-left: 20rpx;
    background-color: #dce2ec;
}

.tab-text1 {
    display: inline-block;
    width: 90px;
    height: 30px;
    text-align: center;
    line-height: 28px;
    border: 1rpx solid #cccccc;
    border-radius: 20px;
    margin-left: 20rpx;
    // background-color: #dce2ec;

    color: #ffffff;
    background-color: #007aff;
}
</style>
