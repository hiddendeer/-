<template>
	<view class="chart-item">
		<qiun-data-charts type="bar" :chartData="chartDataone" background="none" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				chartDataone: {
					
				},
				codeNo: "R00004",
				model:{}
			};
		},
		created() {
			
			this.getEnterpriseList_l();
		},
		methods:{
			getEnterpriseList_l() {
					var _this = this;
					
					var conditions = [];
					if (this.codeNo) {
					    let obj = {};
					    obj.codeNo = _this.codeNo;
					    conditions.push(obj);
					}
					
					
					let obj1 = {};
					obj1.year = "2022";
					conditions.push(obj1);
					
					let obj2 = {};
					obj2.isOnlyMe = "0";
					conditions.push(obj2);
					
					var url =
						"/site/commonReportForms/getMainPageInfo?conditions=" +encodeURI(
                    JSON.stringify(conditions));
			
					// if (this.$route.query.enterpriseCode) {
					// 	url =
					// 		url +
					// 		"&companyCode=" +
					// 		this.$route.query.enterpriseCode;
					// }
					this.common.get(url, ).then((res) => {
						if (res.code == 200) {
							let datas = res.data;
							this.model = datas;
							_this.updatewithView();
							
						}
					});
			},
			updatewithView(){
				
				// M3 人员项目排行榜
				
				
				let projectList = [];
				projectList = this.model.M3;
				
				let ProjectCategories = [];
				let numList = [];
				
				
					for (let i = 0; i < projectList.length; i++) {
						let item = projectList[i];
						ProjectCategories.push(item.user_name);
						numList.push(item.num)
					}
				
				
				
				
				this.chartDataone = {
					categories: ProjectCategories,
					series: [{
						name: '项目数量',
						data: numList
					}]
				};
				
			},
		}
		
	}
</script>

<style lang="scss">
      .chart-item {
      	margin: 20px;
      	border: 1px solid #CCCCCC;
      	border-radius: 10px;
		padding: 10px 20px;
		height: 600px;
      }
</style>
