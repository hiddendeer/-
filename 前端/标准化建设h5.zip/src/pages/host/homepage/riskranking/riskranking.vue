<template>
	<view class="chart-item">
		<view class="tab-text">
			<view class="box">
				<text :class="hiddenTroubleIndex==0? class1:class2" @click="hiddenTrouble(0)">重大隐患</text>
				<text :class="hiddenTroubleIndex==1? class1:class2" @click="hiddenTrouble(1)">未整改隐患</text>
				<text :class="hiddenTroubleIndex==2? class1:class2" @click="hiddenTrouble(2)">隐患总数量</text>
			</view>
			<u-select v-model="show" mode="single-column" :list="list" @confirm="confirm"></u-select>
			<!-- <view class="shownum" @click='<strong></strong>eitnum()'>
				更改
			</view> -->

		</view>
		<view class="charts-box-item">
			<qiun-data-charts type="bar" :chartData="chartDatatwo" background="none" />
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				hiddenTroubleIndex:0,
				class1:"text1",
				class2:"text",
				show: false,
				codeNo: "R00004",
				model:{},
				chartDatatwo: {
					
				},
				list: [{
						value: '1',
						label: 15
					},
					{
						value: '2',
						label: 20
					},
					{
						value: '3',
						label: 25
					},
					{
						value: '4',
						label: 30
					},
					{
						value: '5',
						label: "全部"
					}
				]
			}
		},
		created() {
			this.getEnterpriseList_l();
		},
		methods: {
			hiddenTrouble(index){
				let dIndex = this.hiddenTroubleIndex;
				this.hiddenTroubleIndex = index;
				
				if(dIndex!=this.hiddenTroubleIndex){
					this.updateHiddenTrouble();
				}
			},
			confirm(e) {
				console.log(e);
			},
			eitnum() {
				this.show = true
			},
			getEnterpriseList_l() {
					var _this = this;
					
					
					var conditions = [];
					if (this.codeNo) {
					    let obj = {};
					    obj.codeNo = _this.codeNo;
					    conditions.push(obj);
					}
					
					
					let obj1 = {};
					obj1.year = "2022";
					conditions.push(obj1);
					
					let obj2 = {};
					obj2.isOnlyMe = "0";
					conditions.push(obj2);
					
					var url =
						"/site/commonReportForms/getMainPageInfo?conditions=" +encodeURI(
                    JSON.stringify(conditions));
			
					// if (this.$route.query.enterpriseCode) {
					// 	url =
					// 		url +
					// 		"&companyCode=" +
					// 		this.$route.query.enterpriseCode;
					// }
					this.common.get(url, ).then((res) => {
						if (res.code == 200) {
							let datas = res.data;
							this.model = datas;
							_this.updateHiddenTrouble();
							
						}
					});
			},
			updateHiddenTrouble(){
				let list = [];
				list = this.model.M4;
				
				let categories = [];
				let numList = [];
				if(list.length<5){
					for (let i = 0; i < list.length; i++) {
						let item = list[i];
						let enterprise_name = this.common.sixDigitString(item.enterprise_name);
						// this.getEnterpriseName(item.enterprise_name);
						categories.push(enterprise_name);
						
						if(this.hiddenTroubleIndex == 0){
							numList.push(item.hiddenNum);
						}else if(this.hiddenTroubleIndex == 1){
							numList.push(item.NotCorrectiveNum);
						}else if(this.hiddenTroubleIndex == 2){
							numList.push(item.num);
						}
						
					}
				}else{
					for (let i = 0; i < 5; i++) {
						let item = list[i];
						let enterprise_name = this.common.sixDigitString(item.enterprise_name);;
						categories.push(enterprise_name);
						if(this.hiddenTroubleIndex == 0){
							numList.push(item.hiddenNum);
						}else if(this.hiddenTroubleIndex == 1){
							numList.push(item.NotCorrectiveNum);
						}else if(this.hiddenTroubleIndex == 2){
							numList.push(item.num);
						}
					}
				}
				this.chartDatatwo= {
						categories: categories,
						series: [{
							name: '隐患数量',
							data: numList
						}]
					}
				},
				
				// getEnterpriseName(name){
				// 	if(name){
				// 		if(name.length <= 6){
				// 			return name;
				// 		}else{
				// 			name = name.slice(0,6);//截取第二个到第四个之间的字符 cd
				// 			name = name + "..."
				// 			return name;
				// 		}
				// 	}else{
				// 		return "";
				// 	}
				// }
		},
		
	}
</script>

<style lang="scss">
	.chart-item {
		margin: 20px;
		border: 1px solid #CCCCCC;
		border-radius: 10px;
	}

	.tab-text {
		margin-top: 20px;
		display: flex;
		justify-content: space-between;

		.box {

			.text {
				display: inline-block;
				width: 80px;
				height: 30px;
				text-align: center;
				line-height: 28px;
				border: 1rpx solid #CCCCCC;
				border-radius: 20px;
				margin-left: 15rpx;
				background-color: #dce2ec;
			}
			
			.text1 {
				display: inline-block;
				width: 90px;
				height: 30px;
				text-align: center;
				line-height: 28px;
				border: 1rpx solid #CCCCCC;
				border-radius: 20px;
				margin-left: 20rpx;
				// background-color: #dce2ec;
				
				color: #FFFFFF;
				background-color: #007AFF;
			}
		}


	}

	.charts-box-item {
		padding: 10px 20px;
		height: 600px;
	}

	.shownum {
		width: 100rpx;
		height: 100rpx;
		margin-right: 10px;
		padding-top: 10rpx;
	}
</style>
