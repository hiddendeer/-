<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :margin-bottom="170" :showCheck="true" @beforeLoad="beforeLoad" :boolInitData="boolInitData" searchDisplay='none' :showPages='false' controllerHeight="16">
            <view slot="list">
                <view class="list-wrap">
                    <view class="finite-space-container">
                        <view class="uni-media-cell">
                            <view class="uni-media-list">
                                <view class="uni-media-list-body">
                                    <view class="card-content">
                                        <view class="card-content-img">
                                            <image style="width: 150rpx;height: 150rpx;" :src="noImgUrl" mode="aspectFill">
                                            </image>
                                        </view>
                                        <view class="card-content-body">
                                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                                <eagle-girdrow-block>安全台账系统</eagle-girdrow-block>
                                            </eagle-girdrow-base>
                                            <eagle-girdrow-base>
                                                <eagle-girdrow-block>
                                                    <view class="icon-text" @click="goProjectConsultation()">
                                                        <view>
                                                            <u-icon name="coupon" size="30" color='#1257ce'></u-icon>
                                                        </view>
                                                        <view style="font-size: 10px;color:#1257ce">创建新项目</view>
                                                    </view>
                                                    <view class="icon-text" @click="goProjectCompany()">
                                                        <view>
                                                            <u-icon name="grid" size="30" color='#1257ce'></u-icon>
                                                        </view>
                                                        <view style="font-size: 10px;color:#1257ce">服务单位管理</view>
                                                    </view>
                                                    <!-- <view class="icon-text">
														<view>
															<u-icon name="setting" size="30" color='#1257ce'></u-icon>
														</view>
														<view style="font-size: 10px;color:#1257ce">参数设置</view>
													</view>
													<view class="icon-text">
														<view>
															<u-icon name="server-fill" size="30" color='#1257ce'></u-icon>
														</view>
														<view style="font-size: 10px;color:#1257ce">帮助中心</view>
													</view> -->
                                                </eagle-girdrow-block>
                                            </eagle-girdrow-base>
                                        </view>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </eagle-page-list>
        <!-- <view style="padding: 10px;">
			<u-subsection mode='subsection' active-color='#2979FF' :list="radioList" :current="radioIndex"
				:height='60' :bold='false' @change="handlerSectionChange"></u-subsection>
		</view> -->
        <view class="charts-box-item" v-if="radioIndex === 0">
            <teamsreports :value="model"></teamsreports>
        </view>
        <view class="charts-box-item" v-if="radioIndex === 1">
            <myreports></myreports>
        </view>
    </view>
</template>

<script>
import teamsreports from "./teamsreports/teamsreports.vue";
import myreports from "./myreports/myreports.vue";
export default {
    components: {
        teamsreports,
        myreports,
    },
    data() {
        return {
            noImgUrl: require("@/static/img/no-img.png"),
            radioList: ["我的团队报表", "我的报表"],
            radioIndex: 0,
            codeNo: "R00004",
            boolInitData: false,
            model: {},
        };
    },
    created() {
        this.getEnterpriseList_l();
    },

    methods: {
        handlerSectionChange(index) {
            console.log(index);
            this.radioIndex = index;
        },

        getEnterpriseList_l() {
            var conditions = [];
            if (this.codeNo) {
                let obj = { codeNo: "" };
                obj.codeNo = _this.codeNo;
                conditions.push(obj);
            }

            let obj1 = {};
            obj1.year = "2022";
            conditions.push(obj1);

            let obj2 = {};
            obj2.isOnlyMe = "0";
            conditions.push(obj2);

            var _this = this;
            var url =
                "/site/commonReportForms/getMainPageInfo?conditions=" +
                encodeURI(JSON.stringify(conditions));

            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url +
            //         "&companyCode=" +
            //         this.$route.query.enterpriseCode;
            // }
            this.common.get(url).then((res) => {
                if (res.code == 200) {
                    let datas = res.data;
                    this.model = datas;
                }
            });
        },

        goProjectConsultation() {
            this.navigateTo(
                "pages/project/projectConsultation/myList?modulesId=host"
            );
        },

        goProjectCompany() {
            this.navigateTo("pages/project/projectCompany/list?modulesId=host");
        },

        navigateTo(url) {
            let linkUrl = this.common.getLinkUrl(url, {
                projectId: this.$route.query.projectId ?? "",
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
            });

            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style lang="scss">
.card-content {
    display: flex;

    .card-content-img {
        display: flex;
        flex-direction: column;
        margin-right: 20rpx;
    }

    .card-content-body {
        flex: 1 1;
    }
}

.icon-text {
    text-align: center;
    margin: 10px 0 0 10px;
}
</style>
