<template>
	<view class="">
		<qiun-data-charts type="bar" :chartData="chartData" background="none" />
	</view>
</template>

<script>
	export default {
		data(){
			return {
				chartData: {
					categories: ['王菲', '周涛', '王五', '李四', '张三'],
					series: [{
						name: '项目数量',
						data: [35, 36, 31, 33, 13, 34]
					}]
				},
			}
		}
	}
</script>

<style>
</style>
