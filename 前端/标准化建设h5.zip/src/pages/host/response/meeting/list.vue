<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" :conditions="conditions" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="60" @beforeLoad="beforeLoad" dataType="list" :showCheck="true" :boolInitData="false">
            <template slot="search">
                <!-- <view class="search-solt"> -->
                <eagle-condition v-model="kvs" @reSearch="reSearch" @search="search" :searchResults="searchResults">
                    <eagle-select v-model="year" title="统计年度" prop="year" labelWidth="70px" :data-source="kvs.year">
                    </eagle-select>
                    <eagle-input title="计划名称" v-model="conditions.name.value" />
                </eagle-condition>
                <!-- </view> -->
            </template>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" @click="goDetail(item.id)">
                    <eagle-girdrow-base isTitle>{{ item.name }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view>
                            <span v-if="item.participant" class="success">已召开</span>
                            <span v-else class="error">未召开</span>
                        </view>
                    </template>
                    <eagle-girdrow-base>
                        计划时间:{{ planDate(item) }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        会议时间:{{ item.meetingDate | dateFormat }}</eagle-girdrow-base>
                    <eagle-girdrow-base>
                        参会人:{{ item.participant || "--" }}
                    </eagle-girdrow-base>

                    <template slot="button">
                        <u-button type="error" @click="del(item.id)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerEitClick(item)" size="mini">编辑</u-button>
                        <u-button type="primary" @click="handlerMainClick(item)" size="mini">会议纪要</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <tabbar-host v-if="enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
export default {
    components: { TabbarHost, TabbarSite },
    onShow() {
        this.search();
    },
    data() {
        return {
            controller: "site/meeting",
            list: [],
            clearabled: true,
            conditions: {
                name: {
                    value: "",
                    operate: "like",
                },
            },
            model: {},
            selectShow: false,
            selectValue: "2022",

            year: new Date().getFullYear(),
            kvs: {
                year: [],
            },
            enterpriseCode: "",
        };
    },

    created() {
        var _this = this;
        var year = new Date().getFullYear();
        this.year = year;
        for (var i = year - 5; i < year + 5; i++) {
            _this.kvs.year.push({
                id: i,
                name: i,
            });
        }

        this.searchResults = this.year;
    },
    mounted() {
        if (this.$route.query.enterpriseCode) {
            this.enterpriseCode = this.$route.query.enterpriseCode;
        }
    },
    methods: {
        planDate: function (item) {
            if (item.planTime) {
                return item.planTime;
            } else
                return (
                    this.common.dateFormat(
                        item.planStartDate.replace(/-/g, "/")
                    ) +
                    "至" +
                    this.common.dateFormat(item.planEndDate.replace(/-/g, "/"))
                );
        },
        initList(data) {
            this.list = data;
        },
        search() {
            this.searchResults = this.year;
            var params = {
                year: this.year,
            };
            if (this.$route.query.enterpriseCode) {
                params.enterpriseCode = this.$route.query.enterpriseCode;
            }
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    // conditions: this.common.getCondtions(this.conditions),
                    params: params,
                });
            });
        },
        reSearch() {
            this.year = new Date().getFullYear();
            this.conditions.name.value = "";
            this.search();
        },

        handlerBody(item) {
            // let linkUrl = this.common.getLinkUrl("/pages/host/response/meeting/view", {
            //     id: item.id,
            //     enterpriseCode: this.$route.query.enterpriseCode ?? "",
            // })

            // this.base.navigateTo(linkUrl)
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/response/meeting/view",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/response/meeting/edit",
                {
                    id: 0,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerEitClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/response/meeting/edit",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        goDetail(id) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/response/meeting/view",
                {
                    id: id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerMainClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/response/meeting/detail",
                {
                    id: item.id,
                    code: item.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
    },
};
</script>

<style scoped lang="scss">
.host-meeting-container {
    .list-item {
        height: 50rpx;
        line-height: 50rpx;
    }
}
</style>
