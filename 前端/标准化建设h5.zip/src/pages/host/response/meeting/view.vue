<template>
    <view class="hsot-meeting-detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="150" labelAlign='left' :initUrl="initUrl" selfHeight='calc(100vh - 125px)'>
            <eagle-container title="安全生产会议详情">
                <eagle-text title="会议主题" v-model="model.name" />
                <eagle-text title="计划时间" v-model="model.planDate" />
                <eagle-text title="会议时间" :value="model.meetingDate|dateFormat" />
                <eagle-text title="参会人" v-model="model.participant" />
                <eagle-text title="会议主要内容" v-model="model.meetingContent" />
                <eagle-text title="会议决议" v-model="model.meetingResolution" />
                <eagle-text title="现场照片">
                    <eagle-display-image prop="livePhoto" v-model="model.livePhoto" />
                </eagle-text>
                <eagle-text title="会议签到表">
                    <eagle-file-upload :disabled="true" v-model="model.checkInSheet" />
                </eagle-text>
            </eagle-container>
            <!-- <eagle-display-input v-model="model.name" title="会议主题" prop="name">
            </eagle-display-input>
            <eagle-display-input v-model="model.planDate" title="计划时间" prop="planTime">
            </eagle-display-input>
            <eagle-display-input :value="model.meetingDate|dateFormat" required title="会议时间" prop="meetingDate"></eagle-display-input>
            <eagle-display-input v-model="model.participant" required title="参会人" prop="participant">
            </eagle-display-input>
            <eagle-display-input v-model="model.meetingContent" required title="会议主要内容" prop="meetingContent">
            </eagle-display-input>
            <eagle-display-input v-model="model.meetingResolution" title="会议决议" prop="meetingResolution">
            </eagle-display-input>
            <eagle-display-image title="现场照片" prop="livePhoto" v-model="model.livePhoto" />
            <eagle-file-upload title="会议签到表" :disabled="true" v-model="model.checkInSheet" /> -->
        </eagle-form>
    </view>
</template>

<script>
import $timeFormat from "@/uview-ui/libs/function/timeFormat.js";
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/meeting",
            labelPosition: "left",
            labelWidth: "150",
            initUrl: "",
        };
    },
    created() {},
    computed: {},
    methods: {
        planDate() {
            return (
                this.common.dateFormat(
                    this.model.planStartDate.replace(/-/g, "/")
                ) +
                "至" +
                this.common.dateFormat(
                    this.model.planEndDate.replace(/-/g, "/")
                )
            );
        },
        initCallBack(data) {
            this.model = data;
            this.model.planDate = this.planDate();
        },
        post(op) {
            let _this = this;
            // let url = "/pages/host/response/meeting/list";
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "?enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            this.$refs.eagleForm.post({
                needValid: true,
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

<style>
</style>
