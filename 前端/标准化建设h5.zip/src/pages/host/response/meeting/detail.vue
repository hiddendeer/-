<template>
    <view class="hsot-meeting-detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="150" labelAlign='left' :detailUrl="detailUrl" selfHeight='calc(100vh - 125px)'>
            <eagle-container title="会议计划">
                <eagle-text v-model="model.name" title="会议主题" prop="name" labelWidth="130" />
                <eagle-text title="计划时间" prop="planTime" labelWidth="130">
                    {{model.planStartDate|dateFormat}}至{{model.planEndDate|dateFormat}}
                </eagle-text>
            </eagle-container>
            <eagle-container title="会议纪要">

                <eagle-date v-model="model.meetingDate" required title="会议时间" prop="meetingDate" labelPosition="top" labelWidth="130" type='date' />
                <eagle-input v-model="model.participant" required title="参会人" prop="participant" labelPosition="top" labelWidth="130" />
                <eagle-input v-model="model.meetingContent" required title="会议主要内容" prop="meetingContent" labelPosition="top" type='textarea' labelWidth="130" />
                <eagle-input v-model="model.meetingResolution" title="会议决议" prop="meetingResolution" labelPosition="top" type='textarea' labelWidth="130" />
                <eagle-upload title="现场照片" :maxCount="3" prop="livePhoto" v-model="model.livePhoto" labelPosition="top" />
                <eagle-file-upload title="会议签到表" :maxCount="3" prop="checkInSheet" v-model="model.checkInSheet" labelPosition="top" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/meeting",
            labelPosition: "left",
            labelWidth: "150",
            detailUrl: "site/meeting/initMinutes/" + this.$route.query.code,
        };
    },
    created() {},
    computed: {},
    methods: {
        // planDate() {
        //     return (
        //         this.common.dateFormat(
        //             this.model.planStartDate.replace(/-/g, "/")
        //         ) +
        //         "至" +
        //         this.common.dateFormat(
        //             this.model.planEndDate.replace(/-/g, "/")
        //         )
        //     );
        // },
        initCallBack(data) {
            this.model = data;
            // this.model.planDate = this.planDate();
        },
        post(op) {
            let _this = this;

            // let linkUrl = this.common.getLinkUrl(
            //     "/pages/host/response/meeting/list",
            //     {
            //         enterpriseCode: this.$route.query.enterpriseCode ?? "",
            //         projectId: this.$route.query.projectId ?? "",
            //     }
            // );
            this.$refs.eagleForm.post({
                needValid: true,
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

<style>
</style>
