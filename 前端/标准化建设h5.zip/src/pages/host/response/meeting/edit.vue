<template>
    <view class="hsot-meeting-detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="150" labelAlign='left' :initUrl="initUrl">
            <eagle-container>
                <eagle-input required v-model="model.name" title="会议主题" prop="name" labelWidth="130" />
                <eagle-date title="计划时间" prop="planStartDate" :endDate.sync="model.planEndDate" required type="daterange" rangeSeparator="至" :startDate.sync="model.planStartDate" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/meeting",
            labelPosition: "left",
            labelWidth: "150",
            initUrl: "",
        };
    },
    created() {},
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        post(op) {
            let _this = this;
            // let url = "/pages/host/response/meeting/list";
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "?enterpriseCode=" + this.$route.query.enterpriseCode;
            // }

            // let linkUrl = this.common.getLinkUrl(
            //     "/pages/host/response/meeting/list",
            //     {
            //         enterpriseCode: this.$route.query.enterpriseCode ?? "",
            //         projectId: this.$route.query.projectId ?? "",
            //     }
            // );

            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    // this.base.navigateTo(linkUrl);
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

<style>
</style>
