<template>
    <view class="host-ent-erprise-container-2">
        <view class="u-tabs-box">
            <u-tabs-swiper ref="tabs" :bold="false" :list="tabList" :current="tabContentIndex" @change="onTabChanged" :is-scroll="false">
            </u-tabs-swiper>
        </view>
        <!-- <view class="swiper-box">
            <HostCostPlanList ref="UsePlan" v-if="tabContentIndex==0"></HostCostPlanList>
            <UsingRecord ref="UsingRecord" v-if="tabContentIndex==1"></UsingRecord>
        </view> -->
        <!-- <view class="swiper-wrapper"> -->
        <swiper class="swiper-box" :current="tabContentIndex" @transition="transition" @animationfinish="animationfinish">
            <swiper-item class="swiper-item">
                <HostCostPlanList ref="UsePlan"></HostCostPlanList>
            </swiper-item>
            <swiper-item class="swiper-item">
                <UsingRecord ref="UsingRecord"></UsingRecord>
            </swiper-item>
        </swiper>
        <!-- </view> -->
        <view class="footer">
            <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
            <tabbar-site v-else></tabbar-site>
        </view>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
import HostCostPlanList from "./components/usePlan/list.vue";
import UsingRecord from "./components/usingRecord/list.vue";
export default {
    components: { HostCostPlanList, UsingRecord, TabbarHost, TabbarSite },
    data() {
        return {
            tabList: [
                {
                    name: "安全经费使用计划",
                },
                {
                    name: "安全经费使用记录",
                },
            ],
            tabContentIndex: 0,
            swipIndex: 0,
            // tabIndex: 0,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            isMounted: false,
        };
    },
    mounted() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        if (this.$route.query.tabContentIndex) {
            this.tabContentIndex = this.$route.query.tabContentIndex;
        }
        this.afterTabChanged();
        this.isMounted = true;
    },
    onShow() {
        if (this.isMounted) {
            this.afterTabChanged();
        }
    },
    methods: {
        afterTabChanged() {
            if (this.tabContentIndex == 0) {
                setTimeout(() => {
                    this.$refs.UsePlan.search();
                });
            }

            if (this.tabContentIndex == 1) {
                setTimeout(() => {
                    this.$refs.UsingRecord.search();
                });
            }
        },
        onTabChanged(index) {
            this.tabContentIndex = index;
            this.afterTabChanged();
        },
        animationfinish(e) {
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
            this.tabContentIndex = current;
        },
        transition(e) {
            let dx = e.detail.dx;
            this.$refs.tabs.setDx(dx);
        },
    },
};
</script>

<style lang="scss" scoped>
.host-ent-erprise-container-2 {
    width: 100vw;
    height: calc(100vh);
    overflow: hidden;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    .swiper-ios {
        position: fixed;
        z-index: 10;
    }

    .swiper-box {
        width: 100%;
        height: calc(100vh);
        flex: 1;
    }

    .swiper-box {
        height: 300px;
    }
}
</style>