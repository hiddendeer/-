<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container>
                <eagle-input disabled title="年份" v-model="year"></eagle-input>
                <eagle-radio-group v-model="model.type" required v-if="params.planType.length>0" title="类别" prop="planType" :data-source="params.planType" />

                <eagle-input v-model="model.cost" title="费用生产计划" prop="cost" labelPosition="top" labelWidth="130" required type="textarea" />

                <eagle-input v-model="model.money" type="number" :isNumber="true" title="计划金额" prop="money" labelPosition="top" labelWidth="130" required @input="numDxsCheck(model, 2, 'money')" />
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>

    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/safeCostPlan",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            params: { planType: [] },
            year: 0,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.mainCode = this.code;

        this.initParams();
        this.year = new Date().getFullYear();
        this.model.id = this.$route.query.id;
        //
        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增安全经费使用计划",
            });
        } else {
            uni.setNavigationBarTitle({
                title: "编辑安全经费使用计划",
            });
        }
    },
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        post() {
            if (this.model.id == "0") {
                this.model.years = new Date().getFullYear();
            }

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("safe_cost_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "safe_cost_plan_type") {
                                _this.params.planType.push(item);
                            }
                        });
                    }
                });
        },

        numDxsCheck(form, ws, key) {
            let _this = this;
            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },
    },
};
</script>

<style scoped lang="scss">
</style>
