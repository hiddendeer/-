<template>
    <view class="host-cost-plan">
        <eagle-page-list :conditions="conditions" :margin-bottom="100" ref="eaglePageList" @initList="_initList" :param="queryParams" :pageSize="990" :dataType="dataType" :showPages="false" :controller="controller">
            <template slot="search">
                <eagle-condition @reSearch="reSearch" @search="search" v-model="queryParams" :searchResults="searchResults">
                    <eagle-select v-model="queryParams.year" title="选择年份:" prop="year" border :height="70" :data-source="list">
                    </eagle-select>
                    <eagle-input title="筛选条件" placeholder="输入关键字" v-model="conditions.name.value"></eagle-input>
                </eagle-condition>
            </template>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="handlerClick(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        <template slot="icon">
                            类别：{{ item.type | paramsFormat(params.planType) }}
                        </template>
                    </eagle-row-view>
                    <!-- <template slot="tag">
                        <view> <span class="primary"> 类别：{{item.type|paramsFormat(params.planType)}}</span></view>
                    </template> -->
                    <!-- <eagle-row-view :isTitle="true" type="warn">
                        类别：{{item.type|paramsFormat(params.planType)}}
                    </eagle-row-view> -->
                    <eagle-girdrow-base class="balck-title">
                        <view>安全生产费用计划：{{ item.cost }}</view>
                    </eagle-girdrow-base>
                    <eagle-girdrow-base :spaceBetween="false">
                        <view> 计划金额：{{ item.money.toFixed(2) }}</view>
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" @click="del(item.id)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerEitClick(item)" size="mini">编辑</u-button>
                        <!-- <u-icon class="eagle-blue eagle-row-span" @click="handlerEitClick(item)" name="edit-pen" label="编辑" />
                        <u-icon @click="del(item.id)" class="eagle-red eagle-row-span" name="trash" label="删除" /> -->
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'>
        </eagle-fab>

    </view>
</template>

<script>
export default {
    name: "host-cost-plan-list",
    data() {
        return {
            data: [],
            list: [],
            name: "",
            searchResults: "",
            queryParams: {
                year: new Date().getFullYear(),
                enterpriseCode: "",
            },
            conditions: {
                name: {
                    value: "",
                },
            },
            dataType: "list",
            controller: "site/safeCostPlan",
            params: {
                planType: [],
            },
        };
    },
    mounted() {
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
    },
    created() {
        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.list.push({
                id: i,
                name: i,
            });
        }

        this.queryParams.year = new Date().getFullYear();
        this.searchResults = this.queryParams.year;
        this.initParams();
    },

    methods: {
        _initList(data) {
            this.data = data;
        },
        search() {
            this.searchResults = this.queryParams.year;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    // conditions: conditions,
                    params: this.queryParams,
                });
            });
        },
        reSearch() {
            this.queryParams.year = new Date().getFullYear();
            this.conditions.name.value = "";
        },

        initParams() {
            var _this = this;
            this.common
                .getparamsList("safe_cost_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "safe_cost_plan_type") {
                                _this.params.planType.push(item);
                            }
                        });
                    }
                });
        },

        handlerEitClick(item) {
            var url =
                "/pages/host/response/productCost/components/usePlan/detail?id=" +
                item.id +
                "&year=" +
                this.queryParams.year;

            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },

        handlerClick(item) {
            var url =
                "/pages/host/response/productCost/components/usePlan/view?id=" +
                item.id +
                "&year=" +
                this.queryParams.year;
            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },

        handlerFabClick() {
            var url =
                "/pages/host/response/productCost/components/usePlan/detail?id=0" +
                "&year=" +
                this.queryParams.year;
            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.balck-title {
    font-size: 16px;
    color: #333;
}
</style>