<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container title="安全经费使用详情">
                <eagle-text title="年度" v-model="model.years" />
                <eagle-text title="类别" :value="model.type|paramsFormat(params.planType)" />
                <eagle-text title="使用人/部门" v-model="model.peopleChnName" />
                <eagle-text title="使用时间" :value="model.useDate|dateFormat" />
                <eagle-text title="使用金额(元)" :value="model.money|moneyFormat" />
                <eagle-text title="实际使用内容" v-model="model.content" />
                <eagle-text title="附件">
                    <eagle-file-upload disabled prop="attachs" v-model="model.attachs"></eagle-file-upload>
                </eagle-text>

            </eagle-container>

        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            codeMain: "",
            errorType: ["message"],
            control: "site/safeCostRecord",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            isAddCost: false,
            list: [],
            params: { planType: [] },
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.codeMain = this.$route.query.codeMain;
        this.model.mainCode = this.code;

        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.list.push({
                id: i,
                name: i,
            });
        }

        this.initParams();
    },
    methods: {
        initCallBack(data) {
            this.model = data;

            if (this.model.id == "0") {
                this.model.years = new Date().getFullYear();
            }

            if (this.codeMain) {
                this.model.years = this.$route.query.years;
                this.model.type = this.$route.query.type;
                this.model.codeMain = this.$route.query.codeMain;
            }
        },
        post() {
            // if(this.model.id == "0"){
            // 	this.model.years = new Date().getFullYear()
            // }

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            var url = "pages/host/response/productCost/index?radioIndex=1";

            if (this.$route.query.enterpriseCode) {
                url =
                    url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            }
            this.base.navigateTo(url);
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("safe_cost_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "safe_cost_plan_type") {
                                _this.params.planType.push(item);
                            }
                        });
                    }
                });
        },

        numDxsCheck(form, ws, key) {
            let _this = this;

            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },
    },
};
</script>

<style scoped lang="scss">
</style>
