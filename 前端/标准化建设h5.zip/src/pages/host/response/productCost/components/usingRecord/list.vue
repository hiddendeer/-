<template>
    <view class="host-cost-record">
        <eagle-page-list :margin-bottom="100" ref="eaglePageList" @initList="_initList" :boolInitData="false" :pageSize="990" :dataType="dataType" :showPages="false" :controller="controller">
            <view slot="search">
                <eagle-condition @reSearch="reSearch" @search="search" v-model="params" :searchResults="searchResults">
                    <eagle-select v-model="year" title="选择年份:" prop="year" border :height="70" :data-source="list" labelWidth="150">
                    </eagle-select>

                    <eagle-input title="筛选条件" placeholder="输入关键字" v-model="name" :labelWidth="150"></eagle-input>

                </eagle-condition>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="handlerClick(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        <template slot="icon">
                            类别：{{ item.type | paramsFormat(params.planType) }}
                        </template>
                    </eagle-row-view>
                    <eagle-girdrow-base class="balck-title" v-if="item.cost">
                        <view> 安全费用计划： {{ item.cost }}</view>
                    </eagle-girdrow-base>
                    <eagle-girdrow-base :class="{ 'balck-title': !item.cost }" v-if="item.content">
                        <view> 实际使用内容： {{ item.content }}</view>
                    </eagle-girdrow-base>
                    <!-- <template slot="tag">
                        <view> <span class="primary"> 类别：{{item.type|paramsFormat(params.planType)}}</span></view>
                    </template> -->
                    <eagle-girdrow-base>
                        <view v-if="item.peopleChnName"> 使用人/部门： {{ item.peopleChnName }}</view>
                        <view> 计划金额： {{ item.money.toFixed(2) }}</view>
                        <view v-if="item.costMoney"> 使用金额： {{ item.costMoney.toFixed(2) }}</view>

                    </eagle-girdrow-base>

                    <template slot="button">
                        <u-button type="error" @click="del(item.id)" v-if="item.id > 0" size="mini">删除</u-button>
                        <u-button type="primary" @click="editClick(item)" v-if="item.id > 0" size="mini">编辑</u-button>
                        <u-button type="primary" @click="handlerEitClick(item)" size="mini">添加费用</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item,index) in data" :key="index">
                    <view class="uni-media-list">
                        <view class="uni-media-list-body" @click="handlerClick(item)">
                            <eagle-girdrow-base :isTitle="true">
                                <eagle-girdrow-block> 类别：{{item.type|paramsFormat(params.planType)}}</eagle-girdrow-block>
                            </eagle-girdrow-base>
                            <eagle-girdrow-base>
                                <eagle-girdrow-block> 安全生产费用计划：{{item.cost}}
                                    <view class="text"></view>
                                </eagle-girdrow-block>
                            </eagle-girdrow-base>
                            <eagle-girdrow-base v-if="item.peopleChnName">
                                <eagle-girdrow-block>使用人/部门：{{item.peopleChnName}} </eagle-girdrow-block>
                            </eagle-girdrow-base>
                            <eagle-girdrow-base>
                                <eagle-girdrow-block>计划金额：{{item.money.toFixed(2)}}</eagle-girdrow-block>
                            </eagle-girdrow-base>
                            <eagle-girdrow-base>
                                <eagle-girdrow-block>使用金额：{{item.costMoney.toFixed(2)}} </eagle-girdrow-block>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>

                        <u-icon class="eagle-blue eagle-row-span" @click="editClick(item)" v-if="item.id > 0" name="edit-pen" label="编辑" />
                        <u-icon @click="del(item.id)" v-if="item.id > 0" class="eagle-red eagle-row-span" name="trash" label="删除" />
                        <u-icon class="eagle-blue eagle-row-span" @click="handlerEitClick(item)" v-if="item.planCode" name="red-packet-fill" label="添加费用" />

                    </eagle-grid-botton>
                </view> -->
            </view>

        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'>
        </eagle-fab>

        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    name: "host-cost-record-list",
    data() {
        return {
            searchResults: "",
            data: [],
            list: [],
            year: new Date().getFullYear(),
            name: "",
            dataType: "list",
            controller: "site/safeCostRecord",
            params: {
                planType: [],
            },
            queryParams: {
                enterpriseCode: "",
            },
        };
    },
    // onShow() {
    //     this.search();
    // },
    mounted() {
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        this.search();
    },
    created() {
        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.list.push({
                id: i,
                name: i,
            });
        }

        this.initParams();
    },

    methods: {
        _initList(data) {
            this.data = data;
        },
        search() {
            let conditions = [];

            // [{"name":"years","operate":"=","value":"2022"}]
            let obj = {};
            obj.name = "years";
            obj.value = this.year;
            obj.operate = "=";
            conditions.push(obj);

            this.searchResults = this.year;

            if (this.name && this.name != "") {
                let obj1 = {};
                obj1.name = "cost";
                obj1.value = this.name;
                obj1.operate = "like";
                conditions.push(obj1);

                if (this.searchResults == "") {
                    this.searchResults = this.name;
                } else {
                    this.searchResults = this.searchResults + "," + this.name;
                }
            }

            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: conditions,
                });
            });
        },
        reSearch() {
            this.year = new Date().getFullYear();
            this.name = "";
        },

        initParams() {
            var _this = this;
            this.common
                .getparamsList("safe_cost_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "safe_cost_plan_type") {
                                _this.params.planType.push(item);
                            }
                        });
                    }
                });
        },

        handlerClick(item) {
            if (item.id == 0) {
                // this.$refs.uToast.show({
                //     title: "请先添加费用",
                //     type: "error",
                // });
                return false;
            }

            var url =
                "/pages/host/response/productCost/components/usingRecord/view?id=" +
                item.id +
                "&codeMain=" +
                item.codeMain +
                "&type=" +
                item.type +
                "&years=" +
                item.years;
            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },

        editClick(item) {
            var url =
                "/pages/host/response/productCost/components/usingRecord/detail?id=" +
                item.id +
                "&codeMain=" +
                item.codeMain +
                "&type=" +
                item.type +
                "&years=" +
                item.years;
            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },

        handlerEitClick(item) {
            var url =
                "/pages/host/response/productCost/components/usingRecord/detail?id=0&codeMain=" +
                item.planCode +
                "&type=" +
                item.type +
                "&years=" +
                item.years;

            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },

        handlerFabClick() {
            var url =
                "/pages/host/response/productCost/components/usingRecord/detail?id=0";

            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.balck-title {
    font-size: 16px;
    color: #333;
}
</style>
