<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container title="安全生产计划详情">
                <eagle-text title="年份" v-model="model.years" />
                <eagle-text title="类别" :value="model.type|splitParamsFormat(params.planType)" />
                <eagle-text title="费用生产计划" v-model="model.cost" />
                <eagle-text title="计划金额" :value="model.money|moneyFormat" />
                <!-- <eagle-display-input :value='year' title="年份"></eagle-display-input>

                <eagle-display-input :value="model.type|splitParamsFormat(params.planType)" title="类别" prop="type"></eagle-display-input>
                <eagle-display-input v-model="model.cost" title="费用生产计划" prop="cost"></eagle-display-input>

                <eagle-display-input v-model="model.money" title="计划金额" prop="money"></eagle-display-input> -->
            </eagle-container>
        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/safeCostPlan",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            params: { planType: [] },
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.mainCode = this.code;

        this.initParams();
        this.model.id = this.$route.query.id;
        //
    },
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        post() {
            if (this.model.id == "0") {
                this.model.years = new Date().getFullYear();
            }

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("safe_cost_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "safe_cost_plan_type") {
                                _this.params.planType.push(item);
                            }
                        });
                    }
                });
        },

        numDxsCheck(form, ws, key) {
            let _this = this;
            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },
    },
};
</script>

<style scoped lang="scss">
</style>
