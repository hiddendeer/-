<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="232" :boolInitData="false">
            <view slot="search" class="search-slot">
                <eagle-condition @search="search" v-model="queryParams" @reSearch="reSearsh" :searchResults="searchResults">
                    <eagle-select v-model="queryParams.year" title="年份" prop="queryParams.year" :data-source="kvs.year">
                    </eagle-select>
                </eagle-condition>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="handlerBodyClick(item)">
                    <eagle-girdrow-base isTitle>
                        {{ item.planName }}
                    </eagle-girdrow-base>
                    <template slot="tag">
                        <view><span :class="getType(item)">{{ item.serviceStatus | paramsFormat(status) }}</span></view>
                    </template>
                    <eagle-girdrow-base>
                        参训人员：{{ item.learnEmployeeName }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        计划培训时间：{{ item.startDate | dateFormat }} -{{ item.endDate | dateFormat }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        <eagle-grid-attach title="培训教材" v-model="item.learnResourcesAttach">
                        </eagle-grid-attach>
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="success" @click="handlerMainClick(item)" size="mini">培训记录</u-button>
                        <u-button type="primary" @click="handlerEitClick(item)" size="mini">编辑</u-button>
                        <u-button type="primary" size="mini" @click="showAction(item)">更多
                        </u-button>
                    </template>
                </eagle-row-card>
                <u-action-sheet v-model="actionShow" @close="actionShow = false" :list="actionList" @click="clickSheet" :borderRadius="15" cancelText="取消">
                </u-action-sheet>
            </view>
        </eagle-page-list>

        <eagle-fab clasr="eagle-fab" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'>
        </eagle-fab>
        <popup-window ref="popupWindow" headTitle="选择课件" :isMult="true" idField="id" textField="resourceName" controller="/site/trainLearnResourceslib" dataType="list" @callBackChoosedData="callBackChoosedData">
        </popup-window>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
import popupWindow from "@/components/eagle-courseLib-choose/popup-window.vue";
export default {
    components: {
        TabbarHost,
        TabbarSite,
        "popup-window": popupWindow,
    },
    mounted() {
        this.search();
    },
    data() {
        return {
            searchResults: "",
            controller: "site/learnPlan",
            data: [],
            model: {},
            conditions: {
                planName: {
                    value: "",
                    operate: "like",
                },
            },
            status: [
                {
                    id: 1,
                    name: "待实施",
                    color: "#909399",
                },
                {
                    id: 2,
                    name: "进行中",
                    color: "#0088ff",
                },
                {
                    id: 3,
                    name: "已逾期",
                    color: "#E6A23C",
                },
                {
                    id: 4,
                    name: "已完成",
                    color: "#67C23A",
                },
            ],
            queryParams: {
                year: "",
                enterpriseCode: "",
            },
            kvs: {
                year: [],
                checkTypeCode: [],
            },
            optionItem: {},
            actionShow: false,
            actionList: [
                { text: "删除", name: "del" },
                { text: "选择课件", name: "addClick" },
            ],
        };
    },
    computed: {},
    created() {
        var _this = this;
        var year = new Date().getFullYear();
        this.queryParams.year = year;
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        for (var i = year - 5; i < year + 5; i++) {
            _this.kvs.year.push({
                id: i,
                name: i,
            });
        }

        this.searchResults = this.queryParams.year;
    },
    methods: {
        getType(item) {
            let type = "success";
            switch (item.serviceStatus) {
                case 2:
                    type = "primary";
                case 3:
                    type = "orange";
            }
            return type;
        },
        _initList(list) {
            this.data = list;
        },
        reSearsh() {
            this.queryParams.year = new Date().getFullYear();
            this.conditions.planName.value = "";
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/listDetail",
                {
                    id: 0,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        addClick(item) {
            this.model = item;
            this.$refs.popupWindow.show();
        },

        hdChangeRes(array) {
            let _this = this;
            let learnResourcesAttach = [];

            // let tmpArray1 = JSON.parse(this.model.learnResourcesAttach);
            // tmpArray1.forEach((x) => {
            //     learnResourcesAttach.push(x);
            // });

            let learnLogTemplateAttach = [];
            array.forEach((item) => {
                if (item.resourcesAttach) {
                    let tmpArray = JSON.parse(item.resourcesAttach);
                    tmpArray.forEach((x) => {
                        learnResourcesAttach.push(x);
                    });
                }
            });

            uni.showLoading({
                mask: true,
            });

            var url = "site/learnPlan/setResourcesAttach";

            var model = this.model;
            model.learnResourcesAttach = JSON.stringify(learnResourcesAttach);

            _this.common.post(url, model).then(function (res) {
                if (res.code == 200) {
                    _this.search();

                    uni.hideLoading();
                } else {
                    uni.hideLoading();
                    _this.$refs.uToast.show({
                        title: res,
                        type: "error",
                    });
                }
            });
        },

        callBackChoosedData(e) {
            this.hdChangeRes(e);
        },

        handlerEitClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/listDetail",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerMainClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/upload",
                {
                    id: item.id,
                    code: item.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        handlerBodyClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/listView",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        search() {
            let _this = this;

            this.searchResults = this.queryParams.year;

            if (this.conditions.planName.value) {
                this.searchResults =
                    this.searchResults + "," + this.conditions.planName.value;
            }

            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.queryParams,
            });
        },

        gotoProjectDetail(item) {
            let url = "";
            switch (this.queryParams.modulesId) {
                case "host":
                    url = "/pages/host/hostMain/hostIndex";
                    break;
                case "dangerJg":
                    break;
                default:
                    break;
            }
            url =
                url +
                "?projectId=" +
                item.code +
                "&enterpriseCode=" +
                item.enterpriseCode;
            this.base.navigateTo(url);
        },

        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        showAction(item) {
            this.optionItem = item;
            this.actionShow = true;
            let timer = setTimeout(()=> {
                clearTimeout(timer)
                let drawerDom = document.querySelector('.u-drawer')
                let copyone = drawerDom
                drawerDom.parentNode.removeChild(drawerDom)
                document.body.appendChild(copyone)
            }, 20)
        },
        clickSheet(index) {
            let item = this.actionList[index];
            switch (item.name) {
                case "addClick":
                    this.addClick(this.optionItem);
                    break;
                case "handlerMainClick":
                    this.handlerMainClick(this.optionItem);
                    break;
                case "del":
                    this.del(this.optionItem.id);
                    break;
                // case "handlerMainClick":
                //     this.handlerMainClick(this.optionItem);
                //     break;
            }
        },
    },
};
</script>

<style lang="scss">
.host-train-body-item {
    display: flex;
    justify-content: space-between;
    width: 100%;
    box-sizing: border-box;
    height: 50rpx;
    align-items: center;

    .left {
        height: 40rpx;
        line-height: 40rpx;
        font-size: 28rpx;
        font-weight: 600;
    }

    .right {
        height: 40rpx;
        width: 200rpx;

        /deep/.uni-input-input {
            font-size: 26rpx;
        }
    }
}

.eagle-fab {
    bottom: 225px;
}

.list-card-body {
    padding: 0 16rpx;
    box-sizing: border-box;
}

.host-train-body-bottom {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 15rpx 0 0 0;

    .bottom-item {
        width: 220rpx;
        height: 120rpx;
        font-weight: 600;
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        margin-bottom: 15rpx;
        border-radius: 10rpx;

        &:nth-child(1) {
            background: #e60d0d;
            color: #ffffff;
        }

        &:nth-child(2) {
            background: #ecb70c;
        }

        &:nth-child(3) {
            background: #4262d4;
            color: #ffffff;
        }

        &:nth-child(4) {
            background: #198608;
            color: #ffffff;
        }

        &:nth-child(5) {
            background: #198608;
            color: #ffffff;
        }
    }
}
</style>
