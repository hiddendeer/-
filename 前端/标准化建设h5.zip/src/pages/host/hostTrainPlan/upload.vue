<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" :detailUrl="detailUrl" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container>
                <eagle-text v-model="model.planName" title="培训名称">
                </eagle-text>

                <eagle-date title="培训时间" v-model="model.learnDate" labelPosition="top" labelWidth="130" required>
                </eagle-date>

                <!-- <eagle-input v-model="model.learnEmployeeName" title="参训人员" prop="learnEmployeeName" labelPosition="top" labelWidth="130" required>
                </eagle-input> -->

                <eagle-file-upload title="上传培训记录" prop="learnLogAttach" v-model="model.learnLogAttach" labelPosition="top" labelWidth="150" required></eagle-file-upload>

                <eagle-upload title="上传现场照片" :maxCount="3" prop="learnLocaleImg" v-model="model.learnLocaleImg" labelPosition="top" labelWidth="150" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
import eagleText from "../../../components/eagle-text/eagle-text.vue";
export default {
    components: { eagleText },
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/learnPlan",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            detailUrl: "site/learnPlan/initMinutes/" + this.$route.query.code,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.mainCode = this.code;
    },
    methods: {
        initCallBack(data) {
            // this.model = data
        },
        post() {
            //

            this.$refs.eagleForm.post({
                url: "site/learnPlan/submit",
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/list",
                {
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style scoped lang="scss">
</style>
