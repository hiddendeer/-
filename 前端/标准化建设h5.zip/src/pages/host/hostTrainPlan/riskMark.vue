<template>
    <view class="eagle-layer eagle-train-res-lib">
        <eagle-page-list ref="eaglePageList" :controller="controller" :dataType="dataType" :showCheck="true" @initList="_initList" :margin-bottom="70" :boolInitData="false">
            <view slot="search" class="search-slot">
                <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled" :show-action="false" @clear="search"></eagle-search>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" :hasImg="true" :imgSrc="item.cover" @click="setFileList(item.resourcesAttach)">
                    <view>
                        {{ item.resourceName }}
                    </view>
                    <view>
                        所属分类： {{ item.resourcesTypeName }}
                    </view>
                    <template slot="rowBtn">
                        <u-button type="success" @click="setFileList(item.resourcesAttach)" size="mini">播放</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

        <tabbar-host v-if="enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";

export default {
    components: { TabbarHost, TabbarSite },
    data() {
        return {
            controller: "/site/trainLearnResourceslib",
            dataType: "list",
            searchValue: "",
            data: [],
            clearabled: true,
            queryParams: {},
            directoryUrl: "/support/riskMark/getMarkDirectory",
            query: {
                params: {
                    pageNum: 1,
                    pageSize: 20,
                    pageType: "OpRegulation",
                },
            },
            checkedList: [],
            enterpriseCode: "",
        };
    },
    computed: {},

    created() {
        let _that = this;

        this.search();
    },
    mounted() {
        if (this.$route.query.enterpriseCode) {
            this.enterpriseCode = this.$route.query.enterpriseCode;
        }
    },
    methods: {
        _initList(list) {
            console.log("list: ", list);

            this.data = list;
            this.checkedList = this.data;
        },
        doPreviewDoc(code) {
            var url = "/pages/common/pdfView?code=" + code;
            this.base.navigateTo(url);
        },
        setFileList(attachs) {
            var fileList = [];
            if (attachs) {
                if (typeof attachs == "string") {
                    var arryFile = JSON.parse(attachs);
                    fileList = arryFile;
                } else {
                    fileList = attachs;
                }
                if (fileList.length > 0) {
                    var item = fileList[0];
                    this.doPreviewDoc(item.attCode);
                }
            }
        },

        search() {
            // this.queryParams.keyword = this.searchValue;

            var conditions = [];

            if (this.searchValue) {
                let obj = {};
                obj.name = "resourceName";
                obj.value = this.searchValue;
                obj.operate = "like";

                conditions.push(obj);
            }

            setTimeout(() => {
                this.$refs.eaglePageList.search({ conditions: conditions });
            });
        },
    },
};
</script>

<style lang="scss">
.eagle-train-res-lib {
    .row-btn {
        position: absolute;
        right: 10rpx;
        bottom: 10rpx;
    }
}

// .view_container {
//     background: #fff;
//     line-height: 100rpx;
//     margin: 20rpx;
//     padding: 10rpx;
//     border-radius: 10rpx;
// }

// .view_row {
//     // display: flex;
//     justify-content: space-between;
//     margin-top: 5px;
//     margin-bottom: 5px;
//     margin-left: 5px;
//     margin-right: 5px;
//     // border: 1px solid #ececec;
//     border-radius: 5px;
//     background-color: #fff;
//     align-items: center;
//     // height: 200px;

//     .view_row-item {
//         // display: flex;
//         align-items: center;

//         image {
//             width: 100%;
//             height: 100%;
//         }
//     }
// }
// .uni-media-list-text-top {
//     line-height: 100rpx;
//     text-indent: 20rpx;
// }

// .view-choose-botton {
//     position: fixed;
//     width: 100%;
//     bottom: 0px;
//     padding-bottom: 15px;
//     padding-top: 10px;
//     background: #fff;
//     .choose-item {
//         float: left;
//         display: inline-block;
//         line-height: 40px;
//         margin-left: 10px;
//         font-size: 16px;
//     }

//     .choose-num {
//         color: #2979ff;
//     }

//     .choose-btn {
//         float: right;
//         // margin-left: 8rpx;
//         margin-right: 20rpx;
//     }
// }

// .uni-date__icon-clear {
//     top: 10rpx;
//     right: 0;
//     display: inline-block;
//     box-sizing: border-box;
//     border: 12rpx solid transparent;
//     margin-right: 12rpx;
//     cursor: pointer;
// }

// .choosed-view {
//     margin-bottom: 50rpx;
// }

// .uni-page-head {
//     background-color: rgb(27, 118, 209);
//     color: white;
// }
</style>
