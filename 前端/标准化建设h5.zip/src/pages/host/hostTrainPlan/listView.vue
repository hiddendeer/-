<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :boolInitData="true">
            <eagle-container title="安全培训计划详情">
                <eagle-text title="计划名称" v-model="model.planName" />
                <eagle-text title="计划培训时间">
                    {{model.startDate|dateFormat}}-{{model.endDate|dateFormat}}
                </eagle-text>
                <eagle-text title="培训时间" :value="model.learnDate|dateFormat" />
                <eagle-text title="参训人员" v-model="model.learnEmployeeName" />
                <eagle-text title="上传培训记录">
                    <eagle-file-upload disabled prop="learnLogAttach" v-model="model.learnLogAttach"></eagle-file-upload>
                </eagle-text>
                <eagle-text title="现场照片">
                    <eagle-display-image v-model="model.learnLocaleImg"></eagle-display-image>
                </eagle-text>
            </eagle-container>

        </eagle-form>
        <!-- <eagle-bottom-view marginBottom="5px">
            <u-button type="primary" size="medium" @click="post()">保存</u-button>
        </eagle-bottom-view> -->

        <u-toast ref="uToast" />

    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/learnPlan",
            labelPosition: "top",
            labelWidth: "150",
            type: "",
            deletable: true,
            time: "",
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.mainCode = this.code;
    },
    methods: {
        initCallBack(data) {
            this.model = data;
            this.time =
                this.common.dateFormat(this.model.startDate) +
                " 至 " +
                this.common.dateFormat(this.model.endDate);
        },
        post() {
            if (this.model.learnResourcesAttach == "") {
                this.$refs.uToast.show({
                    title: "请添选择课件库",
                    type: "error",
                });
                return;
            }

            this.$refs.eagleForm.post({
                needValid: true,
                url: "site/learnPlan/setResourcesAttach",
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
        callBackChoosedData(e) {
            this.model.learnResourcesAttach = e;
        },
    },
};
</script>

<style scoped lang="scss">
</style>
