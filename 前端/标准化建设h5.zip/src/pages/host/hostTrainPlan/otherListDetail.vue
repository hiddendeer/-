<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container>
                <eagle-input v-model="model.employeeName" title="员工姓名" prop="employeeName" required>
                </eagle-input>
                <eagle-upload title="安全教育培训卡和考核记录" :maxCount="9" prop="examineAttach" v-model="model.examineAttach" labelPosition="top" labelWidth="150" />
                <eagle-text title="培训文件">
                    <eagle-grid-attach title=" " v-model="model.examineAttachPdf"></eagle-grid-attach>
                </eagle-text>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/learnPlanNewEmpLog",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.id = this.$route.query.id;

        if (this.model.id != "0") {
            uni.setNavigationBarTitle({
                title: "编辑新员工安全培训",
            });
        }
    },
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style scoped lang="scss">
</style>
