<template>
    <view class="scroll-content">
        <scroll-view scroll-y class="scroll" :style="{ height: scrollHeight + 'px' }" :scroll-top="0">
            <view class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.examineAttach">
                    <eagle-row-view :isTitle="true" type="warn">
                        记录（{{ index + 1 }})
                    </eagle-row-view>
                    <eagle-row-view>
                        <eagle-input v-model="item.employeeName" title="员工姓名" prop="employeeName" required labelWidth="130"></eagle-input>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="error" size="mini" @click="handlerDel(index)">删除</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </scroll-view>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" :loading="loading" loadingText="提交中" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>

<script>
export default {
    name: "PictureListDetail",
    data() {
        return {
            isShow: false,
            list: [],
            noImgUrl: require("@/static/img/no-img.png"),
            tags: "error",
            controller: "",
            searchValue: "",
            scrollHeight: 600,
            loading: false,
        };
    },
    components: {},
    created() {
        this.resetTableHeight();
    },
    mounted() {
        let data = uni.getStorageSync("otherPlanGetPhoto");
        // console.log("------------------data3: ", data);
        // console.log("data3.length: ", data.length);
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            let model = {};
            model.employeeName = "";
            model.examineAttach = item.filePath;
            if (this.$route.query.enterpriseCode) {
                model.companyCode = this.$route.query.enterpriseCode;
            }
            this.list.push(model);
        }
    },
    methods: {
        close() {
            this.base.navigateBack();
        },
        post() {
            for (let i = 0; i < this.list.length; i++) {
                let item = this.list[i];
                if (item.employeeName == "" || item.employeeName == null) {
                    let num = i + 1;
                    this.$refs.uToast.show({
                        title: "请输入记录(" + num + ")的员工姓名",
                        type: "error",
                    });
                    return;
                }
            }

            this.realPost();
        },
        realPost() {
            // uni.showLoading({
            //     mask: true,
            // });

            let _this = this;
            var url = "/site/learnPlanNewEmpLog/batchSave";

            var model = this.list;
            this.loading = true;
            _this.common.post(url, model).then(function (res) {
                if (res.code == 200) {
                    uni.setStorageSync("otherPlanGetPhoto", "");
                    _this.close();

                    // uni.hideLoading();
                } else {
                    // uni.hideLoading();
                    _this.$refs.uToast.show({
                        title: res,
                        type: "error",
                    });
                }
                this.loading = false;
            });
        },
        handlerDel(index) {
            let _this = this;
            this.$refs.eagleConfirm.showConfirm({
                content: "确认是否删除？",
                confirm: function () {
                    _this.list.splice(index, 1);
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消删除了",
                        type: "error",
                    });
                },
            });
        },
        resetTableHeight() {
            var _that = this;
            uni.getSystemInfo({
                success: function (res) {
                    _that.scrollHeight = res.windowHeight - 80;
                },
            });
        },
    },
};
</script>

<style lang='scss'>
.search {
    .searchFont {
        width: 80rpx;
        height: 80rpx;
        line-height: 80rpx;
        text-align: center;
        margin-left: 10rpx;
    }
}

.circleShow {
    height: 50rpx;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;
}

.content {
    padding: 24rpx;
    text-align: center;
    margin-bottom: 20rpx;
}

.finite-space-container {
    width: 100%;
    overflow: hidden;
    box-sizing: border-box;
}

.double-line {
    display: -webkit-box;
    text-overflow: ellipsis;
    overflow: hidden;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}

.one-line {
    /**
		思路：
		1.设置inline-block属相
		2.强制不换行
		3.固定高度
		4.隐藏超出部分
		5.显示“……”
	  */
    display: inline-block;
    white-space: nowrap;
    width: 120px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.card-content {
    display: flex;

    .card-content-img {
        margin-right: 20rpx;
    }

    .card-content-body {
        flex: 1 1;
    }
}
</style>
