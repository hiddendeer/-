<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm">
            <eagle-container title="新员工培训详情">
                <eagle-text title="员工姓名" v-model="model.employeeName" />
                <eagle-text title="培训记录">
                    <eagle-display-image :value="model.examineAttach" />
                </eagle-text>
                <eagle-text title="培训文件">
                    <eagle-grid-attach title=" " v-model="model.examineAttachPdf"></eagle-grid-attach>
                </eagle-text>
            </eagle-container>

        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/learnPlanNewEmpLog",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.id = this.$route.query.id;

        // if(this.model.id != "0"){
        uni.setNavigationBarTitle({
            title: "培训详情",
        });
        // }
    },
    methods: {
        initCallBack(data) {
            // this.model = data
        },
        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style scoped lang="scss">
</style>
