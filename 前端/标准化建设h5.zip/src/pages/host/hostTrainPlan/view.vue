<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" :boolInitData="false" labelAlign='left'>
            <eagle-input v-model="model.remarks" title="培训计划名称" prop="remarks" labelPosition="top" :disabled='true' :height='70' labelWidth="130"></eagle-input>
            <eagle-input v-model="model.maintenanceUserName" title="培训主题" prop="maintenanceUserName" :disabled='true' :height='70' labelPosition="top" labelWidth="130"></eagle-input>
            <eagle-input v-model="model.remarks" title="培训类型" prop="remarks" labelPosition="top" :disabled='true' :height='70' labelWidth="130"></eagle-input>
            <eagle-date v-model="model.maintenanceDate" title="培训日期" prop="maintenanceDate" labelWidth="130" labelPosition="top"></eagle-date>
            <eagle-upload title="营业执照" :maxCount="3" prop="licenseAttach" v-model="model.licenseAttach" labelWidth="130" labelPosition="top" />
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/maintenance/",
            labelPosition: "top",
            labelWidth: "150",
            type: "",
            deletable: true,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.mainCode = this.code;
    },
    methods: {
        initCallBack(data) {
            // this.model = data
        },
        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            let url =
                "pages/host/ent/enterpriseResearch/equipment/maintainlist?code=" +
                this.code +
                "&enterpriseCode=" +
                this.$route.query.enterpriseCode;
            this.base.navigateTo(url);
        },
    },
};
</script>

<style scoped lang="scss">
</style>
