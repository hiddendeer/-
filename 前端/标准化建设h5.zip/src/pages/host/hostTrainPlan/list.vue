<template>
    <view class="eagle-layer">
        <host-header-enterprise></host-header-enterprise>
        <view style="padding: 0 20rpx;">
            <u-subsection mode='subsection' active-color='#2979FF' :list="radioList" :current="sectionCurrent" :height='60' :bold='false' @change="handlerSectionChange"></u-subsection>
        </view>

        <PlanList ref="planList" v-if='sectionCurrent===0'></PlanList>
        <OtherPlanList ref="otherPlanList" v-if='sectionCurrent===1'></OtherPlanList>
        <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
// import HostHeader from '../hostMain/components/hostHeader.vue';
import HostHeaderEnterprise from "../hostMain/components/hostHeaderEnterprise.vue";
import PlanList from "./listPlan.vue";
import OtherPlanList from "./otherPlanList.vue";

export default {
    components: {
        TabbarHost,
        HostHeaderEnterprise,
        PlanList,
        OtherPlanList,
        TabbarSite,
    },
    data() {
        return {
            controller: "",
            data: [],
            clearabled: true,
            conditions: [],
            params: {
                equStatus: [],
                equipmentType: [],
            },
            searchValue: {},
            sectionCurrent: 0,
            radioList: [{ name: "安全培训计划" }, { name: "新员工安全培训" }],
            selectShow: false,
            selectValue: "",
            actionSheetList: [
                { text: "2019年" },
                { text: "2020年" },
                { text: "2021年" },
            ],
            toucheX: 0,
            toucheY: 0,
            timeOutEvent: "",
            radioList1: ["新员工", "四新", "复工", "复工", "换岗"],
            queryParams: {
                enterpriseCode: "",
            },
        };
    },
    mounted() {
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        if (this.$route.query.sectionCurrent) {
            this.handlerSectionChange(
                parseInt(this.$route.query.sectionCurrent)
            );
        }
    },

    onShow() {
        console.log("onShow");

        // if(this.$route.query.sectionCurrent){
        // 	this.sectionCurrent = this.$route.query.sectionCurrent;
        // }

        if (this.sectionCurrent == 0) {
            if (this.$refs.planList) {
                this.$refs.planList.search();
            }
        }

        if (this.sectionCurrent == 1) {
            if (this.$refs.otherPlanList) {
                this.$refs.otherPlanList.search();
            }
        }
    },
    onHide() {},
    methods: {
        handlerSectionChange(index) {
            this.sectionCurrent = index;
        },

        search() {},
        searchChang() {},
    },
};
</script>

