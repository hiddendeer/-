<template>
    <view class="detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container>
                <eagle-input v-model="model.planName" title="计划名称" prop="planName" labelPosition="top" labelWidth="130" required />

                <eagle-date title="起始时间" type="daterange" :startDate.sync="model.startDate" :endDate.sync="model.endDate" labelPosition="top" :height='70' labelWidth="130" required></eagle-date>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            companyCode: "",
            code: "",
            errorType: ["message"],
            control: "site/learnPlan",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            id: "",
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.model.mainCode = this.code;

        this.id = this.$route.query.id;
        if (this.id == "0") {
            uni.setNavigationBarTitle({
                title: "新增安全培训计划",
            });
        }
    },
    methods: {
        initCallBack(data) {
            // this.model = data
        },
        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style scoped lang="scss">
</style>
