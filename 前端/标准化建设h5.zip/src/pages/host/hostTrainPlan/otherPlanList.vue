<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="232" :boolInitData="false">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.employeeName.value" :clearabled="true" :show-action="false" @clear="search"></eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" :hasImg="true" :imgSrc="item.examineAttach" @click="handlerClick(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.employeeName }}
                    </eagle-row-view>
                    <view>
                        上传日期:{{ item.createDate | dateFormat }}
                    </view>
                    <template slot="rowBtn">
                        <u-button type="error" @click="del(item.id)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerEitClick(item)" size="mini">编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

        <eagle-fab v-if="env=='testAfx'||env=='afx'" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'>
        </eagle-fab>
        <eagle-fab v-else horizontal="right" vertical="bottom" direction="horizontal" :content='fabContent' @trigger="trigger">
        </eagle-fab>
    </view>
</template>

<script>
export default {
    components: {},
    data() {
        return {
            controller: "site/learnPlanNewEmpLog",
            data: [],

            conditions: {
                employeeName: {
                    value: "",
                    operate: "like",
                },
            },
            fabContent: [
                {
                    iconPath: "../../../static/img/AppIcon/add-grey.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/add-blue.png",
                    text: "新增",
                    active: true,
                },
                {
                    iconPath: "../../../static/img/AppIcon/camera-grey.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/camera-blue.png",
                    text: "连拍",
                    active: false,
                },
            ],
            env: "",
            searchValue: "",
        };
    },
    mounted() {
        this.search();
    },
    created() {
        this.env = process.env.VUE_APP_ENV;
    },
    methods: {
        _initList(list) {
            this.data = list;
        },
        search() {
            let _this = this;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: _this.common.getCondtions(_this.conditions),
                    params: _this.queryParams,
                });
            });
        },

        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/otherListDetail",
                {
                    id: 0,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        handlerClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/otherListView",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerEitClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/hostTrainPlan/otherListDetail",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        trigger(e) {
            this.fabContent.forEach((item, index) => {
                item.active = false;
                if (index === e.index) {
                    item.active = true;
                }
            });
            if (e.index === 0) {
                this.handlerFabClick();
            } else if (e.index === 1) {
                this.eagleClick();
            }
        },
		continuousShootingResult(dataStr){
			console.log("continuousShootingResult",dataStr);
			
			let data5 = this.$u.test.jsonString(dataStr)
			    ? JSON.parse(dataStr)
			    : dataStr;
							
			console.log("data5: ", data5);
			console.log("data5.length: ", data5.length);
							
			uni.setStorageSync("otherPlanGetPhoto", data5);
							
			let linkUrl = this.common.getLinkUrl(
			    "pages/host/hostTrainPlan/pictureListDetail",
			    {
			        enterpriseCode: this.$route.query.enterpriseCode ?? "",
			        projectId: this.$route.query.projectId ?? "",
			    }
			);
			this.base.navigateTo(linkUrl);
			console.log(res.data);
		},

        eagleClick() {
            var token = uni.getStorageSync("token");
            var url = process.env.VUE_APP_UPLOAD_FILE_URL;
            var Params = {
                name: "PlanGetPhoto",
                maxCount: 9,
                Authorization: "Bearer " + token,
                url: url,
                isNoData: true,
                title: "新员工安全培训考核记录批量上传",
            };
            // uni.setStorageSync("otherPlanGetPhoto", "");
			console.log("Params: ", Params);
			var userAgent = navigator.userAgent;
			
			uni.removeStorageSync("otherPlanGetPhoto");
			
			if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
				
				
				serve.eagleModule(Params).then((res) => {
				    let data5 = this.$u.test.jsonString(res.data)
				        ? JSON.parse(res.data)
				        : res.data;
				
				    console.log("data5: ", data5);
				    console.log("data5.length: ", data5.length);
				
				    uni.setStorageSync("otherPlanGetPhoto", data5);
				
				    let linkUrl = this.common.getLinkUrl(
				        "pages/host/hostTrainPlan/pictureListDetail",
				        {
				            enterpriseCode: this.$route.query.enterpriseCode ?? "",
				            projectId: this.$route.query.projectId ?? "",
				        }
				    );
				    this.base.navigateTo(linkUrl);
				    console.log(res.data);
				});
			}else if (this.base.isWeixin()) {
				
			} else if (window.jsListener) { // 安卓
			// 	isNext = false;
			// 	window.getPicturePathResult = this.getPicturePathResult;
			
			// 	window.jsListener.getPicture(newMaxCount, this.isNeedEdit,true);
			
			window.jsListener.continuousShooting(Params);
			
			} else {
				if (window.webkit) { //iOS
					if (window.webkit.messageHandlers) {
						
						if (window.webkit.messageHandlers.continuousShooting) {
							window.continuousShootingResult = this.continuousShootingResult;
							
							
							window.webkit.messageHandlers.continuousShooting.postMessage(Params);
							
							
							
							// window.webkit.messageHandlers.getPicture.postMessage({ num: newMaxCount, isEdit: this.isNeedEdit ,isBase64:true});
						}
					}
				}
			}  
        },
    },
};
</script>

<style lang="scss">
</style>
