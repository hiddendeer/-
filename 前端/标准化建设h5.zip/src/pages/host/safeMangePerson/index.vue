<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :queryUrl="queryUrl" :margin-bottom="100" :boolInitData="false">
            <view slot="search">
                <view class="search">
                    <view class="tips-body">
                        <img :src="warninigIcon.default" />
                        <span>根据企业四色分级管理评分规则，缺少专（兼）职安管员任命书，减10分。</span>
                    </view>
                    <eagle-search @search="search" placeholder="请输入文件名称进行模糊搜索" v-model="conditions.name.value" :clearabled="true" :show-action="false" @clear="search"></eagle-search>
                </view>
            </view>
            <view slot="list">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <template slot="tag">
                        <view> <span :class="item.status == '10' ? 'blue' : 'red'"> {{ item.status == '10' ? '启用' : '禁用' }}</span></view>
                    </template>
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.name }}
                    </eagle-row-view>
                    <eagle-row-view>
                        录入人:{{ item.createChnName }}
                    </eagle-row-view>
                    <eagle-row-view>
                        录入时间:{{ item.createDate | dateFormat }}
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="primary" @click="handlerEitClick(item)" size="mini">编辑</u-button>
                        <u-button type="error" @click="del(item.id)" size="mini">删除</u-button>
                        <u-button type="primary" v-if="item.status == '20'" @click="handlerStatus(item.id, '10')" size="mini">启用</u-button>
                        <u-button type="error" v-else @click="handlerStatus(item.id, '20')" size="mini">禁用</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>

<script>
export default {
    components: {},
    data() {
        return {
            controller: "site/colorDutyRegime",
            queryUrl: "site/colorDutyRegime/getPageData?businessType=A",
            data: [],
            conditions: {
                name: {
                    value: "",
                    operate: "like",
                },
            },
            env: "",
            warninigIcon: require("@/static/img/AppIcon/icon_warning.png"),
        };
    },
    mounted() {
        this.search();
    },
    created() {
        this.env = process.env.VUE_APP_ENV;
        uni.$on('_update_relation_list', () => {
            this.search();
        })
    },
    methods: {
        _initList(list) {
            this.data = list;
        },
        search() {
            let _this = this;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: _this.common.getCondtions(_this.conditions),
                    params: _this.queryParams,
                });
            });
        },

        handlerFabClick() {
            let url = "pages/host/safeMangePerson/add";
            let linkUrl = this.common.getLinkUrl(url, {
                projectId: this.$route.query.projectId ?? "",
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
            });
            this.base.navigateTo(linkUrl);
        },
        confirm(content, callback) {
          this.$refs.eagleConfirm.showConfirm({
            content: content,
            confirm: () => {
              callback && callback();
            }
          });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        handlerEitClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/safeMangePerson/add",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerStatus(id, status) {
            let _this = this;
            let url = this.controller + "/editStatus";
            let str = status == "10" ? "启用" : "禁用";
            _this.confirm(`是否${str}此行数据项?`, () => {
                _this.common.post(url,{
                  ids: [id],
                  status: status,
                }).then((res) => {
                    if (res.code == 200) {
                        _this.successMsg("操作成功");
                        _this.search();
                    }
                });
            });
        },
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.tips-body {
    display: flex;
    align-items: center;
    padding: 12rpx 22rpx;
    img {
        height: 36rpx;
        width: 36rpx;
        margin-right: 16rpx;;
    }
}
</style>
