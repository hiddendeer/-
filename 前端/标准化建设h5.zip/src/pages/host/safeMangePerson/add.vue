<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" :postUrl="postUrl" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" :boolInitData="boolInitData" selfHeight='calc(100vh - 200px)' marginBottom="90px">
            <eagle-container>
                <eagle-input placeholder="请输入文件名称" maxlength="50"  v-model="model.name" required title="文件名称" prop="name" labelPosition="top" labelWidth="180"
                @input="
                    (e) => {
                        $nextTick(() => {
                            model.name = ellipsis(e,50);
                        });
                    }
                ">
                </eagle-input>
                <eagle-file-upload placeholder="请选择上传文件" :maxCount="10" required title="文件选择" prop="attachList" v-model="model.attachList" labelPosition="top" labelWidth="180" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view marginBottom="5px">
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            control: "site/colorDutyRegime",
            postUrl: 'site/colorDutyRegime/saveColorDutyRegime',
            errorType: ["message"],
            boolInitData: false,
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
            initParams: { companyCode: "" },
        };
    },

    created() {
        let _this = this;
        _this.model.businessType = 'A';
        this.model.id = this.$route.query.id;

        if (this.model.id != "0") {
            uni.setNavigationBarTitle({ title: "上传安全生产管理人员任命书" });
            this.boolInitData = true;
        } else {
            this.boolInitData = false;
        }
    },
    mounted() {
        let _this = this;
        if (this.$route.query.enterpriseCode) {
            this.initParams.companyCode = this.$route.query.enterpriseCode;
        }

        setTimeout(() => {
            let action = this.$refs.eagleForm.getAction();
            if (action == "init") {
                let url = "site/relation/initData/0";
                this.common.get(url, this.initParams).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data;
                    } else {
                    }
                    uni.hideToast();
                });
            }
        });
    },
    methods: {
        initCallBack(data) {},
        ellipsis(value, len) {
            if (!value) return "";
            if (value.length > len) {
                return value.substring(0, len);
            }
            return value;
        },
        post(op) {
            let _this = this;
            _this.model.businessType = 'A';
          if (this.model.id != "0" && this.model.id != undefined && this.model.id != null) {
            _this.postUrl = 'site/colorDutyRegime/updateColorDutyRegime';
          }

            this.$refs.eagleForm.post({
                url: _this.postUrl,
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.close();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        close() {
            this.base.navigateBack();
            uni.$emit('_update_relation_list')
        },
    },
};
</script>