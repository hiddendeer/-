<template>
    <view class="host-site-main-container">
        <view class="list-head-title">
            <u-icon name="coupon" style="margin-right: 15rpx;"></u-icon>
            一企一档
        </view>
        <view style="margin:10rpx 20rpx;background: #fff;">
            <view class="home-title">基础信息</view>
            <view class="risk-point">
                <!-- <view class="grid-item-box" @click="goOrg()">
                    <uni-badge size="small" :text="ResponseData.enterpriseNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.enterpriseNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="../../../static/icon/jc/zzjg.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">组织架构图</text>
                </view>
                <view class="grid-item-box" @click="goToProcess()">
                    <uni-badge size="small" :text="ResponseData.processNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.processNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="../../../static/icon/jc/scgy.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">生产工艺</text>
                </view> -->
                <view class="grid-item-box" @click="goCertificate()">
                    <uni-badge size="small" :text="ResponseData.certificateNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.certificateNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="../../../static/icon/jc/gwzs.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">岗位证书</text>
                </view>
            </view>
            <view class="home-title">现场调研</view>
            <view class="risk-point">
                <!-- <view class="grid-item-box" @click="goBuild()">
                    <uni-badge size="small" :text="ResponseData.buildNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.buildNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="@/static/icon/jc/jgzw.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">建构筑物</text>
                </view> -->
                <view class="grid-item-box" @click="goPost()">
                    <uni-badge size="small" :text="ResponseData.workNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.workNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="@/static/icon/jc/zygw.png">
                        </u-image>

                    </uni-badge>
                    <text class="text">作业岗位</text>
                </view>
                <view class="grid-item-box" @click="goEquipment()">
                    <uni-badge size="small" :text="ResponseData.equipmentNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.equipmentNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="@/static/icon/jc/sbss.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">设备设施</text>
                </view>
                <!-- <view class="grid-item-box" @click="goMaterial()">
                    <uni-badge size="small" :text="ResponseData.materialNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.materialNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="@/static/icon/jc/scyfl.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">生产原辅料</text>
                </view>
                <view class="grid-item-box" @click="goLimitSpace()">
                    <uni-badge size="small" :text="ResponseData.spaceNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.spaceNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="@/static/icon/jc/yxkj.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">有限空间</text>
                </view> -->
                <view class="grid-item-box" @click="goRelation()">
                    <uni-badge size="small" :text="ResponseData.relationNum" absolute="rightTop" :isShowZero="true"
                        :type="ResponseData.relationNum > 0 ? badgePrimaryType : badgeErrorType">
                        <u-image width="70rpx" height="70rpx" src="@/static/icon/jc/xgf.png">
                        </u-image>
                    </uni-badge>
                    <text class="text">相关方</text>
                </view>
            </view>
        </view>
        <view class="list-head-title">
            <u-icon name="list" style="margin-right: 15rpx;"></u-icon>
            目标职责/制度化管理/安全投入
        </view>
        <view class="head-top">
            <view class="yaun">
                <!-- <view class="yaun-text">
					<view class="asdf">
					</view>
					<text class="">
						安全生产基本文书<text style="color: #332a7c;font-size: 18px;margin-left: 4px;">2<text style="font-size: 10px;">份</text></text>
					</text>
				</view> -->

                <view class="yaun-text">
                    <view class="asdf">
                    </view>
                    <text class="">
                        <text style="font-size: 26rpx;">安全生产责任制</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ ResponseData.postResponseNum
                        }}</text>
                        <text style="font-size: 24rpx;">岗位</text>
                    </text>
                </view>
                <view class="yaun-text">
                    <view class="asdf">
                    </view>
                    <text class="" style="white-space: nowrap;">
                        <text style="font-size: 26rpx;">安全生产目标责任书</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ ResponseData.deptResponseNum
                        }}</text>
                        <text style="font-size: 24rpx;">份</text>
                    </text>
                </view>
                <view class="yaun-text">
                    <view class="asdf">
                    </view>
                    <text class="">
                        <text style="font-size: 26rpx;">安全生产会议</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ ResponseData.meetingNum }}</text>
                        <text style="font-size: 24rpx;">(计划)</text>
                    </text>
                </view>
                <!-- <view class="yaun-text">
					<view class="asdf">
					</view>
					<text class="">
						生成规章制度文件<text style="color: #332a7c;font-size: 18px;margin-left: 4px;">{{ResponseData.rulesNum}}<text style="font-size: 10px;">份</text></text>
					</text>
				</view> -->

                <view class="yaun-text">
                    <!-- <view class="asdf"></view>
                    <text class="">
                        <text style="font-size: 26rpx;">适用法律法规</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ Statistic.lawQty }}</text>
                        <text style="font-size: 24rpx;">条</text>
                    </text> -->
                </view>
            </view>
        </view>

        <view class="nav">
            <view class="nav-box" @click="goPlan()">
                <view style="margin-top: 8px;">
                    年度计划安全费用
                </view>
                <view style="color: #5cbdf5;">
                    {{ ResponseData.plan_cost | moneyFormat }}元
                </view>
            </view>
            <view class="nav-box" @click="goReal()">
                <view style="margin-top: 8px;">
                    年度实际提取费用
                </view>
                <view style="color: #adcf4d;">
                    {{ ResponseData.real_cost | moneyFormat }}元
                </view>
            </view>
        </view>
        <view class="list-head-title">
            <u-icon name="list" style="margin-right: 15rpx;"></u-icon>
            教育培训
        </view>
        <view class="charts">
            <!-- <view class="grid-item-box" style="float: right;margin-top: 15px;">
				<uni-badge size="small" :text="5" absolute="rightTop" type="error">
					<u-image width="70rpx" height="70rpx" src="../../../static/icon/xian/people.png">
					</u-image>
				</uni-badge>
				<text class="text">累计培训记录</text>
			</view> -->

            <view class="charts-bar-box" :style="`height:${2 * 10 + 300}rpx`"
                v-if="chartDataone.series && chartDataone.series.length > 0">
                <qiun-data-charts type="bar" :chartData="chartDataone" background="#fff" :opts="chartBarOpts" />
            </view>
            <view class="charts-ring-box" style="background: #fff;height: 500rpx;" v-else>
                <u-empty text="暂无数据"></u-empty>
            </view>
        </view>

        <view class="list-head-title">
            <u-icon name="list" style="margin-right: 15rpx;"></u-icon>隐患排查治理
        </view>
        <view style="background-color: #FFFFFF; " class="charts">
            <!-- <view class="grid-item-box"
				style="float: right;margin-top: 15px; width='70rpx'; height='70rpx';background-color: #FF0000;">
				
				<qiun-data-charts style="width: 70px;height='70px';" ref="ringCharts" type="ring" :chartData="chartData" background="none" />
			</view> -->

            <view class="charts-bar-box" :style="`height:${2 * 10 + 300}rpx`"
                v-if="dangerTaskData.series && dangerTaskData.series.length > 0">
                <qiun-data-charts type="bar" :chartData="dangerTaskData" background="#fff" :opts="chartBarOpts" />
            </view>
            <view class="charts-ring-box" style="background: #fff;height: 500rpx;" v-else>
                <u-empty text="暂无数据"></u-empty>
            </view>
        </view>

        <view style="background-color: #FFFFFF;margin-bottom: 10rpx;border-radius: 15rpx; " class="charts">
            <!-- <view style="width: 100%;  margin-left: 0px;" v-if="dangerRingData.series&&dangerRingData.series[0].data.length>0"> -->
            <view style="width: 100%;  margin-left: 0px;" v-if="dataList.M3 && dataList.M3.length > 0">
                <qiun-data-charts type="ring" :opts="dangerRingOpts" :chartData="dangerRingData" background="none" />
            </view>
            <view style="width: 100%;  margin-left: 0px;height: 500rpx;" v-else>
                <u-empty text="暂无数据"></u-empty>
            </view>
        </view>

        <view style="background-color: #FFFFFF;margin-bottom: 10rpx; " class="charts">

            <!-- <view style="width: 100%;  margin-left: 0px;" v-if="chartLineData.series&&chartLineData.series[0].data.length>0"> -->
            <view style="width: 100%;  margin-left: 0px;"
                v-if="dataList.M4 && dataList.M4.length > 0 || dataList.M5 && dataList.M5.length > 0">
                <qiun-data-charts type="line" :opts="chartlineOpts" :chartData="chartLineData" background="#fff" />
            </view>
            <view style="width: 100%;  margin-left: 0px;height: 500rpx;" v-else>
                <u-empty text="暂无数据"></u-empty>
            </view>
        </view>

        <view class="list-head-title">
            <u-icon name="list" style="margin-right: 15rpx;"></u-icon>风险分级管控
        </view>
        <view class="head-top" style="border-radius: 15rpx;">
            <view class="yaun">
                <view class="yaun-text">
                    <view class="asdf">
                    </view>
                    <text class="">
                        <text style="font-size: 26rpx;">辨识风险点</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ ResponseData.pointNum }}</text>
                        <text style="font-size: 24rpx;">个</text>
                    </text>
                </view>
                <view class="yaun-text">
                    <view class="asdf">
                    </view>
                    <text class="">
                        <text style="font-size: 26rpx;">生成风险告知卡</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ ResponseData.cardNum }}</text>
                        <text style="font-size: 24rpx;">份</text>
                    </text>
                </view>

                <!-- <view class="yaun-text">
					<view class="asdf">
					</view>
					<text class="">

						<text style="font-size: 26rpx;">编制检查表</text>
						<text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ResponseData.checkNum}}</text>
						<text style="font-size: 24rpx;">份</text>
					</text>
				</view> -->
                <view class="yaun-text">
                    <view class="asdf"></view>
                    <text class="">
                        <text style="font-size: 26rpx;">生成作业规程</text>
                        <text style="color: #332a7c;font-size:34rpx;margin:0 4rpx;">{{ ResponseData.regulationNum
                        }}</text>
                        <text style="font-size: 24rpx;">份</text>
                    </text>
                </view>
                <view class="yaun-text"></view>
            </view>
        </view>
        <view style="background-color: #FFFFFF;margin-bottom: 10px; " class="charts">
            <view style="margin-top: 10px;margin-left: 10px;">风险分布</view>
            <!-- <view style="width: 100%;  margin-left: 0px;" v-if="ringData.series[0]['data']&&ringData.series[0]['data'].length>0"> -->
            <view style="width: 100%;  margin-left: 0px;" v-if="dataList.M2 && dataList.M2.length > 0">
                <qiun-data-charts type="ring" :opts="dangerRingOpts" :chartData="ringData" background="#fff" />
            </view>
            <view style="width: 100%;  margin-left: 0px;height: 500rpx;" v-else>
                <u-empty text="暂无数据"></u-empty>
            </view>

        </view>

        <view style="background-color: #FFFFFF;margin-bottom: 10px; " class="charts">
            <view style="margin-top: 10px;margin-left: 10px;">重要风险点清单</view>

            <view style="display: flex;flex-wrap: wrap;">
                <view class="riskList" v-if="pointList && pointList.length > 0" v-for="(item, index) in pointList"
                    :key="index">
                    <view>
                        <image src="../../../static/icon/jc/fxd.png"></image>
                    </view>
                    <text class="riskListText one-line">
                        {{ item.rp_name }}
                    </text>
                    <text class="colorTextRed" v-if="item.evaluation_value == 'A/1级'">
                    </text>

                    <text class="colorTextYellow" v-else-if="item.evaluation_value == 'B/2级'">
                    </text>

                    <text class="colorTextBlue" v-else-if="item.evaluation_value == 'C/3级'">
                    </text>

                    <text class="colorTextGreen" v-else>
                    </text>
                </view>
            </view>
            <view v-if="pointList && pointList.length <= 0" style="width: 100%;  margin-left: 0px;height: 500rpx;">
                <u-empty text="暂无数据"></u-empty>
            </view>
        </view>

        <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
export default {
    components: {
        TabbarHost,
        TabbarSite,
    },
    data() {
        return {
            userInfo2: {},
            badgePrimaryType: "primary",
            badgeErrorType: "error",
            pointList: [],
            dataList: {},
            chartDataone: {},
            dangerTaskData: {},
            dangerRingData: {},
            dangerRingOpts: {
                color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666"],
                padding: [5, 5, 5, 5],
                legend: {
                    show: true,
                    position: "bottom",
                    float: "center",
                    padding: 0,
                    margin: 5,
                    backgroundColor: "rgba(0,0,0,0)",
                    borderColor: "rgba(0,0,0,0)",
                    borderWidth: 0,
                    fontSize: 12,
                    fontColor: "#666666",
                    lineHeight: 25,
                    hiddenColor: "#CECECE",
                    itemGap: 10,
                },
                title: {
                    name: "",
                    offsetX: 0,
                    offsetY: 0,
                },
                subtitle: {
                    name: "",
                    offsetX: 0,
                    offsetY: 0,
                },
                extra: {
                    ring: {
                        ringWidth: 30,
                        centerColor: "#FFFFFF",
                        activeOpacity: 0.5,
                        activeRadius: 10,
                        offsetAngle: 0,
                        customRadius: 70,
                        labelWidth: 15,
                        border: true,
                        borderWidth: 3,
                        borderColor: "#FFFFFF",
                        linearType: "none",
                    },
                    tooltip: {
                        showBox: true,
                        showArrow: true,
                        showCategory: false,
                        borderWidth: 0,
                        borderRadius: 0,
                        borderColor: "#000000",
                        borderOpacity: 0.7,
                        bgColor: "#000000",
                        bgOpacity: 0.7,
                        gridType: "solid",
                        dashLength: 4,
                        gridColor: "#CCCCCC",
                        fontColor: "#FFFFFF",
                        splitLine: true,
                        horizentalLine: false,
                        xAxisLabel: false,
                        yAxisLabel: false,
                        labelBgColor: "#FFFFFF",
                        labelBgOpacity: 0.7,
                        labelFontColor: "#666666",
                    },
                },
            },
            ringData: {
                series: [
                    {
                        data: [],
                    },
                ],
            },
            ringOpts: {
                color: ["#EE6666", "#FC8452", "#FAC858", "#1890FF"],
                title: {
                    name: "",
                    fontSize: 15,
                    color: "#666666",
                    offsetX: 0,
                    offsetY: 0,
                },
                subtitle: {
                    name: "",
                    fontSize: 25,
                    color: "#7cb5ec",
                    offsetX: 0,
                    offsetY: 0,
                },
            },
            chartlineOpts: {
                type: "line",
                canvasId: "",
                canvas2d: false,
                background: "none",
                animation: true,
                timing: "easeOut",
                duration: 1000,
                color: [
                    "#1890FF",
                    "#91CB74",
                    "#FAC858",
                    "#EE6666",
                    "#73C0DE",
                    "#3CA272",
                    "#FC8452",
                    "#9A60B4",
                    "#ea7ccc",
                ],
                padding: [15, 10, 0, 15],
                rotate: false,
                errorReload: true,
                fontSize: 13,
                fontColor: "#666666",
                enableScroll: false,
                touchMoveLimit: 60,
                enableMarkLine: false,
                dataLabel: true,
                dataPointShape: true,
                dataPointShapeType: "solid",
                tapLegend: true,
                xAxis: {
                    disabled: false,
                    axisLine: true,
                    axisLineColor: "#CCCCCC",
                    calibration: false,
                    fontColor: "#666666",
                    fontSize: 13,
                    rotateLabel: false,
                    itemCount: 5,
                    boundaryGap: "center",
                    disableGrid: true,
                    gridColor: "#CCCCCC",
                    gridType: "solid",
                    dashLength: 4,
                    gridEval: 1,
                    scrollShow: false,
                    scrollAlign: "left",
                    scrollColor: "#A6A6A6",
                    scrollBackgroundColor: "#EFEBEF",
                    format: "",
                },
                yAxis: {
                    disabled: false,
                    disableGrid: false,
                    splitNumber: 5,
                    gridType: "dash",
                    dashLength: 2,
                    gridColor: "#CCCCCC",
                    padding: 10,
                    showTitle: false,
                    data: [
                        {
                            type: "value",
                            position: "left",
                            disabled: false,
                            axisLine: true,
                            axisLineColor: "#CCCCCC",
                            calibration: false,
                            fontColor: "#666666",
                            fontSize: 13,
                            textAlign: "right",
                            title: "",
                            titleFontSize: 13,
                            titleOffsetY: 0,
                            titleOffsetX: 0,
                            titleFontColor: "#666666",
                            min: 0,
                            max: null,
                            tofix: null,
                            unit: "",
                            format: "",
                        },
                    ],
                },
                legend: {
                    show: true,
                    position: "bottom",
                    float: "center",
                    padding: 5,
                    margin: 5,
                    backgroundColor: "rgba(0,0,0,0)",
                    borderColor: "rgba(0,0,0,0)",
                    borderWidth: 0,
                    fontSize: 13,
                    fontColor: "#666666",
                    lineHeight: 11,
                    hiddenColor: "#CECECE",
                    itemGap: 10,
                },
                extra: {
                    line: {
                        type: "straight",
                        width: 2,
                    },
                    tooltip: {
                        showBox: true,
                        showArrow: true,
                        showCategory: false,
                        borderWidth: 0,
                        borderRadius: 0,
                        borderColor: "#000000",
                        borderOpacity: 0.7,
                        bgColor: "#000000",
                        bgOpacity: 0.7,
                        gridType: "solid",
                        dashLength: 4,
                        gridColor: "#CCCCCC",
                        fontColor: "#FFFFFF",
                        splitLine: true,
                        horizentalLine: false,
                        xAxisLabel: false,
                        yAxisLabel: false,
                        labelBgColor: "#FFFFFF",
                        labelBgOpacity: 0.7,
                        labelFontColor: "#666666",
                    },
                    markLine: {
                        type: "solid",
                        dashLength: 4,
                        data: [],
                    },
                },
            },
            chartLineData: {},
            chartBarOpts: {
                color: ["#1890FF"],
                padding: [15, 30, 0, 5],
                rotate: false,
                errorReload: true,
                fontSize: 13,
                fontColor: "#666666",
                enableScroll: false,
                touchMoveLimit: 60,
                enableMarkLine: false,
                dataLabel: true,
                dataPointShape: true,
                dataPointShapeType: "solid",
                tapLegend: true,
                xAxis: {
                    disabled: false,
                    axisLine: false,
                    axisLineColor: "#CCCCCC",
                    calibration: false,
                    fontColor: "#666666",
                    fontSize: 13,
                    rotateLabel: false,
                    itemCount: 5,
                    boundaryGap: "justify",
                    disableGrid: false,
                    gridColor: "#CCCCCC",
                    gridType: "solid",
                    dashLength: 4,
                    gridEval: 1,
                    scrollShow: false,
                    scrollAlign: "left",
                    scrollColor: "#A6A6A6",
                    scrollBackgroundColor: "#EFEBEF",
                    min: 0,
                    format: "",
                },
                yAxis: {
                    disabled: false,
                    disableGrid: false,
                    splitNumber: 5,
                    gridType: "solid",
                    dashLength: 8,
                    gridColor: "#CCCCCC",
                    padding: 10,
                    showTitle: false,
                    data: [
                        {
                            type: "categories",
                            position: "left",
                            disabled: false,
                            axisLine: true,
                            axisLineColor: "#CCCCCC",
                            calibration: false,
                            fontColor: "#666666",
                            fontSize: 13,
                            textAlign: "right",
                            title: "",
                            titleFontSize: 13,
                            titleOffsetY: 0,
                            titleOffsetX: 0,
                            titleFontColor: "#666666",
                            min: 0,
                            max: 0,
                            tofix: 1,
                            unit: "",
                            format: "yAxisName",
                        },
                    ],
                },
                legend: {
                    show: true,
                    position: "bottom",
                    float: "center",
                    padding: 5,
                    margin: 5,
                    backgroundColor: "rgba(0,0,0,0)",
                    borderColor: "rgba(0,0,0,0)",
                    borderWidth: 0,
                    fontSize: 13,
                    fontColor: "#666666",
                    lineHeight: 11,
                    hiddenColor: "#CECECE",
                    itemGap: 10,
                },
                extra: {
                    bar: {
                        type: "group",
                        width: 20,
                        seriesGap: 2,
                        categoryGap: 3,
                        barBorderCircle: false,
                        linearType: "none",
                        linearOpacity: 1,
                        colorStop: 0,
                        meterBorder: 1,
                        meterFillColor: "#FFFFFF",
                        activeBgColor: "#000000",
                        activeBgOpacity: 0.08,
                        meterBorde: 1,
                    },
                    tooltip: {
                        showBox: true,
                        showArrow: true,
                        showCategory: false,
                        borderWidth: 0,
                        borderRadius: 0,
                        borderColor: "#000000",
                        borderOpacity: 0.7,
                        bgColor: "#000000",
                        bgOpacity: 0.7,
                        gridType: "solid",
                        dashLength: 4,
                        gridColor: "#CCCCCC",
                        fontColor: "#FFFFFF",
                        splitLine: true,
                        horizentalLine: false,
                        xAxisLabel: false,
                        yAxisLabel: false,
                        labelBgColor: "#FFFFFF",
                        labelBgOpacity: 0.7,
                        labelFontColor: "#666666",
                    },
                },
            },
            chartBarData1List: [],
            list: [],
            controller: "/site/post",
            queryParams: {
                enterpriseCode: "",
            },
            radioList: ["台账信息一览", "异常统计分析"],
            sectionCurrent: 0,
            ResponseData: {},
            // ArchivesData: {},
            codeNo: "R00001",
            Statistic: {},
        };
    },
    created() {
        this.getEnterpriseList_l();
        // this.getStatistic();
        this.userInfo2 = uni.getStorageSync("userInfo");

        // this.getResponseData();

        // M：
        // enterpriseNum 组织架构数量
        // processNum 生产工艺数量
        // certificateNum 特殊岗位证书数量
        // buildNum 建筑物数量
        // workNum 作业岗位数量
        // equipmentNum 设备设施数量
        // materialNum 生产原辅料数量
        // spaceNum 有限空间数量
        // relationNum 相关方数量
        // deptResponseNum 目标责任书
        // postResponseNum 生产责任制
        // meetingNum 生产会议
        // rulesNum 规章制度
        // plan_cost 年度计划安全费用
        // real_cost 年度实际提取费用
        // plan_count  培训计划次数
        // real_count 实际培训记录
        // three_count 三级安全培训记录
        // pointNum 风险点数量
        // cardNum 风险告知卡数量
        // checkNum 检查表数量
        // regulationNum 作业规程数量
        // dangerPlanNum 隐患排查计划量
        // dangerTaskNum 隐患排查实际量
        // dangerTotalNum 累计隐患

        // M1 重要风险点
        // M2 风险分布
        // M3 隐患分布
        // M4 隐患排查发现数
        // M5 隐患排查整改数
    },
    methods: {
        handlerSectionChange(index) {
            this.sectionCurrent = index;
        },

        goToProcess() {
            this.navigateTo(
                "pages/host/ent/basicResearch/index?tabContentIndex=3"
            );
        },
        goOrg() {
            this.navigateTo(
                "pages/host/ent/basicResearch/index?tabContentIndex=1"
            );
        },

        goBuild() {
            //
            this.navigateTo("pages/host/ent/building/index?tabContentIndex=0");
        },

        goCertificate() {
            this.navigateTo(
                "pages/host/ent/basicResearch/index?tabContentIndex=2"
            );
        },
        goRelation() {
            this.navigateTo(
                "pages/host/ent/basicResearch/index?tabContentIndex=4"
            );
        },

        goMeeting() {
            this.navigateTo(
                "pages/host/response/meeting/list?tabContentIndex=0"
            );
        },
        goPlan() {
            this.navigateTo(
                "pages/host/response/productCost/index?tabContentIndex=0"
            );
        },

        goReal() {
            this.navigateTo(
                "pages/host/response/productCost/index?tabContentIndex=1"
            );
        },

        goEquipment() {
            // this.navigateTo(
            //     "pages/host/ent/enterpriseResearch/equipment/allList"
            // );
            this.navigateTo("pages/host/ent/building/index?tabContentIndex=2");
        },
        goMaterial() {
            // this.navigateTo(
            //     "pages/host/ent/enterpriseResearch/material/allList"
            // );
            this.navigateTo("pages/host/ent/building/index?tabContentIndex=3");
        },
        goLimitSpace() {
            // this.navigateTo(
            //     "pages/host/ent/enterpriseResearch/limitSpace/allList"
            // );
            this.navigateTo("pages/host/ent/building/index?tabContentIndex=4");
        },
        goPost() {
            // this.navigateTo("pages/host/ent/enterpriseResearch/post/allList");
            this.navigateTo("pages/host/ent/building/index?tabContentIndex=1");
        },

        navigateTo(url) {
            if (!this.userInfo2.manager && !this.queryParams.enterpriseCode) {
                return false;
            }
            let linkUrl = this.common.getLinkUrl(url, {
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
            this.base.navigateTo(linkUrl);
        },

        getStatistic() {
            var _this = this;
            var url = "site/guidelinelaw/getStatistic";

            if (this.$route.query.enterpriseCode) {
                url = url + "?companyCode=" + this.$route.query.enterpriseCode;
            }

            this.common.get(url).then((res) => {
                if (res.code == 200) {
                    this.Statistic = res.data;
                }
            });
        },

        getEnterpriseList_l() {
            var _this = this;
            var conditions = [];
            if (this.codeNo) {
                let obj = {};
                obj.codeNo = _this.codeNo;
                conditions.push(obj);
            }

            let obj1 = {};
            obj1.year = "2022";
            conditions.push(obj1);

            var url =
                "/site/commonReportForms/getMainPageInfo?conditions=" +
                encodeURI(JSON.stringify(conditions));

            // var url =
            // 	"/site/commonReportForms/getMainPageInfo?codeNo=" +
            // 	_this.codeNo +
            // 	"&year=2022";

            if (this.$route.query.enterpriseCode) {
                url = url + "&companyCode=" + this.$route.query.enterpriseCode;
            }

            this.common.get(url).then((res) => {
                if (res.code == 200) {
                    let datas = res.data;
                    this.dataList = res.data;
                    _this.ResponseData = datas.M;
                    _this.pointList = datas.M1;
                    _this.chartDataone = {
                        categories: [""],
                        color: ["#91CB74", "#1890FF"],
                        series: [
                            {
                                name: "计划培训",
                                data: [_this.ResponseData.plan_count],
                            },
                            {
                                name: "实际培训",
                                data: [_this.ResponseData.real_count],
                            },
                        ],
                    };

                    _this.dangerTaskData = {
                        categories: [""],
                        color: ["#91CB74", "#1890FF"],
                        series: [
                            {
                                name: "计划排查",
                                data: [_this.ResponseData.dangerPlanNum],
                            },
                            {
                                name: "实际排查",
                                data: [_this.ResponseData.dangerTaskNum],
                            },
                        ],
                    };

                    _this.dangerRingData = {
                        series: [
                            {
                                data: datas.M3,
                                format: "seriesName",
                            },
                        ],
                    };

                    let monthnameList = [];
                    let foundNumbList = [];
                    for (let i = 0; i < datas.M4.length; i++) {
                        let item = datas.M4[i];
                        monthnameList.push(item.monthname);
                        foundNumbList.push(item.value);
                    }

                    let rectificationList = [];
                    for (let i = 0; i < datas.M5.length; i++) {
                        let item = datas.M5[i];

                        rectificationList.push(item.value);
                    }

                    const result = Math.max(...foundNumbList);
                    _this.chartLineData = {
                        categories: monthnameList,
                        // ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月", ],
                        series: [
                            {
                                name: "发现隐患数",
                                data: foundNumbList,
                            },
                            {
                                name: "整改隐患数",
                                data: rectificationList,
                            },
                        ],
                    };

                    this.chartlineOpts["yAxis"]["data"][0]["max"] =
                        Math.ceil(result / 10) * 10;
                    if (result < 5) {
                        this.chartlineOpts["yAxis"]["splitNumber"] = result;
                    }

                    _this.ringData = {
                        series: [
                            {
                                data: datas.M2,
                                format: "seriesName",
                            },
                        ],
                    };
                }
            });
        },
    },

    mounted() {
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
    },
};
</script>

<style lang="scss" scoped>
.charts-bar-box {
    width: 100%;
    border-radius: 15rpx;
    overflow: hidden;
}

.head-top {
    margin: 10rpx 20rpx;
    margin-bottom: 0;
    padding: 10rpx;
    background: #fff;
    border-top-right-radius: 15rpx;
    border-top-left-radius: 15rpx;
}

.nav {
    display: flex;
    justify-content: space-between;
    text-align: center;
    font-weight: 700;
    margin: 10rpx 20rpx;
    margin-top: 0;
    padding: 10rpx;
    background: #fff;
    border-bottom-right-radius: 15rpx;
    border-bottom-left-radius: 15rpx;

    .nav-box {
        width: 49%;
        height: 60px;
        border: 1px solid #00b0ff;
        border-radius: 15rpx;
        background-color: #f0f8ff;
    }
}

.box {
    position: absolute;
    right: 26rpx;
    top: 8rpx;
    width: 20px;
    height: 20px;
    border-radius: 10px;
    color: #ffffff;
    text-align: center;
}

.charts {
    border: 1px solid #ededed;
    border-radius: 15rpx;
    margin: 10rpx 20rpx;
    overflow: hidden;
}

.host-site-main-container {
    width: 100vw;
    // height: calc(100vh - 80px);
    box-sizing: border-box;
    // background-color: #ffffff;

    .list-head-title {
        width: 100%;
        background: #00b0ff;
        color: #ffffff;
        font-weight: 900;
        text-align: center;
        padding: 10rpx 20rpx;
        box-sizing: border-box;
        font-weight: 600;
        font-size: 30rpx;

        image {
            width: 40rpx;
            height: 40rpx;
            margin-right: 20rpx;
            vertical-align: middle;
        }
    }
}

.home-title {
    line-height: 30px;
    font-weight: 400;
    text-indent: 18px;
    font-size: 14px;
    margin: 0 15px;
    border-bottom: 1rpx solid #ededed;
    font-weight: 600;
}

.image {
    width: 70rpx;
    height: 70rpx;
}

.text {
    width: 150rpx;
    font-size: 15px;
    text-align: center;
    margin-top: 10rpx;
}

.one-line {
    /**
		思路：
		1.设置inline-block属相
		2.强制不换行
		3.固定高度
		4.隐藏超出部分
		5.显示“……”
	  */
    display: inline-block;
    white-space: nowrap;
    // width: 100px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.riskList {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    width: 49%;
    margin-top: 10px;
    padding: 10px;

    image {
        width: 60rpx;
        height: 60rpx;
        margin-left: 10px;
    }

    .riskListText {
        // display: flex;
        line-height: 30px;
        font-size: 14px;
        // color: #bfbfbf;
        width: 160rpx;
    }

    .colorTextRed {
        width: 40rpx;
        height: 40rpx;
        border: 1rpx solid #bebeb8;
        border-radius: 10rpx;
        background-color: #ff0000;
        margin-top: 4px;
    }

    .colorTextYellow {
        width: 40rpx;
        height: 40rpx;
        border: 1rpx solid #bebeb8;
        border-radius: 10rpx;
        background-color: #ffc000;
        margin-top: 4px;
    }

    .colorTextBlue {
        width: 40rpx;
        height: 40rpx;
        border: 1rpx solid #bebeb8;
        border-radius: 10rpx;
        background-color: #ffff00;
        margin-top: 4px;
    }

    .colorTextGreen {
        width: 40rpx;
        height: 40rpx;
        border: 1rpx solid #bebeb8;
        border-radius: 10rpx;
        background-color: #00b0f0;
        margin-top: 4px;
    }
}

.yaun {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    border: 1rpx solid #bebeb8;
    border-radius: 20rpx;
    // margin: 5px 5px 7px 10px;

    view {
        width: 50%;
        padding: 10rpx;
        font-size: 10px;
    }

    .yaun-text {
        display: flex;
        line-height: 20px;
        font-size: 15px;

        .asdf {
            width: 10rpx;
            height: 10rpx;
            background-color: #00b0ff;
            border-radius: 10rpx;
            margin: 14rpx 5rpx 0 0;
        }
    }
}

.grid-item-box {
    position: relative;
    flex: 1;
    // position: relative;
    /* #ifndef APP-NVUE */
    display: flex;
    /* #endif */
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20rpx;
}

.risk-point {
    width: 100%;
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    padding: 5px;
}
</style>
