<template>
  <view>
    <eagle-form @initCallBack="initCallBack" :control="control" :postUrl="postUrl" v-model="model" ref="eagleForm"
                :out-height='60' :errorType="errorType" :boolInitData="boolInitData" selfHeight='calc(100vh - 200px)'
                marginBottom="90px">
      <eagle-container>
        <eagle-input v-model="model.name" required title="文件名称" prop="name" labelPosition="top" labelWidth="180">
        </eagle-input>
        <eagle-radio-group title="文件对象" v-model="model.businessDetailType" prop="businessDetailType"
                           v-if="pmTypeArray.length>0" :dataSource="pmTypeArray" :required="true" @change="changeType">
        </eagle-radio-group>
        <eagle-input maxlength="11" type="number" @input="() => {model.count = model.count.replace(/[^\d]/g, '')}"
                     isNumber="true" v-if="model.businessDetailType== 'A'" v-model="model.count" required
                     title="签订人数" prop="count" labelPosition="top" labelWidth="180">
        </eagle-input>
        <eagle-file-upload :maxCount="10" required title="文件选择" prop="attachList" v-model="model.attachList"
                           labelPosition="top" labelWidth="180"/>
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view marginBottom="5px">
      <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
    </eagle-bottom-view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      model: {},
      control: "site/colorDutyRegime",
      postUrl: 'site/colorDutyRegime/saveColorDutyRegime',
      errorType: ["message"],
      boolInitData: false,
      params: {
        equStatus: [],
        enterpriseScale: [],
      },
      pmTypeArray: [{
        name: '全员',
        id: 'A'
      }, {
        name: '主要负责人',
        id: 'B'
      }, {
        name: '安管员',
        id: 'C'
      }],
      initParams: {companyCode: ""},
    };
  },

  watch: {
    dataList(val) {
      this.dbPort = val.replace(/\D/g, '')
    }
  },

  created() {
    let _this = this;
    _this.model.businessType = 'B';
    this.model.id = this.$route.query.id;

    if (this.model.id != "0") {
      uni.setNavigationBarTitle({title: "编辑安全责任书"});
      this.boolInitData = true;
    } else {
      this.boolInitData = false;
    }
  },
  mounted() {
    let _this = this;
    if (this.$route.query.enterpriseCode) {
      this.initParams.companyCode = this.$route.query.enterpriseCode;
    }

    setTimeout(() => {
      let action = this.$refs.eagleForm.getAction();
      if (action == "init") {
        let url = "site/relation/initData/0";
        this.common.get(url, this.initParams).then(function (res) {
          if (res.code === 200) {
            _this.model = res.data;
          } else {
          }
          uni.hideToast();
        });
      }
    });
  },
  methods: {
    changeType(e) {
      console.log(this.model)
      // this.model.businessDetailType = this.common.formateDict(
      //     this.pmTypeArray,
      //     this.model.businessDetailType
      // );
    },
    initCallBack(data) {
    },
    post(op) {
      let _this = this;
      _this.model.businessType = 'B';
      console.log(_this.model)
      if (_this.model.businessDetailType== 'A'&& _this.model.count <= 0) {
        return _this.$refs.eagleForm.errorMsg(
            `签订人数必须大于0`
        );
      }
      if (this.model.id != "0" && this.model.id != undefined && this.model.id != null) {
        _this.postUrl = 'site/colorDutyRegime/updateColorDutyRegime';
      }
      // console.log(_this.postUrl)


      this.$refs.eagleForm.post({
        url: _this.postUrl,
        needValid: true,
        validCallback: function () {
          return true;
        },
        successCallback: function (res) {
          _this.close();
        },
        errorCallback: function (res) {
          console.log(res);
        },
      });
    },
    close() {
      this.base.navigateBack();
      uni.$emit('_update_relation_list')
    },
  },
};
</script>