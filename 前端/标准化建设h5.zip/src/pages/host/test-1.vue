<template>
	<view class="graphic-detail-container">
		<view class="header">
			<view class="title">
				<view class="title-1">钢板深加工分厂安全行动</view>
				<view class="title-2">作业人观察日常检查表</view>
			</view>
			<view class="text">
				<view class=""><text>适用行业：</text>机械行业，医药、化工与危险品生产经营行业</view>
				<view class=""><text>适用地区：</text>全国</view>
				<view class=""><text>检查说明：</text>防雷、防静电、防解冻泄露、防解冻坍塌</view>
			</view>
		</view>
		<view class="main">
			<view class="overview">
				<view class="overview-1">概述</view>
				<view class="overview-2">
					会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？对此，财政部副部长许宏才指出，因为今年退税减税的重头戏就是留抵退税。
				</view>
				<view class="overview-img">
					<u-image width="100%" height="340rpx"
						src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
					</u-image>
					<text>安全检查示意图</text>
				</view>
				<view class="overview-video">
					<u-image width="100%" height="340rpx"
						src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
					</u-image>
					<text>安全检查视频</text>
				</view>
			</view>
			<view class="term">
				<view class="term-1">基本术语定义</view>
				<view class="term-2">
					<view class="term-2-1" v-for="(item,index) in 3" :key='index+"trem"'>
						<view class="left">
							<u-image width="176rpx" height="176rpx"
								src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
							</u-image>
						</view>
						<view class="right">
							<view class="title">
								企业安全生产标准化
							</view>
							<view class="text">
								会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="case">
				<view class="case-1">
					事故案例
				</view>
				<view class="case-2">
					<u-image width="100%" height="452rpx"
						src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
					</u-image>
				</view>
				<view class="case-3">
					<view class="case-3-item">
						<view class="title">
							<view class="title-1">杭州市萧山区人民法院刑事判决书</view>
							<view class="title-2">（2019）浙0109刑初1304号</view>
							<view class="title-3">公诉机关杭州市萧山区人民检察院</view>
						</view>
						<view class="content">
							会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？
						</view>
					</view>
				</view>
			</view>
			<view class="check-list">
				<view class="check-list-1">
					安全检查清单
				</view>
				<view class="check-list-bg">
					<view class="check-list-2">
						<u-image width="100%" height="452rpx"
							src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
						</u-image>
					</view>
					<view class="check-list-3">
						基础内容
					</view>
					<view class="check-list-4">
						<view class="check-list-4-1">
							<u-image width="100%" height="452rpx"
								src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
							</u-image>
						</view>
						<view class="check-list-4-2">
							检查内容
						</view>
						<view class="check-list-4-3">
							<view class="img">
								<u-image width="176rpx" height="176rpx"
									src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
								</u-image>
							</view>
							<view class="text">
								会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？
							</view>
						</view>
						<view class="check-list-4-line"></view>
						<view class="check-list-4-4">
							<view class="img" v-for="(item,index) in 3" :key='index+"img"'>
								<u-image width="188rpx" height="182rpx"
									src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
								</u-image>
								<view class="tag">
									正确图示
								</view>
								<view class="text">
									检查图示{{index===0?'一':index===1?'二':'三'}}
								</view>
							</view>
						</view>
						<view class="check-list-4-5">
							<view class="img" v-for="(item,index) in 3" :key='index+"img1"'>
								<u-image width="188rpx" height="182rpx"
									src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
								</u-image>
								<view class="tag">
									错误图示
								</view>
								<view class="text">
									检查图示{{index===0?'一':index===1?'二':'三'}}
								</view>
							</view>
						</view>
						<view class="check-list-4-line"></view>
						<view class="check-list-4-6">
							注解
						</view>
						<view class="check-list-4-6-1">
							标题
						</view>
						<view class="check-list-4-7">
							会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？
						</view>
						<view class="check-list-4-line"></view>
						<view class="check-list-4-8">
							法律依据
						</view>
						<view class="check-list-4-9">
							<view class="item" v-for="(item,index) in 4" :key='index'>
								<view class="left" :class="index%2===0?'f5f5f5':'ffffff'">
									中华人民共和国安全生产法 第二十二条
								</view>
								<view class="right" :class="index%2===0?'f3ac00':'f6d000'">
									<u-icon name="play-right-fill" color="#ffffff" size="24"
										style="margin-right: 10rpx;"></u-icon>
									<text>查看详情</text>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="other">
				<view class="other-1">
					其他说明
				</view>
				<view class="other-bg">
					<view class="other-2">
						会上，有提问称：近年来我国持续推进增值税改革，基本建立了现代增值税制度。今年为什么要推出大规模的留抵退税？在留抵退税政策安排上，为什么将小微企业和制造业作为重点支持领域？
					</view>
					<view class="other-3">
						<u-image width="100%" height="340rpx"
							src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
						</u-image>
						<view class="text">
							安全检查示意图
						</view>
					</view>
					<view class="other-4">
						<u-image width="100%" height="452rpx"
							src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg">
						</u-image>
						<view class="text">
							安全检查视频
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
	}
</script>

<style scoped lang="scss">
	.graphic-detail-container {
		width: 100%;
		overflow: hidden;

		.header {
			width: 100%;
			height: 591rpx;
			background: url('../../static/img/checklist/head-bg.jpg') 0 0 no-repeat;
			background-clip: padding-box;
			background-size: 100% 100%;
			position: relative;
			// border-bottom-right-radius: 30rpx;
			// border-bottom-left-radius: 30rpx;

			.title {
				background-image: -webkit-linear-gradient(right, #e5f4ff, #c5e6ff);
				-webkit-background-clip: text;
				-webkit-text-fill-color: transparent;
				font-size: 36rpx;
				line-height: 1.5em;
				text-align: end;
				font-weight: bold;
				position: absolute;
				top: 100rpx;
				right: 70rpx;
			}

			.text {
				font-size: 24rpx;
				line-height: 1.5em;
				color: #FFFFFF;
				position: absolute;
				top: 330rpx;
				right: 70rpx;

				text {
					font-weight: bold;
				}
			}
		}

		.main {
			// margin-top: -15rpx;

			.overview {
				width: 100%;
				padding-bottom: 260rpx;
				position: relative;
				background: url('../../static/img/checklist/gs-bg.png') 0 0 no-repeat;
				background-clip: padding-box;
				background-size: 100% 100%;

				.overview-1 {
					position: relative;
					margin: 0 32rpx;
					// width: 100%;
					margin-top: -140rpx;
					height: 160rpx;
					background: url('../../static/img/checklist/bt-1.png') 0 0 no-repeat;
					background-clip: padding-box;
					background-size: 100% 100%;
					text-align: center;
					line-height: 150rpx;
					color: #FFFFFF;
					font-size: 48rpx;
					font-weight: bold;
					z-index: 10;
				}

				.overview-2 {
					position: relative;
					z-index: 5;
					margin: 0 32rpx;
					padding: 75rpx 32rpx 0;
					margin-top: -66rpx;
					background: #ffffff;
					border-top-right-radius: 20rpx;
					border-top-left-radius: 20rpx;
					line-height: 2em;
					padding-bottom: 46rpx;
				}

				.overview-img {
					background: #ffffff;
					margin: 0 32rpx;
					text-align: center;

					text {
						color: #999999;
						font-size: 20rpx;
						padding: 14rpx 0 26rpx;
					}
				}

				.overview-video {
					background: #ffffff;
					margin: 0 32rpx;
					text-align: center;
					padding: 26rpx 0;
					border-bottom-left-radius: 20rpx;
					border-bottom-right-radius: 20rpx;

					text {
						color: #999999;
						font-size: 20rpx;
						padding: 14rpx 0 26rpx;
					}
				}
			}

			.term {
				width: 100%;

				.term-1 {
					position: relative;
					margin: 0 32rpx;
					height: 160rpx;
					background: url('../../static/img/checklist/bt-1.png') 0 0 no-repeat;
					background-clip: padding-box;
					background-size: 100% 100%;
					text-align: center;
					line-height: 150rpx;
					color: #FFFFFF;
					font-size: 45rpx;
					font-weight: bold;
					margin-top: -10rpx;
				}

				.term-2 {
					margin: 0 32rpx;
					background-image: -webkit-linear-gradient(-95deg, #20a8f5, #0311d3);
					padding: 78rpx 32rpx 0;
					margin-top: -66rpx;
					border-radius: 20rpx;
					box-shadow: rgba($color: #036db4, $alpha: 0.1) 0 0 140rpx 280rpx;

					.term-2-1 {
						display: flex;
						padding: 12rpx 0;

						.left {
							margin-right: 16rpx;
						}

						.right {
							.title {
								color: #ffc73e;
								font-size: 28rpx;
								font-weight: bold;
								margin-bottom: 22rpx;
							}

							.text {
								color: #FFFFFF;
								font-size: 24rpx;
								line-height: 1.6em;
							}
						}
					}
				}
			}

			.case {
				background: url('../../static/img/checklist/al-bg.png') 0 0 no-repeat;
				background-clip: padding-box;
				background-size: 100% 100%;
				position: relative;
				padding: 160rpx 0 250rpx 0;
				margin-top: 60rpx;
				z-index: 9;

				.case-1 {
					position: relative;
					margin: 0 32rpx;
					height: 160rpx;
					background: url('../../static/img/checklist/bt-1.png') 0 0 no-repeat;
					background-clip: padding-box;
					background-size: 100% 100%;
					text-align: center;
					line-height: 150rpx;
					color: #FFFFFF;
					font-size: 45rpx;
					font-weight: bold;
					z-index: 10;
				}

				.case-2 {
					background: #FFFFFF;
					margin: 0 32rpx;
					padding: 80rpx 42rpx 60rpx 42rpx;
					position: relative;
					margin-top: -66rpx;
					border-top-right-radius: 20rpx;
					border-top-left-radius: 20rpx;
				}

				.case-3 {
					margin: 0 32rpx;
					padding: 0 0 36rpx 0;
					background: #FFFFFF;
					border-bottom-right-radius: 20rpx;
					border-bottom-left-radius: 20rpx;
					margin-bottom: 40rpx;

					.case-3-item {
						margin: 0 16rpx;
						background: #F5F5F5;
						border-radius: 20rpx;
						padding: 28rpx;

						.title {
							.title-1 {
								height: 50rpx;
								width: 480rpx;
								color: #FFFFFF;
								font-weight: bold;
								font-size: 28rpx;
								background: #1469e7;
								line-height: 50rpx;
								padding-left: 20rpx;
								border-top-right-radius: 50rpx;
								border-bottom-right-radius: 50rpx;
							}

							.title-2 {
								color: #999999;
								font-size: 18rpx;
								margin: 22rpx 0 18rpx 0;
							}

							.title-3 {
								color: #999999;
								font-size: 18rpx;
							}
						}

						.content {
							width: 100%;
							margin-top: 70rpx;
							color: #000000;
							font-size: 24rpx;
							line-height: 1.8em;
						}
					}

				}
			}

			.check-list {
				position: relative;
				padding: 200rpx 32rpx 96rpx;
				background: #F1faff;
				margin-top: -224rpx;
				z-index: 8;

				.check-list-1 {
					position: relative;
					// margin: 0 32rpx;
					// width: 100%;
					// margin-top: -140rpx;
					height: 160rpx;
					background: url('../../static/img/checklist/bt-1.png') 0 0 no-repeat;
					background-clip: padding-box;
					background-size: 100% 100%;
					text-align: center;
					line-height: 150rpx;
					color: #FFFFFF;
					font-size: 48rpx;
					font-weight: bold;
				}

				.check-list-bg {
					margin-top: -66rpx;
					padding: 58rpx 0 20rpx 0;
					background: url('../../static/img/checklist/qd-bg.png') 0 0 no-repeat;
					background-clip: padding-box;
					background-size: 100% 100%;
					border-radius: 20rpx;

					.check-list-2 {
						margin: 0 16rpx;
					}

					.check-list-3 {
						width: 315rpx;
						height: 57rpx;
						font-size: 36rpx;
						color: #FFFFFF;
						font-weight: bold;
						padding-left: 16rpx;
						line-height: 57rpx;
						margin: 40rpx 16rpx 0 16rpx;
						background: url('../../static/img/checklist/bt-2.png') 0 0 no-repeat;
						background-clip: padding-box;
						background-size: 100% 100%;
					}

					.check-list-4 {
						background: #FFFFFF;
						margin: 0 16rpx;
						padding: 48rpx 27rpx;
						border-radius: 20rpx;
						border-top-left-radius: 0;

						.check-list-4-2 {
							width: 168rpx;
							height: 50rpx;
							color: #FFFFFF;
							font-weight: bold;
							font-size: 30rpx;
							background: #1469e7;
							line-height: 50rpx;
							padding-left: 15rpx;
							margin: 23rpx 0 31rpx;
							border-top-right-radius: 50rpx;
							border-bottom-right-radius: 50rpx;
						}

						.check-list-4-3 {
							display: flex;
							margin-bottom: 35rpx;

							.img {
								margin-right: 16rpx;
							}

							.text {
								color: #000000;
								font-size: 24rpx;
								line-height: 1.8em;
							}
						}

						.check-list-4-line {
							height: 0;
							width: 100%;
							border-top: 1px dashed #999999;
						}

						.check-list-4-4 {
							margin-top: 32rpx;
							display: flex;
							justify-content: space-between;

							.img {
								position: relative;
								width: 188rpx;

								.tag {
									background: #1469e7;
									width: 110rpx;
									height: 40rpx;
									line-height: 40rpx;
									text-align: center;
									border-bottom-left-radius: 20rpx;
									color: #fff;
									font-size: 24rpx;
									position: absolute;
									top: 0;
									right: 0;
								}

								.text {
									color: #999999;
									font-size: 20rpx;
									text-align: center;
									margin-top: 10rpx;
								}
							}
						}

						.check-list-4-5 {
							margin: 32rpx 0 30rpx 0;
							display: flex;
							justify-content: space-between;

							.img {
								position: relative;
								width: 188rpx;

								.tag {
									background: #333333;
									width: 110rpx;
									height: 40rpx;
									line-height: 40rpx;
									text-align: center;
									border-bottom-left-radius: 20rpx;
									color: #fff;
									font-size: 24rpx;
									position: absolute;
									top: 0;
									right: 0;
								}

								.text {
									color: #999999;
									font-size: 20rpx;
									text-align: center;
									margin-top: 10rpx;
								}
							}
						}

						.check-list-4-6 {
							width: 100rpx;
							height: 50rpx;
							color: #1469e7;
							font-weight: bold;
							font-size: 30rpx;
							background: #FFFFFF;
							border: 1px solid #1469e7;
							line-height: 50rpx;
							padding-left: 15rpx;
							margin: 30rpx 0;
							border-top-right-radius: 50rpx;
							border-bottom-right-radius: 50rpx;
						}

						.check-list-4-6-1 {
							color: #333333;
							font-size: 26rpx;
							font-weight: bold;
							margin-bottom: 22rpx;
						}

						.check-list-4-7 {
							color: #333333;
							font-size: 22rpx;
							line-height: 1.8em;
							margin-bottom: 38rpx;
						}

						.check-list-4-8 {
							width: 168rpx;
							height: 50rpx;
							color: #1469e7;
							font-weight: bold;
							font-size: 30rpx;
							background: #FFFFFF;
							border: 1px solid #1469e7;
							line-height: 50rpx;
							padding-left: 15rpx;
							margin: 30rpx 0;
							border-top-right-radius: 50rpx;
							border-bottom-right-radius: 50rpx;
						}

						.check-list-4-9 {
							.item {
								display: flex;
								justify-content: space-between;
								// margin-bottom: 10rpx;

								.left {
									color: #333333;
									font-size: 20rpx;
									padding: 15rpx;
									flex: 1;
								}

								.ffffff {
									background: #ffffff;
								}

								.f5f5f5 {
									background: #F5F5F5;
								}

								.right {
									background: #f3ac00;
									color: #333333;
									font-size: 20rpx;
									padding: 15rpx;
								}

								.f3ac00 {
									background: #f3ac00;
								}

								.f6d000 {
									background: #f6d000;
								}
							}
						}
					}
				}
			}
		}

		.other {
			background: url('../../static/img/checklist/qt-bg.png') 0 0 no-repeat;
			background-clip: padding-box;
			background-size: 100% 100%;
			padding: 108rpx 32rpx 164rpx;

			.other-1 {
				position: relative;
				height: 160rpx;
				background: url('../../static/img/checklist/bt-1.png') 0 0 no-repeat;
				background-clip: padding-box;
				background-size: 100% 100%;
				text-align: center;
				line-height: 150rpx;
				color: #FFFFFF;
				font-size: 48rpx;
				font-weight: bold;
			}

			.other-bg {
				background: #FFFFFF;
				padding: 77rpx 42rpx 57rpx;
				margin-top: -66rpx;
				border-radius: 20rpx;

				.other-2 {
					color: #333333;
					font-size: 24rpx;
					line-height: 1.8em;
				}

				.other-3 {
					margin: 44rpx 0;

					.text {
						color: #999999;
						font-size: 20rpx;
						margin-top: 14rpx;
						text-align: center;
					}
				}

				.other-4 {
					margin-top: 26rpx;

					.text {
						color: #999999;
						font-size: 20rpx;
						margin-top: 14rpx;
						text-align: center;
					}
				}
			}
		}
	}
</style>
