<template>
    <view class="eagle-layer">
        <view class="u-tabs-box">
            <u-tabs-swiper prop="dangerIndex" :bold="false" name="name" ref="tabs" :list="tabList" :current="tabContentIndex" @change="onTabChanged" :is-scroll="false">
            </u-tabs-swiper>
        </view>
        <dangerPlanList ref="dangerTask" v-if="tabName==0"></dangerPlanList>
        <dangerDetailList ref="dangerList" key="dangerDetailList1" v-if="tabName==2" stype="1"></dangerDetailList>
        <dangerReportList ref="dangerReport" v-if="tabName==3"></dangerReportList>
        <dangerDetailList ref="myDangerList" key="dangerDetailList2" v-if="tabName==1&& (!projectId)" stype="2"></dangerDetailList>
        <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
import dangerPlanList from "@/pages/host/danger/dangerPlan/index";
import dangerDetailList from "@/pages/host/danger/dangerDetail/index";
import dangerReportList from "@/pages/host/danger/dangerReport/index";
export default {
    components: {
        dangerPlanList,
        dangerDetailList,
        dangerReportList,
        TabbarHost,
        TabbarSite,
    },
    data() {
        return {
            tabName: 0,
            tabList: [
                { name: "隐患排查任务", code: 0 },
                { name: "待处理隐患", code: 1 },
                { name: "隐患台账", code: 2 },
                { name: "检查报告", code: 3 },
            ],

            tabIndex: 0,
            tabContentIndex: 0,
            pageNum: 1,
            pageSize: 20,
            queryParams: { enterpriseCode: "" },
            oldTabIndex: "",
            projectId: "",
            isMounted: false,
            model: {},
        };
    },
    mounted() {
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        this.projectId = this.$route.query.projectId;
        if (this.projectId) {
            this.tabList = this.tabList.filter((x) => x.code != 1);
        }
        let hasDangerList = uni.getStorageSync("hasHostDangerList");
        if (!hasDangerList && !this.projectId) {
            this.tabList = this.tabList.filter((x) => x.code != 2);
        }
        if (this.$route.query.tabContentIndex) {
            this.tabName = parseInt(this.$route.query.tabContentIndex);
            this.initCurrentPage();
        }
        this.searchPage();
        this.isMounted = true;
    },
    onShow() {
        if (this.isMounted) {
            this.searchPage();
        }
    },

    methods: {
        initCurrentPage() {
            for (var i = 0; i < this.tabList.length; i++) {
                if (this.tabList[i].code == this.tabName) {
                    this.tabContentIndex = i;
                }
            }
        },
        onTabChanged(index) {
            this.tabContentIndex = index;
            this.tabName = this.tabList[index].code;
            this.searchPage();
        },
        animationfinish(e) {
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
        },
        transition(e) {
            let dx = e.detail.dx;
            this.$refs.tabs.setDx(dx);
        },
        searchPage() {
            switch (this.tabName) {
                case 0:
                    setTimeout(() => {
                        this.$refs.dangerTask.search();
                    });
                    break;
                case 2:
                    setTimeout(() => {
                        this.$refs.dangerList.search();
                    });
                    break;
                case 3:
                    setTimeout(() => {
                        this.$refs.dangerReport.search();
                    });
                    break;
                case 1:
                    setTimeout(() => {
                        this.$refs.myDangerList.search();
                    });
                    break;
            }
        },
    },
};
</script>

