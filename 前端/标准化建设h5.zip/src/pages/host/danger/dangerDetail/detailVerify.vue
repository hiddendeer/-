<template>
    <view class="host-danger-danger-detail-verify">

        <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" marginBottom='80px'>
            <eagle-container title="隐患详情">
                <eagle-display-image title="隐患图片" prop="attachs" v-model="model.attachs"></eagle-display-image>
                <eagle-text title="隐患状态">
                    <span v-html="common.formateStatus(params.detailStatus,model.status)"></span>
                </eagle-text>
                <eagle-text title="隐患区域" v-model="model.correctiveArea" />
                <eagle-text title="隐患描述" v-model="model.hiddenDangerDesc" />
                <eagle-text title="整改建议" v-model="model.correctiveAdvise" />
                <eagle-text title="隐患分类" v-model="model.hiddenName" />
                <eagle-text title="隐患性质" v-model="model.hiddenDangerTypeCode">
                    <span v-html="common.formateStatus(params.hiddenDangerTypeArry,model.hiddenDangerTypeCode)"></span>
                </eagle-text>

                <eagle-text title="检查人" v-model="model.createChnName" />
                <eagle-text title="检查时间">
                    {{ model.createDate|dateFormat}}
                </eagle-text>
            </eagle-container>
            <eagle-container title="整改详情">
                <eagle-text v-if="model.appointCorrectiveChnName" title="整改负责人" v-model="model.appointCorrectiveChnName" />
                <eagle-text title="整改方式" v-model="model.correctiveType">
                    {{model.correctiveType|paramsFormat(params.correctiveTypeArry)}}
                </eagle-text>
                <eagle-text title="整改期限" v-model="model.correctiveDeadline" />
                <eagle-text title="整改措施" v-model="model.correctiveMeasure" />
                <eagle-display-image title="整改图片" prop="correctiveAttachs" v-model="model.correctiveAttachs"></eagle-display-image>
                <eagle-text title="整改说明" v-model="model.correctiveDesc" />
            </eagle-container>
            <eagle-container title="复查">
                <!-- <view style="background: #ffffff;padding: 0 30rpx"> -->
                <u-form-item class="eagle-text-form-item" ref="uFormItem" label-position="top" label="复查结论">
                    <view class="btn-span">
                        <text class="btn-dft" :class="model.pass?'pass':''" @click="model.pass=true">复查通过</text>
                        <text class="btn-dft" :class="!model.pass?'un-pass':''" @click="model.pass=false">复查不通过</text>
                    </view>
                </u-form-item>
                <!-- </view> -->
                <eagle-upload title="复查图片" key="receiveAttach" prop="receiveAttach" v-model="model.receiveAttach" />
                <eagle-input type="textarea" key="receiveRemark" :row="2" label-width="100px" title="复查说明" v-model="model.receiveRemark" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="default" @click="back()">
                返回
            </u-button>
            <u-button type="primary" @click="post()">
                复查并返回
            </u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>

<script>
export default {
    components: {},
    name: "host-danger-danger-detail-corrective",
    data() {
        return {
            opType: 0, // 0 查看,1编辑,2整改,3随手拍,4 依据查
            control: "site/dangerCheckTaskDetail",
            model: {},
            initUrlParams: {
                enterpriseCode: "",
                projectId: "",
            },
            id: -10,
            params: {
                detailStatus: [
                    { id: 100, name: "已复查", color: "#67C23A" },
                    { id: 60, name: "已整改", color: "#0088ff" },
                    { id: 30, name: "待整改", color: "#dd6161" },
                    { id: 10, name: "待提交", color: "#E6A23C" },
                    { id: 5, name: "暂存", color: "#dd6161" },
                ],
                hiddenDangerTypeArry: [
                    { name: "一般隐患", id: "1", color: "#E6A23C" },
                    { name: "重大隐患", id: "2", color: "#dd6161" },
                ],
                correctiveTypeArry: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
            },
        };
    },
    computed: {},
    created() {
        this.code = this.$route.query.code;
        this.id = this.$route.query.id;
        this.initUrlParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.initUrlParams.projectId = this.$route.query.projectId ?? "";
        this.getModel();
    },

    methods: {
        post() {
            let _this = this;
            _this.$refs.eagleForm.post({
                url: `site/dangerCheckTaskDetail/rectify`,
                model: _this.model,
                needValid: true,
                successCallback: function (res) {
                    _this.back();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        getModel() {
            var _this = this;
            _this.model.attachs = "";
            if (this.id && this.id > 0) {
                this.common
                    .get("site/dangerCheckTaskDetail/getData/" + this.id)
                    .then((res) => {
                        if (res.code == 200) {
                            _this.model = res.data;
                            _this.model.pass = true;
                        }
                    });
            } else if (this.code) {
                this.common
                    .get(
                        "site/dangerCheckTaskDetail/getDataByCode/" + this.code
                    )
                    .then((res) => {
                        if (res.code == 200) _this.model = res.data;
                    });
            }
        },
        back() {
            this.base.navigateBack();
        },
    },
};
</script>

<style lang="scss" scoped>
.host-danger-danger-detail-verify {
    .btn-span {
        .btn-dft {
            border-radius: 3px;
            display: inline-block;
            border: 1px solid #c8c9cc;
            background-color: #c8c9cc;
            color: #fff;
            padding: 5px;
            width: 200rpx;
            text-align: center;
            margin: 10rpx;
        }
        .btn-dft.pass {
            border: 1px solid #19be6b;
            color: #fff;
            background-color: #71d5a1;
        }
        .btn-dft.un-pass {
            border: 1px solid #fa3534;
            color: #fff;
            background-color: #dd6161;
        }
    }
}
</style>