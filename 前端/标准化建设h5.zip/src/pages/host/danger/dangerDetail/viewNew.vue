<template>
    <view class="host-danger-danger-view">
        <eagle-form :control="control" :boolInitData="false" v-model="model" ref="eagleForm" marginBottom="80px">
            <eagle-container>
                <view slot="title">隐患详情</view>
                <eagle-text title="隐患图片">
                    <eagle-display-image prop="attachs" v-model="model.attachs"></eagle-display-image>
                </eagle-text>
                <eagle-text title="隐患状态">
                    <span v-html="common.formateStatus(params.detailStatus, model.status)"></span>
                </eagle-text>
                <eagle-text title="隐患区域" v-model="model.correctiveArea" />
                <eagle-text title="隐患描述" v-model="model.hiddenDangerDesc" />
                <eagle-text title="整改建议" v-model="model.correctiveAdvise" />
                <eagle-text title="隐患分类" v-model="model.hiddenName" />
                <eagle-text title="隐患性质" v-model="model.hiddenDangerTypeCode">
                    <span v-html="common.formateStatus(params.hiddenDangerTypeArry, model.hiddenDangerTypeCode)"></span>
                </eagle-text>
            </eagle-container>
            <eagle-container>
                <view slot="title">整改详情</view>
                <eagle-text title="整改负责人" key="appointCorrectiveChnName" v-if="model.appointCorrectiveChnName" v-model="model.appointCorrectiveChnName">
                </eagle-text>
                <eagle-text title="整改方式" key="correctiveType">
                    {{ model.correctiveType | paramsFormat(params.correctiveTypeArry) }}
                </eagle-text>
                <eagle-text title="整改期限" key="correctiveDeadline">
                    {{model.correctiveDeadline|dateFormat}}
                </eagle-text>
                <eagle-text title="整改措施" key="correctiveMeasure" v-model="model.correctiveMeasure" />
                <eagle-text title="整改图片" key="correctiveAttachs" v-if="model.correctiveAttachs || model.status >= 60">
                    <eagle-display-image v-model="model.correctiveAttachs" />
                </eagle-text>
                <eagle-text title="整改说明" key="correctiveDesc" v-if="model.correctiveDesc || model.status >= 60" v-model="model.correctiveDesc" />
                <eagle-text title="复查图片" key="receiveAttach" v-if="model.receiveAttach || model.status == 100">
                    <eagle-display-image v-model="model.receiveAttach" />
                </eagle-text>
                <eagle-text v-if="model.receiveRemark || model.status == 100" key="receiveRemark" title="复查说明" v-model="model.receiveRemark" />

            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="back()">
                返回
            </u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    components: {},
    name: "host-danger-danger-view",
    data() {
        return {
            code: "",
            id: -1,
            title: "隐患详情",
            control: "site/dangerCheckTaskDetail",
            model: {
                appointCorrectiveChnName: "",
            },
            enterpriseCode: "",
            params: {
                detailStatus: [
                    { id: 100, name: "已复查", color: "#67C23A" },
                    { id: 60, name: "已整改", color: "#0088ff" },
                    { id: 30, name: "待整改", color: "#dd6161" },
                    { id: 10, name: "待提交", color: "#E6A23C" },
                    { id: 5, name: "暂存", color: "#dd6161" },
                ],
                hiddenDangerTypeArry: [
                    {
                        name: "一般隐患",
                        id: "1",
                        color: "#E6A23C",
                    },
                    {
                        name: "重大隐患",
                        id: "2",
                        color: "#dd6161",
                    },
                ],
                correctiveTypeArry: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
            },
            initUrlParams: {
                enterpriseCode: "",
                projectId: "",
            },
            projectId: "",
        };
    },
    created() {
        this.code = this.$route.query.code;
        this.id = this.$route.query.id;
        this.initUrlParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.initUrlParams.projectId = this.$route.query.projectId ?? "";
        this.getModel();
    },
    computed: {},

    methods: {
        getModel() {
            var _this = this;
            _this.model.attachs = "";
            if (this.id && this.id > 0) {
                this.common
                    .get("site/dangerCheckTaskDetail/getData/" + this.id)
                    .then((res) => {
                        if (res.code == 200) _this.model = res.data;
                    });
            } else if (this.code) {
                this.common
                    .get(
                        "site/dangerCheckTaskDetail/getDataByCode/" + this.code
                    )
                    .then((res) => {
                        if (res.code == 200) _this.model = res.data;
                    });
            }
        },
        back() {
            this.base.navigateBack();
        },
    },
};
</script>
<style lang="scss" scoped>
.host-danger-danger-view {
}
</style>