<template name="host-plan-danger-list">
    <view class="host-danger-danger-plan">
        <eagle-page-list ref="eaglePageList" :isUseEnterprise="true" @initList="_initList" :boolInitData="false" :marginBottom="110" :controller="controller" @beforeLoad="beforeLoad" :showCheck="true" :data-type="stype == '1' ? 'siteList' : 'siteMyList'">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" title="隐患状态" prop="taskDetailStatus" :data-source="params.taskDetailStatus" v-if="stype == '1' && params.taskDetailStatus.length > 0" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.correctiveUserType.value" title="隐患类型" prop="correctiveUserType" :data-source="params.correctiveUserType" v-if="stype == '2' && params.correctiveUserType.length > 0" />

                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.hiddenDangerTypeCode.value" title="隐患性质" prop="certState" :data-source="params.hiddenDangerType" v-if="params.hiddenDangerType.length > 0">
                        </eagle-fast-choose>
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.originType.value" title="来源类型" prop="certState" :data-source="params.checkSource" v-if="stype == '1' && params.checkSource.length > 0"></eagle-fast-choose>

                        <eagle-input title="隐患描述" placeholder="请输入隐患描述模糊查询" v-model="conditions.hiddenDangerDesc.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <!-- <view class="uni-media-cell" v-for="(item) in data" :key="item.ID">
                    <view class="uni-media-list">
                        <view class="uni-media-list-body" @click="hdView(item)"> -->

                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdView(item)">
                    <eagle-girdrow-base isTitle>{{ item.hiddenDangerDesc }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-base sBetween>
                        <text>隐患来源:{{ item.originType | paramsFormat(params.checkSource) }}</text>

                    </eagle-girdrow-base>
                    <eagle-girdrow-base sBetween>
                        <text>
                            检查时间:{{ item.createDate | dateTimeFormat }}
                        </text>
                        <text>
                            检查人:{{ item.createChnName }}
                        </text>
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" size="mini" v-if="(item.manager || isHost) || (item.self && item.status == 10)" @click="hdDelete(item)">
                            删除</u-button>
                        <u-button type="primary" size="mini" v-if="item.status == 30 && !isHost" @click="hdClick(item)">
                            {{
                                    item.self || item.manager ?
                                        '整改/复查' : '整改'
                            }}</u-button>
                        <u-button type="primary" size="mini" v-if="(item.status == 60 && (item.self || item.manager)) || (item.status < 100 && item.status >= 30 && isHost)" @click="hdClick(item)">
                            复查</u-button>

                        <u-button type="success" size="mini" @click="hdView(item)">详情</u-button>
                    </template>
                    <!-- </eagle-grid-botton> -->
                </eagle-row-card>
                <!-- </view> -->
            </view>
        </eagle-page-list>
    </view>

</template>
<script>
// import Template from "../../../danger/dangerTemplate/template.vue";
export default {
    props: {
        stype: { type: String, default: "1" },
    },
    // components: { Template },
    mounted() {},
    data() {
        return {
            conditions: {
                hiddenDangerDesc: { value: "", operate: "like" },
                checkResult: { value: "N", operate: "=" },
                originType: { value: null, operate: "=" },
                status: { value: null, operate: "=" },
                hiddenDangerTypeCode: { value: null, operate: "=" },
                correctiveUserType: { value: "", operate: "=" },
            },
            queryParams: { enterpriseCode: "", projectId: "" },
            controller: "site/dangerCheckTaskDetail",
            data: [],
            clearabled: true,
            mainCode: "",
            params: {
                checkSource: [
                    { id: "", name: "不限" },
                    { id: "1", name: "随手拍" },
                    { id: "2", name: "依据检查" },
                    { id: "3", name: "检查表检查" },
                ],
                taskDetailStatus: [
                    { id: "", name: "不限" },
                    { id: "100", name: "已复查", type: "success" },
                    { id: "60", name: "已整改", type: "success" },
                    { id: "30", name: "待整改", type: "red" },
                ],
                hiddenDangerType: [
                    { id: "", name: "不限" },
                    { id: "1", name: "一般隐患" },
                    { id: "2", name: "重大隐患" },
                ],
                correctiveUserType: [
                    { id: "1", name: "我的待整改隐患" },
                    { id: "2", name: "我的待复查隐患" },
                ],
            },
            pageType: 1,
        };
    },
    computed: {
        isHost() {
            return this.queryParams.projectId != "";
        },
    },
    created() {
        this.mainCode = this.$route.query.taskCode ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.pageType = this.queryParams.projectId ? 2 : 1;
    },
    onShow() {},
    onReady() {},
    methods: {
        bindTag(val) {
            console.log(val);
            let obj = this.params.taskDetailStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        close() {
            this.visible = false;
        },
        reSearsh() {
            this.conditions.hiddenDangerDesc.value = null;
            this.conditions.originType.value = null;
            this.conditions.status.value = null;
            this.conditions.hiddenDangerTypeCode.value = null;
            this.conditions.correctiveUserType.value = null;
            this.search();
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    console.log("hdDelete");
                    _this.search();
                },
            });
        },
        hdClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/danger/dangerDetail/detailCorrective",
                {
                    taskCode: item.taskCode,
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdEdit() {
            let _this = this;

            let linkUrl = this.common.getLinkUrl(
                "/pages/host/danger/dangerDetail/detailNew",
                {
                    taskCode: item.code,
                    opType: 1,
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdVerifyClick(item) {
            let url = "/pages/host/danger/dangerDetail/detailVerify";
            let linkUrl = this.common.getLinkUrl(url, {
                taskCode: item.taskCode,
                id: item.id,
            });
            this.base.navigateTo(linkUrl);
        },
        hdView(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/danger/dangerDetail/viewNew",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        _initList(list) {
            this.data = list;
        },
        change() {
            console.log("change");
            this.search();
        },
        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                // params: _this.queryParams,
            });
        },
        initParams() {},
    },
};
</script>
<style lang="scss">
.host-plan-danger-list {
}
</style>
