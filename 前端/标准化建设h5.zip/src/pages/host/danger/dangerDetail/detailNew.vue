<template name="host-danger-danger-detail">
    <view class="host-danger-danger-detail">
        <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" marginBottom="80px">
            <eagle-container>
                <view class="item">
                    <view class="item-container">
                        <view class="citem">
                            <view v-if="model.checkResult === 'N'">
                                <eagle-upload :isNeedEdit="true"  ref="eagleUpload" title="隐患图片" v-if="opType == 1 || opType == 3 || opType == 4" key="attachs" prop="attachs" v-model="model.attachs" />
                                <eagle-display-image title="隐患图片" :required="model.originType == 1" v-if="opType === 0 || opType === 2 || opType === 5" key="display_attachs" prop="attachs" v-model="model.attachs">
                                </eagle-display-image>
                                <eagle-input type="textarea" title="隐患区域" :onlyShowRequired="model.hiddenTypeCode == '2' ? true : false" v-model="model.correctiveArea" />
                                <eagle-input type="textarea" title="隐患描述" onlyShowRequired v-model="model.hiddenDangerDesc" />

                                <eagle-input type="textarea" title="整改建议" prop="correctiveAdvise" v-model="model.correctiveAdvise">
                                    <template slot="topBotton">
                                        <view style="text-align: right">
                                            <span v-if="opType !== 0 && opType !== 2 && opType !== 5" style="color: #2979ff; margin-left: 10rpx" @click="chooseDangerLg">选择依据</span>
                                            <span style="color: #2979ff; margin-right: 20rpx;margin-left: 20rpx;" @click="showDetail()">{{opType !== 0 && opType !== 2 && opType !== 5? "编辑依据": "查看依据"}}</span>
                                        </view>
                                    </template>
                                </eagle-input>
                                <eagle-choose title="隐患分类" v-model="model.hiddenName" :onlyShowRequired="isHost" :required="isHost" :select-open="dangerTypeDialog" @click="showDangerType(model)">
                                </eagle-choose>
                                <eagle-radios :disabled="opType === 0" title="隐患性质" required onlyShowRequired :data-source="checkDatas.checkType" v-model="model.hiddenDangerTypeCode" />
                                <view v-if="!isHost" style="position: relative">
                                    <span style="color: #2979ff;position: absolute;right: 50rpx;top: 4rpx;font-size: 32rpx;z-index: 9" @click="hdSetMeCorrective">由我本人整改</span>
                                    <eagle-choose-user placeholderVal="请选择整改负责人" required onlyShowRequired title="整改负责人" :isMult="false" v-model="model.appointCorrectiveName" :names.sync="model.appointCorrectiveChnName" prop="appointCorrectiveName" />
                                </view>
                                <eagle-radios title="整改方式" required onlyShowRequired :dataSource="checkDatas.correctiveType" v-model="model.correctiveType" />
                                <eagle-date v-if="model.correctiveType == 2" label-width="100px" :disabled="opType === 0" key="correctiveDeadline" title="整改期限" v-model="model.correctiveDeadline" />
                                <eagle-input v-if="model.correctiveType == 2" type="textarea" :disabled="opType === 0" key="correctiveMeasure" :row="2" label-width="100px" title="整改措施" v-model="model.correctiveMeasure" />
                                <eagle-upload title="整改图片" v-if="model.correctiveType == 1" required key="correctiveAttachs" prop="correctiveAttachs" v-model="model.correctiveAttachs" />
                                <eagle-input v-if="model.correctiveType == 1" type="textarea" key="correctiveDesc" :row="2" label-width="100px" title="整改说明" required v-model="model.correctiveDesc" />
                            </view>
                        </view>
                    </view>
                </view>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="default" @click="back()">返回</u-button>
            <u-button class="bottom-btn" type="primary" v-if="opType !== 0" @click="post(false)">保存并返回</u-button>
            <u-button class="bottom-btn" type="success" v-if="opType == 3" @click="post(true)">保存并继续</u-button>

        </eagle-bottom-view>
        <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog = false" v-model="model.hiddenCode" @change="changeDangeType"></popup-danger-type>

        <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        <!-- <lib-temp-details :listShow='listShow' :checkType='libCheckType' @handlerSelectBase='handlerSelectBase' @handlerSelectImg='handlerSelectImg' @libtempDetailsClose='libtempDetailsClose' /> -->
        <u-toast ref="uToast" />
        <eagle-comfirm ref="eagleConfirm" />
    </view>
</template>

<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type.vue";
// import libTempDetails from "@/pages/support/libTemp/components/libTempDetails/libTempDetails.vue";
export default {
    components: {
        "popup-danger-type": popupDangerType,
        "view-danger-lg": viewDangerLg,
        // "lib-temp-details": libTempDetails,
    },
    name: "host-danger-danger-detail",
    data() {
        return {
            libCheckType: "base", //base img
            showDialog: false,
            dangerTypeDialog: false,
            listShow: false,
            taskCode: "",
            title: "隐患详情",
            opType: 0, // 0 查看,1编辑,2整改,3随手拍,4 依据查,5复查
            errorType: ["message"],
            control: "site/dangerCheckTaskDetail",
            model: {},
            enterpriseCode: "",
            params: {
                hiddenDangerType: [],
                lgdType: [],
            },
            initUrlParams: {
                ctCode: "",
            },
            checkDatas: {
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkType: [
                    { id: 1, name: "一般隐患" },
                    { id: 2, name: "重大隐患" },
                ],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
            },
            tempModel: {},
        };
    },
    created() {
        this.show();
    },
    computed: {
        isHost() {
            if (this.projectId) return true;
            else return false;
        },
    },
    methods: {
        hdSetMeCorrective() {
            let _this = this;
            let userInfo = uni.getStorageSync("userInfo");
            if (typeof userInfo === "string") {
                userInfo = JSON.parse(userInfo);
            }
            _this.model.appointCorrectiveChnName = userInfo.chnName;
            _this.model.appointCorrectiveName = userInfo.userName;
        },
        libtempDetailsClose() {
            this.listShow = false;
        },
        handlerSelectBase(val) {
            let _this = this;
            if (val.item == "base" && _this.model.correctiveAdvise) {
                this.$refs.eagleConfirm.showConfirm({
                    content: "是否确认覆盖整改建议?",
                    confirm: function () {
                        _this.setHidderDangerDesc(val);
                    },
                });
            } else if (
                val.item === "base-danger" &&
                (_this.model.hiddenDangerDesc || _this.model.correctiveAdvise)
            ) {
                this.$refs.eagleConfirm.showConfirm({
                    content: "是否确认覆盖隐患描述和整改建议?",
                    confirm: function () {
                        _this.setHidderDangerDesc(val);
                    },
                });
            } else _this.setHidderDangerDesc(val);
            this.libtempDetailsClose();
        },
        handlerSelectImg(val) {
            this.libtempDetailsClose();
        },
        setHidderDangerDesc(obj) {
            let _this = this;
            _this.model.correctiveAdvise = obj.base.correctiveAdvise;
            _this.model.gistSource = obj.base.gistSource;
            _this.model.originalText = obj.base.originalText;
            _this.model.lgCode = obj.base.lGCode;
            if (obj.item === "base-danger") {
                if (obj.danger.dFullName) {
                    _this.model.hiddenCode = obj.danger.dCode;
                    _this.model.hiddenName = obj.danger.dFullName.replace(
                        ">",
                        "-"
                    );
                    _this.model.hiddenTypeName =
                        _this.model.hiddenName.split("-")[0];
                    if (_this.model.hiddenTypeName === "现场管理")
                        _this.model.hiddenTypeCode = "2";
                    if (_this.model.hiddenTypeName === "基础管理")
                        _this.model.hiddenTypeCode = "1";
                }
                _this.model.lgHdCode = obj.danger.lGHDCode;
                _this.model.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.model.hiddenDangerTypeCode = obj.danger.hiddenDangerType;
                _this.model.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.model.legalLiability = obj.danger.legalLiability;
            }
        },
        // hdChooseLg() {
        //     this.listShow = true;
        // },
        showDetail(item) {
            let config = {
                isEdit:
                    this.opType !== 0 && this.opType !== 2 && this.opType !== 5,
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },
        handleChangeResult(result) {
            if (this.opType === 1) this.model.checkResult = result;
        },
        post(isContinue) {
            let _this = this;
            _this.$refs.eagleForm.post({
                url: `site/dangerCheckTaskDetail/save`,
                model: _this.model,
                needValid: _this.opType == 2 || _this.opType == 5,
                successCallback: function (res) {
                    //   _this.$emit("saved");
                    if (!isContinue) _this.base.navigateBack();
                    else {
                        _this.$refs["eagleUpload"].clear();
                        _this.getModel(_this.$route.query.id, this.taskCode);
                    }
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        back() {
            this.base.navigateBack();
        },
        initParams() {},
        showDangerType() {
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.model.hiddenCode = obj.dCode;
            this.model.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeCode = obj.dType;
            this.model.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.dangerTypeDialog = false;
        },
        show() {
            this.taskCode = this.$route.query.taskCode ?? "";
            this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
            this.projectId = this.$route.query.projectId ?? "";
            this.opType = parseInt(this.$route.query.opType);
            switch (this.opType) {
                case 1:
                    this.title = "隐患编辑";
                    break;
                case 3:
                    this.title = "随手拍";
                    break;
                case 4:
                    // this.tempModel = this.$route.query.lg;
                    this.title = "依据检查";
                    break;
            }

            uni.setNavigationBarTitle({ title: this.title });
            this.getModel(this.$route.query.id, this.taskCode);
        },
        setHiddenCode(taskCode) {
            if (taskCode) {
                let _this = this;
                this.common
                    .get("site/dangerCheckTask/getDataByCode/" + taskCode)
                    .then((res) => {
                        if (res.code == 200) {
                            let data = res.data;
                            // _this.isHost = data.companyCode != data.enterpriseCode && data.enterpriseCode;

                            // _this.isHost = !(
                            //     data.companyCode == data.enterpriseCode ||
                            //     !data.enterpriseCode
                            // );
                        }
                    });
            }
        },
        chooseDangerLg() {
            let _this = this;
            this.$bus.$off("chooseLg").$on("chooseLg", function (lgData) {
                _this.handlerSelectBase(lgData);
            });
            this.goChooseTemp();
        },
        goChooseTemp() {
            let linkUrl = this.common.getLinkUrl(
                "pages/support/libTempPublic/list",
                {
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                    taskCode: this.taskCode,
                    checkType: "base",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        getModel(id, taskCode) {
            var _this = this;
            _this.model.attachs = "";
            if (id && id > 0) {
                this.common
                    .get("site/dangerCheckTaskDetail/getData/" + id)
                    .then((res) => {
                        _this.model = res.data;
                        if (
                            _this.opType == 2 &&
                            (_this.model.self || _this.model.manager)
                        ) {
                            _this.model.pass = true;
                        }
                        if (_this.opType == 5) {
                            _this.model.pass = true;
                        }
                        _this.setHiddenCode(_this.model.mainCode);
                    });
            } else {
                //this.title = "随手拍";
                this.common
                    .get("site/dangerCheckTaskDetail/initData/0")
                    .then((res) => {
                        _this.model = res.data;
                        _this.model.originType = 1;
                        _this.model.mainCode = _this.taskCode;
                        _this.model.enterpriseCode = _this.enterpriseCode;
                        _this.model.projectId = _this.projectId;
                        _this.model.checkResult = "N";
                        _this.model.hiddenDangerTypeCode = "1";
                        _this.model.correctiveType = _this.model.correctiveType
                            ? _this.model.correctiveType
                            : 2;
                        if (!_this.isHost) {
                            _this.hdSetMeCorrective();
                        }
                        if (_this.opType == 4) {
                            //依据查
                            _this.model.originType = 2;
                            let lgStr = localStorage.getItem(
                                "choosedDangerLgWithLgCheck"
                            );
                            // console.log("lgStr", lgStr);

                            if (lgStr) {
                                let temp = JSON.parse(lgStr);
                                _this.handlerSelectImg(temp);
                            }
                            localStorage.removeItem(
                                "choosedDangerLgWithLgCheck"
                            );
                        }
                    });
            }
            if (taskCode && (!id || id == 0)) {
                this.setHiddenCode(taskCode);
            }
        },
        handlerSelectImg(obj) {
            this.model.correctiveAdvise = obj.base.correctiveAdvise;
            this.model.gistSource = obj.base.gistSource;
            this.model.originalText = obj.base.originalText;
            this.model.item = obj.item;
            this.model.lGCode = obj.base.lGCode;
            if (obj.item === "base-img") {
                this.model.attachs = obj.img;
            }
            if (obj.item === "base-img-danger") {
                this.model.attachs = obj.img.url;
                this.model.lGHDCode = obj.danger.lGHDCode;
                this.model.dFullName = obj.danger.dFullName;
                if (obj.danger.dFullName) {
                    this.model.hiddenCode = obj.danger.dCode;
                    this.model.hiddenName = obj.danger.dFullName.replace(
                        ">",
                        "-"
                    );
                    this.model.hiddenTypeName =
                        this.model.hiddenName.split("-")[0];
                    if (this.model.hiddenTypeName === "现场管理")
                        this.model.hiddenTypeCode = "2";
                    if (this.model.hiddenTypeName === "基础管理")
                        this.model.hiddenTypeCode = "1";
                }
                this.model.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                this.model.hiddenDangerTypeCode = obj.danger.hiddenDangerType;
                this.model.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                this.model.legalLiability = obj.danger.legalLiability;
            }
        },
    },
};
</script>
<style lang="scss" scoped>
.host-danger-danger-detail {
    .btn-span {
        .btn-dft {
            border-radius: 3px;
            display: inline-block;
            border: 1px solid #c8c9cc;
            background-color: #c8c9cc;
            padding: 5px;
            width: 200rpx;
            text-align: center;
            margin: 10rpx;
        }
        .btn-dft.pass {
            border: 1px solid #19be6b;
            color: #fff;
            background-color: #71d5a1;
        }
        .btn-dft.un-pass {
            border: 1px solid #fa3534;
            color: #fff;
            background-color: #dd6161;
        }
    }
}
</style>
