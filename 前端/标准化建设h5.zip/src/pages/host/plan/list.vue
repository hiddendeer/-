<template name="emergency-list">
    <view class="emergency-list eagle-layer">
        <view class="u-tabs-box">
            <u-tabs-swiper prop="dangerIndex" :bold="false" name="name" ref="tabs" :list="tabList" :current="tabContentIndex" @change="onTabChanged" :is-scroll="false" />
        </view>

        <planDocRiskList ref="planDocRiskList" v-if="tabName==0" />
        <sceneList ref="sceneList" v-if="tabName==1" />
        <planDocList ref="planDocList" v-if="tabName==2" />
        <!-- <planGoodsList ref="planGoodsList" v-if="tabName==3" /> -->
        <!-- <drillList ref="drillList" v-if="tabName==4" /> -->
        <!-- <eventList ref="eventList" v-if="tabName==5" /> -->

        <!--  <dangerPlanList ref="dangerTask" v-if="tabName==0"></dangerPlanList>
        <dangerDetailList ref="dangerList" key="dangerDetailList1" v-if="tabName==2" stype="1"></dangerDetailList>
        <dangerReportList ref="dangerReport" v-if="tabName==3"></dangerReportList>
        <dangerDetailList ref="myDangerList" key="dangerDetailList2" v-if="tabName==1&& (!projectId)" stype="2"></dangerDetailList>
		 -->

        <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
import planDocRiskList from "@/pages/host/plan/components/planDocRisk/list.vue";
// import drillList from "@/pages/host/plan/components/drill/list.vue";
// import eventList from "@/pages/host/plan/components/event/list.vue";
// import planGoodsList from "@/pages/host/plan/components/planGoods/list.vue";
import planDocList from "@/pages/host/plan/components/planDoc/list.vue";
import sceneList from "@/pages/host/plan/components/scene/list.vue";

// import dangerPlanList from "@/pages/host/danger/dangerPlan/index";
// import dangerDetailList from "@/pages/host/danger/dangerDetail/index";
// import dangerReportList from "@/pages/host/danger/dangerReport/index";
export default {
    components: {
        planDocRiskList,
        // drillList,
        // eventList,
        // planGoodsList,
        planDocList,
        sceneList,
        // dangerPlanList,
        // dangerDetailList,
        // dangerReportList,
        TabbarHost,
        TabbarSite,
    },
    data() {
        return {
            tabName: 0,
            tabList: [
                { name: "事故风险评估", code: 0 },
                { name: "现场处置措施", code: 1 },
                { name: "预案文件管理", code: 2 },
                // { name: "应急物资管理", code: 3 },
                // { name: "应急演练管理", code: 4 },
                // { name: "事故档案管理", code: 5 },
            ],

            tabIndex: 0,
            tabContentIndex: 0,
            pageNum: 1,
            pageSize: 20,
            queryParams: { enterpriseCode: "" },
            oldTabIndex: "",
            projectId: "",
            isMounted: false,
            model: {},
        };
    },
    mounted() {
        if (this.$route.query.tabContentIndex) {
            this.tabName = parseInt(this.$route.query.tabContentIndex);
            this.initCurrentPage();
        }
        this.searchPage();
        this.isMounted = true;
    },
    onShow() {
        if (this.isMounted) {
            this.searchPage();
        }
    },

    methods: {
        initCurrentPage() {
            for (var i = 0; i < this.tabList.length; i++) {
                if (this.tabList[i].code == this.tabName) {
                    this.tabContentIndex = i;
                }
            }
        },
        onTabChanged(index) {
            this.tabContentIndex = index;
            this.tabName = this.tabList[index].code;
            this.searchPage();
        },
        animationfinish(e) {
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
        },
        transition(e) {
            let dx = e.detail.dx;
            this.$refs.tabs.setDx(dx);
        },
        searchPage() {
            switch (this.tabName) {
                case 0:
                    setTimeout(() => {
                        this.$refs.planDocRiskList.search();
                    });
                    break;
                case 1:
                    setTimeout(() => {
                        this.$refs.sceneList.search();
                    });
                    break;
                case 2:
                    setTimeout(() => {
                        this.$refs.planDocList.search();
                    });
                    break;
                case 3:
                    setTimeout(() => {
                        this.$refs.planGoodsList.search();
                    });
                    break;
                case 4:
                    setTimeout(() => {
                        this.$refs.drillList.search();
                    });
                    break;
                case 5:
                    setTimeout(() => {
                        this.$refs.eventList.search();
                    });
                    break;
            }
        },
    },
};
</script>
<style lang="scss">
.emergency-list {
    /deep/.list-wrap {
        padding-top: 20rpx;
    }
}
</style>

