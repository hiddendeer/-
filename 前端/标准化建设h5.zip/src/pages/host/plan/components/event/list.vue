<template name="emergency-event-list">
    <!-- 事故记录 -->
    <view class="emergency-event-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :conditions="conditions" :bool-init-data="false"
            :pageSize="20" :controller="controller" :margin-bottom="38" @beforeLoad="beforeLoad" :showCheck="true"
            :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="conditions"
                        :searchResults="conditions.name.value">
                        <eagle-input v-model="conditions.name.value" title="事故名称" prop="name" />
                        <!-- <eagle-radio-group v-model="conditions.status.value" title="计划状态" prop="status" :data-source="params.status" /> -->
                        <eagle-select v-model="conditions.accidentType.value" title="事故类型" prop="finishDate" border
                            :height="70" :data-source="params.accidentType" labelWidth="150" />
                    </eagle-condition>
                </view>
            </view>

            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <eagle-row-view isTitle type="warn" maxWidth="250px">
                        {{ index + 1 }}. {{ item.name }}
                        <template slot="icon">
                            <span style="color:  red" v-if="item.accidentObj === 1">已完成</span>
                            <span style="color:yellow" v-if="item.accidentObj === 2">相关方</span>
                        </template>
                    </eagle-row-view>

                    <eagle-row-view>
                        <div>事故类型: {{ item.accidentType }} </div>
                        <div>事故日期: {{ item.accidentDate | dateFormat }}</div>
                    </eagle-row-view>

                    <eagle-row-view>
                        <div> 录入人: {{ item.createChnName }} </div>
                        <div> 录入日期: {{ item.createDate | dateFormat }} </div>
                    </eagle-row-view>

                    <template slot="button">
                        <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

    </view>
</template>

<script>
export default {
    data() {
        return {
            conditions: {
                name: {
                    value: "",
                    operate: "like",
                },
                accidentType: {
                    value: "",
                    operate: "=",
                },
            },
            controller: "site/accidentReport",
            dataType: "list",
            data: [],
            params: {
                accidentType: [],
                happenSide: [],
            },
        };
    },
    created() {
        this.initParams();
    },
    methods: {
        initParams() {
            var _this = this;
            if (
                !_this.params.accidentType ||
                _this.params.accidentType.length <= 0
            ) {
                _this.common
                    .getparamsList("accident_type,site_accident_happen_side")
                    .then(function (res) {
                        if (res.code == 200 && res.data) {
                            _this.params.accidentType = res.data.filter(
                                (p) => p.paramId == "accident_type"
                            );
                            _this.params.happenSide = res.data.filter(
                                (p) => p.paramId == "site_accident_happen_side"
                            );
                        }
                    });
            }
        },

        reSearch() {
            this.conditions.name.value = "";
            this.conditions.accidentType.value = "";
        },

        search() {
            this.$refs.eaglePageList.search();
        },
        _initList(list) {
            this.data = list;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
    },
};
</script>

<style lang="scss">
.emergency-event-list {}
</style>
