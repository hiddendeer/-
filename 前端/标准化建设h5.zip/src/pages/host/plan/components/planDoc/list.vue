<template name="emergency-planDoc-list">
    <!-- 应急预案文件管理 -->
    <view class="emergency-planDoc-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :conditions="conditions" :bool-init-data="false" :pageSize="20" :controller="controller" :margin-bottom="88" @beforeLoad="beforeLoad" :showCheck="true" :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="conditions" :searchResults="conditions.docName.value">
                        <eagle-input v-model="conditions.docName.value" title="预案名称" prop="docName" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.docType.value" title="文件类型" prop="docType" :data-source="params.docType" />

                    </eagle-condition>
                </view>
            </view>
            <!-- 	<view slot="search">
				<view class="search">
					<eagle-search @search="search" v-model="conditions.drillName.value" :show-action="false"
						@clear="search" />
				</view>
			</view> -->
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <template slot="tag">
                        <view> <span class="success"> {{ item.docTypeName }}</span></view>
                    </template>
                    <eagle-row-view isTitle type="warn">
                        {{ index + 1 }}. {{ item.docName }}
                    </eagle-row-view>
                    <eagle-row-view>
                        <div> 上传日期: {{ item.createDate | dateTimeFormat }} </div>
                        <div> 上传人: {{ item.createChnName }} </div>
                    </eagle-row-view>

                    <template slot="button">
                        <u-button type="success" size="mini" @click="hdView(item)">详情</u-button>
                        <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

    </view>
</template>

<script>
import eagleSelect from "../../../../../components/eagle-select/eagle-select.vue";
export default {
    components: { eagleSelect },
    data() {
        return {
            conditions: {
                docName: {
                    value: "",
                    operate: "like",
                },
                docType: {
                    value: "",
                    operate: "=",
                },
            },
            controller: "site/planDoc",
            dataType: "list",
            data: [],
            params: {
                docType: [
                    { id: "", name: "不限" },
                    { id: "1", name: "现场处置方案" },
                    { id: "2", name: "综合应急预案" },
                    { id: "3", name: "专项应急预案" },
                    { id: "4", name: "其他类型" },
                ],
            },
        };
    },
    created() {
        // this.initParams();
    },
    methods: {
        // initParams() {
        //     var _this = this;
        //     if (!_this.params.docType || _this.params.docType.length <= 0) {
        //         _this.common.getparamsList("disposal_doc_type").then(function (res) {
        //             if (res.code == 200 && res.data) {
        //                 _this.params.docType = res.data.filter(p => p.paramId == "disposal_doc_type");
        //             }
        //         });
        //     }
        // },

        reSearch() {
            this.conditions.docName.value = "";
            this.conditions.docType.value = "";
        },

        search() {
            this.$refs.eaglePageList.search();
        },
        _initList(list) {
            this.data = list;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdView(item) {
            if (item.attachs) {
                let attData = JSON.parse(item.attachs);
                if (attData && attData.length > 0) {
                    var url =
                        "/pages/common/pdfView?code=" + attData[0].attCode;
                    this.base.navigateTo(url);
                }
            }
        },
    },
};
</script>

<style lang="scss">
.emergency-planDoc-list {
}
</style>
