<template name="emergency-scene-list">
    <!-- 现场处置措施 -->
    <view class="emergency-scene-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :conditions="conditions" :bool-init-data="false" :pageSize="20" :controller="controller" :margin-bottom="88" @beforeLoad="beforeLoad" :showCheck="true">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.docName.value" :show-action="false" @clear="search" />
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ index + 1 }}. {{ item.docName }}
                    </eagle-row-view>
                    <eagle-row-view>
                        适用范围: {{ item.scopeOfApplication }}
                    </eagle-row-view>
                    <eagle-row-view>
                        <div>编辑人: {{ item.createChnName }}</div>
                        <div> 编辑时间: {{ item.createDate | dateFormat }}</div>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="success" size="mini" v-if="item.attachs" @click="hdView(item)">详情</u-button>
                        <u-button type="error" size="mini" @click="handlerDel(item)">删除</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

    </view>
</template>

<script>
export default {
    data() {
        return {
            conditions: {
                docName: {
                    value: "",
                    operate: "like",
                },
            },
            controller: "site/planDoc",
            // dataType: "disposalList",
            data: [],
        };
    },
    methods: {
        search() {
            let url = `${this.controller}/getPageData?dataType=disposalList`;
            this.$refs.eaglePageList.search({ url: url });
        },
        _initList(list) {
            this.data = list;
        },
        handlerDel(item) {
            let _this = this;
            let url = this.controller + "/getTobyId/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdView(item) {
            if (item.attachs) {
                let attData = JSON.parse(item.attachs);
                if (attData && attData.length > 0) {
                    var url =
                        "/pages/common/pdfView?code=" + attData[0].attCode;
                    this.base.navigateTo(url);
                }
            }
        },
    },
};
</script>

<style lang="scss">
.emergency-scene-list {
}
</style>
