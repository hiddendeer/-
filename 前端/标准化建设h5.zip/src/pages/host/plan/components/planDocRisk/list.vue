<template name="emergency-planDocRisk-list">
    <!-- 事故风险评估 -->
    <view class="emergency-planDocRisk-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :conditions="conditions" :bool-init-data="false"
            :pageSize="20" :controller="controller" :margin-bottom="88" @beforeLoad="beforeLoad" :showCheck="true"
            :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.riskName.value"
                        :show-action="false" @clear="clear"></eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <template slot="tag">
                        <view> <span
                                :class="{ 'A': item.evaluationValue.indexOf('A') == 0, 'B': item.evaluationValue.indexOf('B') == 0, 'C': item.evaluationValue.indexOf('C') == 0, 'D': item.evaluationValue.indexOf('D') == 0, 'E': item.evaluationValue.indexOf('E') == 0 }">
                                {{ item.evaluationName }}</span></view>
                    </template>
                    <eagle-row-view :isTitle="true" type="warn">
                        风险点: {{ item.riskName }}
                    </eagle-row-view>

                    <eagle-row-view>
                        事故类型: {{ item.accidentName }}
                    </eagle-row-view>
                    <!-- <eagle-row-view>
                        风险等级: {{item.evaluationName}}
                    </eagle-row-view> -->
                    <eagle-girdrow-base>
                        <!-- 评估方法: {{item.evaluationType?'直接判断':item.evaluationType}} -->
                        危险因素及后果: {{ item.dangerFactor }}
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>

    </view>
</template>

<script>
export default {
    data() {
        return {
            conditions: {
                riskName: {
                    value: "",
                    operate: "like",
                },
            },
            controller: "site/planDocRisk",
            dataType: "list",
            data: [],
        };
    },
    methods: {
        reSearch() {
            this.conditions.riskName.value = "";
        },
        search() {
            this.$refs.eaglePageList.search();
        },
        _initList(list) {
            this.data = list;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
    },
};
</script>

<style lang="scss">
.emergency-planDocRisk-list {
    /deep/.search {
        padding: 0;
        background-color: #f3f4f6;
    }

    .eagle-row-card .card-tag .A {
        background-color: #ff0000;
        color: #fff;
    }

    .eagle-row-card .card-tag .B {
        background-color: #ffc000;
        color: #fff;
    }

    .eagle-row-card .card-tag .C {
        background-color: #ffff00;
        color: #606266;
    }

    .eagle-row-card .card-tag .D {
        background-color: #00b0f0;
        color: #fff;
    }

    .eagle-row-card .card-tag .E {
        background-color: #00b0f0;
        color: #fff;
    }
}
</style>
