<template>
    <view>
        <eagle-form :control="control" v-model="model" ref="eagleForm" :boolInitData="false">
            <eagle-container>
                <eagle-input title="演练环节" v-model="model.step" prop="step" required></eagle-input>
                <eagle-input title="执行人" v-model="model.executor" prop="executor" required></eagle-input>
                <eagle-input type="textarea" title="演练内容" v-model="model.content" prop="content" required></eagle-input>
                <eagle-upload title="演练照片" v-model="model.attach" prop="attach"></eagle-upload>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="post">保存</u-button>
        </eagle-bottom-view>
    </view>
</template>
<script>
export default {
    data() {
        return {
            model: {
                problem: "",
                measures: "",
                mainCode: "",
                id: 0,
            },
            control: "site/planDrillRecordDts",
            urlParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
        };
    },
    computed: {},
    created() {
        this.model.id = this.$route.query.id ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
        this.urlParams.code = this.$route.query.code ?? "";
        this.getData();
    },
    onReady() {},
    mounted() {},
    methods: {
        bindData(data) {
            this.model = data;
        },
        getData() {
            let _this = this;
            if (this.model.id > 0) {
                let url = "site/planDrillRecordDts/getData/" + this.model.id;
                this.common.get(url, {}).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data ? res.data : {};
                    } else {
                        _this.$refs.eagleForm.errorMsg(
                            "获取数据失败:" + res.errMsg
                        );
                    }
                });
            } else {
                this.model.mainCode = this.urlParams.code;
            }
        },
        post(boolClose) {
            let _this = this;
            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    if (res.code == 200) {
                        if (boolClose) {
                            _this.close();
                        } else {
                            _this.model.problem = "";
                            _this.model.measures = "";
                            _this.model.id = 0;
                        }
                    }
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>
<style lang="scss">
</style>
