<template >
    <view class="plan-drillList">
        <eagle-container v-if="model.drillName"><span class="plan-title">{{ model.drillName }}</span></eagle-container>
        <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.attach" imgWidth="160rpx">
            <eagle-row-view isTitle><span>{{ item.orderNo }}.</span>{{ item.step }}</eagle-row-view>
            <eagle-girdrow-block>
                <!-- <view class="step"><span>{{item.orderNo}}.</span>{{item.step}}</view> -->
                <view class="content three-line">
                    <span v-html="item.content"></span>
                </view>
            </eagle-girdrow-block>
            <template slot="button" v-if="model.status == 10&&!mulitSave">
                <u-button type="primary" size="mini" @click="handlerEdit(item)">编辑</u-button>
            </template>
        </eagle-row-card>
        <view v-if="mulitSave" style="height:80rpx;"></view>
        <eagle-bottom-view v-if="mulitSave">
            <u-button class="bottom-btn" type="primary" @click="post">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    data() {
        return {
            dataType: "list",
            list: [],
            model: {
                drillName: "",
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
                planCode: "",
            },
            mulitSave: false,
            storageData: [],
        };
    },
    onShow() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.queryParams.code = this.$route.query.code ?? "";
        this.queryParams.planCode = this.$route.query.planCode ?? "";
        this.drillName = this.$route.query.drillName ?? "";

        //从缓存中取出连拍信息（图片）
        let data = uni.getStorageSync("planDrillRecordDts");
        this.storageData = data;
        this.search();
        this.getRecord();
    },
    methods: {
        bindTag(val) {
            let obj = this.params.status.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        search() {
            let url = "site/planDrillRecordDts/getPhoneDataListByMainCode";
            let _this = this;
            this.common
                .get(url, { mainCode: this.queryParams.code })
                .then((res) => {
                    if (res.code == 200) {
                        _this.list = res.data;
                        if (_this.storageData && _this.storageData.length > 0) {
                            for (var i = 0; i < _this.list.length; i++) {
                                //如果缓存中有数据代表是管管打开随手拍连拍，将连拍的图片分别映射到attach上。
                                let mapModel = _this.storageData.filter(
                                    function (currentValue) {
                                        if (
                                            currentValue.ID == _this.list[i].id
                                        ) {
                                            return currentValue;
                                        }
                                    }
                                );
                                if (
                                    mapModel &&
                                    mapModel.length > 0 &&
                                    mapModel[0].Attachs
                                ) {
                                    console.log("Attachs");
                                    _this.mulitSave = true;
                                    _this.list[i].attach = mapModel[0].Attachs;
                                }
                            }
                            uni.removeStorageSync("planDrillRecordDts");
                            _this.post();
                        }
                    }
                });
        },
        getRecord() {
            let url =
                "site/planDrillRecord/getPhoneDataByCode?code=" +
                this.queryParams.planCode;
            let _this = this;
            this.common
                .get(url, { companyCode: this.queryParams.enterpriseCode })
                .then((res) => {
                    if (res.code == 200) {
                        if (res.data) {
                            _this.model = res.data;
                        }
                    }
                });
        },
        handlerEdit(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/drill/drillDetail",
                {
                    id: item.id,
                    projectId: this.queryParams.projectId ?? "",
                    enterpriseCode: this.queryParams.enterpriseCode ?? "",
                    code: this.queryParams.code,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        post() {
            let url = "site/planDrillRecordDts/updatePhoneDataList";
            this.common.post(url, this.list).then((res) => {
                if (res.code == 200) {
                    // this.$refs.uToast.show({
                    //     title: "保存成功",
                    //     type: "success",
                    //     callback: function () {},
                    // });
                    this.mulitSave = false;
                }
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.plan-drillList {
    .step {
        width: 160rpx;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        margin: auto;
        height: 100%;
        color: #333;
        font-weight: 600;
    }

    .content {
        flex: 1;
        white-space: pre-line;
    }

    .plan-title {
        font-size: 16px;
        padding: 5px 10px;
    }
}
</style>
