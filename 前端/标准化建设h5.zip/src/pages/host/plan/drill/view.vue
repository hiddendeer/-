<template>
    <view class="drill-view-container" style="margin-top:10px;">
        <eagle-form @initCallBack="initCallBack" detailUrl="site/planDrillRecord/getPhoneDataByCode" :boolInitData="false" :control="control" v-model="model" ref="eagleForm">
            <eagle-container v-if="model.status == 10" title="演练信息">
                <eagle-input required title="演练名称" v-model="model.drillName" prop="drillName"></eagle-input>
                <!-- <eagle-date type="month" required title="计划月份" v-model="model.planDate" prop="planDate"></eagle-date> -->
                <!-- <eagle-year-month required title="计划月份" v-model="model.planDate"></eagle-year-month> -->
                <eagle-month title="计划月份" v-model="model.planDate"></eagle-month>
                <eagle-input required title="演练范围" type="textarea" v-model="model.scopeOfApplication" prop="scopeOfApplication"></eagle-input>
                <eagle-date required title="演练日期" v-model="model.drillDate" prop="drillDate"></eagle-date>
                <eagle-input required title="演练场景" v-model="model.scene" prop="scene" type="textarea"></eagle-input>
            </eagle-container>
            <eagle-container v-if="model.status == 20" title="演练信息">
                <eagle-text title="演练名称" v-model="model.drillName" prop="drillName"></eagle-text>
                <eagle-text title="计划月份" :v-bind="model.planDate" prop="planDate">
                    {{ model.planDate | dateFormat }}
                </eagle-text>
                <eagle-text title="演练范围" v-model="model.scopeOfApplication" prop="scopeOfApplication" labelWidth="75px" class="eagle-flex"></eagle-text>
                <eagle-text title="演练日期" :v-bind="model.drillDate" prop="drillDate">
                    {{ model.drillDate | dateFormat }}
                </eagle-text>
                <eagle-text title="演练场景" v-model="model.scene" prop="scene"></eagle-text>
            </eagle-container>
            <eagle-container title="演练现场信息" v-if="model.status > 0">
                <eagle-text v-if="model.drillScript" title="演练脚本" key="drillScript" labelWidth="75px" class="eagle-flex">
                    <eagle-grid-attach title="" v-model="model.drillScript"></eagle-grid-attach>
                </eagle-text>
                <eagle-text title="演练记录" v-if="model.recordAttachs" key="recordAttachs" labelWidth="75px" class="eagle-flex">
                    <eagle-grid-attach title="" v-model="model.recordAttachs"></eagle-grid-attach>
                    <!-- <eagle-grid-attach title="" v-model="model.docAttach"></eagle-grid-attach> -->
                </eagle-text>
                <eagle-text title="演练过程记录" key="hdDillList">
                    <span class="eagle-blue" @click="hdDillList">
                        共 {{ model.dtsCount }} 项
                    </span>
                </eagle-text>
                <eagle-text title="演练发现项" key="hdFindList">
                    <span class="eagle-blue" @click="hdFindList">
                        共 {{ model.dtsCount2 }} 项
                    </span>
                </eagle-text>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button v-if="model.status == 10" type="primary" class="bottom-btn" @click="post(false)">保存演练信息</u-button>
            <!-- <u-button v-if="model.status==10" type="primary" class="bottom-btn" @click="hdDillList()">开始演练</u-button> -->
            <u-button v-if="model.status == 10" type="error" class="bottom-btn" @click="post(true)">结束演练</u-button>
            <u-button v-if="model.status == 10&&!(env=='testAfx'||env=='afx')" type="primary" class="bottom-btn" @click="getPhoneData()">
                开始演练
            </u-button>
            <u-button v-if="model.status == 20" type="primary" class="bottom-btn" @click="close">返回</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
import eagleYearMonth from "@/components/eagle-date/eagle-year-month";
export default {
    components: {
        eagleYearMonth,
    },
    data() {
        return {
            model: {
                status: 0,
            },
            control: "site/planDrillPlan",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
            env: "",
        };
    },
    created() {
        this.env = process.env.VUE_APP_ENV;
        this.queryParams.code = this.$route.query.code ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
    },
    mounted() {},
    onShow() {
        if (this.$route.query.code) {
            this.queryParams.code = this.$route.query.code ?? "";
        }
        this.show();
    },
    methods: {
        show() {
            let params = {
                code: this.queryParams.code,
            };
            setTimeout(() => {
                this.$refs.eagleForm.get("view", params);
            });
        },
        initCallBack(data) {
            this.model = data;
        },
        close() {
            this.base.navigateBack();
        },
        hdDillList() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/drill/drillList",
                {
                    enterpriseCode: this.queryParams.enterpriseCode,
                    projectId: this.queryParams.projectId,
                    code: this.model.code,
                    planCode: this.queryParams.code,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdFindList() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/drill/findList",
                {
                    enterpriseCode: this.queryParams.enterpriseCode,
                    projectId: this.queryParams.projectId,
                    code: this.model.code,
                    planCode: this.queryParams.code,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        post(finish) {
            let url = "site/planDrillRecord/savePhoneData";
            if (finish == true) {
                url = url + "?isFinish=t";
            }
            let _this = this;
            this.$refs.eagleForm.post({
                url: url,
                successCallback: function (res) {
                    _this.show();
                },
            });
            // this.common.post(url, this.model).then(function (res) {
            //     if (res.code == 200) {
            //         _this.$refs.eagleForm.successMsg("保存成功");
            //         _this.show();
            //     }
            // });
        },

        // http://localhost:1024/api/site/planDrillRecordDts/getPhoneDataListByMainCode?mainCode=ea5267473a8a4a869241efef443a35b2

        getPhoneData() {
            let url =
                "site/planDrillRecordDts/getPhoneDataListByMainCode?mainCode=" +
                this.model.code;
            let _this = this;

            uni.showToast({
                icon: "loading",
            });
            let arr = [];

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        arr.push({
                            Name: item.step,
                            ID: item.id,
                            Attach: item.attach,
                        });
                    }

                    if (arr.length > 0) {
                        _this.eagleClick(arr);
                    }
                } else {
                }
                uni.hideToast();
            });
        },
		
		continuousShootingResult(dataStr){
			console.log("continuousShootingResult",dataStr);
			
			let data5 = this.$u.test.jsonString(dataStr)
			    ? JSON.parse(dataStr)
			    : dataStr;
							
			uni.setStorageSync("planDrillRecordDts", data5);
			let linkUrl = this.common.getLinkUrl(
			    "pages/host/plan/drill/drillList",
			    {
			        enterpriseCode: this.queryParams.enterpriseCode,
			        projectId: this.queryParams.projectId,
			        code: this.model.code,
			        planCode: this.queryParams.code,
			    }
			);
			this.base.navigateTo(linkUrl);
		},

        eagleClick(arr) {
            var token = uni.getStorageSync("token");
			
            var url = process.env.VUE_APP_UPLOAD_FILE_URL;
            var Params = {
                name: "PlanGetPhoto",
                maxCount: 9,
                Authorization: "Bearer " + token,
                url: url,
                isNoData: false,
                title: "",
                AttArr: arr,
            };

            uni.removeStorageSync("planDrillRecordDts");

            console.log("Params: ", Params);
			
			var userAgent = navigator.userAgent;
			if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
				serve.eagleModule(Params).then((res) => {
				    let data5 = this.$u.test.jsonString(res.data)
				        ? JSON.parse(res.data)
				        : res.data;
				    uni.setStorageSync("planDrillRecordDts", data5);
				    let linkUrl = this.common.getLinkUrl(
				        "pages/host/plan/drill/drillList",
				        {
				            enterpriseCode: this.queryParams.enterpriseCode,
				            projectId: this.queryParams.projectId,
				            code: this.model.code,
				            planCode: this.queryParams.code,
				        }
				    );
				    this.base.navigateTo(linkUrl);
				});
			}else if (this.base.isWeixin()) {
				
			} else if (window.jsListener) { // 安卓
			// 	isNext = false;
			// 	window.getPicturePathResult = this.getPicturePathResult;
			
			// 	window.jsListener.getPicture(newMaxCount, this.isNeedEdit,true);
			
			} else {
				if (window.webkit) { //iOS
					if (window.webkit.messageHandlers) {
						
						if (window.webkit.messageHandlers.continuousShooting) {
							window.continuousShootingResult = this.continuousShootingResult;
							
							
							window.webkit.messageHandlers.continuousShooting.postMessage(Params);
							
							
							
							// window.webkit.messageHandlers.getPicture.postMessage({ num: newMaxCount, isEdit: this.isNeedEdit ,isBase64:true});
						}
					}
				}
			}
			
			
            
        },

        // endPlan() {
        //     let url = "site/planDrillRecord/endDrill";
        //     let _this = this;
        //     this.$refs.eagleForm.validata(function () {
        //         _this.common
        //             .get(url, { code: _this.model.code })
        //             .then(function (res) {
        //                 if (res.code == 200) {
        //                     _this.$refs.eagleForm.successMsg("提交成功");
        //                     _this.show();
        //                 }
        //             });
        //     });
        // },
    },
};
</script>

<style lang="scss" scoped>
.drill-view-container {
    /* padding: 15rpx; */
    box-sizing: border-box;
    overflow: hidden;
    height: 100%;
}
</style>
