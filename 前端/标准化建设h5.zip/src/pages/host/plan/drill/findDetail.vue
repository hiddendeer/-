<template>
    <view>
        <eagle-form :control="control" v-model="model" ref="eagleForm" :boolInitData="false">
            <eagle-container>
                <eagle-input title="问题描述" required type="textarea" v-model="model.problem" prop="problem"></eagle-input>
                <eagle-input title="整改措施" required type="textarea" v-model="model.measures" prop="measures"></eagle-input>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="post(true)">保存并返回</u-button>
            <u-button class="bottom-btn" type="primary" @click="post(false)">保存并继续</u-button>
        </eagle-bottom-view>
    </view>
</template>
<script>
export default {
    data() {
        return {
            model: {
                problem: "",
                measures: "",
                mainCode: "",
                id: 0,
            },
            control: "site/planDrillRecordDts2",
            urlParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
        };
    },
    computed: {},
    created() {
        this.model.id = this.$route.query.id ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
        this.urlParams.code = this.$route.query.code ?? "";
        this.getData();
    },
    onReady() {},
    mounted() {},
    methods: {
        bindData(data) {
            this.model = data;
        },
        getData() {
            if (this.model.id > 0) {
                let _this = this;
                let url = "site/planDrillRecordDts2/getData/" + this.model.id;
                this.common.get(url, {}).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data ? res.data : {};
                    } else {
                        _this.$refs.eagleForm.errorMsg(
                            "获取数据失败:" + res.errMsg
                        );
                    }
                });
            } else {
                this.model.mainCode = this.urlParams.code;
            }
        },
        post(boolClose) {
            let _this = this;
            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    if (res.code == 200) {
                        if (boolClose) {
                            _this.close();
                        } else {
                            _this.model.problem = "";
                            _this.model.measures = "";
                            _this.model.id = 0;
                        }
                    }
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>
<style lang="scss">
</style>
