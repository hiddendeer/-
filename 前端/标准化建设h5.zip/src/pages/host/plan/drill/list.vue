<template name="emergency-drill-list">
    <!-- 应急演练管理 -->
    <view class="emergency-drill-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :conditions="conditions" :controller="controller" :margin-bottom="20" :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="conditions" :searchResults="conditions.drillName.value">
                        <eagle-input v-model="conditions.drillName.value" title="演练名称" prop="drillName" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" title="计划状态" prop="status" :data-source="params.status" />
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdView(item)">
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-row-view isTitle type="warn">
                        {{ item.drillName || item.drillName }}
                    </eagle-row-view>
                    <eagle-row-view v-if="item.status < 20 || !item.finishDate">
                        计划时间: {{ item.planDate | dateFormat }}
                    </eagle-row-view>
                    <eagle-row-view v-else>
                        演练时间: {{ item.drillDate | dateFormat }}
                    </eagle-row-view>
                    <eagle-row-view>
                        演练范围: {{ item.scopeOfApplication }}
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button>
                        <u-button type="success" size="mini" v-if="item.status == 20" @click="hdView(item)"> 详情
                        </u-button>
                        <u-button type="success" size="mini" v-if="item.status == 10" @click="hdView(item)">实施
                        </u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
    </view>
</template>

<script>
export default {
    data() {
        return {
            conditions: {
                drillName: {
                    value: "",
                    operate: "like",
                },
                status: {
                    value: "",
                    operate: "=",
                },
                finishDate: {
                    value: "",
                    operate: "=",
                },
            },
            controller: "site/planDrillPlan",
            dataType: "list",
            data: [],
            params: {
                status: [
                    {
                        id: "",
                        name: "全部",
                        type: "primary",
                    },
                    {
                        id: "10",
                        name: "进行中",
                        type: "primary",
                    },
                    {
                        id: "20",
                        name: "已完成",
                        type: "success",
                    },
                ],
                years: [],
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    onShow() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.search();
    },
    methods: {
        bindTag(val) {
            let obj = this.params.status.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        reSearch() {
            this.conditions.drillName.value = "";
            this.conditions.status.value = "";
            this.conditions.finishDate.value = "";
        },
        // getDate(e) {
        //     let date = new Date();
        //     if (e) {
        //         date = new Date(e);
        //     }
        //     let a = date.getFullYear();
        //     let b = date.getMonth() + 1;
        //     if (b < 10) {
        //         b = "0" + b;
        //     }
        //     return a + "-" + b;
        // },
        search() {
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        _initList(list) {
            this.data = list;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdView(item) {
            let linkUrl = this.common.getLinkUrl("pages/host/plan/drill/view", {
                id: item.id,
                enterpriseCode: this.queryParams.enterpriseCode,
                projectId: this.queryParams.projectId,
                code: item.code,
            });
            this.base.navigateTo(linkUrl);
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/drill/detail",
                {
                    id: 0,
                    projectId: this.queryParams.projectId,
                    enterpriseCode: this.queryParams.enterpriseCode,
                }
            );
            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style lang="scss">
.emergency-drill-list {
}
</style>
