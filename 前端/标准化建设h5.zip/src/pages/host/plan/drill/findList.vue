<template >
    <view class="plan-findList">
        <eagle-container v-if="model.drillName"><span class="plan-title">{{ model.drillName }}</span></eagle-container>
        <view v-if="list && list.length > 0">
            <eagle-row-card v-for="(item, index) in list" :key="index">
                <eagle-row-view :isTitle="true" type="warn">
                    问题描述：{{ item.problem }}
                </eagle-row-view>
                <eagle-row-view>
                    整改措施：{{ item.measures }}
                </eagle-row-view>
                <template slot="button" v-if="model.status == 10">
                    <u-button type="error" size="mini" @click="handlerDel(item)">删除</u-button>
                    <u-button type="primary" size="mini" @click="handlerEdit(item)">编辑</u-button>
                </template>
            </eagle-row-card>
        </view>
        <eagle-container v-else>
            <u-empty class="eagle-page-empty" style="height:150px;" text="暂无数据">
            </u-empty>
        </eagle-container>
        <eagle-fab v-if="model.status == 10" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="close">返回</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    data() {
        return {
            dataType: "list",
            list: [],
            model: {
                drillName: "",
            },

            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
        };
    },
    onShow() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.queryParams.code = this.$route.query.code ?? "";
        this.queryParams.planCode = this.$route.query.planCode ?? "";
        this.search();
        this.getRecord();
    },
    methods: {
        bindTag(val) {
            let obj = this.params.status.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        search() {
            let url = "site/planDrillRecordDts2/getPhoneDataListByMainCode";
            let _this = this;
            this.common
                .get(url, { mainCode: this.queryParams.code })
                .then((res) => {
                    if (res.code == 200) {
                        _this.list = res.data;
                    }
                });
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/drill/findDetail",
                {
                    id: 0,
                    projectId: this.queryParams.projectId ?? "",
                    enterpriseCode: this.queryParams.enterpriseCode ?? "",
                    code: this.queryParams.code,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        getRecord() {
            let url =
                "site/planDrillRecord/getPhoneDataByCode?code=" +
                this.queryParams.planCode;
            let _this = this;
            this.common
                .get(url, { companyCode: this.queryParams.enterpriseCode })
                .then((res) => {
                    if (res.code == 200) {
                        if (res.data) {
                            // _this.drillName = res.data.drillName;
                            _this.model = res.data;
                        }
                    }
                });
        },
        close() {
            this.base.navigateBack();
        },
        handlerDel(val) {
            let _this = this;
            let url = "site/planDrillRecordDts2/delete/" + val.id;
            this.common.del(url, {}).then(function (res) {
                if (res.code == 200) {
                    _this.$refs.uToast.show({
                        title: "删除成功",
                        type: "success",
                        callback: function () {},
                    });
                    _this.search();
                } else {
                    _this.$refs.uToast.show({
                        title: "删除失败：" + res.errorText,
                        type: "error",
                        callback: function () {},
                    });
                }
                uni.hideToast();
            });
        },
        handlerEdit(val) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/drill/findDetail",
                {
                    id: val.id,
                    projectId: this.queryParams.projectId,
                    enterpriseCode: this.queryParams.enterpriseCode,
                }
            );

            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style lang="scss" scoped>
.plan-findList {
    .plan-title {
        font-size: 16px;
        padding: 5px 10px;
    }
}
</style>
