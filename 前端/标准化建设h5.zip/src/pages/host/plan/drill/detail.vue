<template>
    <view>

        <eagle-form :control="control" v-model="model" ref="eagleForm" :boolInitData="false">
            <eagle-container>
                <eagle-window-choose title="现场处置措施"  headTitle="请选择现场处置措施" v-model="model.docCode" :isMult="false" :names.sync="model.drillNameShow" :queryParams="queryParams" controller="site/planDoc" dataType="reserveList" idField="code" textField="docName" @callBackChoosedData="callBack"></eagle-window-choose>
                <eagle-input title="演练名称" v-model="model.drillName" prop="drillName" required></eagle-input>
                <eagle-radio-group title="是否设置综合演练环境" prop="needMultiple" :data-source="params.needMultipleArry" v-model="model.needMultiple" required></eagle-radio-group>
                <eagle-month title="计划时间" prop="planDate" v-model="model.planDate" required></eagle-month>
                <eagle-input type="textarea" title="演练范围" v-model="model.scopeOfApplication" prop="scopeOfApplication" required></eagle-input>
            </eagle-container>
            <!-- <eagle-container title="演练文件">
                <eagle-text title="预案文件">
                    <eagle-file-upload disabled v-model="model.docAttach"></eagle-file-upload>
                </eagle-text>
                <eagle-text title="演练方案与脚本">
                    <eagle-file-upload disabled v-model="model.drillScript"></eagle-file-upload>
                </eagle-text>
            </eagle-container> -->
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" position='top' />
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {
                needMultiple: "0",
                drillNameShow: "",
            },
            control: "site/planDrillPlan/planDrillPlanSave",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            params: {
                needMultipleArry: [
                    { id: "0", name: "否" },
                    { id: "1", name: "是" },
                ],
            },
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
    },
    methods: {
        callBack(data) {
            if (data && data.length > 0) {
                this.model.scopeOfApplication = data[0].scopeOfApplication;
                this.model.drillName = data[0].docName;
            }
        },
        post() {
            let _this = this;
            let postModel = [];
            if (this.queryParams.enterpriseCode) {
                this.model.companyCode = this.queryParams.enterpriseCode;
            }
            postModel.push(this.model);
            this.$refs.eagleForm.post({
                needValid: true,
                url: "site/planDrillPlan/planDrillPlanSave",
                model: postModel,
                successCallback: (res) => {
                    _this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style>
</style>
