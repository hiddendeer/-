<template name="emergency-planGoods-list">
    <!-- 事故记录 -->
    <view class="emergency-planGoods-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :conditions="conditions" :bool-init-data="false" :pageSize="20" :controller="controller" :margin-bottom="45" @beforeLoad="beforeLoad" :showCheck="true" :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="conditions" :searchResults="conditions.name.value">
                        <eagle-input v-model="conditions.name.value" title="应急物资名称" prop="name" />
                        <eagle-input v-model="conditions.area.value" title="存储位置" prop="area" />

                    </eagle-condition>
                </view>
            </view>

            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <eagle-row-view isTitle type="warn" maxWidth="250px">
                        {{ index + 1 }}. {{ item.name }}

                    </eagle-row-view>
                    <eagle-row-view>
                        <div>储物位置: {{ item.area }} </div>
                        <div>数量: {{ item.cnt }}</div>
                    </eagle-row-view>

                    <eagle-row-view>
                        <div> 录入人: {{ item.createChnName }} </div>
                        <div> 录入日期: {{ item.createDate | dateFormat }} </div>
                    </eagle-row-view>

                    <template slot="button">
                        <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button>
                        <u-button type="primary" size="mini" @click="handlerEdit(item)">编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
    </view>
</template>

<script>
export default {
    data() {
        return {
            conditions: {
                name: {
                    value: "",
                    operate: "like",
                },
                area: {
                    value: "",
                },
            },
            controller: "site/planGoods",
            dataType: "list",
            data: [],
        };
    },
    onShow() {
        this.search();
    },
    methods: {
        reSearch() {
            this.conditions.name.value = "";
            this.conditions.area.value = "";
        },

        search() {
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        _initList(list) {
            this.data = list;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        handlerEdit(val) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/planGoods/detail",
                {
                    id: val.id,
                    code: val.code,
                    projectId: this.$route.query.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/plan/planGoods/detail",
                {
                    id: 0,
                    projectId: this.$route.query.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style lang="scss">
.emergency-planGoods-list {
}
</style>
