<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' labelAlign='left' initUrl="site/planGoods/initData/0">
            <eagle-container>
                <eagle-input title="应急物资名称" v-model.trim="model.name" required prop="name"></eagle-input>
                <eagle-input title="存储位置" v-model="model.area" prop="area"></eagle-input>
                <eagle-input title="数量" v-model.trim="model.cnt" required prop="cnt"></eagle-input>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view v-if="look">
            <u-button class="bottom-btn" type="primary" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" position='top' />
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            control: "site/planGoods",
            type: "",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            deletable: true,
            look: true,
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        if (this.$route.query.id !== "0") {
            uni.setNavigationBarTitle({ title: "编辑应急物资" });
        }
    },
    methods: {
        initCallBack(data) {
            this.model = {};
            this.model = data;
        },
        post() {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    _this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style>
</style>
