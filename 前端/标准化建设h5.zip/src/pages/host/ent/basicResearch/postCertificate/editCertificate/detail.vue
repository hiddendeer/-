<template>
  <view class="formInfo">
    <eagle-form @initCallBack="initCallBack"  :control="control" v-model="model" ref="eagleForm" :errorType="errorType">
      <!-- <view class="peoInfo">
          人员信息
      </view> -->
      <eagle-container>
        <eagle-input v-model="model.certificateName" required title="证书名称" prop="certificateName"
                     labelPosition="left"  labelWidth="180">
        </eagle-input>
        <eagle-date type="daterange" :startDate.sync="model.certificateValidityDateStart" :endDate.sync="model.certificateValidityDate"
                  @change="changeDateRange"  labelPosition="left"  labelWidth="180" title="证书有效期" prop="certificateValidityDateRangeList"
                    :height="70" required ></eagle-date>
        <!--  <eagle-date
              v-model="model.certificateFirstGetDate"
              required
              title="证书初领日期"
              prop="certificateFirstGetDate"
              labelPosition="left"  labelWidth="180"
          ></eagle-date> -->
          <u-form-item label="证书类型" ref="uFormItem" class="eagle-input eagle-form-item eagle-input-form-item" label-position="left" required  prop="certificateType" label-width="180">
            <eagle-arrow-input class="cert-input" prop="eagle-arrow-input" v-model="model.certificateTypeName" :disabled="false" placeholder="请选择证书类型"  @click="showSelect=true"></eagle-arrow-input>
          </u-form-item>
          <eagle-input v-model="model.name" required title="姓名" prop="name" labelPosition="left"  labelWidth="180">
          </eagle-input>
          <!-- <eagle-input v-model="model.postName" title="岗位" prop="postName" labelPosition="left"  labelWidth="180">
          </eagle-input> -->
        <!-- <eagle-input v-model="model.organName" title="部门" prop="organName" labelPosition="left"  labelWidth="180">
        </eagle-input> -->

        <!-- <eagle-input
            v-model="model.remarks"
            title="备注"
            prop="remarks"
            type="textarea"
            labelPosition="left"  labelWidth="180"
        >
        </eagle-input> -->
        <eagle-upload
            title="证书照片"
            :maxCount="3"
            prop="attachs"
            required
            v-model="model.attachs"
            labelPosition="left"  labelWidth="180"
            @uploadSuccess="uploadSuccess"
        />
      </eagle-container>

      <!--            <view class="peoInfo">-->
      <!--                <view>*</view>-->
      <!--                证书信息-->
      <!--            </view>-->
      <!--            <eagle-page-list ref="eaglePageList" :boolInitData="false" :marginBottom="0" :cutHeight="440" :showPages="false" @initList="initList" :pageSize="20" :margin-bottom="0" :showCheck="true" searchDisplay="none" @beforeLoad="beforeLoad">-->
      <!--                <template slot="list">-->
      <!--                    <eagle-container>-->
      <!--                        <u-empty class="eagle-page-empty" v-if="!model.details || model.details.length == 0" style="height:150px;" text="暂无数据">-->
      <!--                        </u-empty>-->
      <!--                        <view class="list-wrap">-->
      <!--                            <eagle-row-card v-for="(item, index) in model.details" :key="index" :hasImg="true" :imgSrc="item.attachsStr">-->
      <!--                                <eagle-row-view :isTitle="true" type="warn">-->
      <!--                                    {{ item.certificateName }}-->
      <!--                                </eagle-row-view>-->
      <!--                                <eagle-row-view :spaceBetween="false">-->
      <!--                                    证书有效日期:{{ item.certificateValidityDate | dateFormat }}-->
      <!--                                </eagle-row-view>-->
      <!--                                <eagle-row-view>-->
      <!--                                    <u-tag :text="getSuplusDate(item)" size="mini" :type="item.tags" />-->
      <!--                                </eagle-row-view>-->
      <!--                                <template slot="button">-->
      <!--                                    <u-button type="error" size="mini" @click="deleteContract(item, index)">删除-->
      <!--                                    </u-button>-->
      <!--                                    <u-button type="primary" size="mini" @click="handlerEdit(index)">编辑</u-button>-->
      <!--                                </template>-->
      <!--                            </eagle-row-card>-->
      <!--                        </view>-->
      <!--                    </eagle-container>-->
      <!--                </template>-->
      <!--            </eagle-page-list>-->

    </eagle-form>
    <!--        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>-->
    <eagle-bottom-view>
      <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
    </eagle-bottom-view>
    <!-- 对话框 -->
    <u-popup mode="bottom" v-model="isShow" :mask-close-able="false">
      <view class="content">
        <scroll-view scroll-y="true" style="height:100vh;">
          <view>
            <addList :isEditor.sync="isEditor" @showstrr='showstrr' :isShow.sync='isShow'
                     :listData="listData"></addList>
          </view>
        </scroll-view>
      </view>
    </u-popup>
    <!-- 预览图片 -->
    <u-mask :show="show" @click="show = false">
      <view class="warp">
        <view class="rect" @tap.stop>
          <image :src="noImgUrl" mode="aspectFill"></image>
        </view>
      </view>
    </u-mask>
    <u-toast ref="uToast"/>

    <u-select value-name="id" label-name="name" v-model="showSelect" mode="single-column" :list="allList" @confirm="confirm"></u-select>
  </view>
</template>

<script>
import addList from "../editInformation/view.vue";
import fastChooseCert from "@/pages/host/ent/basicResearch/postCertificate/components/fast-choose-cert.vue";

export default {
  components: {fastChooseCert, addList},
  data() {
    return {
      noImgUrl: require("@/static/img/no-img.png"),
      listData: {
        certificateName: "",
        certificateValidityDate: "",
        postRemarks: "",
        attachs: "",
        attachsStr: "",
      },
      model: {},
      color: "#ffffff",
      show: false,
      isShow: false,
      isEditor: false,
      control: "site/entPostCertificate",
      errorType: ["message"],
      allList:[],
      showSelect: false,
    };
  },
  created() {
    let _this = this;
    _this.initParams();
  },
  mounted() {
    // this.initParams.name = this.$route.query.name;
    // let _this = this;
    //
    // let url = _this.control + "/initData/0";
    // let params = {};
    // if (this.$route.query.enterpriseCode) {
    //   params.companyCode = this.$route.query.enterpriseCode;
    // }
    // this.common.get(url, params).then(function (res) {
    //   if (res.code === 200) {
    //     _this.model.companyCode = res.data.companyCode;
    //   } else {
    //   }
    //   uni.hideToast();
    // });
  },
  methods: {
    changeDateRange(e){
      console.log(e,'日期格式')
      this.model.certificateValidityDateRangeList=e;
    },
    confirm(e) {
      console.log(e);
      this.model.certificateType=e[0].value;
      this.model.certificateTypeName=e[0].label;
    },
    initParams() {
      var _this = this;
      this.common
          .getparamsList("cert_type")
          .then(function (res) {
            if (res.code == 200 && res.data) {
              let arr =['主要负责人证书','安全管理员证书','特种设备作业证', '特种设备安全管理员证','其他']
              let filteredData = res.data.filter(item => arr.includes(item.name));
              console.log(filteredData);
              // _this.allList = res.data;
              _this.allList = filteredData
            }
          });
    },
    initCallBack(data) {
      this.allList.forEach(it=>{
        if(it.id==data.certificateType){
          this.model.certificateTypeName=it.name;
        }
      })
      this.model.certificateValidityDateStart = Date.parse(this.formatDate(data.certificateValidityDateRangeList[0], "yyyy-MM-dd"));
      this.model.certificateValidityDate = Date.parse(this.formatDate(data.certificateValidityDateRangeList[1], "yyyy-MM-dd"));
      // this.model.certificateTypeName=data.value;
    },
    handlerFabClick() {
      this.isShow = true;
    },
    handlerEdit(index) {
      this.isShow = true;
      this.isEditor = true;
      console.log(index);
      this.listData = this.model.details[index];
    },
    handlerBodyClick() {
      console.log(2);
    },

    doPreviewImage(item) {
      var _this = this;
      var srcArray = [];
      if (item.attachs) {
        srcArray = item.attachs.split(";");
      } else {
        srcArray = [this.noImgUrl];
      }

      //this.lists.map(item => item.url || item.path);
      uni.previewImage({
        urls: srcArray,
        current: srcArray[0],
        success: () => {
          _this.$emit("on-preview", srcArray[0], srcArray, 0);
        },
        fail: () => {
          uni.showToast({
            title: "预览图片失败",
            icon: "none",
          });
        },
      });
    },

    post(op) {
      let _this = this;

        this.$refs.eagleForm.post({
          url: "site/entPostCertificate/save",
          needValid: true,
          validCallback: function () {
            return true;
          },
          successCallback: function (res) {
            _this.close();
          },
          errorCallback: function (res) {
            console.log(res);
          },
        });

    },
    close() {
      this.base.navigateBack();
      uni.$emit('_update_postCertificate_list')
    },
    showstrr(list) {
      this.model.details = this.model.details.filter(
          (item) => item.certificateName !== list.certificateName
      );
      this.model.details.push(list);
      this.color = "#f3f4f6";
    },

    uploadSuccess(e) {
      let _this = this;
      if (e?.filePath !== "") {
        this.common.post("/site/ToGStatistics/ocrOperator", {
            fileUrl: e?.filePath,
            fileName: e?.attName,
          })
          .then((res) => {
            if (res.code === 200 && res?.data?.["姓名"] !== "") {
              _this.handleImgInfo(res.data);
            }
          });
      }
    },
    handleImgInfo(info) {
      let _this = this;
      uni.showModal({
        title: "提示",
        content: "通过OCR识别信息，是否覆盖当前表单?",
        success: (res) => {
          if(res.confirm) {  
            if (info["行业类别"]) {
        _this.model.certificateName = info["人员类别"];
        _this.model.postName = info["人员类别"];
        _this.model.name = info["姓名"];
        // _this.model.certificateFirstGetDate = info["初领日期"] ?? "";
        // _this.model.organName = info["工作单位"];
        if (info?.["有效期开始日期"]!="" && info?.["有效期终止日期"] !="") {
          _this.$set(
          _this.model.certificateValidityDateRangeList,
          0,
          info?.["有效期开始日期"]
        );
        _this.$set(
          _this.model.certificateValidityDateRangeList,
          1,
          info?.["有效期终止日期"]
        );
        _this.model.certificateValidityDateStart = info["有效期开始日期"];
        _this.model.certificateValidityDate = info["有效期终止日期"];
        // _this.changeDateRange(_this.model.certificateValidityDateRangeList);
        } else {
          _this.model.certificateValidityDateRangeList = [];
          _this.model.certificateValidityDateStart = "";
          _this.model.certificateValidityDate = "";
      }
      } 

      if (info.hasOwnProperty('有效期-年')) {
        _this.model.name = info["姓名"];
        if (info?.["发证日期-年"] != "" && info?.["发证日期-月"] != "") {
          let fzday = _this.getLastDay(
            info?.["发证日期-年"],
            info?.["发证日期-月"]
          );
          let certificateFirstGetDate =
            info?.["发证日期-年"] + "-" + info?.["发证日期-月"] + "-" + fzday;
          if (info?.["发证日期-年"] != "" && info?.["发证日期-月"] != "") {
            let rangeDay = _this.getLastDay(
              info?.["有效期-年"],
              info?.["有效期-月"]
            );
            let rangeDate =
              info?.["有效期-年"] + "-" + info?.["有效期-月"] + "-" + rangeDay;
            console.log(certificateFirstGetDate,'certificateFirstGetDate');
            _this.$set(
              _this.model.certificateValidityDateRangeList,
              0,
              certificateFirstGetDate
            );
            _this.$set(
              _this.model.certificateValidityDateRangeList,
              1,
              rangeDate
            );
            _this.model.certificateValidityDateStart = certificateFirstGetDate;
            _this.model.certificateValidityDate = rangeDate;
            console.log( _this.model,' _this.model');
            // _this.changeRangeDate(_this.model.certificateValidityDateRangeList);
          }
        } else {
          console.log('发生了什么');
          // _this.model.certificateFirstGetDate = "";
          _this.model.certificateValidityDateRangeList = [];
          _this.model.certificateValidityDateStart = "";
          _this.model.certificateValidityDate = "";
        }

        // _this.form.organName = info["工作单位"];
      }
	} else {  
		} 
        },
      });

 

    },

    getLastDay(year, month) {
      if (year && month) {
        console.log(new Date(year, month, 0).getDate());
        return new Date(year, month, 0).getDate();
      }
    },
    deleteContract(item, index) {
      var _this = this;
      uni.showModal({
        title: "提示",
        content: "您确定要删除这条证书信息吗？",
        success: (res) => {
          if (res.confirm) {
            _this.model.details.splice(index, 1);
          }
        },
      });
    },

    getSuplusDate(item) {
      var deadline = item.certificateValidityDate;

      if (deadline == null || deadline == "") {
        return `无记录`;
      } else {
        var now = new Date();
        let day = this.getDaysBetween(now, deadline);
        if (day >= 0 && day < 30) {
          item.tags = "warning";
          return `剩余${day}天`;
        } else if (day >= 30) {
          item.tags = "success";
          return `剩余${day}天`;
        } else {
          item.tags = "error";
          return `逾期${day * -1}天`;
        }
      }
    },

    getDaysBetween(date1, date2) {
      var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));
      var endDate = Date.parse(
          this.formatDate(date2.replace(/-/g, "/"), "yyyy-MM-dd")
      );
      var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
      return days > 0 ? parseInt(days) : parseInt(days);
    },
    formatDate(dateTime = null, fmt = "yyyy-MM-dd") {
      // 如果为null,则格式化当前时间
      if (!dateTime) return "";
      // 如果dateTime长度为10或者13，则为秒和毫秒的时间戳，如果超过13位，则为其他的时间格式
      if (dateTime.toString().length == 10) dateTime *= 1000;
      let date = new Date(dateTime);
      let ret;
      let opt = {
        "y+": date.getFullYear().toString(), // 年
        "M+": (date.getMonth() + 1).toString(), // 月
        "d+": date.getDate().toString(), // 日
        "h+": date.getHours().toString(), // 时
        "m+": date.getMinutes().toString(), // 分
        "s+": date.getSeconds().toString(), // 秒
        // 有其他格式化字符需求可以继续添加，必须转化成字符串
      };
      for (let k in opt) {
        ret = new RegExp("(" + k + ")").exec(fmt);
        if (ret) {
          fmt = fmt.replace(
              ret[1],
              ret[1].length == 1
                  ? opt[k]
                  : opt[k].padStart(ret[1].length, "0")
          );
        }
      }
      return fmt;
    },

    isString(obj) {
      return typeof obj === "string" ? true : false;
    },
  },
};
</script>

<style lang='scss'>
.formInfo {
  .warp {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
  }

  .rect {
    width: 120px;
    height: 120px;
    background-color: #fff;

    image {
      width: 240rpx;
      height: 240rpx;
    }
  }

  .peoInfo {
    display: flex;
    padding: 20rpx;
    color: #303133;
    font-size: 32rpx;

    view {
      color: #ff0000;
    }
  }

  .allowed {
    background: #ffffff;
    padding: 0 20rpx;
    /* border-bottom: 2rpx solid ; */

    .button {
      height: 70rpx;
      line-height: 70rpx;
      box-sizing: border-box;
    }
  }

  .pics {
    border: 1px solid #999999;
    height: 200rpx;
    width: 650rpx;
    margin-top: 30rpx;
    margin-left: 20rpx;
    display: flex;
    justify-content: space-between;

    .pics-left {
      view {
        padding: 10rpx;
      }
    }

    .pics-right {
      height: 200rpx;

      image {
        width: 130rpx;
        height: 100rpx;
        margin-right: 20px;
      }
    }
  }

  .eagle-page-empty {
    background: #fff;
  }

  .card-content {
    display: flex;

    .card-content-img {
      display: flex;
      flex-direction: column;
      margin-right: 20rpx;
    }

    .card-content-body {
      flex: 1 1;
    }
  }

  /deep/ .eagle-row-card {
    margin: 0 0 20rpx 0;
  }
}
</style>
