<template>
    <view>

        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" selfHeight='calc(100vh - 125px)'>
            <eagle-container title="">
                  <eagle-text v-model="model.certificateName" title="证书名称"></eagle-text>
                  <eagle-text title="证书有效期" v-if="model.certificateValidityDateRangeList">
                    {{(model.certificateValidityDateRangeList[0]) |dateFormat}}至{{(model.certificateValidityDateRangeList[1]) |dateFormat}}
                  </eagle-text>
                  <eagle-text title="证书初领日期">
                    {{model.certificateValidityDate|dateFormat}}
                  </eagle-text>
                  <eagle-text v-model="model.name" title="证书类型">
                    <template>
                      <view v-for="its in allList" :key="its.id"> <span v-if="its.id==model.certificateType" class="orange" > {{ its.name }}</span></view>
                    </template>
                  </eagle-text>
                  <eagle-text v-model="model.name" title="姓名"></eagle-text>
                  <!-- <eagle-text v-model="model.organName" title="部门"></eagle-text>
                  <eagle-text v-model="model.postName" title="岗位"></eagle-text>
                  <eagle-text v-model="model.remarks" title="备注"></eagle-text> -->
                  <eagle-text title="证书照片">
                      <eagle-display-image :value="model.attachs" />
                  </eagle-text>
              </eagle-container>
        </eagle-form>
    </view>
</template>
<script>
export default {
    data() {
        return {
            tags: ["主要负责人证", "高压电工证", "低压电工证"],
            model: { certificateName: "" },
            control: "site/entPostCertificate",
            errorType: ["message"],
            allList: [],
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
        };
    },
    created() {
        let _this = this;
        _this.initParams();
    },
    methods: {
        initCallBack(data) {},
        initParams() {
            var _this = this;
          this.common
              .getparamsList("cert_type")
              .then(function (res) {
                if (res.code == 200 && res.data) {
                  _this.allList = res.data;
                }
              });
            this.common
                .getparamsList(
                    "site_enterprise_danger,site_enterprise_factory_ownership,site_enterprise_standardization_level,site_project_enterprise_scale"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        console.log(res.data, 22222222);
                        res.data.forEach(function (item) {
                            if (
                                item.paramId ==
                                "site_enterprise_standardization_level"
                            ) {
                                _this.params.equStatus.push(item);
                            } else if (
                                item.paramId == "site_project_enterprise_scale"
                            ) {
                                _this.params.enterpriseScale.push(item);
                            }
                        });
                    }
                });
        },
        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.close();
                },
                errorCallback: function (res) {},
            });
        },
        close() {
            let url = "pages/host/ent/basicResearch/index?tabContentIndex=1";
            if (this.$route.query.enterpriseCode) {
                url =
                    url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            }
            this.base.navigateTo(url);
        },
        tagClick(index) {
            this.model.certificateName = this.tags[index];
        },
      formatDate(dateTime = null, fmt = "yyyy-MM-dd") {
        // 如果为null,则格式化当前时间
        if (!dateTime) return "";
        // 如果dateTime长度为10或者13，则为秒和毫秒的时间戳，如果超过13位，则为其他的时间格式
        if (dateTime.toString().length == 10) dateTime *= 1000;
        let date = new Date(dateTime);
        let ret;
        let opt = {
          "y+": date.getFullYear().toString(), // 年
          "M+": (date.getMonth() + 1).toString(), // 月
          "d+": date.getDate().toString(), // 日
          "h+": date.getHours().toString(), // 时
          "m+": date.getMinutes().toString(), // 分
          "s+": date.getSeconds().toString(), // 秒
          // 有其他格式化字符需求可以继续添加，必须转化成字符串
        };
        for (let k in opt) {
          ret = new RegExp("(" + k + ")").exec(fmt);
          if (ret) {
            fmt = fmt.replace(
                ret[1],
                ret[1].length == 1
                    ? opt[k]
                    : opt[k].padStart(ret[1].length, "0")
            );
          }
        }
        return fmt;
      },
    },
};
</script>

<style lang='scss'>
.peoInfo {
    padding: 20rpx;
    color: #303133;
    font-size: 32rpx;
}

.allowed {
    background: #ffffff;
    padding: 0 20rpx;
    /* border-bottom: 2rpx solid ; */

    .button {
        height: 70rpx;
        line-height: 70rpx;
        box-sizing: border-box;
    }
}
</style>
