<template>
    <view class="">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="100" :showCheck="true" @beforeLoad="beforeLoad" :boolInitData="false">
            <view slot="search" class="search-slot">
              <view class="search">
                <view class="tips-body">
                  <img :src="warninigIcon.default" />
                  <span>根据企业四色分级管理评分规则，未上传安全操作规程目录的，减10分。</span>
                </view>
                <eagle-search @search="search" placeholder="请输入名称进行搜索" v-model="searchValue" @custom="search" :show-action="false"></eagle-search>
<!--                <eagle-search @search="search" placeholder="请输入文件名称进行模糊搜索" v-model="conditions.name.value" :clearabled="true" :show-action="false" @clear="search"></eagle-search>-->
              </view>

            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.attachs" @click="handlerBody(item, index)">
                    <template slot="tag">
                        <view v-for="its in checkDatas" :key="its.id"> <span v-if="its.id==item.certificateType" class="orange" > {{ its.name }}</span></view>
                    </template>
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.name }}
                    </eagle-row-view>
                    <eagle-row-view>
                       {{ item.certificateName || "--" }}
                    </eagle-row-view>
                  <!--  <eagle-row-view>
                      初领日期: {{formatDate( item.certificateFirstGetDate )|| "--" }}
                    </eagle-row-view>  -->
                    <eagle-row-view>
                      有效日期: {{ (formatDate(item.certificateValidityDateRangeList[0]) +'至'+ formatDate(item.certificateValidityDateRangeList[1])) || "--" }}
                    </eagle-row-view>
                    <eagle-row-view>
                        <!-- <view>
                            <u-tag :text="item.certificateName" size="mini" style="margin: 5rpx;" />
                        </view> -->

                        <view>
                            <u-tag :text="item.statusName" size="mini" :type="getSuplusDate(item)" style="margin: 5rpx;" />
                        </view>
                    </eagle-row-view>
                    <template slot="rowBtn" style="margin-top: 5rpx">
                        <u-button type="primary" size="mini" @click="handlerBodyClick(item, index)">编辑</u-button>
                        <u-button type="error" size="mini" @click="handlerDel(item)">删除</u-button>

                    </template>
                </eagle-row-card>
                <!-- <view >
                    <view class="finite-space-container">
                        <view class="uni-media-cell" v-for="(item, index) in list" :key="index">
                            <view class="uni-media-list">
                                <view class="uni-media-list-body" @click="handlerBody(item,index)">
                                    <view class="card-content">
                                        <view class="card-content-img">
                                            <image style="width: 250rpx;height: 150rpx;" :src="item.attachs?item.attachs:noImgUrl" mode="aspectFill">
                                            </image>
                                        </view>
                                        <view class="card-content-body">
                                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                                <eagle-girdrow-block class="one-line" style='white-space: nowrap; width: 130px;'>{{item.name}}</eagle-girdrow-block>
                                                <eagle-girdrow-block type="warn">
                                                    <view class="circleShow">
                                                        {{item.postName}}
                                                    </view>
                                                </eagle-girdrow-block>
                                            </eagle-girdrow-base>
                                            <eagle-girdrow-base>
                                                所在部门: {{item.organName||"--"}}
                                            </eagle-girdrow-base>
                                            <eagle-girdrow-base style="">
                                                <view class="double-line">
                                                    <eagle-girdrow-block>
                                                        <view>
                                                            <u-tag :text="item.certificateName" size="mini" style="margin: 5rpx;" />
                                                        </view>

                                                        <view>
                                                            <u-tag :text="getSuplusDate(item)" size="mini" :type="tags" style="margin: 5rpx;" />
                                                        </view>
                                                    </eagle-girdrow-block>
                                                </view>
                                            </eagle-girdrow-base>
                                        </view>
                                    </view>
                                </view>
                            </view>
                            <eagle-grid-botton>
                                <u-icon class="eagle-red eagle-row-span" name="trash" label="删除" @click="handlerDel(item)" />
                                <u-icon name="edit-pen" label="编辑" @click="handlerBodyClick(item,index)"></u-icon>
                            </eagle-grid-botton>
                        </view>
                    </view>
                </view> -->
            </view>

        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal="right" @fabClick="handlerFabClick">
        </eagle-fab>
        <!-- <TabbarHost></TabbarHost> -->
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
export default {
    name: "SpecialPost",
    props: { TabbarHost },
    data() {
        return {
            isShow: false,
            list: [],
            noImgUrl: require("@/static/img/no-img.png"),
            tags: "error",
            controller: "/site/entPostCertificate",
            searchValue: "",
            checkDatas:[],
            warninigIcon: require("@/static/img/AppIcon/icon_warning.png"),
        };
    },
    components: { TabbarHost },
    created() {
         uni.$on('_update_postCertificate_list', () => {
            this.search();
        })
    },
    mounted() {
        this.initParams()
        this.search();
    },
    methods: {
        search() {
            let conditions = [];
            if (this.searchValue) {
                conditions.push({
                    name: "name",
                    value: this.searchValue,
                    operate: "like",
                });
            }
            setTimeout(() => {
                this.$refs.eaglePageList.search({ conditions: conditions });
            });
        },
      initParams() {
        var _this = this;
        this.common
            .getparamsList("cert_type")
            .then(function (res) {
              if (res.code == 200 && res.data) {
                _this.checkDatas = res.data;
              }
            });
      },
        initList(list) {
            this.list = list;

            for (let i = 0; i < this.list.length; i++) {
                var item = this.list[i];
                var arr = item.attachs.split(";");

                if (arr.length > 0) {
                    item.attachs = arr[0];
                } else {
                }
            }
        },

        handlerBody(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/postCertificate/editCertificate/view",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        handlerBodyClick(item, index) {
            // let url =
            //     "pages/host/ent/basicResearch/postCertificate/editInformation/detail?id=" +
            //     item.id;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // this.base.navigateTo(url); editCertificate
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/postCertificate/editCertificate/detail",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerFabClick() {
            // let url =
            //     "pages/host/ent/basicResearch/postCertificate/editCertificate/detail?id=0";
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // this.base.navigateTo(url);
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/postCertificate/editCertificate/detail",
                {
                    id: 0,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        close() {
            this.base.navigateBack();
        },
        handleretie() {
            console.log("编辑了");
        },
        handlerDel(item) {
            console.log("删除了");

            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        getSuplusDate(item) {
          if (item.statusName == '三个月内到期') {
            return `warning`;
          } else if (item.statusName == '正常') {
            return `primary`;
          } else if (item.statusName == '已过期') {
            return `error`;
          }
            // var deadline = item.certificateValidityDate;
            //
            // if (deadline == null || deadline == "") {
            //     item.tags = "success";
            //     return `无记录`;
            // } else {
            //     var now = new Date();
            //     let day = this.getDaysBetween(now, deadline);
            //     if (day >= 0 && day < 30) {
            //         // item.tags = "success";
            //         return `剩余${day}天`;
            //     } else if (day >= 30) {
            //         // item.tags = "success";
            //         return `剩余${day}天`;
            //     } else {
            //         item.tags = "error";
            //         return `逾期${day * -1}天`;
            //     }
            // }
        },
        getDaysBetween(date1, date2) {
            var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));
            var endDate = Date.parse(
                this.formatDate(date2.replace(/-/g, "/"), "yyyy-MM-dd")
            );
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
        formatDate(dateTime = null, fmt = "yyyy-MM-dd") {
            // 如果为null,则格式化当前时间
            if (!dateTime) return "";
            // 如果dateTime长度为10或者13，则为秒和毫秒的时间戳，如果超过13位，则为其他的时间格式
            if (dateTime.toString().length == 10) dateTime *= 1000;
            let date = new Date(dateTime);
            let ret;
            let opt = {
                "y+": date.getFullYear().toString(), // 年
                "M+": (date.getMonth() + 1).toString(), // 月
                "d+": date.getDate().toString(), // 日
                "h+": date.getHours().toString(), // 时
                "m+": date.getMinutes().toString(), // 分
                "s+": date.getSeconds().toString(), // 秒
                // 有其他格式化字符需求可以继续添加，必须转化成字符串
            };
            for (let k in opt) {
                ret = new RegExp("(" + k + ")").exec(fmt);
                if (ret) {
                    fmt = fmt.replace(
                        ret[1],
                        ret[1].length == 1
                            ? opt[k]
                            : opt[k].padStart(ret[1].length, "0")
                    );
                }
            }
            return fmt;
        },

        isString(obj) {
            return typeof obj === "string" ? true : false;
        },
    },
    beforeDestroy() {
        uni.$off('_update_postCertificate_list')
    }
};
</script>

<style lang='scss'>
.search {
    .searchFont {
        width: 80rpx;
        height: 80rpx;
        line-height: 80rpx;
        text-align: center;
        margin-left: 10rpx;
    }
}

.circleShow {
    height: 50rpx;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;
}

.content {
    padding: 24rpx;
    text-align: center;
    margin-bottom: 20rpx;
}

.finite-space-container {
    width: 100%;
    overflow: hidden;
    box-sizing: border-box;
}

.double-line {
    display: -webkit-box;
    text-overflow: ellipsis;
    overflow: hidden;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}

.one-line {
    /**
		思路：
		1.设置inline-block属相
		2.强制不换行
		3.固定高度
		4.隐藏超出部分
		5.显示“……”
	  */
    display: inline-block;
    white-space: nowrap;
    width: 120px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.card-content {
    display: flex;

    .card-content-img {
        margin-right: 20rpx;
    }

    .card-content-body {
        flex: 1 1;
    }
}
.tips-body {
  display: flex;
  align-items: center;
  padding: 12rpx 22rpx;
  img {
    height: 36rpx;
    width: 36rpx;
    margin-right: 16rpx;;
  }
}
</style>
