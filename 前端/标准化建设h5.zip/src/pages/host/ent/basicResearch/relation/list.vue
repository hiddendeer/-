<template>
    <view class="finite-space-container eagle-layer">

        <!-- <view class="search">
            <eagle-search @search="search" placeholder="请输入名称进行搜索" v-model="searchValue" @custom='search' :show-action="false">
            </eagle-search>
        </view> -->

        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="100" :showCheck="true">
            <view slot="search" class="search-slot">
                <eagle-search @search="search" placeholder="请输入名称进行搜索" v-model="searchValue" @custom='search' :show-action="false">
                </eagle-search>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="handlerBodyClick(item)">
                    <template slot="tag">
                        <view> <span class="success"> {{ item.relateType | splitParamsFormat(params.sourceType) }}</span>
                        </view>
                    </template>
                    <view>
                        <eagle-row-view :isTitle="true" type="success">
                            {{ item.name }}
                        </eagle-row-view>
                        <!-- <eagle-row-view>
                            联系人: {{ item.contactPerson }}
                        </eagle-row-view>
                        <eagle-row-view>
                            联系电话:{{ item.contactPhone }}
                        </eagle-row-view> -->
                    </view>
                    <template slot="button">

                        <u-button type="error" size="mini" @click="handlerDel(item)">删除</u-button>

                        <u-button type="primary" size="mini" @click="handlerEdit(item)">编辑</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="list-wrap">
                    <view class="uni-media-cell" v-for="item in data" :key="item.id">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body">
                                <view @click="handlerBodyClick(item)">
                                    <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                        <eagle-girdrow-block class="one-line">
                                            {{item.name}}
                                        </eagle-girdrow-block>
                                        <eagle-girdrow-block type="success">
                                            {{item.relateType|splitParamsFormat(params.sourceType)}}
                                        </eagle-girdrow-block>
                                    </eagle-girdrow-base>
                                    <eagle-girdrow-base style="margin-bottom: 20rpx;">
                                        <eagle-girdrow-block class="double-line">
                                            姓名:
                                            {{item.contactPerson}}
                                        </eagle-girdrow-block>
                                    </eagle-girdrow-base>
                                    <eagle-girdrow-base style="margin-bottom: 20rpx;">
                                        <eagle-girdrow-block class="double-line">电话:{{item.contactPhone}}</eagle-girdrow-block>
                                    </eagle-girdrow-base>

                                </view>
                            </view>
                        </view>
                        <eagle-grid-botton>
                            <u-icon class="eagle-red eagle-row-span" name="trash" label="删除" @click="handlerDel(item)" />
                            <u-icon name="edit-pen" label="编辑" @click="handlerEdit(item)"></u-icon>
                        </eagle-grid-botton>
                    </view>
                </view> -->
            </view>
        </eagle-page-list>

        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <!-- <TabbarHost></TabbarHost> -->
    </view>
</template>
<script>
// import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
export default {
    data() {
        return {
            searchValue: "",
            controller: "/site/relation",
            datatype: "List",
            data: [],
            noImgUrl: require("@/static/img/no-img.png"),
            list: [],
            params: {
                sourceType: [],
            },
            fabContent: [
                {
                    iconPath: "../../../static/img/AppIcon/icon_list_add.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_list_add.png",
                    text: "新增",
                    active: true,
                },
                {
                    iconPath: "../../../static/img/AppIcon/icon_camera.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_camera.png",
                    text: "拍照",
                    active: false,
                },
            ],
        };
    },
    // onShow() {
    //     this.search();
    // },
    created() {
        this.search();
        this.initParams();
        uni.$on('_update_relation_list', () => {
            this.search();
        })
    },
    components: {},
    onReady() {},
    methods: {
        initList(list) {
            console.log("http===List12>", list);
            this.data = list;
        },
        search() {
            var conditions = [];

            if (this.searchValue) {
                conditions.push({
                    name: "name",
                    value: this.searchValue,
                    operate: "like",
                });
            }

            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: conditions,
                });
            });
        },
        handlerFabClick() {
            let url = "pages/host/ent/basicResearch/relation/detail?id=0";
            let linkUrl = this.common.getLinkUrl(url, {
                projectId: this.$route.query.projectId ?? "",
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
            });
            this.base.navigateTo(linkUrl);
        },
        trigger(e) {
            if (e.index === 0) {
                this.handlerFabClick();
            }
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_relation_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_relation_type") {
                                _this.params.sourceType.push(item);
                            }
                        });
                    }
                });
        },
        handlerBodyClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/relation/view",
                {
                    id: item.id,
                    projectId: this.$route.query.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerDel(item) {
            console.log("删除按钮");

            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },

        handlerEdit(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/relation/detail",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
    },
    beforeDestroy() {
        uni.$off('_update_relation_list')
    }
};
</script>

<style scoped lang="scss">
.finite-space-container {
    width: 100%;
    overflow: hidden;
    box-sizing: border-box;
}

.card-content {
    .card-content-body {
        flex: 1 1;
    }
}

.double-line {
    display: -webkit-box;
    text-overflow: ellipsis;
    overflow: hidden;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}

.one-line {
    /**
		思路：
		1.设置inline-block属相
		2.强制不换行
		3.固定高度
		4.隐藏超出部分
		5.显示“……”
	  */
    display: inline-block;
    white-space: nowrap;
    width: 80%;
    overflow: hidden;
    text-overflow: ellipsis;
}
</style>
