<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" :boolInitData="boolInitData" selfHeight='calc(100vh - 200px)' marginBottom="90px">
            <eagle-container>
                <eagle-input v-model="model.name" required title="单位名称" prop="name" labelPosition="top" labelWidth="180">
                </eagle-input>
                <eagle-radios title="类型" required :data-source="params.enterpriseScale" v-model="model.relateType" labelPosition="top" labelWidth="180" v-if="params.enterpriseScale.length > 0" />
                <eagle-input v-model="model.serviceDetail" title="服务说明" prop="serviceDetail" labelPosition="top" labelWidth="180" type="textarea">
                </eagle-input>
                <!-- <eagle-input v-model="model.contactPerson" required title="联系人" prop="contactPerson" labelPosition="top" labelWidth="180">
                </eagle-input>
                <eagle-input v-model="model.contactPhone" required title="联系电话" prop="contactPhone" labelPosition="top" labelWidth="180">
                </eagle-input> -->
                <eagle-file-upload :maxCount="9" title="安全协议" prop="secureProtocol" v-model="model.secureProtocol" labelPosition="top" labelWidth="180" />
                <eagle-file-upload :maxCount="9" title="其他附件" prop="attachs" v-model="model.attachs" labelPosition="top" labelWidth="180" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view marginBottom="5px">
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            control: "site/relation",
            errorType: ["message"],
            boolInitData: false,
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
            initParams: { companyCode: "" },
        };
    },

    created() {
        let _this = this;
        this.model.id = this.$route.query.id;
        _this.initParams1();
        console.log(this.params.enterpriseScale, 11);

        if (this.model.id != "0") {
            uni.setNavigationBarTitle({ title: "编辑相关方" });
            this.boolInitData = true;
        } else {
            this.boolInitData = false;
        }
    },
    mounted() {
        let _this = this;
        if (this.$route.query.enterpriseCode) {
            this.initParams.companyCode = this.$route.query.enterpriseCode;
        }

        setTimeout(() => {
            let action = this.$refs.eagleForm.getAction();
            if (action == "init") {
                let url = "site/relation/initData/0";
                this.common.get(url, this.initParams).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data;
                    } else {
                    }
                    uni.hideToast();
                });
            }
        });
    },
    methods: {
        initCallBack(data) {},
        initParams1() {
            var _this = this;
            this.common
                .getparamsList("site_relation_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_relation_type") {
                                _this.params.enterpriseScale.push(item);
                            }
                        });
                    }
                });
        },
        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.close();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        close() {
            this.base.navigateBack();
            uni.$emit('_update_relation_list')
        },
    },
};
</script>
