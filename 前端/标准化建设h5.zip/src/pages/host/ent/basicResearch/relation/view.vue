:<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :boolInitData="boolInitData" selfHeight='calc(100vh - 200px)'>
            <eagle-container title="相关方详情">
                <eagle-text v-model="model.name" title="单位名称"></eagle-text>
                <eagle-text v-model="model.name" title="类型">
                    {{model.relateType|splitParamsFormat(params.enterpriseScale)}}
                </eagle-text>
                <eagle-text v-model="model.serviceDetail" title="服务说明"></eagle-text>
                <!-- <eagle-text v-model="model.contactPerson" title="联系人"></eagle-text>
                <eagle-text v-model="model.contactPhone" title="联系电话"></eagle-text> -->
                <eagle-text prop="secureProtocol" title="安全协议">
                    <eagle-file-upload disabled v-model="model.secureProtocol" labelPosition="top" labelWidth="180" />
                </eagle-text>
                <eagle-text prop="attachs" title="其他附件">
                    <eagle-file-upload disabled v-model="model.attachs" labelPosition="top" labelWidth="180" />
                </eagle-text>

            </eagle-container>
            <!-- <eagle-display-input v-model="model.name" title="相关方名称" prop="name"></eagle-display-input>
            <eagle-display-input v-model="model.serviceDetail" title="服务说明" prop="serviceDetail"></eagle-display-input>
            <eagle-display-input v-model="model.contactPerson" title="联系人" prop="contactPerson"></eagle-display-input>
            <eagle-display-input v-model="model.contactPhone" title="联系电话" prop="contactPhone"></eagle-display-input> -->
        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            control: "site/relation",
            errorType: ["message"],
            boolInitData: false,
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
            initParams: { companyCode: "" },
        };
    },

    created() {
        let _this = this;
        this.model.id = this.$route.query.id;
        _this.initParams1();
        console.log(this.params.enterpriseScale, 11);
        this.boolInitData = true;
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        initParams1() {
            var _this = this;
            this.common
                .getparamsList("site_relation_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_relation_type") {
                                _this.params.enterpriseScale.push(item);
                            }
                        });
                    }
                });
        },
        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.close();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        close() {
            let url = "pages/host/ent/basicResearch/index?tabContentIndex=3";

            if (this.$route.query.enterpriseCode) {
                url =
                    url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            }
            this.base.navigateTo(url);
        },
    },
};
</script>
