<template>
    <view class="finite-space-container">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="100" :showCheck="true" @beforeLoad="beforeLoad">
            <view slot="search" class="search-slot">
                <eagle-search placeholder="请输入工艺名称进行搜索" @search="search" v-model="searchValue" @custom="search" :show-action="false"></eagle-search>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" :hasImg="true" :imgSrc="item.image" @click="handlerBodyClick(item)">
                    <view>
                        <eagle-row-view :isTitle="true" type="warn">
                            {{ item.name }}
                        </eagle-row-view>
                        <eagle-row-view>
                            {{ item.descText }}
                        </eagle-row-view>
                    </view>
                    <template slot="button">
                        <u-button type="error" size="mini" @click="handlerDel(item)">删除</u-button>
                        <u-button type="primary" size="mini" @click="handlerEdit(item)">编辑</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view >
                    <view class="uni-media-cell" v-for="(item, index) in data" :key="index">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body">
                                <view class="card-content">
                                    <view class="card-content-img">
                                        <image style="width: 250rpx;height: 150rpx;" :src="item.image?item.image:noImgUrl" mode="aspectFill"></image>
                                    </view>
                                    <view class="card-content-body" @click="handlerBodyClick(item)">
                                        <eagle-girdrow-base :isTitle="true">
                                            <eagle-girdrow-block class="double-line">{{item.name}}</eagle-girdrow-block>
                                        </eagle-girdrow-base>
                                        <eagle-girdrow-base>
                                            <eagle-girdrow-block>
                                                <view class="double-line">
                                                    {{item.descText}}
                                                </view>
                                            </eagle-girdrow-block>
                                        </eagle-girdrow-base>
                                    </view>
                                </view>
                            </view>
                        </view>
                        <eagle-grid-botton>
                            <u-icon class="eagle-red eagle-row-span" name="trash" label="删除" @click="handlerDel(item)" />
                            <u-icon name="edit-pen" label="编辑" @click="handlerEdit(item)"></u-icon>
                        </eagle-grid-botton>
                    </view>
                </view> -->
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>

    </view>
</template>

<script>
export default {
    data() {
        return {
            controller: "/site/entProcess",
            datatype: "List",
            noImgUrl: require("@/static/img/no-img.png"),
            data: [],
            searchValue: "",
        };
    },
    components: {},
    created() {
        this.search();
    },
    methods: {
        initList(list) {
            console.log("http===list>", list);
            this.data = list;
        },

        search() {
            let conditions = [];
            if (this.searchValue) {
                conditions.push({
                    name: "name",
                    value: this.searchValue,
                    operate: "like",
                });
            }
            setTimeout(() => {
                this.$refs.eaglePageList.search({ conditions: conditions });
            });
        },

        handlerBodyClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/process/view",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },

        handlerDel(item) {
            console.log("删除按钮");

            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        handlerEdit(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/process/detail",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/basicResearch/process/detail",
                {
                    id: 0,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        trigger(e) {
            if (e.index === 0) {
                this.handlerFabClick();
            }
        },
    },
};
</script>


<style scoped lang="scss">
.finite-space-container {
    width: 100%;
    overflow: hidden;
    box-sizing: border-box;

    .btn-box {
        display: flex;
        justify-content: center;
        align-items: center;
        color: #303133;

        view {
            width: 300rpx;
            height: 60rpx;
            line-height: 60rpx;
            text-align: center;

            .foot-icon {
                width: 28rpx;
                height: 28rpx;
                margin-right: 15rpx;
            }
        }
    }

    .u-body {
        display: flex;
        justify-content: space-between;
    }

    .u-body-item {
        width: 250rpx;
        height: 150rpx;
        text-align: center;

        image {
            width: 100%;
            height: 100%;
        }
    }

    .u-body-item-title {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        width: 370rpx;

        .u-tag {
            margin-right: 10rpx;
        }
    }

    .u-body-item-icon {
        width: 28rpx;
    }
}

.double-line {
    display: -webkit-box;
    text-overflow: ellipsis;
    overflow: hidden;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

.card-content {
    display: flex;

    .card-content-img {
        margin-right: 20rpx;
    }

    .card-content-body {
        flex: 1 1;
    }
}
</style>
