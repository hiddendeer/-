:<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm">
            <eagle-container title="安全生产工艺详情">
                <eagle-text v-model="model.name" title="工艺名称"></eagle-text>
                <eagle-text v-model="model.descText" title="工艺描述"></eagle-text>
                <eagle-text v-model="model.descText" title="工艺图">
                    <eagle-display-image :value="model.image" />
                </eagle-text>
            </eagle-container>
        </eagle-form>
    </view>
</template>

<script>
import eagleText from "../../../../../components/eagle-text/eagle-text.vue";
export default {
    components: { eagleText },
    data() {
        return {
            model: {},
            control: "site/entProcess",
            errorType: ["message"],
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
        };
    },
    created() {
        let _this = this;
        _this.initParams();
        // console.log(this.params.enterpriseScale, 11);
    },
    mounted() {
        let id = this.$route.query.id;
        console.log("id: ", id);
    },
    methods: {
        initCallBack(data) {},
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_relation_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_relation_type") {
                                _this.params.enterpriseScale.push(item);
                            }
                        });
                    }
                });
        },
    },
};
</script>
