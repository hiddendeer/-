<template>
    <view>

        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType">
            <eagle-container>
                <eagle-input v-model="model.name" required title="工艺名称" prop="name" labelPosition="top" labelWidth="180">
                </eagle-input>

                <eagle-input v-model="model.descText" title="工艺描述" type="textarea" prop="descText" labelPosition="top" labelWidth="180">
                </eagle-input>

                <eagle-upload title="工艺图" :maxCount="1" prop="image" v-model="model.image" labelPosition="top" labelWidth="180" />
            </eagle-container>
        </eagle-form>

        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
            <!-- <u-button type="error" size="medium">删除</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
import eagleContainer from "../../../../../components/eagle-container/eagle-container.vue";
export default {
    components: { eagleContainer },
    data() {
        return {
            model: {},
            control: "site/entProcess",
            errorType: ["message"],
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
        };
    },
    created() {
        let _this = this;
        _this.initParams();
        // console.log(this.params.enterpriseScale, 11);
    },
    mounted() {
        let id = this.$route.query.id;
        console.log("id: ", id);
        if (id && id !== 0) {
            uni.setNavigationBarTitle({ title: "生产工艺-编辑" });
        }
    },
    methods: {
        initCallBack(data) {},
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_relation_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_relation_type") {
                                _this.params.enterpriseScale.push(item);
                            }
                        });
                    }
                });
        },
        post(op) {
            let _this = this;

            // if(this.model.id == "0"){
            // 	this.model.companyCode = this.$route.query.enterpriseCode;
            // }

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.close();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>
