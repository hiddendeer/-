<template>
    <view class="enterpriseinfo eagle-layer">
        <view style="padding: 10rpx 0;">
            <u-subsection mode='subsection' active-color='#2979FF' :list="radioList" :current="radioIndex" :height='60' :bold='false' @change="handlerSectionChange"></u-subsection>
        </view>
        <view class="page-body">
            <view v-show="radioIndex === 0" class="enterpriseinfoWrap">
                <eagle-form @initCallBack="initCallBack" control="site/entInfo" v-model="model" ref="eagleForm" labelWidth="150" labelAlign='left' :initUrl="initUrl" :errorType="errorType" :boolInitData="false" marginBottom="90px">
                    <eagle-container>
                        <fast-choose-company label="企业名称" required prop="name" v-model="model.enterpriseName" @changed="buttonFastSearch" />
                        <eagle-input prop="uscn" v-model="model.uscn" title="统一社会信用代码"></eagle-input>
                        <eagle-select-item required v-model="model.applyProfessionNames" title="所属行业" labelWidth="130" @industryInformation='industryInformation'></eagle-select-item>
                        <eagle-address v-model="model.belongArea" required title="所属地区" labelWidth="130">
                        </eagle-address>
                        <eagle-input v-model="model.safeManager" title="安全管理人员" prop="safeManager">
                        </eagle-input>
                        <eagle-input v-model="model.safeManagerTel" title="联系方式" prop="enterpriseShortName">
                        </eagle-input>
                        <u-form-item>
                            <u-col :span='4'>
                                <eagle-upload title="公司LOGO" :maxCount="1" prop="logoAttach" v-model="model.logoAttach" labelPosition="top" labelAlign='center' :hasPadding='false' />
                            </u-col>
                            <u-col :span='5'>
                                <eagle-upload title="公司营业执照" :maxCount="1" prop="licenseAttach" v-model="model.licenseAttach" labelPosition="top" labelAlign='center' :hasPadding='false' />
                            </u-col>
                        </u-form-item>
                        <eagle-checkbox-group checkBoxWidth="160px" v-model="model.reskPointCodes" title="监管重点" prop="reskPointCodes" :data-source="params.equStatus" @checkboxGroupChange="checkboxChange" />
                        <eagle-input v-model="model.remarks" placeholder="请输入关键风险点描述信息" title="描述" prop="remarks" type="textarea">
                        </eagle-input>
                    </eagle-container>
                </eagle-form>
            </view>
            <view v-show='radioIndex === 1' class="enterpriseinfoWrap">

                <eagle-form @initCallBack="initCallBack" control="site/entInfo" v-model="model" ref="eagleForm" :errorType="errorType" :boolInitData="false" marginBottom="90px">
                    <eagle-container>
                        <eagle-select v-model="model.factoryOwnerShip" title="厂房权属" labelPosition="top" prop="factoryOwnerShip" :height="70" :data-source="params.equipmentType">
                        </eagle-select>
                        <eagle-input v-model="model.address" title="详细地址" prop="address" type="textarea">
                        </eagle-input>
                        <eagle-select v-model="model.enterpriseScale" labelPosition="top" title="企业规模" prop="enterpriseScale" :height="70" :data-source="params.enterpriseScale">
                        </eagle-select>
                        <eagle-input v-model="model.introduce" title="经营范围" type="textarea" prop="introduce">
                        </eagle-input>
                        <eagle-input v-model="model.preAnnualSales" title="年产值(万元)" prop="preAnnualSalesn">
                        </eagle-input>

                        <u-form-item label="员工人数(人)" label-position='top' :label-width='150'>
                            <u-number-box v-model="model.empCnt"></u-number-box>
                        </u-form-item>

                        <eagle-switch v-model="model.isInsure" title="投保安责险" prop="isInsure">
                        </eagle-switch>
                        <view v-if="model.isInsure">
                            <eagle-input v-model="model.insureCompany" title="投保安责险公司" prop="insureCompany">
                            </eagle-input>
                            <eagle-date v-model="model.insureOverDate" title="安责险有效期" prop="insureOverDate">
                            </eagle-date>
                        </view>
                        <eagle-switch v-model="model.isPassStandardization" title="标准化等级" prop="isInsure">
                        </eagle-switch>
                        <view v-if="model.isPassStandardization">
                            <eagle-select v-model="model.standardizationLevel" labelPosition="top" title="标准化等级" prop="standardizationLevel" :height="70" :data-source="params.level"></eagle-select>

                            <eagle-date v-model="model.standardizationInsuranceOverDate" title="证书有效日期" prop="standardizationInsuranceOverDate"></eagle-date>
                        </view>
                        <eagle-input v-model="model.enterpriseShortName" title="公司简称" type="textarea" prop="enterpriseShortName">
                        </eagle-input>
                        <u-form-item label="安全管理人员" :label-width='190' class="no-border">
                            <uni-view class="u-checkbox__label" style="color:#777;">全职</uni-view>
                            <view style="width: 160rpx;">
                                <u-number-box v-model="model.fullTimePersonCount"></u-number-box>
                            </view>
                        </u-form-item>
                        <u-form-item>
                            <view style="margin-left: 190rpx; display: flex;">
                                <uni-view class="u-checkbox__label" style="color:#777;">兼职</uni-view>
                                <view style="width: 160rpx;">
                                    <u-number-box v-model="model.partTimePersonCount"></u-number-box>
                                </view>
                            </view>
                        </u-form-item>
                    </eagle-container>
                </eagle-form>
            </view>
        </view>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
        <view style="height:50rpx;"></view>
    </view>
</template>

<script>
import fastChooseCompany from "@/pages/project/projectCompany/components/fast-choose-company";

export default {
    components: {
        fastChooseCompany,
    },
    data() {
        return {
            radioList: ["基础信息", "编辑更多信息"],

            radioIndex: 0,
            control: "site/entInfo/getEnterpriseInfo",
            initUrl: "",
            model: {},
            errorType: ["message"],
            surss: [
                {
                    name: "机械行业",
                },
            ],
            params: {
                equStatus: [],
                equipmentType: [],
                enterpriseScale: [],
                level: [],
            },
            industrySelectShow: false,
            regionShow: false,
            scrollHeight: 300,
            // showIndustry: false,
        };
    },
    mounted() {
        this.getEnterpriseInfo();
    },

    created() {
        let _this = this;
        _this.initParams();
    },
    methods: {
        // funDialogShow() {
        //     this.showIndustry = true;
        // },

        getEnterpriseInfo() {
            this.initParams.code = this.$route.query.code;
            if (this.$route.query.enterpriseCode) {
                this.initParams.companyCode = this.$route.query.enterpriseCode;

                this.control =
                    this.control +
                    "?enterpriseCode=" +
                    this.$route.query.enterpriseCode;
            }
            let _this = this;
            setTimeout(() => {
                this.common
                    .post(_this.control, _this.initParams)
                    .then(function (res) {
                        if (res.code === 200) {
                            _this.model = res.data;
                        } else {
                        }
                        uni.hideToast();
                    });
            });
            this.resetTableHeight();
        },

        resetTableHeight() {
            let windowHeight = 0;
            var _that = this;
            uni.getSystemInfo({
                success: function (res) {
                    _that.scrollHeight = res.windowHeight;
                },
            });
        },
        choose() {
            console.log(1);
        },
        checkboxChange(e) {
            let checkedVals = e.join();
            let names = [];
            for (let i = 0; i < this.params.equStatus.length; i++) {
                let item = this.params.equStatus[i];

                if (e.includes(item.id)) {
                    names.push(item.name);
                }
            }

            console.log(names.join());
            this.model.reskPointNames = names.join();
        },

        handlerSectionChange(index) {
            console.log(index);
            this.radioIndex = index;
        },
        initCallBack(data) {},
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_enterprise_danger,site_enterprise_factory_ownership,site_project_enterprise_scale,site_enterprise_standardization_level"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        console.log(res.data);
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_enterprise_danger") {
                                _this.params.equStatus.push(item);
                            } else if (
                                item.paramId ==
                                "site_enterprise_factory_ownership"
                            ) {
                                _this.params.equipmentType.push(item);
                            } else if (
                                item.paramId == "site_project_enterprise_scale"
                            ) {
                                _this.params.enterpriseScale.push(item);
                            } else if (
                                item.paramId ==
                                "site_enterprise_standardization_level"
                            ) {
                                _this.params.level.push(item);
                            }
                        });
                    }
                });
        },
        post() {
            let _this = this;
            if (this.model.enterpriseName == "") {
                this.$refs.uToast.show({
                    title: "请输入企业名称",
                    type: "error",
                });
                return;
            }

            if (this.model.applyProfessionCodes == "") {
                this.$refs.uToast.show({
                    title: "请选择行业",
                    type: "error",
                });
                return;
            }
            // if (!this.model.uscn) {
            //     this.$refs.uToast.show({
            //         title: "请输入统一社会信用代码",
            //         type: "error",
            //     });
            //     return;
            // }

            if (this.model.belongArea == "") {
                this.$refs.uToast.show({
                    title: "请选择所属地区",
                    type: "error",
                });
                return;
            }

            this.$refs.eagleForm.post({
                needValid: false,
                url: "site/entInfo/save",
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.$refs.uToast.show({
                        title: "提交成功",
                        type: "success",
                    });
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        // close() {

        //     let linkUrl = this.common.getLinkUrl(
        //         "pages/host/ent/basicResearch/index",
        //         {
        //             enterpriseCode: this.$route.query.enterpriseCode ?? "",
        //             projectId: this.$route.query.projectId ?? "",
        //         }
        //     );
        //     this.base.navigateTo(linkUrl);
        // },
        industryInformation(val) {
            (this.model.applyProfessionNames = val.industryName),
                (this.model.applyProfessionCodes = val.industryIap);
            // this.showIndustry = false;
        },
        confirm(e) {
            if (e.city.label === "市辖区") {
                this.model.belongArea = e.province.label + "/" + e.area.label;
            } else if (e.province.label === "全国") {
                this.model.belongArea = "全国";
            } else {
                this.model.belongArea =
                    e.province.label + "/" + e.city.label + "/" + e.area.label;
            }
        },
        buttonFastSearch() {
            var _this = this;
            _this.common
                .get(
                    "/site/projectCustomer/getDataFromGuanguanTyByName/" +
                        _this.model.enterpriseName
                )
                .then((res) => {
                    if (res.code == 200 && res.data) {
                        _this.model.uscn = res.data.organizationCode;
                        _this.model.address = res.data.address;
                        _this.model.introduce = res.data.natureOfBusiness;
                    }
                });
        },
    },
};
</script>
<style lang="scss" scoped>
.enterpriseinfo {
    display: flex;
    flex-direction: column;
    width: 100vw;

    .div_buttonFastSearch {
        display: block;
        color: rgb(41, 121, 255);
    }

    .page-body {
        -webkit-box-flex: 1;
        -webkit-flex: 1;
        flex: 1;
        overflow: auto;
    }
}

.view-bottom-btn {
    height: 140rpx;
    width: 100%;
    bottom: 0px;
    padding: 10px;
    background: #fff;
}
</style>
