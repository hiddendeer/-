:<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" :boolInitData="false">

            <view style="background-color: #FFFFFF;">
                <u-form-item>
                    <img class="u-preview-image" v-if="model.orgImg" :src="model.orgImg" />
                    <!-- <eagle-img :width="width" v-if="model.orgImg" :src="model.orgImg" :previewFullImage="previewFullImage"></eagle-img> -->
                    <uni-view class="no-image" v-else style="display: inline-block;">
                        暂无图片
                    </uni-view>
                </u-form-item>
            </view>

        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            control: "site/entInfo",
            errorType: ["message"],
            width: "100px",
            params: {
                equStatus: [],
                enterpriseScale: [],
            },
        };
    },
    created() {
        let _this = this;
        _this.getDataByCompanyCode();
        // console.log(this.params.enterpriseScale, 11);
    },
    mounted() {},
    methods: {
        initCallBack(data) {},
        getDataByCompanyCode() {
            let _this = this;
            let url = "site/entInfo/getEnterpriseInfo";

            if (this.$route.query.enterpriseCode) {
                url =
                    url + "?enterpriseCode=" + this.$route.query.enterpriseCode;
            }

            this.common.post(url).then(function (res) {
                if (res.code === 200) {
                    _this.model = res.data ? res.data : {};
                } else {
                }
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.u-preview-image {
    width: 100%;
    padding: 10px;
}
.no-image {
    text-align: center;
    width: 100%;
    padding: 10%;
}
</style>
