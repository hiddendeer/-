<template>
  <view class="equipment-facilities-detail-container" style="margin-top: 10px">
    <u-subsection
      mode="subsection"
      active-color="#2979FF"
      :list="radioList"
      :current="sectionCurrent"
      :height="60"
      :bold="false"
      @change="handlerSectionChange"
    ></u-subsection>
    <eagle-form
      @initCallBack="initCallBack"
      :control="control"
      :initUrl="initUrl"
      v-model="model"
      ref="eagleForm"
      :out-height="60"
      :errorType="errorType"
      labelWidth="150"
      labelAlign="left"
      selfHeight="calc(100vh - 160px)"
    >
      <eagle-container>
        <template v-if="sectionCurrent === 0">
          <fast-choose-build
            required
            title="所在区域"
            v-model="model.locationName"
            :name.sync="model.locationCode"
          ></fast-choose-build>
          <eagle-upload
            title="设备照片"
            :maxCount="1"
            prop="equipmentPhoto"
            v-model="model.equipmentPhoto"
            labelWidth="150"
            labelPosition="top"
            :deletable="deletable"
            key="equipmentPhoto1"
          />
          <eagle-input
            v-model="model.orgName"
            required
            title="部门"
            prop="orgName"
            labelPosition="top"
            labelWidth="150"
            key="orgName1"
          />
          <eagle-input
            v-model="model.equipmentName"
            required
            title="设备名称"
            prop="equipmentName"
            labelPosition="top"
            labelWidth="150"
            key="equipmentName1"
          />
          <eagle-input
            v-model="model.equipmentModel"
            title="设备型号"
            prop="equipmentModel"
            labelPosition="top"
            labelWidth="150"
            key="equipmentModel1"
          />
          <!-- <view style="background: #FFFFFF;" v-if="!(this.model.id > 0)">
                        <view style="padding: 0 30rpx;"> -->
          <u-form-item
            label="设备数量"
            label-position="top"
            required
            :label-width="150"
            v-if="!model.id"
          >
            <u-number-box
              v-model="model.equipmentCount"
              @change="countChange"
              onkeydown="return false;"
            ></u-number-box>
          </u-form-item>
          <!-- </view>
                    </view> -->
          <!-- <view style="background: #FFFFFF;">
                        <view style="padding: 0 30rpx;"> -->
          <!-- <u-form-item label="特种设备" label-position="top" :label-width="150">
            <u-radio-group v-model="specialEquipmentValue">
              <u-radio
                v-for="(item, index) in specialEquipmentList"
                :key="index"
                :name="item.name"
              >
                {{ item.name }}
              </u-radio>
            </u-radio-group>
          </u-form-item> -->
          <!-- </view>
                    </view> -->
          <template v-if="specialEquipmentValue === '是'">
            <!-- <view style="background: #FFFFFF;">
                            <view style="padding: 0 30rpx;"> -->
            <u-form-item
              label="是否有安全附件"
              label-position="top"
              :label-width="150"
            >
              <u-radio-group v-model="safetyValue">
                <u-radio
                  v-for="(item, index) in safetyList"
                  :key="index"
                  :name="item.name"
                >
                  {{ item.name }}
                </u-radio>
              </u-radio-group>
            </u-form-item>

            <!-- </view>
                        </view> -->
            <eagle-checkbox-group
              v-model="model.secureAttach"
              title="安全附件"
              prop="secureAttach"
              :data-source="params.SiteEquipmentSecureAttachArray"
              v-if="safetyValue === '是'"
              label-position="top"
            />
          </template>
          <template v-if="specialEquipmentValue === '是'">
            <view
              class="device"
              v-for="(item, index) in model.specialEquipmentList"
            >
              <view class="device-content">
                <div class="title">
                  <span v-if="model.id">
                    特种设备
                  </span>
                  <span v-else>
                    特种设备{{ index + 1 }}
                  </span>
                </div>
                <eagle-input
                  v-model="item.equipmentNumber"
                  title="设备编号"
                  labelPosition="top"
                  labelWidth="150"
                  key="equipmentNumber1"
                />

                <eagle-date
                  title="登记时间"
                  type="datetime"
                  v-model="item.registerDate"
                  @change="registerDateChange(item)"
                />
                <eagle-file-upload
                  :maxCount="10"
                  title="使用登记证"
                  prop="attachs"
                  v-model="item.registerCertificateFile"
                />
                <eagle-file-upload
                  :maxCount="10"
                  title="特种设备检测"
                  prop="attachs"
                  v-model="item.equipmentSpecialCheckFile"
                />
                <eagle-file-upload
                  :maxCount="10"
                  title="检测报告"
                  prop="attachs"
                  v-model="item.equipmentSpecialCheckReportFile"
                />
              </view>
            </view>
          </template>
        </template>
        <template v-else>
          <eagle-file-upload
            title="设备资料"
            :maxCount="2"
            prop="attachs"
            v-model="model.attachs"
            labelWidth="150"
          />
          <eagle-input
            v-model="model.maintenanceAttention"
            title="维保事项"
            prop="maintenanceAttention"
            labelPosition="top"
            labelWidth="150"
            type="textarea"
            placeholder="请输入维保事项"
            :isChoose="true"
            key="maintenanceAttention2"
          >
            <template slot="topBotton">
              <u-button
                class="bottom-btn"
                type="primary"
                size="mini"
                @click="choose"
                >选择维保事项
              </u-button>
            </template>
          </eagle-input>
          <eagle-select
            v-model="model.maintenanceFrequency"
            title="维护保养频次"
            prop="maintenanceFrequency"
            labelPosition="top"
            :height="70"
            :data-source="params.fireFrequency"
            labelWidth="150"
            key="maintenanceFrequency2"
          >
          </eagle-select>
          <eagle-input
            v-model="model.remarks"
            title="备注"
            prop="remarks"
            labelPosition="top"
            labelWidth="150"
            type="textarea"
            placeholder="请输入备注"
            key="remarks2"
          />
        </template>
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button type="primary" class="bottom-btn" @click="post()"
        >保存</u-button
      >
    </eagle-bottom-view>
    <u-toast ref="uToast" />

    <popup-window
      ref="popupWindow"
      :isMult="true"
      headTitle="选择维保内容"
      idField="code"
      textField="title"
      controller="site/maintenanceTemp"
      dataType="list"
      :names.sync="model.maintenanceContent"
      v-model="model.maintenanceContent"
      :isUseEnterprise="false"
      @callBackChoosedData="callBackChoosedData"
    >
      <template v-slot:body="scope">
        <view>
          <view class="c333"> {{ scope.item.title }}</view>
          <view> {{ scope.item.content }}</view>
        </view>
      </template>
    </popup-window>
  </view>
</template>

<script>
import popupWindow from "@/components/eagle-window-choose/popup-window.vue";
import FastChooseBuild from "@/pages/host/ent/building/components/fast-choose-build.vue";
export default {
  components: { "popup-window": popupWindow, FastChooseBuild },
  data() {
    return {
      sectionCurrent: 0,
      deviceCount: 0,
      radioList: ["基础信息", "编辑更多信息"],
      model: {},
      errorType: ["message"],
      control: "site/entEquipment",
      labelPosition: "top",
      labelWidth: "150",
      type: "",
      initUrl: `site/entEquipment/initData/0?code=${this.$route.query.code}`,
      deletable: true,
      specialEquipmentList: [{ name: "是" }, { name: "否" }],
      safetyList: [{ name: "是" }, { name: "否" }],
      params: {
        ProjectBuildStructureArray: [],
        SiteEquipmentSecureAttachArray: [],
        fireFrequency: [],
        // fire_frequency
      },
      numberBoxValue: 0,
      boolInitData: false,
      specialEquipmentValue: "",
      safetyValue: "",
      // initParams: {
      //     code: "",
      // },
      dialogShow: false,
    };
  },
  created() {
    this.model.id = this.$route.query.id;

    if (this.model.id > 0) {
      uni.setNavigationBarTitle({ title: "编辑设备设施" });
      this.boolInitData = true;
    } else {
      this.boolInitData = false;
    }
    this.initData();
  },

  watch: {
    // specialEquipmentValue: function (val) {
    //   if (this.model.id) {
    //     return;
    //   }
    //   if (val == "是") {
    //     if (this.model.equipmentCount > 0) {
    //       this.model.specialEquipmentList = [];
    //       for (let i = 0; i < this.model.equipmentCount; i++) {
    //         this.model.specialEquipmentList.push({
    //           equipmentNumber: "",
    //           registerDate: "",
    //           registerCertificateFile: [],
    //           equipmentSpecialCheckFile: [],
    //           equipmentSpecialCheckReportFile: [],
    //         });
    //       }
    //     }
    //   } else {
    //     this.model.specialEquipmentList = [];
    //   }
    // },
    "model.equipmentCount"(newValue, oldValue) {
      if (this.model.id) {
        return;
      }
      if (newValue == 0) {
        this.model.specialEquipmentList = [];
        return;
      }
      if ((newValue > oldValue) || !oldValue) {
        this.model.specialEquipmentList.push({
          equipmentNumber: "",
          registerDate: "",
          registerCertificateFile: [],
          equipmentSpecialCheckFile: [],
          equipmentSpecialCheckReportFile: [],
        });
      } else {
        this.model.specialEquipmentList.pop();
      }
    },
  },

  mounted() {
    // this.initParams.code = this.$route.query.code;
    // let _this = this;
    // setTimeout(() => {
    //     let action = this.$refs.eagleForm.getAction();
    //     if (action == "init") {
    //         let url = "site/entEquipment/initData/0";
    //         this.common.get(url, this.initParams).then(function (res) {
    //             if (res.code === 200) {
    //                 _this.model = res.data;
    //             } else {
    //             }
    //             uni.hideToast();
    //         });
    //     }
    // });
  },

  methods: {
    queryPage() {
      setTimeout(() => {
        this.$refs.eaglePageList.search();
      });
    },

    initCallBack(data) {
      // if (this.model.equipmentType === "true") {
      //   this.specialEquipmentValue = "是";
      // } else if (this.model.equipmentType === "false") {
      //   this.specialEquipmentValue = "否";
      // }
  
      this.specialEquipmentValue = "是";
      this.model.equipmentType = "true"
      //
      if (this.model.isAttached === true) {
        this.safetyValue = "是";
      } else if (this.model.isAttached === false) {
        this.safetyValue = "否";
      }
      this.model.locationCode = this.$route.query.code;
    },
    handlerRadioClick(item, index) {
      console.log("item,index: ", item, index);
      this.radioIndex = index;
    },

    handlerSectionChange(index) {
      console.log("item,index: ", index);
      this.sectionCurrent = index;
      let name = this.model.locationName;
      this.model.locationName = "null";
      let timer = setTimeout(() => {
        this.model.locationName = name;
        clearTimeout(timer);
      }, 100);
    },

    initData() {
      console.log("111: ", 111);
      let _this = this;

      this.common
        .getparamsList(
          "site_equipment_secure_attach,end_building_structure,fire_frequency"
        )
        .then((res) => {
          console.log(res);
          if (res.code === 200) {
            this.params.ProjectBuildStructureArray = res.data.filter((item) => {
              return item.paramId === "end_building_structure";
            });
            this.params.SiteEquipmentSecureAttachArray = res.data.filter(
              (item) => {
                return item.paramId === "site_equipment_secure_attach";
              }
            );
            this.params.fireFrequency = res.data.filter((item) => {
              return item.paramId === "fire_frequency";
            });
          }
        });
    },

    choose() {
      this.$refs.popupWindow.show();
    },
    callBackChoosedData(choosedData) {
      // if (choosedData.length > 0) {
      //     var item = choosedData[0];

      //     this.model.maintenanceAttention = item.content ?? "";
      // }

      if (choosedData.length > 0) {
        var i = 0;
        let _this = this;
        _this.model.maintenanceAttention = "";
        choosedData.forEach(function (item) {
          i = i + 1;
          _this.model.maintenanceAttention =
            _this.model.maintenanceAttention.concat(
              i + ": ",
              item.content ? item.content : "",
              "\r\n"
            );
          // arry.push(i + item.content || "");
          // i++;
        });
        // this.model.maintenanceAttention = arry.join(",");
        // this.model.maintenanceContentCode = item.code;
      }

      this.dialogShow = false;
    },

    post() {
      if (this.sectionCurrent === 0) {
        if (this.model.orgName === "") {
          this.$refs.uToast.show({
            title: "请输入部门",
            type: "error",
          });
          return;
        }

        if (this.model.equipmentName === "") {
          this.$refs.uToast.show({
            title: "请输入设备名称",
            type: "error",
          });
          return;
        }

        // if (this.model.equipmentModel === "") {
        //     this.$refs.uToast.show({
        //         title: "请输入设备型号",
        //         type: "error",
        //     });
        //     return;
        // }

        if (this.model.equipmentCount <= 0) {
          this.$refs.uToast.show({
            title: "设备数量要大于0",
            type: "error",
          });
          return;
        }
      }

      if (this.specialEquipmentValue === "是") {
        this.model.equipmentType = true;
      } else if (this.specialEquipmentValue === "否") {
        this.model.equipmentType = false;
      }

      if (this.safetyValue === "是") {
        this.model.isAttached = true;
      } else if (this.safetyValue === "否") {
        this.model.isAttached = false;
      }

      //

      var url = "site/entEquipment/saveEquipment";
      if (this.model.id > 0) {
        //编辑保存
        url = "site/entEquipment/save";
      }

      // 处理文件上传的数据格式
      if (
        this.model?.specialEquipmentList &&
        this.model.specialEquipmentList?.length > 0
      ) {
        this.model?.specialEquipmentList?.forEach((item) => {
          if (item?.registerCertificateFile?.length > 0) {
            item.registerCertificateFile.forEach((it) => {
              it.fileName = it.name;
              it.attachs = it.filePath;
            });
          }
          if (item?.equipmentSpecialCheckFile?.length > 0) {
            item.equipmentSpecialCheckFile.forEach((it) => {
              it.fileName = it.name;
              it.attachs = it.filePath;
            });
          }
          if (item?.equipmentSpecialCheckReportFile?.length > 0) {
            item.equipmentSpecialCheckReportFile.forEach((it) => {
              it.fileName = it.name;
              it.attachs = it.filePath;
            });
          }
        });
      }
  
      this.$refs.eagleForm.post({
        needValid: true,
        url: url,
        validCallback: () => {
          return true;
        },
        successCallback: (res) => {
          this.close();
        },
        errorCallback: (res) => {
          return;
        },
      });
    },
    del() {
      let _this = this;
      if (this.model.id == 0) {
        this.close();
        return;
      }

      let url = this.control + "/delete/" + this.model.id;
      this.$refs.eagleForm.del({
        url: url,
        successCallback: function () {
          _this.close();
        },
      });
    },

    countChange(e) {
      this.deviceCount = e.value;
    },

    registerDateChange(item) {
      if (!this.checkTimeFormat(item.registerDate)) {
        let date = new Date();
        let hours = date.getHours().toString().padStart(2, '0');
        let minutes = date.getMinutes().toString().padStart(2, '0');
        let seconds = date.getSeconds().toString().padStart(2, '0');
        item.registerDate += hours+":"+minutes+":"+seconds;
      }
    },

    checkTimeFormat(time) {
      var reg = /^(?:19|20)[0-9][0-9]-(?:(?:0[1-9])|(?:1[0-2]))-(?:(?:[0-2][1-9])|(?:[1-3][0-1])) (?:(?:[0-2][0-3])|(?:[0-1][0-9])):[0-5][0-9]:[0-5][0-9]$/;
      return reg.test(time);
    },


    close() {
      this.base.navigateBack();
      uni.$emit("_update_equipment_list");
    },
  },
};
</script>

<style scoped lang="scss">
.equipment-facilities-detail-container {
  /* padding: 15rpx; */
  box-sizing: border-box;
  overflow: hidden;
  height: 100%;
}
.device {
  width: 100%;
  padding: 20rpx;
  .device-content {
    border: 1px solid #d2d2e6;
    width: 100%;
    min-height: 400rpx;
    border-radius: 6px;
    .title {
      font-size: 32rpx;
      color: #02a7f0;
      padding: 10rpx;
    }
  }
}
</style>
