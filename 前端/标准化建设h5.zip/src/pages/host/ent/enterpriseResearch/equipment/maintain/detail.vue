<template>
    <view class="maintain-detail-container">

        <eagle-form :queryParams="queryParams" @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" labelWidth="150" labelAlign='left'>
            <eagle-container title="设备信息">
                <eagle-text title="设备名称" v-model="equData.equipmentName" />
                <eagle-text title="维护保养频次">
                    {{equData.maintenanceFrequency|splitParamsFormat(params.fireFrequency)}}
                </eagle-text>
                <eagle-text title="维保事项" v-model="equData.maintenanceAttention">
                </eagle-text>
            </eagle-container>
            <eagle-container title="维保信息">
                <eagle-date v-model="model.maintenanceDate" title="维保日期" prop="maintenanceDate" labelWidth="150" labelPosition="top" required @change="dateCallback"></eagle-date>
                <eagle-date v-model="model.nextMaintenanceDate" title="下次维保日期" prop="nextMaintenanceDate" labelPosition="top" required></eagle-date>
                <eagle-input v-model="model.maintenanceChnName" title="维保人" prop="maintenanceChnName" labelPosition="top" labelWidth="150" required />
                <eagle-input v-model="model.maintenanceContent" title="维保内容" prop="maintenanceContent" labelPosition="top" type='textarea' labelWidth="150" :isChoose="true" @choose="choose" required />
                <eagle-input v-model="model.remarks" title="备注" prop="remarks" labelPosition="top" type='textarea' labelWidth="150" />
                <eagle-upload title="维保图片" :maxCount="3" prop="attach" v-model="model.attach" labelPosition="top" labelWidth="150" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <popup-window ref="popupWindow" :isMult="true" headTitle="选择维保内容" idField="code" textField="title" controller="site/maintenanceTemp" dataType="list" :names.sync="model.maintenanceContent" v-model="model.maintenanceContent" :isUseEnterprise="false" @callBackChoosedData="callBackChoosedData">
            <template v-slot:body="scope">
                <view>
                    <view class="c333"> {{scope.item.title}}</view>
                    <view> {{scope.item.content}}</view>
                </view>
            </template>
        </popup-window>
    </view>
</template>

<script>
import popupWindow from "@/components/eagle-window-choose/popup-window.vue";
import { getNextDate } from "@/common/dateUtil";
export default {
    components: {
        "popup-window": popupWindow,
    },
    data() {
        return {
            model: {},
            equData: {},
            companyCode: "",
            code: "",
            queryParams: {
                mainCode: "",
            },
            control: "site/maintenance",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            params: {
                fireFrequency: [],
            },
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.queryParams.mainCode = this.$route.query.mainCode;
        this.model.mainCode = this.mainCode;
        this.initData();
        this.getEquData();
    },
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        initData() {
            this.common.getparamsList("fire_frequency").then((res) => {
                if (res.code === 200) {
                    this.params.fireFrequency = res.data.filter((item) => {
                        return item.paramId === "fire_frequency";
                    });
                }
            });
        },
        getEquData() {
            let url =
                "site/entEquipment/getDataByCode/" + this.queryParams.mainCode;
            this.common.get(url, {}).then((res) => {
                if (res.success) {
                    this.equData = res.data;
                }
            });
        },

        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },

        choose() {
            setTimeout(() => {
                // this.$refs.eaglePageList.search();
                this.$refs.popupWindow.show();
            });
        },

        callBackChoosedData(choosedData) {
            var i = 0;
            let _this = this;
            _this.model.maintenanceContent = "";
            if (choosedData.length > 0) {
                choosedData.forEach(function (item) {
                    i = i + 1;
                    _this.model.maintenanceContent =
                        _this.model.maintenanceContent.concat(
                            i + ": ",
                            item.content ? item.content : "",
                            "\r\n"
                        );
                });
            }
            this.dialogShow = false;
        },
        dateCallback(e) {
            if (this.equData.id) {
                this.model.nextMaintenanceDate = getNextDate(
                    e,
                    this.equData.maintenanceFrequency
                );
            }
        },
    },
};
</script>

<style scoped lang="scss">
.maintain-detail-container {
    // padding: 15rpx;
    box-sizing: border-box;

    .maintain-detail-title {
        height: 80rpx;
        line-height: 80rpx;
        font-size: 40rpx;
        font-weight: 600;
        padding-left: 30rpx;
        box-sizing: border-box;
    }
}
</style>
