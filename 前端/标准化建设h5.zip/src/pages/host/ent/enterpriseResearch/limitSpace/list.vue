<template>
    <view class="finite-space-list-container">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="marginBottom" :queryParams="queryParams">
            <view slot="search">
                <eagle-search placeholder="请输入有限空间名称进行搜索" v-model="searchValue" @custom="search" @search="search" :show-action="false" @clear="search"></eagle-search>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.spacePhoto" @click="handlerBody(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.spaceName }}
                        <template slot="icon">
                            {{ item.locationName }}
                        </template>
                    </eagle-row-view>
                    <eagle-row-view>
                        <view class="circleShow">
                            编号：{{ item.no }}
                        </view>
                    </eagle-row-view>
                    <eagle-girdrow-base>
                        <view>
                            <template v-if="item.spaceTypeArr && item.spaceTypeArr.length > 0">
                                <u-tag size="mini" v-for="(item1, index) in item.spaceTypeArr" :key='index + "spaceTypeArr"' :text="item1" style="margin: 5rpx;" />
                            </template>
                        </view>
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        <template v-if="item.mainRiskCodeArr && item.mainRiskCodeArr.length > 0">
                            <u-tag size="mini" type="error" v-for="(item1, index) in item.mainRiskCodeArr" :key='index + "mainRiskCodeArr"' :text="item1" style="margin: 5rpx;" />
                        </template>
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" @click="handlerDel(item)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerBodyClick(item)" size="mini">编辑</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view >
                    <view class="uni-media-cell" v-for="(item, index) in list" :key="item.id">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body">
                                <view class="card-content">
                                    <view class="card-content-img">
                                        <image style="width: 250rpx;height: 150rpx;" :src="item.spacePhoto?item.spacePhoto:noImgUrl" mode="aspectFill"></image>
                                    </view>
                                    <view class="card-content-body" @click="handlerBody(item)">
                                        <eagle-girdrow-base :isTitle="true">
                                            <eagle-girdrow-block>{{item.spaceName}}</eagle-girdrow-block>
                                        </eagle-girdrow-base>
                                        <eagle-girdrow-base>
                                            <view class="circleShow">
                                                编号：{{item.no}}
                                            </view>
                                            <view class="circleShow">
                                                <template v-if="item.spaceTypeArr&&item.spaceTypeArr.length>0">
                                                    <u-tag size="mini" v-for="(item1,index) in item.spaceTypeArr" :key='index+"spaceTypeArr"' :text="item1" style="margin: 5rpx;" />
                                                </template>
                                                <template v-if="item.mainRiskCodeArr&&item.mainRiskCodeArr.length>0">
                                                    <u-tag size="mini" type="error" v-for="(item1,index) in item.mainRiskCodeArr" :key='index+"mainRiskCodeArr"' :text="item1" style="margin: 5rpx;" />
                                                </template>

                                            </view>
                                        </eagle-girdrow-base>
                                    </view>
                                </view>
                            </view>
                        </view>
                        <eagle-grid-botton>
                            <u-icon class="eagle-red eagle-row-span" name="trash" label="删除" @click="handlerDel(item)" />
                            <u-icon name="edit-pen" label="编辑" @click="handlerBodyClick(item)"></u-icon>
                        </eagle-grid-botton>
                    </view>
                </view> -->
            </view>
        </eagle-page-list>
        <eagle-fab v-if="!isAll" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
    </view>
</template>

<script>
export default {
    name: "limitSpace-list",
    props: {
        name: {
            type: String,
            default() {
                return "";
            },
        },
        code: {
            type: String,
            default() {
                return "";
            },
        },
        isAll: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            controller: "site/space",
            list: [],
            marginBottom: 160,
            searchValue: "",
            // fabContent: [{
            //     iconPath: "../../../static/img/AppIcon/icon_list_add.png",
            //     selectedIconPath: "../../../static/img/AppIcon/icon_list_add.png",
            //     text: "新增",
            //     active: true,
            // },
            // {
            //     iconPath: "../../../static/img/AppIcon/icon_camera.png",
            //     selectedIconPath: "../../../static/img/AppIcon/icon_camera.png",
            //     text: "拍照",
            //     active: false,
            // },
            // ],
            params: {
                siteSpaceTypeArray: [],
                siteSpaceDangerArray: [],
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
            noImgUrl: require("@/static/img/no-img.png"),
        };
    },
    created() {
        this.queryParams.code = this.$route.query.code ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";

        if (this.isAll) {
            this.marginBottom = 60;
        } else {
            this.marginBottom = 140;
        }

        this.initData();
        this.queryPage();
    },
    mounted() {
        // this.queryParams.enterpriseCode = this.$route.query.enterpriseCode
        // this.queryParams.projectId = this.$route.query.projectId
        // this.queryParams.code = this.$route.query.code
        // this.search()
        // this.initData()
    },
    methods: {
        queryPage() {
            var conditions = [];
            // [{"name":"spaceName","operate":"like","value":"111"}]
            if (this.searchValue) {
                conditions.push({
                    name: "spaceName",
                    value: this.searchValue,
                    operate: "like",
                });
            }
            setTimeout(() => {
                this.$refs.eaglePageList.search({ conditions: conditions });
            });
        },

        initList(data) {
            this.list = [];
            this.list = data;

            for (let i = 0; i < this.list.length; i++) {
                let item = this.list[i];

                if (item.spaceType != "") {
                    let spaceType = this.common.splitParamsFormat(
                        item.spaceType,
                        this.params.siteSpaceTypeArray
                    );
                    // item.spaceTypeArr = spaceType.split(",");
                    // this.$set(item, "spaceTypeArr", spaceType.split(","));
                    if (spaceType) {
                        this.$nextTick(() => {
                            this.$set(
                                item,
                                "spaceTypeArr",
                                spaceType.split(",")
                            );
                        });
                    }
                }

                if (item.mainRiskCode != "") {
                    let mainRiskCode = this.common.splitParamsFormat(
                        item.mainRiskCode,
                        this.params.siteSpaceDangerArray
                    );
                    // item.mainRiskCodeArr = mainRiskCode.split(",");
                    // this.$set(item, "mainRiskCodeArr", mainRiskCode.split(","));
                    if (mainRiskCode) {
                        this.$nextTick(() => {
                            this.$set(
                                item,
                                "mainRiskCodeArr",
                                mainRiskCode.split(",")
                            );
                        });
                    }
                }

                if (item.spacePhoto.includes(";")) {
                    let photo = item.spacePhoto.split(";");
                    // item.spacePhoto = photo[0];
                    this.$set(item, "spacePhoto", photo[0]);
                }
            }
            console.log("this.list: ", this.list);
        },
        initData() {
            this.common
                .getparamsList("site_space_type,site_space_danger")
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.siteSpaceTypeArray = res.data.filter(
                            (item) => {
                                return item.paramId === "site_space_type";
                            }
                        );
                        this.params.siteSpaceDangerArray = res.data.filter(
                            (item) => {
                                return item.paramId === "site_space_danger";
                            }
                        );
                    }
                });
            // this.queryPage()
        },

        search(val) {
            console.log("val: ", val);
            this.queryParams.enterpriseCode =
                this.$route.query.enterpriseCode ?? "";
            this.queryParams.projectId = this.$route.query.projectId ?? "";
            this.queryParams.code = this.$route.query.code ?? "";

            //小参只拉取一次
            if (
                this.params.siteSpaceTypeArray.length > 0 &&
                this.params.siteSpaceDangerArray.length > 0
            ) {
                this.queryPage();
            } else {
                this.initData();
            }
        },

        handlerBody(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/limitSpace/view",
                {
                    type: "look",
                    id: item.id,
                    code: this.code,
                    name: this.name,
                    tabContentIndex: 3,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },

        handlerBodyClick(item, index) {
            // console.log("item,index: ", item, index)
            // let url =
            //     "pages/host/ent/enterpriseResearch/limitSpace/detail?type=look&id=" +
            //     item.id +
            //     "&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode
            // }
            // if (this.$route.query.projectId) {
            //     url =
            //         url + "&projectId=" + this.$route.query.projectId
            // }

            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/limitSpace/detail",
                {
                    type: "look",
                    id: item.id,
                    code: this.code,
                    name: this.name,
                    tabContentIndex: 3,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },
        handlerDel(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/limitSpace/detail",
                {
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        trigger(e) {
            // this.fabContent.forEach((item, index) => {
            //     item.active = false
            //     if (index === e.index) {
            //         item.active = true
            //     }
            // })
            if (e.index === 0) {
                this.handlerFabClick();
            }
        },
    },
};
</script>
<style scoped lang="scss">
.card-content {
    display: flex;

    .card-content-img {
        margin-right: 20rpx;
    }

    .card-content-body {
        flex: 1 1;
    }
}

.circleShow {
    height: 50rpx;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;
}
</style>
