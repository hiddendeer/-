<template>
    <view class="finite-space-detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :boolInitData="boolInitData">
            <eagle-container title="有限空间详情">
                <eagle-text title="有限空间照片">
                    <eagle-display-image :value="model.spacePhoto" />
                </eagle-text>
                <eagle-text title="空间编号" v-model="model.no" />
                <eagle-text title="有限空间名称" v-model="model.spaceName" />
                <eagle-text title="管理部门" v-model="model.orgName" />
                <eagle-text title="有限空间类型">
                    {{model.spaceType|splitParamsFormat(params.siteSpaceTypeArray)}}
                </eagle-text>
                <eagle-text title="主要风险">
                    {{model.mainRiskCode|splitParamsFormat(params.siteSpaceDangerArray)}}
                </eagle-text>
                <eagle-text title="警示标识">
                    <view class="space-item" v-for="(item,index) in imgUrlList" :key='item.imgCode' :class="{'active':activeIndex===index}" v-if="item.imgCode == model.warningSignCode">
                        <image style="width: 200rpx;height: 160rpx;" :src="item.imgUrl" mode=""></image>
                    </view>
                </eagle-text>
                <eagle-text title="备注" v-model="model.remarks" />
            </eagle-container>
            <!-- <eagle-display-image title="有限空间照片" :value="model.spacePhoto" />

            <eagle-display-input v-model="model.no" title="空间编号" prop="no"></eagle-display-input>

            <eagle-display-input v-model="model.spaceName" title="有限空间名称" prop="spaceName"></eagle-display-input>
            <eagle-display-input v-model="model.orgName" title="管理部门" prop="orgName"></eagle-display-input>
            <eagle-display-input :value="model.spaceType|splitParamsFormat(params.siteSpaceTypeArray)" title="有限空间类型" prop="spaceType"></eagle-display-input>

            <eagle-display-input :value="model.mainRiskCode|splitParamsFormat(params.siteSpaceDangerArray)" title="主要风险" prop="mainRiskCode"></eagle-display-input> -->

            <!-- <view style="background: #FFFFFF;">
                <view style="padding: 0 30rpx;">
                    <u-form-item label="警示标识" prop="warningSignCode" labelPosition="top">
                        <view style="display: flex;justify-content: space-between;width: 100%;align-items: center;">
                            <view class="space-item" v-for="(item,index) in imgUrlList" :key='item.imgCode' :class="{'active':activeIndex===index}" v-if="item.imgCode == model.warningSignCode">
                                <image style="width: 200rpx;height: 160rpx;" :src="item.imgUrl" mode=""></image>
                            </view>
                        </view>
                    </u-form-item>
                </view>
            </view> -->

            <!-- <eagle-display-input v-model="model.remarks" title="备注" prop="remarks"></eagle-display-input> -->
        </eagle-form>

    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/space",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            boolInitData: true,
            params: {
                siteSpaceTypeArray: [],
                siteSpaceDangerArray: [],
            },
            initParams: {
                code: "",
                name: "",
                companyCode: "",
                projectId: "",
            },
            imgUrlList: [
                {
                    imgUrl: require("@/static/safety_alert_card_min.jpg"),
                    // imgViewUrl: require("@/assets/images/view/host/safety_alert_card.jpg"),
                    imgCode: "safety_alert",
                },
                {
                    imgUrl: require("@/static/safety_notice_board_min.jpg"),
                    // imgViewUrl: require("@/assets/images/view/host/safety_notice_board.jpg"),
                    imgCode: "safety_notice",
                },
                {
                    imgUrl: require("@/static/danger_min.jpg"),
                    // imgViewUrl: require("@/assets/images/view/host/danger_min.jpg"),
                    imgCode: "danger",
                },
            ],
            activeIndex: -1,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.model.id = this.$route.query.id;
        if (this.model.id !== "0") {
            this.boolInitData = true;
        } else {
            this.boolInitData = false;
        }
        this.initData();
    },

    mounted() {
        this.initParams.code = this.$route.query.code ?? "";
        this.initParams.name = this.$route.query.name ?? "";
        this.initParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";

        this.initParams.projectId = this.$route.query.projectId ?? "";

        let _this = this;
        setTimeout(() => {
            let action = this.$refs.eagleForm.getAction();
            if (action == "init") {
                let url = "site/space/initData/0";
                this.common.get(url, this.initParams).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data;
                    } else {
                    }
                    uni.hideToast();
                });
            }
        });
    },

    methods: {
        initCallBack(data) {
            this.model = data;
            this.imgUrlList.forEach((item, index) => {
                if (this.model.warningSignCode === item.imgCode) {
                    this.activeIndex = index;
                }
            });
        },
        handlerRadioClick(item, index) {
            this.radioIndex = index;
        },
        initData() {
            let _this = this;
            this.enterpriseCode = this.$route.query.enterpriseCode;
            this.common
                .getparamsList("site_space_type,site_space_danger")
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.siteSpaceTypeArray = res.data.filter(
                            (item) => {
                                return item.paramId === "site_space_type";
                            }
                        );
                        this.params.siteSpaceDangerArray = res.data.filter(
                            (item) => {
                                return item.paramId === "site_space_danger";
                            }
                        );
                    }
                });
        },
        buildStructureClick(item, index) {
            this.activeIndex = index;
            console.log("item: ", item);
            this.model.warningSignCode = item.imgCode;
            console.log("this.model: ", this.model);
        },
        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },

        del() {
            let _this = this;
            if (this.model.id == 0) {
                this.close();
                return;
            }

            let url = this.control + "/delete/" + this.model.id;
            this.$refs.eagleForm.del({
                url: url,
                successCallback: function () {
                    _this.close();
                },
            });
        },

        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style lang="scss">
.finite-space-detail-container {
    /* padding: 15rpx; */
    box-sizing: border-box;

    .space-item {
        padding: 20rpx;
        // border: 2rpx solid #cccccc;
        // border-radius: 10rpx;
        display: flex;
        // justify-content: center;
        align-items: left;

        // &.active {
        //     border-color: #2979ff;
        //     background: #2979ff;
        // }
    }
}
</style>
