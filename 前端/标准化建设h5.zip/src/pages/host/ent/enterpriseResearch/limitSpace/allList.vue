<template>
    <view>
        <limitSpace-list ref="LimitSpaceList" isAll="Y"></limitSpace-list>
		<tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
		<tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import LimitSpaceList from "./list.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";

export default {
    components: { 
		LimitSpaceList,
		TabbarHost,
		TabbarSite
	},
    data() {
        return {
            state: "show",
			queryParams: {
				enterpriseCode: "",
			},
        };
    },
    created() {
        console.log("父组件初始化3333");
    },
    mounted() {
		this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        this.search();
    },
    onload() {
        console.log("mylist is onload");
    },
    onShow() {
		
        this.search();
    },
    onHide: function () {
        this.state = "hidden";
    },
    methods: {
        search() {
            if (this.$refs.LimitSpaceList) {
                this.$refs.LimitSpaceList.queryPage();
            }
        },
    },
    computed: {
        routerCategory() {
            return this.$route.query.modulesId;
        },
    },
};
</script>
