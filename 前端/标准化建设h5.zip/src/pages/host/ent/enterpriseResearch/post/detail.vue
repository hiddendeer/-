<template>
    <view>
        <eagle-form :boolInitData="boolInitData" @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left' selfHeight="calc(100vh - 125px)">
            <eagle-container>
                <fast-choose-build required title="所在区域" v-model="model.locationName" :name.sync="model.locationCode" />
                <eagle-input v-model="model.orgName" required title="部门" maxlength="20" prop="orgName" labelPosition="top" labelWidth="130" />

                <eagle-input v-model="model.jobPosition" required title="岗位名称" maxlength="20" prop="jobPosition" labelPosition="top" labelWidth="130" />

                <u-form-item label="员工人数" label-position='top' :label-width='150'>
                    <u-number-box v-model="model.stuffNumber" :inputWidth="160"></u-number-box>
                </u-form-item>
                <eagle-window-choose title="职业病危害因素" placeholderVal="请选择职业病危害因素" headTitle='职业病危害因素' v-model="model.occupationalHazardFactors" :isMult="true" :names.sync="model.occupationalHazardFactors" showDetail="true" controller="support/healthHazardFactors" :maxCount="9" idField="title" textField="title" labelPosition="top" labelWidth="130"></eagle-window-choose>
                <!-- <eagle-mark-choose labelPosition="top" labelWidth="130" ></eagle-mark-choose> -->
                <eagle-choose-input title="劳保要求" headTitle='劳保要求' :hasSearch="false" v-model="laborProtectionRequirementCnt" @callBackChoosedData="callBackChoosedData" :isMult="true" controller="/support/riskMark" idField="markCode" textField="markName">
                    <template v-slot:popupBody='scope'>
                        <view>
                            <view style="display:flex;">
                                <img class="u-preview-image" :width="40" :height="40" :src="scope.item.markAttach" />
                                <span style="line-height:80rpx;" class="ml5">{{scope.item.markName}}</span>
                            </view>
                        </view>
                    </template>
                    <!-- {{laborProtectionRequirementCnt}} -->
                </eagle-choose-input>
                <template v-if="laborProtectionRequirementArry && laborProtectionRequirementArry.length > 0">
                    <eagle-row-list :allowDel="false" :list="laborProtectionRequirementArry">
                        <template slot="list" slot-scope="scope">
                            <view style="display:flex;">
                                <img class="u-preview-image" :width="40" :height="40" :src="scope.item.markAttach" />
                                <span class="eagle-row ml5">{{scope.item.markName}}</span>
                            </view>
                        </template>
                        <template slot="popupBody" slot-scope="scope">
                            <view style="display:flex;">
                                <img class="u-preview-image" :width="40" :height="40" :src="scope.item.markAttach" />
                                <span class="eagle-row ml5">{{scope.item.markName}}</span>
                            </view>
                        </template>
                    </eagle-row-list>
                </template>
                <eagle-file-upload title="相关检测报告" prop="checkReport" v-model="model.checkReport" />
                <eagle-file-upload title="其他职业健康文件" prop="heathAttach" v-model="model.heathAttach" />
                <!-- <eagle-upload title="相关检测报告" :maxCount="3" prop="remarks" v-model="model.checkReport" labelPosition="top" :deletable='deletable' labelWidth="130" />
            <eagle-upload title="其他职业健康文件" :maxCount="3" prop="其他职业健康文件" v-model="model.heathAttach" labelPosition="top" :deletable='deletable' labelWidth="130" />
			 -->
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()" v-if='$route.query.type !== "look"'>保存</u-button>
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
import eagleMarkChoose from "./components/eagle-mark-choose.vue";
import FastChooseBuild from "@/pages/host/ent/building/components/fast-choose-build.vue";
export default {
    components: { eagleMarkChoose, FastChooseBuild },
    data() {
        return {
            model: {
                stuffNumber: 0,
            },
            errorType: ["message"],
            control: "site/post",
            companyCode: "",
            type: "",
            params: {
                ProjectBuildStructureArray: [],
                buildRegulatoryfocusArray: [],
            },
            initParams: {
                code: "",
                name: "",
                companyCode: "",
            },
            deletable: true,
            boolInitData: false,
            codes: "",
        };
    },
    created() {
        this.initData();

        this.companyCode = this.$route.query.enterpriseCode;
        console.log("this.$route.query.id : ", this.$route.query.id);
        console.log("this.$route.query.type : ", this.$route.query.type);
        if (this.$route.query.id && this.$route.query.id !== "0") {
            this.deletable = false;
            this.boolInitData = true;
            uni.setNavigationBarTitle({ title: "编辑作业岗位" });
        } else {
            this.boolInitData = false;
        }
        if (this.$route.query.type && this.$route.query.type === "look") {
            uni.setNavigationBarTitle({ title: "查看详情" });
        }
    },
    computed: {
        laborProtectionRequirementCnt() {
            let num = 0;
            if (this.model.laborProtectionRequirement) {
                num = JSON.parse(this.model.laborProtectionRequirement).length;
            }
            return "已选择" + num + "项";
        },
        laborProtectionRequirementArry() {
            if (this.model.laborProtectionRequirement) {
                return JSON.parse(this.model.laborProtectionRequirement);
            }
            return [];
        },
    },
    mounted() {
        this.initParams.code = this.$route.query.code;
        this.initParams.name = this.$route.query.name;
        this.initParams.companyCode = this.$route.query.enterpriseCode;
        let _this = this;
        setTimeout(() => {
            let action = this.$refs.eagleForm.getAction();
            if (action === "init") {
                let url = "site/post/initData/0";
                this.common.get(url, this.initParams).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data;
                    } else {
                    }
                    uni.hideToast();
                });
            }
        });
    },
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        initData() {
            let _this = this;
            this.enterpriseCode = this.$route.query.enterpriseCode;
            this.common
                .getparamsList(
                    "end_building_structure,end_building_Regulatoryfocus"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.ProjectBuildStructureArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_structure"
                                );
                            });
                        this.params.buildRegulatoryfocusArray = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId ===
                                    "end_building_Regulatoryfocus"
                                );
                            }
                        );
                    }
                });
        },
        callBackChoosedData(val) {
            if (val == "") {
                this.model.laborProtectionRequirement = "";
            } else {
                this.model.laborProtectionRequirement = JSON.stringify(val);
            }
        },
        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },

        del() {
            let _this = this;
            if (this.model.id === 0) {
                this.close();
                return;
            }

            let url = this.control + "/delete/" + this.model.id;
            this.$refs.eagleForm.del({
                url: url,
                successCallback: function () {
                    _this.close();
                },
            });
        },

        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style lang="scss">
</style>
