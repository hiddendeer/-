<template>
    <view class="finite-space-list-container">
        <eagle-page-list :queryParams="queryParams" ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="marginBottom">
            <view slot="search">
                <eagle-search placeholder="请输入岗位名称进行搜索" v-model="searchValue" @custom="search" @search="search" :show-action="false" @clear="search"></eagle-search>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" @click="handlerBodyClick(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.orgName }}-{{ item.jobPosition }}
                        <!-- <template slot="icon">
                            {{ item.locationName }}
                        </template> -->
                    </eagle-row-view>
                    <view v-if="item.occupationalHazardFactors">
                        <u-tag :text="res" size="mini" mode="plain" v-for="(res, index) in item.occupationalHazardFactors.split(',')" :key='index + "occupationalHazardFactors"' style="margin: 5rpx;" />
                    </view>
                    <view>
                        所在区域： {{ item.locationName }}
                    </view>
                    <view>
                        <view class="circleShow" style="display: flex;height: 70rpx;line-height: 70rpx;align-items: center;">
                            <view style="white-space: nowrap;">劳保要求：</view>
                            <view class="circleShow" style="display: flex;align-items: center;width: 520rpx;">
                                <u-image style="margin-right: 5rpx;" width="50" height="50" :src="item1.markAttach" mode="aspectFit" v-for="(item1, index) in item.laborProtectionRequirementArr" :key='index'>
                                </u-image>
                                <view v-if="item.laborProtectionRequirementArr && item.laborProtectionRequirementArr.length >= 5">
                                    ...</view>
                            </view>
                        </view>
                        <view>
                            员工人数：{{ item.stuffNumber }}人
                        </view>
                    </view>
                    <template slot="button">
                        <u-button type="error" @click="handlerDel(item)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerEdit(item)" size="mini">编辑</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view >
                    <view class="uni-media-cell" v-for="(item, index) in list" :key="item.id">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body">
                                <view class="card-content">
                                    <view class="card-content-body" @click="handlerBodyClick(item)">
                                        <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                            <eagle-girdrow-block>{{item.orgName}}-{{item.jobPosition}}
                                            </eagle-girdrow-block>
                                            <eagle-girdrow-block type="warn" style='white-space: nowrap;'>
                                                员工：{{item.stuffNumber}}人
                                            </eagle-girdrow-block>
                                        </eagle-girdrow-base>
                                        <eagle-girdrow-base v-if="item.occupationalHazardFactors">
                                            <view class="circleShow" style="width: 650rpx;">
                                                <u-tag :text="res" size="mini" mode="plain" v-for="(res,index) in item.occupationalHazardFactors.split(',')" :key='index+"occupationalHazardFactors"' style="margin: 5rpx;" />
                                            </view>
                                        </eagle-girdrow-base>
                                        <eagle-girdrow-base>
                                            <view class="circleShow" style="display: flex;height: 70rpx;line-height: 70rpx;align-items: center;">
                                                <view style="white-space: nowrap;">劳保要求：</view>
                                                <view class="circleShow" style="display: flex;align-items: center;width: 520rpx;">
                                                    <u-image style="margin-right: 5rpx;" width="50" height="50" :src="item1.markAttach" mode="aspectFit" v-for="(item1,index) in item.laborProtectionRequirementArr" :key='index'>
                                                    </u-image>
                                                    <view v-if="item.laborProtectionRequirementArr&&item.laborProtectionRequirementArr.length>=5">
                                                        ...</view>
                                                </view>
                                            </view>
                                        </eagle-girdrow-base>
                                    </view>
                                </view>
                            </view>
                        </view>
                        <eagle-grid-botton>
                            <u-icon class="eagle-red eagle-row-span" name="trash" label="删除" @click="handlerDel(item)" />
                            <u-icon name="edit-pen" label="编辑" @click="handlerEdit(item)"></u-icon>
                        </eagle-grid-botton>
                    </view>
                </view> -->
            </view>
        </eagle-page-list>
        <eagle-fab v-if="!isAll" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>

    </view>
</template>

<script>
export default {
    // components: { TabbarHost },
    name: "post-list",
    props: {
        name: {
            type: String,
            default() {
                return "";
            },
        },
        code: {
            type: String,
            default() {
                return "";
            },
        },
        isAll: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            marginBottom: 140,
            searchValue: "",
            showBottom: false,
            getData: true,
            list: [],
            controller: "/site/post",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.queryParams.code = this.$route.query.code ?? "";

        if (this.isAll) {
            this.marginBottom = 60;
        } else {
            this.marginBottom = 140;
        }
    },
    mounted() {
        if (this.getData) {
            this.getData = false;
            this.queryPage();
        }
        //
    },
    onShow() {},
    methods: {
        initList(data) {
            this.list = [];
            this.list = data;
            // laborProtectionRequirement

            for (let i = 0; i < this.list.length; i++) {
                var item = this.list[i];

                let val = item.laborProtectionRequirement;

                if (val) {
                    if (typeof val === "string") {
                        var arryFile = JSON.parse(val);
                        item.laborProtectionRequirementArr = arryFile;
                        if (item.laborProtectionRequirementArr.length > 8) {
                            item.laborProtectionRequirementArr.length = 8;
                        }
                    } else {
                        item.laborProtectionRequirementArr = val;
                        if (item.laborProtectionRequirementArr.length > 8) {
                            item.laborProtectionRequirementArr.length = 8;
                        }
                    }
                }
            }
        },

        search() {
            this.queryPage();
        },
        queryPage() {
            var conditions = [];
            // [{"name":"spaceName","operate":"like","value":"111"}]
            if (this.searchValue) {
                conditions.push({
                    name: "jobPosition",
                    value: this.searchValue,
                    operate: "like",
                });
            }
            setTimeout(() => {
                this.$refs.eaglePageList.search({ conditions: conditions });
            });

            // setTimeout(() => {
            //     this.$refs.eaglePageList && this.$refs.eaglePageList.search();
            // });
        },

        handlerBodyClick(item, index) {
            // console.log("item,index: ", item, index);
            // let url =
            //     "pages/host/ent/enterpriseResearch/post/view?id=" +
            //     item.id +
            //     "&type=look&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url =
            //         url + "&projectId=" + this.$route.query.projectId;
            // }
            // this.base.navigateTo(url);

            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/post/view",
                {
                    id: item.id,
                    type: "look",
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerEdit(item, index) {
            // console.log("item,index: ", item, index);
            // let url =
            //     "pages/host/ent/enterpriseResearch/post/detail?id=" +
            //     item.id +
            //     "&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url =
            //         url + "&projectId=" + this.$route.query.projectId;
            // }
            // this.base.navigateTo(url);

            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/post/detail",
                {
                    id: item.id,
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerFabClick() {
            // let url =
            //     "pages/host/ent/enterpriseResearch/post/detail?id=0&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url =
            //         url + "&projectId=" + this.$route.query.projectId;
            // }
            // this.base.navigateTo(url);
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/post/detail",
                {
                    id: 0,
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerDel(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
    },
};
</script>

<style scoped lang="scss">
.finite-space-list-container {
    height: calc(100vh - 70px);

    .card-content {
        display: flex;

        .card-content-img {
            margin-right: 20rpx;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .card-content-body {
            flex: 1 1;
        }
    }

    .circleShow {
        height: 50rpx;
        // width: 100%;
        // overflow: hidden;
        // display: -webkit-box;
        // -webkit-box-orient: vertical;
        // -webkit-line-clamp: 1;
        line-height: 50rpx;

        width: 100%;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
</style>
