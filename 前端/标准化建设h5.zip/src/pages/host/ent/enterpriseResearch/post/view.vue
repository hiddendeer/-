<template>
    <view>
        <eagle-form :boolInitData="boolInitData" @initCallBack="initCallBack" :control="control" v-model="model"
            ref="eagleForm" selfHeight="calc(100vh - 125px)">
            <eagle-container title="作业岗位详情">
                <eagle-text v-model="model.orgName" title="部门"></eagle-text>
                <eagle-text v-model="model.jobPosition" title="岗位名称"></eagle-text>
                <eagle-text v-model="model.stuffNumber" title="员工人数"></eagle-text>
                <eagle-text v-model="model.occupationalHazardFactors" title="职业病危害因素"></eagle-text>
                <view>
                    <view style="padding: 8px 8px 5px 8px;">劳保要求：</view>
                    <template v-for="item in laborProtectionRequirement">
                        <image style="width: 60rpx;height: 60rpx;margin-right: 15rpx;" :src="item.markAttach"
                            mode="aspectFit"></image>
                    </template>
                </view>
                <eagle-text title="相关检测报告">
                    <eagle-file-upload disabled :maxCount="9" prop="checkReport" v-model="model.checkReport"
                        labelPosition="top" labelWidth="180" />
                </eagle-text>
                <eagle-text title="其他职业健康文件">
                    <eagle-file-upload disabled :maxCount="9" prop="heathAttach" v-model="model.heathAttach"
                        labelPosition="top" labelWidth="180" />
                </eagle-text>
            </eagle-container>
            <!-- <eagle-display-input title="部门" :value="model.orgName" />
            <eagle-display-input title="岗位名称" :value="model.jobPosition" />
            <eagle-display-input title="员工人数" :value="model.stuffNumber" />
            <eagle-display-input title="职业病危害因素" :value="model.occupationalHazardFactors" /> -->
            <!-- <eagle-display-input title="劳保要求"  :value="model.laborProtectionRequirement" /> -->

        </eagle-form>

    </view>
</template>

<script>
import eagleMarkChoose from "./components/eagle-mark.vue";
export default {
    components: {
        eagleMarkChoose,
    },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/post",
            companyCode: "",
            type: "",

            initParams: {
                code: "",
                name: "",
                companyCode: "",
            },
            deletable: true,
            boolInitData: true,
            laborProtectionRequirement: []
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;

    },
    mounted() {
        this.initParams.code = this.$route.query.code;
        this.initParams.name = this.$route.query.name;
        this.initParams.companyCode = this.$route.query.enterpriseCode;
    },
    methods: {
        initCallBack(data) {
            this.model = data;
            this.laborProtectionRequirement = JSON.parse(this.model.laborProtectionRequirement);
            console.log(this.laborProtectionRequirement, "============>");
        },
    },
};
</script>

<style lang="scss">
</style>
