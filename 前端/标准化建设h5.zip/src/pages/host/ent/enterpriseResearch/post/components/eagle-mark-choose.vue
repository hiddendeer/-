<template name="eagle-choose-user">

    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
        <view class="" style="width: 100%;height: auto;line-height: 50rpx;display: flex;flex-wrap: wrap;" @click="funDialogShow">
            <text style="width: 100%;height: 70rpx;font-size: 28rpx;color: rgb(192, 196, 204)" v-if='!this.choosedData.length>0' @click="funDialogShow">请选择劳保要求</text>
            <view v-for="(item,index) in choosedData" :key="index">
                <image style="width: 60rpx;height: 60rpx;margin-right: 15rpx;" :src="item.markAttach" mode="aspectFit"></image>
            </view>
        </view>
        <view v-show="this.choosedData.length>0" class="uni-date__icon-clear" :class="{border:'uni-date-clear'}" @click.stop="clear">
            <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
        </view>
        <popup-window headTitle='劳保要求' :hasSearch="false" idField="dCode" textField="markName" ref="popupWindow" :isMult="isMult" :headTitle="headTitle" :controller="controller" :dataType="dataType" :names.sync="myNames" v-model="codes" @change="setValues" :conditions="conditions" @callBackChoosedData="callBackChoosedData">
        </popup-window>
    </u-form-item>
</template>

<script>
import common from "@/common/common.js";
import popupWindow from "./popup-window.vue";
export default {
    name: "eagle-mark-choose",
    components: { "popup-window": popupWindow },
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        conditions: {
            type: Array,
            default() {
                return [];
            },
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
        placeholderVal: {
            type: String,
            default: "请选择",
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
        headTitle: {
            type: String,
            default() {
                return "";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        dataType: {
            type: String,
            default() {
                return "list";
            },
        },
        border: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
            choosedData: [],
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                if (nVal) {
                    this.codes = nVal;
                    console.log("nVal: ", nVal);
                    if (Array.isArray(nVal)) {
                        this.choosedData = nVal;
                    } else {
                        this.choosedData = JSON.parse(nVal);
                    }
                }
            }
        },
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        funDialogShow() {
            console.log("112233: ");
            // this.dialogShow=true

            this.$refs.popupWindow.show();
            // this.$refs.eaglePageList.search();
        },
        setValues(codes, names, markAttachs) {
            this.$emit("update:names", names);
            this.$emit("input", codes);
            this.$emit("change", codes, names, markAttachs);
        },

        callBackChoosedData(choosedData, codes, names) {
            this.choosedData = choosedData;
            this.$emit("update:names", names);
            this.$emit("callBackChoosedData", choosedData);
        },

        clear() {
            this.codes = "";
            this.myNames = "";
            // this.$emit('update:names', '')
            // this.$emit('input', '')
            // this.$emit('change', '', '')
            this.$emit("callBackChoosedData", "");
            this.choosedData = [];
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.value) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.uni-date-clear {
    position: absolute;
    top: 10px;
}
</style>
