<template>
    <view class="">
        <u-popup v-model="popupShow" closeable mode='right'>
            <eagle-head title='劳保要求' @close='popupClose'></eagle-head>
            <view class="mark-attach-container">
                <view class="mark-attach-head">
                    <u-radio-group v-model="value" @change="radioGroupChange" size='30rpx'>
                        <u-radio v-for="(item, index) in radioList" :key="item.id" :name="item.extra">
                            {{item.name}}
                        </u-radio>
                    </u-radio-group>
                </view>
                <u-gap height="2" marginBottom="10" bg-color="#FF9900"></u-gap>
                <view class="mark-attach-body">
                    <scroll-view scroll-y="true" style="height: calc(100vh - 175px);">
                        <u-checkbox-group @change="checkboxGroupChange" wrap>
                            <u-checkbox shape="square" v-model="item.checked" v-for="(item, index) in list" :key="index" :name="item.markCode">
                                <view class="mark-attach-item">
                                    <image :src="item.markAttach" mode="aspectFit"></image>
                                    <view>{{item.markName}}</view>
                                </view>
                            </u-checkbox>
                        </u-checkbox-group>
                    </scroll-view>
                </view>
                <view class="mark-attach-footer">
                    <u-button size="small" @tap.stop="allCkeck">全选</u-button>
                    <u-button size="small" @tap.stop="reset">重置</u-button>
                    <u-button size="small" type="primary" @tap.stop="submit">确定</u-button>
                </view>
            </view>
        </u-popup>
    </view>
</template>

<script>
export default {
    props: {
        popupShow: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            directoryUrl: "/support/riskMark/getMarkDirectory",
            query: {
                url: "/support/riskMark/getPageData",
                params: {
                    pageNum: 1,
                    pageSize: 20,
                    pageType: "OpRegulation",
                    dCode: ""
                }
            },
            total: 0,
            radioList: [],
            list: [],
            value: "RMD1904300001",
            checkedList: []
        }
    },
    created() { },
    watch: {
        popupShow(val) {
            if (val) {
                this.initMarkDirector()
                this.getPageData()
            }
        }
    },
    methods: {
        initMarkDirector() {
            this.common.get(this.directoryUrl, { pageType: this.query.params.pageType }).then(res => {
                console.log("res: ", res);
                if (res.code === 200) {
                    res.data.forEach(item => {
                        if (item.name === "劳动防护用品") {
                            item.name = '不限'
                        }
                    })
                    this.radioList = [...res.data.splice(2), ...res.data]
                }
            })
        },
        getPageData() {
            this.common.get(this.query.url, this.query.params).then(res => {
                console.log("res: ", res);
                res.data.forEach(item => {
                    item.markAttach = item.markAttach.replace('http://101.133.221.15:7700',
                        'http://libnew.safetyhua.com')
                })
                this.list = res.data
            })
        },
        popupClose() {
            this.$emit('popupClose', false)
        },
        allCkeck() {
            console.log("allCkeck: ",);
            this.checkedList = []
            this.list.forEach(item => {
                this.$set(item, 'checked', true)
                this.checkedList.push(item)
            })
        },
        reset() {
            console.log("reset: ",);
            this.list.forEach(item => {
                this.$set(item, 'checked', false)
            })
        },
        radioGroupChange(val) {
            console.log("val: ", val);
            this.query.params.dCode = val
            if (val === 'RMD1904300001') {
                this.query.params.dCode = ''
            }
            this.getPageData()
        },
        checkboxGroupChange(val) {
            console.log("val ", val);
            this.checkedList = []
            val.forEach(item => {
                this.list.forEach(v => {
                    if (item === v.markCode) {
                        this.checkedList.push(v)
                    }
                })
            })
            console.log("this.checkedList: ", this.checkedList);
        },
        submit() {
            this.$emit('submit', this.checkedList)
        }
    },
}
</script>

<style scoped lang="scss">
.mark-attach-container {
    width: 100vw;
    padding: 20rpx;
    box-sizing: border-box;
    overflow: hidden;

    .mark-attach-head {
        width: 100%;
        height: 70rpx;
        line-height: 70rpx;
        // padding: 10rpx;
        // border: 2rpx solid #EEEEEE;
        box-sizing: border-box;
    }

    .mark-attach-body {
        width: 100%;

        .mark-attach-item {
            width: 100%;
            display: flex;
            align-items: center;

            image {
                width: 60rpx;
                height: 60rpx;
                margin-right: 15rpx;
            }

            view {
                font-size: 28rpx;
                text-align: center;
            }
        }
    }

    .mark-attach-footer {
        width: 100%;
        height: 80rpx;
        line-height: 80rpx;
        background: #eeeeee;
        display: flex;
        justify-content: space-around;
        align-items: center;
        position: fixed;
        left: 0;
        bottom: 0;
    }
}
</style>
