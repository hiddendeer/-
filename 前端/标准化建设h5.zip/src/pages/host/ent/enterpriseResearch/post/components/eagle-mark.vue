<template name="eagle-choose-user">
    <!-- <view style="background: #FFFFFF;">
		<view style="padding: 0 30rpx;"> -->
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
        <view class="" style="width: 100%;height: auto;line-height: 50rpx;display: flex;flex-wrap: wrap;">
            <view v-for="(item,index) in choosedData" :key="index">
                <image style="width: 60rpx;height: 60rpx;margin-right: 15rpx;" :src="item.markAttach" mode="aspectFit"></image>
            </view>
            <view style="width: 100%;height: auto;line-height: 50rpx;" v-if="this.choosedData.length<=0">
                <text style="width: 100%;height: 70rpx;font-size: 32rpx;text-align: start;">无</text>
            </view>
        </view>

    </u-form-item>

    <!-- </view>
	</view> -->
</template>

<script>
export default {
    name: "eagle-window-choose",
    components: {},
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        conditions: {
            type: Array,
            default() {
                return [];
            },
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
        placeholderVal: {
            type: String,
            default: "请选择",
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
        headTitle: {
            type: String,
            default() {
                return "";
            },
        },
        idField: {
            type: String,
            default() {
                return "id";
            },
        },
        textField: {
            type: String,
            default() {
                return "name";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        dataType: {
            type: String,
            default() {
                return "list";
            },
        },
        border: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
            choosedData: [],
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                if (nVal) {
                    this.codes = nVal;
                    console.log("nVal: ", nVal);
                    if (Array.isArray(nVal)) {
                        this.choosedData = nVal;
                    } else {
                        this.choosedData = JSON.parse(nVal);
                    }
                }
            }
        },
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        setValues(codes, names, markAttachs) {
            this.$emit("update:names", names);
            this.$emit("input", codes);
            this.$emit("change", codes, names, markAttachs);
        },

        callBackChoosedData(choosedData) {
            this.choosedData = choosedData;
            this.$emit("update:names", choosedData);
            this.$emit("callBackChoosedData", choosedData);
        },

        clear() {
            this.codes = "";
            this.myNames = "";
            // this.$emit('update:names', '')
            // this.$emit('input', '')
            // this.$emit('change', '', '')
            this.$emit("callBackChoosedData", "");
            this.choosedData = [];
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.value) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.uni-date-clear {
    position: absolute;
    top: 10px;
}
</style>
