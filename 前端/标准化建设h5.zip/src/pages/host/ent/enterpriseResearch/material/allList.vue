<template>
    <view>
        <material-list ref="MaterialList" isAll="Y"></material-list>
		
		
		<tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
		<tabbar-site v-else></tabbar-site>
    </view>
	
	
</template>

<script>
import MaterialList from "./list.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";

export default {
	
    components: { 
		MaterialList,
		TabbarHost,
		TabbarSite
	},
    data() {
        return {
            state: "show",
			queryParams: {
				enterpriseCode: "",
			},
        };
    },
    created() {
        console.log("父组件初始化3333");
    },
    mounted() {
		this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        this.search();
    },
    onload() {
        console.log("mylist is onload");
    },
    onShow() {
        this.search();
    },
    onHide: function () {
        this.state = "hidden";
    },
    methods: {
        search() {
            if (this.$refs.MaterialList) {
                this.$refs.MaterialList.search();
            }
        },
    },
    computed: {
        routerCategory() {
            return this.$route.query.modulesId;
        },
    },
};
</script>
