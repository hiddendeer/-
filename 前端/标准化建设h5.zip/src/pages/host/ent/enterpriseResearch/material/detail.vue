<template>
    <view class="production-materials-list-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" labelWidth="150" :boolInitData="boolInitData" labelAlign='left' :outHeight='80' :isUseEnterprise="false">
            <eagle-container>
                <fast-choose-build required title="所在区域" v-model="model.locationName" :name.sync="model.locationCode"></fast-choose-build>
                <eagle-upload title="原辅料照片" :maxCount="1" prop="photo" v-model="model.photo" labelWidth="150" labelPosition="top" :deletable='deletable' />
                <eagle-input v-model="model.materialName" required title="原辅料名称" prop="materialName" labelPosition="top" labelWidth="150" />

                <eagle-select v-model="model.physicalCode" required title="物质形态" prop="physicalCode" labelPosition="top" :height="70" :data-source="params.physicalFormArray" labelWidth="150" required />

                <eagle-input v-model="model.currentStorage" title="当前存储量(kg,T,L)" prop="currentStorage" labelPosition="top" labelWidth="150" />

                <eagle-input v-model="model.useAmount" title="使用量(kg,T,L/年)" prop="useAmount" labelPosition="top" labelWidth="150" />

                <eagle-checkbox-group v-model="model.mainPurposeCode" title="主要用途" prop="mainPurposeCode" :data-source="params.purposeArray" label-position='top' />
                <eagle-file-upload title="附件" prop="attach" v-model="model.attach" />

                <view style="background: #ffffff">
                    <view style="padding: 0 30rpx">
                        <u-form-item label="属于化学品" label-position='top' :label-width='150'>
                            <u-switch v-model="model.danger"></u-switch>
                        </u-form-item>
                    </view>
                </view>
                <template v-if="model.danger">

                    <eagle-checkbox-group v-model="model.dangerAttributeCode" title="主要危险属性" prop="dangerAttributeCode" :data-source="params.dangerAttribute" label-position='top' />

                    <eagle-select v-model="model.storageMethodCode" title="存储方式" prop="storageMethodCode" labelPosition="top" :height="70" :data-source="params.storageArray" labelWidth="150" />

                    <eagle-input v-model="model.dedicatedStorageArea" type="number" title="专用仓库面积(㎡)" prop="dedicatedStorageArea" labelPosition="top" labelWidth="150" v-if="model.storageMethodCode == 'Warehouse'" />

                    <!-- <view style="background: #ffffff">
					<view style="padding: 0 30rpx">
						<u-form-item label="常压储罐(m³)" label-position='top' :label-width='150'
							v-if="model.storageMethodCode == 'AtmosphericTank'">
							<u-number-box color="#303133" v-model="model.atmosphericTank"
								style="margin-right: 10rpx;">
							</u-number-box>
							<u-input v-model="model.atmosphericTankVolume" placeholder='储罐总容积' />
						</u-form-item>
					</view>
				</view>
				 -->

                    <eagle-input v-model="model.atmosphericTank" type="number" title="常压储罐(个)" prop="atmosphericTank" labelPosition="top" labelWidth="150" v-if="model.storageMethodCode == 'AtmosphericTank'" />

                    <eagle-input v-model="model.atmosphericTankVolume" type="number" title="储罐总容积(m³)" prop="atmosphericTankVolume" labelPosition="top" labelWidth="150" v-if="model.storageMethodCode == 'AtmosphericTank'" />

                    <!-- <view style="background: #ffffff">
					<view style="padding: 0 30rpx">
						<u-form-item label="压力储罐(m³)" label-position='top' :label-width='150'
							v-if="model.storageMethodCode == 'PressureTank'">
							<u-number-box color="#000" bg-color="#3291F8" v-model="model.pressureTank"
								style="margin-right: 10rpx;">
							</u-number-box>
							<u-input v-model="model.pressureTankVolume" placeholder='储罐总容积' />
						</u-form-item>
					</view>
				</view> -->

                    <eagle-input v-model="model.pressureTank" type="number" title="压力储罐(个)" prop="pressureTank" labelPosition="top" labelWidth="150" v-if="model.storageMethodCode == 'PressureTank'" />

                    <eagle-input v-model="model.pressureTankVolume" type="number" title="储罐总容积(m³)" prop="pressureTankVolume" labelPosition="top" labelWidth="150" v-if="model.storageMethodCode == 'PressureTank'" />

                    <eagle-input v-model="model.tempStorageArea" type="number" title="临时存放点面积(㎡)" prop="tempStorageArea" labelPosition="top" labelWidth="150" v-if="model.storageMethodCode == 'TempStorage'" />

                </template>
                <view style="background: #ffffff;">
                    <view style="padding: 0 30rpx">
                        <u-form-item label="更多信息" label-position='top' :label-width='150' v-if="checked">
                            <u-switch v-model="checked1"></u-switch>
                        </u-form-item>
                    </view>
                    <template v-if="checked1">
                        <eagle-input v-model="model.supplier" title="供应商名称" prop="supplier" labelPosition="top" labelWidth="150" />
                        <eagle-input v-model="model.contactPhone" title="联系电话" prop="contactPhone" labelPosition="top" labelWidth="150" />
                        <eagle-input v-model="model.remarks" title="备注" prop="remarks" labelPosition="top" type='textarea' labelWidth="150" />
                    </template>
                </view>
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
            <!-- <u-button type="error" size="medium" @click="del()">删除</u-button> -->
            <!-- <u-button size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
    </view>
</template>

<script>
import FastChooseBuild from "@/pages/host/ent/building/components/fast-choose-build.vue";

export default {
    components: { FastChooseBuild },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/material",
            labelPosition: "top",
            labelWidth: "150",
            type: "",
            companyCode: "",
            deletable: true,
            checked: true,
            checked1: false,
            boolInitData: false,
            numberBoxValue: 0,
            value: "",
            params: {
                physicalFormArray: [],
                purposeArray: [],
                storageArray: [],
                dangerAttribute: [],
            },
            initParams: {
                code: "",
                name: "",
                companyCode: "",
            },
        };
    },

    watch: {
        "model.danger": {
            handler(val) {
                if (!val) {
                    this.model.dangerAttributeCode = "";
                }
            },
        },
        immediate: true,
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode ?? "";

        this.model.id = this.$route.query.id ?? "";

        if (this.model.id != "0") {
            uni.setNavigationBarTitle({ title: "编辑生产原辅料" });
            this.boolInitData = true;
        } else {
            this.boolInitData = false;
        }

        this.initParams.code = this.$route.query.code ?? "";
        if (this.$route.query.enterpriseCode) {
            this.initParams.enterpriseCode = this.$route.query.enterpriseCode;
            this.initParams.companyCode = this.$route.query.enterpriseCode;
        }
        if (this.$route.query.projectId) {
            this.initParams.projectId = this.$route.query.projectId;
        }
        this.initData();
    },

    mounted() {
        let _this = this;
        setTimeout(() => {
            let action = this.$refs.eagleForm.getAction();
            if (action == "init") {
                let url = "site/material/initData/0";
                this.common.get(url, this.initParams).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data;
                    } else {
                    }
                    uni.hideToast();
                });
            }
        });
    },

    methods: {
        initCallBack(data) {
            this.model = data;
        },
        initData() {
            let _this = this;
            this.enterpriseCode = this.$route.query.enterpriseCode;
            this.common
                .getparamsList(
                    "site_material_physical_form,site_material_purpose,site_material_storage,site_material_danger_attribute"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.physicalFormArray = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId ===
                                    "site_material_physical_form"
                                );
                            }
                        );
                        this.params.purposeArray = res.data.filter((item) => {
                            return item.paramId === "site_material_purpose";
                        });

                        this.params.storageArray = res.data.filter((item) => {
                            return item.paramId === "site_material_storage";
                        });

                        this.params.dangerAttribute = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId ===
                                    "site_material_danger_attribute"
                                );
                            }
                        );
                    }
                });
        },

        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },

        del() {
            let _this = this;
            if (this.model.id == 0) {
                this.close();
                return;
            }

            let url = this.control + "/delete/" + this.model.id;
            this.$refs.eagleForm.del({
                url: url,
                successCallback: function () {
                    _this.close();
                },
            });
        },

        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style scoped lang="scss">
.production-materials-list-container {
    // padding: 15rpx;
    box-sizing: border-box;
}
</style>
