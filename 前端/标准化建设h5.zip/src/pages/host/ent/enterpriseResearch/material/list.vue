<template>
    <view class="production-materials-list-container">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="135" :queryParams="queryParams">
            <view slot="search" class="search-slot">
                <u-subsection mode='subsection' active-color='#2979FF' :list="radioList" :current="sectionCurrent" :height='60' :bold='false' @change="handlerSectionChange"></u-subsection>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.photo" @click="handlerBody(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.materialName }}
                        <template slot="icon">
                            {{ item.locationName }}
                        </template>
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            是否危化品：{{ item.danger ? "是" : "否" }}
                        </view>
                    </eagle-row-view>
                    <eagle-girdrow-base>
                        <view v-if="item.mainPurposeCode">
                            用途：{{ item.mainPurposeCode | splitParamsFormat(params.siteMaterialPurposeArray) }}
                        </view>
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        <u-tag :text="item1" size="mini" v-for="(item1, index) in item.dangerAttributeArr" :key='index + "dangerAttributeArr"' style="margin: 5rpx;" />
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" @click="handlerDel(item)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerBodyClick(item)" size="mini">编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab v-if="!isAll" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <!-- <eagle-fab horizontal="right" vertical="bottom" direction="horizontal" :content='fabContent' @trigger="trigger">
        </eagle-fab> -->
    </view>
</template>

<script>
// import productionMaterialCard from '../components/productionMaterialCard.vue'
export default {
    // components: { productionMaterialCard },
    name: "material-list",
    props: {
        name: {
            type: String,
            default() {
                return "";
            },
        },
        code: {
            type: String,
            default() {
                return "";
            },
        },
        isAll: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            controller: "/site/material",
            list: [],
            sectionCurrent: 0,
            companyCode: "",
            marginBottom: 140,
            radioList: [
                { name: "不限" },
                { name: "一般原材料" },
                { name: "危险化学品" },
            ],
            fabContent: [
                {
                    iconPath: "../../../static/img/AppIcon/icon_list_add.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_list_add.png",
                    text: "新增",
                    active: true,
                },
                {
                    iconPath: "../../../static/img/AppIcon/icon_camera.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_camera.png",
                    text: "拍照",
                    active: false,
                },
            ],

            params: {
                siteMaterialPurposeArray: [],
                siteMaterialDangerAttributeArray: [],
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
            noImgUrl: require("@/static/img/no-img.png"),
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode ?? "";
        this.queryParams.code = this.$route.query.code ?? "";
        if (this.$route.query.enterpriseCode) {
            this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
        }
        if (this.$route.query.projectId) {
            this.queryParams.projectId = this.$route.query.projectId;
        }
        this.initData();
        setTimeout(() => {
            this.queryPage();
        });
        if (this.isAll) {
            this.marginBottom = 40;
        } else {
            this.marginBottom = 140;
        }
    },

    // mounted() {
    // 	this.queryParams.enterpriseCode = this.$route.query.enterpriseCode
    // 	this.queryParams.projectId = this.$route.query.projectId
    // 	this.queryParams.code = this.$route.query.code
    // 	this.queryPage()
    // },

    methods: {
        initList(data) {
            this.list = [];
            this.list = data;

            for (let i = 0; i < this.list.length; i++) {
                var item = this.list[i];
                let dangerAttributeCode = this.common.splitParamsFormat(
                    item.dangerAttributeCode,
                    this.params.siteMaterialDangerAttributeArray
                );

                if (dangerAttributeCode != "") {
                    item.dangerAttributeArr = dangerAttributeCode.split(",");
                }
            }
        },
        search() {
            this.queryPage();
        },

        queryPage() {
            // var conditions = [];
            var params = { isDanger: "" };
            if (this.sectionCurrent == 1) {
                params.isDanger = "0";
            } else if (this.sectionCurrent == 2) {
                params.isDanger = "1";
            } else {
                params.isDanger = "";
            }

            this.$refs.eaglePageList.search({
                params: { ...params, ...this.queryParams },
            });
        },

        initData() {
            this.common
                .getparamsList(
                    "site_material_purpose,site_material_danger_attribute"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.siteMaterialPurposeArray = res.data.filter(
                            (item) => {
                                return item.paramId === "site_material_purpose";
                            }
                        );
                        this.params.siteMaterialDangerAttributeArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId ===
                                    "site_material_danger_attribute"
                                );
                            });
                    }
                });
        },

        handlerBody(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/material/view",
                {
                    id: item.id,
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },

        handlerBodyClick(item, index) {
            console.log("item,index: ", item, index);

            // let url =
            //     "pages/host/ent/enterpriseResearch/material/detail?id=" +
            //     item.id +
            //     "&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode
            // }
            // if (this.$route.query.projectId) {
            //     url =
            //         url + "&projectId=" + this.$route.query.projectId
            // }
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/material/detail",
                {
                    id: item.id,
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },
        handlerSectionChange(index) {
            console.log("item,index: ", index);
            this.sectionCurrent = index;
            this.queryPage();
        },
        handlerDel(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        handlerFabClick() {
            // let url =
            //     "pages/host/ent/enterpriseResearch/material/detail?id=0&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode
            // }
            // if (this.$route.query.projectId) {
            //     url =
            //         url + "&projectId=" + this.$route.query.projectId
            // }

            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/material/detail",
                {
                    id: 0,
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },
        trigger(e) {
            // console.log("e: ", e)
            // this.fabContent.forEach((item, index) => {
            //     item.active = false
            //     if (index === e.index) {
            //         item.active = true
            //     }
            // })
            if (e.index === 0) {
                this.handlerFabClick();
            }
        },
        onreachBottom() {},
    },
};
</script>

<style scoped lang="scss">
.circleShow {
    height: 50rpx;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;

    width: 380rpx;
    // white-space: nowrap;
    // overflow: hidden;
    // text-overflow: ellipsis;
}
</style>
