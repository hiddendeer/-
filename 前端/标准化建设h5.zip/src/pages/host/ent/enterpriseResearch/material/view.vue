<template>
    <view class="production-materials-list-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :boolInitData="boolInitData" labelAlign='left' :isUseEnterprise="false">
            <eagle-container title="原辅料详情">
                <eagle-text title="原辅料照片">
                    <eagle-display-image :value="model.photo" />
                </eagle-text>
                <eagle-text title="原辅料名称" v-model="model.materialName" />
                <eagle-text title="物质形态">
                    {{model.physicalCode|splitParamsFormat(params.physicalFormArray)}}
                </eagle-text>
                <eagle-text title="当前存储量" v-model="model.currentStorage" />
                <eagle-text title="使用量" v-model="model.useAmount" />
                <eagle-text title="主要用途" v-model="model.mainPurposeCode" />
                <eagle-text title="附件">
                    <eagle-file-upload disabled v-model="model.attach" />
                </eagle-text>
                <eagle-text title="属于化学品">
                    {{model.danger?"是":"否"}}
                </eagle-text>
            </eagle-container>

            <eagle-container title="危化品属性" v-if="model.danger">
                <eagle-text title="主要危险属性">
                    {{model.dangerAttributeCode|splitParamsFormat(params.dangerAttribute)}}
                </eagle-text>
                <eagle-text title="存储方式">
                    {{model.storageMethodCode|splitParamsFormat(params.storageArray)}}
                </eagle-text>
                <eagle-text title="专用仓库面积(㎡)" v-model="model.dedicatedStorageArea" />
                <eagle-text title="常压储罐(个)" v-model="model.atmosphericTank" />
                <eagle-text title="储罐总容积(m³)" v-model="model.atmosphericTankVolume" />
                <eagle-text title="压力储罐(个)" v-model="model.pressureTank" />
                <eagle-text title="储罐总容积(m³)" v-model="model.pressureTankVolume" />
                <eagle-text title="临时存放点面积(㎡)" v-model="model.tempStorageArea" />
            </eagle-container>

            <eagle-container title="更多信息">
                <eagle-text title="供应商名称" v-model="model.supplier" />
                <eagle-text title="联系电话" v-model="model.contactPhone" />
                <eagle-text title="备注" v-model="model.remarks" />
            </eagle-container>

        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/material",
            labelPosition: "top",
            labelWidth: "150",
            type: "",
            companyCode: "",
            deletable: true,
            checked: true,
            checked1: false,
            boolInitData: false,
            numberBoxValue: 0,
            value: "",
            params: {
                physicalFormArray: [],
                purposeArray: [],
                storageArray: [],
                dangerAttribute: [],
            },
            initParams: {
                code: "",
                name: "",
                companyCode: "",
            },
        };
    },

    watch: {
        "model.danger": {
            handler(val) {
                if (!val) {
                    this.model.dangerAttributeCode = "";
                }
            },
        },
        immediate: true,
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode ?? "";

        this.model.id = this.$route.query.id ?? "";

        if (this.model.id != "0") {
            this.boolInitData = true;
        } else {
            this.boolInitData = false;
        }

        this.initParams.code = this.$route.query.code ?? "";
        if (this.$route.query.enterpriseCode) {
            this.initParams.enterpriseCode = this.$route.query.enterpriseCode;
        }
        if (this.$route.query.projectId) {
            this.initParams.projectId = this.$route.query.projectId;
        }
        this.initData();
    },

    mounted() {
        let _this = this;
        setTimeout(() => {
            let action = this.$refs.eagleForm.getAction();
            if (action == "init") {
                let url = "site/material/initData/0";
                this.common.get(url, this.initParams).then(function (res) {
                    if (res.code === 200) {
                        _this.model = res.data;
                    } else {
                    }
                    uni.hideToast();
                });
            }
        });
    },

    methods: {
        initCallBack(data) {
            this.model = data;
        },
        initData() {
            let _this = this;
            this.enterpriseCode = this.$route.query.enterpriseCode;
            this.common
                .getparamsList(
                    "site_material_physical_form,site_material_purpose,site_material_storage,site_material_danger_attribute"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.physicalFormArray = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId ===
                                    "site_material_physical_form"
                                );
                            }
                        );
                        this.params.purposeArray = res.data.filter((item) => {
                            return item.paramId === "site_material_purpose";
                        });

                        this.params.storageArray = res.data.filter((item) => {
                            return item.paramId === "site_material_storage";
                        });

                        this.params.dangerAttribute = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId ===
                                    "site_material_danger_attribute"
                                );
                            }
                        );
                    }
                });
        },

        post() {
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },

        del() {
            let _this = this;
            if (this.model.id == 0) {
                this.close();
                return;
            }

            let url = this.control + "/delete/" + this.model.id;
            this.$refs.eagleForm.del({
                url: url,
                successCallback: function () {
                    _this.close();
                },
            });
        },

        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style scoped lang="scss">
.production-materials-list-container {
    // padding: 15rpx;
    box-sizing: border-box;
}
</style>
