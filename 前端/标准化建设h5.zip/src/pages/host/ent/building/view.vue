<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm">
            <eagle-container title="建构筑物详情">
                <eagle-text title="建构筑物名称" prop="buildName" v-model="model.buildName" />
                <eagle-text label="建构筑物照片" prop="buildPhoto" v-if="model.buildPhoto">
                    <eagle-display-image prop="attachs" v-model="model.buildPhoto"></eagle-display-image>
                </eagle-text>
                <eagle-text label="平面图" prop="buildPhoto" v-if="model.buildPlanarGraph">
                    <eagle-display-image prop="attachs" v-model="model.buildPlanarGraph"></eagle-display-image>
                </eagle-text>

                <eagle-text title="建筑用途">
                    {{model.buildPurpose|paramsMultFormat(params.ProjectBuildPurposeArray)}}
                </eagle-text>
                <eagle-text title="建造时间">
                    {{ model.buildMaketime|dateFormat}}
                </eagle-text>
                <eagle-text title="建筑结构">
                    {{model.buildStructure|paramsFormat(params.ProjectBuildStructureArray)}}
                </eagle-text>
                <eagle-text title="建筑材质">
                    {{model.buildMaterial|paramsFormat(params.ProjectBuildMaterialArray)}}
                </eagle-text>
                <eagle-text title="建筑面积(㎡)">
                    {{model.buildArea}}
                </eagle-text>
                <eagle-text title="耐火等级">
                    {{model.buildFireGrade|paramsFormat(params.ProjectBuildFireGradeArray)}}
                </eagle-text>
                <eagle-text title="火灾危险性">
                    {{model.buildDangerType|paramsFormat(params.ProjectBuildDangerTypeArray)}}
                </eagle-text>
                <eagle-text title="监管重点">
                    {{model.buildRegulatoryfocus|paramsMultFormat(params.buildRegulatoryfocusArray)}}
                </eagle-text>

            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="close()">关闭</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/entBuilding",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            initUrl: "",
            params: {
                ProjectBuildDangerTypeArray: [],
                ProjectBuildFireGradeArray: [],
                ProjectBuildPurposeArray: [],
                buildRegulatoryfocusArray: [],
                ProjectBuildMaterialArray: [],
                ProjectBuildStructureArray: [],
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            deletable: true,
            look: true,
        };
    },
    created() {
        this.initData();

        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
    },
    methods: {
        initCallBack(data) {
            this.model = {};
            this.model = data;
        },
        initData() {
            let _this = this;

            this.common
                .getparamsList(
                    "end_building_danger_type,end_building_fire_grade,end_building_purpose,site_enterprise_danger,end_building_material,end_building_structure"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.ProjectBuildDangerTypeArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_danger_type"
                                );
                            });
                        this.params.ProjectBuildFireGradeArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_fire_grade"
                                );
                            });
                        this.params.ProjectBuildMaterialArray = res.data.filter(
                            (item) => {
                                return item.paramId === "end_building_material";
                            }
                        );
                        this.params.ProjectBuildPurposeArray = res.data.filter(
                            (item) => {
                                return item.paramId === "end_building_purpose";
                            }
                        );
                        this.params.ProjectBuildStructureArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_structure"
                                );
                            });
                        this.params.buildRegulatoryfocusArray = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId === "site_enterprise_danger"
                                );
                            }
                        );
                    }
                });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style>
</style>
