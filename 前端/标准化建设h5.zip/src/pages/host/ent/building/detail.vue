<template>
    <view>

        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="150" labelAlign='left' :initUrl="initUrl">
            <eagle-container>
                <eagle-input v-model="model.buildName" required title="建构筑物名称" prop="buildName" labelPosition="top" labelWidth="150" />
                <eagle-upload title="建构筑物照片" :maxCount="1" prop="buildPhoto" v-model="model.buildPhoto" labelPosition="top" :deletable='deletable' />
                <eagle-checkbox-group checkBoxWidth="160px" v-model="model.buildRegulatoryfocus" title="监管重点" prop="buildRegulatoryfocus" labelPosition="top" :data-source="params.buildRegulatoryfocusArray" labelWidth="150" v-if="params.buildRegulatoryfocusArray.length>0" />

                <eagle-checkbox-group v-model="model.buildPurpose" title="建筑用途" prop="buildPurpose" required labelPosition="top" :data-source="params.ProjectBuildPurposeArray" labelWidth="150" v-if="params.ProjectBuildPurposeArray.length>0" />

                <eagle-date v-model="model.buildMaketime" title="建造时间" prop="buildMaketime" labelPosition="top" :height="70" labelWidth="150"></eagle-date>

                <eagle-select v-model="model.buildStructure" title="建筑结构" prop="buildStructure" labelPosition="top" :height="70" :data-source="params.ProjectBuildStructureArray" labelWidth="150">
                </eagle-select>
                <eagle-select v-model="model.buildMaterial" title="建筑材质" prop="buildMaterial" labelPosition="top" :height="70" :data-source="params.ProjectBuildMaterialArray" labelWidth="150">
                </eagle-select>

                <eagle-input v-model="model.buildArea" title="建筑面积(㎡)" prop="buildArea" labelPosition="top" labelWidth="150" />

                <eagle-select v-model="model.buildFireGrade" title="耐火等级" prop="buildFireGrade" labelPosition="top" :height="70" :data-source="params.ProjectBuildFireGradeArray" labelWidth="150" />

                <eagle-select v-model="model.buildDangerType" title="火灾危险性" prop="buildDangerType" labelPosition="top" :height="70" :data-source="params.ProjectBuildDangerTypeArray" labelWidth="150" />
                <eagle-upload title="平面图" :maxCount="1" prop="buildPlanarGraph" v-model="model.buildPlanarGraph" labelPosition="top" :deletable='deletable' />

            </eagle-container>
        </eagle-form>

        <eagle-bottom-view v-if="look">
            <u-button class="bottom-btn" type="primary" @click="post()">保存</u-button>
            <!-- <u-button type="primary" size="medium" @click="close()">关闭</u-button> -->
        </eagle-bottom-view>
        <u-toast ref="uToast" position='top' />
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/entBuilding",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            initUrl: "",
            params: {
                ProjectBuildDangerTypeArray: [],
                ProjectBuildFireGradeArray: [],
                ProjectBuildPurposeArray: [],
                buildRegulatoryfocusArray: [],
                ProjectBuildMaterialArray: [],
                ProjectBuildStructureArray: [],
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            deletable: true,
            look: true,
        };
    },
    created() {
        this.initData();

        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";

        this.initUrl = "site/entBuilding/initData/0";

        console.log("this.$route.query.id: ", this.$route.query.id);
        if (this.$route.query.id !== "0" && !this.$route.query.type) {
            uni.setNavigationBarTitle({ title: "编辑建构筑物" });
        }
        if (this.$route.query.type && this.$route.query.type === "look") {
            this.look = false;
            this.deletable = false;
            uni.setNavigationBarTitle({ title: "查看详情" });
        }
    },
    methods: {
        initCallBack(data) {
            this.model = {};
            this.model = data;
        },
        initData() {
            let _this = this;

            this.common
                .getparamsList(
                    "end_building_danger_type,end_building_fire_grade,end_building_purpose,site_enterprise_danger,end_building_material,end_building_structure"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.ProjectBuildDangerTypeArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_danger_type"
                                );
                            });
                        this.params.ProjectBuildFireGradeArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_fire_grade"
                                );
                            });
                        this.params.ProjectBuildMaterialArray = res.data.filter(
                            (item) => {
                                return item.paramId === "end_building_material";
                            }
                        );
                        this.params.ProjectBuildPurposeArray = res.data.filter(
                            (item) => {
                                return item.paramId === "end_building_purpose";
                            }
                        );
                        this.params.ProjectBuildStructureArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_structure"
                                );
                            });
                        this.params.buildRegulatoryfocusArray = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId === "site_enterprise_danger"
                                );
                            }
                        );
                    }
                });
        },

        post() {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: () => {
                    return true;
                },
                successCallback: (res) => {
                    _this.close();
                },
                errorCallback: (res) => {
                    return;
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style>
</style>
