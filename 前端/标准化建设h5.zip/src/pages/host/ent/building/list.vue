<template>
    <view class="host-ent-building-container">
        <eagle-page-list ref="eaglePageList" @initList="initList" :controller="controller" :margin-bottom="140">
            <view slot="search" class="search-slot">
                <eagle-search placeholder="请输入建构筑物名称进行搜索" @search="search" v-model="conditions.buildName.value" :clearabled="true" :show-action="false" @clear="search"></eagle-search>
            </view>
            <view slot="list" class=" list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.buildPhoto" @click="handlerView(item)">
                    <template slot="tag">
                        <view> <span class="orange">
                                {{ item.buildPurpose | splitParamsFormat(params.ProjectBuildPurposeArray) }}</span>
                        </view>
                    </template>
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.buildName }}
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <u-tag v-if="item.buildStructure" size='mini' style="margin: 5rpx;" :text="item.buildStructure | paramsFormat(params.ProjectBuildStructureArray)" mode="plain" />
                        <u-tag v-if="item.buildMaterial" size='mini' style="margin: 5rpx;" :text="item.buildMaterial | paramsFormat(params.ProjectBuildMaterialArray)" mode="plain" />
                    </eagle-row-view>
                    <eagle-girdrow-base v-if="item.buildRegulatoryfocus">
                        监管重点：{{ item.buildRegulatoryfocus | splitParamsFormat(params.buildRegulatoryfocusArray) }}
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" @click="handlerDel(item)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerEdit(item)" size="mini">编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
export default {
    components: { TabbarHost, TabbarSite },
    data() {
        return {
            controller: "/site/entBuilding",
            list: [],
            conditions: {
                buildName: {
                    value: "",
                    operate: "like",
                },
            },

            params: {
                buildRegulatoryfocusArray: [],
                ProjectBuildPurposeArray: [],
                ProjectBuildMaterialArray: [],
                ProjectBuildStructureArray: [],
            },
            queryParams: { projectId: "", enterpriseCode: "" },

            noImgUrl: require("@/static/img/no-img.png"),
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";

        this.queryParams.projectId = this.$route.query.projectId ?? "";

        this.initData();
        this.search();
    },
    mounted() {},
    onShow() {
        this.search();
    },
    methods: {
        initList(data) {
            this.list = data;
        },
        initData() {
            this.common
                .getparamsList(
                    "end_building_purpose,site_enterprise_danger,end_building_material,end_building_structure"
                )
                .then((res) => {
                    console.log(res);
                    if (res.code === 200) {
                        this.params.ProjectBuildMaterialArray = res.data.filter(
                            (item) => {
                                return item.paramId === "end_building_material";
                            }
                        );
                        this.params.ProjectBuildPurposeArray = res.data.filter(
                            (item) => {
                                return item.paramId === "end_building_purpose";
                            }
                        );
                        console.log(
                            "this.params.ProjectBuildPurposeArray: ",
                            this.params.ProjectBuildPurposeArray
                        );
                        this.params.ProjectBuildStructureArray =
                            res.data.filter((item) => {
                                return (
                                    item.paramId === "end_building_structure"
                                );
                            });
                        this.params.buildRegulatoryfocusArray = res.data.filter(
                            (item) => {
                                return (
                                    item.paramId === "site_enterprise_danger"
                                );
                            }
                        );
                    }
                });
        },

        search() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    url: "/site/entBuilding/getPageData",
                    conditions: this.common.getCondtions(this.conditions),
                    params: this.queryParams,
                });
            });
        },

        handlerFabClick() {
            // let url = "pages/host/ent/building/detail?id=0";
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url = url + "&projectId=" + this.$route.query.projectId;
            // }
            // this.base.navigateTo(url);
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/building/detail",
                {
                    id: 0,
                    projectId: this.$route.query.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerBodyClick(item, index) {
            // console.log("123132: ", item);
            // let url =
            //     "pages/host/ent/enterpriseResearch/index" +
            //     "?code=" +
            //     item.code +
            //     "&projectId=" +
            //     this.queryParams.projectId;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // this.base.navigateTo(url);

            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/enterpriseResearch/index",
                {
                    code: item.code,
                    projectId: this.queryParams.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerView(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/building/view",
                {
                    id: item.id,
                    projectId: this.queryParams.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        handlerEdit(val) {
            // let url =
            //     "pages/host/ent/building/detail?id=" +
            //     val.id +
            //     "&code=" +
            //     val.code;
            // if (this.queryParams.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.queryParams.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url = url + "&projectId=" + this.$route.query.projectId;
            // }

            let linkUrl = this.common.getLinkUrl(
                "pages/host/ent/building/detail",
                {
                    id: val.id,
                    code: val.code,
                    projectId: this.$route.query.projectId ?? "",
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },
        handlerDel(val) {
            let url = this.controller + "/delete/" + val.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: () => {
                    this.search();
                },
            });
        },
    },
};
</script>

<style scoped lang="scss">
.host-ent-building-container {
    width: 100vw;
    overflow: hidden;
    height: calc(100vh);
    // .card-content {
    //     display: flex;

    //     .card-content-img {
    //         margin-right: 20rpx;
    //     }

    //     .card-content-body {
    //         flex: 1 1;
    //     }
    // }

    .circleShow {
        height: 50rpx;
        // overflow: hidden;
        // display: -webkit-box;
        // -webkit-box-orient: vertical;
        // -webkit-line-clamp: 1;
        line-height: 50rpx;

        // width: 333px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .circleShow1 {
        height: 50rpx;
        // overflow: hidden;
        // display: -webkit-box;
        // -webkit-box-orient: vertical;
        // -webkit-line-clamp: 1;
        line-height: 50rpx;

        // width: 333px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
</style>
