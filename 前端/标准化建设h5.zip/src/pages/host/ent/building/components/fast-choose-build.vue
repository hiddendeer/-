<template name="project-build-fast">
    <u-form-item class="project-build-fast" :label="label" ref="uFormItem" :label-position="labelPosition" :required="required" :prop="prop" :label-width="labelWidth">
        <eagle-arrow-input v-model="defaultValue" :disabled="false" :placeholder="placeholderVal" @input="inputChange" @confirm="confirmEvent" @click="showList"></eagle-arrow-input>
        <template v-if="list.length>0">
            <view class="drop-select">
            </view>
            <view class="drop-content" id="drop-content" v-clickoutside="close">
                <view class="drop-row" v-for="(item,index) in list" :key="index" @click="hdClick(item)">
                    <view style="flex:1">{{item.buildName}}</view>
                    <u-icon class="button" label="选择"></u-icon>
                </view>
            </view>
        </template>
    </u-form-item>
</template>
<script>
import "@/common/clickoutside.js";
export default {
    components: {},
    name: "fast-choose-build",
    props: {
        label: {
            type: String,
            default: "所在区域",
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        border: {
            type: Boolean,
            default: false,
        },
        value: {
            type: String,
            default() {
                return "";
            },
        },
        name: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: [String],
            default: "",
        },
    },
    data() {
        return {
            model: {},
            lock: false,
            locklength: 0,
            defaultValue: "",
            list: [],
        };
    },

    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请输入" + this.label;
    },
    watch: {
        value(nVal, oVal) {
            if (this.defaultValue != this.value) {
                this.defaultValue = this.value;
                this.$emit("input", this.defaultValue);
            }
        },
    },
    methods: {
        inputChange() {
            this.$emit("input", this.defaultValue);
            if (this.defaultValue && this.defaultValue.length >= 0) {
                if (!this.lock || this.locklength < this.defaultValue.length) {
                    let _this = this;
                    this.lock = true;
                    this.locklength = this.defaultValue.length;
                    this.getList(_this.defaultValue);
                }
            } else {
                this.list = [];
            }
        },
        close() {
            console.log("close");
            this.list = [];
        },
        hdClick(item) {
            this.$emit("input", item.buildName);
            this.$emit("update:name", item.code);
            this.close();
        },
        showList() {
            if (this.list && this.list.length > 0) {
                return false;
            }
            this.getList("");
        },
        getList(val) {
            let _this = this;
            this.common
                .get("/site/entBuilding/getListDataByName", {
                    name: val,
                    companyCode: this.$route.query.enterpriseCode ?? "",
                })
                .then((res) => {
                    _this.list = res.data;
                    setTimeout((x) => {
                        _this.lock = false;
                    }, 500);
                });
        },
        confirmEvent() {
            this.$emit("input", this.defaultValue);
            this.$emit("update:name", "");
            this.valid();
            this.close();
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss" scopd>
.project-build-fast {
    position: relative;
    .drop-select {
        padding: 10px;
        position: absolute;
        z-index: 9999999;
        width: 100%;
        background: #5e5e5e;
        top: 78px;
        left: 0px;
        height: calc(100vh);
        opacity: 0.5;
    }
    .drop-content {
        border: 1px solid #eee;
        position: absolute;
        max-height: 200px;
        overflow: auto;
        line-height: 36px;
        padding: 10px;
        background: #fff;
        z-index: 9999999;
        width: calc(100vw - 20px);
        left: 0;
        top: 78px;
        border-radius: 0 0 5px 5px;
    }
    .drop-row {
        display: flex;
        .button {
            width: 50px;
            color: #0088ff;
        }
    }
}
</style>
