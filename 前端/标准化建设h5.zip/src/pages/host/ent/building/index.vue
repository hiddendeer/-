
<template>
    <view class="host-ent-erprise-container">
        <view class="u-tabs-box">
            <u-tabs-swiper :bold="false" prop="buildIndex" name="name" ref="tabs" :list="tabList" :current="tabIndex" @change="onTabChanged">
            </u-tabs-swiper>
        </view>
        <!-- <building ref='building' v-if="tabIndex==0"></building>
        <OperationPost ref='OperationPost' v-if="tabIndex==1"></OperationPost>
        <EquipmentFacilities ref='EquipmentFacilities' v-if="tabIndex==2"></EquipmentFacilities>
        <ProductionMaterials ref='ProductionMaterials' v-if="tabIndex==3"></ProductionMaterials>
        <FiniteSpace ref='FiniteSpace' v-if="tabIndex==4"></FiniteSpace> -->
        <swiper class="swiper-box" :current="tabContentIndex" @transition="transition" @animationfinish="animationfinish">
            <swiper-item class="swiper-item1">
                <building ref='building'></building>
            </swiper-item>
            <swiper-item class="swiper-item1">
                <OperationPost ref='OperationPost'></OperationPost>
            </swiper-item>
            <swiper-item class="swiper-item1">
                <EquipmentFacilities ref='EquipmentFacilities'>
                </EquipmentFacilities>
            </swiper-item>
            <swiper-item class="swiper-item1">
                <ProductionMaterials ref='ProductionMaterials'></ProductionMaterials>
            </swiper-item>
            <swiper-item class="swiper-item1">
                <FiniteSpace ref='FiniteSpace'></FiniteSpace>
            </swiper-item>
        </swiper>
        <view>
            <tabbar-host v-if="queryParams.enterpriseCode" :queryParams="queryParams"></tabbar-host>
            <tabbar-site v-else></tabbar-site>
        </view>

    </view>
</template>

<script>
import building from "./list.vue";

import OperationPost from "../enterpriseResearch/post/list.vue";
import EquipmentFacilities from "../enterpriseResearch/equipment/list.vue";
import ProductionMaterials from "../enterpriseResearch/material/list.vue";
import FiniteSpace from "../enterpriseResearch/limitSpace/list.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";

export default {
    components: {
        building, //建构筑物

        OperationPost, //作业岗位组件
        EquipmentFacilities, //设备设施组件
        ProductionMaterials, //生产原辅料组件
        FiniteSpace, //有限空间 组件

        TabbarHost, //底部导航栏
        TabbarSite,
    },
    data() {
        return {
            tabList: [
                {
                    name: "建构筑物",
                },
                {
                    name: "作业岗位",
                },
                {
                    name: "设施设备",
                },
                {
                    name: "生产原辅料",
                },
                {
                    name: "有限空间",
                },
            ],
            tabIndex: 0,
            tabContentIndex: 0,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            scrollHeight: 500,
        };
    },
    mounted() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        if (this.$route.query.tabContentIndex) {
            this.tabContentIndex = this.$route.query.tabContentIndex;
        } else {
            this.tabContentIndex = this.tabIndex;
        }
    },

    onShow() {
        this.refreshPage();
    },
    methods: {
        refreshPage() {
            setTimeout(() => {
                if (this.tabContentIndex === 0) {
                    this.$refs.building.search();
                }
                if (this.tabContentIndex === 1) {
                    this.$refs.OperationPost.search();
                }
                if (this.tabContentIndex === 2) {
                    this.$refs.EquipmentFacilities.search();
                }

                if (this.tabContentIndex === 3) {
                    this.$refs.ProductionMaterials.search();
                }

                if (this.tabContentIndex === 4) {
                    this.$refs.FiniteSpace.search();
                }
            });
        },

        onTabChanged(index) {
            this.tabContentIndex = index;
            this.refreshPage();
        },
        transition(e) {
            let dx = e.detail.dx;
            this.$refs.tabs.setDx(dx);
        },
        animationfinish(e) {
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
            this.tabContentIndex = current;
            this.tabIndex = current;
        },
    },
};
</script>

<style lang="scss" scoped>
.host-ent-erprise-container {
    width: 100vw;
    height: calc(100vh);
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
    //.swiper-item1,
    // swiper-box {
    //     height: calc(100vh-50px);
    // }
}

uni-swiper {
    height: calc(100vh - 36px);
}
</style>
