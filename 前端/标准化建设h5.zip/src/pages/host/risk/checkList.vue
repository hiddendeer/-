<template name="host-danger-danger-plan">
    <view class="host-danger-danger-plan">
        <eagle-page-list :conditions="conditions" :margin-bottom="95" ref="eaglePageList" @initList="_initList" :boolInitData="false" :pageSize="20" :param="queryParams" :controller="controller" :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="queryParams" :searchResults="queryParams.year">
                        <eagle-select v-model="conditions.year.value" title="选择年份:" prop="year" border :height="70" :data-source="list" labelWidth="150">
                        </eagle-select>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class=" list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goToDetail(item.id)">
                    <eagle-row-view :isTitle="true" type="warn" maxWidth="250px">
                        {{ item.checkTaskName }}
                        <template slot="icon">
                            <span v-html="common.formateStatus(status, item.status)"></span>
                        </template>
                    </eagle-row-view>
                    <eagle-row-view>
                        隐患数: {{ item.hiddenDangerCnt }}
                    </eagle-row-view>
                    <eagle-row-view>
                        整改数: {{ item.correctiveCnt }}
                    </eagle-row-view>
                    <eagle-row-view>
                        检查人: {{ item.checkPersonChName }}
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="error" size="mini" v-if="currentUser.manager || item.status == 10" @click="hdDelete(item)">删除</u-button>
                        <u-button type="success" size="mini" @click="goToDetail(item.id)">详情</u-button>
                    </template>
                </eagle-row-card>
            </view>

        </eagle-page-list>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="back">返回</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    components: {},
    data() {
        return {
            data: [],
            list: [],
            queryParams: {
                // year: new Date().getFullYear(),
                enterpriseCode: "",
                projectId: "",
                sourceCode: "",
            },
            conditions: {
                otherCheckType: {
                    value: "",
                },
                projectId: {
                    value: "",
                },
                year: {
                    value: "",
                },
            },
            controller: "site/dangerCheckTask",
            dataType: "riskCorrectiveDetailList",
            searchValue: "",
            status: [
                {
                    id: 10,
                    name: "进行中",
                    color: "#0088ff",
                },
                {
                    id: 100,
                    name: "已完成",
                    color: "#67C23A",
                },
            ],
            currentUser: {},
        };
    },
    created() {
        var _this = this;
        let userInfoA = uni.getStorageSync("userInfo");
        if (typeof userInfoA === "string") {
            userInfoA = JSON.parse(userInfoA);
        }
        this.currentUser = userInfoA;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.list.push({
                id: i,
                name: i,
            });
        }
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.queryParams.sourceCode = this.$route.query.code ?? "";
        this.conditions.otherCheckType.value = this.$route.query.type;
        this.conditions.projectId.value = this.$route.query.code;
        this.conditions.year.value = new Date().getFullYear();
    },
    onShow() {
        this.search();
    },
    mounted() {},
    methods: {
        _initList(data) {
            this.data = data;
        },
        search() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: "",
                    params: this.queryParams,
                });
            });
        },
        reSearch() {
            // this.queryParams.year = new Date().getFullYear();
            this.conditions.year.value = new Date().getFullYear();
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        goToDetail(id) {
            let url = `/pages/host/danger/dangerPlan/view?id=${id}&enterpriseCode=${this.queryParams.enterpriseCode}&projectId=${this.queryParams.projectId}`;
            this.base.navigateTo(url);
        },
        back() {
            this.base.navigateBack();
        },
    },
};
</script>
 