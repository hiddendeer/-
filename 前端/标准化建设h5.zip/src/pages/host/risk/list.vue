<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :marginBottom="70" :controller="controller" :boolInitData="false">
            <view slot="search" class="search-slot">
                <eagle-search placeholder="请输入风险点名称进行搜索" @search="queryPage" v-model="conditions.rpName.value" :clearabled="true" :show-action="false" @clear="queryPage"></eagle-search>
            </view>
            <view slot="list" class=" list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.attachs" @click="handlerBodyClick(item.code)">
                    <eagle-row-view :isTitle="true" type="warn" maxWidth="250px">
                        {{ item.rpName }}
                        <template slot="icon">
                            {{ item.rpTypeName }}
                        </template>
                    </eagle-row-view>
                    <eagle-row-view>
                        未整改隐患数: {{ item.unCorrectiveCount }}
                    </eagle-row-view>
                    <eagle-row-view>
                        已整改隐患数: {{ item.correctiveCount }}
                    </eagle-row-view>
                    <eagle-row-view>
                        检查次数: {{ item.jdCount + item.rcCount + item.zxCount }}
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="primary" size="mini" v-if="checkTypes == 3" @click="handlerCheck(item, 'JCLX0003')">专项检查</u-button>
                        <u-button type="primary" size="mini" @click="handlerCheck(item, 'JCLX0002')">监督检查</u-button>
                        <u-button type="primary" size="mini" @click="handlerCheck(item, 'JCLX0001')">日常检查</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <view style="background:#fff;">
            <!-- <eagle-bottom-view marginBottom="120rpx" paddingBottom="10rpx">
                <u-button class="bottom-btn" type="primary" @click="scan">扫码检查</u-button>
            </eagle-bottom-view> -->
            <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
            <tabbar-site v-else></tabbar-site>
        </view>
        <eagle-add-round icon="scan" @click="scan"></eagle-add-round>
    </view>
</template>

<script>
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
export default {
    components: { TabbarHost, TabbarSite },
    data() {
        return {
            controller: "/site/riskPoint",
            list: [],
            conditions: {
                rpName: {
                    value: "",
                    operate: "like",
                },
            },
            queryParams: {
                projectId: "",
                enterpriseCode: "",
                dataType: "riskCorrectiveList",
            },
            checkTypes: 2,
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.getCheckTypes();
    },
    mounted() {},
    onShow() {
        this.queryPage();
    },
    methods: {
        getCheckTypes() {
            let url = "site/riskPointCheckList/getCheckTypeList";
            this.common
                .get(url, { companyCode: this.queryParams.enterpriseCode })
                .then((res) => {
                    if (res.code == 200) {
                        this.checkTypes = res.data.length;
                    }
                });
        },
        initList(data) {
            this.list = data;
        },
        // getCheckTypes() {
        //     let url = "site/riskPointCheckList/getCheckTypeList";
        //     this.common
        //         .get(url, { companyCode: this.queryParams.enterpriseCode })
        //         .then((res) => {
        //             if (res.code == 200) {
        //                 this.checkTypes = res.data.length;
        //             }
        //         });
        // },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    url: "/site/riskPoint/getPageData",
                    conditions: this.common.getCondtions(this.conditions),
                    params: this.queryParams,
                });
            });
        },
        handlerCheck(item, type) {
            let url =
                "site/dangerCheckTask/SaveTaskyByRisk/" +
                item.code +
                "/" +
                type;
            let _this = this;
            this.common.post(url, {}).then((res) => {
                let data = res.data;
                if (data && data.relations && data.relations.length > 0) {
                    let relations = data.relations[0].checkTemplateCode;
                    let linkUrl = this.common.getLinkUrl(
                        "pages/host/danger/dangerDetail/dangerTempCheckSingle",
                        {
                            taskCode: data.code,
                            templateCode: relations,
                            enterpriseCode: _this.queryParams.enterpriseCode,
                            projectId: _this.queryParams.projectId,
                        }
                    );
                    this.base.navigateTo(linkUrl);
                }
            });
        },
        // handlerFabClick() {
        //     let linkUrl = this.common.getLinkUrl(
        //         "pages/host/ent/building/detail",
        //         {
        //             id: 0,
        //             projectId: this.$route.query.projectId ?? "",
        //             enterpriseCode: this.$route.query.enterpriseCode ?? "",
        //         }
        //     );
        //     this.base.navigateTo(linkUrl);
        // },
        handlerBodyClick(code) {
            let _this = this;
            let linkUrl = this.common.getLinkUrl("pages/host/risk/view", {
                rpCode: code,
                enterpriseCode: _this.queryParams.enterpriseCode,
                projectId: _this.queryParams.projectId,
            });
            this.base.navigateTo(linkUrl);
        },
        scan() {
            let _this = this;
            serve.scanQRCode().then((res) => {
                if (res.data && res.data.result) {
                    let code = res.data.result;

                    if (code && code.indexOf("guan://riskPoint?code=") == 0) {
                        let md5Code = code.replace(
                            "guan://riskPoint?code=",
                            ""
                        );
                        let url = "site/riskPointQrCode/getQrCodeString";
                        this.common
                            .get(url, { md5Str: md5Code })
                            .then(function (response) {
                                console.log(response);
                                if (response.code === 200) {
                                    if (response.data.code) {
                                        let linkUrl = _this.common.getLinkUrl(
                                            "pages/host/risk/view",
                                            {
                                                rpCode: response.data.code,
                                                enterpriseCode:
                                                    _this.queryParams
                                                        .enterpriseCode,
                                                projectId:
                                                    _this.queryParams.projectId,
                                            }
                                        );
                                        _this.base.navigateTo(linkUrl);
                                    } else {
                                        _this.$refs.eaglePageList.errorMsg(
                                            "没有此二维码权限"
                                        );
                                    }
                                } else {
                                    _this.$refs.eaglePageList.errorMsg(
                                        "获取数据失败:" + res.errMsg
                                    );
                                }
                            });
                    } else {
                        this.$refs.eaglePageList.errorMsg("无效的二维码");
                    }
                }
            });
        },
    },
};
</script>

<style scoped lang="scss">
</style>
