<template>
    <view class="hsot-meeting-detail-container">
        <eagle-form @initCallBack="initCallBack" :boolInitData="false" :hasBg="false" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelAlign='left' selfHeight='calc(100vh - 125px)'>
            <eagle-container title="风险点基本信息">
                <eagle-text v-model="model.rpName" blod label="风险点">
                </eagle-text>
                <eagle-text v-model="model.rpTypeName" blod label="风险类别">
                </eagle-text>
                <eagle-text blod label="风险等级">
                    <span class="">{{model.evaluationName}}</span>
                </eagle-text>
                <eagle-text v-model="model.controlLevel" blod label="管控层级">
                </eagle-text>
                <eagle-text v-model="model.mainResponsibleChnName" blod label="管控负责人">
                </eagle-text>
                <!-- <eagle-text blod label="风险辨识信息">
                    <span class="eagle-blue point" @click="go(1)">点击查看</span>
                </eagle-text> -->
                <eagle-text blod label="未整改隐患数">
                    <span @click="goTo('unCorrective',model.unCorrectiveCount)" :class="{'eagle-grey':model.unCorrectiveCount==0}" class="eagle-blue point">{{model.unCorrectiveCount}}个<span v-if="model.unCorrectiveCount>0">(点击查看)</span></span>
                </eagle-text>
                <eagle-text blod label="已整改隐患数">
                    <span @click="goTo('corrective',model.correctiveCount)" class="eagle-blue point" :class="{'eagle-grey':model.correctiveCount==0}">{{model.correctiveCount}}个<span v-if="model.correctiveCount>0">(点击查看)</span></span>
                </eagle-text>
                <eagle-text blod label="管控检查记录">
                    <view class="eagle-blue record-block">
                        <view @click="goTo('JCLX0001',model.rcCount)" :class="{'eagle-grey':model.rcCount==0}">{{model.rpName}}日常检查 <span>{{model.rcCount}}次</span></view>
                        <view @click="goTo('JCLX0002',model.jdCount)" :class="{'eagle-grey':model.jdCount==0}">{{model.rpName}}监督检查 <span>{{model.jdCount}}次</span></view>
                        <view v-if="checkTypes==3" @click="goTo('JCLX0003',model.zxCount)" :class="{'eagle-grey':model.zxCount==0}">{{model.rpName}}专项检查 <span>{{model.zxCount}}次</span></view>
                    </view>
                </eagle-text>
            </eagle-container>
            <view style="height:120px;"></view>
            <eagle-bottom-view marginBottom="140rpx" paddingBottom="10rpx">
                <u-button class="bottom-btn" type="primary" @click="scan">扫码检查</u-button>
            </eagle-bottom-view>
            <eagle-bottom-view>
                <u-button class="bottom-btn" :disabled="!this.model.code" type="primary" @click="handlerCheck('JCLX0001')">日常检查</u-button>
                <u-button class="bottom-btn" :disabled="!this.model.code" v-if="checkTypes==3" type="primary" @click="handlerCheck('JCLX0003')">专项检查</u-button>
                <u-button class="bottom-btn" :disabled="!this.model.code" type="primary" @click="handlerCheck('JCLX0002')">监督检查</u-button>
            </eagle-bottom-view>
        </eagle-form>
    </view>
</template>

<script>
export default {
    data() {
        return {
            model: {
                code: "",
            },
            errorType: ["message"],
            control: "site/riskPoint",
            initUrl: "",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            rpCode: "",
            code: "",
            checkTypes: 2,
        };
    },
    created() {
        this.getCheckTypes();
    },
    computed: {},
    onShow() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.rpCode = this.$route.query.rpCode ?? "";
        this.code = this.$route.query.code ?? "";
        this.init();
    },
    methods: {
        getCheckTypes() {
            let url = "site/riskPointCheckList/getCheckTypeList";
            this.common
                .get(url, { companyCode: this.queryParams.enterpriseCode })
                .then((res) => {
                    if (res.code == 200) {
                        this.checkTypes = res.data.length;
                    }
                });
        },
        init() {
            let _this = this;
            if (this.rpCode) {
                let url = "site/riskPoint/getRiskCorrectiveDetail";
                this.common
                    .get(url, { code: this.rpCode })
                    .then(function (res) {
                        if (res.code === 200) {
                            _this.model = res.data ? res.data : {};
                        } else {
                            _this.$refs.eagleForm.errorMsg(
                                "获取数据失败:" + res.errMsg
                            );
                        }
                    });
            } else if (this.code) {
                this.initMd5Data();
            }
        },
        initCallBack(data) {
            this.model = data;
            console.log(data);
        },
        scan() {
            serve.scanQRCode().then((res) => {
                if (res.data && res.data.result) {
                    let code = res.data.result;
                    if (code && code.indexOf("guan://riskPoint?code=") == 0) {
                        this.code = code.replace("guan://riskPoint?code=", "");
                        this.initMd5Data();
                    } else {
                        this.$refs.eagleForm.errorMsg("无效在的二维码");
                    }
                }
            });
        },
        initMd5Data() {
            let _this = this;
            let url = "site/riskPointQrCode/getQrCodeString";
            this.common.get(url, { md5Str: this.code }).then(function (res) {
                if (res.code === 200) {
                    if (res.data.code) {
                        let rpCode = res.data.code;
                        let linkUrl = _this.common.getLinkUrl(
                            "pages/host/risk/view",
                            {
                                rpCode: rpCode,
                                enterpriseCode:
                                    _this.queryParams.enterpriseCode,
                                projectId: _this.queryParams.projectId,
                            }
                        );
                        uni.redirectTo({ url: linkUrl });
                    } else {
                        _this.$refs.eagleForm.errorMsg("没有此二维码权限");
                    }
                } else {
                    _this.$refs.eagleForm.errorMsg(
                        "获取数据失败:" + res.errMsg
                    );
                }
            });
        },
        handlerCheck(type) {
            let item = this.model;
            let url =
                "site/dangerCheckTask/SaveTaskyByRisk/" +
                item.code +
                "/" +
                type;
            let _this = this;
            this.common.post(url, {}).then((res) => {
                let data = res.data;
                if (data && data.relations && data.relations.length > 0) {
                    let relations = data.relations[0].checkTemplateCode;
                    let linkUrl = this.common.getLinkUrl(
                        "pages/host/danger/dangerDetail/dangerTempCheckSingle",
                        {
                            taskCode: data.code,
                            templateCode: relations,
                            enterpriseCode: _this.queryParams.enterpriseCode,
                            projectId: _this.queryParams.projectId,
                        }
                    );
                    this.base.navigateTo(linkUrl);
                }
            });
        },
        goTo(type, count) {
            if (count == 0) {
                return false;
            }
            let url = "pages/host/risk/checkList";
            let params = {};
            params.enterpriseCode = this.queryParams.enterpriseCode;
            params.projectId = this.queryParams.projectId;
            params.type = type;
            params.code = this.model.code;
            if (type == "unCorrective" || type == "corrective") {
                url = "pages/host/risk/correctiveList";
            }
            let linkUrl = this.common.getLinkUrl(url, params);
            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style scoped lang="scss">
.eagle-grey {
    color: #666;
}
.record-block {
    line-height: 72rpx;
    display: inline-grid;
}
</style>
