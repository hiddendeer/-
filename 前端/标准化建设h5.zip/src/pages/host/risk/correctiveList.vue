<template name="host-plan-danger-list">
    <view class="host-danger-danger-plan">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :boolInitData="false" :pageSize="20" :marginBottom="80" :controller="controller" data-type="correctiveList">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.correctiveUserType.value" title="隐患类型" prop="correctiveUserType" :data-source="params.correctiveUserType" v-if="stype == '2' && params.correctiveUserType.length > 0" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.hiddenDangerTypeCode.value" title="隐患性质" prop="certState" :data-source="params.hiddenDangerType" v-if="params.hiddenDangerType.length > 0" />
                        <eagle-input title="隐患描述" placeholder="请输入隐患描述模糊查询" v-model="conditions.hiddenDangerDesc.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class=" list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">

                    <eagle-girdrow-base isTitle>
                        {{ item.hiddenDangerDesc }}
                        <!-- <template slot="icon">
                            <span v-html="common.formateStatus(params.taskDetailStatus,item.status)"></span>
                        </template> -->
                    </eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-view v-if="item.checkTypeName">
                        <text>隐患来源：{{ item.originType | paramsFormat(params.checkSource) }}</text>
                    </eagle-girdrow-view>
                    <eagle-row-view>
                        检查时间:{{ item.createDate | dateTimeFormat }}
                    </eagle-row-view>
                    <eagle-row-view>
                        检查人:{{ item.createChnName }}
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="success" size="mini" @click="hdView(item, 0)">详情</u-button>
                        <u-button type="error" size="mini" v-if="item.manager" label="删除" @click="hdDelete(item)">删除
                        </u-button>
                        <u-button type="primary" size="mini" v-if="item.status == 30" @click="hdCorrective(item)">{{
                                item.self || item.manager ? '整改/复查' : '整改'
                        }}
                        </u-button>

                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="back">返回</u-button>
        </eagle-bottom-view>
    </view>

</template>
<script>
export default {
    props: {
        stype: { type: String, default: "1" },
    },
    components: {},
    mounted() {},
    data() {
        return {
            conditions: {
                hiddenDangerDesc: { value: "", operate: "like" },
                checkResult: { value: "N", operate: "=" },
                originType: { value: null, operate: "=" },
                status: { value: null, operate: "=" },
                hiddenDangerTypeCode: { value: null, operate: "=" },
                correctiveUserType: { value: "", operate: "=" },
            },
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                correctiveType: "",
                sourceCode: "",
            },
            controller: "site/dangerCheckTaskDetail",
            data: [],
            clearabled: true,
            mainCode: "",
            params: {
                checkSource: [
                    { id: "1", name: "随手拍" },
                    { id: "2", name: "依据检查" },
                    { id: "3", name: "检查表检查" },
                ],
                taskDetailStatus: [
                    { id: "100", name: "已复查", type: "success" },
                    { id: "60", name: "已整改", type: "success" },
                    { id: "30", name: "待整改", type: "primary" },
                ],
                hiddenDangerType: [
                    { id: "1", name: "一般隐患" },
                    { id: "2", name: "重大隐患" },
                ],
                correctiveUserType: [
                    { id: "1", name: "我的待整改隐患" },
                    { id: "2", name: "我的待复查隐患" },
                ],
            },
            pageType: 1,
        };
    },
    created() {
        this.mainCode = this.$route.query.taskCode ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.pageType = this.queryParams.projectId ? 2 : 1;
        this.queryParams.correctiveType = this.$route.query.type;
        this.queryParams.sourceCode = this.$route.query.code;
    },
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    onReady() {},
    methods: {
        bindTag(val) {
            let obj = this.params.taskDetailStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        reSearsh() {
            this.conditions.hiddenDangerDesc.value = null;
            this.conditions.originType.value = null;
            this.conditions.status.value = null;
            this.conditions.hiddenDangerTypeCode.value = null;
            this.conditions.correctiveUserType.value = null;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    console.log("hdDelete");
                    _this.search();
                },
            });
        },
        hdView(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/danger/dangerDetail/viewNew",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdClick(item, opType) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/danger/dangerDetail/detailNew",
                {
                    taskCode: item.taskCode,
                    opType: opType,
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdCorrective(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/host/danger/dangerDetail/detailCorrective",
                {
                    taskCode: item.taskCode,
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        _initList(list) {
            this.data = list;
        },

        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.queryParams,
            });
        },
        back() {
            this.base.navigateBack();
        },
    },
};
</script>
<style lang="scss">
</style>
