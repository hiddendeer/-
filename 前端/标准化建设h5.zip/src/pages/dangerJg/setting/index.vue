<template name="danger-jg-setting">
    <view class="danger-jg-setting">
        <eagle-form v-model="model" ref="eagleForm" :boolInitData="false">
            <eagle-container title="通用设置">

                <!-- <view> -->
                <!-- <view style="height: 40px;line-height: 40px;padding-left: 10px;font-size:28rpx">通用设置</view> -->
                <!-- <view style="padding: 20rpx 30rpx 0rpx 30rpx;  background-color: #fff;position: relative;"> -->
                <u-form-item label="分配检查表" label-position="top">
                    <u-button class="bottom-btn" style="position: absolute;top: 2px;right: 0px;" type="primary" size="mini" @click="dialogShow=true">选择检查表
                    </u-button>
                    <view class="eagle-orange">
                        <view v-for="(item ,index) in  templates" :key="index" style="display: block;line-height: 50rpx;">
                            {{item.templateName}}
                            <uni-icons style="margin-left:15px;color:#aaa" size="14" type="clear" @click="removeTemp(index)" />
                        </view>
                    </view>
                </u-form-item>
                <!-- </view> -->

                <eagle-switch title="是否需要隐患整改复查" :active-value="true" :inactive-value="false" v-model="model.verifyDanger" :active-color="settings.activeColor" :label-width="settings.labelWidth" :label-position="settings.labelPosition" :size="settings.size" />
                <eagle-input label-width="150px" type="textarea" title="检查要求" prop="checkRequire" v-model="model.checkRequire" placeholder="请输入检查要求;设置好后新增任务时候带出来，可以修改" clearable size="small" />
                <!-- </view> -->
            </eagle-container>
            <view>
                <eagle-container title="隐患排查报告模板设置">

                    <!-- <view style="height: 40px;line-height: 40px;padding-left: 10px; font-size:28rpx ">隐患排查报告模板设置</view> -->
                    <eagle-select labelPosition="top" title="隐患排查报告模板" :dataSource="reportTemp1" v-model="model.checkReportTemplateCode" prop="checkReportTemplateCode" @change="changeReportSource1"></eagle-select>
                    <eagle-select labelPosition="top" title="隐患整改报告模板-按任务" :dataSource="reportTemp2" v-model="model.acceptReportTemplateCode" prop="acceptReportTemplateCode" @change="changeReportSource2"></eagle-select>
                    <eagle-select labelPosition="top" title="隐患整改报告模板-按单位" :dataSource="reportTemp3" v-model="model.enterpriseAcceptReportTemplateCode" prop="enterpriseAcceptReportTemplateCode" @change="changeReportSource3"></eagle-select>
                </eagle-container>
            </view>
        </eagle-form>
        <eagle-bottom-view marginBottom="2px">
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <popup-table :isMult="true" :show.sync="dialogShow" :TagList="tagList" v-model="codes" @tableData="tableData">
        </popup-table>
    </view>
</template>

<script>
import popupTable from "@/components/eagle-check-table/popup-table";
export default {
    components: {
        popupTable,
    },
    data() {
        return {
            dialogShow: false,
            codes: "",
            tagList: [],
            settings: {
                activeColor: "#19be6b",
                labelWidth: "90%",
                labelPosition: "left",
                size: 40,
            },
            controller: "danger/dangerSettingJg",
            model: {},
            mainCode: "",
            params: {},
            projectId: "",
            enterpriseCode: "",
            templates: [],
            reportTemp1: [],
            reportTemp2: [],
            reportTemp3: [],
        };
    },
    onShow() {
        this.initData();
        if (this.$route.query && this.$route.query.enterpriseCode)
            this.enterpriseCode = this.$route.query.enterpriseCode;
        if (this.$route.query && this.$route.query.enterpriseCode)
            this.projectId = this.$route.query.projectId;
        this.getSetting();
    },
    methods: {
        getSetting() {
            let _this = this;
            let url = `${_this.controller}/getSetting/${_this.enterpriseCode}/${_this.projectId}`;
            _this.common.get(url).then((res) => {
                _this.model = res.data;
                _this.templates = [];
                if (_this.model.dangerCheckTemplateCodes) {
                    let codes = _this.model.dangerCheckTemplateCodes.split(",");
                    let names = _this.model.dangerCheckTemplateNames.split(",");
                    for (let i = 0; i < codes.length; i++) {
                        _this.templates.push({
                            checkTemplateCode: codes[i],
                            templateName: names[i],
                        });
                    }
                    // this.codes = _this.model.dangerCheckTemplateCodes
                }
            });
        },
        post() {
            let _this = this;
            _this.model.dangerCheckTemplateCodes = "";
            _this.model.dangerCheckTemplateNames = "";
            console.log(_this.templates);
            if (_this.templates && _this.templates.length > 0) {
                _this.templates.forEach((x) => {
                    _this.model.dangerCheckTemplateCodes = _this.model
                        .dangerCheckTemplateCodes
                        ? `${_this.model.dangerCheckTemplateCodes},${x.checkTemplateCode}`
                        : x.checkTemplateCode;
                    _this.model.dangerCheckTemplateNames = _this.model
                        .dangerCheckTemplateNames
                        ? `${_this.model.dangerCheckTemplateNames},${x.templateName}`
                        : x.templateName;
                });
            }
            _this.$refs.eagleForm.post({
                url: "danger/dangerSettingJg/submitSet",
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
            });
        },
        hdRemoveTemp(index) {
            this.templates.splice(index, 1);
        },
        changeReportSource1() {
            this.model.checkReportTemplateName = this.common.formateDict(
                this.reportTemp1,
                this.model.checkReportTemplateCode
            );
        },
        changeReportSource2() {
            this.model.acceptReportTemplateName = this.common.formateDict(
                this.reportTemp2,
                this.model.acceptReportTemplateCode
            );
        },
        changeReportSource3() {
            this.model.enterpriseAcceptReportTemplateName =
                this.common.formateDict(
                    this.reportTemp3,
                    this.model.enterpriseAcceptReportTemplateCode
                );
        },

        initData() {
            let _this = this;
            let url = `site/fileToolDataSource/getMap?reportType=DangerJgCheckReport`;
            _this.common.get(url).then((res) => {
                _this.reportTemp1 = res.data;
            });
            let url2 = `site/fileToolDataSource/getMap?reportType=DangerJgVerifyReportByTask`;
            _this.common.get(url2).then((res) => {
                _this.reportTemp2 = res.data;
            });

            let url3 = `site/fileToolDataSource/getMap?reportType=DangerJgVerifyReporyByEnterprise`;
            _this.common.get(url3).then((res) => {
                _this.reportTemp3 = res.data;
            });
        },
        removeTemp(index) {
            this.templates.splice(index, 1);
        },
        tableData(array) {
            let _this = this;
            array.forEach((x) => {
                if (
                    _this.templates.findIndex(
                        (p) => p.checkTemplateCode === x.id
                    ) < 0
                ) {
                    _this.templates.push({
                        checkTaskCode: _this.model.code,
                        checkTemplateCode: x.id,
                        templateName: x.name,
                    });
                }
            });
            console.log("this.templates", _this.templates);
            this.codes = "";
            this.tagList = [];
        },
    },
};
</script>

<style lang="scss" scopd>
.danger-jg-setting {
}
</style>
