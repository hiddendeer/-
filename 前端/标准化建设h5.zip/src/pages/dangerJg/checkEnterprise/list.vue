<template>
    <view class="eagle-layer">
        <view class="search">
            <eagle-search @search="search" v-model="conditions.keyWords.value" @custom='search' :show-action="false" @clear="search" placeholder='请输入被检查单位名称进行模糊查询'>
            </eagle-search>
            <!-- <u-search v-model="conditions.keyWords.value" height="76" :show-action="false" placeholder="请输入被检查单位名称进行模糊查询" @search="search" @clear="search" bg-color='#fff' shape="square">
            </u-search> -->
        </view>
        <eagle-page-list ref="eaglePageList" :queryParams="queryParams" :conditions="conditions" :pageSize="20" @initList="initList" :boolInitData="false" :controller="controller" :showCheck="true" @beforeLoad="beforeLoad" searchDisplay='none' controllerHeight="calc(100vh - 120px)">
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index">
                    <template slot="tag">
                        <span class="orange"> {{ item.applyProfessionName }}</span>
                    </template>
                    <eagle-girdrow-base isTitle>{{ item.enterpriseName }}</eagle-girdrow-base>

                    <eagle-girdrow-base sBetween>
                        <view>任务数:{{ item.taskCount }}</view>
                        <view>发现隐患数:{{ item.dangerCount }}</view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base sBetween>
                        <view>已复查隐患数:{{ item.passCount }}</view>

                        <view>整改率:{{ item.taskCount ? `${item.passScale}%` : "-" }}</view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base sBetween>
                        <view>一般隐患数:{{ item.dangerTypeCount1 }}</view>
                        <view>重大隐患数:{{ item.dangerTypeCount2 }}</view>
                    </eagle-girdrow-base>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <popupWindow ref="popupWindow" :marginBottom="170" :isMult="true" dataType="list" addUrl="pages/project/projectCompany/detail" controller="system/company" idField="code" textField="name" @callBackChoosedData="changeEnterprise" headTitle="请选择检查企业" :isUseEnterprise="false"></popupWindow>
        <!-- <tabbar-danger-jg></tabbar-danger-jg> -->
    </view>
</template>

<script>
import popupWindow from "@/components/eagle-window-choose/popup-window";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg";
export default {
    components: {
        popupWindow,
        TabbarDangerJg,
    },
    data() {
        return {
            controller: "/danger/checkEnterprise",
            datatype: "List",
            list: [],
            queryParams: {
                projectId: this.$route.query.projectId ?? "",
            },
            conditions: {
                keyWords: {
                    value: "",
                },
            },
        };
    },
    onShow() {
        this.search();
    },
    methods: {
        handlerFabClick() {
            this.$refs.popupWindow.show();
        },
        changeEnterprise(data) {
            let _this = this;
            if (data && data.length > 0) {
                let array = [];
                data.forEach((item, index) => {
                    array.push({
                        enterpriseName: item.name,
                        enterpriseCode: item.code,
                        projectId: _this.queryParams.projectId,
                    });
                });
                let url = `${_this.controller}/pushEnterprise/${_this.queryParams.projectId}`;
                _this.common.post(url, array).then((res) => {
                    if (res.code == 200 && res.data.result) {
                        _this.$refs.eaglePageList.successMsg("操作成功");
                        _this.search();
                    }
                });
            }
        },
        search() {
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        handlerDel(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;

            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        initList(list) {
            this.list = list;
        },
    },
};
</script>

<style lang="scss">
.host-ent-erprise-container {
    width: 100vw;
    height: calc(100vh - 80px);
    overflow: hidden;
    box-sizing: border-box;
}
</style>
