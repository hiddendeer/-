<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" dataType="verifyList" @initList="_initList" :pageSize="20" :boolInitData="false" :controller="controller" :margin-bottom="marginBottom" @beforeLoad="beforeLoad" :showCheck="true">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" v-model="searchValue" @reSearch="reSearsh">

                        <eagle-fast-choose itemWidth="200rpx" title="复查状态" v-model="conditions.status.value" prop="status" :dataSource="kvs.taskStatus" />

                        <eagle-fast-choose itemWidth="200rpx" title="整改报告" v-model="conditions.reportStatus.value" prop="reportStatus" :dataSource="kvs.reportStatus" />

                        <eagle-input title="名称" placeholder="任务名称" v-model="conditions.checkTaskName.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdLinkDetail(item)">
                    <!-- <view @click="hdLinkDetail(item)"> -->
                    <eagle-girdrow-base isTitle>{{ item.checkTaskName }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-base>被检查单位:{{ item.enterpriseName }}</eagle-girdrow-base>
                    <eagle-girdrow-base>
                        <view>开始/截止日期 :{{ item.startDate | dateFormat }} ~ {{ item.endDate | dateFormat }}</view>
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        <view>检查人 : {{ item.checkNames }}</view>
                    </eagle-girdrow-base>
                    <!-- </view> -->
                    <!-- <eagle-girdrow-base sBetween>
                        <view class="double-line">创建日期 : {{ item.startDate|dateFormat}}</view>
                        <view class="double-line">创建人 : {{item.createChnName}} </view>
                    </eagle-girdrow-base> -->
                    <template slot="button">
                        <u-button type="error" v-if="item.status == 30" @click="hdUnVerify(item.code)" size="mini">
                            无需复查
                        </u-button>
                        <u-button type="primary" v-if="item.status == 100 && item.unNextVerify" @click="backVerify(item.code)" size="mini">恢复复查
                        </u-button>
                        <u-button type="primary" v-if="item.status == 100&&(item.unNextVerify)!=true" @click="buildVerifyReport(item)" size="mini">
                            生成整改报告
                        </u-button>
                        <u-button type="success" v-if="item.status == 30" @click="hdLinkVerifyTask(item)" size="mini">
                            复查
                        </u-button>
                        <u-button type="success" v-else @click="hdLinkDetail(item)" size="mini">详情</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <!-- <verifyTaskReport ref="verifyTaskReport" @saved="() => { refresh() }" /> -->
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
        <!-- <tabbar-danger-jg v-if="paramsUrl.enterpriseCode"></tabbar-danger-jg>
        <tabbar-danger-jg-index v-else></tabbar-danger-jg-index> -->
    </view>

</template>


<script>
// import verifyTaskReport from "@/pages/dangerJg/report/buildTaskVerifyReport";
// import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg";
// import TabbarDangerJgIndex from "@/pages/components/tabbar/tabbar-dangerJg-index.vue";

export default {
    // components: { verifyTaskReport, TabbarDangerJg, TabbarDangerJgIndex },
    data() {
        return {
            marginBottom: 10,
            searchValue: {
                enterpriseCode: "",
                projectId: "",
            },
            paramsUrl: {
                enterpriseCode: "",
                projectId: "",
            },
            conditions: {
                checkTaskName: { value: "", operate: "like" },
                status: { value: null, operate: "=" },
                reportStatus: { value: null, operate: "=" },
            },
            controller: "/danger/jgDangerTask",
            data: [],
            clearabled: true,
            kvs: {
                taskStatus: [
                    { id: "", name: "不限" },
                    { id: "30", name: "待复查", type: "red" },
                    { id: "100", name: "已结束", type: "success" },
                ],
                reportStatus: [
                    { id: "", name: "不限" },
                    { id: "1", name: "已生成整改报告", color: "#dd6161" },
                    { id: "2", name: "未生成整改报告", color: "#67C23A" },
                ],
            },
        };
    },
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    created() {
        this.searchValue.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.searchValue.projectId = this.$route.query.projectId ?? "";
        this.marginBottom = this.searchValue.projectId ? 65 : 25;
        this.paramsUrl.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.paramsUrl.projectId = this.$route.query.projectId ?? "";
    },
    methods: {
        bindTag(val) {
            console.log(val);
            let obj = this.kvs.taskStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },

        /**刷新 */
        refresh() {
            this.search();
        },
        /**不在复查 */
        hdUnVerify(code) {
            let _this = this;
            _this.confirm("是否确定该检查任务无需复查?", () => {
                let url = `${_this.controller}/unVerify/${code}`;
                _this.common.post(url).then((res) => {
                    if (res.code == 200) {
                        _this.successMsg("操作成功");
                        _this.search();
                    }
                    // else {
                    //     _this.errorMsg(res.errorText)
                    // }
                });
            });
        },
        /**恢复复查 */
        backVerify(code) {
            let _this = this;

            _this.confirm("是否确定该检查任务恢复复查?", () => {
                let url = `${_this.controller}/backVerify/${code}`;
                _this.common.post(url).then((res) => {
                    if (res.code == 200) {
                        _this.successMsg("操作成功");
                        _this.search();
                    }
                    // else {
                    //     _this.errorMsg(res.errorText)
                    // }
                });
            });
        },

        /**生成整改报告 */
        buildVerifyReport(item) {
            let _this = this;
            _this.submitPopup = false;
            // this.$refs.verifyTaskReport.show({
            //     optionModel: {
            //         relationName: item.checkTaskName,
            //         relationCode: item.code,
            //         relationType: 2,
            //         projectId: item.sourceCode,
            //         enterpriseCode: item.enterpriseCode,
            //         enterpriseName: item.enterpriseName,
            //     },
            // });
            let url = "pages/dangerJg/report/detail";
            let linkUrl = this.common.getLinkUrl(url, {
                taskCode: item.code,
                enterpriseCode: item.enterpriseCode,
                projectId: item.sourceCode,
                reportType: "3",
            });
            this.base.navigateTo(linkUrl);
        },
        /**重置 */
        reSearsh() {
            this.conditions.checkTaskName.value = "";
            this.conditions.status.value = null;
            this.conditions.reportStatus.value = null;
            this.search();
        },
        _initList(list) {
            this.data = list;
        },
        /**查询 */
        search() {
            let _this = this;
            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.searchValue,
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        hdLinkVerifyTask(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/dangerJg/taskDetail/taskDangerList",
                {
                    taskCode: item.code,
                    enterpriseCode: this.searchValue.enterpriseCode,
                    projectId: this.searchValue.projectId,
                    status: 30,
                }
            );
            this.goto(linkUrl);
        },
        hdLinkDetail(item) {
            let url = this.common.getLinkUrl("/pages/dangerJg/task/view", {
                taskCode: item.code,
                enterpriseCode: this.searchValue.enterpriseCode,
                projectId: this.searchValue.projectId,
            });
            this.goto(url);
        },
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        confirm(content, callback) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
            });
        },
    },
};
</script>


<style lang="scss">
.list_row {
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
}

.list_row_value {
    margin-left: 5px;
}

.list_title_row {
    display: flex;
    justify-content: space-between;
}
</style>
