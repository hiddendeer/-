<template name="danger-danger-jg-verify-index">
    <view class="danger-danger-jg-verify-index eagle-layer">
        <view class="u-tabs-box">
            <u-tabs-swiper activeColor="#2979ff" inactive-color="#606266" name="Name" :showBar="false" ref="tabs" :list="tabList" :bar-width="100" :current="tabContentIndex" @change="onTabChanged" :is-scroll="false">
            </u-tabs-swiper>
        </view>
        <verfyTaskList ref="verfyTaskList" v-if="tabContentIndex==0" />
        <verfyEnterpriseList ref="verfyEnterpriseList" v-if="tabContentIndex==1" />
        <!-- <view></view>
        <view></view> -->
        <!-- <tabbar-danger-jg v-if="enterpriseCode"></tabbar-danger-jg>
        <tabbar-danger-jg-index v-else></tabbar-danger-jg-index> -->
    </view>

</template>
<script>
import verfyEnterpriseList from "@/pages/dangerJg/dangerJgVerify/verfyEnterpriseList";
import verfyTaskList from "@/pages/dangerJg/dangerJgVerify/verfyTaskList";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg.vue";
import TabbarDangerJgIndex from "@/pages/components/tabbar/tabbar-dangerJg-index.vue";

export default {
    components: {
        verfyEnterpriseList,
        verfyTaskList,
        TabbarDangerJg,
        TabbarDangerJgIndex,
    },
    data() {
        return {
            tabList: [{ name: "按任务复查" }, { name: "按单位复查" }],
            tabContentIndex: 0,
            enterpriseCode: "",
        };
    },
    onLoad() {
        this.tabContentIndex = this.$route.query.index ?? 0;
    },
    created() {
        this.enterpriseCode = this.$route.query.enterpriseCode;
        console.log(this.enterpriseCode);
    },
    onShow() {
        setTimeout(() => {
            this.refresh();
        });
    },
    methods: {
        onTabChanged(index) {
            this.tabContentIndex = index;
            setTimeout(() => {
                this.refresh();
            });
        },
        //刷新
        refresh() {
            switch (this.tabContentIndex) {
                case 0:
                    this.$refs.verfyTaskList.refresh();
                    break;
                case 1:
                    this.$refs.verfyEnterpriseList.refresh();
                    break;
            }
        },
    },
};
</script>


<style lang="scss">
.host-ent-erprise-container {
    width: 100vw;
    height: calc(100vh - 80px);
    overflow: hidden;
    box-sizing: border-box;

    .swiper-box {
        width: 100%;
        height: calc(100vh - 125px);

        .swiper-item {
            width: 100%;
            height: 100%;
        }
    }
}
</style>
