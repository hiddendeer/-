<template>

    <view class="danger-verfy-task-view">
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>

        <eagle-form :control="controller" v-model="model" ref="eagleForm" :out-height='50' :boolInitData="false" action="detail" by-code :errorType="errorType" @initCallBack="bindData">
            <eagle-container title="检查任务信息">

                <!-- <eagle-form-block title="检查任务信息"> -->
                <eagle-text v-model="model.checkTaskName" blod label="任务名称">
                </eagle-text>
                <eagle-text blod label="检查类型">
                    {{common.formateDict(kvs.checkType, model.checkType)}}
                </eagle-text>
                <eagle-text v-model="model.enterpriseName" blod label="被检查单位">
                </eagle-text>
                <eagle-text v-model="model.checkNames" blod label="检查人">
                </eagle-text>
                <eagle-text blod label="开始/结束日期">
                    {{model.startDate|dateFormat}} ~ {{model.endDate|dateFormat}}
                </eagle-text>
                <eagle-text blod label="状态">
                    <span v-html="common.formateStatus(kvs.taskStatus,model.status)"></span>
                    <span v-if="model.unNextVerify" style="color:red">(无需复查)</span>
                </eagle-text>
                <eagle-text blod label="检查记录">
                    <span style=" color:#0088ff; " @click="hdShowDangerList"> 隐患数: {{dangerNums.dangerCount||0}} / 待复查: {{dangerNums.waitVerifyCount||0}}</span>
                </eagle-text>
                <!-- </eagle-form-block> -->
            </eagle-container>
            <eagle-container title="报告">
                <!-- <eagle-form-block title="报告"> -->
                <eagle-text blod label="隐患清单">
                    <eagle-grid-attach v-if="model.dangerListReportAttach" title="" v-model="model.dangerListReportAttach"></eagle-grid-attach>
                </eagle-text>
                <eagle-text blod label="检查报告">
                    <eagle-grid-attach title="" v-model="model.checkAttachs"></eagle-grid-attach>
                </eagle-text>
                <eagle-text blod label="整改报告">
                    <eagle-grid-attach v-if="model.verifyAttachs" title="" v-model="model.verifyAttachs"></eagle-grid-attach>
                </eagle-text>
            </eagle-container>
            <!-- </eagle-form-block> -->
            <!-- <view class="pannel">
                <u-form-item label="任务名称" label-width="220" :label-position="constLabelPosition">
                    {{model.checkTaskName}}
                </u-form-item>
                <u-form-item label="检查类型" label-width="220" :label-position="constLabelPosition">
                    {{common.formateDict(kvs.checkType, model.checkType)}}
                </u-form-item>
                <u-form-item label="被检查单位" label-width="220" :label-position="constLabelPosition">
                    {{model.enterpriseName}}
                </u-form-item>
                <u-form-item label="检查人" label-width="220" :label-position="constLabelPosition">
                    {{model.checkNames}}
                </u-form-item>
                <u-form-item label="开始/结束日期" label-width="220" :label-position="constLabelPosition">
                    {{model.startDate|dateFormat}} ~ {{model.endDate|dateFormat}}
                </u-form-item>
            </view>
            <view class="pannel">
                <u-form-item label="状态" label-width="220" :label-position="constLabelPosition" class="base-item">
                    <view v-html="common.formateStatus(kvs.taskStatus,model.status)"></view>
                </u-form-item>
                <u-form-item label="检查记录" label-width="220" :label-position="constLabelPosition" class="base-item">
                    <view style="display: unset;  color: #0088ff; width: 100%;" @click="hdShowDangerList">
                        隐患数: {{dangerNums.dangerCount||0}} 待复查: {{dangerNums.waitVerifyCount||0}}
                    </view>
					
					<view @click="hdShowDangerList">
					    <u-icon name="arrow-right" color="#e1e1e1" size="28"></u-icon>
					</view>

                </u-form-item>

            </view>

            <view class="pannel">
                <u-form-item label="隐患清单" label-width="180" :label-position="constLabelPosition">
                    <eagle-grid-attach title="" v-model="model.dangerListReportAttach"></eagle-grid-attach>
                </u-form-item>
                <u-form-item label="检查报告" label-width="180" :label-position="constLabelPosition">
                    <eagle-grid-attach title="" v-model="model.checkAttachs"></eagle-grid-attach>
                </u-form-item>
                <u-form-item label="整改报告" label-width="180" :label-position="constLabelPosition">
                    <eagle-grid-attach title="" v-model="model.verifyAttachs"></eagle-grid-attach>
                </u-form-item>
            </view> -->

        </eagle-form>

        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="buildVerifyReport">生成整改报告</u-button>
        </eagle-bottom-view>
        <verifyTaskReport ref="verifyTaskReport" @saved="reportAttach" />
    </view>
</template>
<script>
import verifyTaskReport from "@/pages/dangerJg/report/buildTaskVerifyReport";
export default {
    components: { verifyTaskReport },
    data() {
        return {
            constLabelPosition: "left",
            taskCode: "",
            model: {},
            dangerNums: {},
            errorType: ["message"],
            controller: "danger/jgDangerTask",
            detailController: "danger/jgDangerTaskDetail",
            reportController: "danger/dangerJgReport",
            kvs: {
                checkType: [],
                taskStatus: [
                    { id: 30, name: "待复查", color: "#dd6161" },
                    // { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
        };
    },
    onShow() {
        {
            this.model.code = this.$route.query.taskCode;
            this.initParams();
            setTimeout(() => {
                this.refresh();
                this.bindData();
            });
        }
    },
    methods: {
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        confirm(content, callback) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
            });
        },
        refresh() {
            this.$refs.eagleForm.refresh();
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("danger_check_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.kvs.checkType = res.data.filter(
                            (p) => p.paramId == "danger_check_plan_type"
                        );
                    }
                });
        },
        /**生成整改报告 */
        buildVerifyReport() {
            let _this = this;
            this.$refs.verifyTaskReport.show({
                optionModel: {
                    relationName: _this.model.checkTaskName,
                    relationCode: _this.model.code,
                    relationType: 2,
                    projectId: _this.model.sourceCode,
                    enterpriseCode: _this.model.enterpriseCode,
                    enterpriseName: _this.model.enterpriseName,
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        bindData() {
            let _this = this;
            let url = `/${_this.detailController}/getVerifyNumByTask/${_this.model.code}`;
            console.log(url);
            _this.common.get(url).then((res) => {
                _this.dangerNums = res.data;
            });
        },
        hdShowDangerList() {
            this.goto(
                this.common.getLinkUrl(
                    "/pages/dangerJg/taskDetail/taskDangerList",
                    {
                        taskCode: this.model.code,
                        endStatus: 20,
                        status: 30,
                    }
                )
            );
        },
        reportAttach(item) {
            let fileList = [];
            if (item.reportAttach) {
                if (typeof item.reportAttach == "string") {
                    var arryFile = JSON.parse(item.reportAttach);
                    fileList = arryFile;
                } else {
                    fileList = item.reportAttach;
                }
            }
            if (fileList.length > 0) {
                let model = fileList[0];
                var url =
                    "/pages/common/pdfView?code=" + model.attCode ||
                    model.AttCode;
                this.base.navigateTo(url);
            }
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-verfy-task-view {
    .more-btn-group {
        .u-btn {
            margin-top: 20rpx;
        }
    }
    .pannel {
        background-color: rgb(255, 255, 255);
        // padding: 5px;
        // margin-top: 10px;
        margin-bottom: 10px;
        padding-left: 15px;
    }

    .base-item {
        line-height: 68rpx !important;
    }
    .popup-title {
        font-size: 15px;
        padding: 8px;
        border-bottom: solid 1px #c0c4cc;
    }
    .popup-body {
        padding: 10px;
    }
    .detail-btn-group {
        //popup-body

        display: flex;
        justify-content: space-between;
        .btn {
            display: block;
            border: 1px solid #c0c4cc;
            width: 31%;
            font-size: 13px;
            height: 35px;
            line-height: 35px;
            padding: 0 10px;
            text-align: center;
            border-radius: 4px;
        }
        .btn.info {
            color: #606266;
            background-color: #ffffff;
        }
        .btn.primary {
            color: #ffffff;
            background-color: #2979ff;
        }
        .btn.error {
            color: #ffffff;
            background-color: red;
        }
    }
}
</style>
