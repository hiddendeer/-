<template>
    <view>
        <eagle-page-list ref="eaglePageList" dataType="verifyList" @initList="_initList" :pageSize="20" :boolInitData="false" :controller="controller" :margin-bottom="45" @beforeLoad="beforeLoad" :showCheck="true">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" v-model="searchValue" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" title="复查状态" v-model="conditions.checkStatus.value" prop="status" :dataSource="kvs.taskStatus" />
                        <eagle-fast-choose itemWidth="200rpx" title="整改报告" v-model="conditions.reportStatus.value" prop="reportStatus" :dataSource="kvs.reportStatus" />
                        <eagle-input title="单位名称" placeholder="单位名称" v-model="conditions.enterpriseName.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdLinkDetail(item)">
                    <eagle-girdrow-base>被检查单位:{{ item.enterpriseName }}</eagle-girdrow-base>
                    <view>
                        状态 :<text v-if="item.waiteVerifyCount > 0" style="color:#F56C6C"> 待复查 </text>
                        <text v-else style="color:#67C23A"> 已完成 </text>
                    </view>
                    <view>
                        <text>检查次数 :{{ item.taskCount }} </text>
                    </view>
                    <view>
                        <text>检查隐患数 :{{ item.dangerCount }} </text>
                    </view>
                    <view>
                        <text>待复查隐患数:{{ item.waiteVerifyCount }} </text>
                    </view>
                    <template slot="button">

                        <u-button style="margin-left: 5px;" type="primary" @click="buildVerifyReport(item)" size="mini">
                            生成整改报告</u-button>
                        <u-button type="success" v-if="item.waiteVerifyCount > 0" @click="hdVerifyLink(item)" size="mini">
                            复查</u-button>
                        <u-button style="margin-left: 5px;" type="success" v-else @click="hdLinkDetail(item)" size="mini">
                            详情</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <verifyTaskReport ref="verifyTaskReport" @saved="reportAttach" />
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>
<script>
import verifyTaskReport from "@/pages/dangerJg/report/buildTaskVerifyReport";
export default {
    components: { verifyTaskReport },
    data() {
        return {
            searchValue: {
                enterpriseCode: "",
                projectId: "",
            },
            conditions: {
                enterpriseName: { value: "", operate: "like" },
                checkStatus: { value: null, operate: "=" },
                reportStatus: { value: null, operate: "=" },
            },
            controller: "/danger/checkEnterprise",
            data: [],
            clearabled: true,
            kvs: {
                taskStatus: [
                    { id: "", name: "不限", color: "#F56C6C" },
                    { id: "2", name: "待复查", color: "#F56C6C" },
                    { id: "1", name: "已完成", color: "#67C23A" },
                ],
                reportStatus: [
                    { id: "", name: "不限", color: "#F56C6C" },
                    { id: "1", name: "已生成整改报告", color: "#F56C6C" },
                    { id: "2", name: "未生成整改报告", color: "#67C23A" },
                ],
            },
        };
    },
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    created() {
        this.searchValue.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.searchValue.projectId = this.$route.query.projectId ?? "";
    },
    methods: {
        /**刷新 */
        refresh() {
            this.search();
        },
        /**生成整改报告 */
        buildVerifyReport(item) {
            let url = "pages/dangerJg/report/detail";
            let linkUrl = this.common.getLinkUrl(url, {
                checkedEnterprise: item.enterpriseCode,
                projectId: this.searchValue.projectId,
                reportType: "4",
            });
            this.base.navigateTo(linkUrl);
            // let _this = this;
            // _this.submitPopup = false;
            // this.$refs.verifyTaskReport.show({
            //     optionModel: {
            //         relationName: item.enterpriseName,
            //         relationCode: item.enterpriseCode,
            //         relationType: 1,
            //         projectId: item.projectId,
            //         enterpriseCode: item.enterpriseCode,
            //         enterpriseName: item.enterpriseName,
            //     },
            // });
        },
        /**重置 */
        reSearsh() {
            this.conditions.enterpriseName.value = "";
            this.conditions.checkStatus.value = null;
            this.conditions.reportStatus.value = null;
            this.search();
        },
        _initList(list) {
            this.data = list;
        },
        /**查询 */
        search() {
            let _this = this;
            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.searchValue,
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        hdLinkDetail(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/dangerJg/dangerJgVerify/verfyEnterpriseView",
                {
                    enterpriseCode: item.enterpriseCode,
                    code: item.code,
                    projectId: item.projectId,
                }
            );
            this.goto(linkUrl);
        },
        hdVerifyLink(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/dangerJg/taskDetail/enterpriseDangerList",
                {
                    enterpriseCode: item.enterpriseCode,
                    projectId: item.projectId,
                }
            );
            this.goto(linkUrl);
        },
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        confirm(content, callback) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
            });
        },
        reportAttach(item) {
            let fileList = [];
            if (item.reportAttach) {
                if (typeof item.reportAttach == "string") {
                    var arryFile = JSON.parse(item.reportAttach);
                    fileList = arryFile;
                } else {
                    fileList = item.reportAttach;
                }
            }
            if (fileList.length > 0) {
                let model = fileList[0];
                var url =
                    "/pages/common/pdfView?code=" + model.attCode ||
                    model.AttCode;
                this.base.navigateTo(url);
            }
        },
    },
};
</script>


<style lang="scss">
.list_row {
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
}

.list_row_value {
    margin-left: 5px;
}

.list_title_row {
    display: flex;
    justify-content: space-between;
}
</style>
