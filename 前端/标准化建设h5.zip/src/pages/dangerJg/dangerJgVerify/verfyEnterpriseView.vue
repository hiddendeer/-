<template name="danger-verfy-enterprise-view">

    <view class="danger-verfy-enterprise-view">
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>

        <eagle-form :control="controller" v-model="model" ref="eagleForm" :out-height='50' :boolInitData="false" action="detail" by-code :errorType="errorType" @initCallBack="bindData">
            <eagle-container title="检查详情">
                <!-- <eagle-form-block title="检查详情"> -->
                <eagle-text title="检查人">
                    {{ model.checkNames }}
                </eagle-text>
                <eagle-text title="被检查单位">
                    {{ model.enterpriseName }}
                </eagle-text>
                <eagle-text blod label="检查记录">
                    <span style=" color:#0088ff; " @click="hdShowDangerList"> 隐患数: {{ dangerNums.dangerCount || 0 }} /
                        待复查:
                        {{ dangerNums.waitVerifyCount || 0 }}</span>
                </eagle-text>
                <eagle-text blod label="整改报告">
                    <eagle-grid-attach title="" v-model="model.verifyAttach"></eagle-grid-attach>
                </eagle-text>
            </eagle-container>
        </eagle-form>

        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="buildVerifyReport">生成整改报告</u-button>
        </eagle-bottom-view>
        <verifyTaskReport ref="verifyTaskReport" @saved="reportAttach" />
    </view>
</template>
<script>
import verifyTaskReport from "@/pages/dangerJg/report/buildTaskVerifyReport";
export default {
    components: { verifyTaskReport },
    data() {
        return {
            enterpriseCode: "",
            projectId: "",
            constLabelPosition: "left",
            model: {},
            dangerNums: {},
            errorType: ["message"],
            controller: "danger/checkEnterprise",
            detailController: "danger/jgDangerTaskDetail",
            reportController: "danger/dangerJgReport",
            kvs: {
                checkType: [],
                taskStatus: [
                    { id: 2, name: "待复查", color: "#dd6161" },
                    // { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
        };
    },
    created() {
        this.projectId = this.$route.query.projectId ?? "";
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.model.code = this.$route.query.code ?? "";
        this.initParams();
    },
    onShow() {
        setTimeout(() => {
            this.refresh();
            // this.bindData();
        });
    },
    methods: {
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        refresh() {
            this.$refs.eagleForm.refresh();
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("danger_check_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.kvs.checkType = res.data.filter(
                            (p) => p.paramId == "danger_check_plan_type"
                        );
                    }
                });
        },
        /**生成整改报告 */
        buildVerifyReport() {
            let _this = this;
            this.$refs.verifyTaskReport.show({
                optionModel: {
                    relationName: _this.model.enterpriseName,
                    relationCode: _this.model.enterpriseCode,
                    relationType: 1,
                    projectId: _this.model.projectId,
                    enterpriseCode: _this.model.enterpriseCode,
                    enterpriseName: _this.model.enterpriseName,
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        bindData() {
            let _this = this;
            let url = `/${_this.detailController}/getVerifyNumByEnterprise/${_this.projectId}/${_this.enterpriseCode}`;
            console.log(url);
            _this.common.get(url).then((res) => {
                _this.dangerNums = res.data;
            });
        },
        hdShowDangerList() {
            this.goto(
                this.common.getLinkUrl(
                    "/pages/dangerJg/taskDetail/enterpriseDangerList",
                    {
                        enterpriseCode: this.model.enterpriseCode,
                        projectId: this.model.projectId,
                    }
                )
            );
        },
        reportAttach(item) {
            debugger;
            let fileList = [];
            if (item.reportAttach) {
                if (typeof item.reportAttach == "string") {
                    var arryFile = JSON.parse(item.reportAttach);
                    fileList = arryFile;
                } else {
                    fileList = item.reportAttach;
                }
            }
            if (fileList.length > 0) {
                let model = fileList[0];
                var url =
                    "/pages/common/pdfView?code=" + model.attCode ||
                    model.AttCode;
                this.base.navigateTo(url);
            }
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-verfy-enterprise-view {
    .more-btn-group {
        .u-btn {
            margin-top: 20rpx;
        }
    }

    .pannel {
        background-color: rgb(255, 255, 255);
        // padding: 5px;
        // margin-top: 10px;
        margin-bottom: 10px;
        padding-left: 15px;
    }

    .base-item {
        line-height: 68rpx !important;
    }

    .popup-title {
        font-size: 15px;
        padding: 8px;
        border-bottom: solid 1px #c0c4cc;
    }

    .popup-body {
        padding: 10px;
    }

    .detail-btn-group {
        //popup-body

        display: flex;
        justify-content: space-between;

        .btn {
            display: block;
            border: 1px solid #c0c4cc;
            width: 31%;
            font-size: 13px;
            height: 35px;
            line-height: 35px;
            padding: 0 10px;
            text-align: center;
            border-radius: 4px;
        }

        .btn.info {
            color: #606266;
            background-color: #ffffff;
        }

        .btn.primary {
            color: #ffffff;
            background-color: #2979ff;
        }

        .btn.error {
            color: #ffffff;
            background-color: red;
        }
    }
}
</style>
