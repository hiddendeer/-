<template name="dangerJg-report-detail">
    <!-- <view class="dangerJg-report-detail">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">生成检查报告</eagle-head> -->
    <view>
        <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" :out-height='55'>
            <eagle-container>
                <view class="item">
                    <eagle-input prop="reportName" title="报告名称" v-model="model.reportName" required />
                    <eagle-radios title="报告模板" key="reportTemplateCode1" prop="reportTemplateCode" v-if="reportTemp && reportTemp.length>0" required :dataSource="reportTemp" @change="changeReportSource" v-model="model.reportTemplateCode" />
                    <eagle-date type="daterange" :startDate.sync="model.startDate" :endDate.sync="model.endDate" title="开始/结束日期" prop="startsDate" required rangeSeparator="至" />
                    <eagle-input key="remarks" type="textarea" title="总结和建议" v-model="model.remarks" />
                </view>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">生成报告</u-button>
        </eagle-bottom-view>
    </view>
    <!-- </u-popup>
        <u-toast ref="uToast" />
    </view> -->
</template>

<script>
export default {
    name: "dangerJg-report-detail",
    data() {
        return {
            model: {},
            control: "danger/report",
            reportTemp: [],
            datetimes: [],
            showDialog: false,
            reportTemplateCode: null,
            taskCode: "",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            reportType:"2"
        };
    },
    created() {
        this.taskCode = this.$route.query.taskCode ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.show();
    },
    methods: {
        changeReportSource() {
            this.model.reportTemplateName = this.common.formateDict(
                this.reportTemp,
                this.model.reportTemplateCode
            );
        },

        // changDateRang() {
        //     if (this.model.datetimes && this.model.datetimes.length > 0) {
        //         this.model.startDate = this.model.datetimes[0];
        //         this.model.endDate = this.model.datetimes[1];
        //     }
        // },
        bindData() {
            let _this = this;
            let url = `site/fileToolDataSource/getMap?reportType=DangerJgCheckReport`;
            _this.common.get(url).then((res) => {
                _this.reportTemp = res.data;
                if (res.data) {
                    _this.reportTemplateCode = res.data[0].id;
                    _this.reportTemplateName = res.data[0].name;
                    _this.model.reportTemplateCode = _this.reportTemplateCode;
                }
                // _this.initModel();
            });

            // this.model.sourceName = this.taskNames;
            // this.model.sourceId = this.taskCodes;
            // this.model.projectId = this.projectId;
            // _this.model.dataType = 1
            //_this.getReportTemp();
        },
        //initModel() {
        //let _this = this;
        // _this.model.reportName = _this.taskModel.checkTaskName;
        // _this.model.datetimes = [];
        // _this.model.datetimes.push(_this.model.startDate);
        // _this.model.datetimes.push(_this.model.endDate);
        // _this.model.sourceName = _this.taskModel.checkTaskName;
        // _this.model.sourceId = _this.taskModel.code;
        // _this.model.enterpriseCode = _this.taskModel.enterpriseCode;
        // _this.model.enterpriseName = _this.taskModel.enterpriseName;
        // _this.model.projectId = _this.taskModel.sourceCode;
        // if (_this.reportTemplateCode) {
        //     _this.model.reportTemplateCode = _this.reportTemplateCode;
        // }
        //},
        //弹窗改跳转
        show() {
            let _this = this;
            // _this.showDialog = true;
            // _this.taskModel = config.taskModel;
            // console.log("config=>", config)

            let url = `${_this.control}/initData/0?projectId=${_this.queryParams.projectId}&taskCode=${_this.taskCode}&reportType=2`;
            _this.common.get(url).then((res) => {
                _this.model = res.data;
                _this.bindData();
            });
        },
        // getReportTemp() {
        //     let url = `site/fileToolDataSource/getMap?reportType=DangerJgCheckReport`;
        //     let _this = this;
        //     _this.common.get(url).then((res) => {
        //         _this.reportTemp = res.data;
        //         if (res.data) {
        //             _this.reportTemplateCode = res.data[0].id;
        //             _this.reportTemplateName = res.data[0].name;
        //         }
        //     });
        // },
        post() {
            let _this = this;
            this.$refs.eagleForm.post({
                url: "/danger/jgDangerTask/buildDangerCheckReportNew",
                successCallback: function (res) {
                    if (res.code == "200") {
                        let item = res.data.report;
                        let attach = JSON.parse(item.reportAttach)[0];
                        var url = _this.common.getLinkUrl(
                            "/pages/dangerJg/report/sign",
                            {
                                code: attach.attCode || attach.AttCode,
                                reportCode: item.code,
                            }
                        );
                        uni.reLaunch({
                            url: url,
                        });
                        // _this.base.navigateTo(url);
                    }

                    // _this.showDialog = false;
                    // _this.$emit("saved")
                    // let item = res.data.report;
                    // _this.$emit("saved", item);
                },
            });
        },
    },
};
</script>

<style lang="scss">
</style>
