<template name="build-task-verify-report">
    <view class="build-task-verify-report">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">生成整改报告</eagle-head>
            <view>
                <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" :out-height='55'>
                    <eagle-container>
                        <view class="item">
                            <eagle-input prop="reportName" title="报告名称" v-model="model.reportName" required />
                            <eagle-radios title="报告模板" key="reportTemplateCode" prop="reportTemplateCode" v-if="reportTemp && reportTemp.length>0" required :dataSource="reportTemp" @change="changeReportSource" v-model="model.reportTemplateCode" />
                            <eagle-date title="检查起始时间" prop="datetimes" @change="changDateRang" v-model="model.datetimes" required type="range" rangeSeparator="至" />
                            <eagle-input key="remarks" type="textarea" title="总结和建议" v-model="model.remarks" />
                        </view>
                    </eagle-container>
                </eagle-form>
                <eagle-bottom-view>
                    <u-button type="primary" class="bottom-btn" @click="post()">生成报告</u-button>
                </eagle-bottom-view>
            </view>
        </u-popup>
        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    name: "build-task-verify-report",
    data() {
        return {
            model: {},
            control: "danger/report",
            reportTemp: [],
            taskModel: {},
            showDialog: false,
            optionModel: {
                relationName: "",
                relationCode: "",
                relationType: null,
                projectId: "",
                enterpriseCode: "",
            },
            reportTemplateCode: null,
        };
    },
    methods: {
        changeReportSource() {
            this.model.reportTemplateName = this.common.formateDict(
                this.reportTemp,
                this.model.reportTemplateCode
            );
        },
        changDateRang() {
            if (this.model.datetimes && this.model.datetimes.length > 0) {
                this.model.startDate = this.model.datetimes[0];
                this.model.endDate = this.model.datetimes[1];
            }
        },
        bindData() {
            this.model.reportName = this.optionModel.relationName;
            this.model.sourceName = this.optionModel.relationName;
            this.model.sourceId = this.optionModel.relationCode;
            this.model.enterpriseCode = this.optionModel.enterpriseCode;
            this.model.enterpriseName = this.optionModel.enterpriseName;
            this.model.projectId = this.optionModel.projectId;
            if (this.reportTemplateCode) {
                this.model.reportTemplateCode = this.reportTemplateCode;
            }
            this.$set(this.model, "datetimes", []);
            this.model.datetimes.push(this.model.startDate);
            this.model.datetimes.push(this.model.endDate);
        },
        show(config) {
            let _this = this;
            _this.showDialog = true;
            this.optionModel = config.optionModel;
            let url = `${this.control}/initData/0?projectId=${
                this.optionModel.projectId
            }&reportType=${this.optionModel.relationType == 1 ? 4 : 3}`;
            // let url = `${this.control}/initData/0?projectId=${this.optionModel.projectId}&relationType=${this.optionModel.relationType}`;
            _this.getReportTemp();
            _this.common.get(url).then((res) => {
                _this.model = res.data;
                _this.bindData();
            });

            //this.$refs.eagleForm.get("initData/0")
        },
        getReportTemp() {
            let _this = this;
            let reportType =
                this.optionModel.relationType == 1
                    ? "DangerJgVerifyReporyByEnterprise"
                    : "DangerJgVerifyReportByTask";
            let url = `site/fileToolDataSource/getMap?reportType=${reportType}`;
            _this.common.get(url).then((res) => {
                _this.reportTemp = res.data;
                if (res.data) {
                    _this.reportTemplateCode = res.data[0].id;
                    _this.reportTemplateName = res.data[0].name;
                }
            });
        },

        post() {
            let _this = this;
            this.$refs.eagleForm.post({
                url: `danger/jgDangerTask/buildTaskVerifyReport`,
                successCallback: function (res) {
                    _this.showDialog = false;
                    let item = res.data.report;
                    _this.$emit("saved", item);
                    // _this.$emit("saved")
                },
            });
        },
    },
};
</script>

<style lang="scss">
</style>
