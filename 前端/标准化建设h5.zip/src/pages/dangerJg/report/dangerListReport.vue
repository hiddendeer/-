<template name="dangerJg-danger-list-report">
    <view class="dangerJg-danger-list-report">
        <!-- <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">隐患清单</eagle-head>
            <view style="background-color: #f3f4f6;"> -->
        <eagle-form :control="control" v-model="model" ref="eagleForm" :out-height='50' :boolInitData="false">
            <eagle-container title="检查任务信息">
                <eagle-text v-if="model.projectName" v-model="model.projectName" blod label="所属项目">
                </eagle-text>
                <eagle-text v-model="model.enterpriseName" blod label="被检查单位">
                </eagle-text>
                <eagle-text v-model="model.checkUserNames" blod label="检查人">

                </eagle-text>
                <eagle-text blod label="隐患清单生成日期">
                    {{model.buildDate}}
                </eagle-text>
            </eagle-container>
            <eagle-container title="隐患清单">
                <view class="padding10" v-for="(item,index) in model.dangerList" :key="item.ID">
                    <view :isTitle="true" :sBetween="true">
                        {{index+1}}.{{item.hiddenDangerArea}}
                    </view>
                    <view>
                        <text>隐患描述 : {{item.hiddenDangerDesc}}</text>
                    </view>
                </view>
            </eagle-container>
            <!-- <view class="pannel" v-if="site=='guanguan'">
                <view class="uni-media-cell">
                    <view class="flex">
                        <text class="flex1">检查人签名:</text>
                        <u-button type="primary" @click="editFunc(1)" size="mini">点击签名
                        </u-button>
                    </view>
                    <view v-if="reportModel.checkerSign">
                        <eagle-img width="400rpx" height="140rpx" :previewFullImage="true" v-for="(item ,index) in reportModel.checkerSign.split(',')" :key="index" title="" :src="item" />
                    </view>
                </view>
                <view class="uni-media-cell">
                    <view class="flex">
                        <text class="flex1">被检查单位代表签名:</text>
                        <u-button type="primary" @click="editFunc(2)" size="mini">点击签名
                        </u-button>
                    </view>
                    <view v-if="reportModel.enterpriseSign">
                        <eagle-img width="400rpx" height="140rpx" :previewFullImage="true" v-for="(item ,index) in reportModel.enterpriseSign.split(',')" :key="index" title="" :src="item" />
                    </view>
                </view>
            </view> -->

        </eagle-form>
        <!-- <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" :out-height='55'>
                    <view class="item">
                        <eagle-textbox prop="reportName" title="报告名称" v-model="model.reportName" required />
                        <eagle-radios title="报告模板" key="reportTemplateCode1" prop="reportTemplateCode" v-if="reportTemp && reportTemp.length>0" required :dataSource="reportTemp" @change="changeReportSource" v-model="model.reportTemplateCode" />
                        <eagle-date title="开始/结束日期" prop="datetimes" @change="changDateRang" v-model="model.datetimes" required type="range" rangeSeparator="至" />
                        <eagle-textbox key="remarks" type="textarea" title="总结和建议" v-model="model.remarks" />
                    </view>
                </eagle-form> -->
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">生成隐患清单</u-button>
        </eagle-bottom-view>
        <!-- </view>
        </u-popup> -->
        <!-- <u-toast ref="uToast" /> -->
    </view>
</template>

<script>
export default {
    name: "dangerJg-danger-list-report",
    data() {
        return {
            constLabelPosition: "left",
            model: {},
            control: "danger/jgDangerTask",

            // showDialog: false,
            taskCode: "",
            reportModel: {
                checkerSign: "",
                enterpriseSign: "",
            },
            env: "",
            site: "",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    created() {
        this.env = process.env.VUE_APP_ENV;
        this.site = process.env.VUE_APP_Site;
        this.taskCode = this.$route.query.taskCode ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.init();
    },
    methods: {
        // editFunc(type) {
        //     var _this = this;
        //     this.common.postBase64().then((res) => {
        //         if (res.code == 200 && res.data.length > 0) {
        //             if (type == 1)
        //                 this.reportModel.checkerSign = res.data.join(",");
        //             if (type == 2)
        //                 this.reportModel.enterpriseSign = res.data.join(",");
        //         } else {
        //             if (type == 1) this.reportModel.checkerSign = "";
        //             if (type == 2) this.reportModel.enterpriseSign = "";
        //         }
        //     });
        // },
        init() {
            let _this = this;
            // this.showDialog = true;
            // this.taskCode = config.taskCode;
            // if (this.base.isApp() || this.env != "development") {
            //     this.reportModel.checkerSign = "";
            //     this.reportModel.enterpriseSign = "";
            // } else {
            //     this.reportModel.checkerSign =
            //         "https://mky.ehsway.com/minio/eagle/20220823/09959/887596ad-51d1-49ac-9e5e-7f480df8081e.png";
            //     this.reportModel.enterpriseSign =
            //         "https://mky.ehsway.com/minio/eagle/20220823/09959/887596ad-51d1-49ac-9e5e-7f480df8081e.png,https://mky.ehsway.com/minio/eagle/20220823/09959/887596ad-51d1-49ac-9e5e-7f480df8081e.png";
            // }
            let url = `${this.control}/getDangerListContent/${this.taskCode}`;
            _this.common.get(url).then((res) => {
                _this.model = res.data;
            });
        },
        post() {
            let _this = this;
            let url = `${this.control}/buildDangerListReportSign/${_this.taskCode}`;
            _this.common.post(url, _this.reportModel).then((res) => {
                if (res.code == "200") {
                    if (res.data.result) {
                        //_this.$refs.eagleForm.successMsg("隐患清单保存成功");
                        // _this.showDialog = false;
                        //_this.$emit("saved", res.data);
                        let item = res.data.report;
                        let attach = JSON.parse(item.reportAttach)[0];
                        var url = _this.common.getLinkUrl(
                            "/pages/dangerJg/report/sign",
                            {
                                code: attach.attCode || attach.AttCode,
                                reportCode: item.code,
                            }
                        );
                        uni.reLaunch({
                            url: url,
                        });
                    } else {
                        _this.$refs.eagleForm.errorMsg(res.data.errorMsg);
                    }
                }
            });
        },
    },
};
</script>

<style lang="scss">
</style>
