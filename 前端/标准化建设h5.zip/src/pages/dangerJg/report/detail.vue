<template name="dangerJg-report-detail">
    <!-- <view class="dangerJg-report-detail">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">生成检查报告</eagle-head> -->
    <view>
        <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" :out-height='55'>
            <eagle-container>
                <view class="item">
                    <eagle-input prop="reportName" title="报告名称" v-model="model.reportName" required />
                    <eagle-radios title="报告模板" key="reportTemplateCode" prop="reportTemplateCode" v-if="reportTemp && reportTemp.length>0" required :dataSource="reportTemp" @change="changeReportSource" v-model="model.reportTemplateCode" />
                    <eagle-date type="daterange" :startDate.sync="model.startDate" :endDate.sync="model.endDate" title="开始/结束日期" prop="startsDate" required rangeSeparator="至" />
                    <eagle-input key="remarks" type="textarea" title="总结和建议" v-model="model.remarks" />
                </view>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">生成报告</u-button>
        </eagle-bottom-view>
    </view>
    <!-- </u-popup>
        <u-toast ref="uToast" />
    </view> -->
</template>

<script>
export default {
    name: "dangerJg-report-detail",
    data() {
        return {
            model: {},
            control: "danger/report",
            reportTemp: [],
            datetimes: [],
            showDialog: false,
            taskCode: "",
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            reportType: "2",
            checkedEnterprise: "",
        };
    },
    created() {
        this.taskCode = this.$route.query.taskCode ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.reportType = this.$route.query.reportType ?? "2";
        this.checkedEnterprise = this.$route.query.checkedEnterprise ?? "";
        this.show();
    },
    methods: {
        changeReportSource() {
            this.model.reportTemplateName = this.common.formateDict(
                this.reportTemp,
                this.model.reportTemplateCode
            );
        },
        bindData() {
            let _this = this;
            let reportTypeCode = this.getReportTypeCode();
            let url = `site/fileToolDataSource/getMap?reportType=${reportTypeCode}`;
            _this.common.get(url).then((res) => {
                _this.reportTemp = res.data;
                if (res.data && res.data.length > 0) {
                    if (!_this.model.reportTemplateCode) {
                        _this.model.reportTemplateCode = res.data[0].id;
                        _this.model.reportTemplateName = res.data[0].name;
                    }
                }
            });
        },
        //弹窗改跳转
        show() {
            let _this = this;
            let url = `${_this.control}/initData/0?projectId=${_this.queryParams.projectId}&taskCode=${_this.taskCode}&reportType=${_this.reportType}&enterpriseCode=${_this.checkedEnterprise}`;
            _this.common.get(url).then((res) => {
                _this.model = res.data;
                _this.bindData();
            });
        },
        post() {
            let _this = this;
            let url = "";
            if (this.reportType == "2") {
                url = "/danger/jgDangerTask/buildDangerCheckReportNew";
            } else if (this.reportType == "3" || this.reportType == "4") {
                url = "/danger/jgDangerTask/buildTaskVerifyReport";
            }
            if (url) {
                this.$refs.eagleForm.post({
                    url: url,
                    successCallback: function (res) {
                        if (res.code == 200) {
                            let item = res.data.report;
                            let attach = JSON.parse(item.reportAttach)[0];
                            var linkurl = _this.common.getLinkUrl(
                                "/pages/dangerJg/report/sign",
                                {
                                    code: attach.attCode || attach.AttCode,
                                    reportCode: item.code,
                                }
                            );
                            uni.reLaunch({
                                url: linkurl,
                            });
                        }
                    },
                });
            }
        },
        getReportTypeCode() {
            switch (this.reportType) {
                //隐患清单
                case "1":
                    return "site_danger_list";
                    break;
                //隐患拍查服务-检查报告
                case "2":
                    return "DangerJgCheckReport";
                    break;
                //整改报告
                case "3":
                    return "DangerJgVerifyReportByTask";
                    break;
                //单位整改报告
                case "4":
                    return "DangerJgVerifyReporyByEnterprise";
                    break;
                //项目总结报告
                case "5":
                    return "dangerJgTotalReport";
                    break;
                //单位验收报告 DangerJgVerifyReporyByEnterprise
                default:
                    return "";
                    break;
            }
        },
    },
};
</script>

<style lang="scss">
</style>
