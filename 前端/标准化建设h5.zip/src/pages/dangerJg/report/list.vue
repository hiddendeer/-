<template name="dangerJg-report-index">
    <view class="dangerJg-report-index">

        <eagle-page-list ref="eaglePageList" @initList="_initList" :boolInitData="false" :pageSize="20"
            :controller="controller" :margin-bottom="53" @beforeLoad="beforeLoad" :showCheck="true"
            dataType="taskDetail">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" v-model="searchValue" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.reportTypeId.value" title="报表类型"
                            prop="reportTypeId" :data-source="kvs.reportType" v-if="kvs.reportType.length > 0" />
                        <eagle-input title="报告名称" placeholder="报告名称" v-model="conditions.reportName.value"
                            :labelWidth="150"></eagle-input>

                        <!-- <eagle-search @search="search" v-model="conditions.reportName.value" :show-action="false" @clear="search"></eagle-search> -->
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <view class="uni-media-cell" v-for="(item) in data" :key="item.ID">
                    <view class="uni-media-list">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base>
                                <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                    <eagle-girdrow-block>{{ item.reportName }}</eagle-girdrow-block>
                                </eagle-girdrow-base>
                                <view v-if="item.startDate && item.endDate">
                                    <text>检查时间 :<text> {{ item.startDate | dateFormat }}至{{ item.endDate | dateFormat
                                    }}</text>
                                    </text>
                                </view>
                                <eagle-girdrow-base>
                                    检查人：{{ item.createChnName }}
                                </eagle-girdrow-base>
                                <!-- <view style="display: flex;justify-content: space-between;">
                                    <text>
                                        <u-icon name="account-fill"></u-icon>{{item.createChnName}}
                                    </text>
                                    <text>
                                        <u-icon name="clock"></u-icon>{{item.createDate|dateTimeFormat}}
                                    </text>
                                </view> -->
                                <eagle-grid-attach title="报告文件" v-model="item.reportAttach"></eagle-grid-attach>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-button type="error" @click="hdDelete(item)" size="mini">删除</u-button>
                    </eagle-grid-botton>
                </view>
            </view>
        </eagle-page-list>
        <!-- </u-popup> -->
        <tabbar-danger-jg></tabbar-danger-jg>
    </view>

</template>
<script>
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg.vue";
export default {
    components: { TabbarDangerJg },

    data() {
        return {
            searchValue: {},
            // showDialog: false,
            conditions: {
                reportName: { value: null, operate: "like" },
                reportTypeId: { value: null, operate: "=" },
            },
            controller: "danger/report",
            data: [],
            clearabled: true,
            kvs: {
                reportType: [
                    { id: "", name: "不限" },
                    { id: "1", name: "隐患清单" },
                    { id: "2", name: "检查报告" },
                    { id: "3", name: "整改报告" },
                ],
            },
            queryParams: {
                taskCode: "",
            },
        };
    },
    onShow() {
        this.queryParams.taskCode = this.$route.query.taskCode;
        setTimeout(() => {
            this.search();
        });
    },
    methods: {
        reSearsh() {
            this.conditions.reportName.value = "";
            this.conditions.reportTypeId.value = "";
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },

        _initList(list) {
            this.data = list;
        },

        search() {
            var conditions = [];
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: this.queryParams,
            });
        },
    },
};
</script>
<style lang="scss">
</style>
