<template name="dangerJg-report-index">
    <view class="eagle-layer">

        <eagle-page-list ref="eaglePageList" @initList="_initList" :boolInitData="false" :pageSize="20" :controller="controller" @beforeLoad="beforeLoad" :showCheck="true" :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.reportName.value" :show-action="false" @clear="search"></eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdLinkDetail(item)">
                    <template slot="tag">
                        <view> <span class="orange"> {{ item.reportType }}</span></view>
                    </template>
                    <eagle-girdrow-base isTitle>{{ item.reportName }}</eagle-girdrow-base>
                    <view>报告模板：{{ item.reportTemplateName }} </view>
                    <view>创建日期：{{ item.startDate | dateFormat }}</view>
                    <view>创建人：{{ item.createChnName }} </view>
                    <!-- <eagle-grid-attach title="" v-model="item.reportAttach"></eagle-grid-attach> -->
                    <template slot="button">
                        <!-- <u-button type="error" @click="hdDelete(item)" size="mini">删除</u-button> -->
                        <u-button type="success" size="mini" @click="hdLinkDetail(item)">查看报告</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item) in data" :key="item.ID">
                    <view class="uni-media-list">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base>
                                <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                    <eagle-girdrow-block>{{ item.reportName }}</eagle-girdrow-block>
                                </eagle-girdrow-base>
                                <view v-if="item.reportTypeId != 1">
                                    <text>检查时间 : {{ item.startDate | dateFormat }}至{{ item.endDate | dateFormat }}</text>
                                </view>
                                <eagle-girdrow-base>
                                    检查人：{{ item.createChnName }}
                                </eagle-girdrow-base>
                                <eagle-grid-attach title="报告文件" v-model="item.reportAttach"></eagle-grid-attach>

                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-button type="error" @click="hdDelete(item)" size="mini">删除</u-button>
                        <u-button type="success" size="mini" @click="hdLinkDetail(item)">查看报告</u-button>
                    </eagle-grid-botton> 
            </view>-->
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='showChooseTask'></eagle-fab>
        <!-- <tabbar-danger-jg></tabbar-danger-jg> -->
        <windowTaskList ref="windowTaskList" @callBackChoosedData="chooseTask" />
        <projectReport ref="projectReport" @saved="reportAttach" />
    </view>

</template>
<script>
import projectReport from "@/pages/dangerJg/report/projectReport";
import windowTaskList from "@/pages/dangerJg/task/windowTaskList";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg.vue";
export default {
    components: { TabbarDangerJg, windowTaskList, projectReport },

    data() {
        return {
            dataType: "projectReport",
            // showDialog: false,
            conditions: {
                reportName: { value: null, operate: "like" },
                // reportTypeId: { value: 4, operate: "=" },
            },
            controller: "danger/report",
            data: [],
            clearabled: true,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    onShow() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.dataType = this.queryParams.projectId
            ? "projectReport"
            : "myReport";
        setTimeout(() => {
            this.search();
        });
    },
    methods: {
        showChooseTask() {
            this.$refs.windowTaskList.show({
                type: "report",
                projectId: this.queryParams.projectId,
            });
            // this.$refs.windowTaskList.show();
        },
        chooseTask(codes, names) {
            this.$refs.projectReport.show({
                projectId: this.queryParams.projectId,
                selections: codes,
            });
        },
        reportAttach(item) {
            let fileList = [];
            if (item.reportAttach) {
                if (typeof item.reportAttach == "string") {
                    var arryFile = JSON.parse(item.reportAttach);
                    fileList = arryFile;
                } else {
                    fileList = item.reportAttach;
                }
            }
            if (fileList.length > 0) {
                let model = fileList[0];
                var url =
                    "/pages/common/pdfView?code=" + model.attCode ||
                    model.AttCode;
                this.base.navigateTo(url);
            }
        },
        reSearsh() {
            this.conditions.reportName.value = "";
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },

        _initList(list) {
            this.data = list;
        },

        search() {
            var conditions = [];
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: this.queryParams,
            });
        },
        hdLinkDetail(item) {
            let attach = JSON.parse(item.reportAttach)[0];
            let url = this.common.getLinkUrl("/pages/dangerJg/report/sign", {
                code: attach.attCode || attach.AttCode,
                reportCode: item.code,
            });
            this.base.navigateTo(url);
        },
    },
};
</script>
<style lang="scss">
</style>
