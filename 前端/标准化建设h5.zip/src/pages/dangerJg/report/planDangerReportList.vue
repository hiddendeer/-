<template name="dangerJg-report-list">
    <view class="dangerJg-report-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :bool-init-data="false" :pageSize="20"
            :controller="controller" :margin-bottom="38" @beforeLoad="beforeLoad" :showCheck="true" dataType="list">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.reportName.value" :show-action="false"
                        @clear="search"></eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <view class="uni-media-cell" v-for="(item) in data" :key="item.ID">
                    <view class="uni-media-list">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base>
                                <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                    <eagle-girdrow-block>{{ item.reportName }}</eagle-girdrow-block>
                                </eagle-girdrow-base>
                                <view>
                                    <text>检查时间 : {{ item.startDate | dateFormat }}至{{ item.endDate | dateFormat }}</text>
                                </view>
                                <eagle-girdrow-base>
                                    检查人：{{ item.createChnName }}
                                </eagle-girdrow-base>


                                <eagle-grid-attach title="报告文件" v-model="item.reportAttach"></eagle-grid-attach>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button>
                    </eagle-grid-botton>
                </view>
            </view>
        </eagle-page-list>

    </view>

</template>
<script>
export default {
    components: {},
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    data() {
        return {
            conditions: {
                reportName: { value: null, operate: "like" },
            },
            controller: "site/dangerReport",
            data: [],
            clearabled: true,
            taskCode: "",
        };
    },
    created() {
        this.taskCode = this.$route.query.taskCode;
    },
    methods: {
        reSearsh() {
            this.conditions.reportName.value = "";
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },

        _initList(list) {
            this.data = list;
        },

        search() {
            var conditions = [];
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                // url: "site/dangerCheckTaskDetail/getPageData",
                params: { taskCode: _this.taskCode },
            });
        },
    },
};
</script>
<style lang="scss">
.host-plan-danger-report-list {}
</style>
