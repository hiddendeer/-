<template>
    <view>

        <eagle-form :control="control" v-model="model" ref="eagleForm" :out-height='50' :errorType="errorType" :boolInitData="false" @initCallBack="bindData">
            <eagle-container>
                <eagle-radio-group title="检查类型" v-model="model.checkType" v-if="kvs.checkType.length>0" @change="hdCheckType" :dataSource="kvs.checkType" :showCustomer="false" required>
                </eagle-radio-group>
                <eagle-text title="所属项目" v-if="query.projectId">{{model.sourceName}}</eagle-text>
                <eagle-window-choose ref="chooseProject" v-else :isUseEnterprise="false" :queryParams="queryParams" :addUrl="addUrl" title="所属项目" headTitle="请选择所属项目" v-model="model.sourceCode" :isMult="false" :names.sync="model.sourceName" showDetail="true" @change="setProject" controller="site/projectConsultation" idField="code" textField="projectName" labelPosition="top" labelWidth="130" dataType="list"></eagle-window-choose>
                <eagle-window-choose ref="chooseCompany" v-if="!query.projectId" :isUseEnterprise="false" addUrl="pages/project/projectCompany/detail" title="被检查单位" headTitle="请选择被检查单位" v-model="model.enterpriseCode" :isMult="false" @change="setTaskName()" :names.sync="model.enterpriseName" showDetail="true" controller="system/company" idField="code" textField="name" labelPosition="top" labelWidth="130" dataType="list" required></eagle-window-choose>
                <choose-eagle-company v-else v-model="model.enterpriseCode" :names.sync="model.enterpriseName" @change="setTaskName()" required labelPosition="top" labelWidth="130"></choose-eagle-company>
                <eagle-input title="任务名称" required v-model="model.checkTaskName" prop="checkTaskName"></eagle-input>
                <eagle-choose-user required title="检查人" isMult v-model="model.checkCodes" :names.sync="model.checkNames" prop="checkCodes" />
                <eagle-date title="开始/结束日期" prop="datetimes" @change="changDateRang" v-model="model.datetimes" required type="range" rangeSeparator="至" :start="startDate">
                </eagle-date>
                <eagle-switch title="是否需要隐患整改复查" :active-value="true" :inactive-value="false" v-model="model.verifyDanger" :active-color="settings.activeColor" :label-width="settings.labelWidth" :label-position="settings.labelPosition" :size="settings.size" />
                <u-form-item class="eagle-choose-input" label="检查表" labelPosition="top">
                    <!-- <u-input placeholder="请选择检查表" :value="checkStr" @click="dialogShow=true" :disabled="true">
                    </u-input>
                    <view v-show="codes" class="uni-date__icon-clear" :class="{border:'uni-date-clear'}" @click.stop="clearCheck">
                        <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                    </view> -->
                    <view class="choose-input-view eagle-flex-between" @click="dialogShow=true">
                        <view>
                            <span class="input-placeholder" v-if="!(model.tempRelations&&model.tempRelations.length>0)">请选择检查表</span>
                            <span v-else>
                                {{checkStr}}
                            </span>
                        </view>
                        <view v-show="model.tempRelations&&model.tempRelations.length>0" @click.stop="clearCheck">
                            <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                        </view>
                    </view>
                    <u-button class="choose-input-btn" type="primary" @click="dialogShow=true">
                        <u-icon size="12" name="plus"></u-icon>选择
                    </u-button>
                </u-form-item>
                <!-- </view>
                </view> -->
                <eagle-input label-width="150px" type="textarea" title="检查要求" prop="checkRequirement" v-model="model.checkRequirement" clearable size="small" />
            </eagle-container>
        </eagle-form>

        <eagle-bottom-view>
            <u-button class="bottom-btn" v-if="model.status===0 || model.status===10" type="primary" @click="post">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />

        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
        <popup-table :isMult="true" :show.sync="dialogShow" :TagList="tagList" v-model="codes" @tableData="tableData"></popup-table>
    </view>
</template>
<script>
import popupTable from "@/components/eagle-check-table/popup-table";
import chooseEagleCompany from "@/pages/components/eagleComapny/choose-eagle-company";

export default {
    components: { popupTable, chooseEagleCompany },
    data() {
        return {
            settings: {
                activeColor: "#19be6b",
                labelWidth: "90%",
                labelPosition: "left",
                size: 40,
            },
            dialogShow: false,
            codes: "",
            tagList: [],
            startDate: "",
            model: {},
            errorType: ["message"],
            control: "danger/jgDangerTask",
            kvs: {
                checkType: [],
            },
            query: {
                enterpriseCode: "",
                projectId: "",
            },
            queryParams: {
                modulesId: "",
            },
            addUrl: "",
        };
    },
    onShow() {
        if (this.$refs.chooseCompany) {
            this.$refs.chooseCompany.search();
        }
        if (this.$refs.chooseProject) {
            this.$refs.chooseProject.search();
        }
    },
    created() {
        {
            this.query.ID = this.$route.query.id ?? "0";
            this.query.enterpriseCode = this.$route.query.enterpriseCode ?? "";
            this.query.projectId = this.$route.query.projectId ?? "";
            let dateNow = new Date();
            this.startDate = dateNow.toString();
            // this.common.dateFormat(dateNow);
            this.queryParams.modulesId = this.$route.query.modulesId ?? "";
            this.addUrl =
                "pages/project/projectConsultation/detail?modulesId=" +
                this.queryParams.modulesId;
        }
    },
    computed: {
        checkStr: {
            get: function () {
                if (
                    this.model.tempRelations &&
                    this.model.tempRelations.length > 0
                ) {
                    return (
                        "已选" + this.model.tempRelations.length + "张检查表"
                    );
                } else {
                    return "";
                }
            },
        },
    },
    onReady() {
        var _this = this;
        _this.initParams();
        _this.getData();
    },
    mounted() {},
    methods: {
        clearCheck() {
            this.model.tempRelations = [];
        },
        bindData(data) {
            this.model = data;

            if (!this.model.id || this.model.id == 0) {
                this.model.checkType = _this.kvs.checkType[0].id;
                this.model.checkTypeName = _this.kvs.checkType[0].name;
            }
        },
        confirm(content, callback) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
            });
        },
        chooseEnterprise() {
            this.$refs.companyChoose.show();
        },
        setTaskName() {
            let _this = this;
            if (
                this.model.checkTaskName &&
                this.model.enterpriseName &&
                this.model.checkTypeName
            ) {
                this.confirm("是否覆盖任务名称", () => {
                    _this.model.checkTaskName = `${
                        _this.model.enterpriseName
                    }_${_this.model.checkTypeName}${this.common.dateFormatStr(
                        new Date()
                    )}`;
                });
            } else if (this.model.enterpriseName && this.model.checkTypeName) {
                _this.model.checkTaskName = `${_this.model.enterpriseName}_${
                    _this.model.checkTypeName
                }${this.common.dateFormatStr(new Date())}`;
            }
        },
        setProject(data) {
            if (data) {
                this.model.sourceType = "1";
            } else {
                this.model.sourceType = "";
            }
        },
        hdCheckType() {
            let _this = this;
            _this.model.checkTypeName = _this.common.formateDict(
                _this.kvs.checkType,
                _this.model.checkType
            );
            this.setTaskName();
        },
        removeTemp(index) {
            this.model.tempRelations.splice(index, 1);
            this.getcodes();
        },
        getcodes() {
            let _this = this;
            _this.codes = "";
            _this.tagList = [];
            if (
                _this.model.tempRelations &&
                _this.model.tempRelations.length > 0
            ) {
                _this.model.tempRelations.forEach((item) => {
                    _this.codes = _this.codes
                        ? `${_this.codes},${item.tCode}`
                        : item.tCode;
                    _this.tagList.push({ id: item.tCode, name: item.tName });
                });
            }
        },
        changDateRang() {
            if (this.model.datetimes && this.model.datetimes.length > 0) {
                this.model.startDate = this.model.datetimes[0];
                this.model.endDate = this.model.datetimes[1];
            }
        },
        getData() {
            let _this = this;
            let url = `${_this.control}/${
                this.query.ID && this.query.ID != "0" ? "getData" : "initData"
            }/${this.query.ID}?enterpriseCode=${
                _this.query.enterpriseCode
            }&projectId=${_this.query.projectId}`;
            _this.common.get(url).then((res) => {
                _this.model = res.data;
                _this.$set(_this.model, "datetimes", []);
                _this.model.datetimes.push(_this.model.startDate);
                _this.model.datetimes.push(_this.model.endDate);
                if (
                    (!_this.model.id || _this.model.id == 0) &&
                    _this.kvs.checkType &&
                    _this.kvs.checkType.length > 0
                ) {
                    _this.model.checkType = _this.kvs.checkType[0].id;
                    _this.model.checkTypeName = _this.kvs.checkType[0].name;
                }
            });
        },

        initParams() {
            var _this = this;
            this.common
                .getparamsList("danger_check_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.kvs.checkType = res.data.filter(
                            (p) => p.paramId == "danger_check_plan_type"
                        );
                    }
                });
        },
        post() {
            let _this = this;

            this.$refs.eagleForm.post({
                url: "danger/jgDangerTask/createTask",
                successCallback: function (res) {
                    _this.hdLinkDetail(res);
                },
            });
        },
        hdLinkDetail(res) {
            if (res.code == 200) {
                let linkUrl = this.common.getLinkUrl(
                    "/pages/dangerJg/task/view",
                    {
                        enterpriseCode: this.query.enterpriseCode ?? "",
                        projectId: this.query.projectId ?? "",
                        taskCode: res.data.code,
                    }
                );
                this.base.navigateTo(linkUrl);
            }
        },
        afterChooseEnt(data) {
            this.model.enterpriseCode = data.code;
            this.model.enterpriseName = data.name;
        },
        clear() {
            this.model.enterpriseCode = "";
            this.model.enterpriseName = "";
        },
        tableData(array) {
            this.codes = "";
            this.tagList = [];
            let _this = this;
            // this.model.relations = [];

            let message = "";
            array.forEach((x) => {
                if (
                    this.model.tempRelations &&
                    this.model.tempRelations.findIndex(
                        (p) => x.id == p.tCode
                    ) >= 0
                ) {
                    message = message ? `${message},${x.name}` : x.name;
                } else
                    this.model.tempRelations.push({
                        taskCode: _this.model.code,
                        tCode: x.id,
                        tName: x.name,
                    });
            });
            if (message) {
                _this.$refs.uToast.show({
                    title: "检查任务中已存在检查:" + message,
                    type: "error",
                });
            }
        },
    },
};
</script>
<style lang="scss">
</style>
