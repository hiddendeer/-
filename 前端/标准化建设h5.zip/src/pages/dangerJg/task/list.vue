<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :boolInitData="false" :controller="controller" @beforeLoad="beforeLoad">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" v-model="searchValue" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.checkType.value" title="检查类型" prop="checkType" :data-source="kvs.checkType" v-if="kvs.checkType.length > 0" labelWidth="150" />
                        <eagle-fast-choose itemWidth="200rpx" title="状态" v-model="conditions.status.value" prop="status" :dataSource="kvs.taskStatus" labelWidth="150" />
                        <eagle-input title="任务名称" placeholder="任务名称" v-model="conditions.checkTaskName.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                    <!-- <eagle-search @search="search" :clearabled="true" :show-action="false" @clear="search" v-model="conditions.checkTaskName.value"></eagle-search> -->
                </view>
            </view>

            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdLinkDetail(item.code)">
                    <eagle-girdrow-base isTitle>{{ item.checkTaskName }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <view>被检查单位:{{ item.enterpriseName }}</view>
                    <view>开始/截止日期 :{{ item.startDate | dateFormat }} ~ {{ item.endDate | dateFormat }}</view>
                    <view>检查人 : {{ item.checkNames }}</view>
                    <view class="double-line">创建日期 : {{ item.startDate | dateFormat }}</view>
                    <view class="double-line">创建人 : {{ item.createChnName }} </view>
                    <template slot="button">
                        <u-button type="error" @click="hdDelete(item)" size="mini">删除</u-button>
                        <u-button type="error" v-if="searchValue.projectId" @click="removeTaskWithProject(item.code)" size="mini">移出项目
                        </u-button>
                        <u-button type="primary" v-if="item.status == 10" @click="goDetail(item.id)" size="mini">编辑
                        </u-button>
                    </template>
                </eagle-row-card>
                <u-action-sheet v-model="actionShow" @close="actionShow = false" :list="actionList" @click="clickSheet" :borderRadius="15" cancelText="取消">
                </u-action-sheet>
            </view>

        </eagle-page-list>
        <eagle-fab horizontal="right" v-if="searchValue.projectId" vertical="bottom" direction="horizontal" :content='fabContent' @trigger="trigger">
        </eagle-fab>
        <eagle-fab :popMenu='false' v-else horizontal='right' @fabClick='goDetail(0)'></eagle-fab>
        <windowTaskList ref="windowTaskList" @callBackChoosedData="chooseTask" />
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm' />
        <!-- <tabbar-danger-jg v-if="enterpriseCode"></tabbar-danger-jg>
        <tabbar-danger-jg-index v-else></tabbar-danger-jg-index> -->
    </view>

</template>

<script>
import windowTaskList from "@/pages/dangerJg/task/windowTaskList";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg";
import TabbarDangerJgIndex from "@/pages/components/tabbar/tabbar-dangerJg-index.vue";
export default {
    components: { TabbarDangerJg, windowTaskList, TabbarDangerJgIndex },
    data() {
        return {
            searchValue: {
                enterpriseCode: "",
                projectId: "",
                modulesId: "",
            },
            conditions: {
                checkTaskName: {
                    value: "",
                    operate: "like",
                },
                checkType: {
                    value: "",
                    operate: "=",
                },
                status: {
                    value: null,
                    operate: "=",
                },
            },
            controller: "/danger/jgDangerTask",
            fabContent: [
                {
                    iconPath: "../../../static/img/AppIcon/add-grey.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/add-blue.png",
                    text: "新增",
                    active: true,
                },
                {
                    iconPath: "../../../static/img/AppIcon/contract-grey.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/contract-blue.png",
                    text: "关联",
                    active: false,
                },
            ],
            data: [],

            //conditions: [],
            kvs: {
                checkType: [],
                taskStatus: [
                    { id: "", name: "不限" },
                    { id: "10", name: "进行中", type: "primary" },
                    { id: "25", name: "任务终止", type: "info" },
                    { id: "30", name: "待复查", type: "red" },
                    // { id: "80", name: "无需复查", color: "#67C23A" },
                    { id: "100", name: "已结束", type: "success" },
                ],
            },
            enterpriseCode: "",
            optionItem: {},
            actionShow: false,
            actionList: [
                { text: "删除", name: "delete" },
                { text: "移出项目", name: "remove" },
            ],
        };
    },
    // mounted() {
    //
    //     setTimeout(() => {
    //         this.initParams();
    //         this.search();
    //     });
    // },
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    created() {
        this.searchValue.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.searchValue.projectId = this.$route.query.projectId ?? "";
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.searchValue.modulesId = this.$route.query.modulesId ?? "";
        this.initParams();
    },
    methods: {
        bindTag(val) {
            console.log(val);
            let obj = this.kvs.taskStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },

        confirm(content, callback) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
            });
        },
        removeTaskWithProject(taskCode) {
            let _this = this;
            let url = `${this.controller}/removeTaskWithProject/${taskCode}`;
            this.confirm("是否确认将此任务移出项目?", function () {
                _this.common.post(url).then(function (res) {
                    _this.$refs.uToast.show({
                        title: "操作成功",
                        type: "success",
                    });
                    _this.search();
                });
            });
        },
        chooseTask(codes, names) {
            let _this = this;
            let url = `${_this.controller}/joinProject/${_this.searchValue.projectId}`;
            _this.common.post(url, codes.split(",")).then(function (res) {
                _this.$refs.uToast.show({
                    title: "操作成功",
                    type: "success",
                });
                _this.search();
            });
        },
        showChooseTask() {
            this.$refs.windowTaskList.show({
                type: "joinProject",
                projectId: this.searchValue.projectId,
            });
            // this.$refs.windowTaskList.show();
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdLinkDetail(code) {
            let url = `/pages/dangerJg/task/view?taskCode=${code}&enterpriseCode=${this.searchValue.enterpriseCode}&projectId=${this.searchValue.projectId}`;
            this.goto(url);
        },
        reSearsh() {
            this.conditions.checkTaskName.value = "";
            this.conditions.checkType.value = "";
            this.conditions.status.value = null;
            this.search();
        },
        _initList(list) {
            this.data = list;
        },
        search() {
            let _this = this;
            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.searchValue,
            });
        },

        initParams() {
            var _this = this;
            this.common
                .getparamsList("danger_check_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.kvs.checkType = res.data.filter(
                            (p) => p.paramId == "danger_check_plan_type"
                        );
                    }
                });
        },
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        goDetail(id) {
            this.goto(
                this.common.getLinkUrl("/pages/dangerJg/task/detail", {
                    id: id,
                    enterpriseCode: this.searchValue.enterpriseCode,
                    projectId: this.searchValue.projectId,
                    modulesId: this.searchValue.modulesId,
                })
            );
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        trigger(e) {
            this.fabContent.forEach((item, index) => {
                item.active = false;
                if (index === e.index) {
                    item.active = true;
                }
            });
            if (e.index === 0) {
                this.goDetail(0);
            } else if (e.index === 1) {
                this.showChooseTask();
            }
        },
        showAction(item) {
            this.optionItem = item;
            this.actionShow = true;
        },
        clickSheet(index) {
            let item = this.actionList[index];
            switch (item.name) {
                case "delete":
                    this.hdDelete(this.optionItem);
                    break;
                case "remove":
                    this.removeTaskWithProject(this.optionItem.code);
                    break;
            }
        },
    },
};
</script>


<style lang="scss">
.list_row {
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
}

.list_row_value {
    margin-left: 5px;
}

.list_title_row {
    display: flex;
    justify-content: space-between;
}
</style>
