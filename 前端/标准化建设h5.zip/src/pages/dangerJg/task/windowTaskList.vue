<template name="window-task-list">
    <u-popup v-model="showDialog" mode="right" height="100vh" length="100%">
        <eagle-head @close="close">{{ headTitle }}</eagle-head>

        <view>
            <eagle-page-list :isUseEnterprise="false" ref="eaglePageList" :controller="controller" :dataType="dataType" :showCheck="true" @initList="_initList" :margin-bottom="96" v-show="!showDetail" :boolInitData="false">
                <view slot="search">
                    <view class="search">
                        <eagle-condition @search="search" :initSearch="true" @reSearch="reSearsh">
                            <eagle-fast-choose itemWidth="200rpx" v-model="conditions.checkType.value" title="检查类型" prop="checkType" :data-source="kvs.checkType" v-if="kvs.checkType.length > 0" />
                            <eagle-fast-choose itemWidth="200rpx" title="状态" v-model="conditions.status.value" prop="status" :dataSource="kvs.taskStatus" v-if="kvs.taskStatus.length > 0" />
                            <eagle-fast-choose itemWidth="200rpx" v-model="conditions.sourceType.value" title="任务来源" prop="sourceType" :data-source="kvs.sourceType" v-if="kvs.sourceType.length > 0" />
                            <eagle-input title="任务名称" placeholder="任务名称" v-model="conditions.checkTaskName.value" :labelWidth="150"></eagle-input>
                        </eagle-condition>
                    </view>
                </view>
                <view slot="list" class="list-wrap">
                    <eagle-container>
                        <view class="view_container" v-for="(item, index) in data" :key="index">
                            <view @tap="choose(item, true)">
                                <view class="view_row">
                                    <view>
                                        <view>{{ item.checkTaskName }} </view>
                                        <view>检查人：{{ item.checkNames }} </view>
                                    </view>
                                    <view style="width:20px">
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose(item, false)" shape="square">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-container>
                </view>
            </eagle-page-list>

            <view class="view-choose-botton">
                <view class="choose-item" v-if="choosedNum >= 0 && isMult">
                    <text>已选择:</text>
                    <text class="choose-num">{{ choosedNum }}条</text>
                </view>
                <u-button class="choose-btn" type="primary" @click="submit">确定</u-button>
                <!-- <u-button class="choose-btn" v-if="addUrl"  type="primary" @click="handlerFabClick" >新增</u-button> -->
                <u-button v-if="isMult" class="choose-btn" type="primary" @click="cancelChoose">取消选择</u-button>
                <!-- <u-button v-if="isMult&&!showDetail" class="choose-btn"  type="primary"  @click="chooseAll">
                    全选
                </u-button> -->
            </view>
            <u-toast ref="uToast" />

        </view>
    </u-popup>
</template>

<script>
export default {
    name: "window-task-list",
    props: {
        isMult: {
            type: Boolean,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            headTitle: "选择检查任务",
            controller: "danger/jgDangerTask",
            conditions: {
                checkTaskName: { value: "", operate: "like" },
                checkType: { value: "", operate: "=" },
                status: { value: "", operate: "=" },
                sourceType: { value: "", operate: "=" },
                sourceCode: { value: "", operate: "!=" },
            },
            dataType: "",
            searchValue: {},
            data: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,
            choosedNum: 0,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            detailHeigh: 0,
            chooseVal: "",
            showDialog: false,
            kvs: {
                checkType: [],
                taskStatus: [
                    { id: "", name: "不限" },
                    { id: "10", name: "进行中", color: "#dd6161" },
                    { id: "25", name: "任务终止", color: "#dd6161" },
                    { id: "30", name: "待复查", color: "#dd6161" },
                    // { id: "80", name: "无需复查", color: "#67C23A" },
                    { id: "100", name: "已结束", color: "#67C23A" },
                ],
                sourceType: [
                    { id: "", name: "不限" },
                    { id: "0", name: "临时检查任务", color: "#dd6161" },
                    { id: "1", name: "项目检查任务", color: "#dd6161" },
                ],
            },
        };
    },
    computed: {},
    created() {
        this.initParams();
    },
    methods: {
        reSearsh() {
            this.conditions.checkTaskName.value = "";
            this.conditions.checkType.value = "";
            this.conditions.status.value = null;
            this.conditions.sourceType.value = "";
            this.search();
        },
        initParams() {
            let _this = this;
            this.common
                .getparamsList("danger_check_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.kvs.checkType = res.data.filter(
                            (p) => p.paramId == "danger_check_plan_type"
                        );
                    }
                });
        },
        _initList(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].code == list[i].code) {
                        list[i].checked = true;
                    }
                }
            }
            this.data = list;
        },
        show(config) {
            this.choosedNum = 0;
            this.submitDialog = true;
            if (config.type == "joinProject") {
                this.conditions.sourceCode.value = config.projectId;
                this.dataType = "joinProject";
                this.queryParams.projectId = "";
                this.queryParams.enterpriseCode = "";
            } else {
                this.dataType = "list";
                this.queryParams.enterpriseCode =
                    this.$route.query.enterpriseCode ?? "";
                this.queryParams.projectId = this.$route.query.projectId ?? "";
            }

            this.showDialog = true;
            setTimeout(() => {
                this.search();
            });
        },
        close() {
            // this.dialogShow = false;
            // this.$emit("update:show", false);
            this.showDialog = false;
        },
        search() {
            let _this = this;
            this.choosedNum = 0;
            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.queryParams,
            });
        },
        choose(obj, update) {
            let _this = this;
            if (update) {
                obj.checked = !obj.checked;
            }
            this.choosedData = [];
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (!_this.isMult) {
                    if (item.code != obj.code) {
                        item.checked = false;
                    }
                }
                if (item.checked) {
                    _this.choosedData.push({
                        idValue: item.code,
                        textValue: item.checkTaskName,
                    });
                }
            }
            this.choosedNum = this.choosedData.length;
        },
        submit() {
            let codeArry = [];
            let nameArry = [];
            if (!this.choosedData || this.choosedData.length <= 0) {
                this.$refs.uToast.show({
                    title: "请选择检查任务",
                    type: "error",
                });

                return;
            }
            this.choosedData.forEach(function (item) {
                codeArry.push(item.idValue);
                nameArry.push(item.textValue);
            });
            let codes = codeArry.join(",");
            let names = nameArry.join(",");

            this.$emit("callBackChoosedData", codes, names);

            this.close();
        },
        chooseAll() {
            let _this = this;
            this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = true;
                _this.choosedData.push({
                    idValue: item.code,
                    textValue: item.checkTaskName,
                });
            });
            this.choosedNum = this.choosedData.length;
        },
        cancelChoose() {
            let _this = this;
            _this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = false;
            });
            _this.choosedNum = 0;
        },
        clear(obj, index) {
            this.choosedData.splice(index, 1);
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (item.code == obj.code) {
                    item.checked = false;
                }
            }
            this.choosedNum = this.choosedData.length;
            if (this.choosedNum == 0) {
                this.showDetail = false;
            }
        },

        checkChange(e) {},
    },
};
</script>

<style lang="scss">
.view_container {
    // background: #fff;
    line-height: 1.5;
    padding: 10rpx;
}

.view_row {
    display: flex;
    justify-content: space-between;
    // margin: 0rpx 30rpx;
    // border-bottom: 1px solid #ececec;
    background-color: #fff;
    padding: 10px;
    align-items: center;
}

.uni-media-list-text-top {
    line-height: 100rpx;
    text-indent: 20rpx;
}

// .view-choose-botton {
//     position: fixed;
//     width: 100%;
//     bottom: 0px;
//     padding-bottom: 15px;
//     padding-top: 10px;
//     background: #fff;
//     .choose-item {
//         float: left;
//         display: inline-block;
//         line-height: 40px;
//         margin-left: 10px;
//         font-size: 16px;
//     }

//     .choose-num {
//         color: #2979ff;
//     }

//     .choose-btn {
//         float: right;
//         // margin-left: 8rpx;
//         margin-right: 20rpx;
//     }
// }

.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}

.uni-page-head {
    background-color: rgb(27, 118, 209);
    color: white;
}
</style>
