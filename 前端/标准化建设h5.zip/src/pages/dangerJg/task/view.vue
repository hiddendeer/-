<template>

    <view class="danger-task-view">
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
        <eagle-form :control="controller" v-model="model" ref="eagleForm" margin-bottom="40px" :boolInitData="false" by-code :errorType="errorType" @initCallBack="bindData">
            <eagle-container title="检查任务信息">
                <eagle-text v-if="model.sourceName" v-model="model.sourceName" blod label="所属项目">
                </eagle-text>
                <eagle-text v-model="model.checkTaskName" blod label="任务名称">
                </eagle-text>
                <eagle-text v-model="model.enterpriseName" blod label="被检查单位"> </eagle-text>
                <eagle-text blod label="开始/结束日期">
                    {{ model.startDate | dateFormat }} ~ {{ model.endDate | dateFormat }}
                </eagle-text>
                <eagle-text blod label="检查类型">
                    {{ common.formateDict(kvs.checkType, model.checkType) }}
                </eagle-text>
                <eagle-text blod label="检查人">
                    <span style="color:#0088ff;" @click="showUserList">{{ model.checkNames }}</span>
                </eagle-text>
                <eagle-text blod label="状态">
                    <span v-if="model.status == 10" style="color:red">进行中</span>
                    <span v-else v-html="common.formateStatus(kvs.taskStatus, model.status)"></span>
                    <span v-if="model.unNextVerify" style="color:red">(无需复查)</span>
                </eagle-text>
                <eagle-text blod label="检查记录">
                    <span style="color:#0088ff; " @click="hdShowDangerList">隐患数:{{ dangerNums.num }} /
                        检查数:{{ dangerNums.totalNum }}</span>
                </eagle-text>

                <eagle-text blod label="检查要求">{{ model.checkRequirement }}</eagle-text>

            </eagle-container>
            <eagle-container title="报告" v-if="model.dangerListReportAttach || model.checkAttachs || model.verifyAttachs">
                <eagle-text blod label="隐患清单" v-if="model.dangerListReportAttach">
                    <text>(已生成)</text>
                    <u-button class="fr" type="primary" size="mini" @click="viewReport(1)">查看清单</u-button>
                    <!-- <eagle-grid-attach title="" v-model="model.dangerListReportAttach"></eagle-grid-attach> -->
                </eagle-text>
                <eagle-text blod label="检查报告" v-if="model.checkAttachs">
                    <text>(已生成)</text>
                    <u-button class="fr" type="primary" size="mini" @click="viewReport(2)">查看报告</u-button>
                    <!-- <eagle-grid-attach title="" v-model="model.checkAttachs"></eagle-grid-attach> -->
                </eagle-text>
                <eagle-text blod label="整改报告" v-if="model.verifyAttachs">
                    <text>(已生成)</text>
                    <u-button class="fr" type="primary" size="mini" @click="viewReport(3)">查看报告</u-button>
                    <!-- <eagle-grid-attach title="" v-model="model.verifyAttachs"></eagle-grid-attach> -->
                </eagle-text>
            </eagle-container>

            <eagle-container title="已分配的检查表">
                <template slot="otherSolot">
                    <u-button v-if="model.status === 10" size="mini" type="success" @click="templateShow = true">
                        选择检查表
                    </u-button>
                </template>
                <eagle-text>
                    <view class="eagle-blue record-block">
                        <template v-if="model.tempRelations && model.tempRelations.length > 0">
                            <view v-for="(item, index) in model.tempRelations" :key="index" tabindex="0" class="tName-block flex">
                                <view class="flex1" @click="hdShowTemp(item)"> {{ item.tName }}</view>
                                <u-button v-if="model.status == 10" type="error" size="mini" @click="hdRemoveRelation(index)">移除</u-button>
                            </view>
                        </template>
                        <template v-else>
                            <u-empty text="未分配" mode="list"></u-empty>
                        </template>
                    </view>
                </eagle-text>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view class="mt10" v-if="model.status && model.status != 25" borderTop="none">
            <u-button class="bottom-btn" type="primary" v-if="model.status < 30" @click="goChooseTemp">依据检查</u-button>
            <u-button class="bottom-btn" type="primary" v-if="model.status < 30" @click="addHand">随手拍</u-button>
            <u-button class="bottom-btn" type="error" v-if="model.canBack && (model.status >= 30) && !(model.status == 100 && !model.unNextVerify)" @click="hdResetEndTask">恢复检查</u-button>
            <u-button class="bottom-btn" type="error" v-if="model.status === 10" @click="submitTask">结束任务</u-button>
            <u-button class="bottom-btn" type="primary" v-if="model.status >= 30&&!model.checkAttachs" @click="hdBuildReport('2')">生成检查报告</u-button>
            <u-button class="bottom-btn" type="primary" v-else-if="model.status >= 30" @click="hdBuildReport('3')">生成整改报告</u-button>
            <u-button class="bottom-btn" type="primary" v-if="model.status >= 30" @click="submitPopup = true">更多操作
            </u-button>
        </eagle-bottom-view>
        <u-popup v-model="submitPopup" mode="bottom" height="auto" length="auto" :z-index="10000">
            <view class="popup-title">更多操作</view>
            <view class="popup-body more-btn-group" style="text-align: center;">
                <u-button type="error" v-if="model.status != 25" @click="hdOverTask">终止任务</u-button>
                <u-button type="primary" v-if="model.status >= 30" @click="buildDangerListReport">生成隐患清单</u-button>
                <u-button type="primary" v-if="model.status >= 30&&model.checkAttach" @click="hdBuildReport('3')">生成整改报告</u-button>
                <u-button type="primary" v-else-if="model.status >= 30" @click="hdBuildReport('2')">生成检查报告</u-button>
                <u-button type="default" @click="submitPopup = false">取消</u-button>
            </view>
        </u-popup>
        <choose-temp-table :isMult="true" :show.sync="templateShow" :TagList="TagList" v-model="tempCodes" @tableData="tableData" />
        <!-- <templateCheck ref="templateCheck" @saved="refreshDangerNums" /> -->
        <!-- <reportDetail ref="reportDetail" @saved="reportAttach" /> -->
        <!-- <dangerListReport ref="dangerListReport" @saved="() => { refresh() }" /> -->
        <!-- <verifyTaskReport ref="verifyTaskReport" @saved="reportAttach" /> -->
    </view>

</template>
<script>
import chooseTempTable from "@/components/eagle-check-table/popup-table";
// import dangerListReport from "@/pages/dangerJg/report/dangerListReport";
// import verifyTaskReport from "@/pages/dangerJg/report/buildTaskVerifyReport";

// import templateCheck from "@/pages/dangerJg/taskDetail/templateCheck";
// import reportDetail from "@/pages/dangerJg/report/detail";

export default {
    components: {
        chooseTempTable,
        // templateCheck,
        // reportDetail,
        // dangerListReport,
        // verifyTaskReport,
    },

    data() {
        return {
            templateShow: false,
            // libTempDetailsVisible: false,
            tempCodes: "",
            reportNum: 0,
            constLabelPosition: "top",

            taskCode: "",
            TagList: [],
            submitPopup: false,
            // startDate: "",
            model: {},
            dangerNums: {},
            errorType: ["message"],
            controller: "danger/jgDangerTask",
            detailController: "danger/jgDangerTaskDetail",
            reportController: "danger/report",
            kvs: {
                checkType: [],
                taskStatus: [
                    { id: 10, name: "进行中", color: "#dd6161" },
                    { id: 25, name: "任务终止", color: "#dd6161" },
                    { id: 30, name: "待复查", color: "#dd6161" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
            urlParams: {
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    onShow() {
        {
            this.model.code = this.$route.query.taskCode;
            // let dateNow = new Date();
            // this.startDate = this.common.dateFormat(dateNow);
            this.initParams();
            setTimeout(() => {
                this.refresh();
            });
        }
    },
    created() {
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
    },
    computed: {
        dangerCunStr: {
            get: function () {
                return (
                    (this.dangerNums.num || 0) +
                    "/" +
                    (this.dangerNums.totalNum || 0)
                );
            },
        },
    },
    methods: {
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        confirm(content, callback) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
            });
        },

        checkSubmit(type, callback) {
            let _this = this;
            let url = `${_this.controller}/checkSubmit/${this.model.code}/${type}`;
            _this.common.get(url).then((res) => {
                if (res.data.result) {
                    callback && callback(res);
                } else {
                    _this.errorMsg(res.data.errorMsg);
                }
            });
        },
        refresh() {
            this.$refs.eagleForm.refresh();
        },
        /**生成整改报告 */
        buildVerifyReport() {
            // let _this = this;
            // _this.submitPopup = false;
            // this.$refs.verifyTaskReport.show({
            //     optionModel: {
            //         relationName: _this.model.checkTaskName,
            //         relationCode: _this.model.code,
            //         relationType: 2,
            //         projectId: _this.model.sourceCode,
            //         enterpriseCode: _this.model.enterpriseCode,
            //         enterpriseName: _this.model.enterpriseName,
            //     },
            // });
        },
        /**终止任务 */
        hdOverTask() {
            let _this = this;
            _this.submitPopup = false;
            _this.confirm(
                "确定要终止任务及它的隐患吗?终止后将无法进行其他操作!",
                () => {
                    let url = `${_this.controller}/overTask/${_this.model.code}`;
                    _this.common.post(url).then((res) => {
                        if (res.code == 200) _this.refresh();
                        // else {
                        //     _this.errorMsg(res.errorText)
                        // }
                    });
                }
            );
        },
        // /** 结束任务 */
        // hdEndTask() {
        //     let _this = this;
        //     let url = `${_this.controller}/endTask/${this.model.code}`;
        //     _this.common.post(url).then((res) => {
        //         if (res.code == 200) _this.refresh();
        //         // else {
        //         //     _this.errorMsg(res.errorText)
        //         // }
        //     });
        // },
        //提交任务
        submitTask() {
            let _this = this;
            let url = `${_this.controller}/submitTask/${this.model.code}/1`;
            _this.common.post(url).then((res) => {
                if (res.code == 200) _this.refresh();
            });
        },
        /**恢复我的检查 */
        hdResetEndTask() {
            let _this = this;
            _this.confirm("是否确认恢复检查?", () => {
                let url = `${_this.controller}/resetEndTask/${_this.model.code}`;
                _this.common.post(url).then((res) => {
                    if (res.code == 200) _this.refresh();
                });
            });
        },
        /**
         * 生成报告
         */
        // buildReport() {
        //     let _this = this;
        //     _this.checkSubmit(1, function (res) {
        //         _this.$refs.buildDangerReport.show({
        //             taskCodes: _this.model.code,
        //             taskNames: _this.model.checkTaskName,
        //             enterpriseCode: _this.urlParams.enterpriseCode,
        //             projectId: _this.urlParams.projectId,
        //         });
        //     });
        // },
        backTask() {
            let _this = this;
            _this.confirm("是否确认撤回检查任务?", () => {
                let url = `${_this.controller}/backTask/${_this.model.code}`;
                _this.common.post(url).then((res) => {
                    if (res.code == 200) _this.refresh();
                    else {
                        _this.errorMsg(res.errorText);
                    }
                });
            });
        },
        showReportList() {
            this.goto(
                this.common.getLinkUrl("/pages/dangerJg/report/list", {
                    taskCode: this.model.code,
                    projectId: this.model.sourceCode,
                })
            );
        },
        showUserList() {
            this.goto(
                this.common.getLinkUrl("/pages/dangerJg/task/taskUserList", {
                    taskCode: this.model.code,
                    projectId: this.model.sourceCode,
                    isManager: this.model.manager,
                    mainStatus: this.model.status,
                    // status: this.model.endStatus,
                })
            );
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        hdBuildReport(reportType) {
            let _this = this;
            _this.checkSubmit(1, () => {
                let url = "pages/dangerJg/report/detail";
                let linkUrl = this.common.getLinkUrl(url, {
                    taskCode: this.model.code,
                    enterpriseCode: this.urlParams.enterpriseCode,
                    projectId: this.urlParams.projectId,
                    reportType: reportType,
                });
                this.base.navigateTo(linkUrl);
                // _this.$refs.reportDetail.show({
                //     taskModel: this.model,
                // });
            });
        },
        //生成隐患清单
        buildDangerListReport() {
            // let _this = this;
            // _this.submitPopup = false;
            // _this.checkSubmit(2, () => {
            //     _this.$refs.dangerListReport.show({
            //         taskCode: _this.model.code,
            //     });
            // });
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/report/dangerListReport",
                {
                    taskCode: this.model.code,
                    enterpriseCode: this.urlParams.enterpriseCode,
                    projectId: this.urlParams.projectId,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdShowTemp(item) {
            // this.$refs.templateCheck.show({
            //     tempCode: item.tCode,
            //     tempName: item.tName,
            //     taskCode: this.model.code,
            //     isEdit: this.model.status == 10 && this.model.endStatus == 10,
            // });

            //templateCheck
            let linkUrl = this.common.getLinkUrl(
                "pages/dangerJg/taskDetail/templateCheckNew",
                {
                    taskCode: this.model.code,
                    templateCode: item.tCode,
                    enterpriseCode: this.urlParams.enterpriseCode,
                    projectId: this.urlParams.projectId,
                    isEdit:
                        this.model.status == 10 && this.model.endStatus == 10,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        //依据查
        goChooseTemp() {
            let linkUrl = this.common.getLinkUrl(
                "pages/support/libTempPublic/list",
                {
                    enterpriseCode: this.urlParams.enterpriseCode,
                    projectId: this.urlParams.projectId,
                    formType: "dangerJg",
                    taskCode: this.model.code,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        //随手拍
        addHand() {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/detailNew",
                {
                    taskCode: this.model.code,
                    opType: 3,
                    enterpriseCode: this.urlParams.enterpriseCode,
                    projectId: this.urlParams.projectId,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdShowDangerList() {
            this.goto(
                this.common.getLinkUrl(
                    "/pages/dangerJg/taskDetail/taskDangerList",
                    {
                        taskCode: this.model.code,
                        status: this.model.status,
                        projectId: this.model.sourceCode,
                    }
                )
            );
        },
        bindData() {
            this.refreshDangerNums();
            this.refreshReportNums();
        },
        refreshReportNums() {
            let _this = this;
            let url = `danger/report/getReportNums/${_this.model.code}`;
            _this.common.get(url).then((res) => {
                _this.reportNum = res.data;
            });
        },
        refreshDangerNums() {
            let _this = this;
            _this.common
                .get(
                    `${_this.detailController}/getNumByDetail/${_this.model.code}`
                )
                .then((res) => {
                    _this.dangerNums = res.data;
                });
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("danger_check_plan_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.kvs.checkType = res.data.filter(
                            (p) => p.paramId == "danger_check_plan_type"
                        );
                    }
                });
        },
        //选择检查表
        tableData(array) {
            let _this = this;
            _this.tempCodes = "";
            _this.TagList = [];
            let relationsArray = [];
            if (
                _this.model.tempRelations &&
                _this.model.tempRelations.length > 0
            ) {
                _this.model.tempRelations.forEach((x) => {
                    relationsArray.push({
                        taskCode: _this.model.code,
                        tCode: x.tCode,
                        tName: x.tName,
                    });
                });
            }
            let message = "";
            if (array && array.length > 0) {
                array.forEach((x) => {
                    if (
                        _this.model.tempRelations.findIndex(
                            (p) => p.tCode == x.id
                        ) >= 0
                    )
                        message = message + (message ? `,${x.name}` : x.name);
                    else
                        relationsArray.push({
                            taskCode: _this.model.code,
                            tCode: x.id,
                            tName: x.name,
                        });
                });
                if (message) {
                    _this.$refs.uToast.show({
                        title: `${message}已经存在检查计划中`,
                        type: "error",
                    });
                    //this.msgInfo(`${message}已经存在检查任务中`);
                }
                if (relationsArray && relationsArray.length > 0) {
                    let url = `${this.controller}/pushRelation/${this.model.code}`;
                    _this.common.post(url, relationsArray).then(function (res) {
                        _this.model.tempRelations = res.data;
                    });
                }
            }
        },
        hdRemoveRelation(index) {
            let _this = this;
            let item = _this.model.tempRelations[index];
            _this.$refs.eagleForm.confirm(
                `是否确认移除检查表[${item.tName}]?`,
                () => {
                    _this.common
                        .post(
                            `${_this.controller}/removeRelation/${_this.model.code}/${item.tCode}`
                        )
                        .then(function (res) {
                            if (res.code == 200)
                                _this.model.tempRelations.splice(index, 1);
                            else
                                _this.$refs.tempRelations.errorMsg(
                                    res.errorMsg
                                );
                        });
                }
            );
        },

        reportAttach(item) {
            let fileList = [];
            if (item.reportAttach) {
                if (typeof item.reportAttach == "string") {
                    var arryFile = JSON.parse(item.reportAttach);
                    fileList = arryFile;
                } else {
                    fileList = item.reportAttach;
                }
            }
            if (fileList.length > 0) {
                let model = fileList[0];
                var url =
                    "/pages/common/pdfView?code=" + model.attCode ||
                    model.AttCode;
                this.base.navigateTo(url);
            }
        },
        viewReport(type) {
            let attach = {};
            let _this = this;
            switch (type) {
                case 1:
                    attach = JSON.parse(this.model.dangerListReportAttach)[0];
                    break;
                case 2:
                    attach = JSON.parse(this.model.checkAttachs)[0];
                    break;
                case 3:
                    attach = JSON.parse(this.model.verifyAttachs)[0];
                    break;
                default:
                    break;
            }
            let reportUrl = "/danger/report/gerEntityByAttachAndSourceId";
            this.common
                .get(reportUrl, {
                    attCode: attach.attCode,
                    sourceId: this.model.code,
                })
                .then((res) => {
                    if (res.code == 200) {
                        if (res.data) {
                            var url = _this.common.getLinkUrl(
                                "/pages/dangerJg/report/sign",
                                {
                                    code: attach.attCode,
                                    reportCode: res.data.code,
                                    enterpriseCode:
                                        _this.urlParams.enterpriseCode,
                                    projectId: _this.urlParams.projectId,
                                }
                            );
                            _this.base.navigateTo(url);
                        }
                    } else {
                        _this.$refs.eagleForm.errorMsg(res.errorText);
                    }
                })
                .catch((res) => {
                    debugger;
                    this.$refs.eagleForm.errorMsg("网络异常,请重新再试");
                });
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-task-view {
    .record-block {
        // line-height: 72rpx;

        .tName-block {
            padding: 0px 16rpx 20rpx 0rpx;
            align-items: center;
        }
        .tName-block:first {
            padding-top: 0px;
        }
    }

    .more-btn-group {
        .u-btn {
            margin-top: 20rpx;
        }
    }

    .pannel {
        background-color: rgb(255, 255, 255);
        // padding: 5px;
        // margin-top: 10px;
        margin-bottom: 10px;
        padding: 0 15px;
    }

    .base-item {
        line-height: 68rpx !important;
    }

    .popup-title {
        font-size: 15px;
        padding: 8px;
        border-bottom: solid 1px #c0c4cc;
    }

    .popup-body {
        padding: 10px;
    }

    .detail-btn-group {
        //popup-body

        display: flex;
        justify-content: space-between;

        .btn {
            display: block;
            border: 1px solid #c0c4cc;
            width: 31%;
            font-size: 13px;
            height: 35px;
            line-height: 35px;
            padding: 0 10px;
            text-align: center;
            border-radius: 4px;
        }

        .btn.info {
            color: #606266;
            background-color: #ffffff;
        }

        .btn.primary {
            color: #ffffff;
            background-color: #2979ff;
        }

        .btn.error {
            color: #ffffff;
            background-color: red;
        }
    }
}
</style>
