<template name="danger-jg-task-user-list">
    <view class="danger-jg-task-user-list">
        <view class="list-wrap">
            <view class="uni-media-cell" v-for="(item) in list" :key="item.ID">
                <view class="uni-media-list">
                    <view class="uni-media-list-body">
                        <eagle-girdrow-base>
                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                <eagle-girdrow-block>{{ item.chnName }}</eagle-girdrow-block>

                            </eagle-girdrow-base>
                            <view>
                                <text>隐患数/检查数 : {{ item.fcount }}/{{ item.tcount }}</text>
                            </view>
                        </eagle-girdrow-base>
                    </view>
                </view>
                <eagle-grid-botton>
                    <u-button type="error" v-if="mainStatus == 10 && item.tcount <= 0 && (isManager || status > 0)" @click="handRemoveChecker(item)" size="mini">删除</u-button>
                </eagle-grid-botton>
            </view>
        </view>
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
      
        <popup-window ref="popupWindow" headTitle="选择人员" v-model="codes" :names.sync="myNames" isMult customItem idField="userName" textField="chnName" queryUrl="support/CommonAQXApi/getUserUser" @callBackChoosedData="changeCheckor">
            <template v-slot:body='scope'>
                <view>
                    <view class="c333"> {{scope.item.chnName}}</view>
                    <view> {{scope.item.orgFullName}}</view>
                </view>
            </template>
        </popup-window>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='pushChecker()'></eagle-fab>
    </view>
</template>
<script>
import popupWindow from "@/components/eagle-window-choose/popup-window.vue";
export default {
    components: { "popup-window": popupWindow },

    data() {
        return {
            myNames: "",
            codes: "",
            mainStatus: 10,
            status: 0,
            isManager: false,
            controller: "danger/jgDangerTask",
            list: [],
            queryParams: {
                taskCode: "",
            },
        };
    },
    onShow() {
        this.queryParams.taskCode = this.$route.query.taskCode ?? "";
        this.isManager = this.$route.query.isManager ?? false;
        this.mainStatus = this.$route.query.mainStatus ?? 10;
        this.status = this.$route.query.status ?? 0;
        setTimeout(() => {
            this.search();
        });
    },
    methods: {
        search() {
            let _this = this;
            let url = `${this.controller}/getTaskUserList/${this.queryParams.taskCode}`;
            _this.common.get(url).then((res) => {
                _this.list = res.data;
            });
        },
        pushChecker() {
            let _this = this;
            setTimeout(() => {
                _this.$refs.popupWindow.show();
            });
        },
        changeCheckor(data, codes, names) {
            let _this = this;
            var tmpModel = {
                code: _this.queryParams.taskCode,
                checkNames: names,
                checkCodes: codes,
            };
            let url = `${_this.controller}/pushChecker`;
            _this.common.post(url, tmpModel).then(function (res) {
                _this.search();
                _this.codes = "";
                _this.myNames = "";
            });
        },
        handRemoveChecker(row) {
            let _this = this;
            this.$refs.eagleConfirm.showConfirm({
                content: "是否确认移除此检查人员吗",
                confirm: function () {
                    let url = `${_this.controller}/removeChecker/${_this.queryParams.taskCode}/${row.userName}`;

                    _this.common.post(url, {}).then(function (res) {
                        _this.search();
                    });
                },
                cancel: function () {},
            });
        },
        hdEndUserTask(row) {
            let _this = this;
            this.$refs.eagleConfirm.showConfirm({
                content: `是否确认为检查人${row.chnName}结束检查任务?`,
                confirm: function () {
                    let url = `${_this.controller}/endUserTask/${_this.queryParams.taskCode}/${row.userName}`;
                    _this.common.post(url, {}).then(function (res) {
                        _this.search();
                    });
                },
                cancel: function () {},
            });
        },
        /**恢复其他检查人的任务 */
        hdResetUserTask(row) {
            let _this = this;
            let url = `${_this.controller}/resetUserTask/${_this.queryParams.taskCode}/${row.userName}`;
            this.$refs.eagleConfirm.showConfirm({
                content: `是否确认为检查人${row.chnName}恢复检查任务?`,
                confirm: function () {
                    _this.common.post(url, {}).then(function (res) {
                        _this.search();
                    });
                },
                cancel: function () {},
            });
        },
    },
};
</script>
<style lang="scss">
.danger-jg-task-user-list {
}
</style>
