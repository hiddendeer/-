<template name="danger-jg-check-view">
    <view class="danger-jg-check-view">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">{{title}}</eagle-head>
            <eagle-form class="form-content" :control="controller" :boolInitData="false" @initCallBack="bindData" v-model="model" ref="eagleForm" marginBottom="120px">
                <eagle-container>
                    <view class="item">
                        <view class="item-container">
                            <view v-if="model.checkResult==='N'">
                                <eagle-display-image title="隐患图片" :value="model.attachs" />
                                <eagle-display-input label-width="200rpx" label-position="top" title="隐患区域" :value="model.hiddenDangerArea" />
                                <eagle-display-input label-width="200rpx" label-position="top" title="隐患描述" :value="model.hiddenDangerDesc" />
                                <eagle-display-input label-width="200rpx" label-position="top" title="整改建议" :value="model.correctiveAdvise" />
                                <eagle-display-input label-width="200rpx" label-position="top" title="隐患分类" :value="model.lgdName" />
                                <eagle-radios label-width="200rpx" :disabled="true" label-position="top" title="隐患性质" required :data-source="params.checkType" v-model="model.hiddenDangerType" />
                                <eagle-display-input label-width="200rpx" label-position="top" title="整改期限" :value="model.correctiveDate|dateFormat" />

                            </view>
                            <eagle-input disabled label-width="200rpx" title="隐患来源" label-position="top">{{model.originType|paramsFormat(params.checkSource)}}</eagle-input>
                            <eagle-input disabled label-width="200rpx" title="检查人" label-position="top">{{model.createChnName}}</eagle-input>
                            <eagle-input disabled label-width="200rpx" title="检查时间" label-position="top">{{model.createDate|dateFormat}}</eagle-input>

                        </view>
                    </view>
                </eagle-container>
                <eagle-container title="操作历史记录">

                    <view class="card-content">
                        <view class="log-item" v-for="(item ,index ) in logList" :key="'log_'+index">
                            <text class="index">{{index+1}}.</text><text class="content">{{item.opeateLog}}</text>
                        </view>
                    </view>

                </eagle-container>
                <view v-if="opType==1 && model.status==40">
                    <u-divider>制定整改措施</u-divider>
                    <view class="card-content">
                        <view>
                            <u-form-item>
                                <u-button :type="ctype==1?'primary':'info'" @click="ctype=1">制定措施</u-button>
                                <u-button :type="ctype==2?'error':'info'" @click="ctype=2">重新指派</u-button>
                            </u-form-item>
                        </view>
                        <view v-if="ctype==1">
                            <eagle-radios label-width="100px" title="整改方式" prop="correctiveMethod" v-model="model.correctiveMethod" required :data-source="params.correctiveMethod" />

                            <eagle-date label-width="100px" v-if="model.correctiveMethod=='2'" title="整改期限" prop="correctiveDate" v-model="model.correctiveDate" required />

                            <view v-if="model.correctiveMethod=='1'">
                                <eagle-upload label-width="100px" title="整改图片" key="attachs" prop="correctiveAttachs" v-model="model.correctiveAttachs" :count="3" required />
                            </view>
                            <eagle-input type="textarea" :rows="2" key="correctiveMeasure" label-width="100px" title="整改措施" prop="correctiveMeasure" v-model="model.correctiveMeasure" required />
                        </view>
                        <view v-if="ctype==2">
                            <eagle-choose-user label-width="100px" title="整改人" prop="correctiveUserName" :names.sync="model.correctiveChnName" v-model="model.correctiveUserName" required />
                            <eagle-input type="textarea" :rows="2" key="remarks" label-width="100px" title="说明" prop="remarks" v-model="model.remarks" required />
                        </view>
                    </view>
                </view>
                <view v-if="opType==2 &&  model.status==50">
                    <u-divider>整改</u-divider>
                    <view class="card-content">
                        <eagle-upload label-width="100px" title="整改图片" key="correctiveAttachs" prop="correctiveAttachs" v-model="model.correctiveAttachs" :count="3" required />
                        <eagle-input type="textarea" :rows="2" key="remarks" label-width="100px" title="说明" prop="remarks" v-model="model.remarks" required />
                    </view>
                </view>

                <view v-if="opType==3 && model.status!=100">
                    <u-divider>整改复查</u-divider>

                    <view class="card-content">
                        <u-form-item label-width="100px" label="判定">
                            <view style="display:unset" class="check-pass-btn-group">
                                <u-button size="mini" :type="verifyType==1?'primary':'info'" @click="verifyType=1">通过</u-button>
                                <u-button size="mini" :type="verifyType==2?'error':'info'" @click="verifyType=2">不通过</u-button>
                            </view>
                        </u-form-item>
                    </view>
                    <view v-if="verifyType==1">
                        <eagle-upload label-width="100px" title="整改图片" key="verifyAttachs" prop="verifyAttachs" v-model="model.verifyAttachs" :count="3" />

                    </view>
                    <eagle-date label-width="100px" v-if="verifyType==2" title="整改期限" prop="correctiveDate" v-model="model.correctiveDate" />
                    <eagle-input type="textarea" :rows="2" label-width="100px" title="复查意见" prop="remarks" v-model=" model.remarks" :required="verifyType==2" />
                </view>

                <eagle-bottom-view marginBottom="0px">
                    <u-button v-if="opType>0" class="bottom-btn" type="primary" @click="post">提 交</u-button>
                    <u-button v-if="opType==0" class="bottom-btn" type="primary" @click="showDialog=false">返 回</u-button>
                </eagle-bottom-view>

            </eagle-form>

            <u-toast ref="uToast" />
            <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        </u-popup>
    </view>
</template>
<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
export default {
    components: {
        viewDangerLg,
    },
    name: "danger-jg-check-view",
    data() {
        return {
            title: "",
            showDialog: false,
            controller: "danger/jgDangerTaskDetail",
            model: {},
            params: {
                checkType: [
                    { id: 1, name: "一般隐患" },
                    { id: 2, name: "重大隐患" },
                ],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                correctiveMethod: [
                    { id: "1", name: "立即整改" },
                    { id: "2", name: "限时整改" },
                ],
            },
            enterpriseCode: "",
            taskCode: "",
            opType: 0, //0查看,1:制定整改措施,2整改,3复查
            // listShow: true,

            logList: [],
            verifyType: 1,
            // verifyType: [{
            //     id: "1",
            //     name: '复查通过'
            // }, {
            //     id: "2",
            //     name: '复查不通过'
            // }],
            ctype: 1,
            //http://localhost:82/dev-api/danger/jgDangerTaskDetail/modifyTaskDetail/2
        };
    },
    created() { },
    methods: {
        getLogs() {
            let _this = this;
            let url = `danger/jgDangerLog/getList/${_this.model.code}`;
            _this.common.get(url).then((res) => {
                if (res.code == 200) _this.logList = res.data;
            });
        },
        showDetail() {
            let config = {
                isEdit: false,
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },
        show(options) {
            this.showDialog = true;
            this.taskCode = options.taskCode;
            this.enterpriseCode = options.enterpriseCode;
            this.opType = options.opType;
            this.ctype = 1;
            this.verifyType = 1;
            switch (options.opType) {
                case 0:
                    this.title = "隐患详情";
                    break;
                case 1:
                    this.title = "制定措施";
                    break;
                case 2:
                    this.title = "隐患整改";
                    break;
                case 3:
                    this.title = "隐患复查";
                    break;
            }
            this.getModel(options.id, this.taskCode);
        },
        getModel(id, taskCode) {
            var _this = this;
            this.common.get(`${this.controller}/getData/` + id).then((res) => {
                _this.model = res.data;
                _this.getLogs();
            });
        },
        initParams() {
            // var _this = this;
            // this.common.getparamsList("hidden_danger_type").then(function (res) {
            //     if (res.code == 200 && res.data) {
            //         _this.params.checkType = res.data.filter(p => p.paramId == "hidden_danger_type")
            //         //_this.params.checkType = res.data;
            //         console.log('_this.checkDatas.checkType:', _this.params.checkType)
            //     }
            // })
        },
        post() {
            let _this = this;
            let type = 1;
            switch (_this.opType) {
                case 1:
                    type = _this.ctype;
                    break;
                case 2:
                    type = 3;
                    break;
                case 3:
                    type = this.verifyType == 1 ? 4 : 5;
                    break;
            }

            _this.$refs.eagleForm.post({
                url: `${_this.controller}/modifyTaskDetail/${type}`,
                successCallback: function (res) {
                    _this.showDialog = false;
                    _this.$emit("saved");
                },
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-jg-check-view {
    .check-pass-btn-group {
        .u-btn {
            margin-left: 20rpx;
        }
    }
    .statistics {
        margin-top: 30rpx;
        padding: 0 30rpx;
    }
    .card-content {
        padding: 5px 10px;
    }
    .form-content {
        .item {
            .item-title {
                display: flex;
                background-color: #2979ff;
                line-height: 35px;
                margin: 10px -30px;
                padding: 0px 30px;
                font-size: 16px;
                font-weight: 600;
                color: #ffffff;
                -webkit-box-flex: 1;
                -webkit-flex: 1;
                flex: 1;

                .arrow-up-fill {
                    text-align: right;
                }
            }

            // .citem {
            //     padding: 10px 0px;
            // }
        }
    }

    .button-pannel {
        width: 100%;
        display: inline-flex;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;

        .button-item {
            margin-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            border: 1px solid #dfe4ec;
            width: 28%;
            /* height: 30px; */
            border-radius: 5px;
            line-height: 30px;
        }

        .button-item.Y.checked {
            border: 1rpx solid #19be6b;
            background-color: #19be6b;
            color: #ffffff;
        }

        .button-item.NA.checked {
            border: 1rpx solid #ff976a;
            background-color: #ff976a;
            color: #ffffff;
        }

        .button-item.N.checked {
            border: 1rpx solid red;
            background-color: red;
            color: #ffffff;
        }
    }
}

// .view-botton {
//     padding: 20rpx;
// }
</style>
