<template name="danger-jg-check-verify">
    <view class="danger-jg-check-verify">
        <eagle-form class="form-content" :control="controller" :boolInitData="false" @initCallBack="bindData" v-model="model" ref="eagleForm" marginBottom="100px">
            <eagle-container title="隐患详情">

                <!-- <eagle-form-block title="隐患详情"> -->
                <eagle-text title="隐患图片">
                    <eagle-display-image v-model="model.attachs"></eagle-display-image>
                </eagle-text>
                <eagle-text title="隐患区域" v-model="model.hiddenDangerArea" />
                <eagle-text title="隐患描述" v-model="model.hiddenDangerDesc" />
                <eagle-text title="整改建议" v-model="model.correctiveAdvise" />
                <eagle-text title="隐患分类" v-model="model.lgdName" />
                <eagle-text title="隐患性质">
                    {{model.hiddenDangerType|paramsFormat(params.checkType)}}
                </eagle-text>
                <eagle-text title="整改期限" :value="model.correctiveDate|dateFormat">
                </eagle-text>
                <eagle-text title="隐患来源">
                    {{model.originType|paramsFormat(params.checkSource)}}
                </eagle-text>
                <eagle-text title="检查人" v-model="model.createChnName" />
                <eagle-text title="检查时间" :value="model.createDate|dateFormat" />
                <!-- </eagle-form-block> -->
            </eagle-container>
            <eagle-container title="复查">
                <!-- <eagle-form-block title="复查"> -->
                <!-- <view style="padding: 0 30rpx"> -->
                <u-form-item label="判定" lableWidth="120px" label-position="top">
                    <!-- <view style="display:unset" class="check-pass-btn-group">
                            <u-button size="mini" :type="verifyType==1?'primary':'info'" @click="verifyType=1">通过</u-button>
                            <u-button size="mini" :type="verifyType==2?'error':'info'" @click="verifyType=2">不通过</u-button>
                        </view> -->
                    <view class="btn-span">
                        <text class="btn-dft" :class="verifyType==1?'pass':''" @click="verifyType=1">通过</text>
                        <text class="btn-dft" :class="verifyType==2?'un-pass':''" @click="verifyType=2">不通过</text>
                    </view>
                </u-form-item>
                <!-- </view> -->
                <!-- <view > -->
                <eagle-upload v-if="verifyType==1" title="复查图片" key="verifyAttachs" prop="verifyAttachs" v-model="model.verifyAttachs" :count="3" />

                <!-- <eagle-upload label-width="100px" title="复查图片" key="verifyAttachs" prop="verifyAttachs" v-model="model.verifyAttachs" :count="3" /> -->

                <!-- </view> -->
                <eagle-date label-width="100px" v-if="verifyType==2" title="整改期限" prop="correctiveDate" v-model="model.correctiveDate" />
                <eagle-input type="textarea" :rows="2" label-width="100px" title="复查意见" prop="remarks" v-model=" model.remarks" :required="verifyType==2" />
                <!-- </eagle-form-block> -->
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="default" @click="back">返 回</u-button>
            <u-button class="bottom-btn" v-if="model.status<100" type="primary" @click="post">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>
<script>
export default {
    components: {},
    name: "danger-jg-check-virify",
    data() {
        return {
            title: "",
            controller: "danger/jgDangerTaskDetail",
            model: {},
            params: {
                checkType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
            },
            id: -10,
            verifyType: 1,
            code: "",
        };
    },
    created() {
        this.initParams();
        this.code = this.$route.query.code;
        this.id = this.$route.query.id;
        this.getModel();
    },
    onShow() {},
    methods: {
        getModel(id, taskCode) {
            var _this = this;
            _this.model.attachs = "";
            if (id && id > 0) {
                this.common
                    .get(`${this.controller}/getData/` + id)
                    .then((res) => {
                        _this.model = res.data;
                        if (this.opType == 2) {
                            _this.model.id = 0;
                            _this.model.code = "";
                        }
                    });
            }
        },
        getModel() {
            var _this = this;
            this.common
                .get(`${this.controller}/getData/` + this.id)
                .then((res) => {
                    _this.model = res.data;
                    // _this.getLogs();
                });
        },
        bindData(data) {
            this.model = data;
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("hidden_danger_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.params.checkType = res.data.filter(
                            (p) => p.paramId == "hidden_danger_type"
                        );
                    }
                });
        },
        back() {
            this.base.navigateBack();
        },
        post() {
            let _this = this;
            let type = this.verifyType == 1 ? 4 : 5;
            _this.$refs.eagleForm.post({
                url: `${_this.controller}/modifyTaskDetail/${type}`,
                successCallback: function (res) {
                    _this.back();
                },
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-jg-check-verify {
    .btn-dft {
        border-radius: 3px;
        display: inline-block;
        border: 1px solid #c8c9cc;
        background-color: #c8c9cc;
        color: #fff;
        padding: 5px;
        width: 200rpx;
        text-align: center;
        margin: 10rpx;
    }
    .btn-dft.pass {
        border: 1px solid #19be6b;
        color: #fff;
        background-color: #71d5a1;
    }
    .btn-dft.un-pass {
        border: 1px solid #fa3534;
        color: #fff;
        background-color: #dd6161;
    }
    .statistics {
        margin-top: 30rpx;
        padding: 0 30rpx;
    }

    .form-content {
        .item {
            .item-title {
                display: flex;
                background-color: #2979ff;
                line-height: 35px;
                margin: 10px -30px;
                padding: 0px 30px;
                font-size: 16px;
                font-weight: 600;
                color: #ffffff;
                -webkit-box-flex: 1;
                -webkit-flex: 1;
                flex: 1;

                .arrow-up-fill {
                    text-align: right;
                }
            }

            .citem {
                padding: 10px 0px;
            }
        }
    }

    .button-pannel {
        width: 100%;
        display: inline-flex;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;

        .button-item {
            margin-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            border: 1px solid #dfe4ec;
            width: 28%;
            /* height: 30px; */
            border-radius: 5px;
            line-height: 30px;
        }

        .button-item.Y.checked {
            border: 1rpx solid #19be6b;
            background-color: #19be6b;
            color: #ffffff;
        }

        .button-item.NA.checked {
            border: 1rpx solid #ff976a;
            background-color: #ff976a;
            color: #ffffff;
        }

        .button-item.N.checked {
            border: 1rpx solid red;
            background-color: red;
            color: #ffffff;
        }
    }
}

// .view-botton {
//     padding: 20rpx;
// }
</style>
