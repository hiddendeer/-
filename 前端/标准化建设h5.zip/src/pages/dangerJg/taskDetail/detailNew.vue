<template name="danger-jg-check-detail">
    <view class="danger-jg-check-detail">
        <eagle-form class="form-content" :control="controller" :boolInitData="false" @initCallBack="bindData" v-model="model" ref="eagleForm" marginBottom="100px">
            <eagle-container title="隐患详情" v-if="model.id && model.id>0">
                <!-- <eagle-form-block title="隐患详情" v-if="model.id && model.id>0"> -->
                <eagle-text label-width="200rpx" title="隐患来源">{{model.originType|paramsFormat(params.checkSource)}}</eagle-text>
                <eagle-text label-width="200rpx" title="检查人">{{model.createChnName}}</eagle-text>
                <eagle-text label-width="200rpx" title="检查时间">{{model.createDate|dateFormat}}</eagle-text>
                <!-- </eagle-form-block> -->
            </eagle-container>
            <eagle-container>
                <eagle-upload :isNeedEdit="true" title="隐患图片" ref="eagleUpload" key="attachs" prop="attachs" v-model="model.attachs" />
                <eagle-input type="textarea" title="隐患区域" :only-show-required="model.lgdType=='2'?true:false" v-model="model.hiddenDangerArea" />
                <eagle-input type="textarea" title="隐患描述" prop="hiddenDangerDesc" only-show-required v-model="model.hiddenDangerDesc" />
                <eagle-input type="textarea" title="整改建议" prop="correctiveAdvise" v-model="model.correctiveAdvise">
                    <template slot="topBotton">
                        <view style="text-align: right;">
                            <span v-if="model.checkSource!==3" style="color:#2979ff;margin-left: 10rpx;" @click="chooseDangerLg">选择依据</span>
                            <span style="color:#2979ff;margin-left: 20rpx;margin-right: 20rpx;" @click="showDetail()">编辑依据</span>
                        </view>
                    </template>
                </eagle-input>
                <eagle-choose title="隐患分类" v-model="model.lgdName" prop="lgdName" only-show-required :select-open="dangerTypeDialog" @click="showDangerType(model)">
                </eagle-choose>
                <eagle-radio-group v-model="model.hiddenDangerType" only-show-required title="隐患性质" prop="operateObj" :data-source="params.checkType" v-if="params.checkType.length>0" />
                <eagle-date label-width="100px" key="correctiveDate" title="整改期限" v-model="model.correctiveDate" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="default" @click="back()">返回</u-button>
            <u-button class="bottom-btn" type="primary" v-if="model.status<100" @click="post(false)">保存并返回</u-button>
            <u-button class="bottom-btn" type="success" v-if="opType == 3 && model.status==0" @click="post(true)">保存并继续</u-button>

            <!-- <u-button class="bottom-btn" type="default" @click="back">返 回</u-button>
            <u-button class="bottom-btn" v-if="model.status<100" type="primary" @click="post">确 定</u-button> -->

        </eagle-bottom-view>

        <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog=false" v-model="model.hiddenCode" @change="changeDangeType"></popup-danger-type>
        <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        <!-- <lib-temp-details :listShow='libShow' checkType='base' @handlerSelectBase='handlerSelectBase' @libtempDetailsClose='libShow=false' /> -->
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>
<script>
// import libTempDetails from "@/pages/support/libTemp/components/libTempDetails/libTempDetails";
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type";
export default {
    components: {
        "popup-danger-type": popupDangerType,
        "view-danger-lg": viewDangerLg,

        // "lib-temp-details": libTempDetails,
    },
    name: "danger-jg-check-detail",
    data() {
        return {
            title: "",
            controller: "danger/jgDangerTaskDetail",
            model: {
                id: 0,
            },
            dangerTypeDialog: false,
            params: {
                checkType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
            },
            tempModel: {},
            enterpriseCode: "",
            taskCode: "",
            libShow: false,
            opType: 1, //1编辑  2复制
            urlParams: {
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    created() {
        this.initParams();
        this.taskCode = this.$route.query.taskCode;
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode;
        this.urlParams.projectId = this.$route.query.projectId;
        this.id = this.$route.query.id;
        this.opType = this.$route.query.opType;
        this.getModel(this.id);
    },
    onShow() {},
    methods: {
        handlerSelectBase(val) {
            let _this = this;
            if (val.item == "base" && _this.model.correctiveAdvise) {
                this.$refs.eagleConfirm.showConfirm({
                    content: "是否确认覆盖整改建议?",
                    confirm: function () {
                        _this.setHidderDangerDesc(val);
                    },
                });
            } else if (
                val.item === "base-danger" &&
                (_this.model.hiddenDangerDesc || _this.model.correctiveAdvise)
            ) {
                this.$refs.eagleConfirm.showConfirm({
                    content: "是否确认覆盖隐患描述和整改建议?",
                    confirm: function () {
                        _this.setHidderDangerDesc(val);
                    },
                });
            } else _this.setHidderDangerDesc(val);

            this.libShow = false;
        },
        setHidderDangerDesc(obj) {
            let _this = this;
            _this.model.correctiveAdvise = obj.base.correctiveAdvise;
            _this.model.gistSource = obj.base.gistSource;
            _this.model.originalText = obj.base.originalText;
            _this.model.lgCode = obj.base.lGCode;

            if (obj.item === "base-img") {
                _this.model.attachs = obj.img;
            }
            if (obj.item === "base-img-danger")
                _this.model.attachs = obj.img.url;
            if (obj.item === "base-danger" || obj.item === "base-img-danger") {
                if (obj.danger.dFullName) {
                    _this.model.lgHdCode = obj.danger.lGHDCode;
                    _this.model.lgdCode = obj.danger.dCode;
                    _this.model.lgdName = obj.danger.dFullName.replace(
                        ">",
                        "-"
                    );
                    let hiddenTypeName = _this.model.lgdName.split("-")[0];
                    if (hiddenTypeName === "现场管理")
                        _this.model.lgdType = "2";
                    if (hiddenTypeName === "基础管理")
                        _this.model.lgdType = "1";
                }
                _this.model.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.model.hiddenDangerType = obj.danger.hiddenDangerType;
                _this.model.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.model.legalLiability = obj.danger.legalLiability;
            }
            //
        },
        showDetail() {
            let config = {
                isEdit: true,
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },
        // show(options) {
        //     this.showDialog = true;
        //     this.taskCode = options.taskCode;
        //     this.enterpriseCode = options.enterpriseCode;
        //     this.opType = options.opType;
        //     switch (options.opType) {
        //         case 0:
        //             this.title = "隐患详情";
        //             break;
        //         case 1:
        //             this.title = "隐患编辑";
        //             break;
        //         case 2:
        //             this.title = "复制隐患";
        //             break;
        //         case 3:
        //             this.title = "随手拍";
        //             break;
        //         case 4:
        //             this.tempModel = options.lg;
        //             this.title = "依据检查";
        //             break;
        //     }
        //     this.getModel(options.id, this.taskCode);
        // },
        getModel(id) {
            var _this = this;
            _this.model.attachs = "";
            if (id && id > 0) {
                this.common
                    .get(`${this.controller}/getData/` + id)
                    .then((res) => {
                        _this.model = res.data;
                        if (this.opType == 2) {
                            _this.model.id = 0;
                            _this.model.code = "";
                        }
                    });
            } else {
                this.common.get(`${this.controller}/initData/0`).then((res) => {
                    _this.model = res.data;
                    _this.model.originType = 1;
                    _this.model.ctCode = _this.taskCode;
                    _this.model.enterpriseCode = _this.enterpriseCode;
                    _this.model.projectId = _this.projectId;
                    _this.model.checkResult = "N";
                    if (_this.opType == 4) {
                        //依据查
                        let lgStr = localStorage.getItem(
                            "choosedDangerLgWithLgCheck"
                        );
                        if (lgStr) {
                            let temp = JSON.parse(lgStr);
                            _this.model.originType = 2;
                            // _this.model.attachs = temp.attachs;
                            _this.setHidderDangerDesc(temp);
                        }
                    }
                });
            }
        },
        chooseDangerLg() {
            let _this = this;
            this.$bus.$off("chooseLg").$on("chooseLg", function (lgData) {
                _this.handlerSelectBase(lgData);
                // _this.model.CorrectiveAdvise = lgData.base.CorrectiveAdvise;
                // _this.model.GistSource = lgData.base.GistSource;
                // _this.model.OriginalText = lgData.base.OriginalText;
                // // _this.model.Attachs = lgData.img.url;
                // if (lgData.item == "base-danger") {
                //     _this.model.LegalLiability =
                //         lgData.danger.LegalLiability;
                //     _this.model.HiddenDangerDesc =
                //         lgData.danger.HiddenDangerDesc;
                //     _this.model.HiddenDangerType =
                //         lgData.danger.HiddenDangerType;
                //     _this.model.HiddenDangerTypeName =
                //         lgData.danger.HiddenDangerTypeName;
                //     _this.model.LGDType = lgData.danger.DType;
                //     _this.model.LGDTypeName = lgData.danger.DTypeName;
                //     _this.model.LGDCode = lgData.danger.DCode;
                //     _this.model.LGDName = lgData.danger.DName;
                //     if (_this.model.DTypeName && _this.model.DName)
                //         _this.model.LGDFullName =
                //             _this.model.DTypeName + ">" + _this.model.DName;
                // }
            });
            this.goChooseTemp();
        },
        goChooseTemp() {
            let linkUrl = this.common.getLinkUrl(
                "pages/support/libTempPublic/list",
                {
                    enterpriseCode: this.urlParams.enterpriseCode,
                    projectId: this.urlParams.projectId,
                    taskCode: this.taskCode,
                    checkType: "base",
                }
            );
            this.base.navigateTo(linkUrl);
        },
        changeDangeType(obj) {
            this.model.lgdType = obj.dType;
            this.model.lgdCode = obj.dCode;
            this.model.lgdName = obj.dFullName.replace(">", "-");
            this.dangerTypeDialog = false;
        },
        showDangerType() {
            this.dangerTypeDialog = true;
        },

        initParams() {
            var _this = this;
            this.common
                .getparamsList("hidden_danger_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.params.checkType = res.data.filter(
                            (p) => p.paramId == "hidden_danger_type"
                        );
                    }
                });
        },
        back() {
            this.base.navigateBack();
        },
        post(isContinue) {
            let _this = this;
            _this.$refs.eagleForm.post({
                url: `${_this.controller}/createTaskDetail`,
                successCallback: function (res) {
                    if (!isContinue) _this.back();
                    else {
                        _this.$refs["eagleUpload"].clear();
                        _this.getModel(_this.$route.query.id);
                    }
                },
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-jg-check-detail {
    .statistics {
        margin-top: 30rpx;
        padding: 0 30rpx;
    }

    .form-content {
        .item {
            .item-title {
                display: flex;
                background-color: #2979ff;
                line-height: 35px;
                margin: 10px -30px;
                padding: 0px 30px;
                font-size: 16px;
                font-weight: 600;
                color: #ffffff;
                -webkit-box-flex: 1;
                -webkit-flex: 1;
                flex: 1;

                .arrow-up-fill {
                    text-align: right;
                }
            }

            .citem {
                padding: 10px 0px;
            }
        }
    }

    .button-pannel {
        width: 100%;
        display: inline-flex;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;

        .button-item {
            margin-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            border: 1px solid #dfe4ec;
            width: 28%;
            /* height: 30px; */
            border-radius: 5px;
            line-height: 30px;
        }

        .button-item.Y.checked {
            border: 1rpx solid #19be6b;
            background-color: #19be6b;
            color: #ffffff;
        }

        .button-item.NA.checked {
            border: 1rpx solid #ff976a;
            background-color: #ff976a;
            color: #ffffff;
        }

        .button-item.N.checked {
            border: 1rpx solid red;
            background-color: red;
            color: #ffffff;
        }
    }
}

// .view-botton {
//     padding: 20rpx;
// }
</style>
