<template name="danger-jg-check-detail-list">
    <!-- <u-popup v-model="showDialog" mode="right" height="100%" length="100%"> -->
    <view class="danger-jg-check-detail-list eagle-layer">
        <!-- <eagle-head @close="showDialog=false">隐患列表</eagle-head> -->
        <eagle-page-list ref="eaglePageList" dataType="taskDetail" @initList="_initList" :bool-init-data="false" :pageSize="20" :controller="controller" @beforeLoad="beforeLoad" :showCheck="true" data-type="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" v-if="params.correctiveStatus && params.correctiveStatus.length > 0" title="隐患状态" prop="status" :data-source="params.correctiveStatus" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.originType.value" title="来源类型" prop="originType" :data-source="params.originType" />
                        <eagle-input title="隐患描述" placeholder="请输入隐患描述模糊查询" v-model="conditions.hiddenDangerDesc.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdViewClick(item)">
                    <eagle-girdrow-base isTitle>{{ item.hiddenDangerDesc }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-base sBetween>
                        <view>
                            <text>隐患来源： {{ item.originType | paramsFormat(params.originType) }}</text>
                        </view>
                        <view v-if="item.complete == false" style="color:#dd6161;font-size:34rpx">
                            待完善
                        </view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base>
                        检查人：{{ item.createChnName }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        检查日期： {{ item.createDate | dateTimeFormat }}
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="error" size="mini" v-if="item.status == 10" @click="hdDelete(item)">删除
                        </u-button>
                        <u-button type="primary" size="mini" v-if="item.status == 10" @click="hdEditClick(item, 1)">编辑
                        </u-button>
                        <u-button type="success" size="mini" v-if="item.status == 10" @click="hdEditClick(item, 2)">复制
                        </u-button>
                        <u-button type="primary" size="mini" v-if="item.status >= 30 && item.status < 80" @click="hdVerifyClick(item, 3)">复查</u-button>
                        <u-button type="success" size="mini" @click="hdViewClick(item)">详情</u-button>
                    </template>
                </eagle-row-card>

            </view>
        </eagle-page-list>
        <dangerJgDetail ref="dangerJgDetail" @saved="search" />
        <dangerJgView ref="dangerJgView" @saved="search" />
        <!-- <tabbar-danger-jg></tabbar-danger-jg> -->
    </view>

    <!-- </u-popup> -->
</template>
<script>
import dangerJgDetail from "@/pages/dangerJg/taskDetail/detail";
import dangerJgView from "@/pages/dangerJg/taskDetail/view";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg.vue";
export default {
    components: { dangerJgDetail, dangerJgView, TabbarDangerJg },
    name: "danger-jg-check-detail-list",

    data() {
        return {
            data: [],
            showDialog: false,
            mainCode: "",
            status: 0,
            controller: "danger/jgDangerTaskDetail",
            conditions: {
                checkResult: { value: "N", operate: "=" },
                status: { value: null, operate: "=" },
                originType: { value: null, operate: "=" },
                hiddenDangerType: { value: null, operate: "=" },
                hiddenDangerDesc: { value: null, operate: "like" },
            },
            params: {
                correctiveStatus: [
                    { id: null, name: "不限", type: "primary" },
                    { id: `10`, name: "检查中", type: "primary" },
                    { id: `25`, name: "任务终止", type: "red" },
                    { id: `30`, name: "待整改", type: "red" },
                    { id: `60`, name: "待复查", type: "red" },
                    { id: `80`, name: "无需复查", type: "red" },
                    { id: `100`, name: "复查通过", type: "success" },
                ],

                checkType: [],
                dangerType: [],
                originType: [
                    { id: "1", name: "随手拍" },
                    { id: "2", name: "依据检查" },
                    { id: "3", name: "检查表检查" },
                ],
            },
        };
    },
    onShow() {
        this.initParams();
        this.mainCode = this.$route.query.taskCode;
        this.isEnd = this.$route.query.isEnd;
        this.status = this.$route.query.status;
        setTimeout(() => {
            this.search();
        });
    },
    methods: {
        bindTag(val) {
            console.log(val);
            let obj = this.params.correctiveStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        show(options) {
            this.mainCode = options.taskCode;

            this.showDialog = true;
        },
        initParams() {},
        reSearsh() {
            this.conditions.hiddenDangerDesc.value = null;
            this.conditions.originType.value = null;
            this.conditions.status.value = null;
        },
        hdDelete(item) {
            let _this = this;
            var url = `${_this.controller}/dangerDelete/${item.ctCode}/${item.id}`;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdOld(item, opType) {
            let _this = this;
            _this.$refs.dangerJgView.show({
                taskCode: item.code,
                opType: opType,
                id: item.id,
            });
        },
        hdViewClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/viewNew",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdEditClick(item, opType) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/detailNew",
                {
                    id: item.id,
                    taskCode: item.code,
                    opType: opType,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdVerifyClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/detailVerify",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdClick(item, opType) {
            let _this = this;
            _this.$refs.dangerJgDetail.show({
                taskCode: item.code,
                opType: opType,
                id: item.id,
            });
        },
        _initList(list) {
            this.data = list;
        },
        change() {
            this.search();
        },
        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                // url: "site/dangerCheckTaskDetail/getPageData",
                params: { ctCode: _this.mainCode },
            });
        },
    },
};
</script>

<style>
</style>