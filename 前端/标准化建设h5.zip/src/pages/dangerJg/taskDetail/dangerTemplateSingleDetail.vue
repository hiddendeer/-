<template>
    <view class="hd-danger-template-single-detail">
        <eagle-form class="form-content" :model="model" :boolInitData="false" marginBottom='60px'>
            <eagle-container>
                <view v-if="opType=='add' || opType=='edit'">
                    <eagle-upload :isNeedEdit="true" title="隐患图片" key="attachs" prop="attachs" v-model="model.attachs" />
                    <eagle-input type="textarea" title="隐患区域" :onlyShowRequired="model.lgdType=='2'" v-model="model.hiddenDangerArea" />
                    <view style="background: #ffffff" class="eagle-line-block" v-if="item.greatGrandsons&&item.greatGrandsons.length>0">
                        <view class="choose-block" v-if="opType!='view'">
                            <view class="useing-title">快捷选择隐患</view>
                            <view v-for="(item,index) in item.greatGrandsons" class="using-content" :key="index">
                                <span class="content-using" @click="setDangerDesc(item)"> {{index+1}}. {{item.hiddenDangerDesc}}</span>
                                <span class="btn-using" @click="setDangerDesc(item)">引用</span>
                            </view>
                        </view>
                    </view>
                    <eagle-input type="textarea" title="隐患描述" onlyShowRequired v-model="model.hiddenDangerDesc" />
                    <eagle-input type="textarea" title="整改建议" v-model="model.correctiveAdvise">
                        <template slot="topBotton">
                            <view style="text-align: right;margin-top:10px">
                                <span style="color:#2979ff;margin-right: 30rpx;margin-left: 20rpx;" @click="showDetail()">{{opType!='view'?"编辑依据":"查看依据"}}</span>
                            </view>
                        </template>
                    </eagle-input>
                    <eagle-choose title="隐患分类" v-model="model.lgdName" onlyShowRequired :select-open="dangerTypeDialog" @click="showDangerType(model)" />
                    <eagle-radios title="隐患性质" onlyShowRequired :dataSource="checkDatas.checkType" v-model="model.hiddenDangerType" />
                    <eagle-date label-width="100px" key="correctiveDate" title="整改期限" v-model="model.correctiveDate" />
                </view>

                <view v-if="opType=='view' ">
                    <eagle-display-image title="隐患图片" key="display_attachs" prop="attachs" v-model="model.attachs" />
                    <eagle-text title="隐患区域">{{model.hiddenDangerArea}}</eagle-text>
                    <eagle-text title="隐患描述">{{model.hiddenDangerDesc}}</eagle-text>
                    <view style="text-align: right;margin-top:10px">
                        <span style="color:#2979ff;margin-left: 20rpx;" @click="showDetail()">查看依据</span>
                    </view>
                    <eagle-text title="整改建议">{{model.correctiveAdvise}}</eagle-text>

                    <eagle-text title="隐患分类">{{model.lgdName}}</eagle-text>
                    <eagle-text title="隐患性质">{{model.hiddenDangerType=="1"?"一般隐患":(model.hiddenDangerType=="2"?"重大隐患":"")}}</eagle-text>
                    <eagle-text title="整改期限">{{model.correctiveDate}}</eagle-text>
                </view>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="default" @click="hdBack">返 回</u-button>
            <u-button class="bottom-btn" type="primary" v-if="opType!='view'" @click="confirm">确 定</u-button>
        </eagle-bottom-view>
        <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog=false" v-model="model.lgdCode" @change="changeDangeType"></popup-danger-type>

    </view>
</template>

<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type.vue";
export default {
    components: {
        popupDangerType,
        "view-danger-lg": viewDangerLg,
    },
    data() {
        return {
            dangerTypeDialog: false,
            model: {},
            item: {},
            opType: this.$route.query.opType ?? "view",
            tempModel: {},
            checkDatas: {
                checkType: [
                    { id: 1, name: "一般隐患" },
                    { id: 2, name: "重大隐患" },
                ],
            },
        };
    },
    created() {
        this.initData();
    },
    methods: {
        hdBack() {
            localStorage.removeItem("HD_DangerForTemp_danger");
            localStorage.removeItem("HD_DangerForTemp_GreatGrandsons");
            this.base.navigateBack(1);
        },
        initData() {
            this.model = {};
            this.item = [];
            this.model = JSON.parse(
                localStorage.getItem("HD_DangerForTemp_danger")
            );
            this.item = JSON.parse(
                localStorage.getItem("HD_DangerForTemp_GreatGrandsons")
            );
        },
        showDetail() {
            let config = {
                isEdit: this.opType != "view",
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },

        showDangerType() {
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.model.lgdType = obj.dType;
            this.model.lgdCode = obj.dCode;
            this.model.lgdName = obj.dFullName.replace(">", "-");
            this.dangerTypeDialog = false;
        },
        setDangerDesc(item) {
            this.model.hiddenDangerDesc = item.hiddenDangerDesc;
            this.model.hiddenDangerType = item.hiddenDangerType;
            this.model.legalLiability = item.legalLiability;
            this.model.lgdCode = item.dCode;
            this.model.lgdName = item.dName;
            this.model.lgdType = item.dType;
            if (item.dType && item.dName) {
                this.model.lgdName = `${
                    item.dType == "1" ? "基础管理" : "现场管理"
                }-${this.model.lgdName}`;
            }
        },
        confirm() {
            this.model.isOver = true;
            if (
                (!this.model.hiddenDangerArea && this.model.lgdType == "2") ||
                !this.model.hiddenDangerDesc ||
                !this.model.lgdName ||
                !this.model.hiddenDangerType
            ) {
                this.model.isOver = false;
            }
            this.item.checkDetails.push(this.model);

            this.$bus.$emit("HD_DangerForTemp", this.model);
            this.hdBack();
        },
    },
};
</script>

<style lang="scss" scoped>
.hd-danger-template-single-detail {
    .useing-title {
        color: #8d8e90;
    }

    .btn-using {
        color: #2979ff;
        // margin-left: 20rpx;
        width: 40px;
        text-align: right;
        font-size: 16px;
    }
    .content-using {
        flex: 1;
    }

    .eagle-line-block {
        line-height: 28px;
        padding: 0px 15px;
        .choose-block {
            border-bottom: 1px solid #e5e7ec;
        }
        .using-content {
            // margin-top: 5px;
            // text-indent: 12px;
            display: flex;
            justify-content: space-between;
            font-size: 15px;
        }
    }
}
</style>
