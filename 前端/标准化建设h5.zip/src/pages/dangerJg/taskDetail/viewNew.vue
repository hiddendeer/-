<template name="danger-jg-check-view">
    <view class="danger-jg-check-view">
        <eagle-form class="form-content" :control="controller" :boolInitData="false" @initCallBack="bindData" v-model="model" ref="eagleForm" marginBottom="120px">
            <eagle-container>
                <view slot="title">隐患详情</view>
                <!-- <eagle-text title="隐患图片"> -->
                <eagle-display-image title="隐患图片" v-model="model.attachs"></eagle-display-image>
                <!-- </eagle-text> -->
                <eagle-text title="隐患区域" v-model="model.hiddenDangerArea" />
                <eagle-text title="隐患描述" v-model="model.hiddenDangerDesc" />
                <eagle-text title="整改建议" v-model="model.correctiveAdvise" />
                <eagle-text title="隐患分类" v-model="model.lgdName" />
                <eagle-text title="隐患性质">
                    {{model.hiddenDangerType=="1"?"一般隐患":(model.hiddenDangerType=="2"?"重大隐患":"")}}
                    <!-- <eagle-radios disabled :data-source="params.checkType" v-model="model.hiddenDangerType" /> -->
                </eagle-text>
                <eagle-text title="整改期限" :value="model.correctiveDate|dateFormat">
                </eagle-text>
                <eagle-text title="隐患来源">
                    {{model.originType|paramsFormat(params.checkSource)}}
                </eagle-text>
                <eagle-text title="检查人" v-model="model.createChnName" />
                <eagle-text title="检查时间" :value="model.createDate|dateFormat" />
            </eagle-container>

            <eagle-container>
                <view slot="title">操作历史记录</view>
                <view class="card-content">
                    <view class="log-item" v-for="(item ,index ) in logList" :key="'log_'+index">
                        <text class="index">{{index+1}}.</text><text class="content">{{item.opeateLog}}</text>
                    </view>
                </view>
            </eagle-container>
        </eagle-form>
        <!-- <eagle-bottom-view marginBottom="0px">
            <u-button class="bottom-btn" type="default" @click="back">返 回</u-button>
        </eagle-bottom-view> -->
        <u-toast ref="uToast" />
    </view>
</template>
<script>
export default {
    components: {},
    name: "danger-jg-check-view",
    data() {
        return {
            title: "",
            showDialog: false,
            controller: "danger/jgDangerTaskDetail",
            model: {},
            params: {
                checkType: [
                    { id: 1, name: "一般隐患" },
                    { id: 2, name: "重大隐患" },
                ],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
            },
            logList: [],
            id: -10,
            code: "",
        };
    },
    created() {
        this.code = this.$route.query.code;
        this.id = this.$route.query.id;
        this.getModel();
    },
    methods: {
        getLogs() {
            let _this = this;
            let url = `danger/jgDangerLog/getList/${_this.model.code}`;
            _this.common.get(url).then((res) => {
                if (res.code == 200) _this.logList = res.data;
            });
        },
        getModel() {
            var _this = this;
            this.common
                .get(`${this.controller}/getData/` + this.id)
                .then((res) => {
                    _this.model = res.data;
                    _this.getLogs();
                });
        },
        back() {
            this.base.navigateBack();
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-jg-check-view {
    .card-content {
        padding: 5px 10px;
        .log-item {
            margin-top: 10px;
        }
        .log-item:first {
            margin-top: 0px;
        }
    }
    .form-content {
        .item {
            .item-title {
                display: flex;
                background-color: #2979ff;
                line-height: 35px;
                margin: 10px -30px;
                padding: 0px 30px;
                font-size: 16px;
                font-weight: 600;
                color: #ffffff;
                -webkit-box-flex: 1;
                -webkit-flex: 1;
                flex: 1;

                .arrow-up-fill {
                    text-align: right;
                }
            }

            // .citem {
            //     padding: 10px 0px;
            // }
        }
    }

    .button-pannel {
        width: 100%;
        display: inline-flex;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;

        .button-item {
            margin-left: 5px;
            margin-right: 5px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            border: 1px solid #dfe4ec;
            width: 28%;
            /* height: 30px; */
            border-radius: 5px;
            line-height: 30px;
        }

        .button-item.Y.checked {
            border: 1rpx solid #19be6b;
            background-color: #19be6b;
            color: #ffffff;
        }

        .button-item.NA.checked {
            border: 1rpx solid #ff976a;
            background-color: #ff976a;
            color: #ffffff;
        }

        .button-item.N.checked {
            border: 1rpx solid red;
            background-color: red;
            color: #ffffff;
        }
    }
}

// .view-botton {
//     padding: 20rpx;
// }
</style>
