<template>
    <view class="host-danger-set-single-detail">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">{{opType=='view'?"隐患详情":"录入隐患信息"}} </eagle-head>
            <eagle-form :model="model" :boolInitData="false" marginBottom='60px'>
                <eagle-container>
                    <view v-if="model.checkResult==='N'">
                        <eagle-upload :isNeedEdit="true" title="隐患图片" v-if="opType!=='view'" key="attachs" prop="attachs" v-model="model.attachs" />
                        <eagle-display-image title="隐患图片" v-if="opType==='view'" key="display_attachs" prop="attachs" v-model="model.attachs" />
                        <eagle-input type="textarea" :disabled="opType=='view'" title="隐患区域" required onlyShowRequired v-model="model.hiddenDangerArea" />
                        <view style="background: #ffffff" class="eagle-line-block">
                            <view class="choose-block" v-if="opType!='view'">
                                <view class="useing-title">快捷选择隐患</view>
                                <view v-for="(item,index) in item.greatGrandsons" class="using-content" :key="index">
                                    <span class="content-using" @click="setDangerDesc(item)"> {{index+1}}. {{item.hiddenDangerDesc}}</span>
                                    <span class="btn-using" @click="setDangerDesc(item)">引用</span>
                                </view>
                            </view>
                        </view>

                        <eagle-input type="textarea" :disabled="opType=='view'" title="隐患描述" required onlyShowRequired v-model="model.hiddenDangerDesc" />
                        <eagle-input type="textarea" :disabled="opType=='view'" title="整改建议" v-model="model.correctiveAdvise">
                            <template slot="topBotton">
                                <view style="text-align: right;margin-top:10px">
                                    <span style="color:#2979ff;margin-left: 20rpx;margin-right: 20rpx;" @click="showDetail()">{{opType!='view'?"编辑依据":"查看依据"}}</span>
                                </view>
                            </template>
                        </eagle-input>
                        <eagle-choose title="隐患分类" :disabled="opType=='view'" v-model="model.lgdName" required onlyShowRequired :select-open="dangerTypeDialog" @click="showDangerType(model)" />
                        <eagle-radios title="隐患性质" :disabled="opType=='view'" required onlyShowRequired :dataSource="checkDatas.checkType" v-model="model.hiddenDangerType" />

                        <eagle-date :disabled="opType=='view'" label-width="100px" key="correctiveDate" title="整改期限" v-model="model.correctiveDate" />

                    </view>
                </eagle-container>
            </eagle-form>
            <eagle-bottom-view>
                <u-button type="primary" v-if="opType!='view'" @click="confirm">确 定</u-button>
                <u-button type="primary" v-if="opType=='view'" @click="showDialog=false">返 回</u-button>
            </eagle-bottom-view>
            <view-danger-lg ref="viewDangerLg"></view-danger-lg>
            <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog=false" v-model="model.lgdCode" @change="changeDangeType"></popup-danger-type>
        </u-popup>
    </view>
</template>

<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type.vue";
export default {
    components: {
        popupDangerType,
        "view-danger-lg": viewDangerLg,
    },
    data() {
        return {
            dangerTypeDialog: false,
            title: "录入检查情况",
            showDialog: false,
            model: {},
            item: {},
            opType: "view",
            tempModel: {},
            checkDatas: {
                checkType: [
                    { id: 1, name: "一般隐患" },
                    { id: 2, name: "重大隐患" },
                ],
            },
        };
    },
    methods: {
        showDetail(item) {
            let config = {
                isEdit: this.opType != "view",
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },
        show(config) {
            // console.log('config=>', config)
            this.model = this.utils.deepClone(config.model);
            this.tempModel = config.model;
            this.item = config.item;
            if (this.model.checkResult != "N") {
                this.model.remarks = this.model.hiddenDangerDesc;
                this.model.hiddenDangerDesc = "";
            }
            this.opType = config.opType;
            this.showDialog = true;
        },
        showDangerType() {
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.model.lgdType = obj.dType == "1";
            this.model.lgdCode = obj.dCode;
            this.model.lgdName = obj.dFullName.replace(">", "-");
            // this.model.hiddenCode = obj.dCode;
            // this.model.hiddenName = obj.dFullName.replace(">", "-");
            // this.model.hiddenTypeCode = obj.dType
            // this.model.hiddenTypeName = obj.dType == "1" ? "基础管理" : "现场管理";;
            this.dangerTypeDialog = false;
        },
        setDangerDesc(item) {
            this.model.hiddenDangerDesc = item.hiddenDangerDesc;
            this.model.hiddenDangerType = item.hiddenDangerType;
            this.model.legalLiability = item.legalLiability;
            this.model.lgdCode = item.dCode;
            this.model.lgdName = item.dName;
            this.model.lgdType = item.dType;
            if (item.dType && item.dName) {
                this.model.lgdName = `${
                    item.dType == "1" ? "基础管理" : "现场管理"
                }-${this.model.lgdName}`;
            }
        },
        confirm() {
            this.showDialog = false;
            if (this.model.checkResult != "N") {
                this.model.hiddenDangerDesc = this.model.remarks;
                this.model.remarks = "";
            }
            if (this.model.checkResult === "N") {
                this.model.isOver = true;
                if (
                    !this.model.hiddenDangerArea ||
                    !this.model.hiddenDangerDesc ||
                    !this.model.lgdName ||
                    !this.model.hiddenDangerType
                ) {
                    this.model.isOver = false;
                }
            }
            if (this.opType == "edit")
                for (let key in this.model) {
                    this.$set(this.tempModel, key, this.model[key]);
                }
            else {
                this.item.checkDetails.push(this.model);
            }
            this.$emit("confirm", this.model, this.opType);
        },
    },
};
</script>

<style lang="scss" scoped>
.host-danger-set-single-detail {
    .useing-title {
        color: #8d8e90;
    }

    .btn-using {
        color: #2979ff;
        // margin-left: 20rpx;
        width: 50px;
        text-align: right;
        font-size: 16px;
    }
    .content-using {
        flex: 1;
    }

    .eagle-line-block {
        line-height: 28px;
        padding: 0px 15px;
        .choose-block {
            border-bottom: 1px solid #e5e7ec;
        }
        .using-content {
            // margin-top: 5px;
            // text-indent: 12px;
            display: flex;
            justify-content: space-between;
            font-size: 15px;
        }
    }
}
</style>
