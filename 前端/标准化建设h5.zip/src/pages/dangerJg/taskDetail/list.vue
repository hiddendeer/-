<template name="danger-jg-detail-list">

    <view class="danger-jg-check-detail-list">
        <!-- <eagle-head @close="showDialog=false">隐患列表</eagle-head> -->
        <eagle-page-list ref="eaglePageList" dataType="list" @initList="_initList" :bool-init-data="false"
            :pageSize="20" :controller="controller" :margin-bottom="38" @beforeLoad="beforeLoad" :showCheck="true"
            data-type="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" title="隐患状态"
                            prop="status" :data-source="params.taskDetailStatus" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.originType.value" title="来源类型"
                            prop="originType" :data-source="params.originType" />
                        <eagle-input title="隐患描述" placeholder="请输入隐患描述模糊查询" v-model="conditions.hiddenDangerDesc.value"
                            :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdClick(item, 0)">
                    <eagle-girdrow-base isTitle>{{ item.hiddenDangerDesc }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-base sBetween>
                        <view>
                            <text>隐患来源： {{ item.originType | paramsFormat(params.originType) }}</text>
                        </view>
                        <view v-if="item.complete == false" style="color:#dd6161;font-size:34rpx">
                            待完善
                        </view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base>
                        检查人：{{ item.createChnName }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        检查日期： {{ item.createDate | dateTimeFormat }}
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="success" @click="hdClick(item, 0)" size="mini">详情</u-button>
                        <u-button type="primary" v-if="item.jg == false && item.status == 40" @click="hdClick(item, 1)"
                            size="mini">制定措施</u-button>
                        <u-button type="primary" v-if="item.jg == false && item.status == 50" @click="hdClick(item, 2)"
                            size="mini">整改</u-button>
                        <u-button type="primary" v-if="item.jg && item.status !== 100" @click="hdClick(item, 3)"
                            size="mini">复查</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item) in data" :key="item.ID">
                    <view class="uni-media-list">
                        <view class="uni-media-list-body" @click="hdClick(item,0)">
                            <eagle-girdrow-base>
                                <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                    <eagle-girdrow-block>{{item.hiddenDangerDesc}}</eagle-girdrow-block>
                                </eagle-girdrow-base>
                                <view>
                                    <text>隐患来源 : {{item.originType|paramsFormat(params.originType)}}</text>
                                </view>
                                <view>
                                    <text>隐患状态 : <text v-html="common.formateStatus(params.taskDetailStatus,item.status)"></text>
                                    </text>
                                </view>
                                <view style="display: flex;justify-content: space-between;">
                                    <text>
                                        <u-icon name="account-fill"></u-icon>{{item.createChnName}}
                                    </text>
                                    <text>
                                        <u-icon name="clock"></u-icon>
                                        {{item.createDate|dateTimeFormat}}
                                    </text>
                                </view>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-icon class="eagle-blue eagle-row-span" name="eye" label="详情" @click="hdClick(item,0)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" name="edit-pen" label="制定措施" v-if="item.jg==false && item.status==40" @click="hdClick(item,1)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" name="bookmark" label="整改" v-if="item.jg==false && item.status==50" @click="hdClick(item,2)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" name="bookmark" label="复查" v-if="item.jg && item.status!==100" @click="hdClick(item,3)"></u-icon>
                    </eagle-grid-botton>
                </view> -->
            </view>
        </eagle-page-list>
        <dangerJgView ref="dangerJgView" @saved="search" />
        <tabbar-danger-jg></tabbar-danger-jg>
    </view>

</template>
<script>
// import dangerJgDetail from '@/pages/dangerJg/taskDetail/detail'
import dangerJgView from "@/pages/dangerJg/taskDetail/view";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg.vue";
export default {
    components: {
        // dangerJgDetail,
        dangerJgView,
        TabbarDangerJg,
    },
    name: "danger-jg-detail-list",
    onShow() {
        this.search();
    },
    data() {
        return {
            data: [],
            // showDialog: false,
            mainCode: "",
            controller: "danger/jgDangerTaskDetail",
            conditions: {
                checkResult: { value: "N", operate: "=" },
                status: { value: null, operate: "=" },
                originType: { value: null, operate: "=" },
                hiddenDangerType: { value: null, operate: "=" },
                hiddenDangerDesc: { value: null, operate: "like" },
            },
            params: {
                taskDetailStatus: [
                    {
                        id: "40",
                        name: "待制定措施",
                        color: "rgb(27, 118, 209)",
                    },
                    { id: "50", name: "待整改", color: "rgb(27, 118, 209)" },
                    { id: "60", name: "待复查", color: "#67C23A" },
                    { id: "100", name: "已完成", color: "#67C23A" },
                ],
                checkType: [],
                dangerType: [],

                originType: [
                    { id: "1", name: "随手拍" },
                    { id: "2", name: "依据检查" },
                    { id: "3", name: "检查表检查" },
                ],
            },
        };
    },
    created() {
        this.initParams();
    },
    methods: {
        bindTag(val) {
            let obj = this.params.taskDetailStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        // show(options) {
        //     this.mainCode = options.taskCode;
        //     this.initParams();
        //     this.showDialog = true;
        // },
        initParams() {
            // var _this = this;
            // this.common.getparamsList("dangerJg_corrective_status").then(function (res) {
            //     if (res.code == 200 && res.data) {
            //         _this.params.taskDetailStatus = res.data.filter(p => p.paramId == "dangerJg_corrective_status")
            //     }
            // })
        },
        reSearsh() {
            this.conditions.hiddenDangerDesc.value = null;
            this.conditions.originType.value = null;
            this.conditions.status.value = null;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdClick(item, opType) {
            let _this = this;
            _this.$refs.dangerJgView.show({
                taskCode: item.code,
                opType: opType,
                id: item.id,
            });
        },
        _initList(list) {
            this.data = list;
        },
        change() {
            this.search();
        },
        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                // url: "site/dangerCheckTaskDetail/getPageData",
                params: {
                    enterpriseCode: _this.$route.query.enterpriseCode ?? "",
                    projectId: _this.$route.query.projectId ?? "",
                },
            });
        },
    },
};
</script>

<style>
</style>