<template name="danger-jg-enterprise-danger-list">
    <view class="danger-jg-enterprise-danger-list">
        <eagle-page-list ref="eaglePageList" dataType="enterpriseVerifyList" @initList="_initList" :bool-init-data="false" :pageSize="20" :controller="controller" :margin-bottom="38" @beforeLoad="beforeLoad" :showCheck="true">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" v-if="params.correctiveStatus && params.correctiveStatus.length > 0" title="隐患状态" prop="status" :data-source="params.correctiveStatus" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.originType.value" title="来源类型" prop="originType" :data-source="params.originType" />
                        <eagle-input title="隐患描述" placeholder="请输入隐患描述模糊查询" v-model="conditions.hiddenDangerDesc.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">

                <eagle-row-card v-for="(item, index) in data" :key="index">

                    <eagle-girdrow-base :sBetween="true" :isTitle="true">
                        <eagle-girdrow-block class="circleShow">{{ item.hiddenDangerDesc }}</eagle-girdrow-block>
                    </eagle-girdrow-base>

                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>

                    <eagle-girdrow-base class='list-item'>
                        <view class="double-line">隐患来源: {{ item.originType | paramsFormat(params.originType) }}</view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base>
                        检查人：{{ item.createChnName }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        检查日期： {{ item.createDate | dateTimeFormat }}
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button type="primary" v-if="item.status >= 30 && item.status < 80" @click="hdVerifyClick(item, 3)" size="mini">复查</u-button>
                        <u-button type="success" @click="hdViewClick(item, 0)" size="mini">详情</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <dangerJgDetail ref="dangerJgDetail" @saved="search" />
        <dangerJgView ref="dangerJgView" @saved="search" />
    </view>

    <!-- </u-popup> -->
</template>
<script>
import dangerJgDetail from "@/pages/dangerJg/taskDetail/detail";
import dangerJgView from "@/pages/dangerJg/taskDetail/view";
export default {
    components: { dangerJgDetail, dangerJgView },
    name: "danger-jg-enterprise-danger-list",

    data() {
        return {
            data: [],
            showDialog: false,
            mainCode: "",
            isEnd: 0,
            status: 0,
            controller: "danger/jgDangerTaskDetail",
            conditions: {
                checkResult: { value: "N", operate: "=" },
                status: { value: null, operate: "=" },
                originType: { value: null, operate: "=" },
                hiddenDangerType: { value: null, operate: "=" },
                hiddenDangerDesc: { value: null, operate: "like" },
            },
            params: {
                correctiveStatus: [
                    { id: "30", name: "待整改", type: "red" },
                    { id: "60", name: "待复查", type: "red" },
                    { id: "80", name: "无需复查", type: "success" },
                    { id: "100", name: "复查通过", type: "success" },
                ],
                checkType: [],
                dangerType: [],
                originType: [
                    { id: "1", name: "随手拍" },
                    { id: "2", name: "依据检查" },
                    { id: "3", name: "检查表检查" },
                ],
            },
        };
    },
    onShow() {
        this.initParams();
        this.enterpriseCode = this.$route.query.enterpriseCode;

        this.projectId = this.$route.query.projectId ?? "";
        setTimeout(() => {
            this.search();
        });
    },
    methods: {
        bindTag(val) {
            console.log(val);
            let obj = this.params.correctiveStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        show(options) {
            this.mainCode = options.taskCode;
            this.showDialog = true;
        },
        initParams() {},
        reSearsh() {
            this.conditions.hiddenDangerDesc.value = null;
            this.conditions.originType.value = null;
            this.conditions.status.value = null;
        },
        hdDelete(item) {
            let _this = this;
            var url = `${_this.controller}/dangerDelete/${item.ctCode}/${item.id}`;
            // let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdViewClick(item, opType) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/viewNew",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdEditClick(item, opType) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/detailNew",
                {
                    id: item.id,
                    taskCode: item.code,
                    opType: opType,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdVerifyClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/dangerJg/taskDetail/detailVerify",
                {
                    id: item.id,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdClick(item, opType) {
            let _this = this;
            _this.$refs.dangerJgDetail.show({
                taskCode: item.code,
                opType: opType,
                id: item.id,
            });
        },
        _initList(list) {
            this.data = list;
        },
        change() {
            this.search();
        },
        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: {
                    enterpriseCode: _this.enterpriseCode,
                    projectId: _this.projectId,
                },
            });
        },
    },
};
</script>

<style>
</style>