<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :boolInitData="false" :dataType="dataType" :pageSize="20" :controller="controller" :margin-bottom="dataType == 'list' ? 60 : 10" @beforeLoad="beforeLoad" :showCheck="true">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearsh" :searchResults="searchResults">
                        <eagle-input title="项目名称" placeholder="请输入项目名称" v-model="conditions.projectName.value" :labelWidth="150"></eagle-input>
                        <eagle-input title="项目单位" placeholder="请输入项目单位" v-model="conditions.enterpriseName.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="gotoProjectDetail(item)">
                    <eagle-girdrow-base :sBetween="true" :isTitle="true">
                        {{ item.projectName }}
                        <!-- <eagle-girdrow-block class="circleShow"></eagle-girdrow-block> -->
                    </eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-base>项目负责人:{{ item.mainChnName }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base class='list-item' v-show="item.partChnName">
                        <view class="double-line">项目参与人:{{ item.partChnName }}</view>
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        <view class='list-item'>项目起止时间:{{ item.startDate | dateFormat }}至{{ item.endDate | dateFormat }}
                        </view>
                    </eagle-girdrow-base>
                    <template slot="button">
                        <u-button style="color: white;background: rgb(153, 153, 153);" size="mini" v-if="!item.btnEnable && item.status > 10">实施
                        </u-button>
                        <u-button type="success" size="mini" v-if="item.btnEnable && item.status > 10" @click="gotoProjectDetail(item)">实施</u-button>
                        <u-button type="primary" size="mini" v-if="item.status != 30 && queryParams.modulesId == 'dangerJg'" @click="goToCheck(item)">检查
                        </u-button>
                        <u-button type="primary" size="mini" v-if="item.status != 30" @click="showAction(item)">更多
                        </u-button>
                    </template>
                </eagle-row-card>
                <u-action-sheet v-model="actionShow" @close="actionShow = false" :list="actionList" @click="clickSheet" :borderRadius="15" cancelText="取消">
                </u-action-sheet>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <popup-project-finish ref="projectFiniah" @submitCallBack="search"></popup-project-finish>
    </view>
</template>

<script>
import PopupProjectFinish from "./case.vue";
import { isConsultManager, isJGB } from "@/api/auth.js";
export default {
    components: {
        PopupProjectFinish,
    },
    name: "prj-list",
    props: {
        isMy: {
            type: String,
            default() {
                return "";
            },
        },
    },
    mounted() {
        // this.search();
    },
    data() {
        return {
            controller: "site/projectConsultation",
            data: [],
            isGetData: false,
            clearabled: true,
            dataType: "",
            searchResults: "",
            actionShow: false,
            optionItem: {},
            actionList: [
                {
                    text: "项目安排",
                    name: "arrange",
                },
                {
                    text: "结案",
                    name: "case",
                },
            ],
            conditions: {
                projectName: {
                    value: "",
                    operate: "like",
                },
                enterpriseName: {
                    value: "",
                    operate: "like",
                },
            },
            queryParams: {
                modulesId: "",
            },
            params: {
                stateArr: [
                    { name: "未安排", id: "10", type: "purple" },
                    { name: "进行中", id: "20", type: "primary" },
                    { name: "已结案", id: "30", type: "success" },
                ],
            },
            isConsultManager: isConsultManager(),
        };
    },

    created() {
        this.queryParams.modulesId = this.$route.query.modulesId;
        if (this.isMy == "Y") {
            this.dataType = "list";
            uni.setNavigationBarTitle({
                title: "项目列表",
            });
            this.search();
        } else {
            this.dataType = "managerList";
        }
    },

    onShow() {
        this.search();
    },

    methods: {
        bindTag(val) {
            console.log(val);
            let obj = this.params.stateArr.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        showAction(item) {
            this.optionItem = item;
            let btnArry = [];
            btnArry.push({
                text: "项目安排",
                name: "arrange",
            });
            btnArry.push({
                text: "结案",
                name: "case",
            });
            if (this.isConsultManager) {
                btnArry.push({
                    text: "删除",
                    name: "delete",
                });
            }
            this.actionList = btnArry;
            this.actionShow = true;
        },
        clickSheet(index) {
            let item = this.actionList[index];
            switch (item.name) {
                case "arrange":
                    this.handlerEitClick(this.optionItem);
                    break;
                case "case":
                    this.handlerCaseClick(this.optionItem);
                    break;
                case "delete":
                    this.del(this.optionItem.id);
                    break;
            }
        },
        _initList(list) {
            this.data = list;
            this.isGetData = true;
        },
        reSearsh() {
            this.conditions.projectName.value = "";
            this.conditions.enterpriseName.value = "";
            this.search();
        },
        handlerFabClick() {
            var url =
                "/pages/project/projectConsultation/detail?id=0&modulesId=" +
                this.queryParams.modulesId;
            if (this.isMy) {
                url = url + "&isMy=" + this.isMy;
            }

            this.base.navigateTo(url);
        },
        goToCheck(item) {
            var url = this.common.getLinkUrl("/pages/dangerJg/task/detail", {
                id: 0,
                enterpriseCode: item.enterpriseCode,
                projectId: item.code,
            });
            this.base.navigateTo(url);
        },
        handlerCaseClick(item) {
            this.$refs.projectFiniah.show(item.id);
        },
        handlerEitClick(item) {
            var url = this.common.getLinkUrl(
                "/pages/project/projectConsultation/detail",
                {
                    modulesId: this.queryParams.modulesId,
                    id: item.id,
                }
            );
            // var url =
            //     "/pages/project/projectConsultation/detail?modulesId=" +
            //     this.queryParams.modulesId +
            //     "&id=" +
            //     item.id;
            if (this.isMy) {
                url = url + "&isMy=" + this.isMy;
            }

            this.base.navigateTo(url);
        },

        handlerViewClick(item) {
            var url =
                "/pages/project/projectConsultation/view?modulesId=" +
                this.queryParams.modulesId +
                "&id=" +
                item.id;
            if (this.isMy) {
                url = url + "&isMy=" + this.isMy;
            }

            this.base.navigateTo(url);
        },

        search() {
            var searchResults = "";

            if (this.conditions.projectName.value) {
                searchResults = this.conditions.projectName.value;
            }

            if (this.conditions.enterpriseName.value) {
                if (searchResults == "") {
                    searchResults = this.conditions.enterpriseName.value;
                } else {
                    searchResults =
                        searchResults +
                        "," +
                        this.conditions.enterpriseName.value;
                }
            }

            this.searchResults = searchResults;

            let _this = this;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: _this.common.getCondtions(_this.conditions),
                    params: _this.queryParams,
                });
            });
        },

        gotoProjectDetail(item) {
            let url = "/pages/host/hostMain/hostIndex";
            if (
                this.$route.query.modulesId == "host" ||
                item.serviceType == "C"
            ) {
                url = "/pages/host/hostMain/hostMainIndex";
            }
            url =
                url +
                "?projectId=" +
                item.code +
                "&enterpriseCode=" +
                item.enterpriseCode;
            switch (item.serviceType) {
                case "A":
                    url = url + "&modulesId=dangerJg";
                    break;
                case "C":
                    url = url + "&modulesId=host";
                    break;
                default:
                    break;
            }
            this.base.navigateTo(url);
        },

        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },

        // initParams() {
        //     var _this = this;
        //     this.common
        //         .getparamsList("site_project_manager_list_state")
        //         .then(function (res) {
        //             if (res.code == 200 && res.data) {
        //                 _this.params.stateArr = res.data;
        //             }
        //         });
        // },
    },
};
</script>

<style scoped lang="scss">
.double-line {
    display: -webkit-box;
    text-overflow: ellipsis;
    overflow: hidden;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
}

.circleShow {
    height: 50rpx;
    width: 100%;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;
}

.host-meeting-container {
    // height: calc(100vh);
    .list-item {
        height: 50rpx;
        line-height: 50rpx;
    }

    .popup-container {
        padding: 30rpx;
        box-sizing: border-box;

        .popup-item {
            box-sizing: border-box;
            // min-height: 140rpx;

            .popup-item-title {
                font-weight: 600;
                font-size: 30rpx;
            }
        }

        .popup-foot {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-top: 35rpx;

            .popup-foot-rest,
            .popup-foot-enter {
                width: 180rpx;
                height: 80rpx;
                line-height: 80rpx;
                text-align: center;
                border: 1rpx solid #cccccc;
                box-sizing: border-box;
            }

            .popup-foot-enter {
                width: 300rpx;
                background: #2979ff;
                color: #ffffff;
                border: none;
            }
        }
    }
}
</style>
