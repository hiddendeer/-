<template>
	<view>
		<eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60'
			:errorType="errorType" :initUrl="initUrl">

			<eagle-display-input v-model="model.orderNo" title="所属合同" prop="orderNo" v-if="isMy!='Y'"></eagle-display-input>
			<eagle-display-input v-model="customerName" title="合同单位" prop="customerName" v-if="isMy!='Y'"></eagle-display-input>
			<eagle-display-input v-model="model.enterpriseName" title="项目单位" prop="enterpriseName"></eagle-display-input>
			<eagle-display-input v-model="model.serviceName" title="服务类型" prop="serviceName"></eagle-display-input>
			<eagle-display-input v-model="model.projectName" title="项目名称" prop="projectName"></eagle-display-input>
			<eagle-display-input v-model="model.mainChnName" title="项目负责人" prop="mainChnName"></eagle-display-input>
			<!-- <eagle-display-input v-model="model.areaName" title="合作区域" prop="areaName"></eagle-display-input> -->
			<eagle-display-input v-model="model.partChnName" title="项目参与人" prop="partChnName"></eagle-display-input>
			<eagle-display-input v-model="model.startDate" title="开始日期" prop="startDate"></eagle-display-input>
			<eagle-display-input v-model="model.endDate" title="结束日期" prop="endDate"></eagle-display-input>
			<eagle-display-input v-model="model.projectContact" title="客户对接人" prop="projectContact"></eagle-display-input>
			<eagle-display-input v-model="model.projectMobile" title="联系方式" prop="projectMobile"></eagle-display-input>
			<eagle-display-input v-model="model.remarks" title="项目说明" prop="remarks"></eagle-display-input>
			<eagle-file-upload disabled title="项目方案" prop="attachs" v-model="model.attachs"  />
			<eagle-file-upload disabled title="项目计划书" prop="attachs2" v-model="model.attachs2"  />
			<eagle-file-upload disabled title="客户资料" prop="customerAttachs" v-model="model.customerAttachs" />

		</eagle-form>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				model: {},
				errorType: ["message"],
				control: "site/projectConsultation",
				labelPosition: "left",
				labelWidth: "150",
				type: "",
				initUrl: "",
				customerName: "",
				isArrange:"",
				isMy:"",
				params: {
					ProjectBuildStructureArray: [],
					SiteEquipmentSecureAttachArray: [],
				},
			};
		},
		
		created() {
			this.isMy = this.$route.query.isMy;//项目列表
		},
		methods: {
			initCallBack(data) {
				this.model = data;
				this.customerName = this.model.customerName;
			},
		},
	};
</script>

<style>
</style>
