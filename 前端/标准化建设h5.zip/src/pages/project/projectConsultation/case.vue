<template>
    <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
        <eagle-head title='项目结案' @close='close'></eagle-head>

        <eagle-form @initCallBack="initCallBack" :boolInitData="false" :control="control" v-model="model" ref="eagleForm" :out-height='60'>
            <eagle-container>
                <eagle-input v-model="model.finishRemarks" type="textarea" title="结案说明" prop="finishRemarks" required />
            </eagle-container>
        </eagle-form>

        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </u-popup>

</template>
<script>
export default {
    components: {},
    name: "popup-project-finish",
    data() {
        return {
            model: {
                id: 0,
                finishRemarks: "",
            },
            errorType: ["message"],
            control: "site/projectConsultation",
            initUrl: "",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
            },
            showDialog: false,
        };
    },
    created() {
        // this.model.id = this.$route.query.id;
        // this.initUrl = "site/projectConsultation/getData/" + this.model.id;
    },
    onReady() {
        var _this = this;
    },
    mounted() { },
    methods: {
        close() {
            this.showDialog = false;
        },
        show(id) {
            this.model.id = id;
            this.model.finishRemarks = "";
            this.showDialog = true;
        },
        initCallBack(data) { },
        post(op) {
            let _this = this;
            this.model.status = "30";

            this.$refs.eagleForm.post({
                url: "site/projectConsultation/finishPrj",
                model: _this.model,
                successCallback: function (res) {
                    if ((res.code = "200")) {
                        _this.$emit("submitCallBack");
                        _this.close();
                    }
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
