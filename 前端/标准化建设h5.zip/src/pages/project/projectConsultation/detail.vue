<template>
    <view class="hsot-meeting-detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="150" :initUrl="initUrl">
            <eagle-container>

                <!-- <eagle-input v-model="model.orderNo" title="所属合同" prop="orderNo" disabled labelWidth="150" :height="70" v-if="isArrange && isMy!='Y'">
                </eagle-input> -->

                <eagle-text title="所属合同" v-if="isArrange && isMy!='Y'">
                    {{model.orderNo}}
                </eagle-text>

                <eagle-window-choose customItem title="所属合同" dataType="windowList" headTitle="请选择所属合同" v-model="model.orderNo" :isMult="false" :names.sync="model.orderNo" showDetail="true" controller="site/projectContract" idField="orderNo" textField="orderNo" labelWidth="130" :height="70" @callBackChoosedData="handelProjectContractChoose" v-else-if="isMy!='Y'">
                    <template v-slot:popupBody='scope'>
                        <view>
                            <view class="c333">合同编号：{{scope.item.orderNo}}</view>
                            <view>客户名称：{{scope.item.customerName}}</view>
                            <view>服务类型：{{scope.item.serviceName}}</view>
                        </view>
                    </template>
                </eagle-window-choose>
                <eagle-window-choose ref="companyChoose" addUrl="pages/project/projectCompany/detail" title="项目单位" headTitle="请选择项目单位" v-model="model.enterpriseCode" :isMult="false" :names.sync="model.enterpriseName" showDetail="true" controller="system/company" idField="code" textField="name" labelWidth="130" dataType="list" @callBackChoosedData="callBackChoosedData" required>
                </eagle-window-choose>

                <eagle-window-choose title="服务类型" headTitle="请选择服务类型" v-model="model.serviceCode" :isMult="false" :names.sync="model.serviceName" :required="true" showDetail="true" controller="site/projectServiceType" :dataType="serviceDataType" idField="code" textField="serviceName" @callBackChoosedData="callBackServiceType" labelWidth="130"></eagle-window-choose>

                <eagle-input v-model="model.projectName" required title="项目名称" prop="projectName" labelWidth="150" />

                <eagle-window-choose title="管家服务模板" headTitle="请选择管家服务模板" v-model="model.entrustedBigCatalogCode" :isMult="false" :names.sync="model.entrustedBigCatalogName" :required="true" showDetail="true" controller="site/ledgerTemp" idField="code" textField="name" labelPosition="top" labelWidth="130" v-if="model.serviceType=='C'">
                </eagle-window-choose>

                <eagle-choose-user title="项目负责人" v-model="model.mainUserName" :names.sync="model.mainChnName" required></eagle-choose-user>
                <eagle-choose-user title="项目参与人" v-model="model.partUserName" :names.sync="model.partChnName" isMult></eagle-choose-user>

                <eagle-date type="daterange" :startDate.sync="model.startDate" :endDate.sync="model.endDate" title="项目日期" prop="startsDate" :height="70" required></eagle-date>

                <eagle-input v-model="model.projectContact" required title="客户对接人" prop="projectContact" labelWidth="150" />
                <eagle-input v-model="model.projectMobile" required title="联系方式" prop="projectMobile" labelWidth="150" />

                <eagle-input v-model="model.remarks" title="项目说明" prop="remarks" labelWidth="150" type='textarea' />

                <eagle-file-upload title="项目方案" prop="attachs" v-model="model.attachs" labelWidth="150" />
                <eagle-file-upload title="项目计划书" prop="attachs2" v-model="model.attachs2" labelWidth="150" />
                <eagle-file-upload title="客户资料" prop="customerAttachs" v-model="model.customerAttachs" labelWidth="150" />

                <eagle-bottom-view>
                    <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
                </eagle-bottom-view>
            </eagle-container>
        </eagle-form>
    </view>
</template>

<script>
import eagleText from "../../../components/eagle-text/eagle-text.vue";
export default {
    components: { eagleText },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectConsultation",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            initUrl: "site/projectConsultation/initData/0",
            customerName: "",
            isArrange: "",
            isMy: "",
            params: {
                ProjectBuildStructureArray: [],
                SiteEquipmentSecureAttachArray: [],
            },
            modulesId: "",
            serviceDataType: "list&serviceType=",
        };
    },
    onShow() {
        if (this.$refs.companyChoose) {
            this.$refs.companyChoose.search();
        }
    },
    created() {
        this.isArrange = this.$route.query.isArrange;

        this.isMy = this.$route.query.isMy; //项目列表
        this.modulesId = this.$route.query.modulesId;
        this.initUrl = this.initUrl + "?modulesId=" + this.modulesId;
        switch (this.modulesId) {
            case "dangerJg":
                this.serviceDataType = "list&serviceType=A";
                break;
            case "host":
                this.serviceDataType = "list&serviceType=C";
                break;
            default:
                break;
        }

        if (this.$route.query.id) {
            uni.setNavigationBarTitle({
                title: "项目安排",
            });
        }

        if (this.isArrange) {
            uni.setNavigationBarTitle({
                title: "项目安排(编辑)",
            });
        }
    },
    methods: {
        initCallBack(data) {
            this.model = data;

            if (!this.isArrange) {
                let nowDate = new Date();
                let date = new Date();
                let nextDate = new Date();
                let _this = this;
                _this.model.startDate = nowDate;
                nextDate = date.setMonth(date.getMonth() + 1);
                _this.model.endDate = new Date(nextDate);
            } else {
                this.customerName = this.model.customerName;
            }
        },

        callBackServiceType(choosedData) {
            if (
                this.model.enterpriseName != "" &&
                this.model.serviceName != ""
            ) {
                this.model.projectName =
                    this.model.enterpriseName + "-" + this.model.serviceName;
            } else if (this.model.enterpriseName != "") {
                this.model.projectName = this.model.enterpriseName;
            } else if (this.model.serviceName != "") {
                this.model.projectName = this.model.serviceName;
            }

            // v-if="form.serviceType=='C'||serviceType=='C'"

            if (choosedData.length > 0) {
                var item = choosedData[0];
                this.model.serviceType = item.serviceType;
            }
        },

        callBackChoosedData(choosedData) {
            if (
                this.model.enterpriseName != "" &&
                this.model.serviceName != ""
            ) {
                this.model.projectName =
                    this.model.enterpriseName + "-" + this.model.serviceName;
            } else if (this.model.enterpriseName != "") {
                this.model.projectName = this.model.enterpriseName;
            } else if (this.model.serviceName != "") {
                this.model.projectName = this.model.serviceName;
            }
        },

        handelProjectContractChoose(choosedData) {
            if (choosedData.length > 0) {
                var data = choosedData[0];
                this.model.orderNo = data.orderNo;
                this.model.orderName = data.orderName;
                this.model.orderCode = data.orderCode;

                this.model.customerName = data.partnerName;
                this.model.customerCode = data.partnerCode;
                //显示label用的
                this.customerName = data.partnerName;
            } else {
                this.model.orderNo = "";
                this.model.orderName = "";
                this.model.orderCode = "";

                this.model.customerName = "";
                this.model.customerCode = "";
                //显示label用的
                this.customerName = "";
            }
        },

        post(op) {
            let _this = this;

            this.model.arrangeDate = new Date();
            this.model.customerName = this.model.enterpriseName;
            this.model.status = 20;

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.close();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        close() {
            this.base.navigateBack();
        },
    },
};
</script>

<style>
</style>
