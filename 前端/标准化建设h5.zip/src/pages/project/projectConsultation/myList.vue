<template>
    <view class="eagle-layer">
        <prj-list ref="PrjList" isMy="Y"></prj-list>
        <TabbarHostIndex v-if='routerCategory==="host"'></TabbarHostIndex>
        <TabbarDangerIndex v-if='routerCategory==="dangerJg"'></TabbarDangerIndex>
    </view>
</template>

<script>
import PrjList from "./list.vue";
import TabbarHostIndex from "@/pages/components/tabbar/tabbar-host-index.vue";
import TabbarDangerIndex from "@/pages/components/tabbar/tabbar-danger-index.vue";
export default {
    components: { PrjList, TabbarHostIndex, TabbarDangerIndex },
    data() {
        return {
            state: "show",
        };
    },
    created() {
        console.log("父组件初始化3333");
    },
    mounted() {
        this.search();
    },
    onload() {
        console.log("mylist is onload");
    },
    onShow() {
        this.search();
    },
    onHide: function () {
        this.state = "hidden";
    },
    methods: {
        search() {
            if (this.$refs.PrjList) {
                this.$refs.PrjList.search();
            }
        },
    },
    computed: {
        routerCategory() {
            return this.$route.query.modulesId;
        },
    },
};
</script>
