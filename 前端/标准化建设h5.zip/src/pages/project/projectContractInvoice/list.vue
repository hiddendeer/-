<template>
    <view class="eagle-layer">
        <view class="u-tabs-box ">
            <u-tabs-swiper ref="tabs" :list="tabList" :current="tabIndex" @change="onTabChanged" :is-scroll="false">
            </u-tabs-swiper>
        </view>
        <view class="swiper-box" @transition="transition" @animationfinish="animationfinish">
            <view class="u-wrap">
                <eagle-page-list ref="eaglePageList" @initList="initList" :margin-bottom="120" :controller="controller" :dataType="dataType">
                    <view slot="search">
                        <view class="search">
                            <eagle-condition @reSearch="searchChang" @search="search" placeholder="请输入关键字进行模糊搜索" v-model="searchValue" :searchResults="searchValue.searchResults">

                                <eagle-date title="合同日期" type="daterange" :startDate.sync="searchValue.StartDate" :endDate.sync="searchValue.EndDate" :labelWidth="150"></eagle-date>
                                <eagle-input title="客户名称" placeholder="请输入客户名称进行模糊搜索" v-model="searchValue.customerName" :labelWidth="150"></eagle-input>
                                <eagle-input title="合同编号" placeholder="请输入合同编号进行模糊搜索" v-model="searchValue.orderNo" :labelWidth="150"></eagle-input>
                            </eagle-condition>
                        </view>
                    </view>
                    <view slot="list" class="list-wrap">
                        <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/projectContract/view?id=' + item.id)">
                            <eagle-row-view isTitle type="warn">
                                {{ item.orderName }}
                            </eagle-row-view>
                            <eagle-row-view :spaceBetween="false">
                                <view>
                                    <text>合同编号 : {{ item.orderNo }} </text>
                                </view>
                                <view>
                                    <text>客户名称 : </text>
                                    <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code=' + item.customerCode)">{{
                                                item.customerName
                                        }}
                                    </text>
                                </view>

                                <view>
                                    <text>服务类型 : {{ item.serviceName }} </text>
                                </view>

                                <view>
                                    <text>预计回款日期 : {{ item.payDate | dateFormat }} </text>
                                </view>

                                <view v-if="dataType == 'appliedInvoice'">
                                    <text>开票申请人 : {{ item.applyChnName }} </text>
                                </view>
                                <view v-if="dataType == 'appliedInvoice'">
                                    <text>开票申请时间 : {{ item.applyDate | dateFormat }} </text>
                                </view>

                                <view>
                                    <text>申请开票金额 : {{ item.planInvoicePrice | twoDecimal }} </text>
                                </view>
                            </eagle-row-view>
                            <template slot="button">

                                <u-button type="primary" size="mini" @click="goto('/pages/project/projectContractInvoice/detail?type=1&code=' + item.backCode)" v-if="dataType == 'toBeInvoice'">开票</u-button>

                                <u-button type="primary" size="mini" @click="goto('/pages/project/projectContractInvoice/detail?type=2&code=' + item.applyCode)" v-else-if="dataType == 'appliedInvoice'">开票</u-button>
                            </template>
                        </eagle-row-card>
                        <!-- <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                            <view class="uni-media-list" @click="goto('/pages/project/projectContract/view?id='+item.id)">
                                <view class="uni-media-list-body">
                                   
                                    <eagle-girdrow-base :isTitle="true">
                                        <eagle-girdrow-block>{{item.orderName}}</eagle-girdrow-block>
                                    </eagle-girdrow-base>
                               
                                    <eagle-girdrow-base>

                                        <view>
                                            <text>合同编号 : {{item.orderNo}} </text>
                                        </view>
                                        <view>
                                            <text>客户名称 : </text>
                                            <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code='+item.customerCode)">{{item.customerName}} </text>
                                        </view>

                                        <view>
                                            <text>服务类型 : {{item.serviceName}} </text>
                                        </view>

                                     

                                        <view>
                                            <text>预计回款日期 : {{item.payDate|dateFormat}} </text>
                                        </view>

                                        <view v-if="dataType =='appliedInvoice'">
                                            <text>开票申请人 : {{item.applyChnName}} </text>
                                        </view>
                                        <view v-if="dataType =='appliedInvoice'">
                                            <text>开票申请时间 : {{item.applyDate|dateFormat}} </text>
                                        </view>

                                        <view>
                                            <text>申请开票金额 : {{item.planInvoicePrice|twoDecimal}} </text>
                                        </view>
                                    </eagle-girdrow-base>
                                </view>
                            </view>
                            <eagle-grid-botton>

                                <u-icon class="eagle-blue eagle-row-span" name="rmb-circle" label="开票" @click="goto('/pages/project/projectContractInvoice/detail?type=1&code='+item.backCode)" v-if="dataType =='toBeInvoice'" />
                                <u-icon class="eagle-blue eagle-row-span" name="rmb-circle" label="开票" @click="goto('/pages/project/projectContractInvoice/detail?type=2&code='+item.applyCode)" v-else-if="dataType =='appliedInvoice'" />
                            </eagle-grid-botton>
                        </view> -->
                    </view>
                </eagle-page-list>
            </view>
        </view>

        <tabbar-site-project-invoice class="tabber-danger"></tabbar-site-project-invoice>
    </view>
</template>
<script>
import tabbarInvoice from "@/pages/components/tabbar/tabbar-site-project-invoice.vue";
export default {
    components: {
        "tabbar-site-project-invoice": tabbarInvoice,
    },
    onShow() {
        this.search();
    },
    data() {
        return {
            tabList: [
                {
                    name: "待开票",
                },
                {
                    name: "已申请开票",
                },
            ],
            tabIndex: 0,
            controller: "/site/projectContract",
            data: [],
            clearabled: true,
            dataType: "toBeInvoice",
            status: "30",
            searchValue: {
                status: "",
                searchResults: "",
                customerName: "",
                StartDate: "",
                EndDate: "",
                orderNo: "",
            },
            params: {},
        };
    },
    onReady() {
        this.initParams();
    },
    created() {},
    filters: {},
    methods: {
        onTabChanged(index) {
            this.tabIndex = index;
            if (this.tabIndex == 0) {
                this.dataType = "toBeInvoice";
            } else if (this.tabIndex == 1) {
                this.dataType = "appliedInvoice";
            }
            this.search();
        },
        searchChang() {
            this.searchValue.status = "";
            this.searchValue.name = "";

            this.searchValue.customerName = "";
            this.searchValue.StartDate = "";
            this.searchValue.EndDate = "";
            this.searchValue.orderNo = "";
        },
        search() {
            var conditions = [];
            var str = "";

            if (this.searchValue.StartDate && this.searchValue.EndDate) {
                let obj = {};
                obj.name = "contractDate";
                obj.operate = "like";
                obj.value = [
                    this.searchValue.StartDate,
                    this.searchValue.EndDate,
                ];
                conditions.push(obj);

                str =
                    this.searchValue.StartDate +
                    "至" +
                    this.searchValue.EndDate;
            }

            if (this.searchValue.customerName) {
                let obj = {};
                obj.name = "customerName";
                obj.operate = "like";
                obj.value = this.searchValue.customerName;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.customerName;
                } else {
                    str = str + "," + this.searchValue.customerName;
                }
            }

            if (this.searchValue.orderNo) {
                let obj = {};
                obj.name = "orderNo";
                obj.operate = "like";
                obj.value = this.searchValue.orderNo;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.orderNo;
                } else {
                    str = str + "," + this.searchValue.orderNo;
                }
            }

            this.searchValue.searchResults = str;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: conditions,
                    dataType: this.dataType,
                });
            });
        },
        initParams() {},
        initList(list) {
            this.data = list;
        },
        goto(url) {
            this.base.navigateTo(url);
        },
    },
};
</script>

<style lang="scss">
.m {
    color: #2979ff;
}
</style>
