<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @reSearch="reSearch" @search="search" placeholder="请输入查询条件搜索" v-model="searchValue" :searchResults="searchValue.searchResults">

                        <eagle-date title="开票日期" type="daterange" :startDate.sync="searchValue.StartDate" :endDate.sync="searchValue.EndDate" :labelWidth="150"></eagle-date>
                        <eagle-input title="客户名称" placeholder="请输入客户名称进行模糊搜索" v-model="searchValue.customerName" :labelWidth="150"></eagle-input>
                        <eagle-input title="合同编号" placeholder="请输入合同编号进行模糊搜索" v-model="searchValue.orderNo" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/projectContract/view?id=' + item.id)">
                    <eagle-row-view isTitle type="warn">
                        {{ item.orderNo }}
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            <text>客户名称：</text>
                            <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code=' + item.customerCode)">
                                {{ item.customerName }} </text>
                        </view>
                        <view>
                            <text>服务类型 : {{ item.serviceName }} </text>
                        </view>
                        <view>
                            <text>合同金额 : {{ item.totalPrice | twoDecimal }} </text>
                        </view>

                        <view>
                            <text>申请开票金额 : {{ item.planInvoicePrice | twoDecimal }} </text>
                        </view>
                        <view>
                            <text>实际开票金额 : {{ item.realInvoicePrice | twoDecimal }} </text>
                        </view>

                        <view>
                            <text>创建人 : {{ item.createChnName }} </text>
                        </view>
                        <view>
                            <text>开票日期 : {{ item.invoiceDate | dateFormat }} </text>
                        </view>
                        <view>
                            <text>状态 : {{ item.status | splitParamsFormat(params.invoiceState) }}</text>
                        </view>

                        <view>
                            <text>备注 : {{ item.remarks }}</text>
                        </view>

                        <view>
                            <eagle-grid-attach title="发票信息" v-model="item.attachs"></eagle-grid-attach>
                        </view>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="error" size="mini" @click="invalid(item)" v-if="item.status != 20">作废</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">

                    <view class="uni-media-list" @click="goto('/pages/project/projectContract/view?id=' + item.id)">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                <eagle-girdrow-block>{{ item.orderNo }}</eagle-girdrow-block>

                            </eagle-girdrow-base>

                            <eagle-girdrow-base>
                                <view>
                                    <text>客户名称 : </text>
                                    <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code=' + item.customerCode)">
                                        {{ item.customerName }} </text>
                                </view>
                                <view>
                                    <text>服务类型 : {{ item.serviceName }} </text>
                                </view>
                                <view>
                                    <text>合同金额 : {{ item.totalPrice | twoDecimal }} </text>
                                </view>

                                <view>
                                    <text>申请开票金额 : {{ item.planInvoicePrice | twoDecimal }} </text>
                                </view>
                                <view>
                                    <text>实际开票金额 : {{ item.realInvoicePrice | twoDecimal }} </text>
                                </view>

                                <view>
                                    <text>创建人 : {{ item.createChnName }} </text>
                                </view>
                                <view>
                                    <text>开票日期 : {{ item.invoiceDate | dateFormat }} </text>
                                </view>
                                <view>
                                    <text>状态 : {{ item.status | splitParamsFormat(params.invoiceState) }}</text>
                                </view>

                                <view>
                                    <text>备注 : {{ item.remarks }}</text>
                                </view>

                                <view>
                                    <eagle-grid-attach title="发票信息" v-model="item.attachs"></eagle-grid-attach>
                                </view>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-button type="error" size="mini" @click="invalid(item)" v-if="item.status != 20">作废</u-button>
                    </eagle-grid-botton>
                </view> -->
            </view>
        </eagle-page-list>

        <tabbar-site-project-invoice class="tabber-danger"></tabbar-site-project-invoice>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
import tabbarInvoice from "@/pages/components/tabbar/tabbar-site-project-invoice.vue";
export default {
    components: {
        "tabbar-site-project-invoice": tabbarInvoice,
    },
    onShow() {
        this.search();
    },
    data() {
        return {
            searchValue: {
                accidentType: "",
                name: "",

                searchResults: "",
                customerName: "",
                StartDate: "",
                EndDate: "",
                orderNo: "",
            },
            controller: "/site/projectContractInvoice",
            data: [],
            status: "",
            clearabled: true,
            conditions: [],
            params: {
                invoiceState: [],
            },
        };
    },
    onReady() {
        this.initParams();
    },
    created() {
        // this.source = this.$route.query.source;
    },
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.accidentType = "";
            this.searchValue.name = "";

            this.searchValue.customerName = "";
            this.searchValue.StartDate = "";
            this.searchValue.EndDate = "";
            this.searchValue.orderNo = "";
        },
        search() {
            var conditions = [];
            var str = "";
            if (this.status) {
                let obj = {};
                obj.name = "status";
                obj.operate = "=";
                obj.value = this.status;
                conditions.push(obj);
                // str = this.common.paramsFormat(this.searchValue.status, this.params.status);
            }

            if (this.searchValue.StartDate && this.searchValue.EndDate) {
                let obj = {};
                obj.name = "createDate";
                obj.operate = "like";
                obj.value = [
                    this.searchValue.StartDate,
                    this.searchValue.EndDate,
                ];
                conditions.push(obj);

                str =
                    this.searchValue.StartDate +
                    "至" +
                    this.searchValue.EndDate;
            }

            if (this.searchValue.customerName) {
                let obj = {};
                obj.name = "customerName";
                obj.operate = "like";
                obj.value = this.searchValue.customerName;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.customerName;
                } else {
                    str = str + "," + this.searchValue.customerName;
                }
            }

            if (this.searchValue.orderNo) {
                let obj = {};
                obj.name = "orderNo";
                obj.operate = "like";
                obj.value = this.searchValue.orderNo;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.orderNo;
                } else {
                    str = str + "," + this.searchValue.orderNo;
                }
            }
            this.searchValue.searchResults = str;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: conditions,
                });
            });
        },
        // queryPage() {
        //     this.$refs.eaglePageList.search({
        //         conditions: this.conditions,
        //     });
        // },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_project_contract_invoice_state")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId ==
                                "site_project_contract_invoice_state"
                            ) {
                                _this.params.invoiceState.push(item);
                            }
                        });
                    }
                });
        },

        invalid(item) {
            let _this = this;

            this.$refs.eagleConfirm.showConfirm({
                content: "确定要作废发票吗？？",
                confirm: function () {
                    var url =
                        "site/projectContractInvoice/deleteByOrderCode/" +
                        item.invoiceCode;
                    _this.common.del(url, null).then(function (res) {
                        if (res.code == 200) {
                            _this.$refs.uToast.show({
                                title: "作废成功",
                                type: "success",
                                callback: function () {
                                    _this.search();
                                },
                            });
                        } else {
                            _this.$refs.uToast.show({
                                title: "删除失败：" + res.errMsg,
                                type: "error",
                            });
                        }
                    });
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消作废",
                        type: "error",
                    });
                },
            });
        },

        goto(url) {
            this.base.navigateTo(url);
        },
    },
};
</script>

<style lang="scss">
.m {
    color: #2979ff;
}
</style>
