<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='80' :errorType="errorType" :boolInitData="boolInitData">
            <eagle-container>

                <eagle-text title="可开票金额">{{invoicePrice|twoDecimal}}</eagle-text>
                <!-- <eagle-input :value="invoicePrice|twoDecimal" disabled="" title="可开票金额" prop="invoicePrice" /> -->

                <eagle-input v-model="model.invoicePrice" type="number" :isNumber="true" title="开票金额" prop="invoicePrice" @input="numDxsCheck(model, 2, 'invoicePrice')" required />

                <eagle-date v-model="model.invoiceDate" title="开票日期" prop="invoiceDate" required />

                <eagle-file-upload :maxCount="3" title="发票文件" prop="attachs" v-model="model.attachs" />

                <eagle-input v-model="model.remarks" type="textarea" title="备注" prop="remarks" />
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <popup-project-contract-dts @contractCallBack="contractCallBack" ref="projectContractDts">
        </popup-project-contract-dts>

        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
// popup-project-contract-dts
import PopupProjectContractDts from "../../components/project/projectContractDts/popupProjectContractDts.vue";
export default {
    components: {
        PopupProjectContractDts,
    },
    data() {
        return {
            model: {},
            code: "",
            type: "",
            invoicePrice: "",
            errorType: ["message"],
            control: "site/projectContractInvoice",
            boolInitData: false,
            params: {
                projectPartner: [],
                taxIncluded: [],
                collectionMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.code = this.$route.query.code;
        this.type = this.$route.query.type;
    },
    onReady() {
        var _this = this;
        this.initData();
    },
    mounted() {},
    methods: {
        initCallBack(data) {},

        initData() {
            let _this = this;

            var url =
                "site/projectContractInvoice/initData/" +
                this.code +
                "?type=" +
                this.type;
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    _this.model = res.data;

                    _this.invoicePrice = _this.model.invoicePrice;
                } else {
                }
                uni.hideToast();
            });
        },
        post(op) {
            let _this = this;

            if (_this.model.invoicePrice - _this.invoicePrice > 0) {
                _this.$refs.uToast.show({
                    title: "开票金额不能小于等于可开票金额",
                    type: "error",
                });
                return;
            }

            this.$refs.eagleConfirm.showConfirm({
                content: "确认要提交本次开票?",
                confirm: function () {
                    _this.$refs.eagleForm.post({
                        url: "site/projectContractInvoice/save",
                        model: _this.model,
                        needValid: true,
                        validCallback: function () {
                            return true;
                        },
                        successCallback: function (res) {
                            _this.base.navigateBack();
                        },
                        errorCallback: function (res) {
                            console.log(res);
                        },
                    });
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消",
                        type: "error",
                    });
                },
            });
        },

        numDxsCheck(form, ws, key) {
            let _this = this;

            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },
    },
};
</script>


<style lang="scss">
.detail-block {
    background: #f7f7f7;
}

.customer-block .custom-style {
    background: #fff;
    color: #2979ff;
    font-size: 14px;
    border-width: 0px;
    line-height: 28px;
}

.form-detail {
    border-bottom: 1px solid #ddd;
    margin-bottom: 10px;
    color: $font-color-base;
    line-height: 24px;

    .form-detail-title {
        color: #494a4c;
        line-height: 28px;
    }

    .form-detail-titleOne {
        color: #494a4c;
        line-height: 28px;
        display: flex;
        justify-content: space-between;
    }

    .form-detail-titleOne_button {
        display: flex;
        column-gap: 5px;
    }
}

.center {
    　　text-align: center;
}
.center_text {
    　　display: inline-block;
    　　width: 500px;
}
</style>
