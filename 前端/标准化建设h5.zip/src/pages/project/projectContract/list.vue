<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @reSearch="reSearch" @search="search" placeholder="请输入筛选条件" v-model="searchValue" :searchResults="searchValue.searchResults">
                        <eagle-fast-choose itemWidth="200rpx" v-model="searchValue.serviceCode" title="服务类型" prop="serviceCode" :data-source="params.serviceNameType" v-if="params.serviceNameType.length > 0" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="searchValue.renewStatus" title="续签状态" prop="renewStatus" :data-source="params.renewalStatus" v-if="params.renewalStatus.length > 0" />
                        <eagle-radio-group v-model="searchValue.status" title="合同状态" prop="status" :data-source="params.contractStatus" v-if="params.contractStatus.length > 0" />
                        <eagle-choose-user title="销售人员" :isMult="false" v-model="searchValue.saleUserName" :names.sync="searchValue.saleChnName" prop="saleUserName"></eagle-choose-user>
                        <eagle-select labelWidth="150" v-model="searchValue.filingDate" title="合同日期" prop="filingDate" :data-source="params.year"></eagle-select>
                        <eagle-input title="合同编号" placeholder="请输入合同编号" v-model="searchValue.orderNo" :labelWidth="150">
                        </eagle-input>
                        <eagle-input title="客户名称" placeholder="请输入客户名称" v-model="searchValue.customerName" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/projectContract/view?id=' + item.id)">
                    <template slot="tag">
                        <view v-html="common.bindTag(item.status, params.contractStatus, types.contractTypes)" />
                    </template>
                    <eagle-girdrow-base isTitle>
                        {{ item.orderName }}
                    </eagle-girdrow-base>
                    <view>
                        合同编号：{{ item.orderNo }}
                    </view>
                    <view>
                        <span class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code=' + item.customerCode)">客户名称：{{ item.customerName }}</span>
                    </view>
                    <view>
                        服务类型：{{ item.serviceName }}
                    </view>
                    <view>
                        销售人员：{{ item.saleChnName }}
                    </view>
                    <view>
                        <text>合同时间：{{ item.startDate | dateFormat }} 至 {{ item.endDate | dateFormat }} </text>
                    </view>
                    <template slot="button" v-if="item.status > 0">
                        <u-button type="success" size="mini" @click="goto('/pages/project/projectContract/apply?id=' + item.id)">{{ item.totalPrice ==
                                    item.invoicePrice ? '开票历史' : '开票申请'
                            }}
                        </u-button>
                        <u-button type="primary" size="mini" @click="goto('/pages/project/projectContract/detail?id=' + item.id)">编辑</u-button>
                        <u-button type="primary" size="mini" v-if="item.status >0" @click="showAction(item)">更多
                        </u-button>
                        <!-- <u-button type="error" size="mini" @click="goto('/pages/project/projectContract/invalid?id=' + item.id)" v-if="item.receivePrice == 0 && item.invoicePrice == 0">作废</u-button> -->
                    </template>
                </eagle-row-card>
                <u-action-sheet v-model="actionShow" @close="actionShow = false" :list="actionList" @click="clickSheet" :borderRadius="15" cancelText="取消">
                </u-action-sheet>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick="goto('/pages/project/projectContract/detail?id=0')">
        </eagle-fab>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    onShow() {
        this.search();
    },
    data() {
        return {
            searchValue: {
                serviceCode: "",
                renewStatus: "",
                status: "",
                saleUserName: "",
                saleChnName: "",
                filingDate: "",
                orderNo: "",
                customerName: "",
            },
            controller: "/site/projectContract",
            data: [],
            clearabled: true,
            conditions: [],
            actionShow: false,
            optionItem: {},
            params: {
                renewalStatus: [],
                contractStatus: [],
                serviceNameType: [],
                year: [],
            },
            types: {
                contractTypes: [
                    { id: "10", type: "success" },
                    { id: "-10", type: "danger" },
                    { id: "20", type: "success" },
                ],
            },
            actionList: [
                {
                    text: "作废",
                    name: "disable",
                },
                {
                    text: "标记为已续签",
                    name: "doRenew",
                },
                {
                    text: "不续签",
                    name: "doUnRenew",
                },
            ],
        };
    },
    onReady() {
        this.initParams();
        this.getServiceNameType();
    },
    created() {
        // this.source = this.$route.query.source;
        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.params.year.push({
                id: i,
                name: i,
            });
        }
    },
    methods: {
        showAction(item) {
            let arry = [{ text: "作废", name: "disable" }];
            if (item.isRenewalWarn) {
                if (item.renewStatus == "10") {
                    arry.push({
                        text: "标记为已续签",
                        name: "doRenew",
                    });
                }
                arry.push({
                    text: "不续签",
                    name: "doUnRenew",
                });
            }
            this.actionList = arry;
            this.optionItem = item;
            this.actionShow = true;
        },
        clickSheet(index) {
            let item = this.actionList[index];
            switch (item.name) {
                case "disable":
                    this.disable(this.optionItem);
                    break;
                case "doRenew":
                    this.doRenew(this.optionItem);
                    break;
                case "doUnRenew":
                    this.doUnRenew(this.optionItem);
                    break;
            }
        },
        disable(item) {
            this.goto("/pages/project/projectContract/invalid?id=" + item.id);
        },
        doRenew(item) {
            let _this = this;
            this.common
                .post(`${this.controller}/hasRenew`, { id: item.id })
                .then(function (res) {
                    if (res.success) {
                        _this.$refs.eaglePageList.msgSuccess("续签成功");
                        _this.search();
                    }
                });
        },
        doUnRenew(item) {
            this.goto("/pages/project/projectContract/unRenew?id=" + item.id);
        },
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.serviceCode = "";
            this.searchValue.renewStatus = "";
            this.searchValue.status = "";
            this.searchValue.saleUserName = "";
            this.searchValue.saleChnName = "";
            this.searchValue.filingDate = "";
            this.searchValue.orderNo = "";
            this.searchValue.customerName = "";
        },
        search() {
            // [{"name":"name","operate":"like","value":"123"},
            // {"name":"accidentType","operate":"=","value":"wutidaji"}]
            var conditions = [];
            var str = "";

            if (this.searchValue.serviceCode) {
                let obj = {};
                obj.name = "serviceCode";
                obj.value = this.searchValue.serviceCode;
                obj.operate = "like";
                conditions.push(obj);
                str = this.common.paramsFormat(
                    this.searchValue.serviceCode,
                    this.params.serviceNameType
                );
            }

            if (this.searchValue.renewStatus) {
                let obj = {};
                obj.name = "renewStatus";
                obj.value = this.searchValue.renewStatus;
                obj.operate = "=";
                conditions.push(obj);

                if (str == "") {
                    str = this.common.paramsFormat(
                        this.searchValue.renewStatus,
                        this.params.renewalStatus
                    );
                } else {
                    str =
                        str +
                        "," +
                        this.common.paramsFormat(
                            this.searchValue.renewStatus,
                            this.params.renewalStatus
                        );
                }
            }

            if (this.searchValue.status) {
                let obj = {};
                obj.name = "status";
                obj.value = this.searchValue.status;
                obj.operate = "=";
                conditions.push(obj);

                if (str == "") {
                    str = this.common.paramsFormat(
                        this.searchValue.status,
                        this.params.contractStatus
                    );
                } else {
                    str =
                        str +
                        "," +
                        this.common.paramsFormat(
                            this.searchValue.status,
                            this.params.contractStatus
                        );
                }
            }

            if (this.searchValue.saleUserName) {
                let obj = {};
                obj.name = "saleUserName";
                obj.value = this.searchValue.saleUserName;
                obj.operate = "like";
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.saleChnName;
                } else {
                    str = str + "," + this.searchValue.saleChnName;
                }
            }

            if (this.searchValue.filingDate) {
                let obj = {};
                obj.name = "filingDate";
                obj.value = this.searchValue.filingDate;
                obj.operate = "like";
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.filingDate;
                } else {
                    str = str + "," + this.searchValue.filingDate;
                }
            }

            if (this.searchValue.orderNo) {
                conditions.push({
                    name: "orderNo",
                    value: this.searchValue.orderNo,
                    operate: "like",
                });

                if (str == "") {
                    str = this.searchValue.orderNo;
                } else {
                    str = str + "," + this.searchValue.orderNo;
                }
            }

            if (this.searchValue.customerName) {
                conditions.push({
                    name: "customerName",
                    value: this.searchValue.customerName,
                    operate: "like",
                });
                if (str == "") {
                    str = this.searchValue.customerName;
                } else {
                    str = str + "," + this.searchValue.customerName;
                }
            }

            this.searchValue.searchResults = str;

            this.conditions = conditions;
            this.queryPage();
        },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: this.conditions,
                });
            });
        },
        initParams() {
            var _this = this;

            // site_project_enterprise_scale,
            // site_project_source_type,
            // site_project_customer_track_mode

            this.common
                .getparamsList(
                    "site_project_renewal_status,site_project_contract_status"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_renewal_status") {
                                _this.params.renewalStatus.push(item);
                            }

                            if (
                                item.paramId == "site_project_contract_status"
                            ) {
                                _this.params.contractStatus.push(item);
                            }
                        });
                    }
                });
        },

        getServiceNameType() {
            let _this = this;

            var url = "site/projectServiceType/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    // var array = [];
                    for (let index in res.data) {
                        let data = {
                            id: res.data[index].code,
                            name: res.data[index].serviceName,
                        };
                        _this.params.serviceNameType.push(data);
                    }
                    // = Object.freeze(array);
                } else {
                }
                uni.hideToast();
            });
        },

        imgError(e) {},
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },

        doRenew(row) {
            let _this = this;
            // _this.form.renewStatus = 2;
            let url = "/site/projectContract/getDataByCode/" + row.code;

            _this.common.get(url).then(function (res) {
                let data = res.data;
                console.log(data);
                if (res.code == 200) {
                    data.renewStatus = "20";

                    _this.common
                        .post("/site/projectContract/save", data)
                        .then(function (res) {
                            // _this.msgSuccess("续签成功");

                            _this.$refs.uToast.show({
                                title: "续签成功",
                                type: "success",
                            });

                            _this.queryPage();
                        });
                }
            });
        },
    },
};
</script>
<style lang="scss">
.m {
    color: #2979ff;
}
</style>