<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" :boolInitData="false" ref="eagleForm">
            <eagle-container title="开票申请">
                <view class="form-detail" v-for="(item, index) in model.projectContractDts" :key="index">
                    <strong></strong>
                    <view class="form-detail-title">
                        回款比例(%)：{{item.rate}}
                    </view>
                    <view>
                        应回款金额：{{item.totalPrice|twoDecimal}}
                    </view>
                    <view>
                        已开票金额：{{item.invoicePrice|twoDecimal}}
                    </view>
                    <view>
                        已申请开票金额：{{item.invoiceApplyPrice|twoDecimal}}
                    </view>
                    <view class="form-detail-titleOne">
                        <view>
                            已回款金额：{{item.receivePrice|twoDecimal}}
                        </view>
                        <view class="form-detail-titleOne_button" v-if="(item.totalPrice - item.invoicePrice - item.invoiceApplyPrice) > 0">
                            <u-button type="primary" size="mini" @click="invoiceApply(item)">开票申请</u-button>
                        </view>
                    </view>
                    <view>
                        状态：{{item.receiveStatus|paramsFormat(params.receiveStatus)}}
                    </view>
                    <view>
                        回款期限：{{item.payDate|dateFormat}}
                    </view>
                    <view v-if="item.remarks">
                        备注：{{item.remarks}}
                    </view>
                    <view>
                        <u-line></u-line>
                    </view>

                </view>
            </eagle-container>
            <eagle-container title="开票历史">
                <view class="form-detail" v-for="(item, index) in model.projectInvoiceApply" :key="index">
                    <view class="form-detail-title">
                        申请开票金额：{{item.invoicePrice|twoDecimal}}
                    </view>
                    <view>
                        已开票金额：{{item.realPrice|twoDecimal}}
                    </view>

                    <eagle-row-view type="warn" style="color:#666">
                        申请时间：{{item.createDate|dateFormat}}
                        <template slot="icon" v-if="item.invoicePrice>0&&item.realPrice==0">
                            <u-button type="primary" size="mini" @click="invoiceApplyBack(item)">撤回</u-button>
                        </template>
                    </eagle-row-view>
                    <view>
                        申请人：{{item.createChnName}}
                    </view>
                    <view>
                        <u-line></u-line>
                    </view>

                </view>
            </eagle-container>
            <eagle-container title="开票信息">
                <template slot="otherSolot">
                    <u-button type="primary" style="margin-left:10rpx;" size="mini" @click="goto('/pages/project/projectContract/updateInvoice?id='+model.id)">修改开票信息
                    </u-button>
                </template>

                <eagle-text v-model="model.payeeName" blod label="开票抬头"> </eagle-text>
                <eagle-text v-model="model.taxNumber" blod label="开票税号"> </eagle-text>
                <eagle-text v-model="model.invoiceAdsTel" blod label="开票地址、电话"> </eagle-text>
                <eagle-text v-model="model.bankAccount" blod label="开户行及账号"> </eagle-text>
                <eagle-text label="开票图片">
                    <eagle-display-image v-model="model.invoiceAttach"></eagle-display-image>
                </eagle-text>
                <eagle-text blod label="开票类目">{{model.category|paramsFormat(params.projectCategory)}} </eagle-text>
                <eagle-text v-model="model.invoiceRemark" blod label="开票备注"> </eagle-text>
            </eagle-container>
            <eagle-container title="合同信息">
                <eagle-text v-model="model.orderNo" blod label="合同编号"></eagle-text>
                <eagle-text blod label="合同名称" v-model="model.orderName"></eagle-text>
                <eagle-text v-model="model.customerName" blod label="客户名称"></eagle-text>
                <eagle-text blod label="销售人员" v-model="model.saleChnName"></eagle-text>
                <eagle-text blod label="服务类型" v-model="model.serviceName"></eagle-text>
                <eagle-text blod label="合同金额">
                    {{model.totalPrice|twoDecimal}}
                </eagle-text>
                <eagle-text blod label="已开票金额">
                    {{model.invoicePrice|twoDecimal}}
                </eagle-text>
                <eagle-text blod label="可申请开票金额">
                    {{model.applyInvoicePrice|twoDecimal}}
                </eagle-text>
                <eagle-text blod label="回款方式">
                    {{model.method|paramsFormat(params.collectionMode)}}
                </eagle-text>
                <eagle-text blod label="含税情况">
                    {{model.taxType|paramsFormat(params.taxIncluded)}}
                </eagle-text>
            </eagle-container>

        </eagle-form>

    </view>

</template>
<script>
// import Template from "../../danger/dangerTemplate/template.vue";
export default {
    // components: { Template },
    data() {
        return {
            model: {},
            formInvoiceApply: {},
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                projectPartner: [],
                taxIncluded: [],
                collectionMode: [],
                projectCategory: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
                receiveStatus: [],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
        this.initParams();
        this.getProjectPartnerList();
        this.getProjectCategoryList();
    },
    onShow() {
        setTimeout(() => {
            this.$refs.eagleForm.refresh();
        });
    },
    methods: {
        initCallBack(data) {
            var _this = this;
            //合同的 可申请开票金额, 回款的 已申请开票金额 的计算
            // _this.model.applyInvoicePrice = 0;

            // if (_this.model.projectContractDts) {
            // 	for (let index in _this.model.projectContractDts) {
            // 		let dtsCode = _this.model.projectContractDts[index].code;
            // 		_this.model.projectContractDts[index].invoiceApplyPrice = 0;

            // 		if (_this.model.projectInvoiceApply) {
            // 			for (let indexApply in _this.model.projectInvoiceApply) {
            // 				if (dtsCode === _this.model.projectInvoiceApply[indexApply].mainCode && _this.model
            // 					.projectInvoiceApply[indexApply].status == "10") {
            // 					_this.model.projectContractDts[index].invoiceApplyPrice += _this.model
            // 						.projectInvoiceApply[indexApply].invoicePrice;
            // 				}
            // 			}
            // 		}
            // 		_this.model.applyInvoicePrice += _this.model.projectContractDts[index].totalPrice -
            // 			_this.model.projectContractDts[index].invoicePrice - _this.model.projectContractDts[index]
            // 			.invoiceApplyPrice;
            // 	}

            // 	if (_this.model.applyInvoicePrice < 0) {
            // 	          _this.model.applyInvoicePrice = 0;
            // 	}
            // }

            //合同的 可申请开票金额, 回款的 已申请开票金额 的计算
            _this.model.applyInvoicePrice = 0;

            if (_this.model.projectContractDts) {
                for (let index in _this.model.projectContractDts) {
                    let dtsCode = _this.model.projectContractDts[index].code;
                    _this.model.projectContractDts[index].invoiceApplyPrice = 0;

                    if (_this.model.projectInvoiceApply) {
                        for (let indexApply in _this.model
                            .projectInvoiceApply) {
                            if (
                                dtsCode ===
                                    _this.model.projectInvoiceApply[indexApply]
                                        .mainCode &&
                                _this.model.projectInvoiceApply[indexApply]
                                    .status == "10"
                            ) {
                                _this.model.projectContractDts[
                                    index
                                ].invoiceApplyPrice = parseFloat(
                                    (
                                        _this.model.projectContractDts[index]
                                            .invoiceApplyPrice +
                                        _this.model.projectInvoiceApply[
                                            indexApply
                                        ].invoicePrice
                                    ).toFixed(2)
                                );
                            }
                        }
                    }
                    _this.model.applyInvoicePrice = parseFloat(
                        (
                            _this.model.applyInvoicePrice +
                            _this.model.projectContractDts[index].totalPrice -
                            _this.model.projectContractDts[index].invoicePrice -
                            _this.model.projectContractDts[index]
                                .invoiceApplyPrice
                        ).toFixed(2)
                    );
                }
                if (_this.model.applyInvoicePrice < 0) {
                    _this.model.applyInvoicePrice = 0;
                }
            }
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_project_tax_included,site_project_collection_mode,site_project_contract_dts_receive_status"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_tax_included") {
                                _this.params.taxIncluded.push(item);
                            }
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }

                            if (
                                item.paramId ==
                                "site_project_contract_dts_receive_status"
                            ) {
                                _this.params.receiveStatus.push(item);
                            }
                        });
                    }
                });
        },
        getProjectPartnerList() {
            let _this = this;

            var url = "site/projectPartner/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectPartner.push({
                            code: item.partnerNo,
                            text: item.partnerName,
                        });
                    }
                } else {
                }
                uni.hideToast();
            });
        },
        getProjectCategoryList() {
            let _this = this;

            var url = "site/projectCategory/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectCategory.push({
                            id: item.code,
                            name: item.categoryName,
                        });
                    }
                } else {
                }
                uni.hideToast();
            });
        },

        goto(url) {
            this.base.navigateTo(url);
        },

        invoiceApply(row) {
            if (
                (!this.model.invoiceAttach &&
                    (!this.model.payeeName ||
                        !this.model.taxNumber ||
                        !this.model.invoiceAdsTel ||
                        !this.model.bankAccount)) ||
                !this.model.category
            ) {
                this.$refs.eagleForm.errorMsg(
                    "开票信息或者开票图片至少完善一项，开票类目不能为空"
                );
                return false;
            }
            var invoicePrice =
                row.totalPrice - row.invoicePrice - row.invoiceApplyPrice;
            var invoicePriceDef =
                row.totalPrice - row.invoicePrice - row.invoiceApplyPrice;

            var url =
                "/pages/project/projectContract/applyDetail?id=" +
                this.model.id +
                "&mainCode=" +
                row.code +
                "&orderCode=" +
                row.mainCode +
                "&invoicePrice=" +
                invoicePrice +
                "&invoicePriceDef=" +
                invoicePriceDef +
                "&orderDetailCode=";

            this.base.navigateTo(url);
        },
        invoiceApplyBack(row) {
            let _this = this;
            this.$refs.eagleForm.confirm("是否撤回本次开票申请", function () {
                let url = "site/projectInvoiceApply/delete/" + row.id;
                _this.common.del(url, {}).then((res) => {
                    if (res.code == 200) {
                        _this.$refs.eagleForm.successMsg("撤回成功");
                        _this.$refs.eagleForm.refresh();
                    }
                });
            });
        },
    },
};
</script>

<style lang="scss">
.detail-block {
    background: #f7f7f7;
}

.customer-block .custom-style {
    background: #fff;
    color: #2979ff;
    font-size: 14px;
    border-width: 0px;
    line-height: 28px;
}

.form-detail {
    // border-bottom: 1px solid #ddd;
    // margin-bottom: 10px;
    color: $font-color-base;
    line-height: 24px;
    padding: 0 30rpx;

    .form-detail-title {
        color: #494a4c;
        line-height: 28px;
    }

    .form-detail-titleOne {
        color: #494a4c;
        line-height: 28px;
        display: flex;
        justify-content: space-between;
    }

    .form-detail-titleOne_button {
        display: flex;
        column-gap: 5px;
    }
}

.m {
    margin-right: 5px;
    color: #2979ff;
}

.other-font {
    color: #303133;
    font-size: 32rpx;
}
</style>
