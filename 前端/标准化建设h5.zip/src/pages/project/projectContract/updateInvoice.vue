<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='80' :errorType="errorType">
            <eagle-container title="开票信息">
                <eagle-input v-model="model.payeeName" title="开票抬头" prop="payeeName" />
                <eagle-input v-model="model.taxNumber" title="开票稅号" prop="taxNumber" />
                <eagle-input v-model="model.invoiceAdsTel" title="开票地址、电话" prop="invoiceAdsTel" />
                <eagle-input v-model="model.bankAccount" title="开户行及账号" prop="bankAccount" />
                <eagle-upload :maxCount="3" title="开票图片" prop="invoiceAttach" v-model="model.invoiceAttach" />
                <eagle-select labelWidth="150" v-model="model.category" title="开票类目" prop="category" idField="code" textField="text" :data-source="params.projectCategory" required v-if="params.projectCategory.length>0" />
                <eagle-input v-model="model.invoiceRemark" type="textarea" title="开票备注" prop="invoiceRemark" />
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            orderNo: "",
            orderNo1: "", //页面显示
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                projectCategory: [],
                projectPartner: [],
                taxIncluded: [],
                collectionMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {},

    onShow() {
        var _this = this;
        _this.getProjectCategoryList();
    },

    mounted() {},
    methods: {
        initCallBack(data) {},

        getProjectCategoryList() {
            let _this = this;

            var url = "site/projectCategory/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectCategory.push({
                            code: item.code,
                            text: item.categoryName,
                        });
                    }
                } else {
                }
                uni.hideToast();
            });
        },
        post(op) {
            let _this = this;

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

<style lang="scss">
.detail-block {
    background: #f7f7f7;
}

.customer-block .custom-style {
    background: #fff;
    color: #2979ff;
    font-size: 14px;
    border-width: 0px;
    line-height: 28px;
}

.form-detail {
    border-bottom: 1px solid #ddd;
    margin-bottom: 10px;
    color: $font-color-base;
    line-height: 24px;

    .form-detail-title {
        color: #494a4c;
        line-height: 28px;
    }

    .form-detail-titleOne {
        color: #494a4c;
        line-height: 28px;
        display: flex;
        justify-content: space-between;
    }

    .form-detail-titleOne_button {
        display: flex;
        column-gap: 5px;
    }
}
</style>
