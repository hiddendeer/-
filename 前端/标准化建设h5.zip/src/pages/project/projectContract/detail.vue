<template>
    <view class="project-contract-detail">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='50' :initUrl="initUrl" selfHeight='calc(100vh - 125px)'>
            <eagle-container>
                <eagle-input required v-model="model.orderNo" title="合同编号" prop="orderNo" />
                <!-- <eagle-text title="合同编号">
                    {{orderNo1}}
                </eagle-text> -->
                <eagle-choose-customer title="意向订单" headTitle="请选择意向订单" v-model="model.intentionOrderCode" customer="intentionOrder" :names.sync="model.intentionOrderName" :required="false" showDetail="true" controller="site/projectIntentionOrder" idField="code" textField="orderno" @callBackChoosedData="selectIntentionOrder"></eagle-choose-customer>

                <eagle-window-choose title="合同单位" required headTitle="请选择合作单位" v-model="model.partnerCode" :names.sync="model.partnerName" showDetail="true" controller="site/projectPartner" idField="partnerName" textField="partnerName" @callBackChoosedData="choosePartner">
                </eagle-window-choose>

                <!-- <eagle-window-choose title="合作区域" headTitle="请选择合作区域" v-model="model.areaName"   :names.sync="model.areaName" :required="false" showDetail="true" controller="site/projectArea" idField="areaName" textField="areaName"></eagle-window-choose> -->

                <eagle-window-choose title="客户" headTitle="请选择客户" v-model="model.customerCode" :names.sync="model.customerName" showDetail="true" controller="site/projectCustomer" dataType="myCustomerList" idField="code" textField="name" :required="true" @callBackChoosedData="chooseCustomer"></eagle-window-choose>

                <eagle-date v-model="model.filingDate" title="合同日期" prop="filingDate" required />
                <eagle-choose-user v-model="model.saleUserName" title="销售人员" :names.sync="model.saleChnName" prop="shareUserName" required></eagle-choose-user>

                <eagle-window-choose title="服务类型" headTitle="请选择服务类型" v-model="model.serviceCode" isMult :names.sync="model.serviceName" :required="true" showDetail="true" controller="site/projectServiceType" idField="code" textField="serviceName" @callBackChoosedData="chooseService"></eagle-window-choose>

                <eagle-input v-model="model.orderRemarks" type="textarea" title="项目说明" prop="orderRemarks" />

                <eagle-input v-model="model.orderName" title="合同名称" prop="orderName" required />
                <eagle-input v-model="model.projectContact" title="客户对接人" prop="projectContact" required />

                <eagle-input v-model="model.projectMobile" title="联系方式" prop="projectMobile" required />

                <eagle-date type="daterange" :startDate.sync="model.startDate" :endDate.sync="model.endDate" title="开始/结束时间" prop="startsDate" :height="70" required></eagle-date>

                <eagle-input v-model="model.totalPrice" type="number" :isNumber="true" required title="合同金额" prop="totalPrice" @input="numDxsCheck(model, 2, 'totalPrice')" />
                <eagle-checkbox-group v-model="isRenewalWarn1" title="是否续签提醒" prop="isRenewalWarn1" :data-source="params.Public" />
                <eagle-checkbox-group v-model="model.projectGenerate1" title="是否生成项目" prop="projectGenerate1" :data-source="params.Public" :disabled="disabled" />
                <eagle-file-upload :maxCount="3" title="合同文件" prop="attachs" v-model="model.attachs" />
                <eagle-file-upload :maxCount="3" title="项目方案或报价" prop="programmeAttachs" v-model="model.programmeAttachs" />
                <eagle-file-upload :maxCount="3" title="其他附件" prop="otherAttachs" v-model="model.otherAttachs" />
            </eagle-container>

            <eagle-container>
                <template slot="title">
                    开票信息
                </template>
                <eagle-radio-group v-model="model.taxType" title="含税情况" prop="taxType" :data-source="params.taxIncluded" v-if="params.taxIncluded.length > 0" required />
                <eagle-radio-group v-model="model.method" title="回款方式" prop="method" :data-source="params.collectionMode" v-if="params.collectionMode.length > 0" required />

                <eagle-input v-model="model.payeeName" title="开票抬头" prop="payeeName" />
                <eagle-input v-model="model.taxNumber" title="开票稅号" prop="taxNumber" />
                <eagle-input v-model="model.invoiceAdsTel" title="开票地址、电话" prop="invoiceAdsTel" />
                <eagle-input v-model="model.bankAccount" title="开户行及账号" prop="bankAccount" />
                <eagle-window-choose title="开票类目" headTitle="请选择开票类目" v-model="model.category" :isMult="false" :names.sync="model.categoryName" showDetail="true" controller="site/projectCategory" idField="code" textField="categoryName"></eagle-window-choose>

                <eagle-upload :maxCount="3" title="开票图片" prop="invoiceAttach" v-model="model.invoiceAttach" />

                <eagle-input v-model="model.invoiceRemark" type="textarea" title="开票备注" prop="invoiceRemark" />
            </eagle-container>

            <eagle-container title="回款设置">
                <template slot="otherSolot">
                    <u-button type="primary" size="mini" @click="addContract">添加回款设置
                    </u-button>
                </template>
                <eagle-item-kong :isItem="model.projectContractDts"></eagle-item-kong>
                <view class="form-detail" v-for="(item, index) in model.projectContractDts" :key="index">

                    <view class="form-detail-title">
                        回款比例(%)：{{ item.rate }}
                    </view>
                    <view class="form-detail-titleOne">
                        <view>
                            应回款金额：{{ item.totalPrice }}
                        </view>
                        <view class="form-detail-titleOne_button">
                            <u-button type="primary" size="mini" @click="updateContract(item, index)">修改</u-button>
                            <!-- <eagle-icon name="edit-pen" size="20px" @click="updateContract(item, index)">修改
                            </eagle-icon> -->
                            <u-button type="error" size="mini" @click="deleteContract(item, index)">删除</u-button>
                            <!-- <eagle-icon name="trash" size="20px" @click="deleteContract(item, index)">删除</eagle-icon> -->
                        </view>
                    </view>
                    <view>
                        回款期限：{{ item.payDate | dateFormat }}
                    </view>
                    <view v-if="item.remarks">
                        备注：{{ item.remarks }}
                    </view>
                    <view>
                        <u-line></u-line>
                    </view>

                </view>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <popup-project-contract-dts @contractCallBack="contractCallBack" ref="projectContractDts">
        </popup-project-contract-dts>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
import EagleText from "../../../components/eagle-text/eagle-text.vue";
// popup-project-contract-dts
import PopupProjectContractDts from "../../components/project/projectContractDts/popupProjectContractDts.vue";
export default {
    components: {
        PopupProjectContractDts,
        EagleText,
    },
    data() {
        return {
            model: {
                orderNo: "",
                projectContractDts: [],
            },
            isRenewalWarn1: "",
            orderNo: "",
            code: "",
            orderNo1: "", //页面显示
            disabled: false,
            initUrl: "",
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                projectCategory: [],
                projectPartner: [],
                taxIncluded: [],
                collectionMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;

        this.initUrl = "site/projectContract/initData/0";
        if (this.$route.query.orderNo) {
            this.orderNo = this.$route.query.orderNo;
        }

        if (this.$route.query.code) {
            this.code = this.$route.query.code;

            this.initUrl =
                "site/projectContract/initData/0?intentionOrderCode=" +
                this.code;
        }

        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增合同订单",
            });
        } else {
        }
    },
    onReady() {
        var _this = this;
        _this.initParams();
        _this.getProjectPartnerList();
        _this.getProjectCategoryList();
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            this.model = data;
            // this.orderNo1 = this.model.orderNo;
            if (this.model.isRenewalWarn) {
                this.isRenewalWarn1 = "1";
            } else {
                this.isRenewalWarn1 = "0";
            }

            if (this.model.projectGenerate) {
                this.model.projectGenerate1 = "1";
            } else {
                this.model.projectGenerate1 = "0";
            }

            if (this.model.id == 0) {
                //新增默认
                this.model.projectGenerate1 = "1";
                if (this.params.taxIncluded.length > 0) {
                    this.model.taxType = this.params.taxIncluded[0].id;
                }
                if (this.params.collectionMode.length > 0) {
                    this.model.method = this.params.collectionMode[0].id;
                }
            } else {
                if (this.model.projectGenerate) {
                    this.disabled = true;
                }
            }
        },
        //选择服务类型回调
        chooseService(chooseData) {
            this.isRenewalWarn1 = "1";

            for (let i = 0; i < chooseData.length; i++) {
                let item = chooseData[i];

                if (item.isRenewalWarn) {
                    this.isRenewalWarn1 = "1";
                }
            }
            this.initOrderName();
        },

        changeStartDate(date) {
            let tempDate = new Date(date);
            tempDate.setFullYear(tempDate.getFullYear() + 1);
            tempDate.setDate(tempDate.getDate() - 1);
            this.model.endDate =
                tempDate.getFullYear() +
                "-" +
                (tempDate.getMonth() + 1) +
                "-" +
                tempDate.getDate();
        },

        // selectPartner(defaultValue, selectObj) {
        //     debugger;
        //     for (let i = 0; i < this.params.projectPartner.length; i++) {
        //         var item = this.params.projectPartner[i];

        //         if (item.code == defaultValue) {
        //             this.orderNo1 =
        //                 item.partnerNo +
        //                 "-" +
        //                 this.model.orderNo.slice(
        //                     this.form.orderNo.indexOf("-")
        //                 );
        //         }
        //     }
        // },

        selectIntentionOrder(chooseData) {
            if (chooseData.length > 0) {
                let item = chooseData[0];

                this.model.serviceCode = item.serviceCode;
                this.model.serviceName = item.serviceName;
                // "serviceCode":"06a5597b34f042f396fdce6bd174bcd2",
                // 			"serviceName":"法律法规服务",

                if (item.customerCode != this.model.customerCode) {
                    this.getCustomerByCode(item.customerCode);
                }
                this.initOrderName();
            }
        },

        chooseCustomer(chooseData) {
            if (chooseData.length > 0) {
                let item = chooseData[0];

                this.model.payeeName = item.payeeName;
                this.model.taxNumber = item.taxNumber;
                this.model.invoiceAdsTel = item.invoiceAdsTel;
                this.model.bankAccount = item.bankAccount;

                if (item.projectCustomerUsers.length) {
                    let contact = item.projectCustomerUsers[0];
                    this.model.projectContact = contact.contact;
                    this.model.projectMobile = contact.mobile;
                }

                this.initOrderName();
            }
        },
        choosePartner(callbackData) {
            if (callbackData) {
                //因为页面初始化的时候 this.model.orderNo默认的加上了对应单位的前缀，所以重新赋值的时候把第一个“-”之前的截取掉，重新拼装成新的合同编号
                // this.orderNo1 =
                //     callbackData[0].partnerNo +
                //     "-" +
                //     this.model.orderNo.substring(
                //         this.model.orderNo.indexOf("-") + 1,
                //         this.model.orderNo.length
                //     );
                this.model.orderNo =
                    callbackData[0].partnerNo +
                    this.model.orderNo.slice(this.model.orderNo.indexOf("-"));
            }
        },
        initOrderName() {
            if (this.model.customerName && this.model.serviceName) {
                this.model.orderName =
                    this.model.customerName + "-" + this.model.serviceName;
            }
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_project_tax_included,site_project_collection_mode"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_tax_included") {
                                _this.params.taxIncluded.push(item);
                            }
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }
                        });

                        if (_this.model.id == 0) {
                            //新增默认

                            if (_this.params.taxIncluded.length > 0) {
                                _this.model.taxType =
                                    _this.params.taxIncluded[0].id;
                            }

                            if (_this.params.collectionMode.length > 0) {
                                _this.model.method =
                                    _this.params.collectionMode[0].id;
                            }
                        }
                    }
                });
        },

        getCustomerByCode(code) {
            let _this = this;

            var url = "site/projectCustomer/getDataByCode/" + code;
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    var item = res.data;
                    _this.model.payeeName = item.payeeName;
                    _this.model.taxNumber = item.taxNumber;
                    _this.model.invoiceAdsTel = item.invoiceAdsTel;
                    _this.model.bankAccount = item.bankAccount;
                    _this.model.saleChnName = item.saleChnName;
                    _this.model.saleUserName = item.saleUserName;
                    _this.model.customerName = item.name;
                    _this.model.customerCode = item.code;

                    if (item.projectCustomerUsers.length) {
                        let contact = item.projectCustomerUsers[0];
                        _this.model.projectContact = contact.contact;
                        _this.model.projectMobile = contact.mobile;
                    }
                } else {
                }
                uni.hideToast();
            });
        },
        initorderName() {
            if (this.model.customerName && this.model.serviceName)
                this.model.orderName =
                    this.model.customerName + "-" + this.model.serviceName;
        },

        getProjectCategoryList() {
            let _this = this;

            var url = "site/projectCategory/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectCategory.push({
                            code: item.code,
                            text: item.categoryName,
                        });

                        if (item.isDefault) {
                            _this.model.category = item.code;
                            _this.model.categoryName = item.categoryName;
                        }
                    }

                    // // 开票类目初始选择
                    //         for (let index in _this.params.categoryName) {
                    //           if (_this.params.categoryName[index].isDefault) {
                    //             _this.form.category = _this.params.categoryName[index].id;
                    //             _this.form.categoryName = _this.params.categoryName[index].name;
                    //           }
                    //         }
                } else {
                }
                uni.hideToast();
            });
        },

        getProjectPartnerList() {
            let _this = this;

            var url = "site/projectPartner/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectPartner.push({
                            code: item.code,
                            text: item.partnerName,
                            partnerNo: item.partnerNo,
                        });
                    }
                } else {
                }
                uni.hideToast();
            });
        },

        post(op) {
            let _this = this;
            if (
                this.model.projectContractDts.length <= 0 &&
                this.model.totalPrice > 0
            ) {
                this.$refs.uToast.show({
                    title: "请添加回款设置",
                    type: "error",
                });
                return;
            }

            let totalPriceDts = 0;
            if (this.model.projectContractDts) {
                for (let index in this.model.projectContractDts) {
                    if (this.model.projectContractDts[index].totalPrice) {
                        totalPriceDts =
                            totalPriceDts +
                            parseFloat(
                                this.model.projectContractDts[index].totalPrice
                            );
                    }
                }
            }
            if (totalPriceDts != this.model.totalPrice) {
                this.$refs.uToast.show({
                    title: "应回款总金额必须等于合同金额",
                    type: "error",
                });
                return;
            }

            if (this.isRenewalWarn1 == "1") {
                this.model.isRenewalWarn = true;
                this.model.renewStatus = "10";
            } else {
                this.model.isRenewalWarn = false;
                this.model.renewStatus = "5";
            }

            if (this.model.projectGenerate1 == "1") {
                this.model.projectGenerate = true;
            } else {
                this.model.projectGenerate = false;
            }

            // this.model.orderNo = this.orderNo1;

            if (this.model.partnerCode != "") {
                for (var i = 0; i < this.params.projectPartner.length; i++) {
                    var item = this.params.projectPartner[i];
                    if (item.code == this.model.partnerCode) {
                        this.model.partnerName = item.text;
                        break;
                    }
                }
            }

            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },

        addContract() {
            if (
                this.model.totalPrice == "" ||
                this.model.totalPrice == "0" ||
                this.model.totalPrice == 0
            ) {
                this.$refs.uToast.show({
                    title: "请输入合同金额",
                    type: "error",
                });
                return;
            }
            setTimeout(() => {
                this.$refs.projectContractDts.show(
                    null,
                    null,
                    this.model.totalPrice
                );
                // this.showCustomerUser = true;
            });
        },

        contractCallBack(data) {
            var dataUser = {};
            dataUser = this.utils.deepMerge(data, dataUser);
            if (dataUser.index != null) {
                this.model.projectContractDts[dataUser.index].rate =
                    dataUser.rate;
                this.model.projectContractDts[dataUser.index].totalPrice =
                    dataUser.totalPrice;
                this.model.projectContractDts[dataUser.index].payDate =
                    dataUser.payDate;
                this.model.projectContractDts[dataUser.index].remarks =
                    dataUser.remarks;
            } else {
                this.model.projectContractDts.push(dataUser);
            }
        },
        deleteContract(item, index) {
            var _this = this;
            uni.showModal({
                title: "提示",
                content: "您确定要删除这条回款设置吗？",
                success: (res) => {
                    if (res.confirm) {
                        _this.model.projectContractDts.splice(index, 1);
                    }
                },
            });
        },
        updateContract(item, index) {
            var _this = this;
            setTimeout(() => {
                this.$refs.projectContractDts.show(
                    item,
                    index,
                    this.model.totalPrice
                );
            });
        },

        numDxsCheck(form, ws, key) {
            let _this = this;

            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.project-contract-detail {
    .detail-block {
        background: #f7f7f7;
    }

    .data-text {
        width: 10%;
        text-align: center;
        padding-top: 40px;
        background-color: #ffffff;
    }

    .customer-block .custom-style {
        background: #fff;
        color: #2979ff;
        font-size: 14px;
        border-width: 0px;
        line-height: 28px;
    }

    .form-detail {
        // border-bottom: 1px solid #ddd;
        // margin-bottom: 10px;
        color: $font-color-base;
        line-height: 24px;
        padding: 0 30rpx;

        .form-detail-title {
            color: #494a4c;
            line-height: 28px;
        }

        .form-detail-titleOne {
            color: #494a4c;
            line-height: 28px;
            display: flex;
            justify-content: space-between;
        }

        .form-detail-titleOne_button {
            display: flex;
            column-gap: 5px;
        }
    }

    .m {
        margin-right: 5px;
        color: #2979ff;
    }

    .other-font {
        color: #303133;
        font-size: 32rpx;
    }

    .m-button {
        margin-right: 5px;
        color: #2979ff;
        // line-height: 70rpx;
    }
}
</style>
