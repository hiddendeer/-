<template>
    <view>
        <eagle-form :autoCreate="false" saveFunName="disableRenew" :control="control" v-model="model" ref="eagleForm">
            <eagle-input v-model="model.unRenewRemarks" type="textarea" title="不续签说明" prop="unRenewRemarks" required>
            </eagle-input>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {
                id: 0,
                unRenewRemarks: "",
            },
            control: "site/projectContract",
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {
        var _this = this;
    },
    mounted() {},
    methods: {
        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    if (res.success) {
                        _this.$refs.eagleForm.successMsg("操作成功");
                        _this.base.navigateBack();
                    }
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
