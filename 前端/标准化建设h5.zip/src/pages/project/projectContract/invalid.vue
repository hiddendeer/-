<template>
    <view>
        <eagle-form :autoCreate="false" saveFunName="disableContract" :control="control" v-model="model" ref="eagleForm">
            <eagle-container>
                <eagle-input type="textarea" v-model="model.disableRemarks" title="作废说明" prop="disableRemarks" required />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {
                id: 0,
                disableRemarks: "",
            },
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {},
    mounted() {},
    methods: {
        initCallBack(data) {},

        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
