<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType">
            <eagle-file-upload :maxCount="3" title="合同文件" prop="attachs" v-model="model.attachs" />

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {
        var _this = this;
    },
    mounted() {},
    methods: {
        initCallBack(data) {},

        post(op) {
            let _this = this;

            if (this.model.attachs == "") {
                this.$refs.uToast.show({
                    title: "请上传合同文件",
                    type: "error",
                });

                return;
            }

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
