<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :errorType="errorType">
            <eagle-container>
                <template slot="title">
                    合同信息
                </template>

                <eagle-text v-model="model.orderNo" blod label="合同编号"></eagle-text>
                <eagle-text blod label="合同名称" v-model="model.orderName"></eagle-text>
                <eagle-text v-model="model.intentionOrderName" blod label="意向订单编号"></eagle-text>
                <eagle-text v-model="model.partnerName" blod label="合同单位"></eagle-text>
                <eagle-text v-model="model.customerName" blod label="客户"></eagle-text>
                <eagle-text blod label="合同金额">
                    {{model.totalPrice|twoDecimal}}
                </eagle-text>
                <eagle-text blod label="合同时间">
                    {{model.startDate|dateFormat}}至 {{model.endDate|dateFormat}}
                </eagle-text>
                <eagle-text blod label="是否续签提醒">
                    {{model.isRenewalWarn==true?'是':'否'}}
                </eagle-text>
                <eagle-text blod label="是否生成项目">
                    {{model.projectGenerate==true?'是':'否'}}
                </eagle-text>
                <eagle-text blod label="销售人员" v-model="model.saleChnName"></eagle-text>
                <eagle-text blod label="服务类型" v-model="model.serviceName"></eagle-text>
                <eagle-text blod label="客户对接人" v-model="model.projectContact"></eagle-text>
                <eagle-text blod label="联系方式" v-model="model.projectMobile"></eagle-text>
                <eagle-text blod label="项目说明" v-model="model.orderRemarks"></eagle-text>
                <eagle-text blod label="合同日期">
                    {{model.filingDate|dateFormat}}
                </eagle-text>
                <eagle-text blod label="合同文件">
                    <eagle-file-upload disabled prop="attachs" v-model="model.attachs" />
                </eagle-text>
                <eagle-text blod label="项目方案或报价">
                    <eagle-file-upload disabled prop="programmeAttachs" v-model="model.programmeAttachs" />
                </eagle-text>
                <!-- </eagle-text>
                <eagle-text blod label="其他附件"> -->
                <eagle-text blod label="其他附件">
                    <eagle-file-upload disabled prop="otherAttachs" v-model="model.otherAttachs" />
                </eagle-text>
                <eagle-text blod label="含税情况">
                    {{model.taxType|paramsFormat(params.taxIncluded)}}
                </eagle-text>
                <eagle-text blod label="回款方式">
                    {{model.method|paramsFormat(params.collectionMode)}}
                </eagle-text>
            </eagle-container>

            <eagle-container>
                <template slot="title">
                    开票信息
                </template>

                <eagle-text v-model="model.payeeName" blod label="开票抬头"> </eagle-text>
                <eagle-text v-model="model.taxNumber" blod label="开票税号"> </eagle-text>
                <eagle-text v-model="model.invoiceAdsTel" blod label="开票地址、电话"> </eagle-text>
                <eagle-text v-model="model.bankAccount" blod label="开户行及账号"> </eagle-text>
                <eagle-display-image title="开票图片" v-model="model.invoiceAttach"></eagle-display-image>
                <eagle-text blod label="开票类目">{{model.category|paramsFormat(params.projectCategory)}} </eagle-text>
                <eagle-text v-model="model.invoiceRemark" blod label="开票备注"> </eagle-text>
            </eagle-container>
            <eagle-container>
                <template slot="title">
                    回款信息
                </template>

                <view class="form-detail" v-for="(item, index) in model.projectContractDts" :key="item.id">
                    <view class="form-detail-title">
                        回款比例(%)：{{item.rate}}
                    </view>
                    <view>
                        应回款金额：{{item.totalPrice|twoDecimal}}
                    </view>
                    <view>
                        已开票金额：{{item.invoicePrice|twoDecimal}}
                    </view>
                    <view>
                        已回款金额：{{item.receivePrice|twoDecimal}}
                    </view>

                    <view>
                        回款期限:{{item.payDate|dateFormat}}
                    </view>
                    <view>
                        状态：{{item.receiveStatus|paramsFormat(params.receiveStatus)}}
                    </view>
                    <view v-if="item.remarks">
                        备注:{{item.remarks}}
                    </view>
                    <view>
                        <u-line></u-line>
                    </view>
                </view>
            </eagle-container>
        </eagle-form>

    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                projectPartner: [],
                taxIncluded: [],
                collectionMode: [],
                receiveStatus: [],
                projectCategory: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;

        this.model.isApply = this.$route.query.isApply;
        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增合同订单",
            });
        }
    },
    onReady() {
        var _this = this;
        _this.initParams();
        _this.getProjectCategoryList();
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            this.getProjectPartnerList();
            if (this.model.isRenewalWarn) {
                this.model.isRenewalWarn = "1";
            } else {
                this.model.isRenewalWarn = "0";
            }

            if (this.model.projectGenerate) {
                this.model.projectGenerate = "1";
            } else {
                this.model.projectGenerate = "0";
            }
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_project_tax_included,site_project_collection_mode,site_project_contract_dts_receive_status"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_tax_included") {
                                _this.params.taxIncluded.push(item);
                            }
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }
                            if (
                                item.paramId ==
                                "site_project_contract_dts_receive_status"
                            ) {
                                _this.params.receiveStatus.push(item);
                            }
                        });
                    }
                });
        },
        getProjectCategoryList() {
            let _this = this;

            var url = "site/projectCategory/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectCategory.push({
                            id: item.code,
                            name: item.categoryName,
                        });
                    }
                } else {
                }
                uni.hideToast();
            });
        },
        getProjectPartnerList() {
            let _this = this;

            var url = "site/projectPartner/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];

                        if (_this.model.partnerCode == item.code) {
                            _this.model.partnerName = item.partnerName;
                        }
                        // _this.params.projectPartner.push({
                        // 	code: item.partnerNo,
                        // 	text: item.partnerName
                        // });
                    }
                } else {
                }
                uni.hideToast();
            });
        },
    },
};
</script>

<style lang="scss">
.detail-block {
    background: #f7f7f7;
}
.data-text {
    width: 10%;
    text-align: center;
    padding-top: 32px;
    background-color: #ffffff;
}
.customer-block .custom-style {
    background: #fff;
    color: #2979ff;
    font-size: 14px;
    border-width: 0px;
    line-height: 28px;
}

.form-detail {
    // border-bottom: 1px solid #ddd;
    // margin-bottom: 10px;
    padding: 0 30rpx;
    color: $font-color-base;
    line-height: 24px;
    padding: 0 30rpx;

    .form-detail-title {
        color: #494a4c;
        line-height: 28px;
    }

    .form-detail-titleOne {
        color: #494a4c;
        line-height: 28px;
        display: flex;
        justify-content: space-between;
    }

    .form-detail-titleOne_button {
        display: flex;
        column-gap: 5px;
    }
}

.m {
    margin-right: 5px;
    color: #2979ff;
}

.other-font {
    color: #303133;
    font-size: 32rpx;
}
</style>
