<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='50' :errorType="errorType" :boolInitData="boolInitData">
            <eagle-container>
                <eagle-text :value="invoicePrice|twoDecimal" title="可申请开票金额" prop="invoicePrice"></eagle-text>
            </eagle-container>
            <eagle-container>
                <eagle-input v-model="model.invoicePrice" type="number" :isNumber='true' title="申请开票金额" required prop="invoicePrice" @input="numDxsCheck(model, 2, 'invoicePrice')" clearable />
                <eagle-input v-model="model.remarks" title="备注" prop="remarks" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {
                invoicePrice: "",
            },
            boolInitData: false,
            invoicePrice: "",
            errorType: ["message"],
            control: "site/projectInvoiceApply",
            params: {
                equStatus: [],
                planType: [],
            },
        };
    },
    created() {
        let _this = this;
        // this.model.id = this.$route.query.id;
        this.model.mainCode = this.$route.query.mainCode;
        this.model.orderCode = this.$route.query.orderCode;
        this.model.invoicePrice = this.$route.query.invoicePrice;
        this.model.invoicePriceDef = this.$route.query.invoicePriceDef;
        this.model.orderDetailCode = this.$route.query.orderDetailCode;
        this.invoicePrice = this.$route.query.invoicePrice;
    },
    onReady() {
        var _this = this;
    },
    mounted() {},
    methods: {
        initCallBack(data) {},
        initParams() {
            var _this = this;

            this.common.getparamsList("site_plan_type").then(function (res) {
                if (res.code == 200 && res.data) {
                    res.data.forEach(function (item) {
                        if (item.paramId == "site_plan_type") {
                            _this.params.planType.push(item);
                        }
                        // if(item.paramId=="equ_status")
                        // {
                        // 	_this.params.equStatus.push(item);
                        // }
                        // else if(item.paramId=="equipment_type_simple")
                        // {
                        // 	_this.params.equipmentType.push(item);
                        // }
                    });
                }
            });
        },
        post(op) {
            let _this = this;

            if (this.model.invoicePrice == "") {
                this.$refs.uToast.show({
                    title: "请输入申请开票金额",
                    type: "error",
                });
                return;
            }

            if (this.model.invoicePrice <= 0) {
                this.$refs.uToast.show({
                    title: "申请开票金额要大于0",
                    type: "error",
                });
                return;
            }

            if (_this.model.invoicePrice > _this.invoicePrice) {
                this.$refs.uToast.show({
                    title: "申请开票金额不能大于可申请开票金额",
                    type: "error",
                });
                return;
            }

            _this.model.id = "";
            _this.model.code = "";

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },

        numDxsCheck(form, ws, key) {
            let _this = this;

            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },

        checkPrice: function (e) {
            // let a  = parseFloat(e);
            // this.model.invoicePrice = a.toFixed(2);
            // console.log(this.model.invoicePrice)
            let that = this;
            let price = parseFloat(e);
            let maxLength = price.indexOf(".");

            // let value = e.match(/^\d*(\.?\d{0,2})/g)[0] || null;
            //重新赋值给input
            // this.$nextTick(() => {
            //   this.info.price = e.target.value;
            // });

            let price1 = price.match(/^\d*(\.?\d{0,2})/g)[0] || null;

            if (price.indexOf(".") < 0 && price != "") {
                //'超过4位则大于1万元'
                // if (price.length > 4) {
                // 	price = price.substring(0, price.length - 1)
                // 	uni.showToast({
                // 		title: '金额最高不能超过1万元',
                // 		icon: 'none'
                // 	})
                // } else {
                // 	price = parseFloat(price);
                // }
                // this.model.invoicePrice = parseFloat(price);
            } else if (price.indexOf(".") == 0) {
                //'首位小数点情况'
                price = price.replace(/[^$#$]/g, "0.");
                price = price.replace(/\.{2,}/g, ".");
            } else if (!/^(\d?)+(\.\d{0,2})?$/.test(price)) {
                //去掉最后一位
                price = price.substring(0, price.length - 1);
            }

            console.log(price);
            console.log(price1);
            // that.$nextTick(function() {
            // 	//'有小数点时，最大长度为7位，没有则是5位'

            // 	// that.currentPrice = price

            // 	this.model.invoicePrice = price;
            // 	// parseFloat(price);
            // })
        },
    },
};
</script>
