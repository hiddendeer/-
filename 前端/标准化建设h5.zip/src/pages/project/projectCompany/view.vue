<template>
    <view class="">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :errorType="errorType" labelWidth="130">
            <eagle-container title="项目单位详情">
                <eagle-text v-model="model.name" title="公司名称" prop="name">
                </eagle-text>
                <eagle-text v-model="model.organizationCode" title="统一社会信用代码" prop="organizationCode">
                </eagle-text>
                <eagle-text v-model="model.applyProfessionName" title="所属行业" labelWidth="130"></eagle-text>

                <eagle-text v-model="model.area" title="地区" labelWidth="130"></eagle-text>
                <eagle-text v-model="model.companySname" title="公司简称" prop="companySname">
                </eagle-text>
                <eagle-text v-model="model.principal" title="公司负责人" prop="principal">
                </eagle-text>
                <eagle-text v-model="model.phone" title="公司电话" prop="phone">
                </eagle-text>
                <eagle-text v-model="model.address" title="公司详细地址" prop="address">
                </eagle-text>
                <eagle-text v-model="model.introduce" title="公司简介" prop="introduce">
                </eagle-text>
            </eagle-container>
        </eagle-form>

    </view>
</template>

<script>
export default {
    name: "eagle-company-form-view",
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "system/company",
            companyCode: "",
            type: "",
            params: {
                ProjectBuildStructureArray: [],
                buildRegulatoryfocusArray: [],
            },
            deletable: true,
            regionShow: false,
        };
    },
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        industryInformation(val) {
            (this.model.applyProfessionName = val.industryName),
                (this.model.applyProfessionCodes = val.industryIap);
        },

        buttonFastSearch() {
            var _this = this;
            if (_this.model.name) {
                _this.common
                    .get(
                        "/site/projectCustomer/getDataFromGuanguanTyByName/" +
                            _this.model.name
                    )
                    .then((res) => {
                        if (res.code == 200 && res.data) {
                            _this.model.organizationCode =
                                res.data.organizationCode;
                            _this.model.address = res.data.address;
                            _this.model.legalPerson = res.data.legalPerson;
                            _this.model.natureOfBusiness =
                                res.data.natureOfBusiness;
                            _this.model.taxNumber = res.data.organizationCode;
                        }
                    });
            } else {
                this.$refs.eagleForm.errorMsg("请输入完整公司名称");
            }
        },

        confirm(e) {
            if (e.city.label === "市辖区") {
                this.model.area = e.province.label + "/" + e.area.label;
            } else if (e.province.label === "全国") {
                this.model.area = "全国";
            } else {
                this.model.area =
                    e.province.label + "/" + e.city.label + "/" + e.area.label;
            }
        },
        post() {
            let _this = this;

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

<style lang="scss">
.div_buttonFastSearch {
    display: block;
    color: rgb(41, 121, 255);
}
</style>
