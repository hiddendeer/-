<template>
	<view class="serve-card-container">
		<u-card :show-head="false" margin="15rpx" padding="15" :head-border-bottom="false"
			@body-click="handlerBodyClick">
			<view class="u-body" slot="body">
				<view class="u-body-item-title">
					<view class="d-flex-between">
						<text style="font-size: 30rpx;">苏州苏达机械有限公司</text>
					</view>
					<view class="d-flex-around">
						<text>行业：</text>
						<view>
							<u-tag text="金属制品业" type="primary" size='mini' style="margin-right: 15rpx;"/>
							<u-tag text="仪器仪表制造业" type="primary" size='mini'/>
						</view>
					</view>
					<view class="">
						<text>地址：苏州工业园区现代大道12号</text>
					</view>
				</view>
				<u-icon class="u-body-item-icon" name="arrow-right"></u-icon>
			</view>
			<view class="" slot="foot">
				<view class="btn-box">
					<view size="medium" @click="handlerEdit">
						<u-icon class="foot-icon" name="edit-pen"></u-icon>
						<text>编辑</text>
					</view>
					<view size="medium" @click="handlerDel">
						<u-icon class="foot-icon" name="close"></u-icon>
						<text>删除</text>
					</view>
				</view>
			</view>
		</u-card>
	</view>
</template>

<script>
	export default {
		props: {
			dataList: {
				type: Object,
				default: () => {}
			}
		},
		methods: {
			handlerBodyClick(){
				this.$emit('handlerBodyClick')
			},
			handlerEdit() {
				this.$emit('handlerEdit')
			},
			handlerDel() {
				this.$emit('handlerDel')
			},
		},
}
</script>

<style scoped lang="scss">
	.serve-card-container {
		width: 100%;
		overflow: hidden;
		box-sizing: border-box;

		.btn-box {
			display: flex;
			justify-content: center;
			align-items: center;
			color: #303133;

			view {
				width: 300rpx;
				height: 60rpx;
				line-height: 60rpx;
				text-align: center;

				.foot-icon {
					width: 28rpx;
					height: 28rpx;
					margin-right: 15rpx;
				}
			}
		}

		.u-body {
			display: flex;
			justify-content: space-between;
		}

		.u-body-item-title {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
		}

		.u-body-item-icon {
			width: 28rpx;
		}

		.d-flex-between {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.d-flex-around {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin: 10rpx 0;
		}
	}
</style>
