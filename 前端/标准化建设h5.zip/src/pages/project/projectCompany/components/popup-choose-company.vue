<template>
    <u-popup v-model="showDialog" mode="right" width="100%" length="100%" class="choose-company">
        <eagle-head @close="close"> 选择被检查单位</eagle-head>
        <view>
            <view class="u-tabs-box ">
                <u-tabs-swiper activeColor="#2979ff" name="Name" :showBar="false" ref="tabs" :list="tabList" :bar-width="100" :current="tabIndex" @change="onTabChanged" :marginBottom="90" :is-scroll="false">
                </u-tabs-swiper>
            </view>
            <swiper class="swiper-box swiper-box1" :current="tabIndex" @change="changeTab">
                <swiper-item class="swiper-item">
                    <eagle-page-list :conditions="conditions" ref="eaglePageList" controller="system/company" :marginBottom="150" :boolInitData="false" :showCheck="true" :isUseEnterprise="false" @initList="_initList">
                        <view slot="search">
                            <view class="search">
                                <eagle-search v-model="conditions.name.value" @search="search" :clearabled="clearabled" :show-action="false" @clear="search"></eagle-search>
                            </view>
                        </view>
                        <view slot="list" class="list-wrap">
                            <view class="view_container" v-for="(item, index) in data" :key="index">
                                <view @tap="choose(item,true)">
                                    <view class="view_row">
                                        <view>
                                            <view class="uni-media-list-text-top">{{item.name}}</view>
                                        </view>
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose(item,false)" shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-page-list>
                </swiper-item>
                <swiper-item class="swiper-item">
                    <eagle-page-list :conditions="conditions2" :marginBottom="150" :queryParams="queryParams" ref="eaglePageList2" controller="danger/checkEnterprise" dataType="chooseEnterprise" :showCheck="true" :boolInitData="false" :isUseEnterprise="false" @initList="_initList">
                        <view slot="search">
                            <view class="search">
                                <eagle-search v-model="conditions2.enterpriseName.value" @search="search" :clearabled="clearabled" :show-action="false" @clear="search"></eagle-search>
                            </view>
                        </view>
                        <view slot="list" class="list-wrap">
                            <view class="view_container" v-for="(item, index) in data" :key="index">
                                <view @tap="choose(item,true)">
                                    <view class="view_row">
                                        <view>
                                            <view class="uni-media-list-text-top">{{item.name}}</view>
                                        </view>
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose(item,false)" shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-page-list>
                </swiper-item>
            </swiper>
            <view class="view-choose-botton">
                <u-button class="choose-btn" type="primary" @click="handlerFabClick">新增</u-button>
            </view>
            <popup-add-company ref="addForm" @formCallback="formCallbackFun"></popup-add-company>
        </view>
    </u-popup>

</template>

<script>
import PopupAddCompany from "./popup-add-company.vue";

export default {
    name: "popup-choose-company",
    components: { PopupAddCompany },
    props: {
        value: {
            type: String,
            default() {
                return "";
            },
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            searchValue: "",
            data: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,
            choosedNum: 0,
            queryParams: {
                projectId: "",
            },
            detailHeigh: 0,
            chooseVal: "",
            showDialog: false,
            tabList: [{ name: "项目单位" }, { name: "被检查单位" }],
            tabIndex: 0,
            conditions: {
                name: {
                    value: "",
                },
            },
            conditions2: {
                enterpriseName: {
                    value: "",
                },
            },
        };
    },
    computed: {},
    watch: {},
    created() {
        this.queryParams.projectId = this.$route.query.projectId;
    },
    mounted() { },
    onShow() { },
    watch: {},
    methods: {
        // transition(e) {
        //     let dx = e.detail.dx
        //     this.$refs.tabs.setDx(dx)
        // },
        // animationfinish(e) {
        //     console.log(e)
        //     let current = e.detail.current
        //     this.$refs.tabs.setFinishCurrent(current)
        //     this.tabContentIndex = current
        //     this.tabIndex = current
        //     this.onTabChanged(current)
        // },
        changeTab(e) {
            console.log(e);
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
            this.tabContentIndex = current;
            this.tabIndex = current;
            this.onTabChanged(current);
            this.search();
        },
        choose(obj, update) {
            this.$emit("callBackChoosedData", obj);
            this.close();
        },
        _initList(list) {
            this.data = list;
        },
        // animationfinish(e) {
        //     let current = e.detail.current;
        //     this.$refs.tabs.setFinishCurrent(current);
        //     this.tabIndex = current;
        // },
        onTabChanged(index) {
            this.tabIndex = index;
        },
        search() {
            switch (this.tabIndex) {
                case 0:
                    setTimeout(() => {
                        this.$refs.eaglePageList.search();
                    });
                    break;
                case 1:
                    setTimeout(() => {
                        this.$refs.eaglePageList2.search();
                    });
                    break;
            }
        },
        close() {
            this.showDialog = false;
        },
        show() {
            this.conditions.name.value = "";
            this.conditions2.enterpriseName.value = "";
            this.search();
            this.showDialog = true;
        },
        handlerFabClick() {
            this.$refs.addForm.show(this.tabIndex == 1);
        },
        checkChange(e) { },
        formCallbackFun() {
            this.search();
        },
    },
};
</script>


<style lang="scss" scoped>
.choose-company {
    .view_container {
        // background: #fff;
        line-height: 100rpx;
    }

    .view_row {
        display: flex;
        justify-content: space-between;
        // margin: 0rpx 30rpx;
        border-bottom: 1px solid #ececec;
        background-color: #fff;
    }

    .uni-media-list-text-top {
        line-height: 100rpx;
        text-indent: 20rpx;
    }

    // .view-choose-botton {
    //     border-top: 1px solid #e4e7ed;
    //     position: fixed;
    //     width: 100%;
    //     bottom: 0px;
    //     padding-bottom: 15px;
    //     padding-top: 10px;
    //     background: #fff;
    //     .choose-item {
    //         float: left;
    //         display: inline-block;
    //         line-height: 40px;
    //         margin-left: 10px;
    //         font-size: 16px;
    //     }

    //     .choose-num {
    //         color: #2979ff;
    //     }

    //     .choose-btn {
    //         float: right;
    //         // margin-left: 8rpx;
    //         margin-right: 20rpx;
    //     }
    // }

    .uni-date__icon-clear {
        top: 10rpx;
        right: 0;
        display: inline-block;
        box-sizing: border-box;
        border: 12rpx solid transparent;
        margin-right: 12rpx;
        cursor: pointer;
    }

    .uni-page-head {
        background-color: rgb(27, 118, 209);
        color: white;
    }
    .swiper-box {
        height: calc(100vh - 170px);
    }
}
</style>
