<template>
    <u-popup v-model="showDetail" mode="right" height="100vh" length="100%">
        <eagle-head @close="close"> 新增单位</eagle-head>
        <eagle-company-form :isContactProject="isContactProject" :isPopup="true" @submitCallback="submitCallbackFun"></eagle-company-form>
    </u-popup>
</template>

<script>
import EagleCompanyForm from "@/pages/project/projectCompany/detail.vue";
export default {
    name: "popup-add-company",
    components: { EagleCompanyForm },
    props: {
    },
    data() {
        return {
            showDetail: false,
            isContactProject:false
        };
    },
    computed: {},
    watch: {},
    created() {},
    methods: {
        close() {
            this.$emit("formCallback");
            this.showDetail = false;
        },

        show(isContact) {
            this.isContactProject=isContact;
            this.showDetail = true;
        },
        submitCallbackFun(e) {
            this.close();
        },
    },
};
</script>

