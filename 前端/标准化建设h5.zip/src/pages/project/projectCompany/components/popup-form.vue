<template>
    <u-popup v-model="show" mode="right" height="100vh" length="100%">
        <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head">
                <div class="uni-page-head-hd">
                    <div class="uni-page-head-btn" @click="close">
                        <i class="uni-btn-icon" style="font-size: 27px;"></i>
                    </div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                        {{headTitle}}
                    </div>
                </div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head>
        <eagle-company-form></eagle-company-form>
    </u-popup>
</template>

<script>
import EagleCompanyForm from "@/project/projectConsultation/detail.vue";
export default {
    name: "popup-eagle-company-form",
    components: { EagleCompanyForm },
    props: {
        show: {
            type: Boolean,
            default() {
                return false;
            },
        },

        headTitle: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            showDetail: false,
        };
    },
    computed: {},
    watch: {},
    created() {
        let _that = this;
        this._initChoosedData();
    },
    methods: {
        close() {
            // this.dialogShow = false;
            this.$emit("update:show", false);
        },

        funShowDetail() {
            this.showDetail = !this.showDetail;
        },
        checkChange(e) {},
    },
};
</script>

<style lang="scss">
.view_container {
    background: #fff;
    line-height: 100rpx;
}

.view_row {
    display: flex;
    justify-content: space-between;
    margin: 0rpx 30rpx;
    border-bottom: 1px solid #ececec;
    background-color: #fff;
}

.uni-media-list-text-top {
    line-height: 80rpx;
}

.view-botton {
    padding: 12rpx;
    width: 100%;
    bottom: 0px;
    // position: absolute;
    background: #fff;
    // margin-bottom: 80rpx;
}

.choose-item {
    float: left;
    display: inline-block;
    line-height: 50rpx;
}

.choose-num {
    color: #2979ff;
}

.choose-btn {
    float: right;
    margin-left: 8rpx;
}

.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}

.choosed-view {
    margin-bottom: 50rpx;
}

.uni-page-head {
    background-color: rgb(27, 118, 209);
    color: white;
}
</style>
