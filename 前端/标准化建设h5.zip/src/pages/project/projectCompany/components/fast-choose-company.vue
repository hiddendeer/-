<template name="project-company-fast-company">
    <u-form-item :label="label" ref="uFormItem" :label-position="labelPosition" :required="required" :prop="prop" :label-width="labelWidth">
        <!-- <u-input :placeholder="placeholderVal" v-model="defaultValue" @input="inputChange" :border='border' :clearable="false" @confirmEvent="confirmEvent">
        </u-input> -->
        <!-- <view class="u-input">
            <input class="u-input__input auto-flex" style="width:100%" type="text" :value="defaultValue" :placeholder="placeholderVal" confirmType="done" @input="inputChange" @confirm="confirmEvent" />
            <view class="u-input__right-icon u-flex">
                <view class="u-input__right-icon--select u-input__right-icon__item">
                    <u-icon name="arrow-down-fill" size="26" color="#c0c4cc"></u-icon>
                </view>
            </view>
        </view> -->
        <eagle-arrow-input v-model="defaultValue" :disabled="false" :placeholder="placeholderVal" @input="inputChange" @confirm="confirmEvent"></eagle-arrow-input>
        <template v-if="list.length>0&&defaultValue">
            <view class="drop-select">

            </view>
            <view class="drop-content" v-clickoutside="close">
                <view class="drop-row" v-for="(item,index) in list" :key="index" @click="hdClick(item)">
                    <view style="flex:1">{{item.name}}</view>
                    <u-icon class="button" label="选择"></u-icon>
                </view>
            </view>
        </template>
    </u-form-item>
</template>
<script>
import "@/common/clickoutside.js";
export default {
    components: {},
    name: "fast-choose-company",
    props: {
        value: {
            type: String,
            default() {
                return "";
            },
        },
        label: {
            type: String,
            default: "公司名称",
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        border: {
            type: Boolean,
            default: false,
        },
        prop: {
            type: [String],
            default: "",
        },
    },
    data() {
        return {
            model: {},
            control: "danger/report",
            lock: false,
            locklength: 0,
            defaultValue: this.value,
            list: "",
        };
    },

    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请输入" + this.label;
    },
    watch: {
        value(nVal, oVal) {
            if (this.defaultValue != this.value) {
                this.defaultValue = this.value;
            }
        },
    },
    methods: {
        inputChange(event) {
            this.$emit("input", this.defaultValue);
            if (this.defaultValue && this.defaultValue.length >= 2) {
                if (!this.lock || this.locklength < this.defaultValue.length) {
                    let _this = this;
                    this.lock = true;
                    this.locklength = this.defaultValue.length;
                    _this.common
                        .get("/site/projectCustomer/getEnterpriseForFast", {
                            name: _this.defaultValue,
                        })
                        .then((res) => {
                            if (res.code == 200) {
                                _this.list = res.data.items;
                            }
                            setTimeout((x) => {
                                _this.lock = false;
                            }, 500);
                        })
                        .catch((error) => {
                            _this.lock = false;
                        });
                }
            } else {
                this.list = [];
            }
        },
        close() {
            this.list = [];
        },
        // clear() {
        //     this.list = [];
        // },
        hdClick(item) {
            if (this.defaultValue && this.defaultValue.length >= 2) {
                let _this = this;
                let url =
                    "/site/projectCustomer/getDataFromGuanguanTyByName/" +
                    item.name;
                this.list = [];
                _this.common.get(url).then((res) => {
                    let data = res.data;
                    let obj = {
                        name: item.name,
                        organizationCode: data.organizationCode,
                        principal: data.legalPerson,
                        introduce: data.natureOfBusiness,
                        address: data.address,
                    };
                    this.defaultValue = obj.name;
                    this.$emit("input", obj.name);
                    _this.$emit("changed", obj);
                });
            }
        },
        confirmEvent() {
            this.$emit("input", this.defaultValue);
            this.valid();
        },

        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss" scopd>
.drop-select {
    padding: 10px;
    position: absolute;
    z-index: 9999999;
    width: 100%;
    background: #5e5e5e;
    top: 79px;
    left: 0px;
    height: calc(100vh);
    opacity: 0.5;
}
.drop-content {
    border: 1px solid #eee;
    position: absolute;
    max-height: 200px;
    overflow: auto;
    line-height: 36px;
    padding: 10px;
    background: #fff;
    z-index: 9999999;
    width: calc(100vw - 20px);
    left: 0;
    top: 79px;
    border-radius: 0 0 5px 5px;
}
.kailong {
    width: 0;
    height: 0;
    border-left: 8px solid #fff;
    border-right: 8px solid #221d1d00;
    border-bottom: 10px solid #eee;
    position: absolute;
    top: 0px;
    left: 40px;
}
.drop-row {
    display: flex;
    .button {
        width: 50px;
        color: #0088ff;
    }
}
</style>
