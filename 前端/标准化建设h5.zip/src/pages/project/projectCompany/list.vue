<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :boolInitData="false">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="searchValue" placeholder="请输入企业名称进行模糊搜索"> </eagle-search>
                </view>
            </view>
            <view slot="list" class=" list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" @click="handlerBodyClick(item)">

                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.name }}
                    </eagle-row-view>
                    <view>
                        <view>行业：{{ item.applyProfessionName }}</view>
                        <view>公司负责人：{{ item.principal }}</view>
                        <view>联系电话：{{ item.phone }}</view>
                        <view>所在地区：{{ item.area }}</view>
                        <view>录入人：{{ item.editChnName }}</view>
                        <view>录入时间：{{ item.editDate | dateFormat }}</view>
                    </view>
                    <template slot="button">
                        <u-button type="error" size="mini" v-if="isConsultManager" @click="handlerDel(item.id)">删除</u-button>
                        <u-button type="primary" size="mini" @click="handlerEdit(item)">编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab horizontal="right" :popuShow='false' @fabClick='handlerFabClick'></eagle-fab>
    </view>
</template>

<script>
import TabbarDangerJgIndex from "@/pages/components/tabbar/tabbar-dangerJg-index.vue";
import TabbarHostIndex from "@/pages/components/tabbar/tabbar-host-index.vue";
import severCard from "./components/serveCard.vue";
import { isConsultManager, isJGB } from "@/api/auth.js";
export default {
    components: { severCard, TabbarHostIndex, TabbarDangerJgIndex },
    onShow() {
        this.search();
    },
    data() {
        return {
            controller: "system/company",
            list: [],
            sectionCurrent: 0,
            fabContent: [
                {
                    iconPath: "../../../static/img/AppIcon/icon_list_add.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_list_add.png",
                    text: "新增",
                    active: true,
                },
                {
                    iconPath: "../../../static/img/AppIcon/icon_camera.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_camera.png",
                    text: "拍照",
                    active: false,
                },
                // {
                // 	iconPath: '',
                // 	selectedIconPath: '',
                // 	text: '连拍',
                // 	active: '',
                // },
            ],
            clearabled: true,
            conditions: [],
            searchValue: "",
            params: {
                equStatus: [],
                equipmentType: [],
            },
            filterPopShow: false,
            modulesId: "",
            isConsultManager: isConsultManager(),
            isJGB: isJGB(),
        };
    },
    created() {
        this.modulesId = this.$route.query.modulesId;
    },
    methods: {
        initList(data) {
            this.list = data;
        },
        handlerBodyClick(item) {
            let url = "pages/project/projectCompany/view?id=" + item.id;
            this.base.navigateTo(url);
        },
        handlerFabClick() {
            let url = "pages/project/projectCompany/detail?id=0";
            this.base.navigateTo(url);
        },
        handlerEdit(item) {
            let url = "pages/project/projectCompany/detail?id=" + item.id;
            this.base.navigateTo(url);
        },

        handlerDel(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        handlerFilter() {
            this.filterPopShow = true;
        },
        search() {
            // [{"name":"name","operate":"like","value":"123"},
            // {"name":"accidentType","operate":"=","value":"wutidaji"}]
            var conditions = [];
            var str = "";
            if (this.searchValue) {
                let obj = {};
                obj.name = "name";
                obj.value = this.searchValue;
                obj.operate = "like";
                conditions.push(obj);
            }

            this.conditions = conditions;
            this.queryPage();
        },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: this.conditions,
                });
            });
        },
        reSearch() {},
    },
};
</script>

<style scoped lang='scss'>
.equipment-facilities-list-container {
    /* padding: 0 15rpx; */
    box-sizing: border-box;
}

.card-content {
    display: flex;

    .card-content-img {
        margin-right: 20rpx;
    }

    .card-content-body {
        flex: 1 1;
    }
}

.circleShow {
    height: 50rpx;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;
}
</style>
