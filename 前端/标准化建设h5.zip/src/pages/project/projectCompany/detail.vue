<template>
    <view class="">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="130" labelAlign='left'>
            <eagle-container>
                <fast-choose-company v-model="model.name" prop="name" required @changed="changeCompany" />
                <eagle-input v-model="model.organizationCode" title="统一社会信用代码" prop="organizationCode" />
                <eagle-select-item :isType="false" v-model="model.applyProfessionName" required title="所属行业" labelWidth="130" @industryInformation='industryInformation'></eagle-select-item>
                <eagle-address v-model="model.area" required title="地区" labelWidth="130"></eagle-address>
                <eagle-input v-model="model.companySname" title="公司简称" prop="companySname" labelPosition="top" labelWidth="130" />

                <eagle-input v-model="model.principal" title="公司负责人" prop="principal" labelPosition="top" labelWidth="130" />

                <eagle-input v-model="model.phone" title="公司电话" prop="phone" labelPosition="top" labelWidth="130" />

                <eagle-input type='textarea' v-model="model.address" title="公司详细地址" prop="address" labelPosition="top" labelWidth="130" />

                <eagle-input type='textarea' v-model="model.introduce" title="公司简介" prop="introduce" labelPosition="top" labelWidth="130" />
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

    </view>
</template>

<script>
import fastChooseCompany from "@/pages/project/projectCompany/components/fast-choose-company";

export default {
    components: { fastChooseCompany },
    name: "eagle-company-form",
    props: {
        //是否是弹窗
        isPopup: {
            type: Boolean,
            default() {
                return false;
            },
        },
        //是否关联项目
        isContactProject: {
            type: Boolean,
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "system/company",
            companyCode: "",
            type: "",
            params: {
                ProjectBuildStructureArray: [],
                buildRegulatoryfocusArray: [],
            },
            deletable: true,
            regionShow: false,
        };
    },
    methods: {
        changeCompany(obj) {
            this.model.name = obj.name;
            this.model.organizationCode = obj.organizationCode;
            this.model.principal = obj.principal;
            this.model.introduce = obj.introduce;
            this.model.address = obj.address;
        },
        initCallBack(data) {
            this.model = data;
        },
        industryInformation(val) {
            (this.model.applyProfessionName = val.industryName),
                (this.model.applyProfessionCodes = val.industryIap);
        },

        buttonFastSearch() {
            var _this = this;
            if (_this.model.name) {
                _this.common
                    .get(
                        "/site/projectCustomer/getDataFromGuanguanTyByName/" +
                            _this.model.name
                    )
                    .then((res) => {
                        if (res.code == 200 && res.data) {
                            _this.model.organizationCode =
                                res.data.organizationCode;
                            _this.model.address = res.data.address;
                            _this.model.legalPerson = res.data.legalPerson;
                            _this.model.natureOfBusiness =
                                res.data.natureOfBusiness;
                            _this.model.taxNumber = res.data.organizationCode;
                        }
                    });
            } else {
                this.$refs.eagleForm.errorMsg("请输入完整公司名称");
            }
        },

        confirm(e) {
            if (e.city.label === "市辖区") {
                this.model.area = e.province.label + "/" + e.area.label;
            } else if (e.province.label === "全国") {
                this.model.area = "全国";
            } else {
                this.model.area =
                    e.province.label + "/" + e.city.label + "/" + e.area.label;
            }
        },
        post() {
            let _this = this;
            if (this.isContactProject && this.$route.query.projectId) {
                this.model.projectId = this.$route.query.projectId;
            }
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    if (res.code == "200") {
                        if (!_this.isPopup) {
                            // var pages = getCurrentPages();
                            // if (pages.length >= 2) {
                            //     var prevPage = pages[pages.length - 2];
                            //     if (
                            //         prevPage.route ==
                            //         "pages/project/projectConsultation/detail"
                            //     ) {
                            //         prevPage.$vm.refreshCompany();
                            //     }
                            // }
                            _this.base.navigateBack();
                        } else {
                            _this.$emit("submitCallback");
                        }
                    }
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

<style lang="scss">
.div_buttonFastSearch {
    display: block;
    color: rgb(41, 121, 255);
}
</style>