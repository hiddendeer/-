<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm">
            <eagle-container title="意向订单详情">
                <eagle-text title="订单编号" v-model="model.orderno" />
                <eagle-text title="客户名称" v-model="model.customerName" />
                <eagle-text title="服务类型" v-model="model.serviceName" />
                <eagle-text title="销售人员" v-model="model.saleChnName" />
                <eagle-text title="预计成单率(%)" :value="model.rate+'%'" />
                <eagle-text title="意向日期" :value="model.filingDate|dateFormat" />
                <eagle-text title="项目方案或报价">
                    <eagle-file-upload disabled v-model="model.programAttachs" />
                </eagle-text>
                <eagle-text title="备注" v-model="model.remarks" />
             </eagle-container>
        </eagle-form>

    </view>

</template>
<script>
// popup-project-contract-dts

export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectIntentionOrder",
            params: {},
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {
        var _this = this;
        // _this.initParams();
    },
    mounted() {},
    methods: {
        initCallBack(data) {},
    },
};
</script>

