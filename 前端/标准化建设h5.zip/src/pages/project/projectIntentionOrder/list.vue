<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @reSearch="reSearch" @search="search" placeholder="输入更多查询" v-model="searchValue" :searchResults="searchValue.searchResults">

                        <eagle-fast-choose itemWidth="200rpx" v-model="searchValue.status" title="状态" prop="chemistryProp" :data-source="params.trackStatus" v-if="params.trackStatus.length > 0" />
                        <eagle-fast-choose itemWidth="200rpx" v-model="searchValue.serviceCode" title="服务类型" prop="serviceCode" :data-source="params.serviceNameType" v-if="params.serviceNameType.length > 0" />
                        <eagle-choose-user title="销售人员" :isMult="false" v-model="searchValue.saleUserName" :names.sync="searchValue.saleChnName" prop="saleUserName"></eagle-choose-user>
                        <eagle-select v-model="searchValue.filingDate" title="意向日期" prop="filingDate" :data-source="params.year"></eagle-select>
                        <eagle-input title="意向订单编号" placeholder="请输入意向订单编号" v-model="searchValue.orderNo" :labelWidth="150">
                        </eagle-input>
                        <eagle-input title="客户名称" placeholder="请输入客户名称" v-model="searchValue.customerName" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/projectIntentionOrder/view?id=' + item.id)">
                    <template slot="tag">
                        <view v-html="common.bindTag(item.status, params.trackStatus, types.trackStatus)" />
                    </template>
                    <eagle-row-view isTitle>
                        {{ item.orderno }}
                    </eagle-row-view>
                    <eagle-row-view>
                        <view>
                            <text>服务类型 : {{ item.serviceName }} </text>
                        </view>
                        <view>
                            <text>销售人员 : {{ item.saleChnName }} </text>
                        </view>
                        <view>
                            <text>预计成单率(%) : {{ item.rate }} </text>
                        </view>
                        <view>
                            <text>最近跟踪日期 : {{ item.lastVisitDay | dateFormat }} </text>
                        </view>

                        <view>
                            <text>意向日期 : {{ item.filingDate | dateFormat }} </text>
                        </view>
                        <view>
                            <text>下次跟踪日期 : {{ item.nextTrackDate | dateFormat }} </text>
                        </view>
                        <view>
                            <text>创建人 : {{ item.createChnName }}</text>

                        </view>
                    </eagle-row-view>
                    <template slot="button">

                        <u-button type="success" size="mini" @click="goto('/pages/project/myProjectCustomer/trackList?code=' + item.customerCode + '&orderNo=' + item.orderno)" v-if="item.status == 10">跟踪</u-button>
                        <u-button type="primary" size="mini" @click="goto('/pages/project/projectIntentionOrder/detail?id=' + item.id)" v-if="item.status == 10">编辑</u-button>
                        <u-button type="error" size="mini" @click="goto('/pages/project/projectIntentionOrder/intention?id=' + item.id)" v-if="item.status == 10">取消意向</u-button>
                        <u-button type="success" size="mini" @click="handleUpdateReason(item)" v-if="item.status == 30">
                            恢复意向</u-button>
                        <u-button type="success" size="mini" label="新增合同" @click="goto('/pages/project/projectContract/detail?id=0&orderNo='+item.orderno +'&code='+item.code)" v-if="item.status == 10"> 新增合同</u-button>
                        <!-- <u-button type="primary" size="mini"
                            @click="goto('/pages/project/projectContract/detail?id=0&orderNo=' + item.orderno + '&code=' + item.code)"
                            v-if="item.status == 10">编辑</u-button> -->

                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                    <view class="uni-media-list" @click="goto('/pages/project/projectIntentionOrder/view?id='+item.id)">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                <eagle-girdrow-block>{{item.orderno}}</eagle-girdrow-block>
                            </eagle-girdrow-base>
                            <eagle-girdrow-base>
                                <view>
                                    <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code='+item.customerCode)">客户名称 : {{item.customerName}} </text>
                                </view>
                                <view>
                                    <text>服务类型 : {{item.serviceName}} </text>
                                </view>
                                <view>
                                    <text>销售人员 : {{item.saleChnName}} </text>
                                </view>
                                <view>
                                    <text>预计成单率(%) : {{item.rate}} </text>
                                </view>

                                <view>
                                    <text>状态 : {{item.status+ ""|splitParamsFormat(params.trackStatus)}} </text>
                                </view>
                                <view>
                                    <text>最近跟踪日期 : {{item.lastVisitDay|dateFormat}} </text>
                                </view>

                                <view>
                                    <text>意向日期 : {{item.filingDate|dateFormat}} </text>
                                </view>
                                <view>
                                    <text>下次跟踪日期 : {{item.nextTrackDate|dateFormat}} </text>
                                </view>
                                <view>
                                    <text>创建人 : {{item.createChnName}}</text>

                                </view>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                    
                        <u-icon class="eagle-blue eagle-row-span" name="phone" label="跟踪" @click="goto('/pages/project/myProjectCustomer/trackList?code='+item.customerCode+'&orderNo='+item.orderno)" v-if="item.status == 10" />
                        <u-icon class="eagle-blue eagle-row-span" name="edit-pen" label="编辑" @click="goto('/pages/project/projectIntentionOrder/detail?id='+item.id)" v-if="item.status == 10" />
                        <u-icon class="eagle-red eagle-row-span" name="lock-fill" label="取消意向" @click="goto('/pages/project/projectIntentionOrder/intention?id='+item.id)" v-if="item.status == 10" />
                        <u-icon class="eagle-blue eagle-row-span" name="lock-opened-fill" label="恢复意向" @click="handleUpdateReason(item)" v-if="item.status == 30" />
                        <u-icon class="eagle-blue eagle-row-span" name="order" label="新增合同" @click="goto('/pages/project/projectContract/detail?id=0&orderNo='+item.orderno +'&code='+item.code)" v-if="item.status == 10" />
                    </eagle-grid-botton>
                </view> -->
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick="goto('/pages/project/projectIntentionOrder/detail?id=0')"></eagle-fab>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    onShow() {
        this.search();
    },
    data() {
        return {
            searchValue: {
                status: "",
                serviceCode: "",
                accidentType: "",
                saleUserName: "",
                saleChnName: "",
                filingDate: "",
                orderNo: "",
                customerName: "",
            },
            controller: "/site/projectIntentionOrder",
            data: [],
            clearabled: true,
            conditions: [],
            params: {
                trackStatus: [],
                serviceNameType: [],
                year: [],
            },
            types: {
                trackStatus: [
                    { id: "20", type: "success" },
                    { id: "30", type: "red" },
                ],
            },
        };
    },
    onReady() {
        this.initParams();
        this.getServiceNameType();
    },
    created() {
        // this.source = this.$route.query.source;

        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.params.year.push({
                id: i,
                name: i,
            });
        }
    },
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.status = "";
            this.searchValue.serviceCode = "";

            this.searchValue.accidentType = "";
            this.searchValue.saleUserName = "";
            this.searchValue.saleChnName = "";
            this.searchValue.filingDate = "";
            this.searchValue.orderNo = "";
            this.searchValue.customerName = "";
        },
        search() {
            // [{"name":"name","operate":"like","value":"123"},
            // {"name":"accidentType","operate":"=","value":"wutidaji"}]
            var conditions = [];
            var str = "";
            if (this.searchValue.status) {
                let obj = {};
                obj.name = "status";
                obj.value = this.searchValue.status;
                obj.operate = "=";
                conditions.push(obj);
                str = this.common.paramsFormat(
                    this.searchValue.status,
                    this.params.trackStatus
                );
            }

            if (this.searchValue.serviceCode) {
                let obj = {};
                obj.name = "serviceCode";
                obj.value = this.searchValue.serviceCode;
                obj.operate = "=";
                conditions.push(obj);
                if (str == "") {
                    str = this.common.paramsFormat(
                        this.searchValue.serviceCode,
                        this.params.serviceNameType
                    );
                } else {
                    str =
                        str +
                        "," +
                        this.common.paramsFormat(
                            this.searchValue.serviceCode,
                            this.params.serviceNameType
                        );
                }
            }

            if (this.searchValue.saleUserName) {
                let obj = {};
                obj.name = "saleUserName";
                obj.value = this.searchValue.saleUserName;
                obj.operate = "like";
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.saleChnName;
                } else {
                    str = str + "," + this.searchValue.saleChnName;
                }
            }

            if (this.searchValue.filingDate) {
                let obj = {};
                obj.name = "filingDate";
                obj.value = this.searchValue.filingDate;
                obj.operate = "like";
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.filingDate;
                } else {
                    str = str + "," + this.searchValue.filingDate;
                }
            }

            if (this.searchValue.orderNo) {
                conditions.push({
                    name: "orderNo",
                    value: this.searchValue.orderNo,
                    operate: "like",
                });

                if (str == "") {
                    str = this.searchValue.orderNo;
                } else {
                    str = str + "," + this.searchValue.orderNo;
                }
            }

            if (this.searchValue.customerName) {
                conditions.push({
                    name: "customerName",
                    value: this.searchValue.customerName,
                    operate: "like",
                });
                if (str == "") {
                    str = this.searchValue.customerName;
                } else {
                    str = str + "," + this.searchValue.customerName;
                }
            }

            this.searchValue.searchResults = str;

            this.conditions = conditions;
            this.queryPage();
        },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: this.conditions,
                });
            });
        },
        initParams() {
            var _this = this;

            this.common
                .getparamsList("site_project_track_status")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_track_status") {
                                _this.params.trackStatus.push(item);
                            }
                        });
                    }
                });
        },
        imgError(e) {},
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        handleUpdateReason(row) {
            let _this = this;
            // _this.form.renewStatus = 2;
            let url = "/site/projectIntentionOrder/getDataByCode/" + row.code;

            _this.common.get(url).then(function (res) {
                let data = res.data;
                console.log(data);
                if (res.code == 200) {
                    data.status = "10";

                    _this.common
                        .post("/site/projectIntentionOrder/save", data)
                        .then(function (res) {
                            // _this.msgSuccess("续签成功");

                            _this.$refs.uToast.show({
                                title: "恢复成功",
                                type: "success",
                            });

                            _this.queryPage();
                        });
                }
            });
        },

        getSuplusDate(deadline) {
            if (deadline == null || deadline == "") {
                return `无跟踪记录`;
            } else {
                var now = new Date();
                let day = this.getDaysBetween(now, deadline);
                if (day >= 0) {
                    return `还剩${day}天`;
                } else {
                    return `超过${day * -1}天未跟踪`;
                }
            }
        },
        getDaysBetween(date1, date2) {
            var startDate = Date.parse(this.common.dateFormat(date1));

            var endDate = Date.parse(
                this.common.dateFormat(date2.replace(/-/g, "/"))
            );
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
        getServiceNameType() {
            let _this = this;

            var url = "site/projectServiceType/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    // var array = [];
                    for (let index in res.data) {
                        let data = {
                            id: res.data[index].code,
                            name: res.data[index].serviceName,
                        };
                        _this.params.serviceNameType.push(data);
                    }
                    // = Object.freeze(array);
                } else {
                }
                uni.hideToast();
            });
        },
    },
};
</script>

<style lang="scss">
.m {
    color: #2979ff;
}
</style>
