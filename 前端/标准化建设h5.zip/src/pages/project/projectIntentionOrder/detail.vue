<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='80' :errorType="errorType">
            <eagle-container>

                <eagle-text title="订单编号">{{model.orderno}}</eagle-text>
                <!-- <eagle-input v-model="model.orderno" disabled title="订单编号" prop="name" /> -->
                <!-- <eagle-input v-model="model.customerName" title="客户" prop="customerName" required /> -->
                <eagle-window-choose title="客户" headTitle="请选择客户" v-model="model.customerCode" :isMult="false" :names.sync="model.customerName" :required="true" showDetail="true" controller="site/projectCustomer" idField="code" textField="name" dataType="myCustomerList"></eagle-window-choose>
                <eagle-window-choose title="服务类型" headTitle="请选择服务类型" v-model="model.serviceCode" :isMult="true" :names.sync="model.serviceName" :required="true" showDetail="true" controller="site/projectServiceType" idField="code" textField="serviceName"></eagle-window-choose>

                <!-- /site/projectCustomer/getPageData?dataType=myCustomerList&pageNum=1&pageSize=20 -->
                <!-- site/projectServiceType/getPageData?dataType=list&pageNum=1&pageSize=20 -->
                <!-- <eagle-input v-model="model.serviceName" title="服务类型" prop="serviceName" required /> -->
                <!-- <eagle-input v-model="model.saleChnName" title="销售人员" prop="saleChnName" required /> -->
                <eagle-choose-user v-model="model.saleUserName" title="销售人员" :names.sync="model.saleChnName" prop="shareUserName" required></eagle-choose-user>

                <eagle-input v-model="model.rate" title="预计成单率(%)" prop="rate" required type="number" />
                <eagle-date v-model="model.filingDate" title="意向日期" prop="filingDate" required />
                <eagle-file-upload :maxCount="3" title="项目方案或报价" prop="programAttachs" v-model="model.programAttachs" />
                <eagle-input v-model="model.remarks" title="备注" prop="remarks" type="textarea" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <popup-project-contract-dts @contractCallBack="contractCallBack" ref="projectContractDts">
        </popup-project-contract-dts>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
// popup-project-contract-dts
import PopupProjectContractDts from "../../components/project/projectContractDts/popupProjectContractDts.vue";
export default {
    components: {
        PopupProjectContractDts,
    },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectIntentionOrder",
            params: {
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增意向订单",
            });
        }
    },
    onReady() {
        var _this = this;
        // _this.initParams();
    },
    mounted() {},
    methods: {
        initCallBack(data) {},

        setValues(codes, names) {},

        post(op) {
            let _this = this;

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>

