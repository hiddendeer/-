<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType">
            <eagle-container>
                <eagle-input v-model="model.reasonForCancellation" type="textarea" required title="取消意向说明" prop="reasonForCancellation" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectIntentionOrder",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {
        var _this = this;
    },
    mounted() {},
    methods: {
        initCallBack(data) {},

        post(op) {
            let _this = this;

            if (this.model.reasonForCancellation == "") {
                this.$refs.uToast.show({
                    title: "请输入取消意向说明",
                    type: "error",
                });

                return;
            }

            var data = {};
            data.id = this.model.id;
            data.reasonForCancellation = this.model.reasonForCancellation;
            data.status = "30";

            _this.common
                .post("/site/projectIntentionOrder/updatePurpose", data)
                .then(function (res) {
                    // _this.msgSuccess("续签成功");

                    _this.$refs.uToast.show({
                        title: "取消意向成功",
                        type: "success",
                    });
                    _this.base.navigateBack();
                });
        },
    },
};
</script>
