<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="back">
            <view slot="search">
                <view class="search">
                    <eagle-condition @reSearch="reSearch" @search="search" placeholder="请输入关键字进行模糊搜索" v-model="searchValue" :searchResults="searchValue.searchResults">

                        <eagle-date title="合同日期" type="daterange" :startDate.sync="searchValue.StartDate" :endDate.sync="searchValue.EndDate" :labelWidth="150"></eagle-date>
                        <eagle-input title="客户名称" placeholder="请输入客户名称进行模糊搜索" v-model="searchValue.customerName" :labelWidth="150"></eagle-input>
                        <eagle-input title="合同编号" placeholder="请输入合同编号进行模糊搜索" v-model="searchValue.orderNo" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/projectContract/view?id=' + item.id)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.orderName }}
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            <text>合同编号 : {{ item.orderNo }} </text>
                        </view>
                        <view>
                            <text>客户名称 : </text>
                            <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code=' + item.customerCode)">{{ item.customerName }}
                            </text>
                        </view>
                        <view>
                            <text>服务类型 : {{ item.serviceName }} </text>
                        </view>

                        <view>
                            <text>本期应收金额 : {{ item.backPrice.toFixed(2) }} </text>
                        </view>
                        <view>
                            <text>本期已收款 : {{ item.peridReceivePrice.toFixed(2) }} </text>
                        </view>
                        <view>
                            <text>本期回款期限 : {{ item.payDate | dateFormat }} </text>
                        </view>
                        <view>
                            <text style="color:red">预警 : {{ getSuplusDate(item.payDate) }} </text>
                        </view>
                        <view>
                            <text>回款方式 : {{ item.method | splitParamsFormat(params.collectionMode) }}</text>
                        </view>
                        <view>
                            <text>销售人员: {{ item.saleChnName }} </text>
                        </view>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="success" size="mini" @click="goto('/pages/project/projectContractBack/detail?id=' + item.id)">回款</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                    <view class="uni-media-list" @click="goto('/pages/project/projectContract/view?id='+item.id)">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                <eagle-girdrow-block>{{item.orderName}}</eagle-girdrow-block>

                            </eagle-girdrow-base>

                            <eagle-girdrow-base>
                                <view>
                                    <text>合同编号 : {{item.orderNo}} </text>
                                </view>
                                <view>
                                    <text>客户名称 : </text>
                                    <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code='+item.customerCode)">{{item.customerName}}
                                    </text>
                                </view>
                                <view>
                                    <text>服务类型 : {{item.serviceName}} </text>
                                </view>

                                <view>
                                    <text>本期应收金额 : {{item.backPrice.toFixed(2)}} </text>
                                </view>
                                <view>
                                    <text>本期已收款 : {{item.peridReceivePrice.toFixed(2)}} </text>
                                </view>
                                <view>
                                    <text>本期回款期限 : {{item.payDate|dateFormat}} </text>
                                </view>
                                <view>
                                    <text style="color:red">预警 : {{getSuplusDate(item.payDate)}} </text>
                                </view>
                                <view>
                                    <text>回款方式 : {{item.method|splitParamsFormat(params.collectionMode)}}</text>
                                </view>
                                <view>
                                    <text>销售人员: {{item.saleChnName}} </text>
                                </view>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-icon class="eagle-blue eagle-row-span" @click="goto('/pages/project/projectContractBack/detail?id='+item.id)" name="reload" label="回款" />
                    </eagle-grid-botton>
                </view> -->
            </view>
        </eagle-page-list>
        <tabbar-project-contract-back class="tabber-danger"></tabbar-project-contract-back>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
import tabbarBack from "@/pages/components/tabbar/tabbar-project-contract-back.vue";
export default {
    components: {
        "tabbar-project-contract-back": tabbarBack,
    },
    onShow() {
        this.search();
    },
    data() {
        return {
            tabIndex: 0,
            controller: "/site/projectContractGet",
            data: [],
            clearabled: true,
            backType: "back",
            searchValue: {
                status: "",

                searchResults: "",
                customerName: "",
                StartDate: "",
                EndDate: "",
                orderNo: "",
            },
            params: {
                collectionMode: [],
                //
            },
        };
    },
    onReady() {
        this.initParams();
    },
    created() {},
    filters: {},
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.status = "";
            this.searchValue.name = "";
            this.searchValue.customerName = "";
            this.searchValue.StartDate = "";
            this.searchValue.EndDate = "";
            this.searchValue.orderNo = "";
        },
        search() {
            var conditions = [];
            var str = "";
            if (this.backType) {
                let obj = {};
                obj.name = "backType";
                obj.operate = "like";
                obj.value = this.backType;
                conditions.push(obj);
                // str = this.common.paramsFormat(this.searchValue.status, this.params.status);
            }

            if (this.searchValue.StartDate && this.searchValue.EndDate) {
                let obj = {};
                obj.name = "contractDate";
                obj.operate = "like";
                obj.value = [
                    this.searchValue.StartDate,
                    this.searchValue.EndDate,
                ];
                conditions.push(obj);

                str =
                    this.searchValue.StartDate +
                    "至" +
                    this.searchValue.EndDate;
            }

            if (this.searchValue.customerName) {
                let obj = {};
                obj.name = "customerName";
                obj.operate = "like";
                obj.value = this.searchValue.customerName;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.customerName;
                } else {
                    str = str + "," + this.searchValue.customerName;
                }
            }

            if (this.searchValue.orderNo) {
                let obj = {};
                obj.name = "orderNo";
                obj.operate = "like";
                obj.value = this.searchValue.orderNo;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.orderNo;
                } else {
                    str = str + "," + this.searchValue.orderNo;
                }
            }

            this.searchValue.searchResults = str;

            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: conditions,
                });
            });
        },
        initParams() {
            var _this = this;

            this.common
                .getparamsList("site_project_collection_mode")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }
                        });
                    }
                });
        },
        initList(list) {
            this.data = list;
        },
        goto(url) {
            this.base.navigateTo(url);
        },

        getSuplusDate(deadline) {
            if (deadline == null || deadline == "") {
                return `/`;
            } else {
                var now = new Date();

                let day = this.monthDayDiff(now, deadline);
                return day;
            }
        },

        monthDayDiff(now, deadline) {
            // this指针
            let _this = this;
            let flag = [1, 3, 5, 7, 8, 10, 12, 4, 6, 9, 11, 2];
            let start = new Date(now);
            let end = new Date(deadline.replace(/-/g, "/"));

            let flag_tiem = "";
            let year, month, day;
            if (start > end) {
                flag_tiem = "(逾期)";
                year = start.getFullYear() - end.getFullYear();
                month = start.getMonth() - end.getMonth();
                day = start.getDate() - end.getDate();
            } else {
                year = end.getFullYear() - start.getFullYear();
                month = end.getMonth() - start.getMonth();
                day = end.getDate() - start.getDate();
            }
            if (month < 0) {
                year--;
                month = end.getMonth() + (12 - start.getMonth());
            }
            if (day < 0) {
                month--;
                let index = flag.findIndex((temp) => {
                    return temp === start.getMonth() + 1;
                });
                let monthLength;
                if (index <= 6) {
                    monthLength = 31;
                } else if (index > 6 && index <= 10) {
                    monthLength = 30;
                } else {
                    monthLength = 28;
                }
                day = end.getDate() + (monthLength - start.getDate());
                // day = start.getDate() - end.getDate();
            }

            let returnStr = ``;

            if (day == 0 && year == 0 && month == 0) {
                return `/`;
            } else {
                if (year != 0) {
                    returnStr = returnStr + `${Math.abs(year)}年`;
                }
                if (month != 0) {
                    returnStr = returnStr + `${Math.abs(month)}月`;
                }
                if (day != 0) {
                    returnStr = returnStr + `${Math.abs(day)}天`;
                }

                return returnStr + flag_tiem;
            }
        },
    },
};
</script>
<style lang="scss">
.m {
    color: #2979ff;
}
</style>
