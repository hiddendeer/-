<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="backHistory">
            <view slot="search">
                <view class="search">
                    <eagle-condition @reSearch="reSearch" @search="search" placeholder="请输入关键字进行模糊搜索" v-model="searchValue" :searchResults="searchValue.searchResults">

                        <eagle-date title="合同日期" type="daterange" :startDate.sync="searchValue.StartDate" :endDate.sync="searchValue.EndDate" :labelWidth="150"></eagle-date>
                        <eagle-input title="客户名称" placeholder="请输入客户名称进行模糊搜索" v-model="searchValue.customerName" :labelWidth="150"></eagle-input>
                        <eagle-input title="合同编号" placeholder="请输入合同编号进行模糊搜索" v-model="searchValue.orderNo" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/projectContract/view?id='+item.id)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{item.orderNo}}
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            <text>客户名称： </text>
                            <text class="m" @click.stop="goto('/pages/project/myProjectCustomer/view?code='+item.customerCode)">{{item.customerName}} </text>
                        </view>
                        <view>
                            <text>服务类型： {{item.serviceName}} </text>
                        </view>

                        <view>
                            <text>本期应收金额： {{item.backPrice.toFixed(2)}} </text>
                        </view>

                        <view>
                            <text>回款金额： {{item.getPrice.toFixed(2)}} </text>
                        </view>
                        <view>
                            <text>坏账金额： </text>
                            <text style="color:red;" v-if="item.badPrice>0"> {{item.badPrice.toFixed(2)}} </text>
                            <text v-else> {{item.badPrice.toFixed(2)}} </text>
                        </view>
                        <view>
                            <text>本期回款日期： {{item.payDate|dateFormat}} </text>
                        </view>
                        <view>
                            <text>收款日期：{{item.backDate|dateFormat}} </text>
                        </view>
                        <view>
                            <text>回款方式：{{item.method|splitParamsFormat(params.collectionMode)}}</text>
                        </view>
                        <view>
                            <text>销售人员：{{item.saleChnName}} </text>
                        </view>

                        <view v-if="item.attachs&&item.attachs!=''&&item.attachs!='[]'">
                            <eagle-grid-attach title="回款凭证" v-model="item.attachs"></eagle-grid-attach>
                        </view>
                        <view v-else>
                            <text>回款凭证：-- </text>
                        </view>
                    </eagle-row-view>
                    <template slot="button" v-if="item.status == 10">
                        <u-icon class="eagle-red eagle-row-span" @click="invalid(item)" name="trash" label="作废" />
                    </template>
                </eagle-row-card>

            </view>
        </eagle-page-list>
        <tabbar-project-contract-back class="tabber-danger"></tabbar-project-contract-back>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
import tabbarBack from "@/pages/components/tabbar/tabbar-project-contract-back.vue";
export default {
    components: {
        "tabbar-project-contract-back": tabbarBack,
    },
    onShow() {
        this.search();
    },
    data() {
        return {
            tabIndex: 0,
            controller: "/site/projectContractGet",
            data: [],
            clearabled: true,
            backType: "backHistory",
            searchValue: {
                name: "",
                status: "",
                searchResults: "",
                customerName: "",
                StartDate: "",
                EndDate: "",
                orderNo: "",
            },
            params: {
                collectionMode: [],
                //
            },
        };
    },
    onReady() {
        this.initParams();
    },
    created() {},
    filters: {},
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.status = "";
            this.searchValue.name = "";
            this.searchValue.customerName = "";
            this.searchValue.StartDate = "";
            this.searchValue.EndDate = "";
            this.searchValue.orderNo = "";
        },
        search() {
            var conditions = [];
            var str = "";
            if (this.backType) {
                let obj = {};
                obj.name = "backType";
                obj.operate = "like";
                obj.value = this.backType;
                conditions.push(obj);
                // str = this.common.paramsFormat(this.searchValue.status, this.params.status);
            }

            if (this.searchValue.StartDate && this.searchValue.EndDate) {
                let obj = {};
                obj.name = "contractDate";
                obj.operate = "like";
                obj.value = [
                    this.searchValue.StartDate,
                    this.searchValue.EndDate,
                ];
                conditions.push(obj);

                str =
                    this.searchValue.StartDate +
                    "至" +
                    this.searchValue.EndDate;
            }

            if (this.searchValue.customerName) {
                let obj = {};
                obj.name = "customerName";
                obj.operate = "like";
                obj.value = this.searchValue.customerName;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.customerName;
                } else {
                    str = str + "," + this.searchValue.customerName;
                }
            }

            if (this.searchValue.orderNo) {
                let obj = {};
                obj.name = "orderNo";
                obj.operate = "like";
                obj.value = this.searchValue.orderNo;
                conditions.push(obj);

                if (str == "") {
                    str = this.searchValue.orderNo;
                } else {
                    str = str + "," + this.searchValue.orderNo;
                }
            }

            this.searchValue.searchResults = str;

            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: conditions,
                });
            });
        },
        initParams() {
            var _this = this;

            this.common
                .getparamsList("site_project_collection_mode")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }
                        });
                    }
                });
        },
        initList(list) {
            this.data = list;
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        getSuplusDate(deadline) {
            if (deadline == null || deadline == "") {
                return `无跟踪记录`;
            } else {
                var now = new Date();
                let day = this.monthDayDiff(now, deadline);
                // if (day >= 0) {
                return day;
                // } else {
                //     return `超过${day}天未跟踪`;
                // }
            }
        },

        monthDayDiff(now, deadline) {
            // this指针
            console.log(now + deadline);
            let _this = this;
            let flag = [1, 3, 5, 7, 8, 10, 12, 4, 6, 9, 11, 2];
            let start = new Date(now);
            let end = new Date(deadline);
            let year = end.getFullYear() - start.getFullYear();
            let month = end.getMonth() - start.getMonth();
            let day = end.getDate() - start.getDate();
            if (month < 0) {
                year--;
                month = end.getMonth() + (12 - start.getMonth());
            }
            if (day < 0) {
                //逾期
                // month--;
                let index = flag.findIndex((temp) => {
                    return temp === start.getMonth() + 1;
                });
                let monthLength;
                if (index <= 6) {
                    monthLength = 31;
                } else if (index > 6 && index <= 10) {
                    monthLength = 30;
                } else {
                    monthLength = 28;
                }
                day = end.getDate() + (monthLength - start.getDate());
                // if(year==0 && month !=0){
                //   return  `${Math.abs(month)}月${Math.abs(day)}天(逾期)`;
                // }else if(year==0 && month == 0){
                //   return  `${Math.abs(day)}天`;
                // }else{
                //    return `${Math.abs(year)}年${Math.abs(month)}月${Math.abs(day)}天(逾期)`;
                // }
            }
            if (year == 0 && month != 0) {
                return `${month}月${day}天`;
            } else if (year == 0 && month == 0) {
                return `${day}天`;
            } else {
                return `${year}年${month}月${day}天`;
            }
        },
        invalid(item) {
            let _this = this;
            this.$refs.eagleConfirm.showConfirm({
                content: "确定要作废本回款信息吗?",
                confirm: function () {
                    var url =
                        "site/projectContractGet/deleteByGetCode/" +
                        item.getCode;
                    _this.common.del(url, null).then(function (res) {
                        if (res.code == 200) {
                            _this.$refs.uToast.show({
                                title: "作废成功",
                                type: "success",
                                callback: function () {
                                    _this.search();
                                },
                            });
                        } else {
                            _this.$refs.uToast.show({
                                title: "删除失败：" + res.errMsg,
                                type: "error",
                            });
                        }
                    });
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消作废",
                        type: "error",
                    });
                },
            });
        },
    },
};
</script>
<style lang="scss">
.m {
    color: #2979ff;
}
</style>