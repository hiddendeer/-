<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='50' :errorType="errorType" :initUrl="initUrl">
            <eagle-container>
                <eagle-input disabled :value="model.backPrice|twoDecimal" title="应回款金额" prop="backPrice"></eagle-input>
                <eagle-checkbox-group v-model="model.finish" title="回款完成" prop="finish" :data-source="params.finish" />
                <eagle-date v-model="model.backDate" title="收款日期" prop="backDate" required />
                <eagle-input v-model="model.getPrice" type="number" :isNumber="true" title="收到金额" required prop="getPrice" @input="numDxsCheck(model, 2, 'getPrice')" />
                <eagle-radio-group v-model="model.method" title="收款方式" prop="method" :data-source="params.collectionMode" v-if="params.collectionMode.length>0" required />
                <eagle-file-upload :maxCount="3" title="收款凭证" prop="attachs" v-model="model.attachs" />
                <eagle-input type="textarea" v-model="model.remarks" title="备注" prop="remarks" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            item: {},
            initUrl: "",
            code: "",
            errorType: ["message"],
            control: "site/projectContractGet",
            params: {
                equStatus: [],
                planType: [],
                collectionMode: [],
                finish: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        let _this = this;

        this.code = this.$route.query.code;

        this.initUrl = "site/projectContractDts/getDataByCode/" + this.code;
    },
    onReady() {
        var _this = this;
    },

    mounted() {},
    methods: {
        initCallBack(data) {
            this.initParams();
            if (this.model.finish) {
                this.model.finish = "1";
            } else {
                this.model.finish = "0";
            }

            // this.model.mainCode = this.item.code;
            // this.model.orderCode = this.item.mainCode;
            this.model.backPrice =
                this.model.totalPrice - this.model.receivePrice;
            this.model.getPrice =
                this.model.totalPrice - this.model.receivePrice;

            var now = new Date();
            this.model.backDate = now;
        },

        initParams() {
            var _this = this;

            this.common
                .getparamsList("site_project_collection_mode")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }
                        });

                        if (_this.params.collectionMode.length > 0) {
                            let item = _this.params.collectionMode[0];
                            _this.model.method = item.id;
                        }
                        //
                    }
                });
        },

        post(op) {
            let _this = this;

            if (this.model.finish == "1") {
                this.model.finish = true;
            } else {
                this.model.finish = false;
            }

            if (
                this.model.getPrice > this.model.backPrice ||
                this.model.getPrice == "" ||
                this.model.getPrice <= 0
            ) {
                this.$refs.uToast.show({
                    title: "收到金额不能大于应回款金额且大于零",
                    type: "error",
                });
                return;
            }
            this.model.orderCode = this.model.mainCode;
            this.model.mainCode = this.code;
            this.model.code = "";
            this.model.id = "";

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        numDxsCheck(form, ws, key) {
            let _this = this;

            if (key === undefined) {
                key = "cost";
            }

            form[key] = form[key] + "";

            //先把非数字的都替换掉，除了数字和.
            form[key] = form[key].replace(/[^\d.]/g, "");
            //必须保证第一个为数字而不是.
            form[key] = form[key].replace(/^\./g, "");
            //保证只有出现一个.而没有多个.
            form[key] = form[key].replace(/\.{2,}/g, ".");
            //保证.只出现一次，而不能出现两次以上
            form[key] = form[key]
                .replace(".", "$#$")
                .replace(/\./g, "")
                .replace("$#$", ".");

            //只能输入4个小数
            let c = null;
            switch (ws) {
                case 1:
                    c = /^(\-)*(\d+)\.(\d).*$/;
                case 2:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
                    break;
                case 3:
                    c = /^(\-)*(\d+)\.(\d\d\d).*$/;
                    break;
                case 4:
                    c = /^(\-)*(\d+)\.(\d\d\d\d).*$/;
                    break;
                default:
                    c = /^(\-)*(\d+)\.(\d\d).*$/;
            }
            //只能输入两个小数

            form[key] = form[key].replace(c, "$1$2.$3");
            console.log(form[key]);

            this.$nextTick(function () {
                if (key == "invoicePrice") {
                    this.model.invoicePrice = form[key];
                }
            });
            console.log("invoicePrice:" + _this.model.invoicePrice);
        },
    },
};
</script>
