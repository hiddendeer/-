<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :boolInitData="false">
            <eagle-container title="回款信息/确认">
                <view class="form-detail" v-for="(item, index) in model.projectContractDts" :key="index">
                    <view class="form-detail-title">
                        回款比例(%)：{{item.rate}}
                    </view>
                    <view>
                        应回款金额：{{item.totalPrice|twoDecimal}}
                    </view>
                    <view>
                        已回款金额：{{item.receivePrice|twoDecimal}}
                    </view>
                    <view class="form-detail-titleOne">
                        <view>
                            已开票金额：{{item.invoicePrice|twoDecimal}}
                        </view>
                        <view class="form-detail-titleOne_button" v-if="item.receiveStatus != 3">
                            <u-button type="primary" size="mini" @click="back(item)">确认收款</u-button>
                        </view>
                    </view>
                    <view>
                        回款期限:{{item.payDate|dateFormat}}
                    </view>
                    <view>
                        状态：{{item.receiveStatus|paramsFormat(params.receiveStatus)}}
                    </view>
                    <view>
                        备注:{{item.remarks}}
                    </view>
                    <view>
                        <u-line></u-line>
                    </view>
                </view>
            </eagle-container>
            <eagle-container title="合同信息">
                <eagle-text v-model="model.orderNo" blod label="合同编号"></eagle-text>
                <eagle-text blod label="合同名称" v-model="model.orderName"></eagle-text>
                <eagle-text v-model="model.intentionOrderName" blod label="意向订单"></eagle-text>
                <eagle-text v-model="model.partnerName" blod label="合同单位"></eagle-text>
                <eagle-text v-model="model.areaName" blod label="客户"></eagle-text>
                <eagle-text blod label="合同金额">
                    {{model.totalPrice|twoDecimal}}
                </eagle-text>
                <eagle-text blod label="合同时间">
                    {{model.startDate|dateFormat}}至 {{model.endDate|dateFormat}}
                </eagle-text>
                <eagle-text blod label="是否续签提醒">
                    {{model.isRenewalWarn==true?'是':'否'}}
                </eagle-text>
                <eagle-text blod label="是否生成项目">
                    {{model.projectGenerate==true?'是':'否'}}
                </eagle-text>
                <eagle-text blod label="销售人员" v-model="model.saleChnName"></eagle-text>
                <eagle-text blod label="服务类型" v-model="model.serviceName"></eagle-text>
                <eagle-text blod label="项目说明" v-model="model.orderRemarks"></eagle-text>
                <eagle-text blod label="客户对接人" v-model="model.projectContact"></eagle-text>
                <eagle-text blod label="联系方式" v-model="model.projectMobile"></eagle-text>
                <eagle-text blod label="项目说明" v-model="model.orderRemarks"></eagle-text>
                <eagle-text blod label="合同日期">
                    {{model.filingDate|dateFormat}}
                </eagle-text>
                <eagle-text blod label="合同文件">
                    <eagle-file-upload disabled prop="attachs" v-model="model.attachs" />
                </eagle-text>
                <eagle-text blod label="项目方案或报价">
                    <eagle-file-upload disabled prop="programmeAttachs" v-model="model.programmeAttachs" />
                </eagle-text>
                <eagle-text blod label="其他附件">
                    <eagle-file-upload disabled prop="otherAttachs" v-model="model.otherAttachs" />
                </eagle-text>
                <eagle-text blod label="含税情况">
                    {{model.taxType|paramsFormat(params.taxIncluded)}}
                </eagle-text>
                <eagle-text blod label="回款方式">
                    {{model.method|paramsFormat(params.collectionMode)}}
                </eagle-text>
            </eagle-container>
            <eagle-container title="开票信息">
                <eagle-text v-model="model.payeeName" blod label="开票抬头"> </eagle-text>
                <eagle-text v-model="model.taxNumber" blod label="开票税号"> </eagle-text>
                <eagle-text v-model="model.invoiceAdsTel" blod label="开票地址、电话"> </eagle-text>
                <eagle-text v-model="model.bankAccount" blod label="开户行及账号"> </eagle-text>
                <eagle-text label="开票图片">
                    <eagle-display-image v-model="model.invoiceAttach"></eagle-display-image>
                </eagle-text>
            </eagle-container>
        </eagle-form>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectContract",
            params: {
                projectPartner: [],
                taxIncluded: [],
                collectionMode: [],
                receiveStatus: [],
                projectCategory: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
        this.initParams();
        this.getProjectCategoryList();
    },
    onShow() {
        setTimeout(() => {
            this.$refs.eagleForm.refresh();
        });
    },
    methods: {
        initCallBack(data) {
            if (this.model.isRenewalWarn) {
                this.model.isRenewalWarn = "1";
            } else {
                this.model.isRenewalWarn = "0";
            }

            if (this.model.projectGenerate) {
                this.model.projectGenerate = "1";
            } else {
                this.model.projectGenerate = "0";
            }
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_project_tax_included,site_project_collection_mode,site_project_contract_dts_receive_status"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_tax_included") {
                                _this.params.taxIncluded.push(item);
                            }
                            if (
                                item.paramId == "site_project_collection_mode"
                            ) {
                                _this.params.collectionMode.push(item);
                            }

                            if (
                                item.paramId ==
                                "site_project_contract_dts_receive_status"
                            ) {
                                _this.params.receiveStatus.push(item);
                            }
                        });
                    }
                });
        },

        getProjectCategoryList() {
            let _this = this;

            var url = "site/projectCategory/getList";
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        _this.params.projectCategory.push({
                            id: item.code,
                            name: item.categoryName,
                        });
                    }
                } else {
                }
                uni.hideToast();
            });
        },

        back(row) {
            // this.base.navigateBack();
            let url =
                "/pages/project/projectContractBack/backDetail?id=0&code=" +
                row.code;
            this.base.navigateTo(url);
        },
    },
};
</script>

<style lang="scss">
.detail-block {
    background: #f7f7f7;
}

.customer-block .custom-style {
    background: #fff;
    color: #2979ff;
    font-size: 14px;
    border-width: 0px;
    line-height: 28px;
}

.form-detail {
    // border-bottom: 1px solid #ddd;
    // margin-bottom: 10px;
    color: $font-color-base;
    line-height: 24px;
    padding: 0 30rpx;

    .form-detail-title {
        color: #494a4c;
        line-height: 28px;
    }

    .form-detail-titleOne {
        color: #494a4c;
        line-height: 28px;
        display: flex;
        justify-content: space-between;
    }

    .form-detail-titleOne_button {
        display: flex;
        column-gap: 5px;
    }
}

.m {
    margin-right: 5px;
    color: #2979ff;
}

.other-font {
    color: #303133;
    font-size: 32rpx;
}
</style>
