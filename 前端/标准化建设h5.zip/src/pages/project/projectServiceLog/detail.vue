<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='130' :errorType="errorType" labelWidth="150" labelAlign='left' :initUrl="initUrl" marginBottom="90px">
            <eagle-container title="服务内容">
                <eagle-choose-input :hasSearch="false" :showChoose="false" :queryParams="contentQueryParams" title="服务内容" btnName="选择" headTitle="选择服务内容" idField="code" style="border-bottom:0px;" textField="hiddenDangerDesc" :names.sync="logStr" queryUrl="site/projectConsultationTask/getList" @callBackChoosedData="callBackChoosedService">
                    <template v-slot:popupBody='scope'>
                        <view>
                            <view class="double-line c333">服务内容：{{ scope.item.taskName }}</view>
                            <view class="double-line">服务说明：{{ scope.item.description }}</view>
                            <view style="line-height: 36px;">
                                <view class="div-button-group">
                                    <view class="div-button-left">已完成</view>
                                    <view class="div-button-right">{{ scope.item.finishCnt }}次</view>
                                </view>
                                <view class="div-button-group" v-if="scope.item.totalCnt > 0">
                                    <view class="div-button-left">需完成</view>
                                    <view class="div-button-right">{{ scope.item.totalCnt }}次</view>
                                </view>
                            </view>
                        </view>
                    </template>
                </eagle-choose-input>
                <template v-if="taskLogDtsList && taskLogDtsList.length > 0">
                    <view v-for="(item, index) in taskLogDtsList" :key="index" class="div-task-log-dts-list">
                        <view class="eagle-flex-between">
                            <view class="double-line auto-flex text-indent10" :title="item.taskName">{{ index + 1 }}.
                                {{ item.taskName }}</view>
                            <!-- <view>
                                <eagle-switch title="是否完成" v-model="item.finishedStatus" label-position="left"
                                    size="40" />
                            </view> -->
                            <view class="w40">
                                <uni-icons class="del-btn" color='#FF0000' type="trash-filled" size="22" @click="handlerDel(item, index)">
                                </uni-icons>
                            </view>
                        </view>
                        <view>
                            <eagle-input title="" v-model="item.taskRemark" :placeholder="'请输入【' + item.taskName + '】的任务说明'" prop="serviceConclusion" labelPosition="top" type='textarea' labelWidth="150" />
                        </view>
                    </view>
                </template>
            </eagle-container>
            <eagle-container>
                <template v-if="modulesId == 'host'">
                    <eagle-choose-input title="重大隐患" btnName="选择隐患" dataType="list" headTitle="选择隐患" idField="code" style="border-bottom:0px;" textField="hiddenDangerDesc" controller="site/dangerCheckTaskDetail" :names.sync="dangerStr" @callBackChoosedData="callBackChoosedData">
                        <template v-slot:popupBody='scope'>
                            <view>
                                <view class="double-line">隐患描述：{{ scope.item.hiddenDangerDesc }}</view>
                                <view class="double-line">隐患区域：{{ scope.item.correctiveArea }}</view>

                            </view>
                        </template>
                    </eagle-choose-input>
                    <view class="div-dangerList">
                        <template v-for="(item, index) in model.projectConsultationTaskLogDangerList">
                            <eagle-row-card style="padding:0px;">
                                <view class="eagle-flex-between" :class="index < model.projectConsultationTaskLogDangerList.length - 1 ? 'eagle-flex-between borderBottom' : 'eagle-flex-between'">
                                    <view class="list-body">
                                        <eagle-text class="double-line" title="隐患描述" key="gistSource" v-model="item.hiddenDangerDesc" />
                                        <eagle-text class="double-line" title="隐患区域" key="correctiveArea" v-model="item.correctiveArea" />
                                    </view>
                                    <view class="eagle-v-middle">
                                        <uni-icons class="del-btn" color='#FF0000' type="trash-filled" size="22" @click="handleDeleteDanger(index,'log')">
                                        </uni-icons>
                                    </view>
                                </view>
                            </eagle-row-card>
                        </template>
                    </view>
                </template>
                <template v-else>
                    <eagle-choose-input title="检查任务" btnName="选择任务" dataType="list" headTitle="选择任务" idField="code" style="border-bottom:0px;" textField="checkTaskName" controller="danger/jgDangerTask" :names.sync="dangerStr" @callBackChoosedData="callBackChoosedData">
                        <template v-slot:popupBody='scope'>
                            <view>
                                <view class="double-line">任务名称：{{ scope.item.checkTaskName }}</view>
                                <view class="double-line">被检查单位：{{ scope.item.enterpriseName }}</view>
                                <view class="double-line">检查人：{{ scope.item.checkNames }}</view>
                            </view>
                        </template>
                    </eagle-choose-input>
                    <view class="div-dangerList">
                        <template v-for="(item, index) in model.checkList">
                            <eagle-row-card style="padding:0px;border-bottom:1px solid #dfdfdf;">
                                <view class="eagle-flex-between" :class="index < model.projectConsultationTaskLogDangerList.length - 1 ? 'eagle-flex-between borderBottom' : 'eagle-flex-between'">
                                    <view class="list-body">
                                        <eagle-text class="double-line" title="任务名称" key="checkTaskName" v-model="item.checkTaskName" />
                                        <eagle-text class="double-line" title="被检查单位" key="enterpriseName" v-model="item.enterpriseName" />
                                    </view>
                                    <view class="eagle-v-middle">
                                        <uni-icons class="del-btn" color='#FF0000' type="trash-filled" size="22" @click="handleDeleteDanger(index,'danger')">
                                        </uni-icons>
                                    </view>
                                </view>
                            </eagle-row-card>
                        </template>
                    </view>
                </template>
            </eagle-container>
            <eagle-container>
                <eagle-input v-model="model.serviceConclusion" title="其他服务" prop="serviceConclusion" labelPosition="top" type='textarea' labelWidth="150" />
                <eagle-date v-model="model.serviceDate" required title="服务日期" prop="serviceDate" labelWidth="150" labelPosition="top"></eagle-date>
                <eagle-input v-model="model.remarks" title="其他说明" prop="Remarks" labelPosition="top" type='textarea' labelWidth="150" />
                <eagle-upload title="照片" :maxCount="1" prop="photo" v-model="model.photo" labelPosition="top" labelWidth="150" />
                <eagle-file-upload title="附件" prop="attachs" v-model="model.attachs" labelPosition="top" labelWidth="150">
                </eagle-file-upload>
                <eagle-choose-user prop="serviceUserName" :isMult="true" title="服务人员" required v-model="model.serviceUserName" :names.sync="model.serviceChnName"></eagle-choose-user>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view v-if="look">
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectConsultationTaskLog",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            initUrl: "",
            deletable: true,
            look: true,
            taskLogDtsList: [],
            dialogShow: false,
            dangerStr: "",
            logStr: "",
            defaultStr: "请选择重大隐患",
            dangerQueryParams: {},
            contentQueryParams: {
                projectCode: "",
            },
            modulesId: "",
        };
    },
    created() {
        this.modulesId = this.$route.query.modulesId;
        this.contentQueryParams.projectCode = this.$route.query.projectId ?? "";
    },
    methods: {
        initCallBack(data) {
            this.model = data;
            this.model.projectCode = this.$route.query.projectId ?? "";
            this.model.mainCode = this.$route.query.taskCode ?? "";
        },
        post(op) {
            let _this = this;
            let projectConsultationTaskLogDtsList = [];
            for (var i = 0; i < _this.taskLogDtsList.length; i++) {
                let currentValue = _this.taskLogDtsList[i];

                if (!currentValue.taskRemark) {
                    let msgStr =
                        "第" +
                        (i + 1) +
                        "条【" +
                        currentValue.taskName +
                        "】的任务说明不能为空";
                    this.$refs.eagleForm.errorMsg(msgStr);
                    return;
                }
                currentValue.processStatus = currentValue.finishedStatus
                    ? 100
                    : 2; //100完成，其他未完成
                projectConsultationTaskLogDtsList.push(currentValue);
            }
            _this.model.projectConsultationTaskLogDtsList =
                projectConsultationTaskLogDtsList;

            _this.$refs.eagleForm.post({
                successCallback: function (res) {
                    _this.back();
                },
            });
        },
        back() {
            this.base.navigateBack();
        },
        callBackChoosedData(dataList) {
            let _this = this;
            if (dataList && dataList.length > 0) {
                _this.dangerStr = "已添加" + dataList.length + "条";
                if (_this.modulesId == "host") {
                    _this.dangerStr = _this.dangerStr + "隐患";
                } else {
                    _this.dangerStr = _this.dangerStr + "检查任务";
                }
            } else {
                _this.dangerStr = _this.defaultStr;
            }

            for (var i = 0; i < dataList.length; i++) {
                let isPush = false;
                //管家服务填报是选择隐患
                //隐患排查服务是选则任务

                if (_this.modulesId == "host") {
                    isPush =
                        _this.model.projectConsultationTaskLogDangerList.filter(
                            function (currentValue) {
                                return (
                                    dataList[i].code == currentValue.detailCode
                                );
                            }
                        ).length > 0
                            ? false
                            : true;
                    if (isPush) {
                        _this.model.projectConsultationTaskLogDangerList.push({
                            projectCode: _this.projectCode,
                            detailCode: dataList[i].code,
                            hiddenDangerDesc: dataList[i].hiddenDangerDesc,
                            correctiveAdvise: dataList[i].correctiveAdvise,
                            correctiveArea: dataList[i].correctiveArea,
                        });
                    }
                } else {
                    isPush =
                        _this.model.checkList.filter(function (currentValue) {
                            return (
                                dataList[i].code == currentValue.checkTaskCode
                            );
                        }).length > 0
                            ? false
                            : true;
                    if (isPush) {
                        _this.model.checkList.push({
                            checkTaskCode: dataList[i].code,
                            checkTaskName: dataList[i].checkTaskName,
                            enterpriseCode: dataList[i].enterpriseCode,
                            enterpriseName: dataList[i].enterpriseName,
                            checkCodes: dataList[i].checkCodes,
                            checkNames: dataList[i].checkNames,
                            checkAttachs: dataList[i].checkAttachs,
                            verifyAttachs: dataList[i].verifyAttachs,
                        });
                    }
                }
            }
        },
        handlerDel(item, index) {
            let _this = this;
            uni.showModal({
                title: "询问",
                content: "您确定要删除此项吗？",
                success: async (res) => {
                    if (res.confirm) {
                        _this.taskLogDtsList.splice(index, 1);
                        _this.setLogStr();
                    }
                },
            });
        },
        callBackChoosedService(data) {
            let _this = this;
            if (data && data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    let hasLog =
                        _this.taskLogDtsList.filter(function (currentValue) {
                            return data[i].code == currentValue.taskCode;
                        }).length > 0
                            ? true
                            : false;

                    if (!hasLog) {
                        _this.taskLogDtsList.push({
                            taskCode: data[i].code,
                            projectCode: _this.model.projectCode,
                            taskName: data[i].taskName,
                            taskRemark: data[i].description,
                            finishedStatus: false,
                        });
                    }
                }
                this.setLogStr();
            }
        },
        setLogStr() {
            let _this = this;
            if (_this.taskLogDtsList && _this.taskLogDtsList.length > 0) {
                _this.logStr =
                    "已添加" + _this.taskLogDtsList.length + "条服务内容";
            } else {
                _this.logStr = "请选择服务内容";
            }
        },
        handleChooseDanger() {
            // this.$refs.chooseDanger.show();
            // let config = {};
            // config.selectList =
            //     _this.model.projectConsultationTaskLogDangerList.filter(
            //         function (currentValue) {
            //             return currentValue.detailCode;
            //         }
            //     );
            // _this.$refs.chooseDangerList.show(config);
        },
        handleDeleteDanger(index, type) {
            let _this = this;
            uni.showModal({
                title: "询问",
                content: "您确定要删除此项吗？",
                success: async (res) => {
                    if (res.confirm) {
                        if (type == "log") {
                            _this.model.projectConsultationTaskLogDangerList.splice(
                                index,
                                1
                            );

                            if (
                                _this.model.projectConsultationTaskLogDangerList
                                    .length > 0
                            ) {
                                _this.dangerStr =
                                    "已添加" +
                                    _this.model
                                        .projectConsultationTaskLogDangerList
                                        .length +
                                    "条隐患";
                            } else {
                                _this.dangerStr = _this.defaultStr;
                            }
                        } else {
                            _this.model.checkList.splice(index, 1);

                            if (_this.model.checkList.length > 0) {
                                _this.dangerStr =
                                    "已添加" +
                                    _this.model.checkList.length +
                                    "条检查";
                            } else {
                                _this.dangerStr = _this.defaultStr;
                            }
                        }
                    }
                },
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.div-task-log-dts-list {
    border-bottom: 1px solid #e4e7ed;
    padding: 20rpx 0rpx;
}

.body .div-task-log-dts-list:last-child {
    border-bottom: none;
}

.div-dangerInfo {
    border-bottom: 1px solid #e4e7ed;
    padding: 10px 10px;
}

.borderBottom {
    border-bottom: 1px solid #e4e7ed;
}

.list-body {
    flex: 1;
}

.span_label {
    padding: 0px 9px;
    font-weight: 600;
    white-space: nowrap;
    width: fit-content;
}

.div-button-group {
    margin-right: 10px;
    float: left;
    font-size: 12px;

    .div-button-left {
        background: #ffffff;
        border: 1px solid #dcdfe6;
        display: inline-block;
        padding: 7px 10px;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        border-color: #dcdfe6;
        color: #606266;
    }

    .div-button-right {
        color: #1890ff;
        border: 1px solid #b3d8ff;
        background-color: #e8f4ff;
        display: inline-block;
        padding: 7px 15px;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        border-left: 0px;
    }
}
</style>
