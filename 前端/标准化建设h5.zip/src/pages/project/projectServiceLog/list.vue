<template>
    <view class="sever-log-container eagle-layer">
        <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller"
            :margin-bottom="60">
            <view slot="search">
                <view class="search">
                    <eagle-search placeholder="请输入其他服务进行模糊搜索" @search="onSearch" v-model="conditions.logName.value">
                    </eagle-search>
                </view>
            </view>
            <view slot="list">
                <view class="list-wrap">
                    <view class="uni-media-cell" v-if="logList.length > 0">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body">
                                <view class="card-content">
                                    <u-time-line>
                                        <u-time-line-item nodeTop="15" v-for="(item, index) in logList" :key='index'>
                                            <template v-slot:content>
                                                <template
                                                    v-if="item.serviceConclusion.indexOf(conditions.logName.value) >= 0">
                                                    <view @click='handlerViewClick(item)'>
                                                        <view class="line-item-title">
                                                            <view style="display: flex;">
                                                                <view style="margin-right: 30rpx;">
                                                                    {{ item.createDate | dateFormat }}</view>
                                                                <view class="view-text">{{ item.logName }}</view>
                                                            </view>
                                                        </view>
                                                        <view class="line-item-content">
                                                            <view class="line-item-content-item">
                                                                <view class="left">{{ item.createDate | timeFormat }}
                                                                </view>
                                                                <view class="right">{{ item.createChnName || "" }}
                                                                </view>
                                                            </view>
                                                            <view class="">
                                                                <view
                                                                    v-if="item.projectConsultationTaskLogDtsList.length > 0 || item.checkList.length > 0">
                                                                    服务内容：
                                                                    <template v-if="modulesId == 'host'"
                                                                        v-for="(children, index) in item.projectConsultationTaskLogDtsList">
                                                                        {{ (index + 1) }} : {{ children.taskName }}；
                                                                    </template>
                                                                    <template v-else
                                                                        v-for="(children, index) in item.checkList">
                                                                        {{ (index + 1) }} : {{ children.checkTaskName
                                                                        }}；
                                                                    </template>
                                                                </view>
                                                                其他服务： {{ item.serviceConclusion }}
                                                            </view>
                                                        </view>
                                                    </view>
                                                </template>
                                            </template>
                                        </u-time-line-item>
                                    </u-time-line>
                                </view>
                            </view>
                        </view>

                    </view>
                </view>
            </view>
        </eagle-page-list>

        <tabbar-host-index v-if="modulesId == 'host'"></tabbar-host-index>
        <tabbar-danger-jg-index v-else-if="modulesId == 'dangerJg'"></tabbar-danger-jg-index>

    </view>
</template>


<script>
import TabbarDangerJgIndex from "@/pages/components/tabbar/tabbar-dangerJg-index.vue";
import TabbarHostIndex from "@/pages/components/tabbar/tabbar-host-index.vue";
export default {
    components: { TabbarDangerJgIndex, TabbarHostIndex },
    onShow() {
        // this.intitLogCard();
    },
    data() {
        return {
            logList: [],
            logCount: 0,
            controller: "site/projectConsultationTaskLog",
            conditions: {
                logName: {
                    value: "",
                    operate: "like",
                },
            },
            modulesId: "",
        };
    },
    created() {
        this.modulesId = this.$route.query.modulesId;
        console.log(this.modulesId);
    },
    mounted() {
        this.intitLogCard();
    },
    methods: {
        initList(data) {
            this.logList = data;
        },
        onSearch() { },
        intitLogCard() {
            var params = {
                projectCode: this.$route.query.projectId ?? "",
            };
            if (this.conditions.logName.value) {
                params.conditions = [
                    { name: "logName", value: this.conditions.logName.value },
                ];
                // JSON.stringify();
            }
            // params.conditions = encodeURI(JSON.stringify(this.conditions));
            var _this = this;

            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: params.conditions,
                });
            });

            debugger;
            // this.common
            //     .get("/site/projectConsultationTaskLog/getPageData", params)
            //     .then((res) => {
            //         if (res.code == 200) {
            //             _this.logList = res.data;
            //             _this.logCount = res.data.length;
            //         }
            //     });
        },

        handlerViewClick(item) {
            let url =
                "pages/project/projectServiceLog/view?id=" +
                item.id +
                "&modulesId=" +
                this.$route.query.modulesId;
            this.base.navigateTo(url);
        },
    },
};
</script>

<style lang="scss">
.sever-log-container {
    width: 100vw;
    height: calc(100vh - 80px);
    box-sizing: border-box;

    .content {
        background: #ffffff;
        margin-top: 10rpx;
        padding: 20rpx 40rpx 0;
        box-sizing: border-box;
    }

    /deep/.u-time-axis {
        margin-left: 15rpx;
    }

    .line-item-title {
        display: flex;
        justify-content: space-between;
        margin-bottom: 25rpx;
    }

    .line-item-content {
        width: 100%;
        background: #f1f1f1;
        padding: 30rpx 20rpx;
        box-sizing: border-box;
        color: #666;

        .line-item-content-item {
            display: flex;
            margin-bottom: 15rpx;

            .left {
                width: 100rpx;
                height: 60rpx;
                line-height: 60rpx;
                text-align: center;
                background: #31bdb4;
                border-top-left-radius: 10rpx;
                border-bottom-left-radius: 10rpx;
                color: #ffffff;
                font-weight: 600;
            }

            .right {
                width: 150rpx;
                height: 60rpx;
                line-height: 60rpx;
                text-align: center;
                border: 1px solid #31bdb4;
                box-sizing: border-box;
                color: #31bdb4;
                font-weight: 600;
                border-top-right-radius: 10rpx;
                border-bottom-right-radius: 10rpx;
            }
        }
    }

    .view-text {
        /**
		思路：
		1.设置inline-block属相
		2.强制不换行
		3.固定高度
		4.隐藏超出部分
		5.显示“……”
	  */
        display: inline-block;
        white-space: nowrap;
        width: 400rpx;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
</style>
