<template>
    <view class="customer-block-detail">

        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='130' :errorType="errorType" selfHeight='calc(100vh - 125px)'>
            <eagle-container>
                <fast-choose-company label="客户名称" required prop="name" v-model="model.name" @changed="buttonFastSearch" />
                <eagle-input v-model="model.organizationCode" title="统一社会信用代码" prop="organizationCode" />

                <eagle-input v-model="model.legalPerson" title="法定代表人" prop="legalPerson" />
                <eagle-input v-model="model.contactNumber" title="联系电话" prop="contactNumber" />

                <eagle-input v-model="model.natureOfBusiness" type="textarea" title="经营范围" prop="natureOfBusiness" />

                <eagle-select-item required v-model="model.applyProfessionName" title="所属行业" labelWidth="130" @industryInformation='industryInformation'></eagle-select-item>

                <eagle-address required v-model="model.belongArea" title="所属地区" labelWidth="130"></eagle-address>

                <eagle-input v-model="model.address" title="详细地址" prop="address" />
                <eagle-radio-group v-model="model.enterpriseScale" title="企业规模" prop="enterpriseScale" :data-source="params.enterpriseScale" v-if="params.enterpriseScale.length > 0" />
            </eagle-container>

            <!-- <view style="background: #ffffff;margin: 10rpx 0;">
                <view style="padding: 0 30rpx;background: #f3f4f6;">
                    <uni-view class="u-form-item--left" style="width: 100%; flex: 0 0 100%">
                        <uni-view data-v-006449ec="" class="u-form-item--left__content">
                            <uni-view data-v-006449ec="" class="u-form-item--left__content__label other-font" style="justify-content: flex-start;height: 50rpx;">开票信息</uni-view>
                        </uni-view>
                    </uni-view>
                </view>
            </view> -->
            <eagle-container>
                <template slot="title">开票信息</template>
                <eagle-input title="开票抬头" v-model="model.payeeName" prop="payeeName" />
                <eagle-input title="开票税号" v-model="model.taxNumber" prop="taxNumber" />
                <eagle-input title="开票地址、电话" v-model="model.invoiceAdsTel" prop="invoiceAdsTel" />
                <eagle-input title="开户行及账号" v-model="model.bankAccount" prop="bankAccount" />
                <eagle-input title="企业人数" v-model="model.empCnt" prop="empCnt" />
                <eagle-radio-group v-model="model.sourceType" title="客户来源" prop="sourceType" :data-source="params.sourceType" v-if="params.sourceType.length > 0" required />
                <eagle-file-upload :maxCount="3" title="开票图片" prop="invoiceAttach" v-model="model.invoiceAttach" />
            </eagle-container>

            <eagle-container>
                <template slot="title">
                    <view style="display: flex;justify-content: space-between;">
                        <view style="flex:1;">客户联系人</view>

                    </view>
                </template>
                <template slot="otherSolot">
                    <view class="m-button" @click="addCustomerUser">添加客户联系人
                    </view>
                </template>
                <eagle-item-kong :isItem="model.projectCustomerUsers"></eagle-item-kong>
                <view class="form-detail" v-for="(item, index) in model.projectCustomerUsers" :key="index">

                    <view class="form-detail-title">客户联系人：{{ item.contact }}</view>
                    <view class="form-detail-title">
                        联系方式：{{ item.mobile }}
                    </view>
                    <view class="form-detail-titleOne">
                        <view>岗位:{{ item.post }}</view>
                        <view class="form-detail-titleOne_button">
                            <u-button type="error" size="mini" @click="deleteCustomerUser(item, index)">删除</u-button>
                            <u-button type="primary" size="mini" @click="updateCustomerUser(item, index)">编辑</u-button>
                        </view>
                    </view>
                    <view class="form-detail-title">
                        邮箱:{{ item.email }}
                    </view>
                    <view class="form-detail-title">
                        备注：{{ item.remarks }}
                    </view>

                    <view>
                        <u-line></u-line>
                    </view>

                </view>
                <view v-if="!model.projectCustomerUsers">
                </view>
            </eagle-container>
        </eagle-form>

        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <popup-customer-user @customerCallBack="customerCallBack" ref="customerUserForm"></popup-customer-user>
        <u-toast ref="uToast" />
    </view>
</template>
<script>
import UFormItem from "../../../uview-ui/components/u-form-item/u-form-item.vue";
import PopupCustomerUser from "../../components/project/projectCustomer/popupCustomerUser.vue";
import fastChooseCompany from "@/pages/project/projectCompany/components/fast-choose-company";

export default {
    components: {
        PopupCustomerUser,
        UFormItem,
        fastChooseCompany,
    },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectCustomer",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
            // showCustomerUser: false,
        };
    },
    created() {
        this.model.id = this.$route.query.id;
        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增客户",
            });
        }
    },
    onReady() {
        var _this = this;
        _this.initParams();
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            if (this.model.isPublic) {
                this.model.isPublic = "1";
            } else {
                this.model.isPublic = "0";
            }
        },
        industryInformation(val) {
            (this.model.applyProfessionName = val.industryName),
                (this.model.applyProfession = val.industryIap);
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_project_enterprise_scale,site_project_source_type,site_project_customer_track_mode"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId == "site_project_enterprise_scale"
                            ) {
                                _this.params.enterpriseScale.push(item);
                            }
                            if (item.paramId == "site_project_source_type") {
                                _this.params.sourceType.push(item);
                            }

                            if (
                                item.paramId ==
                                "site_project_customer_track_mode"
                            ) {
                                _this.params.trackMode.push(item);
                            }
                        });
                    }
                });
        },
        post(op) {
            let _this = this;

            if (this.model.isPublic == "1") {
                this.model.isPublic = true;
            } else {
                this.model.isPublic = false;
            }

            if (this.model.projectCustomerUsers.length <= 0) {
                this.$refs.uToast.show({
                    title: "请添加客户联系人",
                    type: "error",
                });
                return;
            }

            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        addCustomerUser() {
            // var fruits = ["Banana", "Orange", "Apple"];
            // fruits.splice(2,1);
            // console.log(fruits)
            // fruits.splice(2,0);
            // console.log(fruits)

            setTimeout(() => {
                this.$refs.customerUserForm.show(null, null);
                // this.showCustomerUser = true;
            });
        },
        deleteCustomerUser(item, index) {
            var _this = this;
            uni.showModal({
                title: "提示",
                content: "您确定要删除客户联系人【" + item.contact + "】吗？",
                success: (res) => {
                    if (res.confirm) {
                        _this.model.projectCustomerUsers.splice(index, 1);
                    }
                },
            });
        },
        updateCustomerUser(item, index) {
            var _this = this;
            setTimeout(() => {
                this.$refs.customerUserForm.show(item, index);
            });
        },
        customerCallBack(data) {
            if (data.indexValue != null) {
                var dataIndex = data.indexValue;
                this.model.projectCustomerUsers.splice(dataIndex, 1, data);
            } else {
                this.model.projectCustomerUsers.push(data);
            }
        },
        bangding() {
            this.model.payeeName = this.model.name;
        },
        buttonFastSearch(obj) {
            this.model.name = obj.name;
            this.model.taxNumber = obj.organizationCode;
            this.model.organizationCode = obj.organizationCode;
            this.model.legalPerson = obj.principal;
            this.model.introduce = obj.introduce;
            this.model.address = obj.address;
            this.model.natureOfBusiness = obj.natureOfBusiness;
            // _this.common
            //     .get(
            //         "/site/projectCustomer/getDataFromGuanguanTyByName/" +
            //             _this.model.name
            //     )
            //     .then((res) => {
            //         if (res.code == 200 && res.data) {
            //             _this.model.organizationCode =
            //                 res.data.organizationCode;
            //             _this.model.address = res.data.address;
            //             _this.model.legalPerson = res.data.legalPerson;
            //             _this.model.natureOfBusiness =
            //                 res.data.natureOfBusiness;
            //             _this.model.taxNumber = res.data.organizationCode;
            //         }
            //     });
        },
    },
};
</script>
<style lang="scss" scoped>
.customer-block-detail {
    .title-label {
        justify-content: flex-start;
        height: 25px;
        margin: 5px 0px;
        flex: 1;
    }

    .view-title {
        display: flex;
    }

    .div_buttonFastSearch {
        display: block;
        color: rgb(41, 121, 255);
    }

    .detail-block {
        background: #f7f7f7;
    }

    .customer-block .custom-style {
        background: #fff;
        color: #2979ff;
        font-size: 14px;
        border-width: 0px;
        line-height: 28px;
    }

    .form-detail {
        // border-bottom: 1px solid #ddd;
        // margin-bottom: 10px;
        color: $font-color-base;
        line-height: 24px;
        padding: 0 30rpx;

        .form-detail-title {
            color: #494a4c;
            line-height: 28px;
        }

        .form-detail-titleOne {
            color: #494a4c;
            line-height: 28px;
            display: flex;
            justify-content: space-between;
        }

        .form-detail-titleOne_button {
            display: flex;
            column-gap: 5px;
        }
    }

    .m-button {
        margin-right: 5px;
        color: #2979ff;
        // line-height: 70rpx;
    }

    .other-font {
        color: #303133;
        font-size: 32rpx;
    }
}
</style>
