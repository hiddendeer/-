<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType">
            <eagle-container>
                <eagle-choose-user title="需要转移的人" v-model="model.saleUserName" :names.sync="model.saleChnName" prop="shareUserName" required></eagle-choose-user>
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
        <u-toast ref="uToast" />
    </view>

</template>
<script>
import EagleContainer from "../../../components/eagle-container/eagle-container.vue";
export default {
    components: { EagleContainer },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectCustomer",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
    },
    onReady() {
        var _this = this;
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            // saleChnName: "田磊"
            // saleUserName: "5faf9f7ad182e2d5f07e1e1c59bb43f7"

            this.model.saleChnName = "";
            this.model.saleUserName = "";
        },

        post(op) {
            let _this = this;

            if (this.model.saleUserName == "") {
                this.$refs.uToast.show({
                    title: "请选择需要转移的人",
                    type: "error",
                });

                return;
            }

            this.$refs.eagleForm.post({
                needValid: false,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
