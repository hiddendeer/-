<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" :byCode="false">
            <eagle-container title="客户追踪详情">
                <eagle-text v-model="name" title="客户名称" prop="name"></eagle-text>
                <eagle-text v-model="model.contact" title="联系人" prop="contact"></eagle-text>
                <eagle-text v-model="model.mobile" title="联系方式" prop="mobile"></eagle-text>
                <eagle-text :value="model.mode|paramsFormat(params.trackMode)" title="跟踪方式" prop="mode"></eagle-text>
                <eagle-text v-model="model.chnName" title="跟踪人" prop="chnName"></eagle-text>
                <eagle-text :value="model.trackDate|dateFormat" title="跟踪日期" prop="trackDate"></eagle-text>
                <eagle-text :value="model.nextTrackDate|dateFormat" title="下次跟踪日期" prop="nextTrackDate"></eagle-text>
                <eagle-text v-model="model.result" title="跟踪结果" prop="result"></eagle-text>
            </eagle-container>
        </eagle-form>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectCustomerTrack",
            name: "",
            code: "",
            orderNo: "",
            params: {
                trackMode: [],
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id;
        // this.name = this.$route.query.name;
        this.code = this.$route.query.code;
        this.orderNo = this.$route.query.orderNo;
        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增客户跟踪",
            });
        }
    },
    onReady() {
        this.initParams();
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            if (this.orderNo) {
                this.model.intentionOrderCode = this.orderNo;
            }
            this.model.mode = this.params.trackMode[0].id;

            this.getDataByCode();
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_project_customer_track_mode")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId ==
                                "site_project_customer_track_mode"
                            ) {
                                _this.params.trackMode.push(item);
                            }
                        });
                    }
                });
        },

        customerCallBack() {},

        getDataByCode() {
            let _this = this;

            var url = "site/projectCustomer/getDataByCode/" + this.code;
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    if (res.data) {
                        // _this.model.
                        _this.name = res.data.name;

                        _this.model.customerCode = res.data.code;
                        _this.model.customerName = res.data.name;

                        if (res.data.projectCustomerUsers.length > 0) {
                            var item = res.data.projectCustomerUsers[0];
                            _this.model.contact = item.contact;
                            _this.model.mobile = item.mobile;
                        }
                    }
                } else {
                }
                uni.hideToast();
            });
        },

        showOrde() {},

        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    let url =
                        "/pages/project/myProjectCustomer/trackList?code=" +
                        _this.code +
                        "&orderNo=" +
                        _this.orderNo;
                    _this.base.navigateTo(url);
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
