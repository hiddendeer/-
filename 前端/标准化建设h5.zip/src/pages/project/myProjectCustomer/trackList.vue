<template>
    <view class="eagle-layer">
        <eagle-page-list ref="eaglePageList" :queryParams="queryParams" @initList="_initList" :conditions="conditions" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="" :boolInitData="false">
            <view slot="search" class="search-slot">
                <eagle-search placeholder="请输入客户名称进行搜索" @search="search" v-model="conditions.customerName.value" :clearabled="true" :show-action="false" @clear="search"></eagle-search>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/myProjectCustomer/trackView?id='+item.id +'&code='+code+'&orderNo='+orderNo)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{item.customerName}}
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            <text>跟踪日期 : {{item.trackDate|dateFormat}}</text>
                        </view>
                        <view>
                            <text>跟踪结果 : {{item.result}} </text>
                        </view>
                        <view>
                            <text>联系人 : {{item.contact}} </text>
                        </view>
                        <view>
                            <text>联系方式 : {{item.mobile}} </text>
                        </view>
                        <view>
                            <text>下次跟踪日期 : {{item.nextTrackDate|dateFormat}} </text>
                        </view>

                        <view v-if="orderNo!=''">
                            <text>预计成单率% : {{item.rate}} </text>
                        </view>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="error" size="mini" @click="del(item.id)">删除</u-button>
                        <u-button type="primary" size="mini" @click="goto('/pages/project/myProjectCustomer/trackDetail?id='+item.id +'&code='+code+'&orderNo='+orderNo)">
                            编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick="goto('/pages/project/myProjectCustomer/trackDetail?id=0'+'&code='+code+'&orderNo='+orderNo)">
        </eagle-fab>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            searchValue: {
                accidentType: "",
                name: "",
            },
            controller: "/site/projectCustomerTrack",
            data: [],
            code: "",
            name: "",
            orderNo: "",
            clearabled: true,
            conditions: {
                customerName: {
                    value: "",
                },
            },
            queryParams: {
                customerCode: "",
            },
            params: {
                trackMode: [],
            },
        };
    },
    onReady() {
        this.initParams();
    },

    onShow() {
        this.code = this.$route.query.code;
        this.queryParams.customerCode = this.code;
        this.search();
    },
    created() {
        if (this.$route.query.orderNo) {
            this.orderNo = this.$route.query.orderNo;

            uni.setNavigationBarTitle({
                title: "意向订单客户跟踪",
            });
        }
    },
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.accidentType = "";
            this.searchValue.name = "";
        },
        search() {
            this.queryPage();
        },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_project_customer_track_mode")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId ==
                                "site_project_customer_track_mode"
                            ) {
                                _this.params.trackMode.push(item);
                            }
                        });
                    }
                });
        },
        imgError(e) {},
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },

        getSuplusDate(deadline) {
            if (deadline == null || deadline == "") {
                return `无跟踪记录`;
            } else {
                var now = new Date();
                let day = this.getDaysBetween(now, deadline);
                if (day >= 0) {
                    return `<span style='color:#E6A23C'>还剩${day}天</span>`;
                } else {
                    return `<span style='color:#dd6161'>超过${
                        day * -1
                    }天未跟踪</span>`;
                }
            }
        },
        getDaysBetween(date1, date2) {
            var startDate = Date.parse(this.common.dateFormat(date1));

            var endDate = Date.parse(this.common.dateFormat(date2));
            // Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
    },
};
</script>
