<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="publicCustomerList">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="searchValue" placeholder="请输入客户名称进行模糊搜索"> </eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/myProjectCustomer/view?id=' + item.id)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.name }}
                        <template slot="icon">
                            {{ item.sourceType | splitParamsFormat(params.sourceType) }}
                        </template>
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            <text>地址 : {{ item.address }} </text>
                        </view>
                        <view>
                            <text>创建人 : {{ item.createChnName }} </text>
                        </view>
                        <view>
                            <text>创建时间 : {{ item.createDate | dateFormat }} </text>
                        </view>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="success" size="mini" @click="updatePick(item)">认领</u-button>
                        <u-button type="error" size="mini" @click="del(item.id)">删除</u-button>
                        <u-button type="primary" size="mini" @click="goto('/pages/project/myProjectCustomer/distribution?id=' + item.id)">分配</u-button>
                    </template>
                </eagle-row-card>
                <!-- <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                    <view class="uni-media-list" @click="goto('/pages/project/myProjectCustomer/view?id='+item.id)">
                        <view class="uni-media-list-body">
                            <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                <eagle-girdrow-block>{{item.name}}</eagle-girdrow-block>
                                <eagle-girdrow-block type="warn" style="width: 90px;">
                                    <span style="text-align: right;width: 90px;">{{item.sourceType|splitParamsFormat(params.sourceType)}}</span>
                                </eagle-girdrow-block>
                            </eagle-girdrow-base>

                            <eagle-girdrow-base>
                                <view>
                                    <text>地址 : {{item.address}} </text>
                                </view>
                                <view>
                                    <text>创建人 : {{item.createChnName}} </text>
                                </view>
                                <view>
                                    <text>创建时间 : {{item.createDate|dateFormat}} </text>
                                </view>
                            </eagle-girdrow-base>
                        </view>
                    </view>
                    <eagle-grid-botton>
                        <u-icon class="eagle-blue eagle-row-span" @click="updatePick(item)" name="man-add-fill" label="认领" />
                        <u-icon class="eagle-blue eagle-row-span" name="order" label="分配" @click="goto('/pages/project/myProjectCustomer/distribution?id='+item.id)" />
                        <u-icon @click="del(item.id)" class="eagle-red eagle-row-span" name="trash" label="删除" />
                    </eagle-grid-botton>
                </view> -->
            </view>
        </eagle-page-list>
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            searchValue: "",
            controller: "/site/projectCustomer",
            data: [],
            clearabled: true,
            conditions: [],
            params: {
                sourceType: [],
                happenSide: [],
            },
            // source: "",
            // queryParams: {
            // 	conditions:[]
            // }
        };
    },

    onReady() {
        this.initParams();
    },
    created() {
        // this.source = this.$route.query.source;
    },

    onShow() {
        this.search();
    },
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.accidentType = "";
            this.searchValue.name = "";
        },
        search() {
            // [{"name":"name","operate":"like","value":"123"},
            // {"name":"accidentType","operate":"=","value":"wutidaji"}]
            var conditions = [];
            var str = "";
            if (this.searchValue) {
                let obj = {};
                obj.name = "name";
                obj.value = this.searchValue;
                obj.operate = "like";
                conditions.push(obj);
            }

            this.conditions = conditions;
            this.queryPage();
        },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: this.conditions,
                });
            });

            // this.$refs.eaglePageList.search({
            //     conditions: this.conditions,
            // });
        },
        initParams() {
            var _this = this;

            // site_project_enterprise_scale,
            // site_project_source_type,
            // site_project_customer_track_mode

            this.common
                .getparamsList("site_project_source_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_source_type") {
                                _this.params.sourceType.push(item);
                            }
                        });
                    }
                });
        },
        imgError(e) {},
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },

        getSuplusDate(deadline) {
            if (deadline == null || deadline == "") {
                return `无跟踪记录`;
            } else {
                var now = new Date();
                let day = this.getDaysBetween(now, deadline);
                if (day >= 0) {
                    return `<span style='color:#E6A23C'>还剩${day}天</span>`;
                } else {
                    return `<span style='color:#dd6161'>超过${
                        day * -1
                    }天未跟踪</span>`;
                }
            }
        },
        getDaysBetween(date1, date2) {
            var startDate = Date.parse(this.common.dateFormat(date1));

            var endDate = Date.parse(this.common.dateFormat(date2));
            // Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },

        updatePick(item) {
            let _this = this;

            this.$refs.eagleConfirm.showConfirm({
                content: "是否确认认领该客户?",
                confirm: function () {
                    var url = "site/projectCustomer/updatePick";

                    var model = item;

                    _this.common.post(url, model).then(function (res) {
                        uni.hideLoading();
                        if (res.code == 200) {
                            uni.showToast({
                                title: "认领成功",
                                duration: 2000,
                            });

                            _this.search();
                        }
                        // else {
                        //     uni.showToast({
                        //         title: "认领失败：" + res.errorText,
                        //         duration: 2000,
                        //     });
                        // }
                    });
                },
                cancel: function () {
                    _this.$refs.eaglePageList.$refs.uToast.show({
                        title: "取消认领了",
                        type: "error",
                    });
                },
            });
        },
    },
};
</script>
