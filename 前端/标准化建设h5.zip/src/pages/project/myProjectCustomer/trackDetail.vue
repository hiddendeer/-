<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60'>
            <eagle-container>
                <eagle-text title="客户名称">
                    {{name}}
                </eagle-text>
            </eagle-container>
            <eagle-container>
                <eagle-window-choose title="联系人" headTitle="请选择联系人" v-model="model.contact" :isMult="false" :names.sync="model.contact" :required="true" showDetail="true" controller="site/projectCustomerUsers" idField="contact" textField="contact" :queryParams="queryParams" @callBackChoosedData="callBackChoosedData"></eagle-window-choose>
                <eagle-input v-model="model.mobile" title="联系方式" prop="mobile" required />
                <eagle-input v-model="model.rate" title="预计成单率%" prop="rate" required v-if="orderNo!=''" />
                <eagle-text title="意向订单编号" v-if="orderNo!=''">{{orderNo}}</eagle-text>
                <eagle-radio-group v-model="model.mode" title="跟踪方式" prop="trackMode" :data-source="params.trackMode" v-if="params.trackMode.length>0" required />
                <eagle-choose-user title="跟踪人" v-model="model.userName" :names.sync="model.chnName" prop="chnName" required></eagle-choose-user>
                <eagle-date v-model="model.trackDate" title="跟踪日期" prop="trackDate" required></eagle-date>
                <eagle-date v-model="model.nextTrackDate" title="下次跟踪日期" prop="nextTrackDate"></eagle-date>
                <eagle-input type="textarea" v-model="model.result" title="跟踪结果" prop="result" required />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </view>

</template>
<script>
import EagleContainer from "../../../components/eagle-container/eagle-container.vue";
import EagleInput from "../../../components/eagle-input/eagle-input.vue";
import EagleText from "../../../components/eagle-text/eagle-text.vue";
export default {
    components: { EagleInput, EagleText, EagleContainer },
    data() {
        return {
            model: {},
            errorType: ["message"],
            control: "site/projectCustomerTrack",
            name: "",
            code: "",
            orderNo: "",
            contactConditions: [],
            params: {
                trackMode: [],
            },
            queryParams: {
                customerCode: "",
            },
        };
    },
    created() {
        this.model.id = this.$route.query.id ?? 0;
        this.code = this.$route.query.code ?? "";
        this.orderNo = this.$route.query.orderNo;
        this.initParams();
        if (this.model.id == 0) {
            //新增
            uni.setNavigationBarTitle({
                title: "新增客户跟踪",
            });
        }
        this.queryParams.customerCode = this.code;
    },
    onReady() {},
    mounted() {},
    methods: {
        callBackChoosedData(choosedData) {
            if (choosedData.length > 0) {
                let item = choosedData[0];
                this.model.mobile = item.mobile;
            }
        },

        initCallBack(data) {
            if (this.orderNo) {
                this.model.intentionOrderCode = this.orderNo;
            }
            // this.model.mode = this.params.trackMode[0].id;
            this.model = data;
            this.getDataByCode();
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("site_project_customer_track_mode")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId ==
                                "site_project_customer_track_mode"
                            ) {
                                _this.params.trackMode.push(item);
                            }
                        });

                        if (_this.params.trackMode.length > 0) {
                            _this.model.mode = _this.params.trackMode[0].id;
                        }
                    }
                });
        },

        customerCallBack() {},

        getDataByCode() {
            let _this = this;

            var url = "site/projectCustomer/getDataByCode/" + this.code;
            uni.showToast({
                icon: "loading",
            });

            this.common.get(url, "").then(function (res) {
                if (res.code === 200) {
                    if (res.data) {
                        _this.name = res.data.name;
                        _this.model.customerCode = res.data.code;
                        _this.model.customerName = res.data.name;
                        if (
                            res.data.projectCustomerUsers.length > 0 &&
                            _this.model.id == 0
                        ) {
                            var item = res.data.projectCustomerUsers[0];
                            _this.model.contact = item.contact;
                            _this.model.mobile = item.mobile;
                        }
                    }
                } else {
                }
                uni.hideToast();
            });
        },

        showOrde() {},

        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                needValid: true,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
