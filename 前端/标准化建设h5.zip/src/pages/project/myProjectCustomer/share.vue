<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType">
            <eagle-container>
                <eagle-choose-user title="共享给" :isMult="true" v-model="model1.shareUserName" :names.sync="model1.shareChnName" prop="shareUserName" required></eagle-choose-user>
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
    </view>

</template>
<script>
import EagleContainer from "../../../components/eagle-container/eagle-container.vue";
export default {
    components: { EagleContainer },
    data() {
        return {
            model: {},

            model1: {
                shareChnName: "",
                shareUserName: "",
            },
            errorType: ["message"],
            control: "site/projectCustomer",
        };
    },
    created() {
        this.model.id = this.$route.query.id;

        this.model1.shareChnName = "";
        this.model1.shareUserName = "";
    },
    onReady() {
        var _this = this;
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            this.model = data;
            var shareUserName = "";
            var shareChnName = "";

            for (
                let i = 0;
                i < this.model.projectCustomerShareUsers.length;
                i++
            ) {
                var item = this.model.projectCustomerShareUsers[i];

                if (item.shareChnName) {
                    if (shareChnName == "") {
                        shareChnName = item.shareChnName;
                    } else {
                        shareChnName = shareChnName + "," + item.shareChnName;
                    }
                }
                if (item.shareUserName) {
                    if (shareUserName == "") {
                        shareUserName = item.shareUserName;
                    } else {
                        shareUserName =
                            shareUserName + "," + item.shareUserName;
                    }
                }
            }

            this.model1.shareUserName = shareUserName;
            this.model1.shareChnName = shareChnName;
        },

        post(op) {
            this.model.shareUserName = this.model1.shareUserName;
            this.model.shareChnName = this.model1.shareChnName;

            if (this.model.shareUserName == "" || !this.model.shareUserName) {
                this.$refs.uToast.show({
                    title: "请选择共享给",
                    type: "error",
                });

                return;
            }

            let _this = this;

            this.$refs.eagleForm.post({
                url: "/site/projectCustomer/updateShare",
                needValid: false,
                validCallback: function () {
                    return true;
                },
                successCallback: function (res) {
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
    },
};
</script>
