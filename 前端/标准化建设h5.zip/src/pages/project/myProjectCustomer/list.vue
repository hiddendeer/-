<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="20" :controller="controller" :margin-bottom="0" @beforeLoad="beforeLoad" :showCheck="true" dataType="myCustomerList">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="searchValue" placeholder="请输入客户名称进行模糊搜索"> </eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goto('/pages/project/myProjectCustomer/view?id=' + item.id)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{ item.name }}
                        <template slot="icon">
                            {{ item.sourceType | splitParamsFormat(params.sourceType) }}
                        </template>
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view>
                            <text>地址 : {{ item.address }} </text>
                        </view>
                        <view>
                            <text>最近跟踪日期 : {{ item.lastVisitDay | dateFormat }} </text>
                        </view>
                        <view>
                            <text>销售人员 : {{ item.saleChnName }} </text>
                        </view>
                        <view>
                            <text>创建人 : {{ item.createChnName }} </text>
                        </view>
                        <view>
                            <text>创建时间 : {{ item.createDate | dateFormat }} </text>
                        </view>
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="success" size="mini" @click="goto('/pages/project/myProjectCustomer/trackList?code=' + item.code + '&name=' + item.name)">
                            跟踪</u-button>
                        <u-button type="error" size="mini" v-if="item.isSelf == '1'" @click="del(item.id)">删除</u-button>

                        <u-button type="primary" size="mini" @click="goto('/pages/project/myProjectCustomer/detail?id=' + item.id)">编辑</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick="goto('/pages/project/myProjectCustomer/detail?id=0')">
        </eagle-fab>
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
export default {
    components: {},
    data() {
        return {
            searchValue: "",
            controller: "/site/projectCustomer",
            data: [],
            clearabled: true,
            conditions: [],
            params: {
                sourceType: [],
                happenSide: [],
            },
        };
    },
    onShow() {
        this.search();
    },
    onReady() {
        this.initParams();
    },
    created() {},
    methods: {
        _initList(list) {
            this.data = list;
        },

        reSearch() {
            this.searchValue.accidentType = "";
            this.searchValue.name = "";
        },
        search() {
            // [{"name":"name","operate":"like","value":"123"},
            // {"name":"accidentType","operate":"=","value":"wutidaji"}]
            var conditions = [];
            var str = "";
            if (this.searchValue) {
                let obj = {};
                obj.name = "name";
                obj.value = this.searchValue;
                obj.operate = "like";
                conditions.push(obj);
            }

            this.conditions = conditions;
            this.queryPage();
        },
        queryPage() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: this.conditions,
                });
            });
        },
        initParams() {
            var _this = this;

            // site_project_enterprise_scale,
            // site_project_source_type,
            // site_project_customer_track_mode

            this.common
                .getparamsList("site_project_source_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "site_project_source_type") {
                                _this.params.sourceType.push(item);
                            }
                        });
                    }
                });
        },
        imgError(e) {},
        del(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.queryPage();
                },
            });
        },
        goto(url) {
            this.base.navigateTo(url);
        },

        updatePublic(item) {
            let _this = this;

            // site/projectCustomer/updatePublic/1468499399288913997
            this.$refs.eagleConfirm.showConfirm({
                content: "确定将该客户转为公海客户？",
                confirm: function () {
                    var url = "site/projectCustomer/updatePublic/" + item.id;
                    _this.common.get(url, null).then(function (res) {
                        if (res.code == 200) {
                            _this.$refs.uToast.show({
                                title: "转为公海客户成功",
                                type: "success",
                                callback: function () {
                                    _this.search();
                                },
                            });
                        }
                        //  else {
                        //     _this.$refs.uToast.show({
                        //         title: "转为公海客户失败：" + res.errMsg,
                        //         type: "error",
                        //     });
                        // }
                    });
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消",
                        type: "error",
                    });
                },
            });
        },

        getSuplusDate(deadline) {
            if (deadline == null || deadline == "") {
                return `未跟踪`;
            } else {
                return `已跟踪`;
                // var now = new Date();
                // let day = this.getDaysBetween(now, deadline);
                // if (day >= 0) {
                // 	return `<span style='color:#E6A23C'>还剩${day}天</span>`;
                // } else {
                // 	return `<span style='color:#dd6161'>超过${day * -1}天未跟踪</span>`;
                // }
            }
        },
        getDaysBetween(date1, date2) {
            var startDate = Date.parse(this.common.dateFormat(date1));
            var endDate = Date.parse(
                this.common.dateFormat(date2.replace(/-/g, "/"))
            );
            // Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
    },
};
</script>
