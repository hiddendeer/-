<template>
    <view>
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='80' :errorType="errorType" :byCode="byCode" selfHeight='calc(100vh - 125px)'>
            <eagle-container>
                <template slot="title">客户信息</template>
                <eagle-text v-model="model.name" blod label="客户名称"></eagle-text>
                <eagle-text v-model="model.organizationCode" blod label="统一社会信用代码"></eagle-text>
                <eagle-text v-model="model.applyProfessionName" prop="applyProfessionName" blod label="行业"></eagle-text>
                <eagle-text v-model="model.legalPerson" prop="legalPerson" label="法定代表人"></eagle-text>
                <eagle-text v-model="model.contactNumber" blod label="联系电话"></eagle-text>
                <eagle-text v-model="model.natureOfBusiness" blod label="经营范围"></eagle-text>
                <eagle-text v-model="model.address" blod label="详细地址"></eagle-text>
                <eagle-text blod label="企业规模">{{ model.enterpriseScale | paramsFormat(params.enterpriseScale) }}
                </eagle-text>
                <eagle-text v-model="model.empCnt" blod label="企业人数"></eagle-text>
                <eagle-text blod label="客户来源">{{ model.sourceType | paramsFormat(params.sourceType) }}</eagle-text>
            </eagle-container>

            <eagle-container>
                <template slot="title">开票信息</template>
                <eagle-text v-model="model.payeeName" blod label="开票抬头"> </eagle-text>
                <eagle-text v-model="model.taxNumber" blod label="开票税号"> </eagle-text>
                <eagle-text v-model="model.invoiceAdsTel" blod label="开票地址、电话"> </eagle-text>
                <eagle-text v-model="model.bankAccount" blod label="开户行及账号"> </eagle-text>
                <eagle-file-upload disabled title="开票文件" :maxCount="3" prop="invoiceAttach" v-model="model.invoiceAttach" />
                <!-- <eagle-display-image title="开票图片" v-model="model.invoiceAttach"></eagle-display-image> -->
            </eagle-container>
            <eagle-container>
                <template slot="title">客户联系人</template>
                <view class="form-detail" v-for="(item, index) in model.projectCustomerUsers" :key="index">

                    <view class="form-detail-title">客户联系人：{{ item.contact }}</view>
                    <view class="form-detail-title">
                        联系方式：{{ item.mobile }}
                    </view>
                    <view>岗位:{{ item.post }}</view>
                    <view class="form-detail-title">
                        邮箱:{{ item.email }}
                    </view>
                    <view class="form-detail-title">
                        备注：{{ item.remarks }}
                    </view>
                    <view>
                        <u-line></u-line>
                    </view>
                </view>
            </eagle-container>

        </eagle-form>
        <eagle-bottom-view v-if="model.isPublic == false && isMyCustomer">
            <u-button type="primary" class="bottom-btn" @click="goto('/pages/project/myProjectCustomer/share?id=' + model.id)" v-if="model.isSelf == '1'">共享
            </u-button>
            <u-button type="primary" class="bottom-btn" @click="goto('/pages/project/myProjectCustomer/transfer?id=' + model.id)" v-if="model.isSelf == '1'">转移
            </u-button>
            <u-button type="primary" class="bottom-btn" @click="updatePublic(model)">转为公海客户</u-button>
        </eagle-bottom-view>

        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>
<script>
// import Template from "../../danger/dangerTemplate/template.vue";
export default {
    // components: { Template },
    data() {
        return {
            model: {},
            byCode: false,
            errorType: ["message"],
            control: "site/projectCustomer",
            params: {
                enterpriseScale: [],
                sourceType: [],
                trackMode: [],
                Public: [
                    {
                        id: "1",
                        name: "",
                    },
                ],
            },
            currentUser: {},
        };
    },
    computed: {
        isMyCustomer() {
            return (
                this.currentUser.manager ||
                (this.model.saleUserName &&
                    this.model.saleUserName.indexOf(
                        this.currentUser.userName
                    ) >= 0)
            );
        },
    },
    created() {
        this.model.id = this.$route.query.id;
        this.model.code = this.$route.query.code;

        if (this.model.code) {
            this.byCode = true;
        }
        let userInfo = uni.getStorageSync("userInfo");
        if (typeof userInfo === "string") {
            userInfo = JSON.parse(userInfo);
        }
        this.currentUser = userInfo;
    },
    onReady() {
        var _this = this;
        _this.initParams();
    },
    mounted() {},
    methods: {
        initCallBack(data) {
            if (this.model.isPublic) {
                this.model.isPublic = "1";
            } else {
                this.model.isPublic = "0";
            }
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList(
                    "site_project_enterprise_scale,site_project_source_type,site_project_customer_track_mode"
                )
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (
                                item.paramId == "site_project_enterprise_scale"
                            ) {
                                _this.params.enterpriseScale.push(item);
                            }
                            if (item.paramId == "site_project_source_type") {
                                _this.params.sourceType.push(item);
                            }

                            if (
                                item.paramId ==
                                "site_project_customer_track_mode"
                            ) {
                                _this.params.trackMode.push(item);
                            }
                        });
                    }
                });
        },
        goto(url) {
            this.base.navigateTo(url);
        },
        updatePublic(item) {
            let _this = this;

            // site/projectCustomer/updatePublic/1468499399288913997
            this.$refs.eagleConfirm.showConfirm({
                content: "确定将该客户转为公海客户？",
                confirm: function () {
                    var url = "site/projectCustomer/updatePublic/" + item.id;
                    _this.common.get(url, null).then(function (res) {
                        if (res.code == 200) {
                            _this.$refs.uToast.show({
                                title: "转为公海客户成功",
                                type: "success",
                                callback: function () {
                                    _this.base.navigateBack();
                                },
                            });
                        }
                        // else {
                        //     _this.$refs.uToast.show({
                        //         title: "转为公海客户失败：" + res.errMsg,
                        //         type: "error",
                        //     });
                        // }
                    });
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消",
                        type: "error",
                    });
                },
            });
        },
    },
};
</script>
<style lang="scss">
.detail-block {
    background: #f7f7f7;
}

.customer-block .custom-style {
    background: #fff;
    color: #2979ff;
    font-size: 14px;
    border-width: 0px;
    line-height: 28px;
}

.form-detail {
    // border-bottom: 1px solid #ddd;
    // margin-bottom: 10px;
    color: $font-color-base;
    line-height: 24px;
    padding: 0 30rpx;

    .form-detail-title {
        color: #494a4c;
        line-height: 28px;
    }

    .form-detail-titleOne {
        color: #494a4c;
        line-height: 28px;
        display: flex;
        justify-content: space-between;
    }

    .form-detail-titleOne_button {
        display: flex;
        column-gap: 5px;
    }
}

.m {
    margin-right: 5px;
    color: #2979ff;
}

.other-font {
    color: #303133;
    font-size: 32rpx;
}
</style>