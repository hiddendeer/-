<template>
  <view class="host-index">
    <eagle-container title="文件上传">
      <file-upload
        title="污染防治设施安全风险评估报告"
        :limitType="['png', 'jpg', 'jpeg']"
        busType="ppf_sra_report"
        showTips
        :value="ruleForm.attachs3"
      />
    </eagle-container>
    <tabbar-ecology></tabbar-ecology>
  </view>
</template>

<script>
import fileUpload from "../../fileUpload/components/eagle-upload/eagle-upload.vue";
import TabbarEcology from "@/pages/components/tabbar/tabbar-ecology.vue";
export default {
  components: {
    fileUpload,
    TabbarEcology
  },
  data() {
    return {
      ruleForm: {
        attachs1: "",
        attachs2: "",
        attachs3: "",
      },
    };
  },
  mounted() {
    this.getAllFile();
  },
  methods: {
    getAllFile() {
      this.common
        .post("ecologyEnv/fourColor/ecologicalEnvironment/getAllFile", {
          businessDetailType: "",
        })
        .then((res) => {
          if (res?.code == 200) {
            res?.data?.forEach((item) => {
              if (item.businessDetailType == "eia_report") {
                this.ruleForm.attachs1 = item.fileUrl;
              }
              if (item.businessDetailType == "epd_permit") {
                this.ruleForm.attachs2 = item.fileUrl;
              }
              if (item.businessDetailType == "ppf_sra_report") {
                this.ruleForm.attachs3 = item.fileUrl;
              }
            });
          }
        });
    },
  },
};
</script>
