<template>
  <view>
    <eagle-head
      :title="isEditor === true ? '编辑证书信息' : '新增证书信息'"
      @close="addClose"
    ></eagle-head>
    <eagle-form
      :control="control"
      v-model="model"
      ref="eagleForm"
      :errorType="errorType"
      :boolInitData="false"
      label-align="left"
    >
      <eagle-container>
        <!-- <eagle-input v-model="model.certificateName" required title="证书名称" prop="certificateName">
                    <template slot="topBotton">
                        <view class="button" style="color:#2979ff;box-sizing: content-box;float:right;">
                            <span @click='tagClick(index)' v-for="(item,index) in tags" :key='index' style="margin-left: 10rpx;">
                                {{item}}
                            </span>
                        </view>
                    </template>
                </eagle-input> -->
        <fast-choose-cert
          title="证书名称"
          prop="certificateName"
          required
          v-model="model.certificateName"
        ></fast-choose-cert>
        <eagle-date
          v-model="model.certificateValidityDate"
          required
          title="证书有效期"
          prop="certificateValidityDate"
        ></eagle-date>
        <eagle-input
          v-model="model.postRemarks"
          title="备注"
          prop="postRemarks"
          labelPosition="top"
          labelWidth="150"
          type="textarea"
        >
        </eagle-input>
        <eagle-upload
          title="证书照片"
          :maxCount="3"
          prop="attachs"
          v-model="model.attachs"
          labelPosition="top"
          labelWidth="150"
        />
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button type="primary" class="bottom-btn" @click="addName()"
        >确定</u-button
      >
    </eagle-bottom-view>
  </view>
</template>
<script>
import fastChooseCert from "../components/fast-choose-cert.vue";
export default {
  components: { fastChooseCert },
  props: {
    isEditor: {
      type: Boolean,
      default: false
    },
    isShow: {
      type: Boolean,
      default: false
    },
    listData: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      tags: ["主要负责人证", "高压电工证", "低压电工证"],
      show: true,
      model: {
        certificateName: "",
        certificateValidityDate: "",
        postRemarks: "",
        attachs: ""
      },
      control: "system/dict/data/paramsLists",
      errorType: ["message"]
    };
  },
  created() {
    let _this = this;

    if (this.isEditor) {
      this.model = _this.listData;
      let name = this.model.certificateName;
      this.model.certificateName = "null";
      let tiemr = setTimeout(() => {
        clearTimeout(tiemr);
        this.model.certificateName = name;
      }, 50);
    } else {
      this.model = {
        certificateName: "",
        certificateValidityDate: "",
        postRemarks: "",
        attachs: ""
      };
    }
  },
  methods: {
    tagClick(index) {
      this.model.certificateName = this.tags[index];
    },
    addName() {
      var result = this.$refs.eagleForm.valid();
      if (result) {
      } else {
        return;
      }

      if (this.model.certificateValidityDate.length == 10) {
        this.model.certificateValidityDate =
          this.model.certificateValidityDate + " 00:00:00";
      }

      if (this.model.attachs == "") {
        this.model.attachsStr = "";
      } else {
        var arr = this.model.attachs.split(";");

        if (arr.length > 0) {
          this.model.attachsStr = arr[0];
        } else {
        }
      }
      this.$emit("update:isShow", false);
      this.$emit("showstrr", this.model);
      this.$emit("update:isEditor", false);
    },
    addClose() {
      this.$emit("update:isShow", false);
      this.$emit("update:isEditor", false);
    }
  }
};
</script>
