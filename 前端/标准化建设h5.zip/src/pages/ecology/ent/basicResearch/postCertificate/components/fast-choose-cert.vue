<template name="fast-choose-cert">
    <u-form-item class="fast-choose-cert" :label="label" ref="uFormItem" :label-position="labelPosition" :required="required" :prop="prop" :label-width="labelWidth">
        <eagle-arrow-input class="cert-input" prop="eagle-arrow-input" v-model="defaultValue" :disabled="false" :placeholder="placeholderVal" @input="inputChange" @confirm="confirmEvent" @click="showList"></eagle-arrow-input>
        <template v-if="list&&list.length>0">
            <view class="drop-select">
            </view>
            <view class="drop-content-cert" v-clickoutside="close">
                <view class="drop-row" v-for="(item,index) in list" :key="index" @click="hdClick(item)">
                    <view style="flex:1">{{item.name}}</view>
                    <u-icon class="button" label="选择"></u-icon>
                </view>
            </view>
        </template>
    </u-form-item>
</template>
<script>
import "@/common/clickoutside.js";
export default {
    components: {},
    name: "fast-choose-cert",
    props: {
        label: {
            type: String,
            default: "证书类型",
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        border: {
            type: Boolean,
            default: false,
        },
        value: {
            type: String,
            default() {
                return "";
            },
        },
        name: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: [String],
            default: "",
        },
    },
    data() {
        return {
            model: {},
            lock: false,
            locklength: 0,
            defaultValue: "",
            list: [],
            allList: [],
        };
    },

    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请输入" + this.label;
        this.initParams();
    },
    watch: {
        value(nVal, oVal) {
            if (this.defaultValue != this.value) {
                this.defaultValue = this.value;
                this.$emit("input", this.defaultValue);
            }
        },
    },
    methods: {
      initParams() {
        var _this = this;
        this.common
            .getparamsList("cert_type")
            .then(function (res) {
              if (res.code == 200 && res.data) {
                _this.allList = res.data;
              }
            });
      },
        inputChange() {
            this.$emit("input", this.defaultValue);
          console.log(this.defaultValue)
        // return
        //     if (this.defaultValue && this.defaultValue.length >= 0) {
        //         this.getList(this.defaultValue);
        //     } else {
        //         this.list = [];
        //     }
        },
        close(e) {
            console.log("close");
            this.list = [];
        },
        hdClick(item) {
            this.$emit("input", item);
            this.close();
        },
        showList() {
            this.getList("");
        },
        getList(val) {
            this.list = this.allList;
        },
        confirmEvent() {
            this.$emit("input", this.defaultValue);
            this.valid();
            this.close();
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss" scopd>
.fast-choose-cert {
    position: relative;
    .drop-select {
        padding: 10px;
        position: absolute;
        z-index: 9999999;
        width: 100%;
        background: #5e5e5e;
        top: 75px;
        left: 0px;
        height: calc(100vh);
        opacity: 0.5;
    }
    .drop-content-cert {
        border: 1px solid #eee;
        position: absolute;
        //max-height: 200px;
        overflow: auto;
        line-height: 36px;
        padding: 10px;
        background: #fff;
        z-index: 9999999;
        width: calc(100vw - 20px);
        left: 0;
        top: 75px;
        border-radius: 0 0 5px 5px;
    }
    .drop-row {
        display: flex;
        .button {
            width: 50px;
            color: #0088ff;
        }
    }
}
</style>
