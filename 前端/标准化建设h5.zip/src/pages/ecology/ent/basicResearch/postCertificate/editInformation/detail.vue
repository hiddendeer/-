<template>
    <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm">
        <eagle-container style="padding-bottom:0px;" title="人员信息">
            <eagle-input v-model="model.name" required title="姓名" prop="name" labelPosition="top" labelWidth="170">
            </eagle-input>
            <eagle-input v-model="model.organName" title="部门" prop="organName" labelPosition="top" labelWidth="170">
            </eagle-input>
            <eagle-input v-model="model.postName" title="岗位" prop="postName" labelPosition="top" labelWidth="170">
            </eagle-input>
        </eagle-container>
        <eagle-container title="证书信息">
            <fast-choose-cert required title="证书名称" v-model="model.certificateName"></fast-choose-cert>
            <eagle-date v-model="model.certificateValidityDate" required title="证书有效期" prop="certificateValidityDate"></eagle-date>
            <eagle-input v-model="model.remarks" title="备注" prop="remarks" labelPosition="top" labelWidth="170" type="textarea"> </eagle-input>
            <eagle-upload title="证书照片" :maxCount="3" prop="attachs" v-model="model.attachs" labelPosition="top" labelWidth="170" />
        </eagle-container>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="post()">保存</u-button>
        </eagle-bottom-view>
    </eagle-form>
</template>
<script>
import fastChooseCert from "../components/fast-choose-cert.vue";
export default {
    components: { fastChooseCert },
    data() {
        return {
            // tags: ["主要负责人证", "高压电工证", "低压电工证"],
            model: {},
            control: "site/entPostCertificate",
        };
    },
    created() {},
    methods: {
        initCallBack(data) {
            this.model = data;
        },
        post(op) {
            let _this = this;
            this.$refs.eagleForm.post({
                successCallback: function (res) {
                    _this.close();
                },
            });
        },
        close() {
            this.base.navigateBack();
            uni.$emit('_update_postCertificate_list')
        },
    },
};
</script>

