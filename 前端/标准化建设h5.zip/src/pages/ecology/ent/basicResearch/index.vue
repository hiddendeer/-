<template>
    <view class="host-ent-erprise-container eagle-layer">
        <view class="u-tabs-box">
            <u-tabs-swiper name="Name" :bold="false" ref="tabs" :list="tabList" :current="tabIndex" @change="onTabChanged">
            </u-tabs-swiper>
        </view>
        <swiper class="swiper-box" :current="tabContentIndex" @transition="transition" @animationfinish="animationfinish">
            <!-- 基础信息 -->
            <swiper-item class="swiper-item1">
                <hostEnterpriseInfo ref='hostEnterpriseInfo'></hostEnterpriseInfo>
            </swiper-item>
            <swiper-item class="swiper-item1">
                <hostEnterpriseOrg ref='hostEnterpriseOrg'></hostEnterpriseOrg>
            </swiper-item>

            <!-- 特殊岗位证书 -->
            <swiper-item class="swiper-item1">
                <SpecialPostCertificate ref='SpecialPostCertificate'>
                </SpecialPostCertificate>
            </swiper-item>
            <!-- 生产工艺 -->
            <swiper-item class="swiper-item1">
                <productionProcess ref='productionProcess'></productionProcess>
            </swiper-item>
            <!-- 相关方 -->
            <swiper-item class="swiper-item1">
                <RelatedParty ref='RelatedParty'></RelatedParty>
            </swiper-item>
        </swiper>
        <view v-if="tabContentIndex!==0">
            <tabbar-host v-if="queryParams.enterpriseCode" :queryParams="queryParams"></tabbar-host>
            <tabbar-site v-else></tabbar-site>
        </view>

    </view>
</template>

<script>
import hostEnterpriseInfo from "./enterpriseInfo/detail.vue";
import hostEnterpriseOrg from "./enterpriseInfo/orgStructure.vue";
import SpecialPostCertificate from "./postCertificate/list.vue";
import productionProcess from "./process/list.vue";
import RelatedParty from "./relation/list.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
export default {
    components: {
        hostEnterpriseInfo, //基础信息
        hostEnterpriseOrg, //
        SpecialPostCertificate, //特殊岗位证书
        productionProcess, //生产工艺
        RelatedParty, //相关方
        TabbarHost, //底部导航栏
        TabbarSite,
    },
    data() {
        return {
            tabList: [
                {
                    name: "基本信息",
                },
                {
                    name: "组织架构",
                },
                {
                    name: "特殊岗位证书",
                },
                {
                    name: "生产工艺",
                },
                {
                    name: "相关方",
                },
            ],
            tabIndex: 0,
            tabContentIndex: 0,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            scrollHeight: 0,
        };
    },
    mounted() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
    },

    onShow() {
        // this.resetTableHeight();
        if (this.$route.query.tabContentIndex) {
            setTimeout(() => {
                this.tabContentIndex = this.$route.query.tabContentIndex;
            });
        } else {
            this.tabContentIndex = this.tabIndex;
        }
        if (this.tabContentIndex === 2) {
            this.$refs.SpecialPostCertificate.search();
        }

        if (this.tabContentIndex === 3) {
            this.$refs.productionProcess.search();
        }

        if (this.tabContentIndex === 4) {
            this.$refs.RelatedParty.search();
        }
    },
    methods: {
        onTabChanged(index) {
            this.tabContentIndex = index;
        },
        transition(e) {
            let dx = e.detail.dx;
            this.$refs.tabs.setDx(dx);
        },
        animationfinish(e) {
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
            this.tabContentIndex = current;
            this.tabIndex = current;
        },
        // resetTableHeight() {
        //     var _that = this;
        //     uni.getSystemInfo({
        //         success: function (res) {
        //             _that.scrollHeight = res.windowHeight;
        //         },
        //     });
        // },
    },
};
</script>

<style lang="scss" scoped>
.host-ent-erprise-container {
    width: 100vw;
    overflow: hidden;
    box-sizing: border-box;
    position: relative;

    // .swiper-item1,
    // swiper-box {
    //     height: calc(100vh-50px);
    // }
}

uni-swiper {
    height: calc(100vh - 36px);
}
</style>
