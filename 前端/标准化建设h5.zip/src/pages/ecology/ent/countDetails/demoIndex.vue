<template>
    <view class="host-ent-erprise-container">
      <span style="padding-left: 10px">
          统计时间截止到：{{ lastDate }} 
      </span>
      <water-ball
            :totalScore="totalScore"
          ></water-ball>
          <emergency
            ref="refEmergency"
            :emergencyData="emergencyData"
          />
  </view>
    </view>
</template>

<script>
import waterBall from "./components/waterBall";
import emergency from "./components/emergency";
export default {
  components: {
    emergency,
    waterBall,
  },
  data() {
    return {
      lastDate: "2023-09-25",
      totalScore: 0,
      emergencyData: [
        {
          name: "目标职责（平均得分）",
          score: 15,
          fullMark: 20,
        },
        {
          name: "制度化管理（平均得分）",
          score: 132,
          fullMark: 200,
        },
        {
          name: "教育培训（平均得分）",
          score: 96,
          fullMark: 120,
        },
        {
          name: "现场管理（平均得分）",
          score: 22,
          fullMark: 50,
        },
        {
          name: "安全风险管控（平均得分）",
          score: 10,
          fullMark: 20,
        },
        {
          name: "隐患排查（平均得分）",
          score: 10,
          fullMark: 20,
        },
        {
          name: "应急演练（平均得分）",
          score: 10,
          fullMark: 20,
        },
        {
          name: "事故查处（平均得分）",
          score: 20,
          fullMark: 20,
        },
      ],
    };
  },
  mounted() {
    this.emergencyEchart();
  },

  onShow() {},
  methods: {
    historyClick() {},
    emergencyEchart() {
      this.$refs.refEmergency.emergencyEchart(this.emergencyData);
    },
  },
};
</script>


<style lang="scss">
.host-ent-erprise-container {
  width: 100vw;
  height: calc(100vh);
  overflow: hidden;
  box-sizing: border-box;

  // .header-box {
  //     width: 100%;
  //     height: 70rpx;
  //     display: flex;
  //     justify-content: center;
  //     align-items: center;
  //     background-color: #ffbf00;
  //     font-size: 36rpx;
  //     font-weight: bold;

  //     .left {
  //         color: #fff;
  //         font-size: 36rpx;
  //         margin-right: 50rpx;
  //     }

  //     .right {
  //         color: #3988ff;
  //     }
  // }

  // .swiper-box {
  //     width: 100%;
  //     height: calc(100vh - 55px);
  // }

  // .check-scoped-container {
  //     padding: 10rpx 30rpx;
  //     box-sizing: border-box;
  //     display: flex;
  //     justify-content: space-between;
  //     flex-wrap: wrap;

  //     .content {
  //         display: flex;
  //         flex-direction: column;
  //         justify-content: space-between;
  //         align-items: center;
  //         padding: 10rpx;
  //         border: 2rpx solid #c8c9cc;
  //         border-radius: 10px;
  //         box-sizing: border-box;
  //         margin-top: 10px;

  //         &.active {
  //             border-color: #2979ff;
  //             color: #2979ff;
  //         }
  //     }
  // }

  // .btn {
  //     padding: 10rpx;
  //     box-sizing: border-box;
  //     display: flex;
  //     justify-content: space-around;
  //     background: #eeeeee;
  // }
}
</style>
