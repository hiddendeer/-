<template>
  <view class="eagle-layer">
    <eagle-page-list
      ref="eaglePageList"
      @initList="_initList"
      :pageSize="20"
      :queryUrl="queryUrl"
      :margin-bottom="30"
      :boolInitData="false"
    >
      <view slot="list">
        <eagle-row-card v-for="(item, index) in data" :key="index">
          <eagle-row-view> 日期:{{ utils.dateFormat(item.createTime,"yyyy-mm-dd") }} </eagle-row-view>
          <eagle-row-view> 分数:{{ item.totalScore }} </eagle-row-view>
          <template slot="button">
            <u-button type="primary" @click="handleDetail(item)" size="mini"
              >查看详情</u-button
            >
          </template>
        </eagle-row-card>
      </view>
    </eagle-page-list>
    <u-toast ref="uToast" />
  </view>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      userIns: {},
      queryUrl: "ecologyEnv/fourColor/homeStatistics/getScoreHistoryRecord",
      data: [],
      env: "",
      warninigIcon: require("@/static/img/AppIcon/icon_warning.png"),
    };
  },
  mounted() {
    this.search();
  },
  created() {
    this.userIns = uni.getStorageSync("userInfo");
    this.env = process.env.VUE_APP_ENV;
    uni.$on("_update_relation_list", () => {
      this.search();
    });
  },
  methods: {
    _initList(list) {
      this.data = list;
    },
    search() {
      let _this = this;
      _this.userIns = uni.getStorageSync("userInfo");
      setTimeout(() => {
        this.$refs.eaglePageList.search({
          params: {
            companyId: _this.userIns.companyCode
            // companyId: "5e09a41fb6974fa4fd2330cc98d8e04d",
          },
        });
      });
    },

    handleDetail(item) {
      let _this = this;
      uni.redirectTo({
        url: `/pages/ecology/ent/countDetails/historyIndex?companyId=${_this.userIns.companyCode}&recordTime=${item.createTime}&originPla=appCenter`,
      });
      // uni.redirectTo({
      //   url: `/pages/ecology/ent/countDetails/historyIndex?companyId=5e09a41fb6974fa4fd2330cc98d8e04d&recordTime=${item.createTime}&originPla=appCenter`,
      // });
    },
  },
};
</script>

<style lang="scss" scoped>
.eagle-layer {
  padding: 24rpx 0;
}
</style>
