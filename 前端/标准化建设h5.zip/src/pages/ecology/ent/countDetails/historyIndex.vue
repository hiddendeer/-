<template>
  <view class="page-container">
    <view class="page-card">
      <water-ball :totalScore="totalScore" :id="id" :loading="loading"></water-ball>
      <ul class="setScore">
        <li v-for="item in totalMark" :key="item.id">
          <img :src="item.image.default" alt="" />
          <div class="total">
            <div class="total_top">
              <span class="total_top_num">{{ item.total }}</span>
              <span class="total_top_str">分</span>
            </div>
            <div class="total_bottom">
              {{ item.label }}
            </div>
          </div>
        </li>
      </ul>
    </view>

    <view class="page-card">
      <p class="title">应急管理</p>
      <emergency
        :keys="10"
        :emergencyData="state.riskMapData"
        :width="'100%'"
        :height="'640px'"
      />
    </view>

    <view class="page-card">
      <p class="title">综合执法</p>
      <div>
        <p class="setTitle">管理类</p>
        <p class="setNewTitle">特种设备管理</p>
        <emergency
          :keys="20"
          :emergencyData="state.comprehensiveLaw"
          :width="'100%'"
          :height="'80px'"
        />

        <div class="flex-card">
          <p class="setNewTitle no-pb">生态环境类</p>
          <div class="tips_card">
            <img :src="iconUrl.default" />
            <span>此项最多可得100分 </span>
          </div>
        </div>
        <emergency
          :keys="30"
          :emergencyData="state.ecologicalEnvironment"
          :width="'100%'"
          :height="'240px'"
        />
      </div>
      <p class="setTitle">执法类</p>

      <div style="padding: 0 15px 10px">
        <ul class="setLawSty">
          <li v-for="(item, index) in setLaw" :key="index">
            {{ item.label }}
            <span style="padding-left: 10px">{{ item.score }}</span>
          </li>
        </ul>
      </div>
    </view>

    <view class="page-card">
      <p class="title">绩效评价</p>
      <emergency
        style="margin-top: 12px"
        :keys="40"
        :emergencyData="state.evaluate"
        :width="'100%'"
        :height="'80px'"
      />
    </view>
  </view>
</template>

<script>
import waterBall from "./components/waterBall";
import emergency from "./components/emergency";
export default {
  components: {
    waterBall,
    emergency,
  },
  data() {
    return {
      user: {},
      id: 'sBall',
      lastDate: "2023-09-25",
      totalScore: 0,
      loading: false,
      iconUrl: require("@/static/img/AppIcon/warning.png"),
      totalMark: [
        {
          image: require("@/static/img/AppIcon/yjgl.png"),
          label: "应急管理",
          dictCode: "SSDP_JFFL_YJGL",
          total: 0,
          id: "A",
        },
        {
          image: require("@/static/img/AppIcon/zhzf.png"),
          label: "综合执法",
          dictCode: "SSDP_JFFL_ZHZF",
          total: 0,
          id: "B",
        },
        {
          image: require("@/static/img/AppIcon/jxpj.png"),
          label: "绩效评价",
          dictCode: "SSDP_JFFL_JXPJ",
          total: 0,
          id: "C",
        },
      ],
      state: {
        riskMapData: [
          {
            label: "目标职责",
            score: 0,
          },
          {
            label: "制度化管理",
            score: 0,
          },
          {
            label: "教育培训",
            score: 0,
          },
          {
            label: "现场管理",
            score: 0,
          },
          {
            label: "安全风险管控",
            score: 0,
          },
          {
            label: "隐患排查",
            score: 0,
          },
          {
            label: "应急演练",
            score: 0,
          },
          {
            label: "事故查处",
            score: 0,
          },
        ],
        comprehensiveLaw: [
          {
            label: "特种设备管理",
            score: 0,
          },
        ],
        evaluate: [
          {
            label: "A类企业",
            score: 0,
          },
        ],
        ecologicalEnvironment: [
          {
            label: "审批管理",
            score: 0,
          },
          {
            label: "现场管理",
            score: 0,
          },
          {
            label: "涉环问题排查与整改",
            score: 0,
          },
        ],
      },
      setLaw: [
        {
          label: "处罚结果：",
          score: "无",
        },
        {
          label: "挂牌督办：",
          score: "无",
        },
        {
          label: "媒体曝光：",
          score: "无",
        },
        {
          label: "生产许可：",
          score: "无",
        },
        {
          label: "违法用地：",
          score: "无",
        },
        {
          label: "违法建筑：",
          score: "无",
        },
      ],
    };
  },
  mounted() {
    let url = "";
    url = "ecologyEnv/fourColor/homeStatistics/getHistoryScoreDetail";
    this.user = uni.getStorageSync("userInfo");
    this.getInitData(url);
  },

  onShow() {},
  methods: {
    getInitData(url) {
      var _this = this;
      let jsonData = {
        companyId: _this.user?.companyCode,
        // companyId: '5e09a41fb6974fa4fd2330cc98d8e04d',
        recordTime: _this.$route.query.recordTime || ''
      };
      uni.showToast({
        icon: "loading"
      });
      this.common.get(url, jsonData).then((res) => {
        if (res.code === 200) {
          uni.hideToast();
          _this.totalScore = res?.data?.companyScore;
          _this.lastDate = res?.data?.lastStaticticsTime;
          if (res.data?.tabList?.length > 0) {
            res.data?.tabList?.forEach((item) => {
              _this.totalMark.forEach((markItem) => {
                if (item.dictCode == markItem.dictCode) {
                  markItem.total = item.score;
                }
              });
              if (item.dictCode == "SSDP_JFFL_YJGL") {
                _this.state.riskMapData = item.children;
              }
              if (item.dictCode == "SSDP_JFFL_ZHZF") {
                item?.children?.forEach((zhzfItem) => {
                  if (zhzfItem.dictCode == "SSDP_JFFL_ZHZF_GLL") {
                    zhzfItem?.children?.forEach((manageItem) => {
                      if (
                        manageItem.dictCode == "SSDP_JFFL_ZHZF_GLL_TZSBGL"
                      ) {
                        _this.state.comprehensiveLaw = manageItem.children;
                      }
                      if (manageItem.dictCode == "SSDP_JFFL_ZHZF_GLL_SHWT") {
                        _this.state.ecologicalEnvironment =
                          manageItem.children;
                      }
                    });
                  }
                  if (zhzfItem.dictCode == "SSDP_JFFL_ZHZF_ZFL") {
                    _this.setLaw = zhzfItem.children;
                  }
                });
              }
              if (item.dictCode == "SSDP_JFFL_JXPJ") {
                _this.state.evaluate = item.children;
              }
            });
          }
        } else {
          uni.hideToast();
        }
      });
    },
    historyClick() {
      let url = "/pages/ecology/ent/countDetails/historyChoose";
      this.base.navigateTo(url);
    },
  },
};
</script>


<style lang="scss" scoped>
.page-container {
  width: 100vw;
  height: calc(100vh);
  overflow: auto;
  box-sizing: border-box;
  font-size: 28rpx;
  padding: 36rpx 0;

  .flex {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .choose-btn {
    text-decoration: underline;
    color: #1d4ad4;
    padding: 26rpx 0;
    font-weight: 600;
  }
  .flex-card {
    display: flex;
    align-items: center;
    padding-bottom: 12px;
  }
  .page-card {
    background: #fff;
    padding: 28rpx 0 0;
    margin: 0 0 24rpx;
    .title {
      font-size: 36rpx;
      color: #333;
      font-weight: 600;
      padding: 0 30rpx;
    }
    .setTitle {
      font-size: 32rpx;
      font-weight: 600;
      color: #666;
      padding: 24rpx 30rpx;
    }
    .no-pb {
      padding-bottom: 0 !important;
    }
    .setNewTitle {
      font-size: 32rpx;
      font-weight: 600;
      color: #666;
      padding: 0 30rpx 24rpx;
      &::before {
        content: "";
        width: 6rpx;
        height: 20rpx;
        display: inline-block;
        background: #3187ff;
        margin-right: 20rpx;
      }
    }
    .tips_card {
      display: flex;
      align-items: center !important;
      img {
        height: 30rpx;
        width: 30rpx;
        padding: 0 10rpx 0 30rpx;
      }
      span {
        color: #999;
        font-size: 24rpx;
      }
    }
  }
  .setScore {
    display: flex;
    justify-content: space-around;
    padding: 30rpx 0 60rpx;
    list-style: none;
    li {
      display: flex;
      img {
        width: 72rpx;
        height: 72rpx;
        margin-right: 12rpx;
      }
      .total {
        display: flex;
        flex-direction: column;
        &_top {
          width: 100%;
          height: 50%;
          display: flex;
          align-items: center;
          line-height: 50%;
          justify-content: center;
          &_num {
            font-size: 36rpx;
            color: #222;
            font-weight: 600;
          }
          &_str {
            display: inline-block;
            font-size: 20rpx;
            color: #999;
          }
        }
        &_bottom {
          height: 50%;
          display: flex;
          align-items: center;
          line-height: 50%;
          justify-content: center;
          font-size: 24rpx;
          color: #666;
          font-weight: 400;
        }
      }
    }
  }
  .setLawSty {
    padding-inline-start: 36rpx;
    li {
      padding: 14rpx 0;
      text-indent: -4rpx;
      font-weight: 600;
      font-size: 28rpx;
      color: #333;

      &::marker {
        color: #85c1ff !important;
      }
    }
  }
}
</style>