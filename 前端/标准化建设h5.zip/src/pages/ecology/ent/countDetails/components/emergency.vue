<template>
  <view class="emergency">
    <view :id="'emergencyEchartId' + keys" :style="{width:width,height:height,margin: 0,padding:0,}"></view>
  </view>
</template>

<script>
export default {
  props: {
    keys: {
      type: Number,
      default: 0
    },
    emergencyData: {
      type: Array,
      default: () => [],
    },
    width: {
      type: String,
      default: '',
    },
    height: {
      type: String,
      default: '',
    },
  },
  data() {
    return {};
  },
  watch: {
    emergencyData: {
      immediate: true,
      handler(n) {
        this.$nextTick(() => {
          this.emergencyEchart(n);
        })
      }
    }
  },
  methods: {
    emergencyEchart(data) {
      let label = data.map((item) => item.label);
      let value = data.map((item) => item.score);
      let score = data.map((item) => item.score);
      this.$echartsCase.echarBar(
        "emergencyEchartId" + this.keys,
        value,
        label,
        score,
        "#409EFF"
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.emergency {
  width: 100%;
  display: flex;
  .boxSize {
    width: 100%;
    height: 1300rpx;
  }
}
</style>
