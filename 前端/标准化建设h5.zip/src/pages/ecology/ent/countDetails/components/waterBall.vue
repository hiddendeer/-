<template>
  <div class="shell">
    <div class="setPoints">
      <div :id="id" style="width: 200px; height: 140px">
        {{ totalScore }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    totalScore: {
      type: Number,
      default: 0,
    },

    loading: {
      type: Boolean,
      default: false,
    },
    id: {
      type: String,
      default: "",
    }
  },
  data() {
    return {};
  },
  mounted() {
    this.initWater();
  },
  watch: {
    totalScore(val) {
      this.$nextTick(() => {
        this.initWater(val);
      });
    },
  },
  methods: {
    initWater(val) {
      let _this = this;
      this.$nextTick(() => {
        let title = "";
        if (this.$route.query.originPla == `appCenter`) {
          title = "总分";
        } else if (this.$route.query.originPla == `PA`) {
          title = "绩效评价得分";
        } else {
          title = "综合执法得分";
        }
        this.$echartsCase.echarStyle4(_this.id, val || 0, title);
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.shell {
  width: 100%;
}
.setPoints {
  display: flex;
  justify-content: center;
}
</style>
