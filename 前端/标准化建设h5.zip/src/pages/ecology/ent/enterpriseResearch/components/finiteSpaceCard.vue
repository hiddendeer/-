<template>
	<view class="finite-space-container">
		<u-card :show-head="false" :showFoot="false" margin="15rpx" padding="15" :head-border-bottom="false"
			@body-click="handlerBodyClick">
			<view class="u-body" slot="body">
				<view class="u-body-item">
					<image :src="dataList.spacePhoto?dataList.spacePhoto:noImgUrl" mode="aspectFill"></image>
					<!-- <eagle-img :src="dataList.spacePhoto" /> -->
				</view>
				<view class="u-body-item-title">
					<view class="">
						<text style="font-size: 30rpx;">{{dataList.spaceName}}</text>
					</view>
					<view>
						<text>编号：{{dataList.no}}</text>
					</view>
					<view>
						<u-tag :text="item" size="mini" v-for="(item,index) in spaceTypeArr" :key='index+"spaceTypeArr"'
							style="margin: 5rpx;" />
						<u-tag :text="item" size="mini" type="error" v-for="(item,index) in mainRiskCodeArr"
							:key='index+"mainRiskCodeArr"' style="margin: 5rpx;" />
						<!-- <u-tag text="高空坠落" size="mini" type="error" /> -->
					</view>
				</view>
				<u-icon class="u-body-item-icon" name="arrow-right"></u-icon>
			</view>
		</u-card>
	</view>
</template>

<script>
	export default {
		props: {
			dataList: {
				type: Object,
				default: () => {}
			},
			params: {
				type: Object,
				default: () => {}
			},
		},
		data() {
			return {
				spaceTypeArr: [],
				mainRiskCodeArr: [],
				noImgUrl: require('@/static/img/no-img.png')
			}
		},
		created() {

			let spaceType = this.common.splitParamsFormat(this.dataList.spaceType, this.params.siteSpaceTypeArray)
			this.spaceTypeArr = spaceType.split(',')

			let mainRiskCode = this.common.splitParamsFormat(this.dataList.mainRiskCode, this.params.siteSpaceDangerArray)
			this.mainRiskCodeArr = mainRiskCode.split(',')

			// spaceType
		},
		methods: {
			handlerBodyClick() {
				this.$emit('handlerBodyClick')
			},
		},
	}
</script>


<style scoped lang="scss">
	.finite-space-container {
		width: 100%;
		overflow: hidden;
		box-sizing: border-box;

		.btn-box {
			display: flex;
			justify-content: center;
			align-items: center;
			color: #303133;

			view {
				width: 300rpx;
				height: 60rpx;
				line-height: 60rpx;
				text-align: center;

				.foot-icon {
					width: 28rpx;
					height: 28rpx;
					margin-right: 15rpx;
				}
			}
		}

		.u-body {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.u-body-item {
			width: 250rpx;
			height: 150rpx;
			text-align: center;

			image {
				width: 250rpx;
				height: 150rpx;
			}
		}

		.u-body-item-title {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			width: 370rpx;

			.u-tag {
				margin-right: 10rpx;
			}
		}

		.u-body-item-icon {
			width: 28rpx;
		}
	}
</style>
