<template>
	<view class="equipment-card-container">
		<u-card :show-head="false" margin="15rpx" padding="15" :head-border-bottom="false"
			@body-click="handlerBodyClick">
			<view class="u-body" slot="body">
				<view class="u-body-item">
					<image :src="dataList.equipmentPhoto?dataList.equipmentPhoto:noImgUrl" mode="aspectFill">
					<!-- <eagle-img :src="dataList.equipmentPhoto" width='200rpx' height='80rpx'/> -->
					</image>
					<u-tag text="一般设备" size="mini" />
				</view>
				<view class="u-body-item-title">
					<view class="d-flex-between">
						<text style="font-size: 30rpx;">{{dataList.equipmentName}}</text>
						<text style="font-size: 24rpx;color: #999999">部门:{{dataList.orgName}}</text>
					</view>
					<view class="d-flex-around">
						<text>设备型号：{{dataList.equipmentModel}}</text>
						<text>设备编号：{{dataList.equipmentNo}}</text>
					</view>
				</view>
				<u-icon class="u-body-item-icon" name="arrow-right"></u-icon>
			</view>
			<view class="" slot="foot">
				<view class="btn-box">
					<view size="medium" @click="handlerMaintain">
						<u-icon class="foot-icon" name="setting"></u-icon>
						<text>维保</text>
					</view>
					<view size="medium" @click="handlerEdit">
						<u-icon class="foot-icon" name="edit-pen"></u-icon>
						<text>编辑</text>
					</view>
					<view size="medium" @click="handlerDel">
						<u-icon class="foot-icon" name="close"></u-icon>
						<text>删除</text>
					</view>
				</view>
			</view>
		</u-card>
	</view>
</template>

<script>
	export default {
		props: {
			dataList: {
				type: Object,
				default: () => {}
			}
		},
		data() {
			return {
				params: {
					ProjectBuildDangerTypeArray: [],
					ProjectBuildFireGradeArray: [],
					ProjectBuildPurposeArray: [],
					buildRegulatoryfocusArray: [],
					ProjectBuildMaterialArray: [],
					ProjectBuildStructureArray: [],
				},
				noImgUrl: require('@/static/img/no-img.png')
			}
		},
		created() {
			// this.initData()
		},
		methods: {
			initData() {
				console.log('111: ', 111)
				let _this = this
				this.enterpriseCode = this.$route.query.enterpriseCode
				this.common.getparamsList(
					'end_building_danger_type,end_building_fire_grade,end_building_purpose,end_building_Regulatoryfocus,end_building_material,end_building_structure'
				).then(res => {
					console.log(res)
					if (res.code === 200) {
						this.params.ProjectBuildDangerTypeArray = res.data.filter(item => {
							return item.paramId === 'end_building_danger_type'
						})
						this.params.ProjectBuildFireGradeArray = res.data.filter(item => {
							return item.paramId === 'end_building_fire_grade'
						})
						this.params.ProjectBuildMaterialArray = res.data.filter(item => {
							return item.paramId === 'end_building_material'
						})
						this.params.ProjectBuildPurposeArray = res.data.filter(item => {
							return item.paramId === 'end_building_purpose'
						})
						this.params.ProjectBuildStructureArray = res.data.filter(item => {
							return item.paramId === 'end_building_structure'
						})
						this.params.buildRegulatoryfocusArray = res.data.filter(item => {
							return item.paramId === 'end_building_Regulatoryfocus'
						})
					}
				})
			},
			handlerBodyClick() {
				this.$emit('handlerBodyClick')
			},
			handlerEdit() {
				this.$emit('handlerEdit')
			},
			handlerDel() {
				this.$emit('handlerDel')
			},
			handlerMaintain() {
				this.$emit('handlerMaintain')
			},
		},
	}
</script>


<style scoped lang="scss">
	.equipment-card-container {
		width: 100%;
		overflow: hidden;
		box-sizing: border-box;

		.btn-box {
			display: flex;
			justify-content: center;
			align-items: center;
			color: #303133;

			view {
				width: 300rpx;
				height: 60rpx;
				line-height: 60rpx;
				text-align: center;

				.foot-icon {
					width: 28rpx;
					height: 28rpx;
					margin-right: 15rpx;
				}
			}
		}

		.u-body {
			display: flex;
			justify-content: space-between;
		}

		.u-body-item {
			width: 250rpx;
			height: 150rpx;
			text-align: center;

			image {
				width: 200rpx;
				height: 110rpx;
			}
		}

		.u-body-item-title {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			width: 370rpx;

		}

		.u-body-item-icon {
			width: 28rpx;
		}

		.d-flex-between {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.d-flex-around {
			display: flex;
			flex-direction: column;
			justify-content: flex-start;
		}
	}
</style>
