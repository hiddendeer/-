<template>
	<view class="host-ent-erprise-card-container">
		<u-card :show-head="false" margin="15rpx" padding="15" :head-border-bottom="false" :show-foot="false"
			@body-click="handlerBodyClick">
			<view class="u-body" slot="body">
				<view class="u-body-item">
					<image src="./工作证.png" mode="aspectFit"  style="width: 200rpx;height: 100rpx;"></image>
					<!-- <u-icon name="file-text" size="150"></u-icon> -->
					<text>{{dataList.jobPosition}}</text>
					<!-- <text></text> -->
				</view>
				<view class="u-body-item-title">
					<view class="d-flex-between">
						<text style="font-size: 30rpx;">{{dataList.orgName}}</text>
						<text style="font-size: 24rpx;color: #999999">员工:{{dataList.stuffNumber}}人</text>
						<!-- <text style="font-size: 24rpx;color: #999999">员工:{{dataList.stuffNumber}}人</text> -->
					</view>

					<view class="d-flex-between" style="justify-content: flex-start;flex-wrap: wrap;">
						<u-tag :text="item" size="mini" mode="plain" v-for="(item,index) in occupationalHazardFactors"
							:key='index+"occupationalHazardFactors"' style="margin: 5rpx;"/>
					</view>
					<view class="">

						<view class="d-flex-start">
							<text>劳保要求:</text>
							<u-image width="60" height="60" :src="item.markAttach"
								v-for="(item,index) in laborProtectionRequirement" :key='index'></u-image>
						</view>

						<!-- <u-icon name="trash"></u-icon>
						<u-icon name="trash"></u-icon> -->
					</view>
				</view>
				<u-icon class="u-body-item-icon" name="arrow-right"></u-icon>
			</view>
		</u-card>
	</view>
</template>

<script>
	export default {
		props: {
			dataList: {
				type: Object,
				default: () => {}
			}
		},
		data() {
			return {
				occupationalHazardFactors: [],
				laborProtectionRequirement: []
			}
		},
		created() {
			if (this.dataList.occupationalHazardFactors) {
				var arry = this.dataList.occupationalHazardFactors.split(',')
				this.occupationalHazardFactors = arry
			}


			let val = this.dataList.laborProtectionRequirement

			if (val) {
				if (typeof val === 'string') {
					var arryFile = JSON.parse(val)
					this.laborProtectionRequirement = arryFile
				} else {
					this.laborProtectionRequirement = val
				}
			}



			// dataList
			// occupationalHazardFactors
			// this.initData()
		},
		methods: {
			initData() {
				this.enterpriseCode = this.$route.query.enterpriseCode
				this.common.getparamsList(
					'end_building_danger_type,end_building_fire_grade,end_building_purpose,end_building_Regulatoryfocus,end_building_material,end_building_structure'
				).then(res => {
					console.log(res)
					if (res.code === 200) {
						this.params.ProjectBuildDangerTypeArray = res.data.filter(item => {
							return item.paramId === 'end_building_danger_type'
						})
						this.params.ProjectBuildFireGradeArray = res.data.filter(item => {
							return item.paramId === 'end_building_fire_grade'
						})
						this.params.ProjectBuildMaterialArray = res.data.filter(item => {
							return item.paramId === 'end_building_material'
						})
						this.params.ProjectBuildPurposeArray = res.data.filter(item => {
							return item.paramId === 'end_building_purpose'
						})
						this.params.ProjectBuildStructureArray = res.data.filter(item => {
							return item.paramId === 'end_building_structure'
						})
						this.params.buildRegulatoryfocusArray = res.data.filter(item => {
							return item.paramId === 'end_building_Regulatoryfocus'
						})
					}
				})
			},
			handlerBodyClick() {
				this.$emit('handlerBodyClick')
			},
		},
	}
</script>


<style scoped lang="scss">
	.host-ent-erprise-card-container {
		width: 100%;
		overflow: hidden;
		box-sizing: border-box;

		.u-body {
			display: flex;
			justify-content: space-between;
		}

		.u-body-item {
			width: 250rpx;
			// height: 150rpx;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;

		}

		.u-body-item-title {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			width: 370rpx;
		}

		.u-body-item-icon {
			width: 28rpx;
		}

		.d-flex-between {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.d-flex-start {
			margin-top: 10px;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			flex-wrap: wrap;
		}
	}
</style>
