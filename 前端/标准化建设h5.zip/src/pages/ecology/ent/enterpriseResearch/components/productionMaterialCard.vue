<template>
	<view class="production-material-card-container">
		<u-card :show-head="false" :showFoot="false" margin="15rpx" padding="15" :head-border-bottom="false"
			@body-click="handlerBodyClick">
			<view class="u-body" slot="body">
				<view class="u-body-item">
					<image :src="dataList.photo?dataList.photo:noImgUrl" mode="aspectFill"></image>
				</view>
				<view class="u-body-item-title">
					<view class="">
						<text style="font-size: 30rpx;">{{dataList.materialName}}</text>
					</view>
					<view v-if='true'>
						<text>用途：{{dataList.mainPurposeCode|splitParamsFormat(params.siteMaterialPurposeArray)}}</text>
					</view>
					<view v-if='false'>
						<text>型号：JB36Y</text>
						<text>数量：3</text>
					</view>
					<view>
						<u-tag :text="item" size="mini" v-for="(item,index) in dangerAttributeArr" :key='index'
							style="margin: 5rpx;" />
					</view>
				</view>
				<u-icon class="u-body-item-icon" name="arrow-right"></u-icon>
			</view>
		</u-card>
	</view>
</template>

<script>
	export default {
		props: {
			dataList: {
				type: Object,
				default: () => {}
			},
			params: {
				type: Object,
				default: () => {}
			},
		},
		data() {
			return {
				dangerAttributeArr: [],
				noImgUrl: require('@/static/img/no-img.png')
			}
		},

		created() {

			let dangerAttributeCode = this.common.splitParamsFormat(this.dataList.dangerAttributeCode, this.params
				.siteMaterialDangerAttributeArray)

			if (dangerAttributeCode != '') {
				this.dangerAttributeArr = dangerAttributeCode.split(',')
			}

			// dangerAttributeCode
		},

		methods: {
			handlerBodyClick() {
				this.$emit('handlerBodyClick')
			},
		},
	}
</script>


<style scoped lang="scss">
	.production-material-card-container {
		width: 100%;
		overflow: hidden;
		box-sizing: border-box;

		.btn-box {
			display: flex;
			justify-content: center;
			align-items: center;
			color: #303133;

			view {
				width: 300rpx;
				height: 60rpx;
				line-height: 60rpx;
				text-align: center;

				.foot-icon {
					width: 28rpx;
					height: 28rpx;
					margin-right: 15rpx;
				}
			}
		}

		.u-body {
			display: flex;
			justify-content: space-between;
		}

		.u-body-item {
			width: 250rpx;
			height: 150rpx;
			text-align: center;
			align-items: center;

			image {
				width: 100%;
				height: 100%;
			}
		}

		.u-body-item-title {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			width: 370rpx;
		}

		.u-body-item-icon {
			width: 28rpx;
		}
	}
</style>
