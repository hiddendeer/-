<template>
    <view class="maintain-detail-container">
        <eagle-form @initCallBack="initCallBack" :control="control" v-model="model" ref="eagleForm" :out-height='60' :errorType="errorType" labelWidth="150" :boolInitData="true" labelAlign='left'>
            <eagle-container title="维保详情">
                <eagle-text :value="model.maintenanceDate|dateFormat" title="维保日期" prop="maintenanceDate" />
                <eagle-text v-model="model.maintenanceChnName" title="维保人" prop="maintenanceChnName" />
                <eagle-text v-model="model.maintenanceContent" title="维保内容" prop="maintenanceContent" />
                <eagle-text v-model="model.remarks" title="备注" prop="remarks" />
                <eagle-display-image title="维保图片" :value="model.attach" />
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button type="primary" class="bottom-btn" @click="handlerEdit">编辑</u-button>
            <u-button type="error" class="bottom-btn" @click="handlerDel">删除</u-button>
        </eagle-bottom-view>
    </view>
</template>

<script>
export default {
    components: {},
    data() {
        return {
            model: {},
            companyCode: "",
            projectId: "",
            code: "",
            mainCode: "",
            errorType: ["message"],
            control: "ecologyEnv/maintenance",
            labelPosition: "left",
            labelWidth: "150",
            type: "",
            deletable: true,
            isShow: false,
        };
    },
    created() {
        this.companyCode = this.$route.query.enterpriseCode;
        this.projectId = this.$route.query.projectId;
        this.code = this.$route.query.code;
        this.mainCode = this.$route.query.mainCode;
        this.model.mainCode = this.mainCode;
        this.model.id = this.$route.query.id;
        this.isShow = true;
    },
    onShow() {
        if (this.isShow) {
            this.$refs.eagleForm.get();
        }
    },
    methods: {
        initCallBack(data) {
            // this.model = data
        },
        handlerEdit(data) {
            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/maintain/detail",
                {
                    mainCode: this.mainCode,
                    code: this.code,
                    enterpriseCode: this.companyCode,
                    projectId: this.projectId,
                    id: this.model.id,
                }
            );

            this.base.navigateTo(linkUrl);
        },
        close() {
            this.base.navigateBack();
        },
        handlerDel() {
            let _this = this;
            this.$refs.eagleForm.del({
                successCallback: function () {
                    _this.close();
                },
            });
        },
    },
};
</script>

<style scoped lang="scss">
.maintain-detail-container {
    // padding: 15rpx;
    box-sizing: border-box;

    .maintain-detail-title {
        height: 80rpx;
        line-height: 80rpx;
        font-size: 40rpx;
        font-weight: 600;
        padding-left: 30rpx;
        box-sizing: border-box;
    }
}
</style>
