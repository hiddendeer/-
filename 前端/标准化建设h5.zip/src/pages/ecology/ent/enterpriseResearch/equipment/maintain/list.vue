<template>
    <view class="maintain-container eagle-layer">
        <!--  -->
        <eagle-container>
            <view class="maintain-title">
                维保历史
            </view>
            <eagle-page-list ref="eaglePageList" @initList="initList" :pageSize="20" :controller="controller" :margin-bottom="100" :showCheck="true" :boolInitData="false" searchDisplay='none'>
                <view slot="list">
                    <view class="maintain-content">
                        <u-time-line>
                            <u-time-line-item v-for="(item,index) in list" :key='index'>
                                <template v-slot:content>
                                    <view @click="handlerBodyClick(item)">
                                        <view class="u-order-top">
                                            <view class="u-order-time">{{item.maintenanceDate|dateFormat}}</view>
                                            <view class="u-order-name">
                                                <view class="left">维保人</view>
                                                <view class="right">{{item.maintenanceChnName}}</view>
                                            </view>
                                        </view>
                                        <view class="u-order-desc">
                                            {{item.maintenanceContent}}
                                        </view>
                                    </view>
                                </template>
                            </u-time-line-item>
                        </u-time-line>
                    </view>
                </view>
            </eagle-page-list>
        </eagle-container>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
        <!-- <view class="host-footer" ></view> -->
        <!-- <tabbar-host></tabbar-host> -->
    </view>
</template>

<script>
// import TabbarHost from '@/pages/components/tabbar/tabbar-host.vue'
export default {
    data() {
        return {
            controller: "ecologyEnv/maintenance",
            list: [],
            companyCode: "",
            code: "",
            mainCode: "",
        };
    },

    created() {},
    onShow() {
        console.log("onShow");
        this.companyCode = this.$route.query.enterpriseCode;
        this.code = this.$route.query.code;
        this.mainCode = this.$route.query.mainCode;
        this.initData();
    },
    methods: {
        initList(data) {
            this.list = data;
        },
        initData() {
            var _this = this;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    params: { mainCode: _this.mainCode },
                });
            });
        },

        handlerBodyClick(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/maintain/view",
                {
                    mainCode: this.mainCode,
                    code: this.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                    id: item.id,
                }
            );

            this.base.navigateTo(linkUrl);
        },

        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/maintain/detail",
                {
                    mainCode: this.mainCode,
                    code: this.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },
    },
};
</script>

<style scoped lang="scss">
.maintain-container {
    box-sizing: border-box;
    overflow: hidden;

    .maintain-title {
        height: 80rpx;
        line-height: 80rpx;
        font-size: 40rpx;
        font-weight: 600;
        padding-left: 30rpx;
        box-sizing: border-box;
        background: #ffffff;
    }

    .maintain-content {
        padding: 0 80rpx;
        box-sizing: border-box;
        background: #ffffff;
    }

    .u-node {
        width: 44rpx;
        height: 44rpx;
        border-radius: 100rpx;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #d0d0d0;
    }

    .u-order-title {
        color: #333333;
        font-weight: bold;
        font-size: 32rpx;
    }

    .u-order-top {
        display: flex;
        justify-content: space-between;
    }

    .u-order-desc {
        color: #666;
        font-size: 28rpx;
        margin-bottom: 6rpx;
    }

    .u-order-time {
        color: #333;
        font-size: 26rpx;
    }

    .u-order-name {
        display: flex;
        justify-content: flex-start;
        border: 1rpx solid #31bdb4;
        border-radius: 8rpx;
        background: #31bdb4;

        .left {
            color: #ffffff;
            padding: 5rpx 10rpx;
            box-sizing: border-box;
        }

        .right {
            background: #ffffff;
            color: #31bdb4;
            padding: 5rpx 10rpx;
            box-sizing: border-box;
            border-radius: 0 3px 3px 0px;
        }
    }

    .host-footer {
        width: 100%;
        height: 200rpx;
        line-height: 200rpx;
        padding-left: 100rpx;
        box-sizing: border-box;
        position: fixed;
        left: 0;
        bottom: 0;
        display: flex;
        align-items: center;
        color: #2979ff;
        border-top: 1px dashed #cccccc;

        text {
            margin-left: 20rpx;
        }
    }
}
</style>
