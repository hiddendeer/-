<template>
  <view class="equipment-facilities-detail-container eagle-layer">
    <eagle-form
      @initCallBack="initCallBack"
      :control="control"
      v-model="model"
      ref="eagleForm"
    >
      <eagle-container title="设备设施详情">
        <eagle-text title="所在区域" v-model="model.locationName" />
        <eagle-text title="设备照片">
          <eagle-display-image :value="model.equipmentPhoto" />
        </eagle-text>
        <eagle-text title="部门" v-model="model.orgName" />
        <eagle-text title="设备名称" v-model="model.equipmentName" />
        <eagle-text title="设备型号" v-model="model.equipmentModel" />
        <eagle-text title="设备数量" v-model="model.equipmentCount" />
        <eagle-text title="特种设备" v-model="specialEquipmentValue">
        </eagle-text>
        <eagle-text title="是否有安全附件" v-model="safetyValue"> </eagle-text>
        <template v-if="safetyValue === '是'">
          <eagle-text title="安全附件">
            <eagle-checkbox-group
              :disabled="true"
              v-model="model.secureAttach"
              :data-source="params.SiteEquipmentSecureAttachArray"
            />
          </eagle-text>
        </template>
        <eagle-text title="设备资料">
          <eagle-grid-attach
            title=""
            v-model="model.attachs"
          ></eagle-grid-attach>
        </eagle-text>
        <eagle-text title="维保事项" v-model="model.maintenanceAttention">
        </eagle-text>
        <eagle-text title="维护保养频次">
          {{
            model.maintenanceFrequency | splitParamsFormat(params.fireFrequency)
          }}
        </eagle-text>
        <eagle-text title="备注" v-model="model.remarks"> </eagle-text>
        <template v-if="specialEquipmentValue === '是'">
          <view
            class="device"
            v-for="(item, index) in model.specialEquipmentList"
          >
            <view class="device-content">
              <div class="title">
                <span v-if="model.id"> 设备信息 </span>
                <span v-else> 设备{{ index + 1 }} </span>
              </div>
              <eagle-input
                v-model="item.equipmentNumber"
                title="设备编号"
                labelPosition="top"
                labelWidth="150"
                key="equipmentName1"
              />

              <eagle-date
                title="登记时间"
                type="datetime"
                v-model="item.registerDate"
              />
              <eagle-file-upload
                disabled
                :maxCount="10"
                title="使用登记证"
                prop="attachs"
                v-model="item.registerCertificateFile"
              />
              <!-- <eagle-file-upload
                disabled
                :maxCount="10"
                title="特种设备管理制度"
                prop="attachs"
                v-model="item.equipmentSpecialCheckFile"
              /> -->
              <eagle-file-upload
                disabled
                :maxCount="10"
                title="检测报告"
                prop="attachs"
                v-model="item.equipmentSpecialCheckReportFile"
              />
            </view>
          </view>
        </template>
      </eagle-container>
    </eagle-form>
  </view>
</template>

<script>
export default {
  data() {
    return {
      model: {},
      errorType: ["message"],
      control: "ecologyEnv/entEquipment",
      labelPosition: "top",
      labelWidth: "150",
      type: "",
      initUrl: `ecologyEnv/entEquipment/initData/0?code=${this.$route.query.code}`,
      deletable: true,
      specialEquipmentList: [{ name: "是" }, { name: "否" }],
      safetyList: [{ name: "是" }, { name: "否" }],

      params: {
        ProjectBuildStructureArray: [],
        SiteEquipmentSecureAttachArray: [],
        fireFrequency: [],
        // fire_frequency
      },
      numberBoxValue: 0,
      boolInitData: true,
      specialEquipmentValue: "",
      safetyValue: "",
      // initParams: {
      //     code: "",
      // },
      dialogShow: false,
    };
  },
  created() {
    this.model.id = this.$route.query.id;
    this.initData();
  },

  mounted() {},

  methods: {
    initCallBack(data) {
      if (this.model.equipmentType === "true") {
        this.specialEquipmentValue = "是";
      } else if (this.model.equipmentType === "false") {
        this.specialEquipmentValue = "否";
      }
      //
      if (this.model.isAttached === true) {
        this.safetyValue = "是";
      } else if (this.model.isAttached === false) {
        this.safetyValue = "否";
      }
      this.model.locationCode = this.$route.query.code;
    },

    initData() {
      console.log("111: ", 111);
      let _this = this;

      this.common
        .getparamsList(
          "site_equipment_secure_attach,end_building_structure,fire_frequency"
        )
        .then((res) => {
          console.log(res);
          if (res.code === 200) {
            this.params.ProjectBuildStructureArray = res.data.filter((item) => {
              return item.paramId === "end_building_structure";
            });
            this.params.SiteEquipmentSecureAttachArray = res.data.filter(
              (item) => {
                return item.paramId === "site_equipment_secure_attach";
              }
            );
            this.params.fireFrequency = res.data.filter((item) => {
              return item.paramId === "fire_frequency";
            });
          }
        });
    },
  },
};
</script>

<style scoped lang="scss">
.equipment-facilities-detail-container {
  /* padding: 15rpx; */
  box-sizing: border-box;
  overflow: hidden;
  height: 100%;
}

.device {
  width: 100%;
  padding: 20rpx;
  .device-content {
    border: 1px solid #d2d2e6;
    width: 100%;
    min-height: 400rpx;
    border-radius: 6px;
    .title {
      font-size: 32rpx;
      color: #02a7f0;
      padding: 10rpx;
    }
  }
}
</style>
