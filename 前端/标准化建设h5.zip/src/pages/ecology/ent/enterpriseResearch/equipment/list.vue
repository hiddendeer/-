<template>
    <view class="equipment-facilities-list-container">
        <eagle-page-list @initList="initList" ref="eaglePageList" :controller="controller" :margin-bottom="135" :queryParams="queryParams">
            <!-- <view slot="search" class="search-slot">
                <u-subsection mode='subsection' active-color='#2979FF' :list="radioList" :current="sectionCurrent" :height='60' :bold='false' @change="handlerSectionChange"></u-subsection>
            </view> -->
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in list" :key="index" :hasImg="true" :imgSrc="item.equipmentPhoto" @click="handlerBody(item)">
                    <eagle-row-view :isTitle="true" type="warn">
                        {{item.equipmentName}}
                        <template slot="icon">
                            {{item.locationName}}
                        </template>
                    </eagle-row-view>
                    <eagle-row-view :spaceBetween="false">
                        <view class="single-line">
                            设备型号：{{item.equipmentModel}}
                        </view>
                        <view class="single-line">
                            设备编号：{{item.equipmentNo}}
                        </view>
                        <view class="single-line">
                            部门：{{item.orgName}}
                        </view>
                        <!-- <view class="single-line">
                            特种设备：{{item.equipmentType === 'true'?"是":"否"}}
                        </view> -->
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="success" @click="handlerMaintain(item)" size="mini">维保</u-button>
                        <u-button type="error" @click="handlerDel(item.id)" size="mini">删除</u-button>
                        <u-button type="primary" @click="handlerEdit(item)" size="mini">编辑</u-button>
                        <!-- <u-icon class="eagle-blue eagle-row-span" name="setting-fill" label="维保" @click="handlerMaintain(item)" v-if="item.equipmentType=='true'" />
                        <u-icon class="eagle-red eagle-row-span" name="trash" label="删除" @click="handlerDel(item.id)" />
                        <u-icon class="eagle-blue eagle-row-span" name="edit-pen" label="编辑" @click="handlerEdit(item)"></u-icon> -->
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab v-if="!isAll" :popMenu='false' horizontal='right' @fabClick='handlerFabClick'></eagle-fab>
    </view>
</template>

<script>
import uButton from "../../../../../uview-ui/components/u-button/u-button.vue";
// import EquipmentCard from '../components/EquipmentCard.vue'
export default {
    components: { uButton },
    // components: { EquipmentCard },
    name: "equ-list",
    props: {
        name: {
            type: String,
            default() {
                return "";
            },
        },
        code: {
            type: String,
            default() {
                return "";
            },
        },
        isAll: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            controller: "ecologyEnv/entEquipment/",
            list: [],
            marginBottom: 140,
            radioList: ["不限", "一般设备", "特种设备"],
            sectionCurrent: 2,
            fabContent: [
                {
                    iconPath: "../../../static/img/AppIcon/icon_list_add.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_list_add.png",
                    text: "新增",
                    active: true,
                },
                {
                    iconPath: "../../../static/img/AppIcon/icon_camera.png",
                    selectedIconPath:
                        "../../../static/img/AppIcon/icon_camera.png",
                    text: "拍照",
                    active: false,
                },
                // {
                // 	iconPath: '',
                // 	selectedIconPath: '',
                // 	text: '连拍',
                // 	active: '',
                // },
            ],
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
            noImgUrl: require("@/static/img/no-img.png"),
        };
    },
    created() {
        this.queryParams.code = this.$route.query.code ?? "";

        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";

        this.queryParams.projectId = this.$route.query.projectId ?? "";

        setTimeout(() => {
            this.queryPage();
        });

        if (this.isAll) {
            this.marginBottom = 40;
        } else {
            this.marginBottom = 140;
        }
        uni.$on('_update_equipment_list', () => {
            this.queryPage();
        })
    },
    mounted() {
        // this.queryParams.enterpriseCode = this.$route.query.enterpriseCode
        // this.queryParams.projectId = this.$route.query.projectId
        // this.queryParams.code = this.$route.query.code
        // this.queryPage()
    },
    methods: {
        initList(data) {
            this.list = [];
            this.list = data;
        },
        search() {
            this.queryPage();
        },

        queryPage() {
            var conditions = [];

            if (this.sectionCurrent == 1) {
                conditions.push({
                    name: "equipmentType",
                    value: false,
                    operate: "=",
                });
            } else if (this.sectionCurrent == 2) {
                conditions.push({
                    name: "equipmentType",
                    value: true,
                    operate: "=",
                });
            }

            this.$refs.eaglePageList.search({
                conditions: conditions,
            });
        },
        handlerBodyClick(item, index) {
            console.log("item,index: ", item, index);
        },
        handlerSectionChange(index) {
            this.sectionCurrent = index;
            this.queryPage();
        },
        trigger(e) {
            console.log("e: ", e);
            this.fabContent.forEach((item, index) => {
                item.active = false;
                if (index === e.index) {
                    item.active = true;
                }
            });
            if (e.index === 0) {
                this.handlerFabClick();
            }
        },
        handlerMaintain(item) {
            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/maintain/list",
                {
                    mainCode: item.code,
                    code: this.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                }
            );

            this.base.navigateTo(linkUrl);
        },

        handlerBody(item) {
            //详情
            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/view",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                    code: this.code,
                    name: this.name,
                }
            );

            this.base.navigateTo(linkUrl);
        },

        handlerEdit(item) {
            //编辑

            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/detail",
                {
                    id: item.id,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                    code: this.code,
                    name: this.name,
                }
            );
            // let url =
            //     "pages/host/ent/enterpriseResearch/equipment/detail?id=" +
            //     item.id +
            //     "&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url = url + "&projectId=" + this.$route.query.projectId;
            // }
            this.base.navigateTo(linkUrl);
        },
        handlerFabClick() {
            let linkUrl = this.common.getLinkUrl(
                "pages/ecology/ent/enterpriseResearch/equipment/detail",
                {
                    id: 0,
                    code: this.code,
                    name: this.name,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                }
            );

            // let url =
            //     "pages/host/ent/enterpriseResearch/equipment/detail?id=0&code=" +
            //     this.code +
            //     "&name=" +
            //     this.name;
            // if (this.$route.query.enterpriseCode) {
            //     url =
            //         url + "&enterpriseCode=" + this.$route.query.enterpriseCode;
            // }
            // if (this.$route.query.projectId) {
            //     url = url + "&projectId=" + this.$route.query.projectId;
            // }

            this.base.navigateTo(linkUrl);
        },
        handlerDel(id) {
            let _this = this;
            let url = this.controller + "/delete/" + id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.$refs.eaglePageList.search();
                },
            });
        },
        onreachBottom() {},
    },
     beforeDestroy() {
        uni.$off('_update_equipment_list')
    }
};
</script>

<style scoped lang='scss'>
.equipment-facilities-list-container {
    /* padding: 0 15rpx; */
    box-sizing: border-box;
}

.circleShow {
    height: 50rpx;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 50rpx;
}

.equipment-footer {
    width: 100%;
    height: 200rpx;
    line-height: 200rpx;
    padding-left: 100rpx;
    box-sizing: border-box;
    position: fixed;
    left: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    color: #2979ff;
    border-top: 1px dashed #cccccc;

    text {
        margin-left: 20rpx;
    }
}
</style>
