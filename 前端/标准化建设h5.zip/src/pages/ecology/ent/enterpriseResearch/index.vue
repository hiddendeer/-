<template>
    <view class="host-ent-erprise-container">
        <view class="header-box">
            <text class="left">当前区域:{{ form.buildName }}</text>
            <text class="right" @click="handlercheckdWorkShop(form)">切换</text>
        </view>
        <view class="u-tabs-box">
            <u-tabs-swiper activeColor="#2979ff" inactive-color="#606266" name="Name" :showBar="false" ref="tabs" :list="tabList" :bar-width="100" :current="tabIndex" @change="onTabChanged" :is-scroll="false">
            </u-tabs-swiper>
        </view>
        <swiper class="swiper-box" :current="tabContentIndex" @transition="transition" @animationfinish="animationfinish">
            <!-- 作业岗位 -->
            <swiper-item class="swiper-item">
                <OperationPost ref="OperationPost" :code="form.code" :name="form.buildName"></OperationPost>
            </swiper-item>
            <!-- 设备设施 -->
            <swiper-item class="swiper-item">
                <EquipmentFacilities ref="EquipmentFacilities" :code="form.code" :name="form.buildName">
                </EquipmentFacilities>
            </swiper-item>
            <!-- 生产原辅料 -->
            <swiper-item class="swiper-item">
                <ProductionMaterials ref="ProductionMaterials" :code="form.code" :name="form.buildName">
                </ProductionMaterials>
            </swiper-item>
            <!-- 有限空间 -->
            <swiper-item class="swiper-item">
                <FiniteSpace ref="FiniteSpace" :code="form.code" :name="form.buildName"></FiniteSpace>
            </swiper-item>
        </swiper>
        <tabbar-host v-if="queryParams.enterpriseCode"></tabbar-host>
        <tabbar-site v-else></tabbar-site>

        <u-popup v-model="scopedShow" mode='top' height="100%">
            <eagle-head title='请选择建构筑物' @close='handlerClose'></eagle-head>
            <scroll-view scroll-y class="scroll">
                <view class="check-scoped-container">
                    <view v-for="(item, index) in scopedData" :key="item.id" @click="handlerChoose(item, index)">
                        <view class="content" :class="{ 'active': activeIndex === index }">
                            <image :src="item.buildPhoto ? item.buildPhoto : noImgUrl" style="width: 300rpx;height: 150rpx;" mode="aspectFill">
                            </image>
                            <view class="">{{ item.buildName }}</view>
                        </view>
                    </view>
                </view>
            </scroll-view>
        </u-popup>

    </view>
</template>

<script>
import OperationPost from "@/pages/host/ent/enterpriseResearch/post/list.vue";
import EquipmentFacilities from "./equipment/list.vue";
import ProductionMaterials from "./material/list.vue";
import FiniteSpace from "./limitSpace/list.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarSite from "@/pages/components/tabbar/tabbar-site.vue";
export default {
    components: {
        OperationPost, //作业岗位组件
        EquipmentFacilities, //设备设施组件
        ProductionMaterials, //生产原辅料组件
        FiniteSpace, //有限空间 组件
        TabbarHost,
        TabbarSite,
    },
    data() {
        return {
            tabList: [
                { name: "作业岗位" },
                { name: "设施设备" },
                { name: "生产原辅料" },
                { name: "有限空间" },
            ],
            tabIndex: 0,
            tabContentIndex: 0,
            pageNum: 1,
            pageSize: 20,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
                code: "",
            },
            form: {},
            scopedShow: false,
            scopedData: [],
            activeIndex: 0,
            noImgUrl: require("@/static/img/no-img.png"),
        };
    },
    mounted() {
        this.queryParams.code = this.$route.query.code ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";

        this.queryParams.projectId = this.$route.query.projectId ?? "";

        this.initData();
    },

    onShow() {
        if (this.tabContentIndex === 0) {
            if (this.$refs.OperationPost) {
                this.$refs.OperationPost.search();
            }
        }

        if (this.tabContentIndex === 1) {
            this.$refs.EquipmentFacilities.search();
        }

        if (this.tabContentIndex === 2) {
            this.$refs.ProductionMaterials.search();
        }

        if (this.tabContentIndex === 3) {
            this.$refs.FiniteSpace.search();
        }
    },
    methods: {
        initData() {
            let _this = this;
            let url = "site/entBuilding/getDataByCode/" + this.queryParams.code;
            this.common.get(url, {}).then(function (res) {
                if (res.code == 200) {
                    // console.log("res.data: ", res.data);
                    _this.form = res.data;
                }
            });
        },
        onTabChanged(index) {
            this.tabContentIndex = index;
        },
        transition(e) {
            let dx = e.detail.dx;
            this.$refs.tabs.setDx(dx);
        },
        animationfinish(e) {
            let current = e.detail.current;
            this.$refs.tabs.setFinishCurrent(current);
            this.tabContentIndex = current;
            this.tabIndex = current;
        },
        handlercheckdWorkShop(val) {
            this.scopedShow = true;
            this.common
                .get("site/entBuilding/getPageData", {
                    dataType: "list",
                    pageNum: 1,
                    pageSize: 20,
                    companyCode: val.companyCode,
                })
                .then((res) => {
                    if (res.code === 200) {
                        this.scopedData = res.data;
                        this.scopedData.forEach((item, index) => {
                            if (item.id === val.id) {
                                this.activeIndex = index;
                            }
                        });
                    }
                });
        },
        handlerClose() {
            this.scopedShow = false;
        },
        handlerChoose(item, index) {
            console.log("item,index: ", item, index);
            this.activeIndex = index;
            console.log("this.queryParams: ", this.queryParams);
            let url =
                "pages/host/ent/enterpriseResearch/index?enterpriseCode=" +
                this.queryParams.enterpriseCode +
                "&projectId=" +
                this.queryParams.projectId +
                "&code=" +
                item.code;
            if (this.tabContentIndex !== 0) {
                url += "&tabContentIndex=" + this.tabContentIndex;
            }
            this.base.navigateTo(url);
            this.handlerClose();
        },
    },
};
</script>


<style lang="scss">
.host-ent-erprise-container {
    width: 100vw;
    height: calc(100vh);
    overflow: hidden;
    box-sizing: border-box;

    .header-box {
        width: 100%;
        height: 70rpx;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #ffbf00;
        font-size: 36rpx;
        font-weight: bold;

        .left {
            color: #fff;
            font-size: 36rpx;
            margin-right: 50rpx;
        }

        .right {
            color: #3988ff;
        }
    }

    .swiper-box {
        width: 100%;
        height: calc(100vh - 55px);
    }

    .check-scoped-container {
        padding: 10rpx 30rpx;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;

        .content {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            padding: 10rpx;
            border: 2rpx solid #c8c9cc;
            border-radius: 10px;
            box-sizing: border-box;
            margin-top: 10px;

            &.active {
                border-color: #2979ff;
                color: #2979ff;
            }
        }
    }

    .btn {
        padding: 10rpx;
        box-sizing: border-box;
        display: flex;
        justify-content: space-around;
        background: #eeeeee;
    }
}
</style>
