<template>
    <view class="host-index">
        <project-main-index ref="project"></project-main-index>
        <view v-if="modulesId=='host'">
            <tabbar-host></tabbar-host>
        </view>
        <view v-else-if="modulesId=='dangerJg'">
            <tabbar-danger-jg></tabbar-danger-jg>
        </view>
    </view>
</template>

<script>
import ProjectMainIndex from "@/pages/components/project/project-main-index.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
import TabbarDangerJg from "@/pages/components/tabbar/tabbar-dangerJg.vue";
export default {
    name: "host-index",
    components: {
        ProjectMainIndex,
        TabbarHost,
        TabbarDangerJg,
    },
    data() {
        return {
            modulesId: "",
        };
    },
    created() {},
    mounted() {},
	
	onHide() {
	},
    onShow() {
		
		setTimeout(() => {
		    this.$refs.project.search();
		});
		
		
        this.modulesId = this.$route.query.modulesId;
        if (this.modulesId == "host") {
            uni.setNavigationBarTitle({ title: "管家服务平台" });
        } else if (this.modulesId == "dangerJg") {
            uni.setNavigationBarTitle({ title: "隐患排查服务平台" });
        }
    },
    methods: {},
};
</script>
