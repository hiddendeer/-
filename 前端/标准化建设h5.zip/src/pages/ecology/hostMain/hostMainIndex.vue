<template>
    <view class="host-index">
        <project-main-index ref="project"></project-main-index>
        <view>
            <tabbar-host></tabbar-host>
        </view>
    </view>
</template>

<script>
import ProjectMainIndex from "@/pages/components/project/project-host-main-index.vue";
import TabbarHost from "@/pages/components/tabbar/tabbar-host.vue";
export default {
    name: "host-index",
    components: {
        ProjectMainIndex,
        TabbarHost,
    },
    data() {
        return {
            modulesId: "",
        };
    },
    created() {
      
    },
    mounted() {},

    onHide() {},
    onShow() {
        setTimeout(() => {
            this.$refs.project.search();
        });
        this.modulesId = this.$route.query.modulesId;
        uni.setNavigationBarTitle({ title: "管家服务平台" });
    },
    methods: {},
};
</script>
