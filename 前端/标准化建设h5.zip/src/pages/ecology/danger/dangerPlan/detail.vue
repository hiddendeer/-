<template>
    <view>

        <eagle-form saveFunName="saveEntity" :control="control" v-model="model" ref="eagleForm" :out-height='50' :errorType="errorType" @initCallBack="bindData">
            <eagle-container>
                <eagle-radio-group title="检查类型" v-model="model.checkType" prop="checkType" v-if="pmTypeArray.length>0" :dataSource="pmTypeArray" :required="true" @change="changeType">
                </eagle-radio-group>
                <eagle-input title="任务名称" required v-model="model.checkTaskName" prop="checkTaskName"></eagle-input>
                <eagle-date type="daterange" :startDate.sync="model.startDate" :endDate.sync="model.endDate" title="任务检查时间" prop="startsDate" :height="70" required></eagle-date>
                <eagle-choose-user placeholderVal="请选择检查人" required title="检查人" :isMult="true" v-model="model.checkPersonName" :names.sync="model.checkPersonChName" prop="checkPersonName" />
                <u-form-item class="eagle-choose-input" label="检查表" labelPosition="top">
                    <!-- <u-input placeholder="请选择检查表" :value="checkStr" @click="dialogShow=true" :disabled="true">
                    </u-input>
                    <view v-show="codes" class="uni-date__icon-clear" :class="{border:'uni-date-clear'}" @click.stop="clearCheck">
                        <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                    </view> -->
                    <view class="choose-input-view eagle-flex-between" @click="dialogShow=true">
                        <view>
                            <span class="input-placeholder" v-if="!(model.relations&&model.relations.length>0)">请选择检查表</span>
                            <span v-else>
                                {{checkStr}}
                            </span>
                        </view>
                        <view v-show="model.relations&&model.relations.length>0" @click.stop="clearCheck">
                            <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                        </view>
                    </view>
                    <u-button class="choose-input-btn" type="primary" @click="dialogShow=true">
                        <u-icon size="12" name="plus"></u-icon>选择
                    </u-button>
                </u-form-item>
            </eagle-container>
        </eagle-form>
        <eagle-bottom-view>
            <u-button class="bottom-btn" type="primary" @click="post">保存</u-button>
        </eagle-bottom-view>
        <popup-table :isMult="true" :show.sync="dialogShow" :TagList="tagList" v-model="codes" @tableData="tableData"></popup-table>
    </view>
</template>
<script>
import popupTable from "@/components/eagle-check-table/popup-table";
export default {
    components: { popupTable },
    data() {
        return {
            dialogShow: false,
            startDate: "",
            model: {},
            tagList: [],
            codes: "",
            pmTypeArray: [],
            errorType: ["message"],
            control: "ecologyEnv/dangerCheckTask",
            urlParams: {
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    computed: {
        checkStr: {
            get: function () {
                if (this.model.relations && this.model.relations.length > 0) {
                    return "已选" + this.model.relations.length + "张检查表";
                } else {
                    return "";
                }
            },
        },
    },
    created() {
        this.model.ID = this.$route.query.id ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
        this.initParams();
    },
    onReady() {
        var _this = this;
    },
    mounted() {
        // this.resetTableHeight();
    },
    methods: {
        clearCheck() {
            this.model.relations = [];
        },
        changeType() {
            this.model.checkTypeName = this.common.formateDict(
                this.pmTypeArray,
                this.model.checkType
            );
        },
        initParams() {
            var _this = this;

            this.common
                .getparamsList("danger_plan_check_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.pmTypeArray = res.data.filter(
                            (p) => p.paramId == "danger_plan_check_type"
                        );
                        if (!_this.model.id || _this.model.id === "0") {
                            _this.model.checkType = _this.pmTypeArray[0].id;
                            _this.model.checkTypeName =
                                _this.pmTypeArray[0].name;
                        }
                    }
                });
        },
        removeTemp(index) {
            this.model.relations.splice(index, 1);
            this.getcodes();
        },
        getcodes() {
            let _this = this;
            _this.codes = "";
            _this.tagList = [];
            if (_this.model.relations && _this.model.relations.length > 0) {
                _this.model.relations.forEach((item) => {
                    _this.codes = _this.codes
                        ? `${_this.codes},${item.checkTemplateCode}`
                        : item.checkTemplateCode;
                    _this.tagList.push({
                        id: item.checkTemplateCode,
                        name: item.templateName,
                    });
                });
            }
        },
        // changDateRang() {
        //     if (this.model.datetimes && this.model.datetimes.length > 0) {
        //         this.model.startDate = this.model.datetimes[0];
        //         this.model.endDate = this.model.datetimes[1];
        //     }
        // },
        bindData() {
            let _this = this;
            // _this.model.datetimes = [];
            // _this.model.datetimes.push(_this.model.startDate);
            // _this.model.datetimes.push(_this.model.endDate);
            _this.model.projectId = _this.urlParams.projectId;
            _this.model.enterpriseCode = _this.urlParams.enterpriseCode;
            if (!_this.model.id || _this.model.id === "0") {
                _this.model.checkType = _this.pmTypeArray[0].id;
                _this.model.checkTypeName = _this.pmTypeArray[0].name;
            }
        },
        tableData(array) {
            let _this = this;
            this.model.relations = [];
            array.forEach((x) => {
                this.model.relations.push({
                    checkTaskCode: _this.model.code,
                    checkTemplateCode: x.id,
                    templateName: x.name,
                });
            });
        },
        post() {
            let _this = this;
            this.$refs.eagleForm.post({
                successCallback: function (res) {
                 
                    if (res.code == 200) _this.goToDetail(res.data.id);
                },
            });
        },
        goToDetail(id) {
            uni.redirectTo({
                url: `/pages/ecology/danger/dangerPlan/view?id=${id}&enterpriseCode=${this.urlParams.enterpriseCode}&projectId=${this.urlParams.projectId}`,
            });
        },
    },
};
</script>
<style lang="scss">
</style>
