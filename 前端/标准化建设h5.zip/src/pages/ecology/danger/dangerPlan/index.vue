<template name="host-danger-danger-plan">
    <view class="host-danger-danger-plan">
        <eagle-page-list :conditions="conditions" :margin-bottom="110" ref="eaglePageList" @initList="_initList" :boolInitData="false" :controller="controller" :dataType="dataType">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="queryParams" :searchResults="queryParams.year">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" title="任务状态" prop="status" :data-source="params.status" />
                        <eagle-select v-model="queryParams.year" title="选择年份:" prop="year" border :height="70" :data-source="list" labelWidth="150">
                        </eagle-select>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class=" list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="goToDetail(item.id)">
                    <eagle-girdrow-base isTitle>{{ item.checkTaskName }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-row-view v-if="item.checkTypeName">
                        检查类型: {{ item.checkTypeName }}
                        <!-- {{bindTag(item.status)}} -->
                    </eagle-row-view>
                    <eagle-row-view>
                        任务日期: {{ item.startDate | dateFormat }}至{{ item.endDate | dateFormat }}
                    </eagle-row-view>
                    <eagle-row-view>
                        检查人: {{ item.checkPersonChName }}
                    </eagle-row-view>
                    <template slot="button">
                        <u-button type="error" v-if="item.manager || (item.status == 10 && item.self)" @click="hdDelete(item)" size="mini">删除</u-button>
                        <u-button type="primary" @click="eidtPlan(item.id)" size="mini" v-if="item.status == 10">编辑
                        </u-button>
                        <u-button type="success" v-if="item.status != 10" @click="goToDetail(item.id)" size="mini">详情
                        </u-button>
                        <u-button type="primary" @click="goToDetail(item.id)" size="mini" v-if="item.status == 10">实施
                        </u-button>

                        <!-- <u-icon class="eagle-red eagle-row-span" name="trash" v-if="item.manager || (item.status==10 && item.self)" label="删除" @click="hdDelete(item)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" v-if="item.status == 10" name="edit-pen" label="编辑" @click="eidtPlan(item.id)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" v-if="item.status != 10" name="eye-fill" label="详情" @click="goToDetail(item.id)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" v-if="item.status == 10" name="checkmark" label="实施" @click="goToDetail(item.id)"></u-icon> -->
                    </template>
                </eagle-row-card>
            </view>

        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='eidtPlan(0)'></eagle-fab>
    </view>
</template>

<script>
import eagleYearMonth from "@/components/eagle-date/eagle-year-month";
export default {
    name: "host-danger-danger-plan",
    components: {
        eagleYearMonth,
    },
    data() {
        return {
            data: [],
            list: [],
            queryParams: {
                year: new Date().getFullYear(),
                enterpriseCode: "",
                projectId: "",
            },
            controller: "ecologyEnv/dangerCheckTask",
            dataType: "list",
            searchValue: "",
            conditions: {
                status: {
                    value: "",
                    operate: "=",
                },
            },
            params: {
                status: [
                    { id: "", name: "不限", type: "primary" },
                    { id: 10, name: "进行中", type: "primary" },
                    { id: 100, name: "已完成", type: "success" },
                ],
            },
            status: [
                { id: 1, name: "待实施", type: "primary" },
                { id: 2, name: "进行中", type: "primary" },
                { id: 3, name: "已逾期", type: "red" },
                { id: 4, name: "已完成", type: "success" },
            ],
        };
    },
    created() {
        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.list.push({
                id: i,
                name: i,
            });
        }
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        // _this.search()
    },
    methods: {
        bindTag(val) {
            let obj = this.params.status.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },

        _initList(data) {
            this.data = data;
        },
        search() {
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: "",
                    params: { year: this.queryParams.year },
                });
            });
        },
        reSearch() {
            this.queryParams.year = new Date().getFullYear();
            this.conditions.status = "";
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        close() {
            this.visible = false;
        },
        // show(config) {
        //     this.visible = true;
        //     if (config) {
        //         this.queryParams.enterpriseCode = config.enterpriseCode;
        //         this.queryParams.projectId = config.projectId;
        //     }
        //     this.search();
        // },
        eidtPlan(id) {
            let url = `/pages/ecology/danger/dangerPlan/detail?id=${id}&enterpriseCode=${this.queryParams.enterpriseCode}&projectId=${this.queryParams.projectId}`;
            this.base.navigateTo(url);
        },
        goToDetail(id) {
            let url = `/pages/ecology/danger/dangerPlan/view?id=${id}&enterpriseCode=${this.queryParams.enterpriseCode}&projectId=${this.queryParams.projectId}`;
            this.base.navigateTo(url);
        },
    },
};
</script>
 