<template>
  <view class="eagle-layer">
    <p class="tips-body">待政府端上线</p>
  </view>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      
    };
  },
  mounted() {
  },
  created() {

  },
  methods: {

  },
};
</script>

<style lang="scss" scoped>
.tips-body {
  color:#606266;
  padding: 20px  10px;
  text-align: center;
  font-size: 14px;
}
</style>

