<template name="site-danger-list-report">
    <view class="site-danger-list-report">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">隐患清单</eagle-head>
            <view style="background-color: #f3f4f6;">
                <eagle-form :control="control" v-model="model" ref="eagleForm" :out-height='50' :boolInitData="false">

                    <eagle-container title="任务信息">
                        <eagle-text v-model="model.enterpriseName" blod label="被检查单位">
                        </eagle-text>
                        <eagle-text v-model="model.sourceName" blod label="所属项目">
                        </eagle-text>
                        <eagle-text v-model="model.checkUserNames" blod label="检查人">
                        </eagle-text>
                        <eagle-text blod label="隐患清单生成日期">
                            {{model.buildDate}}
                        </eagle-text>
                    </eagle-container>
                    <view class="pannel">
                        <view class="uni-media-cell" v-for="(item,index) in model.dangerList" :key="item.ID">
                            <view class="uni-media-list">
                                <view class="uni-media-list-body">
                                    <eagle-girdrow-base>
                                        <eagle-girdrow-base :isTitle="true" :sBetween="true">
                                            <eagle-girdrow-block>{{index+1}}.{{item.hiddenDangerArea}}</eagle-girdrow-block>
                                        </eagle-girdrow-base>
                                        <view>
                                            <text>隐患描述 : {{item.hiddenDangerDesc}}</text>
                                        </view>
                                    </eagle-girdrow-base>
                                </view>
                            </view>
                        </view>

                    </view>
                </eagle-form>
                <eagle-bottom-view>
                    <u-button type="primary" class="bottom-btn" @click="post()">生成隐患清单</u-button>
                </eagle-bottom-view>
            </view>
        </u-popup>
        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    name: "dangerJg-danger-list-report",
    data() {
        return {
            constLabelPosition: "left",
            model: {},
            control: "ecologyEnv/dangerCheckTask",
            showDialog: false,
            taskCode: "",
            reportModel: {
                checkerSign: "",
                enterpriseSign: "",
            },
        };
    },
    methods: {
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        show(config) {
            let _this = this;
            _this.showDialog = true;
            _this.taskCode = config.taskCode;
            let url = `${_this.control}/getDangerListContent/${_this.taskCode}`;
            _this.common.get(url).then((res) => {
                _this.model = res.data;
            });
        },
        post() {
            let _this = this;
            let url = `${this.control}/buildDangerListReport/${_this.taskCode}`;
            _this.common.post(url).then((res) => {
                if (res.data.result) {
                    _this.successMsg("隐患清单保存成功");
                    _this.showDialog = false;
                    _this.$emit("saved", res.data);
                } else {
                    _this.errorMsg(res.data.errorMsg);
                }
            });
        },
    },
};
</script>

<style lang="scss">
</style>
