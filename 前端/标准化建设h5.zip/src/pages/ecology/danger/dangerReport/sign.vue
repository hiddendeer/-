<template>
  <view>
    <eagle-pdf-view
      v-if="url"
      :url="url"
      :title="title"
      :summary="title"
    ></eagle-pdf-view>
    <eagle-bottom-view v-if="url && site == 'guanguan' && report">
      <u-button
        type="primary"
        v-if="!report.checkerSign && report.code"
        class="bottom-btn"
        @click="sign(1)"
        >检查人签名</u-button
      >
      <u-button
        type="success"
        v-if="!report.enterpriseSign && report.code"
        class="bottom-btn"
        @click="sign(2)"
        >被检查单位签名</u-button
      >
    </eagle-bottom-view>
    <u-popup v-model="show" mode="right" width="100%" length="100%">
      <Autograph :show="show" @complete="complete" @cancel="cancel" />
    </u-popup>
    <u-toast ref="uToast" />
  </view>
</template>

<script>
import Autograph from "@/components/fui-autograph/index.vue";
export default {
  components: { Autograph },
  data() {
    return {
      url: "",
      title: "",
      reportCode: "",
      code: "",
      report: {},
      site: "",
      isApp: false,
      show: false,
      type: 1
    };
  },

  created() {
    this.site = process.env.VUE_APP_Site;
    this.reportCode = this.$route.query.reportCode ?? "";
    this.code = this.$route.query.code ?? "";
    this.isApp = this.base.isApp();
    this.init();
  },
  methods: {
    onCustomBack() {
      if (this.show) {
        this.show = false;
      } else {
        uni.navigateBack();
      }
    },
    init() {
      var _this = this;

      this.common.get("/file/getDataByAttCode/" + this.code).then((res) => {
        let url = `/site/dangerReport/getDataByCode/${this.reportCode}`;
        this.common.get(url, {}).then((res) => {
          if (res.code == 200) {
            this.report = res.data;
          }
        });
        var data = res.data;
        if (data.status == 1) {
          _this.$refs.uToast.show({
            title: "文件在转换中请稍后再试",
            type: "error"
          });
        } else if (data.status == 10) {
          _this.url = data.attMiddlePath;
          _this.isPdf = true;
        } else if (data.status == -1 || data.status == 50) {
          _this.$refs.uToast.show({
            title: "文件无法预览,请在电脑上端下载源文件查看",
            type: "error"
          });
        }
        _this.title = data.attName;
      });
    },
    close() {
      this.base.navigateBack(-1);
    },

    cancel() {
      this.show = false;
    },
    complete(base64) {
      let _this = this;
      let type = this.type;
      this.common.fuiPostBase64(base64).then((res) => {
        if ((res.success || res.code == 200) && res.data.length > 0) {
          let url = "/site/dangerReport/sign";
          if (type == 1) {
            this.report.checkerSign = res.data.join(",");
          }
          if (type == 2) {
            this.report.enterpriseSign = res.data.join(",");
          }
          _this.common.post(url, this.report).then((res) => {
            if (res.code == 200) {
              _this.url = "";
              _this.$refs.uToast.show({
                title: "签字成功",
                type: "success"
              });
              _this.init();
            }
          });
        } else {
          if (type == 1) this.report.checkerSign = "";
          if (type == 2) this.report.enterpriseSign = "";
        }
      });
    },
    sign(type) {
      this.type = type;
      this.show = true;
    }
  }
};
</script>

<style lang="scss"></style>
