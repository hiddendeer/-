<template name="host-plan-danger-report-index">
    <view class="host-danger-danger-plan">
        <eagle-page-list ref="eaglePageList" :conditions="conditions" @initList="_initList" :boolInitData="false" :pageSize="20" :controller="controller" :margin-bottom="110" @beforeLoad="beforeLoad" :showCheck="true" dataType="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.reportTemplateCode.value" title="报告类型" prop="reportTemplateCode" :data-source="params.reportTemplateCodeArry"></eagle-fast-choose>
                        <eagle-input title="隐患描述" placeholder="请输入报告名称模糊查询" v-model="conditions.reportName.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <eagle-row-view isTitle>
                        {{ item.reportName }}
                    </eagle-row-view>
                    <template slot="tag">
                        <view> <span class="orange"> {{ item.reportTemplateName }}</span></view>
                    </template>
                    <eagle-row-view sBetween>
                        <view> 创建人：{{ item.createChnName }}</view>
                        <view> 创建时间：{{ item.createDate | dateTimeFormat }}</view>
                    </eagle-row-view>

                    <template slot="button">
                        <!-- <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button> -->
                        <u-button type="success" size="mini" @click="showCheckAttachs(item)">查看报告</u-button>
                    </template>
                </eagle-row-card>
            </view>
        </eagle-page-list>
        <eagle-fab :popMenu='false' horizontal='right' @fabClick='showChooseTask'></eagle-fab>
        <popup-window :customItem="true" keyWordName="checkTaskName" ref="popupWindow" :isMult="false" headTitle="隐患排查任务" idField="code" textField="checkTaskName" controller="ecologyEnv/dangerCheckTask" dataType="list" @callBackChoosedData="choosedData">
            <template v-slot:body="scope">
                <view class="c333"> {{scope.item.checkTaskName}}</view>
                <view>检查人：{{scope.item.checkPersonChName}}</view>
            </template>
        </popup-window>
        <!-- <windowTaskList ref="windowTaskList" @callBackChoosedData="choosedData" /> -->
        <!-- <danger-report-detail ref="dangerReportDetail" @saveAfter="search" /> -->
    </view>

</template>
<script>
// import windowTaskList from "@/pages/host/danger/dangerPlan/windowTaskList";
import popupWindow from "@/components/eagle-window-choose/popup-window.vue";
// import dangerReportDetail from "@/pages/host/danger/dangerReport/detail";
export default {
    components: { popupWindow },
    data() {
        return {
            conditions: {
                reportName: { value: null, operate: "like" },
                reportTemplateCode: { value: "", operate: "=" },
            },
            controller: "ecologyEnv/dangerReport",
            data: [],
            clearabled: true,
            queryParams: {
                enterpriseCode: "",
                projectId: "",
            },
            params: {
                reportTemplateCodeArry: [],
            },
            isHost: true,
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.isHost = this.queryParams.projectId != "";
        this.getReportTemp();
    },
    mounted() {
        // this.search();
    },
    methods: {
        showChooseTask() {
            this.$refs.popupWindow.show();
        },
        reSearch() {
            this.conditions.reportName.value = "";
            this.conditions.reportTemplateCode.value = "";
        },

        showCheckAttachs(item) {
            // let fileList = [];
            // if (item.reportAttach) {
            //     if (typeof item.reportAttach == "string") {
            //         var arryFile = JSON.parse(item.reportAttach);
            //         fileList = arryFile;
            //     } else {
            //         fileList = item.reportAttach;
            //     }
            // }
            // if (fileList.length > 0) {
            //     let model = fileList[0];
            //     var url =
            //         "/pages/common/pdfView?code=" + model.attCode ||
            //         model.AttCode;
            //     this.base.navigateTo(url);
            // }
            let attach = JSON.parse(item.reportAttach)[0];
            let url = this.common.getLinkUrl(
                "/pages/ecology/danger/dangerReport/sign",
                {
                    code: attach.attCode || attach.AttCode,
                    reportCode: item.code,
                }
            );
            this.base.navigateTo(url);
        },

        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        _initList(list) {
            this.data = list;
        },
        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({});
        },
        choosedData(choosedData, codes, names) {
            if (codes) {
                let linkUrl = this.common.getLinkUrl(
                    "/pages/ecology/danger/dangerReport/detail",
                    {
                        taskCode: codes,
                        projectId: this.queryParams.projectId,
                        enterpriseCode: this.queryParams.enterpriseCode,
                    }
                );
                this.base.navigateTo(linkUrl);
            }
            // let taskName =
            //     "合并报告(" + this.common.dateFormatStr(new Date()) + ")";
            // if (codes.indexOf(",") < 0) {
            //     taskName = names;
            // }
            // let model = {
            //     checkTaskName: taskName,
            //     code: codes,
            //     companyCode: this.$route.query.enterpriseCode ?? "",
            //     enterpriseCode: this.$route.query.enterpriseCode ?? "",
            //     projectId: this.$route.query.projectId ?? "",
            // };
            // this.$refs.dangerReportDetail.show({
            //     taskModel: model,
            //     enterpriseCode: this.$route.query.enterpriseCode ?? "",
            // });
        },
        getReportTemp() {
            let type = "checkReport";
            if (!this.isHost) {
                type = "siteDangerReport";
            }
            let url = "ecologyEnv/fileToolDataSource/getMap?reportType=" + type;
            let _this = this;
            let arry = [{ id: "", name: "不限" }];
            _this.common.get(url).then((res) => {
                if (res.code == 200 && res.data && res.data.length > 0) {
                    _this.params.reportTemplateCodeArry = [];
                    res.data.forEach((element) => {
                        arry.push(element);
                    });
                    _this.params.reportTemplateCodeArry = arry;
                }
            });
        },
    },
};
</script>
<style lang="scss">
</style>
