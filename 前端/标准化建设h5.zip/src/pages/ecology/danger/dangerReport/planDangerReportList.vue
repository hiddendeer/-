<template name="host-plan-danger-report-list">
    <view class="host-plan-danger-report-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :bool-init-data="false" :pageSize="20" :controller="controller" :margin-bottom="38" @beforeLoad="beforeLoad" :showCheck="true" dataType="list">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="conditions.reportName.value" :show-action="false" @clear="search"></eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index">
                    <template slot="tag">
                        <view> <span class="orange"> {{ item.reportTemplateName }}</span></view>
                    </template>
                    <eagle-row-view :isTitle="true" type="warn" maxWidth="250px">
                        {{ item.reportName }}
                        <!-- <template slot="icon">
                            {{ item.reportTemplateName }}
                        </template> -->
                    </eagle-row-view>
                    <view>报告模板：{{ item.reportTemplateName }} </view>
                    <eagle-row-view>
                        创建人: {{ item.createChnName }}
                    </eagle-row-view>
                    <eagle-row-view>
                        创建时间: {{ item.createDate | dateTimeFormat }}
                    </eagle-row-view>
                    <template slot="button">
                        <!-- <u-button type="error" size="mini" @click="hdDelete(item)">删除</u-button> -->
                        <u-button type="success" size="mini" @click="showCheckAttachs(item)">查看报告</u-button>
                    </template>
                </eagle-row-card>

            </view>
        </eagle-page-list>

    </view>

</template>
<script>
export default {
    components: {},
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    data() {
        return {
            conditions: {
                reportName: { value: null, operate: "like" },
            },
            controller: "ecologyEnv/dangerReport",
            data: [],
            clearabled: true,
            taskCode: "",
        };
    },
    created() {
        this.taskCode = this.$route.query.taskCode;
    },
    methods: {
        reSearsh() {
            this.conditions.reportName.value = "";
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },

        _initList(list) {
            this.data = list;
        },

        search() {
            var conditions = [];
            let _this = this;
            setTimeout(() => {
                _this.$refs.eaglePageList.search({
                    conditions: _this.common.getCondtions(_this.conditions),
                    params: { taskCode: _this.taskCode },
                });
            });
        },
        showCheckAttachs(item) {
            // let fileList = [];
            // if (item.reportAttach) {
            //     if (typeof item.reportAttach == "string") {
            //         var arryFile = JSON.parse(item.reportAttach);
            //         fileList = arryFile;
            //     } else {
            //         fileList = item.reportAttach;
            //     }
            // }
            // if (fileList.length > 0) {
            //     let model = fileList[0];
            //     var url =
            //         "/pages/common/pdfView?code=" + model.attCode ||
            //         model.AttCode;
            //     this.base.navigateTo(url);
            // }
            let attach = JSON.parse(item.reportAttach)[0];
            let url = this.common.getLinkUrl(
                "/pages/ecology/danger/dangerReport/sign",
                {
                    code: attach.attCode || attach.AttCode,
                    reportCode: item.code,
                }
            );
            this.base.navigateTo(url);
        },
    },
};
</script>
<style lang="scss">
</style>
