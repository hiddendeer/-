<template name="host-danger-danger-detail">
    <view class="host-danger-danger-detail">
        <view>
            <eagle-form class="form-content" :control="control" :boolInitData="false" v-model="model" ref="eagleForm" marginBottom="80px">
                <view class="item">
                    <view class="item-container">
                        <view class="citem">
                            <view>
                                <eagle-display-input v-if="opType==0||opType==2 || opType===5" :value="model.originType|paramsFormat(checkDatas.checkSource)" required title="隐患来源" prop="originType">
                                </eagle-display-input>
                                <eagle-display-input v-if="opType==0||opType==2 || opType===5" :value="model.createChnName" required title="检查人" prop="createChnName">
                                </eagle-display-input>
                                <eagle-display-input v-if="opType==0||opType==2 || opType===5" :value="model.createDate|dateFormat" required title="检查时间" prop="createDate">
                                </eagle-display-input>
                            </view>
                            <view v-if="model.checkResult==='N'">
                                <eagle-upload :isNeedEdit="true" title="隐患图片" :required="model.originType==1" v-if="opType==1 || opType==3 || opType==4" key="attachs" prop="attachs" v-model="model.attachs" />
                                <eagle-display-image title="隐患图片" :required="model.originType==1" v-if="opType===0 || opType===2 || opType===5" key="display_attachs" prop="attachs" v-model="model.attachs">
                                </eagle-display-image>
                                <eagle-input :disabled="opType===0 || opType===2 || opType===5" type="textarea" title="隐患区域" onlyShowRequired v-model="model.correctiveArea" />
                                <eagle-input :disabled="opType===0 || opType===2 || opType===5" type="textarea" title="隐患描述" onlyShowRequired v-model="model.hiddenDangerDesc" />

                                <eagle-input type="textarea" :disabled="opType===0 || opType===2 || opType==5 " title="整改建议" v-model="model.correctiveAdvise">
                                    <template slot="topBotton">
                                        <view style="text-align: right;">
                                            <span v-if="opType!==0 && opType!==2  && opType!==5" style="color:#2979ff;margin-left: 10rpx;" @click="hdChooseLg()">选择依据</span>
                                            <span style="color:#2979ff;margin-left: 20rpx;margin-right: 20rpx;" @click="showDetail()">{{opType!==0 && opType!==2&& opType!==5?"编辑依据":"查看依据"}}</span>
                                        </view>
                                    </template>
                                </eagle-input>

                                <eagle-choose :disabled="opType===0" title="隐患分类" v-model="model.hiddenName" :required="needHiddenCode" onlyShowRequired :select-open="dangerTypeDialog" @click="showDangerType(model)">
                                </eagle-choose>
                                <eagle-radios :disabled="opType===0" title="隐患性质" required onlyShowRequired :data-source="checkDatas.checkType" v-model="model.hiddenDangerTypeCode" />
                                <view v-if="!isHost" style="position: relative;">
                                    <span v-if="opType!==0 && opType!==2 && opType!==5" style="color:#2979ff;position: absolute;right:50rpx;top:4rpx;font-size:32rpx;z-index:9;" @click="hdSetMeCorrective">由我本人整改</span>
                                    <eagle-choose-user v-if="opType===1 || opType==3  || opType==4 " placeholderVal="请选择整改负责人" required onlyShowRequired title="整改负责人" :isMult="false" v-model="model.appointCorrectiveName" :names.sync="model.appointCorrectiveChnName" prop="appointCorrectiveName" />
                                    <eagle-display-input v-if="opType===0 || opType==2  || opType==5 " :value="model.appointCorrectiveChnName" required onlyShowRequired title="整改负责人" prop="appointCorrectiveChnName" />
                                </view>
                                <eagle-radios :disabled="opType===0 || opType===2" title="整改方式" required onlyShowRequired :dataSource="checkDatas.correctiveType" v-model="model.correctiveType" />
                                <eagle-date v-if="model.correctiveType==2 || opType===2" label-width="100px" :disabled="opType===0" key="correctiveDeadline" title="整改期限" v-model="model.correctiveDeadline" />
                                <eagle-input v-if="model.correctiveType==2 || opType===2" type="textarea" :disabled="opType===0" key="correctiveMeasure" :row="2" label-width="100px" title="整改措施" v-model="model.correctiveMeasure" />
                                <eagle-upload title="整改图片" v-if="opType!=0 &&( model.correctiveType==1 || opType===2 || opType===5) " required key="correctiveAttachs" prop="correctiveAttachs" v-model="model.correctiveAttachs" />

                                <eagle-display-image title="整改图片" v-if="opType===0" required key="correctiveAttachs" prop="correctiveAttachs" v-model="model.correctiveAttachs" />

                                <eagle-input :disabled="opType===0" v-if="opType==0 ||( model.correctiveType==1 && (opType==1||opType==3||opType==4)) ||(opType==2 || opType===5)" type="textarea" key="correctiveDesc" :row="2" label-width="100px" title="整改说明" required v-model="model.correctiveDesc" />

                                <template v-if="opType==5">
                                    <view style="background: #ffffff;padding: 0 30rpx">

                                        <u-form-item class="eagle-text-form-item" ref="uFormItem" label-position="top" label="复查结论">
                                            <view class="btn-span">
                                                <text class="btn-dft" :class="model.pass?'pass':''" @click="model.pass=true">复查通过</text>
                                                <text class="btn-dft" :class="!model.pass?'un-pass':''" @click="model.pass=false">复查不通过</text>
                                            </view>
                                        </u-form-item>
                                    </view>
                                    <eagle-upload title="复查图片" key="receiveAttach" prop="receiveAttach" v-model="model.receiveAttach" />
                                </template>
                                <eagle-display-image title="复查图片" v-if="opType==2 && model.receiveCount>0 " key="receiveAttach" prop="receiveAttach" v-model="model.receiveAttach" />

                                <eagle-input v-if="(opType==2 && model.receiveCount>0 )|| opType==5" :disabled="opType!=5" type="textarea" key="receiveRemark" :row="2" label-width="100px" title="复查说明" v-model="model.receiveRemark" />

                            </view>
                        </view>
                    </view>
                </view>
            </eagle-form>
            <eagle-bottom-view>
                <u-button class="bottom-btn" type="primary" v-if="opType!==0" @click="post()">
                    {{(opType===2 && (model.self || model.manager)) ||opType===5 ?"复查并返回":"保存并返回"}}
                </u-button>
                <u-button class="bottom-btn" type="primary" v-if="opType==0" @click="back()">
                    返回
                </u-button>
            </eagle-bottom-view>
            <popup-danger-type ref="popupDangerType" :dialog-show="dangerTypeDialog" @close="dangerTypeDialog=false" v-model="model.hiddenCode" @change="changeDangeType"></popup-danger-type>
        </view>
        <view-danger-lg ref="viewDangerLg"></view-danger-lg>
        <lib-temp-details :listShow='listShow' :checkType='libCheckType' @handlerSelectBase='handlerSelectBase' @handlerSelectImg='handlerSelectImg' @libtempDetailsClose='libtempDetailsClose' />
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>
</template>

<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type.vue";
import libTempDetails from "@/pages/support/libTemp/components/libTempDetails/libTempDetails.vue";
export default {
    components: {
        "popup-danger-type": popupDangerType,
        "view-danger-lg": viewDangerLg,
        "lib-temp-details": libTempDetails,
    },
    name: "host-danger-danger-detail",
    data() {
        return {
            libCheckType: "base", //base img
            showDialog: false,
            dangerTypeDialog: false,
            listShow: false,
            taskCode: "",
            title: "隐患详情",
            opType: 0, // 0 查看,1编辑,2整改,3随手拍,4 依据查
            errorType: ["message"],
            control: "ecologyEnv/dangerCheckTaskDetail",
            model: {},
            enterpriseCode: "",
            params: {
                hiddenDangerType: [],
                lgdType: [],
            },
            initUrlParams: {
                ctCode: "",
            },
            checkDatas: {
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkType: [
                    { id: 1, name: "一般隐患" },
                    { id: 2, name: "重大隐患" },
                ],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
            },
            tempModel: {},
            projectId: "",
            needHiddenCode: true,
        };
    },
    created() {
        this.show();
    },
    computed: {
        isHost() {
            return (
                this.projectId ||
                (this.model.projectId && this.model.sourceType == "project")
            );
        },
    },

    methods: {
        hdSetMeCorrective() {
            let _this = this;
            let userInfo = uni.getStorageSync("userInfo");
            if (typeof userInfo === "string") {
                userInfo = JSON.parse(userInfo);
            }
            _this.model.appointCorrectiveChnName = userInfo.chnName;
            _this.model.appointCorrectiveName = userInfo.userName;
        },
        libtempDetailsClose() {
            this.listShow = false;
        },
        handlerSelectBase(val) {
            let _this = this;
            if (val.item == "base" && _this.model.correctiveAdvise) {
                this.$refs.eagleConfirm.showConfirm({
                    content: "是否确认覆盖整改建议?",
                    confirm: function () {
                        _this.setHidderDangerDesc(val);
                    },
                });
            } else if (
                val.item === "base-danger" &&
                (_this.model.hiddenDangerDesc || _this.model.correctiveAdvise)
            ) {
                this.$refs.eagleConfirm.showConfirm({
                    content: "是否确认覆盖隐患描述和整改建议?",
                    confirm: function () {
                        _this.setHidderDangerDesc(val);
                    },
                });
            } else _this.setHidderDangerDesc(val);
            this.libtempDetailsClose();
        },
        handlerSelectImg(val) {
            this.libtempDetailsClose();
        },
        setHidderDangerDesc(obj) {
            let _this = this;
            _this.model.correctiveAdvise = obj.base.correctiveAdvise;
            _this.model.gistSource = obj.base.gistSource;
            _this.model.originalText = obj.base.originalText;
            _this.model.lgCode = obj.base.lGCode;
            if (obj.item === "base-danger") {
                if (obj.danger.dFullName) {
                    _this.model.hiddenCode = obj.danger.dCode;
                    _this.model.hiddenName = obj.danger.dFullName.replace(
                        ">",
                        "-"
                    );
                    _this.model.hiddenTypeName =
                        _this.model.hiddenName.split("-")[0];
                    if (_this.model.hiddenTypeName === "现场管理")
                        _this.model.hiddenTypeCode = "2";
                    if (_this.model.hiddenTypeName === "基础管理")
                        _this.model.hiddenTypeCode = "1";
                }
                _this.model.lgHdCode = obj.danger.lGHDCode;
                _this.model.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.model.hiddenDangerTypeCode = obj.danger.hiddenDangerType;
                _this.model.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.model.legalLiability = obj.danger.legalLiability;
            }
        },
        hdChooseLg() {
            this.listShow = true;
        },
        showDetail(item) {
            let config = {
                isEdit:
                    this.opType !== 0 && this.opType !== 2 && this.opType !== 5,
                model: this.model,
            };
            this.$refs.viewDangerLg.show(config);
        },
        handleChangeResult(result) {
            if (this.opType === 1) this.model.checkResult = result;
        },
        post() {
            let _this = this;
            _this.$refs.eagleForm.post({
                url: `ecologyEnv/dangerCheckTaskDetail/${
                    _this.opType == 2 || _this.opType == 5 ? "rectify" : "save"
                }`,
                model: _this.model,
                needValid: _this.opType == 2 || _this.opType == 5,
                successCallback: function (res) {
                    _this.$emit("saved");
                    _this.base.navigateBack();
                },
                errorCallback: function (res) {
                    console.log(res);
                },
            });
        },
        back() {
            this.base.navigateBack();
        },
        initParams() {},
        showDangerType() {
            this.dangerTypeDialog = true;
        },
        changeDangeType(obj) {
            this.model.hiddenCode = obj.dCode;
            this.model.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeCode = obj.dType;
            this.model.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.dangerTypeDialog = false;
        },
        show() {
            this.taskCode = this.$route.query.taskCode;
            this.enterpriseCode = this.$route.query.enterpriseCode;
            this.projectId = this.$route.query.projectId;
            this.opType = parseInt(this.$route.query.opType);
            switch (this.opType) {
                case 0:
                    this.title = "隐患详情";
                    break;
                case 1:
                    this.title = "隐患编辑";
                    break;
                case 2:
                    this.title = "隐患整改";
                    break;
                case 3:
                    this.title = "随手拍";
                    break;
                case 4:
                    this.tempModel = this.$route.query.lg;
                    this.title = "依据检查";
                    break;
                case 5:
                    this.title = "隐患复查";
                    break;
            }

            uni.setNavigationBarTitle({ title: this.title });
            this.getModel(this.$route.query.id, this.taskCode);
        },
        setHiddenCode(taskCode) {
            if (taskCode) {
                let _this = this;
                this.common
                    .get("ecologyEnv/dangerCheckTask/getDataByCode/" + taskCode)
                    .then((res) => {
                        if (res.code == 200) {
                            let data = res.data;
                            _this.needHiddenCode =
                                data.companyCode != data.enterpriseCode &&
                                data.enterpriseCode;
                        }
                    });
            }
        },
        getModel(id, taskCode) {
            var _this = this;
            _this.model.attachs = "";
            if (id && id > 0) {
                this.common
                    .get("ecologyEnv/dangerCheckTaskDetail/getData/" + id)
                    .then((res) => {
                        _this.model = res.data;
                        if (
                            _this.opType == 2 &&
                            (_this.model.self || _this.model.manager)
                        ) {
                            _this.model.pass = true;
                        }
                        if (_this.opType == 5) {
                            _this.model.pass = true;
                        }
                        _this.setHiddenCode(_this.model.mainCode);
                    });
            } else {
                //this.title = "随手拍";
                this.common
                    .get("ecologyEnv/dangerCheckTaskDetail/initData/0")
                    .then((res) => {
                        _this.model = res.data;
                        _this.model.originType = 1;
                        _this.model.mainCode = _this.taskCode;
                        _this.model.enterpriseCode = _this.enterpriseCode;
                        _this.model.projectId = _this.projectId;
                        _this.model.checkResult = "N";
                        _this.model.correctiveType = _this.model.correctiveType
                            ? _this.model.correctiveType
                            : 2;
                        if (_this.opType == 4) {
                            //依据查
                            _this.model.originType = 2;
                            _this.model.attachs = _this.tempModel.attachs;

                            console.log(
                                "_this.model.attachs=>",
                                _this.model.attachs
                            );

                            _this.model.hiddenDangerDesc =
                                _this.tempModel.hiddenDangerDesc;
                            _this.model.correctiveAdvise =
                                _this.tempModel.correctiveAdvise;
                            _this.model.gistSource = _this.tempModel.gistSource;
                            _this.model.originalText =
                                _this.tempModel.originalText;
                            _this.model.lgCode = _this.tempModel.lGCode;
                            if (_this.tempModel.item === "base-img-danger") {
                                if (_this.tempModel.dFullName) {
                                    _this.model.hiddenCode =
                                        _this.tempModel.dCode;
                                    _this.model.hiddenName =
                                        _this.tempModel.dFullName.replace(
                                            ">",
                                            "-"
                                        );
                                    _this.model.hiddenTypeName =
                                        _this.model.hiddenName.split("-")[0];
                                    if (
                                        _this.model.hiddenTypeName ===
                                        "现场管理"
                                    )
                                        _this.model.hiddenTypeCode = "2";
                                    if (
                                        _this.model.hiddenTypeName ===
                                        "基础管理"
                                    )
                                        _this.model.hiddenTypeCode = "1";
                                }
                                _this.model.lgHdCode = _this.tempModel.lGHDCode;
                                _this.model.hiddenDangerTypeCode =
                                    _this.tempModel.hiddenDangerType;
                                _this.model.hiddenDangerTypeName =
                                    _this.tempModel.hiddenDangerTypeName;
                                _this.model.legalLiability =
                                    _this.tempModel.legalLiability;
                            }
                        }
                    });
            }
            if (taskCode && (!id || id == 0)) {
                this.setHiddenCode(taskCode);
            }
        },
    },
};
</script>
<style lang="scss" scoped>
.host-danger-danger-detail {
    .btn-span {
        .btn-dft {
            border-radius: 3px;
            display: inline-block;
            border: 1px solid #c8c9cc;
            background-color: #c8c9cc;
            padding: 5px;
            width: 200rpx;
            text-align: center;
            margin: 10rpx;
        }
        .btn-dft.pass {
            border: 1px solid #19be6b;
            color: #fff;
            background-color: #71d5a1;
        }
        .btn-dft.un-pass {
            border: 1px solid #fa3534;
            color: #fff;
            background-color: #dd6161;
        }
    }
}
</style>