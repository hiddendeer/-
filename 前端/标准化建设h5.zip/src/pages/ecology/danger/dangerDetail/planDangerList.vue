<template name="host-plan-danger-list">
    <view class="host-plan-danger-list">
        <eagle-page-list ref="eaglePageList" @initList="_initList" :bool-init-data="false" :pageSize="20" :controller="controller" :margin-bottom="38" @beforeLoad="beforeLoad" :showCheck="true" data-type="list">
            <view slot="search">
                <view class="search">
                    <eagle-condition @search="search" @reSearch="reSearsh">
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.status.value" title="隐患状态" prop="certState" :data-source="params.taskDetailStatus" v-if="params.taskDetailStatus.length > 0" />
                        <!-- <eagle-radio-group v-model="conditions.originType.value" title="来源类型" prop="certState" :data-source="params.checkSource" v-if="params.checkSource.length>0" /> -->
                        <eagle-fast-choose itemWidth="200rpx" v-model="conditions.hiddenDangerTypeCode.value" title="隐患性质" prop="certState" :data-source="params.hiddenDangerType" v-if="params.hiddenDangerType.length > 0" />
                        <eagle-input title="隐患描述" placeholder="请输入隐患描述模糊查询" v-model="conditions.hiddenDangerDesc.value" :labelWidth="150"></eagle-input>
                    </eagle-condition>
                </view>
            </view>

            <view slot="list" class="list-wrap">
                <eagle-row-card v-for="(item, index) in data" :key="index" @click="hdView(item)">
                    <eagle-girdrow-base isTitle>{{ item.hiddenDangerDesc }}</eagle-girdrow-base>
                    <template slot="tag">
                        <view v-html="bindTag(item.status)" />
                    </template>
                    <eagle-girdrow-base sBetween>
                        <view>
                            <text>隐患来源：{{ item.originType | paramsFormat(params.checkSource) }}</text>
                        </view>
                        <view v-if="item.complete == false" style="color:#dd6161;font-size:34rpx">
                            待完善
                        </view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base>
                        <view>
                            <text>隐患分类：{{ item.hiddenName || '--' }}</text>
                        </view>
                        <view>
                            <text>隐患性质：{{ item.hiddenDangerTypeCode == "1" ? "一般隐患" : (item.hiddenDangerTypeCode == "2"
                                    ? "重大隐患" : "")
                            }}</text>
                        </view>
                    </eagle-girdrow-base>

                    <eagle-girdrow-base>
                        检查人：{{ item.createChnName }}
                    </eagle-girdrow-base>
                    <eagle-girdrow-base>
                        检查时间：
                        {{ item.createDate | dateTimeFormat }}
                    </eagle-girdrow-base>

                    <template slot="button">
                        <u-button type="error" size="mini" v-if="item.status == 10" @click="hdDelete(item)">删除
                        </u-button>
                        <u-button type="primary" size="mini" v-if="item.status == 10" @click="hdClick(item, 1)">编辑
                        </u-button>
                        <u-button type="primary" size="mini" v-if="item.status >= 30 && item.status < 80" @click="hdVerifyClick(item, 3)">复查
                        </u-button>
                        <u-button type="success" size="mini" @click="hdView(item)">详情</u-button>
                    </template>
                </eagle-row-card>

            </view>

        </eagle-page-list>
    </view>

</template>
<script>
export default {
    components: {},
    onShow() {
        setTimeout(() => {
            this.search();
        });
    },
    data() {
        return {
            conditions: {
                hiddenDangerDesc: { value: "", operate: "like" },
                checkResult: { value: "N", operate: "=" },
                originType: { value: null, operate: "=" },
                status: { value: null, operate: "=" },
                hiddenDangerTypeCode: { value: null, operate: "=" },
            },
            controller: "ecologyEnv/dangerCheckTaskDetail",
            data: [],
            clearabled: true,
            mainCode: "",
            params: {
                checkSource: [
                    { id: "1", name: "随手拍" },
                    { id: "2", name: "依据检查" },
                    { id: "3", name: "检查表检查" },
                ],
                taskDetailStatus: [
                    { id: "100", name: "已复查", type: "success" },
                    { id: "60", name: "已整改", type: "success" },
                    { id: "30", name: "待整改", type: "primary" },
                    { id: "10", name: "待提交", type: "primary" },
                    // { id: '5', name: "暂存", color: "#E6A23C" },
                ],
                hiddenDangerType: [],
            },
            queryParams: {
                projectId: "",
                enterpriseCode: "",
            },
        };
    },
    computed: {
        isHost() {
            return this.queryParams.projectId != "";
        },
    },
    created() {
        this.mainCode = this.$route.query.taskCode;
        this.queryParams.projectId = this.$route.query.projectId;
        this.queryParams.enterpriseCode = this.$route.query.enterpriseCode;
    },
    onReady() {
        this.initParams();
    },
    methods: {
        bindTag(val) {
            let obj = this.params.taskDetailStatus.find((x) => x.id == val);
            if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
            else return "";
        },
        reSearsh() {
            this.conditions.hiddenDangerDesc.value = null;
            this.conditions.originType.value = null;
            this.conditions.status.value = null;
            this.conditions.hiddenDangerTypeCode.value = null;
        },
        hdDelete(item) {
            let _this = this;
            let url = this.controller + "/delete/" + item.id;
            this.$refs.eaglePageList.del({
                url: url,
                successCallback: function () {
                    _this.search();
                },
            });
        },
        hdClick(item, opType) {
            let _this = this;

            let linkUrl = this.common.getLinkUrl(
                "/pages/ecology/danger/dangerDetail/detailNew",
                {
                    taskCode: item.code,
                    opType: opType,
                    id: item.id,
                    projectId: _this.queryParams.projectId,
                    enterpriseCode: _this.queryParams.enterpriseCode,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdCorrective(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/ecology/danger/dangerDetail/detailCorrective",
                {
                    taskCode: item.taskCode,
                    id: item.id,
                    projectId: _this.queryParams.projectId,
                    enterpriseCode: _this.queryParams.enterpriseCode,
                }
            );
            this.base.navigateTo(linkUrl);
        },

        hdView(item) {
            let linkUrl = this.common.getLinkUrl(
                "/pages/ecology/danger/dangerDetail/viewNew",
                {
                    id: item.id,
                    projectId: this.queryParams.projectId,
                    enterpriseCode: this.queryParams.enterpriseCode,
                }
            );
            this.base.navigateTo(linkUrl);
        },
        hdVerifyClick(item) {
            let _this = this;
            let url = "/pages/ecology/danger/dangerDetail/detailVerify";
            let linkUrl = this.common.getLinkUrl(url, {
                taskCode: item.taskCode,
                id: item.id,
                projectId: _this.queryParams.projectId,
                enterpriseCode: _this.queryParams.enterpriseCode,
            });
            this.base.navigateTo(linkUrl);
        },
        _initList(list) {
            this.data = list;
        },
        change() {
            this.search();
        },
        search() {
            let _this = this;
            _this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                url: "ecologyEnv/dangerCheckTaskDetail/getPageData",
                params: { mainCode: _this.mainCode, dataType: "list" },
            });
        },
        initParams() {
            var _this = this;
            this.common
                .getparamsList("hidden_danger_type")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        res.data.forEach(function (item) {
                            if (item.paramId == "hidden_danger_type") {
                                _this.params.hiddenDangerType.push(item);
                            }
                        });
                    }
                });
        },
    },
};
</script>
<style lang="scss">
</style>
