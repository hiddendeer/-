<template name="eagle-upload">
  <u-form-item
    ref="uFormItem"
    :label-position="labelPositionVal"
    :label="title"
    :required="required"
    :prop="prop"
    :label-width="labelWidth"
    :label-align="labelAlign"
  >
    <uu-upload
      :max-size="maxSize"
      ref="uUpload"
      :isNeedEdit="isNeedEdit"
      :disabled="disabled"
      :file-list="defaultValue"
      :action="action"
      :show-tips="false"
      :deletable="deletable"
      :width="160"
      :height="160"
      @on-success="onSuccess"
      @on-remove="onRemove"
      @on-error="onError"
      :before-upload="beforeUpload"
      :show-progress="showProgress"
      :max-count="maxCount"
      :header="uploadHead"
      :limitType="limitType"
      :showTips="showTips"
    >
    </uu-upload>
    <div class="upload__tip">
      文件格式：png.jpg.jpeg; 文件大小：5MB; 文件均支持预览
    </div>
    <u-toast ref="uToast" />
  </u-form-item>
</template>

<script>
import uuUpload from "./u-upload.vue"
export default {
  components: {
    uuUpload
  },
  name: "eagle-upload",
  props: {
    value: {
      type: [String],
      default: "",
    },
    busType: {
      // 上传的类型
      type: String,
      required: true,
      default: "",
    },
    title: {
      type: [String],
      default: "",
    },
    prop: {
      type: [String],
      default: "",
    },

    showProgress: {
      type: Boolean,
      default: false,
    },
    showTips: {
      type: Boolean,
      default: false,
    },

    limitType: {
      type: Array,
      default() {
        return ["png", "jpg", "jpeg"];
      },
    },
    maxCount: {
      type: Number,
      default: 1,
    },
    maxSize: {
      type: Number,
      default: 5242880,
    },

    required: {
      type: Boolean,
      default: false,
    },
    onlyShowRequired: {
      type: Boolean,
      default: false,
    },
    deletable: {
      type: Boolean,
      default: true,
    },
    labelPosition: {
      type: String,
      default: "",
    },
    labelWidth: {
      type: String,
      default: "120",
    },
    disabled: {
      type: [Boolean],
      default() {
        return false;
      },
    },
    // 高度，单位rpx
    height: {
      type: [Number, String],
      default: "",
    },
    placeholder: {
      type: String,
      default: "",
    },
    hasPadding: {
      type: Boolean,
      default: true,
    },
    labelAlign: {
      type: String,
      default: "left",
    },

    //拍照是否需要编辑图片 仅仅适用于App端交互
    isNeedEdit: {
      type: Boolean,
      default: false,
    },
    // applicationId: {
    // 	type: [String],
    // 	default: '72e7d4a7e78643af9a33289d2b82253b'
    // },
    // appSecretKey: {
    // 	type: [String],
    // 	default: 'XtJMTI2e3fRChHA8vg7rUSN4dZKyD0FWuOY6'
    // },
  },
  data() {
    return {
      action:
        process.env.VUE_APP_BASE_API + "/ecologyEnv/fourColor/file/upload",
      // action: "/prod-api/file/upload",
      labelPositionVal: "",
      defaultValue: [{url: "http://192.168.1.240:50001/vrgv.four.color.manage/2c9314f10c5c41a7b910c1cf17654249.jpg"}],
      inputHeight: 70, // input的高度
      textareaHeight: 100, // textarea的高度
      validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
      focused: false, // 当前是否处于获得焦点的状态
      showPassword: false, // 是否预览密码
      lastValue: "", // 用于头条小程序，判断@input中，前后的值是否发生了变化，因为头条中文下，按下键没有输入内容，也会触发@input时间
      // uploadFrom: {
      // 	applicationId: this.applicationId,
      // 	companyId: this.companyId
      // },
      uploadHead: { Authorization: "" },
      placeholderVal: "",
      // companyId: "a4328d3ee06c13cc4d3e76f4a0a5a220",
    };
  },
  created() {
    this.bindVal(this.value);
    this.placeholderVal = this.placeholder
      ? this.placeholder
      : "请上传" + (this.title ? this.title : "文件");
    this.labelPositionVal = this.labelPosition
      ? this.labelPosition
      : this.consts.constLabelPosition;
    //let userInfo = uni.getStorageSync('userInfo');
    // this.companyId=userInfo.CompanyCode;
    var token = uni.getStorageSync("token");
    this.uploadHead.Authorization = "Bearer " + token;
  },
  watch: {
    value(newValue, oldValue) {
      if (newValue != oldValue) {
        this.bindVal(newValue);
        if (!newValue) {
          this.$refs.uUpload.lists = [];
        }
      }
    },
  },
  methods: {
    bindVal(val) {
      console.log("val: ", val);
      if (val) {
        let me = this;
        let arry = val.split(";");
        arry.forEach(function (item) {
          me.defaultValue.push({
            url: item,
            progress: 100,
          });
        });
      } else {
        this.defaultValue = [];
      }
    },
    clear() {
      this.$refs.uUpload.lists = [];
      this.$emit("input", "");
      this.$refs["uUpload"].clear();
    },
    beforeUpload() {
      console.log(this.action,'action');
    },
    onRemove(index, lists) {
      this.imageUploads();
    },
    onSuccess(res, index) {
      console.log(res,'上传文件success');
      let lists = this.$refs.uUpload.lists;
      if (res.code == 200) {
        var list = lists[index];
        console.log(list,'我是list');
        list.url = res.data.fileUrl;
        this.saveFile(res?.data); // 保存文件
      } else {
        lists.splice(index, 1);
      }
      this.imageUploads();
    },
    onError(res, index, lists, name) {
      console.log(res,'error-res');
      console.log(index,'error-index');
      console.log(lists,'error-lists');
      console.log(name,'error-name');
    },
    saveFile(data) {
      console.log(this.busType);
      if (!data?.id || this.busType == "") {
        this.$refs.uToast.show({
          title: "服务器错误:不存在图片id",
          type: "error",
        });
        return;
      }
      this.common
        .post("ecologyEnv/fourColor/ecologicalEnvironment/saveFile", {
          businessDetailType: this.busType,
          fileIds: [data?.id],
        })
        .then((res) => {
          if (res.code == 200) {
            this.$refs.uToast.show({
              title: "上传成功",
              type: "success",
            });
          } else {
            this.$refs.uToast.show({
              title: "上传失败",
              type: "error",
            });
          }
        });
    },
    imageUploads() {
      let files = [];
      let filePath = [];
      files = this.$refs.uUpload.lists.filter((val) => {
        return val.progress == 100;
      });
      files.forEach(function (item) {
        filePath.push(item.url);
      });
      this.defaultValue = files;
      this.$emit("input", filePath.join(";"));

      this.valid();
    },
    valid() {
      let _this = this;
      if (_this.required && _this.onlyShowRequired == false) {
        if (!_this.defaultValue || this.defaultValue.length <= 0) {
          _this.$refs.uFormItem.validateState = "error";
          _this.$refs.uFormItem.validateMessage = _this.placeholderVal;
          return false;
        } else if (
          _this.$refs.uFormItem.validateMessage === _this.placeholderVal
        ) {
          _this.$refs.uFormItem.validateState = "";
        }
      }
      return true;
    },
  },
};
</script>

<style lang="scss">
.upload__tip {
  font-size: 12px;
  color: #606266;
  margin-top: 7px;
}
</style>
