<template>
  <view class="host-index">
    <eagle-container title="文件上传">
      <file-upload
        title="环境影响审批报告"
        :limitType="['png', 'jpg', 'jpeg']"
        busType="eia_report"
        showTips
        :value="ruleForm.attachs1"
      />
      <file-upload
        title="企业排污许可证"
        :limitType="['png', 'jpg', 'jpeg']"
        busType="epd_permit"
        showTips
        :value="ruleForm.attachs2"
      />
    </eagle-container>
    <tabbar-ecology></tabbar-ecology>
  </view>
</template>

<script>
import fileUpload from "./components/eagle-upload/eagle-upload.vue";
import TabbarEcology from "@/pages/components/tabbar/tabbar-ecology.vue";
export default {
  components: {
    fileUpload,
    TabbarEcology
  },
  data() {
    return {
      ruleForm: {
        attachs1: "",
        attachs2: "",
        attachs3: "",
      },
    };
  },
  mounted() {
    this.getAllFile();
  },
  methods: {
    getAllFile() {
      this.common
        .post("ecologyEnv/fourColor/ecologicalEnvironment/getAllFile", {
          businessDetailType: "",
        })
        .then((res) => {
          if (res?.code == 200) {
            res?.data?.forEach((item) => {
              if (item.businessDetailType == "eia_report") {
                this.ruleForm.attachs1 = item.fileUrl;
              }
              if (item.businessDetailType == "epd_permit") {
                this.ruleForm.attachs2 = item.fileUrl;
              }
              if (item.businessDetailType == "ppf_sra_report") {
                this.ruleForm.attachs3 = item.fileUrl;
              }
            });
          }
        });
    },
  },
};
</script>
