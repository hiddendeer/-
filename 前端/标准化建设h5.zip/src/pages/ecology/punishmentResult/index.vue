<template>
  <view class="eagle-layer">
    <p style="color: #606266; margin-top: 10px; padding: 10px; text-align: center">无处罚记录</p>
  </view>
</template>

