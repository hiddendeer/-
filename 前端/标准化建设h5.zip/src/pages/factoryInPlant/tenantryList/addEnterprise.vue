<template>
  <view>
    <eagle-form
      saveFunName="addEnterprise"
      :control="control"
      v-model="model"
      :boolInitData="false"
      ref="eagleForm"
      :out-height="50"
      :errorType="errorType"
      @initCallBack="bindData"
    >
      <eagle-container>
        <eagle-input
          title="企业名称"
          required
          v-model="model.entName"
          prop="entName"
        ></eagle-input>
        <eagle-input
          title="社会信用代码"
          required
          v-model="model.unifiedCreditCode"
          prop="unifiedCreditCode"
        ></eagle-input>
        <eagle-input
          title="联系人"
          required
          v-model="model.entContact"
          prop="entContact"
        ></eagle-input>
        <eagle-input
          title="联系电话"
          required
          v-model="model.entContactMobile"
          prop="entContactMobile"
        ></eagle-input>
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button class="bottom-btn" type="primary" @click="navigateBack"
        >取消</u-button
      >
      <u-button class="bottom-btn" type="primary" @click="post">保存</u-button>
    </eagle-bottom-view>
  </view>
</template>
<script>
export default {
  components: {},
  data() {
    return {
      model: {
        entName: "", //
        unifiedCreditCode: "",
        entContactMobile: "",
        entContact: ""
      },
      errorType: ["message"],
      control: "rent/tenantRelationship"
    };
  },
  computed: {},
  created() {},
  onReady() {
    var _this = this;
  },
  mounted() {
    // this.resetTableHeight();
  },
  methods: {
    bindData() {
      let _this = this;
    },
    post() {
      let _this = this;
      this.$refs.eagleForm.post({
        successCallback: function (res) {
          if (res.code == 200) _this.navigateBack();
        }
      });
    },
    navigateBack() {
      uni.$emit('_update_enterprise_list')
      uni.navigateBack({ delta: 1 });
    }
  }
};
</script>
<style lang="scss"></style>
