<template name="host-plan-danger-list">
  <view class="eagle-layer">
    <eagle-page-list
      ref="eaglePageList"
      :isUseEnterprise="true"
      @initList="_initList"
      :boolInitData="false"
      :marginBottom="80"
      :controller="controller"
      @beforeLoad="beforeLoad"
      :showCheck="true"
      :data-type="'list'"
    >
      <view slot="search">
        <view class="search">
          <eagle-search
            v-model="conditions.tenantName.value"
            @search="search"
            :clearabled="clearabled"
            :show-action="false"
            @clear="search"
          ></eagle-search>
        </view>
      </view>
      <view slot="list" class="list-wrap">
        <eagle-row-card
          v-for="(item, index) in data"
          :key="index"
          @click="eidtPlan(item.id)"
        >
          <eagle-girdrow-base isTitle>
            {{ item.tenantName }}
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text> 行业:{{ item.industry }} </text>
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text> 重点监管领域:{{ item.keyRegulatoryAreas }} </text>
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text> 联系人:{{ item.contact }} </text>
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text> 联系人电话:{{ item.contactPhone }} </text>
          </eagle-girdrow-base>
          <template slot="button">
            <u-button type="error" size="mini" @click="hdDelete(item)">
              解除租赁合同</u-button
            >
            <u-button type="primary" size="mini" @click="eidtPlan(item.id)"
              >编辑</u-button
            >
          </template>
          <!-- </eagle-grid-botton> -->
        </eagle-row-card>
        <!-- </view> -->
      </view>
    </eagle-page-list>
    <eagle-fab
      :popMenu="false"
      horizontal="right"
      @fabClick="eidtPlan(0)"
    ></eagle-fab>
    <TabbarPlant></TabbarPlant>
    <u-toast ref="uToast" />
  </view>
</template>
<script>
import TabbarPlant from "@/pages/components/tabbar/tabbar-plant.vue";
export default {
  components: {
    TabbarPlant //底部导航栏
  },
  data() {
    return {
      conditions: {
        tenantName: { value: "", operate: "like" }
      },
      controller: "rent/tenantRelationship",
      data: [],
      clearabled: true
    };
  },
  computed: {},
  created() {},
  onShow() {
    let timer = setTimeout(() => {
      clearTimeout(timer);
      this.search();
    });
  },
  mounted() {},
  onReady() {},
  methods: {
    close() {
      this.visible = false;
    },
    reSearsh() {
      this.conditions.tenantName.value = null;
      this.search();
    },
    hdDelete(item) {
      let _this = this;
      let url = this.controller + "/dissolveRelationship";
      let params = [{ id: item.id }];
      uni.showModal({
        title: "提示",
        content: "您确定要解除该租赁合同吗？",
        success: (res) => {
          if (res.confirm) {
            _this.common
              .post(url, params)
              .then((res) => {
                if (res.code == 200) {
                  _this.$refs.uToast.show({
                    title: "解除成功",
                    type: "success"
                  });
                } else {
                  _this.$refs.uToast.show({
                    title: "解除失败：" + res.errorText,
                    type: "error"
                  });
                }
                _this.search();
              })
              .catch((err) => {
                _this.$refs.uToast.show({
                  title: "解除失败：" + err.errorText,
                  type: "error"
                });
                _this.search();
              });
          }
        }
      });
    },
    eidtPlan(id) {
      let url = `/pages/factoryInPlant/tenantryList/addTenantry?id=${id}`;
      this.base.navigateTo(url);
    },
    _initList(list) {
      this.data = list;
    },
    change() {
      console.log("change");
      this.search();
    },
    search() {
      let _this = this;
      _this.$refs.eaglePageList.search({
        conditions: _this.common.getCondtions(_this.conditions)
      });
    },
    initParams() {}
  }
};
</script>
<style lang="scss"></style>
