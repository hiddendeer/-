<template>
  <view>
    <eagle-form
      saveFunName="saveRelationship"
      :control="control"
      v-model="model"
      ref="eagleForm"
      :submitTotast="chooseShow ? '新增成功' : '编辑成功'"
      :out-height="50"
      :errorType="errorType"
      @initCallBack="bindData"
      :rules="rules"
    >
      <eagle-container>
        <eagle-window-choose
          v-if="chooseShow"
          required
          ref="chooseRentCompany"
          :isUseEnterprise="false"
          :queryParams="queryParams"
          :addUrl="addUrl"
          title="承租方"
          headTitle="请选择承租方"
          v-model="model.tenantCompanyId"
          :isMult="false"
          :names.sync="model.tenantName"
          showDetail="true"
          @change="setProject"
          queryUrl="rent/tenantRelationship/queryEnterpriseInfo"
          idField="companyId"
          textField="entName"
          labelPosition="top"
          labelWidth="130"
          :dataType="'list'"
          keyWordName="entName"
          :otherDataShow="true"
          :otherData="['entContact', 'entContactMobile']"
          prop="tenantCompanyId"
        >
        </eagle-window-choose>
        <eagle-text v-else title="承租方" v-model="model.tenantName" />
        <eagle-input
          maxlength="20"
          title="联系人"
          required
          v-model="model.contact"
          prop="contact"
          @input="
            (e) => {
              $nextTick(() => {
                model.contact = inputFiltration1(e);
              });
            }
          "
        ></eagle-input>
        <eagle-input
          maxlength="11"
          title="联系电话"
          required
          v-model="model.contactPhone"
          prop="contactPhone"
        ></eagle-input>
        <eagle-input
          required
          maxlength="50"
          title="租赁场所"
          v-model="model.leasedPremises"
          prop="leasedPremises"
          @input="
            (e) => {
              $nextTick(() => {
                model.leasedPremises = inputFiltration1(e);
              });
            }
          "
        ></eagle-input>
        <eagle-date
          required
          title="租赁期限"
          prop="leaseDate"
          @change="changDateRang"
          v-model="model.leaseDate"
          type="range"
          rangeSeparator="至"
        />
        <eagle-upload
          required
          title="安全协议"
          :maxCount="10"
          prop="securityProtocol"
          v-model="model.securityProtocol"
          labelPosition="top"
          labelWidth="170"
          :maxSize="5242880"
          :limitType="['png', 'jpg']"
          showTips
        />
        <eagle-date
          title="安全协议期限"
          prop="protocolDate"
          @change="changDateRang"
          v-model="model.protocolDate"
          required
          type="range"
          rangeSeparator="至"
        />
        <eagle-upload
          title="租赁合同"
          :maxCount="10"
          prop="leaseContract"
          v-model="model.leaseContract"
          labelPosition="top"
          labelWidth="170"
          :maxSize="5242880"
          :limitType="['png', 'jpg']"
          showTips
        />
        <eagle-date
          title="租赁合同期限"
          prop="contractDate"
          @change="changDateRang"
          v-model="model.contractDate"
          type="range"
          rangeSeparator="至"
        />
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button class="bottom-btn" type="primary" @click="navigateBack"
        >取消</u-button
      >
      <u-button class="bottom-btn" type="primary" @click="post">保存</u-button>
    </eagle-bottom-view>
    <u-toast ref="uToast" />
  </view>
</template>
<script>
export default {
  components: {},
  data() {
    return {
      queryParams: {},
      addUrl: "",
      model: {},
      codes: "",
      errorType: ["message"],
      control: "rent/tenantRelationship",
      chooseShow: false,
      rules: {
        contactPhone: [
          { required: true, message: "请填写联系电话", trigger: "change" },
          {
            validator: (rule, value, callback) => {
              console.log("value", value);
              let regex = /^(?:(?:\+|00)86)?1[3-9]\d{9}$/;
              if (!regex.test(value)) {
                callback(new Error("请输入正确的手机号"));
              } else {
                callback();
              }
            },
            trigger: "blur"
          }
        ]
      }
    };
  },
  computed: {},
  created() {
    if (this.$route.query.id == 0) {
      this.chooseShow = true;
    }
    this.model.ID = this.$route.query.id ?? "";
    // this.addUrl = "pages/factoryInPlant/tenantryList/addEnterprise";

    if (!this.chooseShow) {
      uni.setNavigationBarTitle({
        title: "编辑承租方"
      });
    }
  },
  onReady() {
    var _this = this;
  },
  mounted() {
    // this.resetTableHeight();
  },
  methods: {
    changDateRang() {
      if (this.model.leaseDate && this.model.leaseDate.length > 0) {
        this.model.leaseStartDate =
          this.model.leaseDate[0].split(" ")[0] + " 00:00:00";
        this.model.leaseEndDate =
          this.model.leaseDate[1].split(" ")[0] + " 23:59:59";
      }
      if (this.model.protocolDate && this.model.protocolDate.length > 0) {
        this.model.protocolStartDate =
          this.model.protocolDate[0].split(" ")[0] + " 00:00:00";
        this.model.protocolEndDate =
          this.model.protocolDate[1].split(" ")[0] + " 23:59:59";
      }
      if (this.model.contractDate && this.model.contractDate.length > 0) {
        this.model.contractStartDate =
          this.model.contractDate[0].split(" ")[0] + " 00:00:00";
        this.model.contractEndDate =
          this.model.contractDate[1].split(" ")[0] + " 23:59:59";
      }
    },
    bindData(data) {
      if (data.leaseStartDate) {
        this.model.leaseDate = [data.leaseStartDate, data.leaseEndDate];
      }
      if (data.protocolStartDate) {
        this.model.protocolDate = [
          data.protocolStartDate,
          data.protocolEndDate
        ];
      }
      if (data.contractStartDate) {
        this.model.contractDate = [
          data.contractStartDate,
          data.contractEndDate
        ];
      }
    },
    setProject(data) {},
    post() {
      console.log("model", this.model);
      let _this = this;
      _this.$refs.eagleForm.post({
        successCallback: function (res) {
          if (res.code == 200) {
            let timer = setTimeout(() => {
              clearTimeout(timer);
              _this.navigateBack();
            }, 1000);
          }
        }
      });
    },
    navigateBack() {
      uni.navigateBack({ delta: 1 });
    },
    inputFiltration1(e) {
      let regex = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;
      if (!regex.test(e)) {
        return e.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, "");
      } else {
        return e;
      }
    }
  }
};
</script>
<style lang="scss"></style>
