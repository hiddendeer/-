<template>
    <view class="host-header-container">
        <view class="host-header">
            <view class="host-header-item">
                <view class="">
                    <view class="company-name">{{ enterprise.enterpriseName }}</view>
                    <view class="company-warp">
                        <view class="left" v-if="src">
                            <u-image width="120rpx" height="120rpx" :src='src'></u-image>
                        </view>
                        <view class="right">
                            <view class="company-opp"><text style="margin-right: 50rpx;"
                                    class="text2">当前账号：{{ chnName }}</text></view>
                            <view class="company-res">
                                <view class="company-res2">
                                    所属地区：{{ enterprise.belongArea }}
                                </view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
export default {
    name: "host-header-enterprise",
    components: {},
    data() {
        return {
            enterprise: {
                name: "",
                serviceName: "",
                projectContact: "",
                projectMobile: "",
                mainChnName: "",
                partChnName: "",
                chnName: "",
            },
            src: "",
            chnName: ""
        };
    },
    mounted() {
        this.initData();
    },
    onShow() {
        // if (this.$route.query.enterpriseCode) {
        //     this.queryParams.companyCode = this.$route.query.enterpriseCode;
        // }
    },
    methods: {
        initData() {
            let userInfoA = uni.getStorageSync("userInfo");
            if (typeof userInfoA === "string") {
                userInfoA = JSON.parse(userInfoA);
            }
            this.chnName = userInfoA.chnName;
            let _this = this;

            let url = "rent/entInfo/getEnterpriseInfo";

            if (this.$route.query.enterpriseCode) {
                url = url + "?companyCode=" + this.$route.query.enterpriseCode;
            }

            this.common.post(url).then(function (res) {
                if (res.code == 200) {
                    _this.enterprise = res.data;
                }
            });
        },
    },
};
</script>

<style scoped lang="scss">
/**
	思路：
		1.超出的文本隐藏
		2.溢出用省略号显示
		3.溢出不换行
		4.将对象作为弹性伸缩盒子模型显示
		5.从上到下垂直排列子元素（设置伸缩盒子的子元素排列方式）
		6.这个属性不是css的规范属性，需要组合上面两个属性，表示显示的行数
	  */
.text2 {
    word-break: break-all;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.host-header-container {
    display: none;
    width: 100vw;
    height: 250rpx;
    overflow: hidden;

    .host-header {
        width: 100%;
        height: 150rpx;
        // background: #1b76d1;
        display: flex;
        justify-content: center;
        padding: 20rpx 20rpx 0;

        .host-header-item {
            padding: 15rpx;
            box-sizing: border-box;
            width: 100%;
            height: 240rpx;
            background: #ffffff;
            border-radius: 14rpx;
            border-bottom-left-radius: 14px;
            border-bottom-right-radius: 14px;

            .company-name {
                font-size: 40rpx;
                font-weight: 600;
                padding: 8rpx;
                box-sizing: border-box;
            }

            .company-warp {
                display: flex;
                padding: 0 8rpx;

                .left {
                    margin-right: 10rpx;
                    border-radius: 10rpx;
                }
            }

            .company-address,
            .company-opp {
                font-size: 24rpx;
                padding: 8rpx;
                box-sizing: border-box;
                color: #a5a5a5;

                .phone {
                    color: #2979ff;
                }
            }

            .company-res {
                display: flex;
                font-size: 24rpx;
                padding: 8rpx;
                align-items: center;

                .company-res1 {
                    display: flex;
                    border: 1rpx solid #f99941;
                    border-radius: 10rpx;
                    margin-right: 50rpx;

                    view {
                        padding: 5rpx;
                        box-sizing: border-box;
                    }

                    .left {
                        color: #f99941;
                        padding: 5rpx 10rpx;
                        box-sizing: border-box;
                    }

                    .right {
                        background-color: #f99941;
                        color: #ffffff;
                        padding: 5rpx 10rpx;
                        box-sizing: border-box;
                    }
                }

                .company-res2 {
                    color: #d0b66c;
                    margin-right: 0rpx;

                    word-break: break-all;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                }

                .details {
                    font-size: 30rpx;
                    color: #2979ff;
                }
            }
        }
    }
}
</style>
