<template name="host-danger-plan-view">
  <view class="host-danger-plan-view">
    <!-- selfHeight='calc(100vh - 130px)' -->
    <eagle-form
      :control="control"
      v-model="model"
      ref="eagleForm"
      @initCallBack="bindData"
      margin-bottom="20px"
    >
      <eagle-container>
        <view slot="title">检查任务信息</view>
        <eagle-text v-model="model.checkTaskName" blod label="任务名称">
        </eagle-text>
        <eagle-text blod label="任务检查时间">
          {{ model.startDate | dateFormat }}至{{ model.endDate | dateFormat }}
        </eagle-text>
        <eagle-text v-model="model.checkPersonChName" blod label="检查人">
        </eagle-text>
        <eagle-text blod label="创建日期">
          {{ model.createDate | dateTimeFormat }}
        </eagle-text>
        <eagle-text blod label="创建人" v-model="model.createChnName">
        </eagle-text>
      </eagle-container>

      <eagle-container title="检查情况">
        <eagle-text blod label="状态">
          <span
            v-html="common.formateStatus(status, model.serviceStatus)"
          ></span>
        </eagle-text>
        <eagle-text blod label="隐患排查记录">
          <span style="color: #0088ff" @click="showDangerList"
            >隐患：{{ statistics.dangerCount }} / 检查：{{
              statistics.total
            }}</span
          >
        </eagle-text>
        <eagle-text blod label="隐患排查报告">
          <span @click="showReportList"
            >已生成隐患排查报告(<span style="color: #0088ff">{{
              reportNum
            }}</span
            >)份</span
          >
        </eagle-text>
      </eagle-container>
      <eagle-container title="已分配的检查表">
        <template slot="otherSolot">
          <u-button
            v-if="model.status == 10 && model.sourceType != 'risk'"
            size="mini"
            type="primary"
            @click="templateShow = true"
            >选择检查表</u-button
          >
        </template>
        <eagle-text>
          <view class="eagle-blue record-block">
            <template v-if="model.relations && model.relations.length > 0">
              <view
                v-for="(item, index) in model.relations"
                :key="index"
                tabindex="0"
                class="tName-block flex"
              >
                <!-- <div @click="hdShowTemp(item)" class="tName-block">
                                <div class="single-line"> {{item.templateName}}</div>
                            </div> -->
                <view class="flex1" @click="hdShowTemp(item)">
                  {{ item.templateName }}</view
                >
                <u-button
                  v-if="model.status == 10"
                  type="error"
                  size="mini"
                  @click="hdRemoveRelation(index)"
                  >移除</u-button
                >
                <!-- <uni-icons v-if="model.status == 10&& model.sourceType!='risk'" style="margin-left:15px;color:#aaa" type="clear" size="14" @click="hdRemoveRelation(index)"></uni-icons> -->
              </view>
            </template>
            <template v-else>
              <u-empty text="未分配" mode="list"></u-empty>
            </template>
          </view>
        </eagle-text>
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button
        class="bottom-btn"
        type="primary"
        v-if="model.status == 10 && model.sourceType != 'risk'"
        @click="goChooseTemp"
        >依据检查</u-button
      >
      <u-button
        class="bottom-btn"
        type="primary"
        v-if="model.status == 10 && model.sourceType != 'risk'"
        @click="addHand()"
        >随手拍</u-button
      >
      <u-button
        class="bottom-btn"
        type="error"
        v-if="model.status == 10"
        @click="submitEnd()"
        >结束任务</u-button
      >
      <u-button
        class="bottom-btn"
        type="primary"
        v-if="model.status == 100"
        @click="buildReport"
        >生成报告</u-button
      >
    </eagle-bottom-view>
    <view style="height: 120px"></view>
    <choose-temp-table
      :isMult="true"
      :show.sync="templateShow"
      :TagList="TagList"
      v-model="tempCodes"
      @tableData="tableData"
    />
    <!-- <dangerTempCheck ref="dangerTempCheck" @saveAfter="refreshNums" /> -->
    <!-- <danger-detail ref="dangerDetail" @saved="refreshNums" /> -->
    <!-- <danger-report-detail ref="dangerReportDetail" @saveAfter="refreshReports" /> -->
    <!-- <u-toast ref="uToast" /> -->
    <!-- <dangerListReport ref="dangerListReport" @saved="refreshReports" /> -->
  </view>
</template>
<script>
// import dangerDetail from "@/pages/factoryInPlant/danger/dangerDetail/detail";
import chooseTempTable from "@/components/eagle-check-table/popup-table";
// import dangerTempCheck from "@/pages/factoryInPlant/danger/dangerDetail/dangerTempCheck";
// import dangerReportDetail from "@/pages/factoryInPlant/danger/dangerReport/detail";
// import dangerListReport from "@/pages/factoryInPlant/danger/dangerReport/dangerListReport";

export default {
  components: {
    // dangerDetail,
    // libTempDetails,
    chooseTempTable
    // dangerTempCheck,
    // dangerReportDetail,
    // dangerListReport,
    // planDangerDetailList
  },
  data() {
    return {
      // outHeight:110
      TagList: [],
      tempCodes: "",
      templateShow: false,
      libTempDetailsVisible: false,
      labelPosition: "top",
      startDate: "",
      model: {},
      errorType: ["message"],
      control: "rent/dangerCheckTask",
      urlParams: {
        enterpriseCode: "",
        projectId: ""
      },
      status: [
        { id: 1, name: "待实施", color: "#909399" },
        { id: 2, name: "进行中", color: "#0088ff" },
        { id: 3, name: "已逾期", color: "#E6A23C" },
        { id: 4, name: "已完成", color: "#67C23A" }
      ],
      statistics: {},
      reportNum: 0,
      taskID: 0
    };
  },
  computed: {
    isHost() {
      return (
        this.projectId ||
        (this.model.projectId && this.model.sourceType == "project")
      );
    }
  },
  created() {
    this.taskID = this.$route.query.id ?? 0;
    this.model.ID = this.$route.query.id ?? "";
    this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
    this.urlParams.projectId = this.$route.query.projectId ?? "";
  },
  onReady() {
    var _this = this;
  },
  onShow() {
    if (this.model && this.model.code) this.bindData();
    // this.resetTableHeight();
  },
  methods: {
    // buildDangerListReport() {
    //     let _this = this;
    //     _this.common
    //         .get(
    //             _this.control + "/checkDangerListReport/" + _this.model.code
    //         )
    //         .then((res) => {
    //             if (res.data.result) {
    //                 _this.$refs.dangerListReport.show({
    //                     taskCode: _this.model.code,
    //                 });
    //             } else {
    //                 _this.$refs.uToast.show({
    //                     title: res.data.errorMsg,
    //                     type: "error",
    //                 });
    //             }
    //         });
    // },
    showReportList() {
      let linkUrl = this.common.getLinkUrl(
        "/pages/factoryInPlant/danger/dangerReport/planDangerReportList",
        {
          taskCode: this.model.code,
          projectId: this.urlParams.projectId,
          enterpriseCode: this.urlParams.enterpriseCode
        }
      );
      this.base.navigateTo(linkUrl);
    },
    showDangerList() {
      let linkUrl = this.common.getLinkUrl(
        "/pages/factoryInPlant/danger/dangerDetail/planDangerList",
        {
          taskCode: this.model.code,
          projectId: this.urlParams.projectId,
          enterpriseCode: this.urlParams.enterpriseCode
        }
      );
      this.base.navigateTo(linkUrl);
    },

    buildReport() {
      let linkUrl = this.common.getLinkUrl(
        "/pages/factoryInPlant/danger/dangerReport/detail",
        {
          taskID: this.taskID,
          taskCode: this.model.code,
          projectId: this.urlParams.projectId,
          enterpriseCode: this.urlParams.enterpriseCode
        }
      );
      this.base.navigateTo(linkUrl);
      // let _this = this;
      // _this.$refs.dangerReportDetail.show({
      //     taskModel: this.model,
      // });
    },
    submitEnd() {
      let _this = this;
      _this.common
        .post(_this.control + "/submit/" + _this.model.id)
        .then(function (res) {
          if (res.code == 200) {
            _this.$refs.eagleForm.get();
            _this.$refs.eagleForm.successMsg("提交成功");
          }
        });
    },
    refreshReports() {
      let _this = this;
      let url = `rent/dangerReport/getStatisticsByMainCode/${this.model.code}`;
      _this.common.get(url).then((res) => {
        _this.reportNum = res.data.total;
      });
    },
    refreshNums() {
      let _this = this;
      let url = `rent/dangerCheckTaskDetail/getStatisticsByMainCode/${this.model.code}`;
      _this.common.get(url).then((res) => {
        _this.statistics = res.data;
      });
    },
    tableData(array) {
      let _this = this;
      this.tempCodes = "";
      this.TagList = [];
      let relationsArray = [];
      let message = "";
      if (array && array.length > 0) {
        array.forEach((x) => {
          if (
            _this.model.relations.findIndex(
              (p) => p.checkTemplateCode == x.id
            ) > 0
          )
            message = (message ? "," : message) + `${x.name}`;
          else
            relationsArray.push({
              checkTaskCode: _this.model.code,
              checkTemplateCode: x.id,
              templateName: x.name
            });
        });
        if (message) {
          _this.$refs.eagleForm.errorMsg(`${message}已经存在检查计划中`);
          // _this.$refs.uToast.show({
          //     title: `${message}已经存在检查计划中`,
          //     type: "error",
          // });
          //this.msgInfo(`${message}已经存在检查任务中`);
        }
        if (relationsArray && relationsArray.length > 0) {
          let url = "rent/dangerCheckTaskRelation/saveRelationsAndBack";
          _this.common.post(url, relationsArray).then(function (res) {
            _this.model.relations = res.data;
          });
        }
      }
    },
    //检查表检查
    // hdShowTemp(item) {
    //     let needHiddenCode =
    //         this.model.projectId && this.model.sourceType == "project";
    //     this.$refs.dangerTempCheck.show({
    //         tempCode: item.checkTemplateCode,
    //         tempName: item.templateName,
    //         taskCode: this.model.code,
    //         isEdit: this.model.status == 10,
    //         needHiddenCode: needHiddenCode,
    //     });
    // },
    hdShowTemp(item) {
      let _this = this;
      let linkUrl = this.common.getLinkUrl(
        "pages/factoryInPlant/danger/dangerDetail/dangerTempCheckSingle",
        {
          taskID: this.taskID,
          taskCode: this.model.code,
          templateCode: item.checkTemplateCode,
          enterpriseCode: _this.urlParams.enterpriseCode,
          projectId: _this.urlParams.projectId
        }
      );
      this.base.navigateTo(linkUrl);
    },
    //随手拍
    addHand() {
      let linkUrl = this.common.getLinkUrl(
        "/pages/factoryInPlant/danger/dangerDetail/detailNew",
        {
          taskID: this.taskID,
          taskCode: this.model.code,
          opType: 3,
          enterpriseCode: this.$route.query.enterpriseCode ?? "",
          projectId: this.$route.query.projectId ?? ""
        }
      );
      this.base.navigateTo(linkUrl);
    },
    goChooseTemp() {
      let linkUrl = this.common.getLinkUrl("pages/support/libTempPublic/list", {
        taskID: this.taskID,
        enterpriseCode: this.$route.query.enterpriseCode ?? "",
        projectId: this.$route.query.projectId ?? "",
        formType: "factoryInPlant",
        taskCode: this.model.code
      });
      this.base.navigateTo(linkUrl);
    },

    bindData(model) {
      let _this = this;
      _this.refreshNums();
      _this.refreshReports();
      // _this.$refs.eagleForm.resetHeight(model.status === 10 ? 130 : 45);
    },
    changeTemplate(codes, names) {
      let _this = this;
      this.model.relations = [];
      if (_this.model.templateCheckCodes) {
        let templateCheckCodes = _this.model.templateCheckCodes.split(",");
        let templateCheckNames = _this.model.templateCheckNames.split(",");
        for (let i = 0; i < templateCheckCodes.length; i++) {
          this.model.relations.push({
            checkTemplateCode: templateCheckCodes[i],
            templateName: templateCheckNames[i]
          });
        }
      }
    },
    goto(url) {
      this.base.navigateTo(url);
    },
    hdRemoveRelation(index) {
      let _this = this;
      let item = _this.model.relations[index];
      _this.$refs.eagleForm.confirm(
        `是否确认移除检查表[${item.templateName}]?`,
        () => {
          _this.common
            .post(
              `${_this.control}/removeRelation/${_this.model.code}/${item.checkTemplateCode}`
            )
            .then(function (res) {
              if (res.code == 200) _this.model.relations.splice(index, 1);
              else _this.$refs.eagleForm.errorMsg(res.errorMsg);
            });
        }
      );
    }
  }
};
</script>
<style lang="scss">
.host-danger-plan-view {
  background-color: rgb(243, 244, 246);

  // /deep/.eagle-form {
  //     padding: 0rpx;
  // }

  // /deep/.eagle-form {
  // 	padding:10rpx ;
  // 	/deep/.u-form-item--left__content__label
  // 	{
  // 		    margin-left: 10rpx;
  // 	}
  // }

  .pannel {
    background-color: rgb(255, 255, 255);
    // padding: 5px;
    // margin-top: 10px;
    margin-bottom: 10px;
    padding-left: 15px;
  }

  .base-item {
    line-height: 68rpx !important;
  }

  .record-block {
    line-height: 72rpx;
    .tName-block {
      padding: 0px 16rpx 20rpx 0rpx;
      align-items: center;
    }
    .tName-block:first {
      padding-top: 0px;
    }
  }
}
</style>
