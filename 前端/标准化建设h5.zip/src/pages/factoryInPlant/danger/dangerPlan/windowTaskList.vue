<template name="host-window-task-list">
    <u-popup v-model="showDialog" mode="right" height="100vh" length="100%">
        <eagle-head @close="close">{{headTitle}}</eagle-head>
        <view>
            <eagle-page-list ref="eaglePageList" :controller="controller" :dataType="dataType" :showCheck="true" @initList="_initList" :margin-bottom="96" v-show="!showDetail" :boolInitData="false">
                <view slot="search">
                    <view class="search">
                        <eagle-condition @search="search" :initSearch="true" @reSearch="reSearch" v-model="queryParams" :searchResults="queryParams.year">
                            <eagle-select v-model="queryParams.year" title="选择年份:" prop="year" border :height="70" :data-source="list" labelWidth="150">
                            </eagle-select>
                        </eagle-condition>
                    </view>
                </view>
                <!-- <view slot="search">
                    <view class="search">
                        <eagle-condition @search="search" :initSearch="true" @reSearch="reSearsh">
                            <eagle-radio-group v-model="conditions.checkType.value" title="检查类型" prop="checkType" :data-source="kvs.checkType" v-if="kvs.checkType.length>0" />
                            <eagle-radio-group title="状态" v-model="conditions.status.value" prop="status" :dataSource="kvs.taskStatus" v-if="kvs.taskStatus.length>0" />
                            <eagle-radio-group v-model="conditions.sourceType.value" title="任务来源" prop="sourceType" :data-source="kvs.sourceType" v-if="kvs.sourceType.length>0" />
                            <eagle-input title="任务名称" placeholder="任务名称" v-model="conditions.checkTaskName.value"  :labelWidth="150"></eagle-input>
                        </eagle-condition>
                    </view>
                </view> -->
                <view slot="list" class="list-wrap">
                    <view class="view_container" v-for="(item, index) in data" :key="index">
                        <view @tap="choose(item,true)">
                            <view class="view_row">
                                <view>
                                    <view class="uni-media-list-text-top">{{item.checkTaskName}}</view>
                                </view>
                                <u-checkbox v-model="item.checked" @click.stop.native="choose(item,false)" shape="circle">
                                </u-checkbox>
                            </view>
                        </view>
                    </view>
                </view>
            </eagle-page-list>
            <view class="view-choose-botton">
                <view class="choose-item" v-if="choosedNum>=0&&isMult">
                    <text>已选择:</text>
                    <text class="choose-num">{{choosedNum}}条</text>
                </view>
                <u-button class="choose-btn" type="primary" @click="submit">确定</u-button>
                <!-- <u-button class="choose-btn" v-if="addUrl"  type="primary" @click="handlerFabClick" >新增</u-button> -->
                <u-button v-if="isMult" class="choose-btn" type="primary" @click="cancelChoose">取消选择</u-button>
                <!-- <u-button v-if="isMult&&!showDetail" class="choose-btn"  type="primary"  @click="chooseAll">
                    全选
                </u-button> -->
            </view>
            <u-toast ref="uToast" />

        </view>
    </u-popup>
</template>

<script>
import eagleYearMonth from "@/components/eagle-date/eagle-year-month";
export default {
    components: {
        eagleYearMonth,
    },
    name: "window-task-list",
    props: {
        isMult: {
            type: Boolean,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            headTitle: "选择检查任务",
            queryParams: {
                year: new Date().getFullYear(),
                enterpriseCode: "",
                projectId: "",
                status: 100,
            },
            controller: "rent/dangerCheckTask",
            dataType: "list",
            data: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,
            choosedNum: 0,
            // queryParams: {
            //     enterpriseCode: "",
            //     projectId: ""
            // },
            detailHeigh: 0,
            chooseVal: "",
            showDialog: false,
            list: [],
            conditions: {
                // status: { value: 100, operate: "=" },
            },
        };
    },
    computed: {},
    created() {
        var _this = this;
        var year = new Date().getFullYear();
        for (var i = year - 5; i < year + 5; i++) {
            _this.list.push({
                id: i,
                name: i,
            });
        }
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
    },
    methods: {
        reSearch() {
            this.queryParams.year = new Date().getFullYear();
        },
        _initList(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].code == list[i].code) {
                        list[i].checked = true;
                    }
                }
            }
            this.data = list;
        },
        show() {
            this.showDialog = true;
            setTimeout(() => {
                this.search();
            });
        },
        close() {
            this.showDialog = false;
        },
        search() {
            let _this = this;
            // setTimeout(() => {
            this.$refs.eaglePageList.search({
                conditions: _this.common.getCondtions(_this.conditions),
                params: _this.queryParams,
            });
            // });
            // setTimeout(() => { this.$refs.eaglePageList.search(); });
        },
        choose(obj, update) {
            let _this = this;
            if (update) {
                obj.checked = !obj.checked;
            }
            this.choosedData = [];
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (!_this.isMult) {
                    if (item.code != obj.code) {
                        item.checked = false;
                    }
                }
                if (item.checked) {
                    _this.choosedData.push({
                        idValue: item.code,
                        textValue: item.checkTaskName,
                    });
                }
            }
            this.choosedNum = this.choosedData.length;
        },
        submit() {
            let codeArry = [];
            let nameArry = [];
            if (!this.choosedData || this.choosedData.length <= 0) {
                this.$refs.uToast.show({
                    title: "请选择检查任务",
                    type: "error",
                });
                return;
            }

            this.choosedData.forEach(function (item) {
                codeArry.push(item.idValue);
                nameArry.push(item.textValue);
            });
            let codes = codeArry.join(",");
            let names = nameArry.join(",");
            this.$emit("callBackChoosedData", codes, names);
            this.close();
        },
        chooseAll() {
            let _this = this;
            this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = true;
                _this.choosedData.push({
                    idValue: item.code,
                    textValue: item.checkTaskName,
                });
            });
            this.choosedNum = this.choosedData.length;
        },
        cancelChoose() {
            let _this = this;
            _this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = false;
            });
            _this.choosedNum = 0;
        },
        clear(obj, index) {
            this.choosedData.splice(index, 1);
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (item.code == obj.code) {
                    item.checked = false;
                }
            }
            this.choosedNum = this.choosedData.length;
            if (this.choosedNum == 0) {
                this.showDetail = false;
            }
        },
        checkChange(e) {},
    },
};
</script>

<style lang="scss">
.view_container {
    // background: #fff;
    line-height: 100rpx;
}

.view_row {
    display: flex;
    justify-content: space-between;
    // margin: 0rpx 30rpx;
    border-bottom: 1px solid #ececec;
    background-color: #fff;
}

.uni-media-list-text-top {
    line-height: 100rpx;
    text-indent: 20rpx;
}

// .view-choose-botton {
//     position: fixed;
//     width: 100%;
//     bottom: 0px;
//     padding-bottom: 15px;
//     padding-top: 10px;
//     background: #fff;
//     .choose-item {
//         float: left;
//         display: inline-block;
//         line-height: 40px;
//         margin-left: 10px;
//         font-size: 16px;
//     }

//     .choose-num {
//         color: #2979ff;
//     }

//     .choose-btn {
//         float: right;
//         // margin-left: 8rpx;
//         margin-right: 20rpx;
//     }
// }

.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}

.uni-page-head {
    background-color: $grid-row-base;
    color: white;
}
</style>
