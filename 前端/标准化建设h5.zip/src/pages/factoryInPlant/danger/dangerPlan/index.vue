<template name="host-danger-danger-plan">
  <view class="host-danger-danger-plan">
    <eagle-page-list
      :conditions="conditions"
      :margin-bottom="100"
      ref="eaglePageList"
      @initList="initList"
      :boolInitData="false"
      :controller="controller"
      :queryUrl="controller + '/getPageDataForRent?dataType=' + dataType"
      :dataType="dataType"
    >
      <view slot="search">
        <view class="search">
          <eagle-condition
            @search="search"
            :initSearch="true"
            @reSearch="reSearch"
            v-model="queryParams"
            :searchResults="conditions.checkTaskName.value"
          >
            <eagle-fast-choose
              itemWidth="200rpx"
              v-model="queryParams.serviceState"
              title="任务状态"
              prop="status"
              :data-source="params.serviceState"
            />
            <eagle-input
              title="任务名称"
              placeholder="请输入任务名称模糊查询"
              v-model="conditions.checkTaskName.value"
              :labelWidth="150"
            ></eagle-input>
          </eagle-condition>
        </view>
      </view>
      <view slot="list" class="list-wrap">
        <eagle-row-card
          v-for="(item, index) in data"
          :key="index"
          @click="goToDetail(item.id)"
        >
          <eagle-girdrow-base isTitle>
            <view class="checkTaskName">
              {{ item.checkTaskName }}
            </view>
          </eagle-girdrow-base>
          <template slot="tag">
            <view v-html="bindTag(item.serviceStatus)" />
          </template>
          <eagle-row-view v-if="item.checkTypeName">
            检查类型: {{ item.checkTypeName }}
            <!-- {{bindTag(item.status)}} -->
          </eagle-row-view>
          <eagle-row-view>
            任务日期: {{ item.startDate | dateFormat }}至{{
              item.endDate | dateFormat
            }}
          </eagle-row-view>
          <eagle-row-view>
            检查人: {{ item.checkPersonChName }}
          </eagle-row-view>
          <eagle-row-view>
            检查企业数: {{ item.checkEnterpriseNumParam }}
          </eagle-row-view>
          <template slot="button">
            <u-button
              type="error"
              v-if="
                item.serviceStatus == 1 ||
                item.serviceStatus == 2 ||
                item.serviceStatus == 3
              "
              @click="hdDelete(item)"
              size="mini"
              >删除</u-button
            >
            <u-button
              type="primary"
              @click="eidtPlan(item.id)"
              size="mini"
              v-if="item.serviceStatus == 1"
              >编辑
            </u-button>
            <u-button
              type="success"
              v-if="item.serviceStatus == 4"
              @click="goToDetail(item.id)"
              size="mini"
              >详情
            </u-button>
            <u-button
              type="primary"
              @click="goToDetail(item.id)"
              size="mini"
              v-if="
                item.serviceStatus == 1 ||
                item.serviceStatus == 2 ||
                item.serviceStatus == 3
              "
              >实施
            </u-button>

            <!-- <u-icon class="eagle-red eagle-row-span" name="trash" v-if="item.manager || (item.status==10 && item.self)" label="删除" @click="hdDelete(item)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" v-if="item.status == 10" name="edit-pen" label="编辑" @click="eidtPlan(item.id)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" v-if="item.status != 10" name="eye-fill" label="详情" @click="goToDetail(item.id)"></u-icon>
                        <u-icon class="eagle-blue eagle-row-span" v-if="item.status == 10" name="checkmark" label="实施" @click="goToDetail(item.id)"></u-icon> -->
          </template>
        </eagle-row-card>
      </view>
    </eagle-page-list>
    <eagle-fab
      :popMenu="false"
      horizontal="right"
      @fabClick="eidtPlan(0)"
    ></eagle-fab>
  </view>
</template>

<script>
import eagleYearMonth from "@/components/eagle-date/eagle-year-month";
export default {
  name: "host-danger-danger-plan",
  components: {
    eagleYearMonth
  },
  data() {
    return {
      data: [],
      list: [],
      queryParams: {
        enterpriseCode: null,
        projectId: "",
        serviceState: null
      },
      controller: "rent/dangerCheckTask",
      dataType: "list",
      searchValue: "",
      conditions: {
        checkTaskName: { value: null, operate: "like" }
      },
      params: {
        serviceState: [
          { id: null, name: "不限" },
          { id: 1, name: "待实施", color: "#909399" },
          { id: 2, name: "进行中", color: "#409EFF" },
          { id: 3, name: "已逾期", color: "#E6A23C" },
          { id: 4, name: "已完成", color: "#67C23A" }
        ]
      },
      status: [
        { id: 1, name: "待实施", type: "primary" },
        { id: 2, name: "进行中", type: "primary" },
        { id: 3, name: "已逾期", type: "red" },
        { id: 4, name: "已完成", type: "success" }
      ]
    };
  },
  created() {
    var _this = this;
    var year = new Date().getFullYear();
    for (var i = year - 5; i < year + 5; i++) {
      _this.list.push({
        id: i,
        name: i
      });
    }
    this.queryParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
    this.queryParams.projectId = this.$route.query.projectId ?? "";
    // _this.search()
  },
  methods: {
    bindTag(val) {
      let obj = this.status.find((x) => x.id == val);
      if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
      else return "";
    },

    initList(data) {
      console.log("data", data);
      this.data = data;
    },
    search() {
      setTimeout(() => {
        this.$refs.eaglePageList.search({
          conditions: "",
          params: {
            serviceState: this.queryParams.serviceState
          }
        });
      });
    },
    reSearch() {
      this.queryParams.serviceState = null;
      this.conditions.checkTaskName.value = null;
    },
    hdDelete(item) {
      let _this = this;
      let url = this.controller + "/delete/" + item.id;
      this.$refs.eaglePageList.del({
        url: url,
        successCallback: function () {
          _this.search();
        }
      });
    },
    close() {
      this.visible = false;
    },
    // show(config) {
    //     this.visible = true;
    //     if (config) {
    //         this.queryParams.enterpriseCode = config.enterpriseCode;
    //         this.queryParams.projectId = config.projectId;
    //     }
    //     this.search();
    // },
    eidtPlan(id) {
      let url = `/pages/factoryInPlant/danger/dangerPlan/detail?id=${id}&enterpriseCode=${this.queryParams.enterpriseCode}&projectId=${this.queryParams.projectId}`;
      this.base.navigateTo(url);
    },
    goToDetail(id) {
      let url = `/pages/factoryInPlant/danger/dangerPlan/view?id=${id}&enterpriseCode=${this.queryParams.enterpriseCode}&projectId=${this.queryParams.projectId}`;
      this.base.navigateTo(url);
    }
  }
};
</script>
<style lang="scss" scoped>
.checkTaskName {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: normal;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
</style>
