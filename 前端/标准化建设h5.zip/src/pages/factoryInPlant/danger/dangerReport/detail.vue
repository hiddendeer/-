<template name="host-danger-report-detail">
  <view class="host-danger-report-detail">
    <!-- <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog=false">生成报告</eagle-head>
            <view> -->
    <eagle-form
      class="form-content"
      saveFunName="saveEntity"
      :control="control"
      :boolInitData="false"
      v-model="model"
      ref="eagleForm"
      :out-height="55"
    >
      <eagle-container>
        <view class="item">
          <eagle-window-choose
            ref="chooseRentCompany"
            required
            :isUseEnterprise="false"
            :queryParams="queryParams"
            addUrl=""
            title="所属企业"
            headTitle="请选择所属企业"
            v-model="model.checkCompanyId"
            :isMult="false"
            :names.sync="model.checkCompanyName"
            showDetail="true"
            @change="setProject"
            :queryUrl="
              'rent/dangerCheckTaskDetail/getCurrentTaskcheckCompany/' + taskID
            "
            idField="companyId"
            textField="entName"
            labelPosition="top"
            labelWidth="130"
            :dataType="'list'"
            keyWordName="entName"
            :otherDataShow="true"
            :otherData="['entContact', 'entContactMobile']"
          ></eagle-window-choose>
          <eagle-input
            key="reportName"
            title="报告名称"
            v-model="model.reportName"
            required
          />
          <eagle-radios
            title="报告模板"
            v-if="reportTemp && reportTemp.length > 0"
            required
            :dataSource="reportTemp"
            @change="changeReportSource"
            v-model="model.reportTemplateCode"
          />
          <eagle-date
            type="daterange"
            :startDate.sync="model.startDate"
            :endDate.sync="model.endDate"
            title="检查起止日期"
            prop="startsDate"
            :height="70"
            required
          ></eagle-date>
          <eagle-input
            key="remarks"
            type="textarea"
            title="总结和建议"
            v-model="model.remarks"
          />
        </view>
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button type="primary" class="bottom-btn" @click="post()"
        >生成报告</u-button
      >
    </eagle-bottom-view>
  </view>
  <!-- </u-popup>
    </view> -->
</template>

<script>
export default {
  name: "host-danger-report-detail",
  data() {
    return {
      model: {},
      control: "rent/dangerReport",
      reportTemp: [],
      taskModel: {},
      datetimes: [],
      showDialog: false,
      projectId: "",
      enterpriseCode: "",
      taskCode: "",
      queryParams: {},
      taskID: 0
    };
  },
  created() {
    this.taskID = this.$route.query.taskID ?? 0;
    this.projectId = this.$route.query.projectId ?? "";
    this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
    this.taskCode = this.$route.query.taskCode ?? "";
    this.init();
  },
  computed: {
    isHost() {
      if (this.projectId) return true;
      else return false;
    }
  },
  methods: {
    setProject(data) {
      if (data) {
        this.model.sourceType = "1";
      } else {
        this.model.sourceType = "";
      }
    },
    changeReportSource() {
      this.model.reportTemplateName = this.common.formateDict(
        this.reportTemp,
        this.model.reportTemplateCode
      );
    },
    // bindData() {
    // let _this = this;
    //var reportName = _this.taskModel.checkTaskName;
    // _this.model.reportName = reportName;
    // _this.model.taskNames = _this.taskModel.checkTaskName;
    // _this.model.taskCodes = _this.taskModel.code;
    // _this.model.enterpriseCode = _this.taskModel.enterpriseCode;
    // _this.model.projectId = _this.taskModel.projectId;

    // },
    init(config) {
      let _this = this;
      // _this.showDialog = true;
      // _this.taskModel = config.taskModel;
      // _this.getReportTemp();
      let url = `${_this.control}/initData/0`;
      _this.common
        .get(url, {
          companyCode: this.enterpriseCode,
          taskCode: this.taskCode
        })
        .then((res) => {
          _this.model = res.data;
          _this.bindData();
        });
      //this.$refs.eagleForm.get("initData/0")
    },
    bindData() {
      let type = "rentDangerReport";
      let url = "rent/fileToolDataSource/getMap?reportType=" + type;
      let _this = this;
      _this.common.get(url).then((res) => {
        _this.reportTemp = res.data;
        if (_this.reportTemp.length > 0) {
          let model = _this.reportTemp[0];
          _this.model.reportTemplateCode = model.id;
          _this.model.reportTemplateName = model.name;
        }
      });
    },

    initParams() {},
    post() {
      let _this = this;
      this.$refs.eagleForm.post({
        successCallback: function (res) {
          // _this.showDialog = false;
          // _this.$emit("saveAfter");
          if (res.code == 200) {
            let item = res.data;
            let attach = JSON.parse(item.reportAttach)[0];
            var linkurl = _this.common.getLinkUrl(
              "/pages/factoryInPlant/danger/dangerReport/sign",
              {
                code: attach.attCode || attach.AttCode,
                reportCode: item.code
              }
            );
            uni.reLaunch({
              url: linkurl
            });
          }
        }
      });
    }
  }
};
</script>

<style lang="scss"></style>
