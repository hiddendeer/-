<template>
  <view>
    <eagle-pdf-view
      v-if="url"
      :url="url"
      :title="title"
      :summary="title"
    ></eagle-pdf-view>

    <u-toast ref="uToast" />
  </view>
</template>

<script>
export default {
  data() {
    return {
      url: "",
      title: "查看报告"
    };
  },

  created() {},
  onLoad(options) {
    // const path = new URL(options.fileUrl).pathname
    console.log(options.fileUrl);
    this.url = options.fileUrl;
    this.title = options.title;
  },
  methods: {
    close() {
      this.base.navigateBack(-1);
    }
  }
};
</script>

<style lang="scss"></style>
