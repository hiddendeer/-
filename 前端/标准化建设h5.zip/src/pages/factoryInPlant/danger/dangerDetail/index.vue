<template name="host-plan-danger-list">
  <view class="host-danger-danger-plan">
    <view class="u-tabs-box">
      <u-tabs-swiper
        prop="dangerIndex"
        :bold="false"
        name="name"
        ref="tabs"
        :list="params.taskDetailStatus"
        :current="tabContentIndex"
        @change="onTabChanged"
        :is-scroll="false"
      >
      </u-tabs-swiper>
    </view>
    <eagle-page-list
      ref="eaglePageList"
      :isUseEnterprise="true"
      @initList="_initList"
      :boolInitData="false"
      :marginBottom="110"
      :controller="controller"
      @beforeLoad="beforeLoad"
      :showCheck="true"
      :data-type="'siteList'"
    >
      <view slot="list" class="list-wrap">
        <eagle-row-card
          v-for="(item, index) in data"
          :key="index"
          @click="hdView(item)"
        >
          <eagle-girdrow-base isTitle class="oneline">{{
            item.taskPlanName
          }}</eagle-girdrow-base>
          <template slot="tag">
            <view v-html="bindTag(item.status)" />
          </template>
          <eagle-girdrow-base sBetween>
            <text class="oneline"> 隐患描述:{{ item.hiddenDangerDesc }} </text>
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text class="oneline"> 企业名称:{{ item.checkCompanyName }} </text>
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text class="oneline"> 检查人:{{ item.createChnName }} </text>
          </eagle-girdrow-base>
          <eagle-girdrow-base sBetween>
            <text> 检查时间:{{ item.createDate | dateTimeFormat }} </text>
          </eagle-girdrow-base>
          <template slot="button">
            <u-button
              type="primary"
              size="mini"
              v-if="
                (stype == 1 && item.status == 30 && item.lessorSelf) ||
                (stype == 2 && item.lessorSelf)
              "
              @click="hdClick(item)"
            >
              开始整改</u-button
            >
            <u-button
              type="primary"
              size="mini"
              v-if="item.status == 60 && stype == 1"
              @click="hdVerifyClick(item)"
            >
              验收</u-button
            >

            <u-button type="success" size="mini" @click="hdView(item)"
              >详情</u-button
            >
          </template>
          <!-- </eagle-grid-botton> -->
        </eagle-row-card>
        <!-- </view> -->
      </view>
    </eagle-page-list>
  </view>
</template>
<script>
// import Template from "../../../danger/dangerTemplate/template.vue";
export default {
  props: {
    stype: { type: String, default: "1" }
  },
  // components: { Template },
  mounted() {},
  data() {
    return {
      conditions: {
        hiddenDangerDesc: { value: "", operate: "like" },
        status: { value: null, operate: "=" }
      },
      queryParams: { enterpriseCode: "", projectId: "" },
      controller: "rent/dangerCheckTaskDetail",
      data: [],
      clearabled: true,
      mainCode: "",
      params: {
        checkSource: [
          { id: "", name: "不限" },
          { id: "1", name: "随手拍" },
          { id: "2", name: "依据检查" },
          { id: "3", name: "检查表检查" }
        ],
        taskDetailStatus: [
          { id: "", name: "不限" },
          { id: "30", name: "待整改", type: "red" },
          { id: "60", name: "待验收", type: "orange" },
          { id: "100", name: "已验收", type: "success" }
        ]
      },
      tabContentIndex: 0,
      pageType: 1
    };
  },
  computed: {
    isHost() {
      return this.queryParams.projectId != "";
    }
  },
  created() {
    this.mainCode = this.$route.query.taskCode ?? "";
    this.queryParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
    this.queryParams.projectId = this.$route.query.projectId ?? "";
    this.pageType = this.queryParams.projectId ? 2 : 1;

    if (this.stype == 1) {
      this.controller = "rent/dangerCheckTaskDetail";
    } else {
      this.controller = "rent/dangerCheckTaskFromG";
      this.conditions.status.value = "30";
      this.params.taskDetailStatus.splice(0, 1);
    }
    let _this = this;
    uni.$on("_update_factoryInPlant_dangerDetail_list", () => {
      _this.search();
    });
  },
  onShow() {},
  onReady() {},
  methods: {
    bindTag(val) {
      if (this.conditions.status.value == "30" && this.stype == 2) {
        return `<span class='red'>待整改 </span>`;
      } else if (this.conditions.status.value == "60" && this.stype == 2) {
        return `<span class='orange'>待验收 </span>`;
      }
      let obj = this.params.taskDetailStatus.find((x) => x.id == val);
      if (obj) return `<span class='${obj.type}'>${obj.name} </span>`;
      else return "";
    },
    onTabChanged(index) {
      this.tabContentIndex = index;
      this.conditions.status.value = this.params.taskDetailStatus[index].id;
      this.search();
    },
    reSearsh() {
      this.conditions.hiddenDangerDesc.value = null;
      this.conditions.status.value = null;
      this.search();
    },
    hdDelete(item) {
      let _this = this;
      let url = this.controller + "/delete/" + item.id;
      this.$refs.eaglePageList.del({
        url: url,
        successCallback: function () {
          console.log("hdDelete");
          _this.search();
        }
      });
    },
    hdClick(item) {
      if (this.stype == 1) {
        let linkUrl = this.common.getLinkUrl(
          "/pages/factoryInPlant/danger/dangerDetail/detailCorrective",
          {
            taskCode: item.taskCode,
            id: item.id
          }
        );
        this.base.navigateTo(linkUrl);
      } else {
        let linkUrl = this.common.getLinkUrl(
          "/pages/factoryInPlant/danger/dangerDetail/supervisionTaskVerify",
          {
            mainCode: item.mainCode
          }
        );
        this.base.navigateTo(linkUrl);
      }
    },
    hdVerifyClick(item) {
      let url = "/pages/factoryInPlant/danger/dangerDetail/detailVerify";
      let linkUrl = this.common.getLinkUrl(url, {
        taskCode: item.taskCode,
        id: item.id
      });
      this.base.navigateTo(linkUrl);
    },
    hdView(item) {
      if (this.stype == 1) {
        let linkUrl = this.common.getLinkUrl(
          "/pages/factoryInPlant/danger/dangerDetail/viewNew",
          {
            id: item.id
          }
        );
        this.base.navigateTo(linkUrl);
      } else {
        let linkUrl = this.common.getLinkUrl(
          "/pages/factoryInPlant/danger/dangerDetail/supervisionTaskDetail",
          {
            mainCode: item.mainCode,
            type: this.conditions.status.value
          }
        );
        this.base.navigateTo(linkUrl);
      }
    },
    _initList(list) {
      this.data = list;
    },
    search() {
      let _this = this;
      _this.$refs.eaglePageList.search({
        conditions: _this.common.getCondtions(_this.conditions)
      });
    },
    initParams() {}
  },
  beforeDestroy() {
    uni.$off("_update_factoryInPlant_dangerDetail_list");
  }
};
</script>
<style lang="scss" scoped>
.oneline {
  overflow: hidden;
  white-space: normal;
  word-wrap: break-word;
  word-break: break-all;
  text-overflow: ellipsis;
}
</style>
