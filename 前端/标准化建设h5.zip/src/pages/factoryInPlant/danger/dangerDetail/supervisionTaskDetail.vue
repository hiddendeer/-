<template>
  <view class="host-danger-danger-view">
    <eagle-form
      :boolInitData="false"
      v-model="model"
      ref="eagleForm"
      marginBottom="80px"
    >
      <eagle-container>
        <view slot="title">隐患详情</view>
        <eagle-text title="隐患图片">
          <eagle-display-image
            prop="attachs"
            v-model="model.attachs"
          ></eagle-display-image>
        </eagle-text>

        <eagle-text title="检查人" v-model="model.createChnName" />
        <eagle-text title="检查时间" key="createDate">
          {{ model.createDate | dateFormat }}
        </eagle-text>
        <eagle-text title="检查结果">
          <span>不符合</span>
        </eagle-text>
        <eagle-text title="隐患区域" v-model="model.correctiveArea" />
        <eagle-text title="隐患描述" v-model="model.hiddenDangerDesc" />
        <eagle-text title="隐患性质" v-model="model.hiddenName" />
        <eagle-text title="隐患分类" v-model="model.hiddenTypeName" />

        <eagle-text
          title="整改图片"
          key="correctiveAttachs"
          v-if="model.status != 30"
        >
          <eagle-display-image v-model="model.correctiveAttachs" />
        </eagle-text>
      </eagle-container>
      <eagle-container v-if="type == 100">
        <view v-for="(item, index) in verifyData" :key="index">
          <eagle-text title="验收人" v-model="item.CreateChnName" />
          <eagle-text title="验收时间" key="verifyDate">
            {{ item.VerifyDate | dateFormat }}
          </eagle-text>
          <eagle-text title="验收意见" v-model="item.OperateLog" />
          <eagle-text title="验收图片" key="VerifyAttachsForToBeVerified">
            <eagle-display-image v-model="item.VerifyAttachsForToBeVerified" />
          </eagle-text>
        </view>
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button class="bottom-btn" type="primary" @click="back()">
        返回
      </u-button>
    </eagle-bottom-view>
  </view>
</template>

<script>
export default {
  components: {},
  name: "host-danger-danger-view",
  data() {
    return {
      title: "隐患详情",
      model: {},
      mainCode: "",
      type: "",
      verifyData: []
    };
  },
  created() {},
  onLoad(options) {
    this.mainCode = options.mainCode;
    this.type = options.type;
    this.getModel();
  },
  computed: {},

  methods: {
    getModel() {
      var _this = this;
      if (this.type == 100) {
        this.common
          .get(
            "/rent/dangerCheckTaskFromG/getAccepInfo?mainCode=" + this.mainCode
          )
          .then((res) => {
            if (res.code == 200) {
              _this.verifyData = res.data;
              _this.verifyData.forEach((item) => {
                item.VerifyAttachsForToBeVerified =
                  item.VerifyAttachsForToBeVerified?.replaceAll(",", ";");
              });
            }
          });
      }
      this.common
        .get(
          "/rent/dangerCheckTaskFromG/getGHiddenDangerDetail?mainCode=" +
            this.mainCode +
            "&HiddenType=" +
            this.type
        )
        .then((res) => {
          if (res.code == 200) {
            console.log("res", res);
            this.model = res.data;
            this.model.attachs = this.model.attachs?.replaceAll(",", ";");
            this.model.correctiveAttachs =
              this.model.correctiveAttachs?.replaceAll(",", ";");
            console.log(
              "this.model.correctiveAttachs",
              this.model.correctiveAttachs
            );
            this.$forceUpdate();
          }
        });
    },
    back() {
      this.base.navigateBack();
    }
  }
};
</script>
<style lang="scss" scoped></style>
