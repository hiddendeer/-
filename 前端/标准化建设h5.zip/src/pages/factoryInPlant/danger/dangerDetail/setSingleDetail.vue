<template>
  <view class="host-danger-set-single-detail">
    <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
      <eagle-form :model="model" :boolInitData="false" marginBottom="60px">
        <eagle-head @close="showDialog = false"
          >{{ opType == "view" ? "隐患详情" : "录入隐患信息" }}
        </eagle-head>
        <view v-if="model.checkResult === 'N'">
          <eagle-upload
            :isNeedEdit="true"
            title="隐患图片"
            v-if="opType !== 'view'"
            key="attachs"
            prop="attachs"
            v-model="model.attachs"
          />
          <eagle-display-image
            title="隐患图片"
            v-if="opType === 'view'"
            key="display_attachs"
            prop="attachs"
            v-model="model.attachs"
          />
          <eagle-input
            type="textarea"
            :disabled="opType == 'view'"
            title="隐患区域"
            :required="model.hiddenTypeCode == '2' ? true : false"
            v-model="model.correctiveArea"
          />
          <view style="background: #ffffff">
            <view
              class="quick-select"
              v-if="
                opType != 'view' &&
                item.greatGrandsons &&
                item.greatGrandsons.length > 0 &&
                item.greatGrandsons[0].hiddenDangerDesc
              "
            >
              <view class="useing-title">快捷选择隐患</view>
              <view
                v-for="(item, index) in item.greatGrandsons"
                class="using-content"
                :key="index"
              >
                <!-- {{index+1}}. {{item.hiddenDangerDesc}}
                            <span class="btn-using" @click="setDangerDesc(item)">引用</span> -->
                <span style="width: calc(100% - 50px)">
                  {{ index + 1 }}. {{ item.hiddenDangerDesc }}</span
                >
                <span class="btn-using" @click="setDangerDesc(item)">引用</span>
              </view>
            </view>
          </view>
          <eagle-input
            type="textarea"
            :disabled="opType == 'view'"
            title="隐患描述"
            required
            v-model="model.hiddenDangerDesc"
          />
          <eagle-input
            type="textarea"
            :disabled="opType == 'view'"
            title="整改建议"
            v-model="model.correctiveAdvise"
          >
            <template slot="topBotton">
              <view style="text-align: right; margin-top: 10px">
                <span
                  style="
                    color: #2979ff;
                    margin-left: 20rpx;
                    margin-right: 20rpx;
                  "
                  @click="showDetail()"
                  >{{ opType != "view" ? "编辑依据" : "查看依据" }}</span
                >
              </view>
            </template>
          </eagle-input>
          <eagle-choose
            title="隐患分类"
            :disabled="opType == 'view'"
            v-model="model.hiddenName"
            :required="isHost"
            :select-open="dangerTypeDialog"
            @click="showDangerType(model)"
          />
          <eagle-radios
            title="隐患性质"
            :disabled="opType == 'view'"
            required
            :dataSource="checkDatas.checkType"
            v-model="model.hiddenDangerTypeCode"
          />


          <eagle-radios
            title="整改方式"
            :disabled="opType == 'view'"
            required
            :dataSource="checkDatas.correctiveType"
            v-model="model.correctiveType"
          />

          <eagle-date
            v-if="model.correctiveType == 2"
            :disabled="opType == 'view'"
            label-width="100px"
            key="correctiveDeadline"
            title="整改期限"
            v-model="model.correctiveDeadline"
          />
          <eagle-input
            v-if="model.correctiveType == 2"
            :disabled="opType == 'view'"
            type="textarea"
            key="correctiveMeasure"
            :row="2"
            label-width="100px"
            title="整改措施"
            v-model="model.correctiveMeasure"
          />
          <eagle-upload
            required
            title="整改图片"
            v-if="model.correctiveType == 1 && opType !== 'view'"
            key="correctiveAttachs"
            prop="correctiveAttachs"
            v-model="model.correctiveAttachs"
          />
          <eagle-display-image
            required
            title="整改图片"
            v-if="model.correctiveType == 1 && opType === 'view'"
            key="correctiveAttachs"
            prop="correctiveAttachs"
            v-model="model.correctiveAttachs"
          />
          <eagle-input
            v-if="model.correctiveType == 1"
            type="textarea"
            :disabled="opType == 'view'"
            key="correctiveDesc"
            :row="2"
            label-width="100px"
            title="整改说明"
            required
            v-model="model.correctiveDesc"
          />
        </view>
      </eagle-form>
      <eagle-bottom-view>
        <u-button type="primary" v-if="opType != 'view'" @click="confirm"
          >确 定</u-button
        >
        <u-button
          type="primary"
          v-if="opType == 'view'"
          @click="showDialog = false"
          >返 回</u-button
        >
      </eagle-bottom-view>
      <view-danger-lg ref="viewDangerLg"></view-danger-lg>
      <popup-danger-type
        ref="popupDangerType"
        :dialog-show="dangerTypeDialog"
        @close="dangerTypeDialog = false"
        v-model="model.hiddenCode"
        @change="changeDangeType"
      ></popup-danger-type>
    </u-popup>
  </view>
</template>

<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type.vue";
export default {
  components: {
    popupDangerType,
    "view-danger-lg": viewDangerLg
  },
  props: {
    // needHiddenCode: {
    //     type: Boolean,
    //     default() {
    //         return true;
    //     },
    // },
  },
  data() {
    return {
      dangerTypeDialog: false,
      title: "录入检查情况",
      showDialog: false,
      model: {},
      item: {},
      opType: "view",
      tempModel: {},
      checkDatas: {
        checkType: [
          { id: 1, name: "一般隐患" },
          { id: 2, name: "重大隐患" }
        ],
        correctiveType: [
          { id: 1, name: "立即整改" },
          { id: 2, name: "限时整改" }
        ]
      },
      projectId: this.$route.query.projectId
    };
  },
  computed: {
    isHost() {
      if (this.projectId) return true;
      else return false;
    }
  },
  methods: {
    hdSetMeCorrective() {
      let _this = this;
      let userInfo = uni.getStorageSync("userInfo");
      if (typeof userInfo === "string") {
        userInfo = JSON.parse(userInfo);
      }
      _this.model.appointCorrectiveChnName = userInfo.chnName;
      _this.model.appointCorrectiveName = userInfo.userName;
    },
    showDetail(item) {
      let config = {
        isEdit: this.opType != "view",
        model: this.model
      };
      this.$refs.viewDangerLg.show(config);
    },
    show(config) {
      this.model = this.utils.deepClone(config.model);
      this.tempModel = config.model;
      this.item = config.item;
      // if (this.model.checkResult != "N") {
      //     this.model.remarks = this.model.hiddenDangerDesc;
      //     this.model.hiddenDangerDesc = "";
      // }
      this.opType = config.opType;

      this.showDialog = true;
    },
    showDangerType() {
      this.dangerTypeDialog = true;
    },
    changeDangeType(obj) {
      this.model.hiddenCode = obj.dCode;
      this.model.hiddenName = obj.dFullName.replace(">", "-");
      this.model.hiddenTypeCode = obj.dType;
      this.model.hiddenTypeName = obj.dType == "1" ? "基础管理" : "现场管理";
      this.dangerTypeDialog = false;
    },
    setDangerDesc(item) {
      this.model.hiddenDangerDesc = item.hiddenDangerDesc;
      this.model.hiddenDangerTypeCode = item.hiddenDangerType;
      this.model.legalLiability = item.legalLiability;
      this.model.hiddenCode = item.dCode;
      if (item.dName) {
        this.model.hiddenTypeName = item.dType == "1" ? "基础管理" : "现场管理";
        this.model.hiddenName =
          this.model.hiddenTypeName + "-" + item.dName.replace(">", "-");
        this.model.hiddenTypeCode = item.dType;
      }
    },
    confirm() {
      this.showDialog = false;
      if (this.model.checkResult != "N") {
        this.model.hiddenDangerDesc = this.model.remarks;
        this.model.remarks = "";
      }
      if (this.model.checkResult === "N") {
        this.model.isOver = true;
        if (
          (!this.model.correctiveArea && this.model.hiddenTypeCode == "2") ||
          !this.model.hiddenDangerDesc ||
          (!this.model.hiddenName && this.isHost) ||
          !this.model.hiddenDangerTypeCode ||
          !this.model.correctiveType ||
          (!this.isHost && !this.model.appointCorrectiveName)
        ) {
          this.model.isOver = false;
        } else if (
          this.model.correctiveType == "1" &&
          (!this.model.correctiveAttachs || !this.model.correctiveDesc)
        ) {
          this.model.isOver = false;
        }
      }
      if (this.opType == "edit") {
        for (let key in this.model) {
          this.$set(this.tempModel, key, this.model[key]);
        }
        console.log("edit", this.tempModel);
      } else {
        this.item.checkDetails.push(this.model);
        console.log(this.item);
      }
      this.$emit("confirm", this.model, this.opType);
    }
  }
};
</script>

<style lang="scss">
.host-danger-set-single-detail {
  .useing-title {
    color: #ff9900;
  }

  .btn-using {
    color: $grid-row-base;
    // margin-left: 20rpx;
    width: 50px;
    font-size: 16px;
  }

  .using-content {
    margin-top: 5px;
    text-indent: 12px;
    display: flex;
    justify-content: space-between;
  }
  .quick-select {
    margin: 0 30rpx;
    border-bottom: 1px solid #eee;
  }
}
</style>
