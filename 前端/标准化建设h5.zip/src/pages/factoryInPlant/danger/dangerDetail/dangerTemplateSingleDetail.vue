<template name="host-danger-template-single-detail">
  <view class="host-danger-template-single-detail">
    <eagle-form :model="model" :boolInitData="false" marginBottom="60px">
      <eagle-container>
        <eagle-upload
          :isNeedEdit="true"
          title="隐患图片"
          v-if="opType !== 'view'"
          key="attachs"
          prop="attachs"
          v-model="model.attachs"
        />
        <eagle-display-image
          title="隐患图片"
          v-if="opType === 'view'"
          key="display_attachs"
          prop="attachs"
          v-model="model.attachs"
        />
        <eagle-window-choose
          ref="chooseRentCompany"
          required
          :isUseEnterprise="false"
          :queryParams="queryParams"
          addUrl=""
          title="所属企业"
          headTitle="请选择所属企业"
          v-model="model.checkCompanyId"
          :isMult="false"
          :names.sync="model.checkCompanyName"
          showDetail="true"
          @change="setProject"
          :queryUrl="
            'rent/dangerCheckTaskDetail/getCurrentTaskcheckCompany/' + taskID
          "
          idField="companyId"
          textField="entName"
          labelPosition="top"
          labelWidth="130"
          :dataType="'list'"
          keyWordName="entName"
          :otherDataShow="true"
          :otherData="['entContact', 'entContactMobile']"
        ></eagle-window-choose>
        <eagle-input
          type="textarea"
          :disabled="opType == 'view'"
          title="隐患区域"
          :required="model.hiddenTypeCode == '2' ? true : false"
          v-model="model.correctiveArea"
        />
        <view style="background: #ffffff">
          <view
            class="quick-select"
            v-if="
              opType != 'view' &&
              item.greatGrandsons &&
              item.greatGrandsons.length > 0 &&
              item.greatGrandsons[0].hiddenDangerDesc
            "
          >
            <view class="useing-title">快捷选择隐患</view>
            <view
              v-for="(item, index) in item.greatGrandsons"
              class="using-content"
              :key="index"
            >
              <span style="width: calc(100% - 40px)">
                {{ index + 1 }}. {{ item.hiddenDangerDesc }}</span
              >
              <span class="btn-using" @click="setDangerDesc(item)">引用</span>
            </view>
          </view>
        </view>
        <eagle-input
          type="textarea"
          :disabled="opType == 'view'"
          title="隐患描述"
          required
          v-model="model.hiddenDangerDesc"
        />
        <eagle-input
          type="textarea"
          :disabled="opType == 'view'"
          title="整改建议"
          v-model="model.correctiveAdvise"
        >
          <template slot="topBotton">
            <view style="text-align: right; margin-top: 10px">
              <span
                style="color: #2979ff; margin-right: 30rpx; margin-left: 20rpx"
                @click="showDetail()"
                >{{ opType != "view" ? "编辑依据" : "查看依据" }}</span
              >
            </view>
          </template>
        </eagle-input>
        <eagle-choose
          title="隐患分类"
          :disabled="opType == 'view'"
          v-model="model.hiddenName"
          :required="isHost"
          :select-open="dangerTypeDialog"
          @click="showDangerType(model)"
        />
        <eagle-radios
          title="隐患性质"
          :disabled="opType == 'view'"
          required
          :dataSource="checkDatas.checkType"
          v-model="model.hiddenDangerTypeCode"
        />
        <eagle-radios
          title="整改方式"
          :disabled="opType == 'view'"
          required
          :dataSource="checkDatas.correctiveType"
          v-model="model.correctiveType"
        />
        <eagle-date
          v-if="model.correctiveType == 2"
          :disabled="opType == 'view'"
          label-width="100px"
          key="correctiveDeadline"
          title="整改期限"
          v-model="model.correctiveDeadline"
        />
        <eagle-input
          v-if="model.correctiveType == 2"
          :disabled="opType == 'view'"
          type="textarea"
          key="correctiveMeasure"
          :row="2"
          label-width="100px"
          title="整改措施"
          v-model="model.correctiveMeasure"
        />
        <eagle-upload
          required
          title="整改图片"
          v-if="model.correctiveType == 1 && opType !== 'view'"
          key="correctiveAttachs"
          prop="correctiveAttachs"
          v-model="model.correctiveAttachs"
        />
        <eagle-display-image
          required
          title="整改图片"
          v-if="model.correctiveType == 1 && opType === 'view'"
          key="correctiveAttachs"
          prop="correctiveAttachs"
          v-model="model.correctiveAttachs"
        />
        <eagle-input
          v-if="model.correctiveType == 1"
          type="textarea"
          :disabled="opType == 'view'"
          key="correctiveDesc"
          :row="2"
          label-width="100px"
          title="整改说明"
          required
          v-model="model.correctiveDesc"
        />
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button class="bottom-btn" type="info" @click="hdBack">返 回</u-button>
      <u-button
        class="bottom-btn"
        type="primary"
        v-if="opType != 'view'"
        @click="confirm"
        >确 定</u-button
      >
    </eagle-bottom-view>
    <view-danger-lg ref="viewDangerLg"></view-danger-lg>
    <popup-danger-type
      ref="popupDangerType"
      :dialog-show="dangerTypeDialog"
      @close="dangerTypeDialog = false"
      v-model="model.hiddenCode"
      @change="changeDangeType"
    ></popup-danger-type>
  </view>
</template>
<script>
import viewDangerLg from "@/pages/components/danger/view-danger-lg";
import popupDangerType from "@/pages/components/danger/popup-danger-type.vue";
import EagleContainer from "../../../../components/eagle-container/eagle-container.vue";
export default {
  components: {
    popupDangerType,
    "view-danger-lg": viewDangerLg,
    EagleContainer
  },
  data() {
    return {
      dangerTypeDialog: false,
      model: {},
      item: {},
      opType: this.$route.query.opType ?? "view",
      tempModel: {},
      checkDatas: {
        checkType: [
          { id: 1, name: "一般隐患" },
          { id: 2, name: "重大隐患" }
        ],
        correctiveType: [
          { id: 1, name: "立即整改" },
          { id: 2, name: "限时整改" }
        ]
      },
      projectId: this.$route.query.projectId ?? "",
      queryParams: {},
      taskID: 0
    };
  },
  created() {
    this.taskID = this.$route.query.taskID ?? 0;
    this.initData();
  },
  computed: {
    isHost() {
      if (this.projectId) return true;
      else return false;
    }
  },
  methods: {
    setProject(data) {},
    hdBack() {
      localStorage.removeItem("Host_DangerForTemp_danger");
      localStorage.removeItem("Host_DangerForTemp_GreatGrandsons");
      this.base.navigateBack(1);
    },
    initData() {
      this.model = {};
      this.item = [];
      this.model = JSON.parse(
        localStorage.getItem("Host_DangerForTemp_danger")
      );
      this.item = JSON.parse(
        localStorage.getItem("Host_DangerForTemp_GreatGrandsons")
      );
    },

    hdSetMeCorrective() {
      let _this = this;
      let userInfo = uni.getStorageSync("userInfo");
      if (typeof userInfo === "string") {
        userInfo = JSON.parse(userInfo);
      }
      _this.model.appointCorrectiveChnName = userInfo.chnName;
      _this.model.appointCorrectiveName = userInfo.userName;
    },
    showDetail(item) {
      let config = {
        isEdit: this.opType != "view",
        model: this.model
      };
      this.$refs.viewDangerLg.show(config);
    },

    showDangerType() {
      this.dangerTypeDialog = true;
    },
    changeDangeType(obj) {
      this.model.hiddenCode = obj.dCode;
      this.model.hiddenName = obj.dFullName.replace(">", "-");
      this.model.hiddenTypeCode = obj.dType;
      this.model.hiddenTypeName = obj.dType == "1" ? "基础管理" : "现场管理";
      this.dangerTypeDialog = false;
    },
    setDangerDesc(item) {
      this.model.hiddenDangerDesc = item.hiddenDangerDesc;
      this.model.hiddenDangerTypeCode = item.hiddenDangerType;
      this.model.legalLiability = item.legalLiability;
      this.model.hiddenCode = item.dCode;
      if (item.dName) {
        this.model.hiddenTypeName = item.dType == "1" ? "基础管理" : "现场管理";
        this.model.hiddenName =
          this.model.hiddenTypeName + "-" + item.dName.replace(">", "-");
        this.model.hiddenTypeCode = item.dType;
      }
    },
    confirm() {
      this.model.isOver = true;
      if (
        (!this.model.correctiveArea && this.model.hiddenTypeCode == "2") ||
        !this.model.hiddenDangerDesc ||
        (!this.model.hiddenName && this.isHost) ||
        !this.model.hiddenDangerTypeCode ||
        !this.model.correctiveType ||
        (!this.isHost && !this.model.appointCorrectiveName)
      ) {
        this.model.isOver = false;
      } else if (
        this.model.correctiveType == "1" &&
        (!this.model.correctiveAttachs || !this.model.correctiveDesc)
      ) {
        this.model.isOver = false;
      }

      this.item.checkDetails.push(this.model);

      this.$bus.$emit("Host_DangerForTemp", this.model);
      this.hdBack();
      // this.$emit("confirm", this.model, this.opType);
    }
  }
};
</script>

<style lang="scss">
.host-danger-template-single-detail {
  .useing-title {
    color: #ff9900;
  }

  .btn-using {
    color: $grid-row-base;
    // margin-left: 20rpx;
    width: 50px;
    font-size: 16px;
  }

  .using-content {
    margin-top: 5px;
    text-indent: 12px;
    display: flex;
    justify-content: space-between;
  }
  .quick-select {
    margin: 0 30rpx;
    border-bottom: 1px solid #eee;
  }
}
</style>
