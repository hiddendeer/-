<template>
  <view class="host-danger-danger-detail-corrective">
    <eagle-form
      class="form-content"
      :boolInitData="false"
      v-model="model"
      ref="eagleForm"
      marginBottom="80px"
    >
      <eagle-container title="整改">
        <eagle-upload
          title="整改图片"
          required
          key="correctiveAttachs"
          prop="correctiveAttachs"
          v-model="model.correctiveAttachs"
        />
      </eagle-container>
    </eagle-form>
    <eagle-bottom-view>
      <u-button class="bottom-btn" type="primary" @click="back()">
        返回
      </u-button>
      <u-button class="bottom-btn" type="primary" @click="post()">
        整改
      </u-button>
    </eagle-bottom-view>
    <u-toast ref="uToast" />
    <eagle-comfirm ref="eagleConfirm"></eagle-comfirm>
  </view>
</template>

<script>
export default {
  components: {},
  name: "factoryInPlant-danger-danger-detail-corrective",
  data() {
    return {
      model: { correctiveAttachs: "" },
      mainCode: ""
    };
  },
  computed: {},
  created() {},
  onLoad(options) {
    this.mainCode = options.mainCode || "";
  },
  // onShow() {},
  methods: {
    post() {
      let _this = this;
      let url = `rent/dangerCheckTaskFromG/rectifyGovernmentHD`;
      let param = {
        mainCode: _this.mainCode,
        attUrl: _this.model.correctiveAttachs.replaceAll(";", ",")
      };
      _this.common
        .get(url, param)
        .then((res) => {
          if (res.code == 200) {
            _this.$refs.uToast.show({
              title: "整改成功",
              type: "success"
            });
            uni.$emit("_update_factoryInPlant_dangerDetail_list");
            _this.back();
          }
        })
        .catch((err) => {
          _this.$refs.uToast.show({
            title: "整改失败：" + err.errMsg,
            type: "error"
          });
        });
    },
    back() {
      this.base.navigateBack();
    }
  }
};
</script>

<style lang="scss"></style>
