<template name="host-danger-temp-check">
    <view class="host-danger-temp-check">
        <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
            <eagle-head @close="showDialog = false">{{ title }}</eagle-head>
            <view class="subs-container">
                <view @click="hdSwaper(0)" class="subs-item"
                    style="color: #FFFFFF;background-color: rgb(92, 143, 232);">
                    待检查{{ waithCheck }}项
                </view>
                <view @click="hdSwaper(1)" class="subs-item"
                    style="color: #FFFFFF;background-color:rgb(187, 187, 187);">
                    不适用{{ unUserCheck }}项
                </view>
                <view @click="hdSwaper(2)" class="subs-item" style="color: #FFFFFF;background-color: rgb(215, 17, 17);">
                    发现隐患{{ failCheck }}个
                </view>
                <view @click="hdSwaper(3)" class="subs-item" style="color: #FFFFFF;background-color:rgb(215, 153, 17);">
                    待完善{{ waithInputCheck }}项
                </view>
            </view>
            <view>
                <u-tabs :list="tabs" :showBar="false" :current="tabIndex" @change="tabChange"></u-tabs>
            </view>
            <scroll-view class="temp-container" scroll-y :scroll-top="scrollTop" :style="{ height: height + 'px' }"
                @scroll="scroll">
                <view>
                    <view class="temp-item" v-for="(item, index) in tempModel.details" :key="'item_' + index">
                        <view class="temp-item-title" :id="'item_' + index">
                            {{ index + 1 }}{{ item.detailTitle }}
                        </view>
                        <view v-for="(gitem, gindex) in item.grandsons" class="temp-item-container"
                            :id="'item_' + index + '_' + gindex" :key="'item_' + index + '_' + gindex">
                            <view class="item-cl-title">
                                {{ gindex + 1 }} {{ gitem.itemName }}
                            </view>
                            <view class="button-pannel">
                                <view class="button-item Y" @click="setCheckResult(gitem, 'Y')"
                                    :class="gitem.checkResult === 'Y' ? 'checked' : ''">符合</view>
                                <view class="button-item N" @click="setCheckResult(gitem, 'N')"
                                    :class="gitem.checkResult === 'N' ? 'checked' : ''">不符合</view>
                                <view class="button-item NA" @click="setCheckResult(gitem, 'NA')"
                                    :class="gitem.checkResult === 'NA' ? 'checked' : ''">不适用</view>
                            </view>
                            <view v-if="gitem.checkResult === 'N'">
                                <view class="push-danger" @click="pushDanger(gitem)" v-if="isEdit">
                                    <u-icon name="plus-circle"></u-icon>新增隐患
                                </view>
                                <view class="check-item" v-for=" (ditem, dindex) in gitem.checkDetails"
                                    :id="'item_' + index + '_' + gindex + '_' + dindex"
                                    :key="'item_' + index + '_' + gindex + '_' + dindex">
                                    <view class="check-item-content"
                                        @click="editCheck(ditem, gitem, isEdit ? 'edit' : 'view')">
                                        <eagle-img :src="ditem.attachs" :showCount="1" />
                                        <view style="padding-top: 10rpx; width: 100%;">
                                            <view class="check-item-title"
                                                style="display: flex;justify-content: space-between;">
                                                <view>隐患描述</view>
                                                <view v-if="ditem.isOver === false" class="item-status"> 待完善</view>
                                            </view>
                                            <view class="check-item-text N">{{ ditem.hiddenDangerDesc }}</view>
                                            <view class="check-item-title">隐患区域</view>
                                            <view class="check-item-text corrective-area">{{ ditem.correctiveArea }}
                                            </view>
                                        </view>
                                    </view>
                                    <eagle-grid-botton v-if="isEdit">
                                        <u-button type="error" size="mini"
                                            @click="gitem.checkDetails.splice(dindex, 1)">删除</u-button>
                                        <u-button type="primary" size="mini" @click="editCheck(ditem, gitem, 'edit')">编辑
                                        </u-button>
                                    </eagle-grid-botton>
                                </view>

                            </view>
                        </view>
                    </view>
                </view>
            </scroll-view>
            <eagle-bottom-view>
                <u-button class="bottom-btn" type="default" @click="showDialog = false">返 回</u-button>
                <u-button :disabled='waithCheck != 0' class="bottom-btn" v-if="isEdit" type="primary" @click="post()">提交并返回</u-button>

            </eagle-bottom-view>
            <setSingleDetail :needHiddenCode="needHiddenCode" ref="setSingleDetail" @confirm="singleConfirm">
            </setSingleDetail>
        </u-popup>
        <u-toast ref="uToast" />
    </view>
</template>

<script>
import setSingleDetail from "@/pages/factoryInPlant/danger/dangerDetail/setSingleDetail.vue";
export default {
    components: {
        setSingleDetail,
    },
    name: "host-danger-temp-check",
    data() {
        return {
            tabs: [],
            tabIndex: 4,
            showDialog: false,
            isEdit: true,
            title: "检查表检查",
            control: "rent/dangerCheckTaskDetail",
            taskCode: "",
            tempCode: "",
            tempName: "",
            tempModel: {},
            tempCheckDetail: [],
            singleModel: {},
            swaperPreIndex: 0,
            swaperPreType: 0,
            height: "auto",
            scrollTop: 0,
            projectId: "",
            needHiddenCode: true,
        };
    },
    created() {
        this.projectId = this.$route.query.projectId ?? "";
    },
    mounted() {
        this.resetHeight(210); //450px
    },
    computed: {
        waithCheck() {
            let num = 0;
            if (
                this.tempModel &&
                this.tempModel.details &&
                this.tempModel.details.length > 0
            )
                this.tempModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (!citem.checkResult) num++;
                    });
                });
            return num;
        },
        unUserCheck() {
            let num = 0;
            if (
                this.tempModel &&
                this.tempModel.details &&
                this.tempModel.details.length > 0
            )
                this.tempModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (citem.checkResult === "NA") num++;
                    });
                });
            return num;
        },

        failCheck() {
            let num = 0;
            if (
                this.tempModel &&
                this.tempModel.details &&
                this.tempModel.details.length > 0
            )
                this.tempModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (
                            citem.checkResult === "N" &&
                            citem.checkDetails &&
                            citem.checkDetails.length > 0
                        ) {
                            num = num + citem.checkDetails.length;
                        }
                    });
                });
            return num;
        },
        waithInputCheck() {
            let num = 0;
            if (
                this.tempModel &&
                this.tempModel.details &&
                this.tempModel.details.length > 0
            )
                this.tempModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (
                            citem.checkResult === "N" &&
                            citem.checkDetails &&
                            citem.checkDetails.length > 0
                        ) {
                            citem.checkDetails.forEach((x) => {
                                if (!x.isOver) num++;
                            });
                        }
                    });
                });
            return num;
        },
        isHost() {
            if (this.projectId) return true;
            else return false;
        },
    },
    methods: {
        scroll(e) {
            if (e.detail.scrollTop < 200) {
                this.tabIndex = 0;
            } else if (e.detail.scrollTop > 200) {
                this.tabIndex = 1;
            }
        },
        hdSwaper(type) {
            let _this = this;
            if (type === _this.swaperPreType) _this.swaperPreIndex++;
            else {
                _this.swaperPreType = type;
                _this.swaperPreIndex = 0;
            }
            //定义min 是为了减少循环,且避免死循环
            let index = -1;
            let minIndex = -1;
            // let cIndex = -1;
            // let cMinIndex = -1;
            let flag = false;
            let minFlag = false;

            let selector = "";
            let minSelector = "";

            if (
                _this.tempModel &&
                _this.tempModel.details &&
                _this.tempModel.details.length > 0
            )
                _this.tempModel.details.forEach((item, i) => {
                    item.grandsons.forEach((citem, ci) => {
                        switch (type) {
                            //待检查项
                            case 0:
                                index++;
                                if (minFlag == false && !citem.checkResult) {
                                    minIndex = index;
                                    minFlag = true;
                                    minSelector = `#item_${i}_${ci}`;
                                }
                                if (flag == false && !citem.checkResult) {
                                    if (index >= _this.swaperPreIndex) {
                                        _this.swaperPreIndex = index;
                                        flag = true;
                                        selector = `#item_${i}_${ci}`;
                                    }
                                }
                                break;
                            //不适用项
                            case 1:
                                index++;
                                if (
                                    minFlag == false &&
                                    citem.checkResult === "NA"
                                ) {
                                    minIndex = index;
                                    minFlag = true;
                                    minSelector = `#item_${i}_${ci}`;
                                }
                                if (
                                    flag == false &&
                                    citem.checkResult === "NA"
                                ) {
                                    if (index >= _this.swaperPreIndex) {
                                        flag = true;
                                        _this.swaperPreIndex = index;
                                        selector = `#item_${i}_${ci}`;
                                    }
                                }
                                break;

                            //隐患数
                            case 2:
                                if (citem.checkResult === "N")
                                    if (
                                        citem.checkDetails &&
                                        citem.checkDetails.length > 0
                                    ) {
                                        citem.checkDetails.forEach(
                                            (gitem, gi) => {
                                                index++;
                                                if (
                                                    minFlag == false &&
                                                    gitem.checkResult === "N"
                                                ) {
                                                    minIndex = index;
                                                    minFlag = true;
                                                    minSelector = `#item_${i}_${ci}_${gi}`;
                                                }
                                                if (
                                                    flag == false &&
                                                    gitem.checkResult === "N"
                                                ) {
                                                    if (
                                                        index >=
                                                        _this.swaperPreIndex
                                                    ) {
                                                        flag = true;
                                                        _this.swaperPreIndex =
                                                            index;
                                                        selector = `#item_${i}_${ci}_${gi}`;
                                                    }
                                                }
                                            }
                                        );
                                    }
                                break;
                            //待完善
                            case 3:
                                if (citem.checkResult === "N")
                                    if (
                                        citem.checkDetails &&
                                        citem.checkDetails.length > 0
                                    ) {
                                        citem.checkDetails.forEach(
                                            (gitem, gi) => {
                                                index++;
                                                if (
                                                    minFlag == false &&
                                                    gitem.isOver === false
                                                ) {
                                                    minIndex = index;
                                                    minFlag = true;
                                                    minSelector = `#item_${i}_${ci}_${gi}`;
                                                }
                                                if (
                                                    flag == false &&
                                                    gitem.isOver === false
                                                ) {
                                                    if (
                                                        index >=
                                                        _this.swaperPreIndex
                                                    ) {
                                                        flag = true;
                                                        _this.swaperPreIndex =
                                                            index;
                                                        selector = `#item_${i}_${ci}_${gi}`;
                                                    }
                                                }
                                            }
                                        );
                                    }
                                break;
                        }
                    });
                });
            if (selector) {
                this.goAnchor(selector);
            } else if (minSelector) {
                _this.swaperPreIndex = minIndex;
                this.goAnchor(minSelector);
            }
        },
        singleConfirm() { },
        pushDanger(item) {
            this.editCheck(this.getPushModel(item), item, "add");
        },
        editCheck(model, item, opType) {
            this.singleModel = model;
            this.$refs.setSingleDetail.show({
                model: this.singleModel,
                item: item,
                opType: opType,
            });
        },
        setCheckResult(item, checkResult) {
            if (!this.isEdit) return;

            item.checkResult =
                item.checkResult === checkResult ? "" : checkResult;
            this.tabsComputed();
            if (item.checkResult == "N") {
                if (item.checkDetails && item.checkDetails.length > 0) {
                } else {
                    this.editCheck(this.getPushModel(item), item, "add");
                }
            }
        },
        tabsComputed() {
            let array = [];
            if (
                this.tempModel &&
                this.tempModel.details &&
                this.tempModel.details.length > 0
            ) {
                this.tempModel.details.forEach((item, index) => {
                    let num = 0,
                        totalNum = 0;
                    item.grandsons.forEach((citem, cindex) => {
                        totalNum++;
                        if (citem.checkResult) num++;
                    });
                    array.push({
                        name: `${item.detailTitle}(${num}/${totalNum})`,
                    });
                });
            }
            console.log(this.tabs);
            this.tabs = array;
        },
        getCheckList() {
            let _this = this;
            let url = `${_this.control}/getTempCheckItem/${_this.taskCode}/${_this.tempCode}`;
            _this.common.get(url).then((res) => {
                _this.tempCheckDetail = res.data;
                _this.reSetModel();
                _this.tabsComputed();
            });
        },
        show(config) {
            this.showDialog = true;
            this.taskCode = config.taskCode;
            this.tempCode = config.tempCode;
            this.tempName = config.tempName;
            this.isEdit = config.isEdit;
            this.title = this.tempName + "检查";
            this.getTemp(this.tempCode);
            this.needHiddenCode = config.needHiddenCode;
        },

        tabChange(index) {
            this.tabIndex = index;
            this.goAnchor("#item_" + index);
        },

        //锚点跳转
        goAnchor(selector) {
            let sss = document.querySelector(selector);
            let top = this.getAbsCoordinates(document.querySelector(selector));
            let container = document.querySelector(".temp-container");
            this.scrollTop = container.scrollTop = top - 162;
        },
        getAbsCoordinates(e) {
            var pos = {
                top: 0,
                left: 0,
            };

            while (e && e.tagName != "BODY") {
                console.log("e=>", e);
                pos.left += e.offsetLeft;
                pos.top += e.offsetTop;
                e = e.offsetParent;
            }
            return pos.top;
        },

        getTemp(tempCode) {
            let url = `/support/DagerTpl/GetTemplateByCode?tCode=${tempCode}`;
            let _this = this;
            _this.common.get(url).then((res) => {
                if (res.code == 200) {
                    _this.tempModel = res.data;
                    _this.getCheckList();
                } else {
                    _this.showDialog = false;
                }
            });
        },
        reSetModel() {
            let _this = this;
            _this.tempModel.details.forEach((item) => {
                if (item.grandsons && item.grandsons.length > 0) {
                    item.grandsons.forEach((citem) => {
                        _this.$set(citem, "checkResult", "");
                        _this.$set(citem, "checkDetailY", {
                            templateItemName: citem.itemName,
                            templateItemCode: citem.itemFullNo,
                            hiddenDangerDesc: "",
                            attachs: "",
                            checkResult: "Y",
                            templateCode: _this.tempCode,
                            mainCode: _this.taskCode,
                            templateName: _this.tempName,
                            originType: 3,
                        });
                        _this.$set(citem, "checkDetailNA", {
                            templateItemName: citem.itemName,
                            templateItemCode: citem.itemFullNo,
                            hiddenDangerDesc: "",
                            attachs: "",
                            checkResult: "NA",
                            templateCode: _this.tempCode,
                            mainCode: _this.taskCode,
                            templateName: _this.tempName,
                            originType: 3,
                        });
                        let array = _this.tempCheckDetail.filter(
                            (x) => x.templateItemCode == citem.itemFullNo
                        );
                        if (array && array.length > 0) {
                            citem.checkResult = array[0].checkResult;
                            if (citem.checkResult === "Y") {
                                citem.checkDetailY = array[0];
                            }
                            if (citem.checkResult === "NA") {
                                citem.checkDetailNA = array[0];
                            }
                            _this.$set(citem, "checkDetails", []);
                            if (citem.checkResult === "N") {
                                array.forEach((x) => {
                                    _this.$set(x, "isOver", true);
                                    if (
                                        (!x.correctiveArea &&
                                            x.hiddenTypeCode == "2") ||
                                        !x.hiddenDangerDesc ||
                                        (!x.hiddenName && _this.isHost) ||
                                        !x.hiddenDangerTypeCode ||
                                        !x.correctiveType ||
                                        (!_this.isHost &&
                                            !x.appointCorrectiveName)
                                    ) {
                                        x.isOver = false;
                                    } else if (
                                        x.correctiveType == "1" &&
                                        (!x.correctiveAttachs ||
                                            !x.correctiveDesc)
                                    ) {
                                        x.isOver = false;
                                    }
                                });
                                citem.checkDetails = array;
                            }
                        } else {
                            _this.$set(citem, "checkDetails", []);
                        }
                    });
                }
            });
        },
        getPushModel(item) {
            return {
                templateItemName: item.itemName,
                templateItemCode: item.itemFullNo,
                hiddenDangerDesc: "",
                hiddenDangerTypeCode: "",
                correctiveAdvise: item.correctiveAdvise,
                hiddenName: "",
                hiddenCode: "",
                lgdType: "",
                hiddenTypeCode: "",
                hiddenTypeName: "",
                legalLiability: "",
                detailItemFullNo: "",
                templateCode: this.tempCode,
                mainCode: this.taskCode,
                templateName: this.tempName,
                detailNo: "",
                checkResult: "N",
                originType: 3,
                correctiveDeadline: "",
                correctiveType: 2,
                originalText: item.originalText,
                gistSource: item.gistSource,
                isOver: false,
                appointCorrectiveChnName: "",
                appointCorrectiveName: "",
            };
        },

        post() {
            let _this = this;
            let array = [];
            let message = "";
            let selector = "";
            _this.tempModel.details.forEach((item, index) => {
                item.grandsons.forEach((citem, cindex) => {
                    if (citem.checkResult == "N") {
                        if (citem.checkDetails && citem.checkDetails.length > 0)
                            citem.checkDetails.forEach((gitem, dindex) => {
                                gitem.templateItemCode = citem.itemFullNo;
                                gitem.detailNo = citem.itemNo;
                                array.push(gitem);
                            });
                    }
                    if (citem.checkResult == "Y") {
                        array.push(citem.checkDetailY);
                    }
                    if (citem.checkResult == "NA") {
                        array.push(citem.checkDetailNA);
                    }
                });
            });
            if (message) {
                _this.goAnchor(selector);
                _this.$refs.uToast.show({
                    title: message,
                    type: "error",
                });
                return false;
            }
            let url = `${_this.control}/tempCheckCommit/${_this.taskCode}/${_this.tempCode}`;
            _this.common.post(url, array).then((res) => {
                _this.showDialog = false;
                _this.$emit("saveAfter");
            });
        },
        resetHeight(outHeight) {
            let windowHeight = 0;
            var _that = this;
            uni.getSystemInfo({
                success: function (res) {
                    _that.height = res.windowHeight - outHeight;
                },
            });
        },
    },
};
</script>

<style lang="scss">
.host-danger-temp-check {
    .subs-container {
        border-top: 2rpx solid rgb(187, 187, 187);
        display: flex;
        flex: 4;
    }

    .subs-item {
        width: 25%;
        text-align: center;
        font-size: 28rpx;
        line-height: 68rpx;
        border: 1px solid #868383;
    }

    .u-tab-bar {
        display: none !important;
        width: 0rpx !important;
    }

    .temp-container {
        margin-top: 1rpx;
        // height: 1190rpx;
        // overflow: auto;

        .temp-item {
            .temp-item-title {
                background-color: rgb(220, 226, 236);
                font-weight: 700;
                font-size: 14px;
                color: rgb(16, 16, 16);
                border: 2rpx rgb(187, 187, 187) solid;
                padding: 18rpx;
            }

            .item-status {
                margin-top: -5px;
                padding: 2px 10px;
                color: #ffffff;
                background-color: rgb(215, 153, 17);
            }

            .temp-item-container {
                border: 1px solid rgb(187, 187, 187);
                padding: 10px;

                .item-cl-title {
                    font-size: 13px;
                }

                .push-danger {
                    font-size: 34rpx;
                    font-weight: 700;
                    padding: 10rpx 20rpx;
                    color: #165edc;
                }

                .check-item {
                    padding: 10px;
                    margin-top: 10px;
                    border: 1px dashed #c9bcbc;
                    background-color: #fff;

                    .check-item-content {
                        display: flex;
                    }

                    .check-item-title {
                        font-weight: 700;
                        font-size: 14px;
                        color: rgb(16, 16, 16);
                        font-style: normal;
                        letter-spacing: 0px;
                        line-height: 20px;
                        text-decoration: none;
                    }

                    .check-item-text {
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: -webkit-box;
                        -webkit-line-clamp: 3;
                        line-clamp: 3;
                        -webkit-box-orient: vertical;
                        height: 60px;
                        padding-left: 4px;
                    }

                    .check-item-text.N {
                        -webkit-line-clamp: 2;
                        line-clamp: 2;
                        height: 40px;
                    }

                    .check-item-text.corrective-area {
                        -webkit-line-clamp: 1;
                        line-clamp: 1;
                        height: 20px;
                    }
                }
            }

            .button-pannel {
                width: 100%;
                display: inline-flex;
                margin-top: 10px;
                margin-left: auto;
                margin-right: auto;
                -webkit-box-align: center;
                -webkit-align-items: center;
                align-items: center;
                -webkit-box-pack: center;
                -webkit-justify-content: center;
                justify-content: center;

                .button-item {
                    margin-left: 5px;
                    margin-right: 5px;
                    display: -webkit-box;
                    display: -webkit-flex;
                    display: flex;
                    -webkit-box-pack: center;
                    -webkit-justify-content: center;
                    justify-content: center;
                    border: 1px solid #dfe4ec;
                    width: 28%;
                    border-radius: 5px;
                    line-height: 30px;
                    background: #e8edf4ed;
                }

                .button-item.Y.checked {
                    border: 1rpx solid #19be6b;
                    background-color: #19be6b;
                    color: #ffffff;
                }

                .button-item.NA.checked {
                    border: 1rpx solid #ff976a;
                    background-color: #ff976a;
                    color: #ffffff;
                }

                .button-item.N.checked {
                    border: 1rpx solid red;
                    background-color: red;
                    color: #ffffff;
                }
            }
        }
    }
}
</style>
