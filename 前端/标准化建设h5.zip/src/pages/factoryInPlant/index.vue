<template>
  <view class="host-log-page-container">
    <view class="example-body">
      <host-header-enterprise></host-header-enterprise>

      <template v-for="(item, index) in list">
        <eagle-row-card
          :key="index"
          :hasLine="false"
          :hasImg="false"
          :hasButton="false"
          style="margin-top: 10px"
        >
          <view
            class="tools"
            style="color: #333333; font-size: 16px; margin-bottom: 10px"
          >
            {{ item.menuName }}
          </view>
          <u-line :hair-line="false" />
          <uni-grid :column="3" :show-border="false" :square="false">
            <uni-grid-item
              v-for="(ditem, dIndex) in item.childs"
              :index="dIndex"
              :key="dIndex"
            >
              <view class="grid-item-box" @click="goto(ditem.path)">
                <image
                  class="image"
                  :src="ditem.icon"
                  mode="aspectFill"
                  style="border-radius: 10px"
                />
                <text class="text">{{ ditem.menuName }}</text>
              </view>
            </uni-grid-item>
          </uni-grid>
        </eagle-row-card>
      </template>
    </view>
    <TabbarPlant></TabbarPlant>
    <u-toast ref="uToast" />
  </view>
</template>

<script>
import TabbarPlant from "@/pages/components/tabbar/tabbar-plant.vue";
import HostHeaderEnterprise from "./components/hostHeaderEnterprise.vue";
export default {
  components: {
    TabbarPlant, //底部导航栏
    HostHeaderEnterprise
  },
  data() {
    return {
      enterprise: {
        name: "",
        serviceName: "",
        projectContact: "",
        projectMobile: "",
        mainChnName: "",
        partChnName: ""
      },
      list: [],
      menuList: []
    };
  },

  beforeCreate() {},
  mounted() {},
  onShow() {
    this.setMenu();
  },
  methods: {
    goto(url) {
      this.base.navigateTo(url);
    },
    setMenu() {
      this.common
        .get("/system/phoneMenu/selectPhoneMenu?type=rent", {})
        .then((result) => {
          let hasHostDangerList = false;
          this.list = result.data;
          this.list.forEach((x) => {
            if (x.childs && x.childs.length > 0) {
              x.childs.forEach((item) => {
                if (item.menuId == 138) {
                  hasHostDangerList = true;
                }
              });
            }
          });
          uni.setStorageSync("hasHostDangerList", hasHostDangerList);
        });
    }
  }
};
</script>

<style scoped lang="scss">
.host-log-page-container {
  width: 100vw;
  height: calc(100vh);
  display: flex;
  flex-direction: column;
  // display: flex;
  // flex-direction: column;
  overflow: hidden;

  .example-body {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    overflow: auto;
  }

  // background: #fff;
  .host-header {
    width: 100%;
    height: 150rpx;
    background: #2979ff;
    display: flex;
    justify-content: center;
    padding: 0 20rpx;
    margin-bottom: 100rpx;

    .host-header-item {
      padding: 15rpx;
      box-sizing: border-box;
      width: 100%;
      height: 250rpx;
      background: #ffffff;
      border-radius: 14rpx;

      .company-name {
        font-size: 40rpx;
        font-weight: 600;
        padding: 8rpx;
        box-sizing: border-box;
      }

      .company-address,
      .company-opp {
        font-size: 24rpx;
        padding: 8rpx;
        box-sizing: border-box;
        color: #a5a5a5;

        .phone {
          color: #2979ff;
        }
      }

      .company-res {
        display: flex;
        font-size: 24rpx;
        padding: 8rpx;
        align-items: center;

        .company-res1 {
          display: flex;
          border: 1rpx solid #f99941;
          border-radius: 10rpx;
          margin-right: 50rpx;

          view {
            padding: 5rpx;
            box-sizing: border-box;
          }

          .left {
            color: #f99941;
            padding: 5rpx 10rpx;
            box-sizing: border-box;
          }

          .right {
            background-color: #f99941;
            color: #ffffff;
            padding: 5rpx 10rpx;
            box-sizing: border-box;
          }
        }

        .company-res2 {
          color: #d0b66c;
          margin-right: 50rpx;
        }

        .details {
          font-size: 30rpx;
          color: #2979ff;
        }
      }
    }
  }

  .host-content {
    width: 100%;
    padding: 0 20rpx;
    box-sizing: border-box;

    .tools {
      font-size: 32rpx;
      margin-bottom: 15rpx;
    }

    .img-list {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      justify-content: flex-start;
      margin-top: 25rpx;

      .img-list-item {
        width: 150rpx;
        height: 160rpx;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        margin: 0 10rpx;
        margin-bottom: 15rpx;

        .label {
          margin-top: 10rpx;
        }
      }
    }
  }

  ::deep.card-content {
    margin-bottom: 5px;
  }

  .example-body .module-block:last-child {
    border-bottom: none;
  }

  .home-title {
    line-height: 30px;
    font-weight: bold;
    // text-indent: 20px;
    margin: 0 20rpx;
    border-bottom: 1px solid #eee;
  }

  .grid-warp {
    display: flex;
  }

  .grid-warp-item {
    width: 25%;
  }

  .module-block {
    margin: 10px;
    // border-bottom: 1px solid #ddd;
    background: #fff;
    border-radius: 10rpx;
  }

  .image {
    width: 100rpx;
    height: 100rpx;
  }

  .text {
    font-size: 28rpx;
    margin-top: 10rpx;
    color: #333;
  }

  .example-body {
    /* #ifndef APP-NVUE */
    display: block;
    /* #endif */
  }

  .grid-dynamic-box {
    margin-bottom: 15px;
  }

  .grid-item-box {
    flex: 1;
    // position: relative;
    /* #ifndef APP-NVUE */
    display: flex;
    /* #endif */
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 15px 0px 0px 0px;
    position: relative;
  }

  .grid-dot {
    position: absolute;
    top: 5px;
    right: 15px;
  }

  .swiper {
    height: 420px;
  }

  .badge {
    width: 15rpx;
    height: 15rpx;
    border-radius: 50%;
    font-size: 12rpx;
    position: absolute;
    top: 0;
    right: 0;
  }
}
</style>
