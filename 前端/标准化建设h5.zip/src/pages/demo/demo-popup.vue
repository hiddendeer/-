<template>
    <view class="page">
        <u-button @click="showDialog">测试</u-button>
        <u-popup v-model="show" length="50%" mode="bottom">
            机构类的
            <eagle-img src="http://localhost:8067/Assets/Images/Custom/localhost/eagle-logo.png"></eagle-img>
        </u-popup>
    </view>
</template>

<script>
export default {
    data() {
        return {
            show: false,
        }
    },
    watch: {
    },
    created() {
    },
    mounted() {
    },
    methods: {
        showDialog() {
            this.show = !this.show;
        }
    }
}
</script>

<style>
@import "@/common/uni-nvue.css";
</style>
