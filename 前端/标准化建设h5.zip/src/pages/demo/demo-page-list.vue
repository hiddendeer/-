<template>
    <view>
        <eagle-page-list ref="eaglePageList" @initList="_initList" :pageSize="5" :param="queryParams" :controller="controller" :margin-bottom="99" @beforeLoad="beforeLoad">
            <view slot="search">
                <view class="search">
                    <eagle-search @search="search" v-model="searchValue" :clearabled="clearabled" :show-action="false" @clear="clear"></eagle-search>
                </view>
            </view>
            <view slot="list" class="list-wrap">
                <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                    <view class="uni-media-cell-content" @tap="choose(item)">
                        <view class="uni-media-list">
                            <image class="uni-media-list-img" :src="'http://localhost:8067/'+item.Attachs" show-error="true">
                                <view slot="error" style="font-size: 24rpx;">加载失败</view>
                            </image>
                            <view class="uni-media-list-body">
                                <view class="uni-media-list-text-top">{{item.HiddenDangerDesc}}</view>
                                <view class="uni-media-list-text-bottom">
                                    <text>{{item.CreateChnName}}</text>
                                    <text>{{utils.dateFormat(Date.now(),"yyyy-mm-dd")}}</text>
                                </view>
                            </view>
                            <u-checkbox v-model="item.checked" @click.stop.native="()=>{}">
                            </u-checkbox>
                        </view>
                        <view class="uni-media-foot">
                            <u-icon class="uni-media-foot-icon" name="edit-pen" label="编辑"></u-icon>
                            <u-icon class="uni-media-foot-icon" name="thumb-up" label="提交"></u-icon>
                            <u-icon class="uni-media-foot-icon" name="thumb-up" label="详情"></u-icon>
                        </view>
                    </view>
                </view>
            </view>
        </eagle-page-list>
        <!-- <u-button  type="primary"  @click="submit">提交</u-button> -->
        <!-- <view class="add-round" @click="add('chooseImage')">
			<u-icon name="plus" size="70" color="#fff"></u-icon>
		</view> -->
        <view class="view-botton">
            <u-button type="primary" @click="submit">生成报告</u-button>
        </view>
        <tabbar-danger-simple></tabbar-danger-simple>
    </view>

</template>
<script>
import tabbarDangerSimple from "@/pages/components/tabbar/tabbar-danger-simple.vue";
export default {
    components: {
        "tabbar-danger-simple": tabbarDangerSimple,
    },
    onShow() {
        this.search();
    },
    data() {
        return {
            searchValue: "",
            // dataUrl: "/DangerCheckSimple/GetPageData?dataType=List",
            controller: "DangerCheckSimple",
            // dataType:"List",
            data: [],
            clearabled: true,
            queryParams: {},
        };
    },
    onLoad() {
        uni.showLoading({
            title: "加载中",
            mask: true,
        });
    },
    onReady() {
        uni.hideLoading();
    },

    methods: {
        _initList(list) {
            this.data = list;
        },
        change() {
            this.search();
        },
        search() {
            this.queryParams.SearchValue = this.searchValue;
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        imgError(e) {},
        edit(item) {},
        add(e) {
            if (e === "requestPayment") {
                serve.requestPayment({
                    provider: "alipay",
                    orderInfo: "test12345678",
                });
                return;
            }
            serve[e]().then((res) => {
                if (e === "chooseImage") {
                    this.src = res.data.tempFilePaths[0];
                }
                this.callbackText = JSON.stringify(res);
            });
        },
        choose(item, e) {
            item.checked = !item.checked;
        },
        change(e) {},
    },
};
</script>

<style lang="scss">
.view-botton {
    padding: 3px;
}
</style>
