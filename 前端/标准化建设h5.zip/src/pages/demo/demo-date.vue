<template>
    <view class="page">
		<!-- <eagle-date type="range" v-model="dateRange" rangeSeparator="至" :start="start" ></eagle-date> -->
	<!-- <uni-datetime-picker v-model="range" type="daterange" start="2021-3-20" end="2021-5-20"
	    rangeSeparator="至" /> -->
     <!-- <text class="example-info">可以同时选择日期和时间的选择器</text>
        <uni-section :title="'日期用法：' + single" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker type="date" :value="single" start="2021-3-20" end="2021-6-20" @change="change" />
        </view>
        <uni-section :title="'时间戳用法：' + single" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker returnType="timestamp" @change="changeLog($event)" start="2021-3-20" end="2021-5-20"  />
        </view>
        <uni-section :title="'日期时间用法：' + datetimesingle" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker type="datetime" v-model="datetimesingle" @change="changeLog" />
        </view>
        <uni-section :title="'v-model用法：' + single" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker v-model="single" />
        </view>
        <uni-section :title="'插槽用法：' + single" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker v-model="single">我是一个插槽，点击我</uni-datetime-picker>
        </view>
        <uni-section :title="'无边框用法：' + single" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker v-model="single" :border="false" />
        </view>
        <uni-section :title="'disabled用法：' + single" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker v-model="single" disabled />
        </view>
        <uni-section :title="'日期范围用法：' + '[' + range + ']'" type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker v-model="range" type="daterange" start="2021-3-20" end="2021-5-20"
                rangeSeparator="至" />
        </view>
        <uni-section :title="'日期时间范围用法：' + '[' + datetimerange + ']' " type="line"></uni-section>
        <view class="example-body">
            <uni-datetime-picker v-model="datetimerange" type="datetimerange"
                start="2021-3-20 12:00:00" end="2021-6-20 20:00:00" rangeSeparator="至" />
        </view>
		
		 <picker mode="date" :value="date" fields="month" @change="bindDateChange">
		 	<text class="uni-calendar__header-text">{{ (nowDate.year||'') +' / '+( nowDate.month||'')}}</text>
		 </picker> -->
		 <picker class="date-picker" mode="date" fields="year" >
		 	<input class="uni-date__input" disabled="true"   />
		 </picker>
		 <eagle-year-month title="计划年份" fields="year" v-model="year"></eagle-year-month>
		 <!-- <eagle-year-month fields="year"></eagle-year-month> -->
    </view>
</template>

<script>
	import eagleYearMonth from "@/components/eagle-date/eagle-year-month";
    export default {
		components:{eagleYearMonth},
        data() {
            return {
				year:"",
				dateRange:[],
				start:'2021-12-18',
                time: '',
                single: '2021-04-3',
                datetimesingle: '2021-04-3',
                range: ['2021-03-8', '2021-4-20'],
                datetimerange: ['2021-03-20 20:10:10', '2021-05-10 10:10:10'],
				date:"",
				nowDate:{
					year:"",
					month:""
				}
            }
        },

        watch: {
            datetimesingle(newval) {
                console.log('单选:', this.datetimesingle);
            },
            range(newval) {
                console.log('范围选:', this.range);
            },
            datetimerange(newval) {
                console.log('范围选:', this.datetimerange);
            }
        },
        mounted() {
            setTimeout(() => {
                this.datetimesingle = '2021-5-1'
                this.single = '2021-5-1'
            },1000)
        },

        methods:{
            change(e) {
                this.single = e
                console.log('-change事件:', e);
            },
			bindTimeChange()
			{
				
			},
			/**
			 * 用户选择日期或时间更新 data
			 * @param {Object} e
			 */
			bindDateChange(e) {
				const val = e.detail.value
				this.nowDate.year = this.years[val[0]]
				this.nowDate.month = this.months[val[1]]
				// this.day = this.days[val[2]]
			},
        }
    }
</script>

<style>
    @import '@/common/uni-nvue.css';
</style>