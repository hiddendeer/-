<template>
    <view>
        <u-icon :name="iconUrl"></u-icon>
        <eagle-form :boolInitData="false" v-model="model" ref="eagleForm" :outHeight="100">
            <!-- <eagle-upload title="隐患图片" prop="Attachs" v-model="model.Attachs" />
           
            <eagle-date title="整改时间" type="date" v-model="model.Date" prop="Date" required></eagle-date>
            <eagle-date title="项目时间" type="daterange" :required="true" :startDate.sync="model.StartDate" :endDate.sync="model.EndDate" prop="DateRange"></eagle-date> -->
            <!-- 	<eagle-year-month title="计划月份" v-model="model.PlanMonth"></eagle-year-month>
			<eagle-year-month title="计划年份" fields="year" v-model="model.Year"></eagle-year-month> -->

            <!-- <eagle-choose-user :isMult="true" v-model="model.UserName" :names.sync="model.ChnName" title="整改人">
            </eagle-choose-user> -->
            <!-- <eagle-choose-user :isMult="true" v-model="model.CreateUserName" :names.sync="model.CreateChnName" title="创建人"></eagle-choose-user>
			<eagle-choose-company  @callBack="changeCompany" :names.sync="model.CompanyName" v-model="model.CompanyCode"
				title="检查企业"></eagle-choose-company>
			<eagle-choose-project @callBack="changeProject" :names.sync="model.ProjectName" v-model="model.ProjectCode"
				title="所属项目"></eagle-choose-project> -->
            <!-- <eagle-choose-input title="重大隐患" btnName="选择隐患" v-model="model.CheckType" @callBackChoosedData="callBackChoosedData"></eagle-choose-input> -->
            <eagle-radio-group title="检查类型" v-model="model.CheckType" :dataSource="paramList" :showCustomer="true"></eagle-radio-group>
            <u-button @click="test">测试</u-button>
            <u-button @click="submit">提交</u-button>
        </eagle-form>
        <!-- <view class="add-round" @click="add('chooseImage')">
			<u-icon name="plus" size="70" color="#fff"></u-icon>
		</view> -->
        <!-- <tabbar-danger-simple></tabbar-danger-simple> -->
    </view>
</template>
<script>
// import tabbarDangerSimple from "@/pages/components/tabbar/tabbar-danger-simple.vue";
// import eagleYearMonth from "@/components/eagle-date/eagle-year-month.vue";
// import eagleChooseProject from "@/pages/components/project/eagle-choose-project.vue";
export default {
    // components: {
    //     "tabbar-danger-simple": tabbarDangerSimple,
    //     "eagle-year-month": eagleYearMonth,
    //     "eagle-choose-project": eagleChooseProject,
    // },
    data() {
        return {
            searchValue: "",
            // dataUrl: "/DangerCheckSimple/GetPageData?dataType=List",
            // controller: "DangerCheckSimple",
            // dataType:"List",
            data: [],
            paramList: [
                {
                    id: "A",
                    name: "综合检查",
                },
                {
                    id: "B",
                    name: "专项检查",
                },
                {
                    id: "C",
                    name: "日常检查",
                },
                {
                    id: "D",
                    name: "综合检查",
                },
                {
                    id: "E",
                    name: "专项检查",
                },
                {
                    id: "F",
                    name: "日常检查",
                },
            ],
            clearabled: true,
            queryParams: {},
            model: {
                ID: 32,
                Attachs:
                    "https://guansafety.obs.cn-east-3.myhuaweicloud.com/72e7d4a7e78643af9a33289d2b82253b_bfd975de86f802a6b628594f45b9c9f5_20219_%E5%85%B3%E9%94%AE%E9%A3%8E%E9%99%A9%E7%82%B9%E5%88%86%E5%B8%83.png,https://guansafety.obs.cn-east-3.myhuaweicloud.com:443/72e7d4a7e78643af9a33289d2b82253b_bfd975de86f802a6b628594f45b9c9f5_20219_%E5%9F%BA%E7%A1%80%E7%AE%A1%E7%90%86%E9%9A%90%E6%82%A3%E5%88%86%E6%9E%90.png,https://guansafety.obs.cn-east-3.myhuaweicloud.com:443/72e7d4a7e78643af9a33289d2b82253b_bfd975de86f802a6b628594f45b9c9f5_20219_%E5%85%B3%E9%94%AE%E9%A3%8E%E9%99%A9%E7%82%B9%E5%88%86%E5%B8%83.png",
                HiddenDangerArea: "",
                Date: "2021-09-20",
                PlanMonth: "",
                UserName: "U21052600000056,U19120900000020,U19120900000008",
                ChnName: "b,朝乐木,陈秀明",
                CheckType: "Custom-自定义内容",
                CompanyName: "adfadsf",
                CompanyCode: "10567",
                ProjectCode: "PRJ2107000045",
                ProjectName: "XXX项目",
                StartDate: "2021-09-22",
                EndDate: "2021-09-24",
            },
            iconUrl: "@/static/list.png",
        };
    },
    created() {},
    methods: {
        test() {
            this.model.UserName = "U21052600000056";
            this.model.ChnName = "b";
        },
        _initList(list) {
            this.data = list;
        },
        change() {
            this.search();
        },
        search() {
            this.queryParams.SearchValue = this.searchValue;
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        imgError(e) {},
        edit(item) {},
        add(e) {
            if (e === "requestPayment") {
                serve.requestPayment({
                    provider: "alipay",
                    orderInfo: "test12345678",
                });
                return;
            }
            serve[e]().then((res) => {
                if (e === "chooseImage") {
                    this.src = res.data.tempFilePaths[0];
                }
                this.callbackText = JSON.stringify(res);
            });
        },
        submit() {
            var result = this.$refs.eagleForm.valid();
            if (result) {
                uni.showToast({
                    title: "保存成功",
                    icon: "success",
                });
            } else {
                uni.showToast({
                    title: "失败",
                    icon: "error",
                });
            }
        },
        changeCompany(codes, names) {
            this.model.CompanyName = names;
        },
        changeProject(codes, names) {
            this.model.ProjectName = names;
        },
        callBackChoosedData(data) {
            debugger;
        },
    },
};
</script>

<style lang="scss">
</style>
