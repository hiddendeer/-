<template>
	<view>
		<view class="uni-media-cell" v-for="(item, index) in list" :key="item.name">
			<view>
				<u-checkbox v-model="item.checked">
				</u-checkbox>
				<view @click="click(item)">
					{{item.name}}
				</view>
			</view>
		</view>
		<tabbar-danger-simple></tabbar-danger-simple>
	</view>
</template>
<script>
	import tabbarDangerSimple from "@/pages/components/tabbar/tabbar-danger-simple.vue";
	export default {
		components: {
			'tabbar-danger-simple': tabbarDangerSimple
		},
		data() {
			return {
				list: [{
					name: 'a',
					checked: undefined
				}, {
					name: 'b',
					checked: false
				}]
			}
		},
		created() {
		},
		methods: {
			click(item) {
				item.checked = !item.checked;
			}
		}
	}
</script>
<style lang="scss">
</style>
