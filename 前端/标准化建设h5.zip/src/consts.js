var consts = {
	constLabelPosition: "top",
	regexs: {
		tel: "", mobile: "", age: "", email: ""
	}
}
export default consts;
