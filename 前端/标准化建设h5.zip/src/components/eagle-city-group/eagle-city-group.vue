<template name="eagle-city-group">
    <!-- <view class="eagle-item eagle-city-group" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx;"> -->
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :prop="prop">
        <u-input :border="border" type="select" :select-open="pickerShow" v-model="defaultValue" :placeholder="placeholderVal" @click="pickerShow = true" :trim="false" :height="height"></u-input>
        <u-picker mode="region" v-model="pickerShow" @confirm="change"></u-picker>

    </u-form-item>
    <!-- </view>
    </view> -->
</template>

<script>
export default {
    name: "eagle-city-group",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        inputAlign: {
            type: String,
            default: "left",
        },
        placeholder: {
            type: String,
            default: "",
        },
        disabled: {
            type: Boolean,
            default: true,
        },
        placeholderStyle: {
            type: String,
            default: "color: #c0c4cc;",
        },
        // 输入框的自定义样式
        customStyle: {
            type: Object,
            default() {
                return {};
            },
        },
        // 如果 textarea 是在一个 position:fixed 的区域，需要显示指定属性 fixed 为 true
        fixed: {
            type: Boolean,
            default: false,
        },

        // input|textarea是否显示边框
        border: {
            type: Boolean,
            default: false,
        },
        // 输入框的边框颜色
        borderColor: {
            type: String,
            default: "#dcdfe6",
        },
        autoHeight: {
            type: Boolean,
            default: true,
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        // type=select时，旋转右侧的图标，标识当前处于打开还是关闭select的状态
        // open-打开，close-关闭
        selectOpen: {
            type: Boolean,
            default: false,
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: "20px",
        },
    },
    data() {
        return {
            pickerShow: false,
            placeholderVal: "",
            labelPositionVal: "",
            defaultValue: this.value,
            validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请选择" + (this.title ? this.title : "内容");
        // 监听u-form-item发出的错误事件，将输入框边框变红色
        this.$on("on-form-item-error", this.onFormItemError);
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },

    methods: {
        change(e) {
            this.defaultValue =
                e.province.label + "-" + e.city.label + "-" + e.area.label;
            this.$emit("input", this.defaultValue);
            this.$emit("change", this.defaultValue, e);
        },
        valid() {
            let result = true;
            var children = this.$refs.uForm.$children[0].$children;
            if (children.length > 0) {
                for (var i = 0; i < children.length; i++) {
                    if (children[i].$options.propsData.required) {
                        let el = children[i].$emit.apply(
                            children[i],
                            ["valid"].concat()
                        );
                        result = result ? el.valid() : result;
                    }
                }
            }
            return result;
        },
    },
};
</script>

<style>
</style>
