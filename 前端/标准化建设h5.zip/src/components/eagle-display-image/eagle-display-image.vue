<template name="eagle-display-image">
    <!-- <view class="eagle-item eagle-display-image" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx"> -->
    <u-form-item class="eagle-display-image" :label="title" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
        <eagle-img v-if="value" :src="value" :previewFullImage="previewFullImage"></eagle-img>
        <uni-view class="no-image" v-else style="display: inline-block;font-size: initial;">
            暂无图片
        </uni-view>
    </u-form-item>
    <!-- </view>
    </view> -->
</template>

<script>
export default {
    name: "eagle-display-image",
    components: {},
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        previewFullImage: {
            type: Boolean,
            default() {
                return true;
            },
        },
        required: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
        };
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {},
};
</script>

<style lang="scss" scoped>
.eagle-display-image {
    // padding: 20rpx 30rpx;
    /deep/.u-form-item--left__content__label {
        color: #303133 !important;
        font-size: 14px;
        font-weight: normal;
    }
    .no-image {
        width: 100px;
        height: 100px;
        overflow: hidden;
        margin: 5px;
        background: #f4f5f6;
        position: relative;
        border-radius: 5px;
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        line-height: 100px;
        text-align: center;
        color: #bbb;
        font-size: 26rpx;
    }
}
</style>
