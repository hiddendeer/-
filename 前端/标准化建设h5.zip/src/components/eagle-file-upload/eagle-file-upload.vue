<template name="eagle-file-upload">
    <!-- <view class="eagle-item eagle-file-upload" style="background: #FFFFFF;">
        <view :style="{padding:hasPadding?'0 30rpx':0}"> -->
    <u-form-item ref="uFormItem" class="eagle-file-upload" :label-position="labelPositionVal" :label="title" :required="required" :prop="prop" :label-align="labelAlign">
        <eagle-file :isNeedEdit="isNeedEdit" style="width: 100%;" ref="uUpload" :disabled="disabled" :file-list="defaultValue" :action="action" :show-tips="false" @on-success="onSuccess" @on-remove="onRemove" :before-upload="beforeUpload" :max-count="maxCount" :header="uploadHead" uploadText="选择文件" :fileList="fileList">
        </eagle-file>
    </u-form-item>
    <!-- </view>
    </view> -->
</template>


<script>
import eagleFile from "@/components/eagle-file-upload/eagle-file.vue";
export default {
    name: "eagle-file-upload",
    components: {
        eagleFile,
    },
    props: {
        value: {
            type: [String, Array],
            default: "",
        },
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        maxCount: {
            type: Number,
            default: 3,
        },

        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },

        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        disabled: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        // onlyShow: {
        //     type: [Boolean],
        //     default() {
        //         return false;
        //     },
        // },
        hasPadding: {
            type: Boolean,
            default: true,
        },
        labelAlign: {
            type: String,
            default: "left",
        },
		//拍照是否需要编辑图片 仅仅适用于App端交互
		isNeedEdit: {
		    type: Boolean,
		    default: false,
		},
    },
    data() {
        return {
            action: process.env.VUE_APP_BASE_API + "/file/upload",
            labelPositionVal: "",
            defaultValue: [],
            inputHeight: 70, // input的高度
            textareaHeight: 100, // textarea的高度
            validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
            focused: false, // 当前是否处于获得焦点的状态
            showPassword: false, // 是否预览密码
            lastValue: "", // 用于头条小程序，判断@input中，前后的值是否发生了变化，因为头条中文下，按下键没有输入内容，也会触发@input时间
            uploadHead: {
                Authorization: "",
            },
            placeholderVal: "",
            fileList: [],
        };
    },
    created() {
        this.uploadHead.Authorization = uni.getStorageSync("token");
        this.bindVal(this.value);
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请上传" + (this.title ? this.title : "文件");
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    watch: {
        value(newValue, oldValue) {
            if (newValue != oldValue) {
                this.bindVal(newValue);
                if (!newValue) {
                    this.$refs.uUpload.lists = [];
                }
            }
        },
    },
    methods: {
        bindVal(val) {
            if (val) {
                if (typeof val == "string") {
                    var arryFile = JSON.parse(val);
                    this.fileList = arryFile;
                } else {
                    this.fileList = val;
                }
            } else {
                this.fileList = [];
            }
        },

        beforeUpload() {},
        onRemove(index, lists) {
            this.fileList.splice(index, 1);
            this.inputFiles();
        },
        inputFiles() {
            this.$emit("input", this.fileList);
        },
        onSuccess(res, index, lists) {
            console.log("res", res);
            console.log("index", index);
            console.log("lists", lists);
            var data = res.data;
            this.fileList.push({
                name: data.attName,
                attCode: data.attCode,
                attExt: data.fileExt,
				filePath:data.filePath,
            });
            this.inputFiles();
            this.valid();
        },

        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.fileList || this.fileList.length <= 0) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>


<style lang="scss">
</style>
