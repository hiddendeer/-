<template>
	<view class="row-check">
		<view :class="{'checked':value}"></view>
	</view>
</template>

<script>
	export default {
		name: "eagle-row-check",
		props: {
			value: {
				type: Boolean,
				default () {
					return false
				}
			},
		},
		data() {

			return {

			};
		}
	}
</script>

<style lang="scss">
	.row-check {
		border: 1px solid #E2e2e2;
		border-radius: 10px;
		width: 22px;
		height: 22px;
		float: right;
		margin-right: 10px;
	}

	.checked {
		width: 16px;
		height: 16px;
		background: #5797e8;
		border: 1xp solid #5797e8;
		border-radius: 10px;
		margin: 2px;
	}
</style>
