<template>

    <!-- <view class="eagle-item eagle-choose-company" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx;"> -->
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
        <u-input :placeholder="placeholderVal" :value="names" @click="funDialogShow" :disabled="true"></u-input>
        <view v-show="codes" class="uni-date__icon-clear" @click.stop="clear">
            <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
        </view>
        <popup-company ref="popupWindow" :isMult="isMult" :names.sync="myNames" v-model="codes" @change="setValues"></popup-company>
    </u-form-item>
    <!-- </view>
    </view> -->
</template>

<script>
//import common from "@/common/common.js";
import popupCompany from "@/components/eagle-choose-company/popup-company.vue";
export default {
    name: "eagle-choose-company",
    components: {
        "popup-company": popupCompany,
    },
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
        placeholderVal: {
            type: String,
            default: "请选择企业",
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this.codes = nVal;
            }
        },
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        funDialogShow() {
            this.$refs.popupWindow.show();
        },
        setValues(codes, names) {
            this.$emit("update:names", names);
            this.$emit("input", codes);
            this.$emit("change", codes, names);
        },
        clear() {
            this.codes = "";
            this.$emit("update:names", "");
            this.$emit("input", "");
            this.$emit("change", "", "");
        },
        valid() {
            let _this = this;
            if (_this.required) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.uni-media-cell {
    margin: 0;
}

.view-botton {
    padding: 12rpx;
    width: 100%;
    bottom: 0px;
    position: fixed;
    background: #fff;
}

.choose-item {
    float: left;
    display: inline-block;
    line-height: 50rpx;
}

.choose-num {
    color: #2979ff;
}

.choose-btn {
    float: right;
    margin-left: 8rpx;
}

.choosed-view {
    margin-bottom: 50rpx;
}
</style>
