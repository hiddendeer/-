<template>
    <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
        <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);">
                <div class="uni-page-head-hd">
                    <div class="uni-page-head-btn" @click="close">
                        <i class="uni-btn-icon" style="color: rgb(0, 0, 0); font-size: 27px;"></i>
                    </div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                        选择企业
                    </div>
                </div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head>
        <view>
            <eagle-page-list :controller="controller" :dataType="dataType" :showCheck="true" @initList="_initList" :margin-bottom="50" v-show="!showDetail">
                <view slot="search">
                    <view class="search">
                        <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled" :show-action="false"></eagle-search>
                    </view>
                </view>
                <view slot="list" class="list-wrap">
                    <view class="uni-media-cell" v-for="(item, index) in data" :key="item.ID">
                        <view class="uni-media-cell-content" @tap="choose(item,true)">
                            <view class="uni-media-list">
                                <view class="uni-media-list-body">
                                    <view class="uni-media-list-text-top">{{item.CompanyName}}</view>
                                </view>
                                <u-checkbox v-model="item.checked" @click.stop.native="choose(item,false)" shape="circle">
                                </u-checkbox>
                            </view>
                        </view>
                    </view>
                </view>
            </eagle-page-list>
            <view class="choosed-view" v-show="showDetail">
                <view class="uni-media-cell" v-for="(item, index) in choosedData" :key="item.ID">
                    <view class="uni-media-cell-content">
                        <view class="uni-media-list">
                            <view class="uni-media-list-body" @tap="choose(item,false)">
                                {{item.CompanyName}}
                            </view>
                            <view class="uni-date__icon-clear" @click.stop="clear(item,index)">
                                <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
            <view class="view-choose-botton">
                <view class="choose-item" v-if="choosedNum>0">
                    <text>已选择:</text>
                    <text class="choose-num" @click="funShowDetail">{{choosedNum}}家企业</text>
                </view>
                <u-button class="choose-btn" type="primary" @click="submit">确定</u-button>
                <u-button v-if="isMult&&showDetail" class="choose-btn" type="primary" @click="cancelChoose">取消全选</u-button>
                <!-- <u-button v-if="isMult&&!showDetail" class="choose-btn" type="primary"  @click="chooseAll">
                    全选
                </u-button> -->
            </view>
        </view>
    </u-popup>
</template>

<script>
import common from "@/common/common.js";
export default {
    name: "popup-company",
    props: {
        value: {
            type: String,
            default() {
                return "";
            },
        },

        names: {
            type: String,
            default() {
                return "";
            },
        },
        isMult: {
            type: Boolean,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            controller: "UserCompany",
            dataType: "orgCompanyList",
            searchValue: "",
            data: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,

            choosedNum: 0,
            queryParams: {},
            detailHeigh: 0,
            chooseVal: "",
            showDialog: false,
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this._initChoosedData();
            }
        },
    },
    created() {
        let _that = this;
        this._initChoosedData();
    },
    // mounted() {
    //     this.search();
    // },
    methods: {
        show() {
            this.showDialog = true;
            this.search();
        },
        _initChoosedData() {
            if (this.chooseVal != this.value) {
                this.choosedData = [];
                if (this.value) {
                    let arry = this.value.split(",");
                    let arryName = this.names.split(",");
                    for (let i = 0; i < arry.length; i++) {
                        this.choosedData.push({
                            CompanyCode: arry[i],
                            CompanyName: arryName[i],
                        });
                    }
                    this.choosedNum = this.choosedData.length;
                }
            }
        },
        _initList(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (
                        this.choosedData[j].CompanyCode == list[i].CompanyCode
                    ) {
                        list[i].checked = true;
                    }
                }
            }
            this.data = list;
        },
        close() {
            this.showDialog = false;
        },
        search() {
            this.queryParams.SearchValue = this.searchValue;
            setTimeout(() => {
                this.$refs.eaglePageList.search();
            });
        },
        choose(obj, update) {
            let _this = this;
            if (update) {
                obj.checked = !obj.checked;
            }
            this.choosedData = [];
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (!_this.isMult) {
                    if (item.CompanyCode != obj.CompanyCode) {
                        item.checked = false;
                    }
                }
                if (item.checked) {
                    _this.choosedData.push(item);
                }
            }
            this.choosedNum = this.choosedData.length;
        },
        submit() {
            let codeArry = [];
            let nameArry = [];
            this.choosedData.forEach(function (item) {
                codeArry.push(item.CompanyCode);
                nameArry.push(item.CompanyName);
            });
            let codes = codeArry.join(",");
            let names = nameArry.join(",");
            this.chooseVal = names;
            this.$emit("input", codes);
            this.$emit("change", codes, names);
            this.$emit("update:names", names);
            this.close();
        },
        chooseAll() {
            let _this = this;
            this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = true;
                _this.choosedData.push(item);
            });
            this.choosedNum = this.choosedData.length;
        },
        cancelChoose() {
            this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = false;
            });
            this.choosedNum = 0;
            this.showDetail = false;
        },
        clear(obj, index) {
            this.choosedData.splice(index, 1);
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];

                if (item.CompanyCode == obj.CompanyCode) {
                    item.checked = false;
                }
            }
            this.choosedNum = this.choosedData.length;
            if (this.choosedNum == 0) {
                this.showDetail = false;
            }
        },
        funShowDetail() {
            this.showDetail = !this.showDetail;
        },
        checkChange(e) {},
    },
};
</script>

<style lang="scss">
.uni-media-cell {
    margin: 0;
}
.uni-media-list-text-top {
    line-height: 100rpx;
    text-indent: 20rpx;
}

// .view-choose-botton {
//     position: fixed;
//     width: 100%;
//     bottom: 0px;
//     padding-bottom: 15px;
//     padding-top: 10px;
//     background: #fff;
//     .choose-item {
//         float: left;
//         display: inline-block;
//         line-height: 40px;
//         margin-left: 10px;
//         font-size: 16px;
//     }

//     .choose-num {
//         color: #2979ff;
//     }

//     .choose-btn {
//         float: right;
//         // margin-left: 8rpx;
//         margin-right: 20rpx;
//     }
// }

.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}

.choosed-view {
    margin-bottom: 50rpx;
}
</style>
