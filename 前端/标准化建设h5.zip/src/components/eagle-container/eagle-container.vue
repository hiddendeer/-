<template name="eagle-container">
    <view class="eagle-container">
        <view class="container">
            <view class="eatle-form--title" v-if="$slots.title||title">
                <view class="title">
                    <slot name="title">
                    </slot>
                    {{title}}
                </view>
                <view class="eagele-form-subtitle" v-if="subTitle||$slots.otherSolot">
                    {{subTitle}}
                    <slot name="otherSolot"></slot>
                </view>
            </view>
            <view class="body" :class="{'both-side-padding':bothSide}">
                <slot>
                </slot>
            </view>
        </view>
    </view>
</template>

<script>
export default {
    name: "eagle-container",
    props: {
        title: {
            type: String,
            default: "",
        },
        bothSide: {
            type: Boolean,
            default: false,
        },
        subTitle: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {};
    },
};
</script>

<style lang="scss">
.eagle-container {
    margin: 20rpx;
    // background-color: $back-color;

    .container {
        border-radius: 10rpx;
        background-color: $color-white;
        padding-bottom: 20rpx;
        padding-top: 20rpx;
        .eatle-form--title {
            display: flex;
            justify-content: space-between;
            border-bottom: 1rpx solid $border-color-base;
            padding: 6rpx 0rpx 26rpx 0rpx;
            padding-left: 20rpx;
            .title {
                font-size: $font-lg;
                // font-weight: 600;
                color: $font-color-dark;
                display: inline-block;
            }
            .eagele-form-subtitle {
                color: $font-color-base;
                display: inline-block;
                padding-right: 10rpx;
            }
        }
    }
    .both-side-padding {
        padding-left: 20rpx;
        padding-right: 20rpx;
    }
}
</style>
