<template name="eagle-display-input">
    <view class="eagle-item eagle-display-input" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx;">
            <view class="form-item">
                <u-form-item :label="title" :label-position="labelPositionVal" :label-width="labelWidth" :required="required||onlyShowRequired">
                    <view style="width: 100%;font-size: 16px;" :class="{'eagle-display-input-view':border}" @click="goto()">
                        <slot />
                        <text>{{value}}</text>
                        <text v-if="value===''">无</text>
                    </view>
                    <view v-show="url" class="uni-date__icon-clear" @click="goto()">
                        <u-icon name="arrow-right" color="#8d8585"></u-icon>
                    </view>
                </u-form-item>
            </view>
        </view>
    </view>
</template>

<script>
export default {
    name: "eagle-display-input",
    components: {},
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        floatR: {
            type: Boolean,
            default() {
                return false;
            },
        },
        url: {
            type: String,
            default() {
                return "";
            },
        },
        border: {
            type: Boolean,
            default() {
                return false;
            },
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
        };
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        goto() {
            if (this.url) {
                this.base.navigateTo(url);
            }
        },
    },
};
</script>

<style scoped lang="scss">
.form-item {
    .header {
        width: 100%;
        height: 10rpx;
        background: #eeeeee;
    }
}

.eagle-display-input-view {
    height: 70rpx;
    line-height: 70rpx;
    padding: 0 20rpx;
    border: 1px solid #dcdfe6;
    box-sizing: border-box;
    border-radius: 8rpx;
}
</style>
