<template>
    <view class="row-block" :style="{ color: getColor() }">
        <slot></slot>
    </view>
</template>

<script>
export default {
    name: "eagle-girdrow-block",
    props: {
        type: String,
        default() {
            return "info";
        },
    },
    data() {
        return {};
    },
    methods: {
        getColor() {
            switch (this.type) {
                case "warn":
                    return "#E6A23C";
                case "success":
                    return "#67C23A";
                case "primary":
                    return "#0088ff";
                case "error":
                    return "#dd6161";
                default:
                    return "auto";
            }
        },
    },
};
</script>

<style lang="scss">
.row-block {
    display: inline-flex;
}
</style>
