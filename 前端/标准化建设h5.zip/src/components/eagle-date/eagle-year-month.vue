<template  name="eagle-year-month">
    <u-form-item :label-position="labelPositionVal" ref="uFormItem" :labelWidth="labelWidth" :label="title" :required="required" :prop="prop">
        <picker class="date-picker" mode="date" :fields="fields" @change="bindDateChange" :disabled="disabled" :start="start" :end="end">
            <input class="uni-date__input" disabled="true" :placeholder="placeholder" :value="date" />
        </picker>
        <view v-show="clearIcon && !disabled" class="uni-date__icon-clear" @click.stop="clear">
            <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
        </view>
    </u-form-item>
    <!-- </view> -->
</template>



<script>
export default {
    name: "eagle-year-month",
    props: {
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        value: {
            type: [String],
            default: "",
        },
        start: {
            type: String,
            default: "",
        },
        end: {
            type: String,
            default: "",
        },
        type: {
            type: String,
            default: "date",
        },
        placeholder: {
            type: String,
            default: "请选择日期",
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        clearIcon: {
            type: Boolean,
            default: true,
        },
        fields: {
            type: String,
            default: "month",
        },
    },
    data() {
        return {
            nowDate: {},
            date: "",
        };
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        this.date = this.value;
    },
    watch: {
        value(newValue, oldValue) {
            console.log("newValue,", newValue);
            console.log("oldValue,", oldValue);
            this.date = newValue;
        },
    },
    methods: {
        bindDateChange(e, item) {
            this.date = e.detail.value;
            this.$emit("input", this.date);
            this.$emit("change", this.date);
        },
        clear() {
            this.date = "";
            this.$emit("input", this.date);
            this.$emit("change", this.date);
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style  lang="scss">
.date-picker {
    width: 100%;
}
/deep/.uni-date__input {
    height: 80rpx;
    width: 100%;
    line-height: 80rpx;
    font-size: $font-base;
}
.input-placeholder {
    color: rgb(192, 196, 204);
}
.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}
</style>