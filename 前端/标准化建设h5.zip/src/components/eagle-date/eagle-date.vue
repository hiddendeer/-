<template name="eagle-date">

    <u-form-item class="eagle-item" :class="border?'eagle-item-boder':''" :label-position="labelPositionVal" ref="uFormItem" :label="title" :required="required" :prop="prop" :label-width="labelWidth">
        <uni-datetime-picker v-if="!disabled" :type="type" :clearIcon="clearIcon" v-model="defaultValue" :start="start" :end="end" @change="change" :border="false" :placeholder="placeholder" :startPlaceholder="startPlaceholder" :endPlaceholder="endPlaceholder" rangeSeparator="至" :disabled="disabled">
        </uni-datetime-picker>
        <view v-else style="font-size: 16px;">
            {{defaultValue|dateFormat}}
        </view>

        <template slot="bottmView">
            <view v-if="quickChoose" style="margin-top: 5px;">
                <span style="margin-left: 5px;margin-right: 5px; ">快捷选择：</span>
                <span v-for="(item, index) in fastKeyArr" :key="index" class="blueColor" style="margin-left: 5px;margin-right: 5px; " @click.stop="chooseDate(item)">
                    {{item.text}}
                </span>
            </view>
        </template>

    </u-form-item>

</template>

<script>
export default {
    name: "eagle-date",
    props: {
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: [Number, String],
            default: "120",
        },
        value: {
            type: [String, Number, Array, Date],
            default: "",
        },
        start: {
            type: String,
            default: "",
        },
        end: {
            type: String,
            default: "",
        },
        type: {
            type: String,
            default: "date",
        },
        placeholder: {
            type: String,
            default: "请选择日期",
        },
        startPlaceholder: {
            type: String,
            default: "开始日期",
        },
        endPlaceholder: {
            type: String,
            default: "结束日期",
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        startDate: {
            type: [String, Date,Number],
            default: "",
        },
        endDate: {
            type: [String, Date,Number],
            default: "",
        },
        formate: {
            type: String,
            default: "yyyy-mm-dd",
        },
        rangeSeparator: {
            type: String,
            default: "~",
        },

        //下面是否有线
        border: {
            type: Boolean,
            default: true,
        },
        // 输入框的边框颜色
        borderColor: {
            type: String,
            default: "#dcdfe6",
        },

        //快捷选择
        quickChoose: {
            type: Boolean,
            default: false,
        },
        clearIcon: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            defaultValue: this.value,
            inputStartDate: this.startDate,
            inputEndDate: this.endDate,
            fastKeyArr: [],

            shortcuts: [
                {
                    text: "今天",
                    key: "T",
                    value: new Date(),
                },
                {
                    text: "昨天",
                    key: "Y",
                    // value: () => {
                    //     return  add(new Date(), -1, "day");
                    // },
                },
                {
                    text: "一周前",
                    key: "M-R7",
                    // value: () => {
                    //     return add(new Date(), -7, "day");
                    // },
                },
                {
                    text: "一周",
                    key: "W-1",
                    // value: () => {
                    //     return add(new Date(), 7, "day");
                    // },
                },
                {
                    text: "两周",
                    key: "W-2",
                    // value: () => {
                    //     return add(new Date(), 14, "day");
                    // },
                },
                {
                    text: "一个月",
                    key: "M-1",
                    // value: () => {
                    //     return add(new Date(), 1, "month");
                    // },
                },
                {
                    text: "两个月",
                    key: "M-2",
                    // value: () => {
                    //     return add(new Date(), 2, "month");
                    // },
                },
            ],
        };
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        if (
            this.type == "daterange" &&
            this.inputEndDate &&
            this.inputStartDate
        ) {
            this.defaultValue = [];
            this.defaultValue.push(this.inputStartDate);
            this.defaultValue.push(this.inputEndDate);
        }

        this.fastKeyArr = this.getFastKeyData();
    },
    watch: {
        value(newValue, oldValue) {
            if (newValue != oldValue && this.value != this.defaultValue) {
                this._initVal();
            }
        },
        startDate(newValue, oldValue) {
            if (newValue != oldValue && this.startDate != this.inputStartDate) {
                this._initVal();
            }
        },
        endDate(newValue, oldValue) {
            if (newValue != oldValue && this.endDate != this.inputEndDate) {
                this._initVal();
            }
        },
    },
    methods: {
        _initVal() {
            if (this.type == "daterange") {
                if (this.startDate) {
                    this.defaultValue = [];
                    this.defaultValue.push(this.startDate);
                    this.defaultValue.push(this.endDate);
                } else {
                    this.defaultValue = undefined;
                }
            } else {
                this.defaultValue = this.value;
            }
        },
        change(e) {
            this.$emit("input", e);

            this.defaultValue = e;
            if (this.type == "daterange" || this.type == "range") {
                this.inputStartDate = e[0];
                this.inputEndDate = e[1];
                this.$emit("update:startDate", e[0]);
                this.$emit("update:endDate", e[1]);
            }
            this.$emit("change", e);
            this.valid();
        },

        getFastKeyData() {
            let array = [];

            array = ["W-1", "W-2", "M-1", "M-2"];

            return this.shortcuts.filter((item) => {
                if (array.indexOf(item.key) >= 0) {
                    return item;
                }
            });
        },

        chooseDate(item) {
            let dateTime = new Date();
            switch (item.key) {
                case "W-1":
                    dateTime = dateTime.setDate(dateTime.getDate() + 7);
                    break;
                case "W-2":
                    dateTime = dateTime.setDate(dateTime.getDate() + 14);
                    break;

                case "M-1":
                    dateTime = dateTime.setMonth(dateTime.getMonth() + 1);
                    // dateTime.setDate(dateTime.getMonth()+1);
                    break;
                case "M-2":
                    dateTime = dateTime.setMonth(dateTime.getMonth() + 2);
                    break;
            }
            dateTime = new Date(dateTime);

            this.defaultValue = this.common.dateTimeFormatYYMMDD(dateTime);

            this.$emit("input", this.defaultValue);
            this.$emit("change", this.defaultValue);
        },

        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (_this.type == "daterange" || _this.type == "range") {
                    let msg = "请选择" + _this.title;
                    if (!_this.defaultValue || !_this.defaultValue[0]) {
                        _this.$refs.uFormItem.validateState = "error";
                        _this.$refs.uFormItem.validateMessage = msg;
                        return false;
                    } else {
                        _this.$refs.uFormItem.validateState = "";
                    }
                } else {
                    if (!_this.defaultValue) {
                        _this.$refs.uFormItem.validateState = "error";
                        _this.$refs.uFormItem.validateMessage =
                            _this.placeholder;
                        return false;
                    } else if (
                        _this.$refs.uFormItem.validateMessage ===
                        _this.placeholder
                    ) {
                        _this.$refs.uFormItem.validateState = "";
                    }
                }
            }
            return true;
        },
    },
};
</script>


<style lang="scss">
/deep/.uni-calendar--fixed {
    z-index: 999;
}

/deep/.uni-date {
    width: 100%;
}

/deep/.input-placeholder {
    color: rgb(192, 196, 204);
}
/deep/.uni-date-x {
    color: $u-main-color;
    background-color: $edit-bg-color;
    padding: 0px;
}
/deep/.uni-date__x-input {
    padding: 0px;
}

.blueColor {
    color: $font-color-spec;
}

/deep/.t-c {
    text-align: left;
}
/deep/.uni-date-x view {
    width: 130px;
}
/deep/.uni-date__x-input {
    line-height: 38px;
    height: 38px;
}
// /deep/.uniui-calendar:before {
//     content: "";
// }
</style>
