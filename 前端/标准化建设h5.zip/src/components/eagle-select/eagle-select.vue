<template name="eagle-select">

    <u-form-item :label-position="labelPosition" ref="uFormItem" :label="title" :prop="prop" :required="required" :label-width="labelWidth">
        <u-input style="padding:0 10rpx;" :border="border" type="select" v-model="textValue" :select-open="actionSheetShow" :placeholder="placeholderVal" @click="actionSheetShow = true" :trim="false" :height="height">
        </u-input>
        <view class="selectBottom">
            <u-select v-model="actionSheetShow" :list="actionSheetList" @confirm='change' :z-index=9999999999999></u-select>
        </view>
    </u-form-item>
</template>

<script>
export default {
    name: "eagle-select",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        text: {
            type: [String, Number],
            default: "",
        },
        idField: {
            type: [String],
            default: "id",
        },
        textField: {
            type: [String],
            default: "name",
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        inputAlign: {
            type: String,
            default: "left",
        },
        placeholder: {
            type: String,
            default: "",
        },
        disabled: {
            type: Boolean,
            default: true,
        },
        placeholderStyle: {
            type: String,
            default: "color: #c0c4cc;",
        },
        // 输入框的自定义样式
        customStyle: {
            type: Object,
            default() {
                return {};
            },
        },
        // 如果 textarea 是在一个 position:fixed 的区域，需要显示指定属性 fixed 为 true
        fixed: {
            type: Boolean,
            default: false,
        },

        // input|textarea是否显示边框
        border: {
            type: Boolean,
            default: false,
        },
        // 输入框的边框颜色
        borderColor: {
            type: String,
            default: "#dcdfe6",
        },
        autoHeight: {
            type: Boolean,
            default: true,
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        // type=select时，旋转右侧的图标，标识当前处于打开还是关闭select的状态
        // open-打开，close-关闭
        selectOpen: {
            type: Boolean,
            default: false,
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: 76,
        },
    },
    data() {
        return {
            actionSheetShow: false,
            actionSheetList: [],
            placeholderVal: "",
            labelPositionVal: "",
            defaultValue: this.value,
            textValue: this.text,
        };
    },
    created() {
        let _this = this;
        _this.placeholderVal = _this.placeholder
            ? _this.placeholder
            : "请选择" + (_this.title ? _this.title : "内容");
        // 监听u-form-item发出的错误事件，将输入框边框变红色
        _this.labelPositionVal = _this.labelPosition
            ? _this.labelPosition
            : _this.consts.constLabelPosition;
        _this.bind();
    },
    watch: {
        value(nVal, oVal) {
            let _this = this;
            if (_this.defaultValue != nVal) {
                _this.defaultValue = nVal;
                _this.textValue = nVal;
                _this.dataSource.forEach((item) => {
                    if (_this.defaultValue === item[_this.idField]) {
                        _this.textValue = item[_this.textField];
                    }
                });
            }
        },
        dataSource(nval, oval) {
            this.bind();
        },
    },
    methods: {
        bind() {
            let _this = this;
            _this.actionSheetList = [];
            _this.dataSource.forEach((item) => {
                _this.actionSheetList.push({
                    // ID: item[_this.idField],
                    // text: item[_this.textField]
                    value: item[_this.idField],
                    label: item[_this.textField],
                });
                if (_this.defaultValue === item[_this.idField]) {
                    _this.textValue = item[_this.textField];
                }
            });
        },
        change(index) {
            let _this = this;
            // var selectObj = _this.dataSource[index]
            // _this.defaultValue = selectObj[_this.idField]
            // _this.textValue = selectObj[_this.textField]
            var selectObj = index[0];
            _this.defaultValue = selectObj["value"];
            _this.textValue = selectObj["label"];
            _this.$emit("change", _this.defaultValue, selectObj);
            _this.$emit("input", _this.defaultValue);
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.selectBottom {
    // background: red;
    position: fixed;
    bottom: 0;
    z-index: 9999999999;
}
</style>