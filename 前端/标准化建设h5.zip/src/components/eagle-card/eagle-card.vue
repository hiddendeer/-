<template name="eagle-card">
    <view class="eagle-card">
        <view v-if="$slots.title||title" class="title">
            <slot name="title">
            </slot>
            <view v-if="title"> {{title}}</view>
        </view>
        <view class="body">
            <slot>
            </slot>
        </view>
    </view>
</template>

<script> 
export default {
    name: "eagle-card",
    props: {
        title: {
            type: String,
            default: "",
        },
    },
    data() {
        return {};
    },
};
</script>

<style lang="scss">
.eagle-card {
    margin-top: 10px;
    background-color: $color-white;
    .title {
        padding: 26rpx;
        font-size: $font-base;
        font-weight: 800;
        color: $font-color-dark;
        border-bottom: 1px solid $border-color-base;
    }
}
</style>
