<template name="eagle-choose-user">
    <view>
        <eagle-choose-input :isUseEnterprise="false" keyWordName="chnName" :placeholder="placeholder" :names.sync="myNames" v-model="defaultValue" :title="title" :required="required" :onlyShowRequired="onlyShowRequired" :btnName="btnName" :isMult="isMult" :prop="prop" :label-width="labelWidth" dataType="list" :headTitle="'选择'+title" idField="userName" textField="chnName" queryUrl="support/CommonAQXApi/getUserUser" @callBackChoosedData="callBackChoosedData">
            <template v-slot:popupBody='scope'>
                <view>
                    <view class="c333"> {{scope.item.chnName}}</view>
                    <view> {{scope.item.orgFullName}}</view>
                </view>
            </template>
            <view v-if="names">
                {{names}}
            </view>
        </eagle-choose-input>
    </view>

</template>

<script>
export default {
    name: "eagle-choose-user",
    components: {},
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "人员";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
        btnName: {
            type: String,
            default() {
                return "选择人员";
            },
        },

        prop: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            defaultValue: "",
            myNames: this.names,
            placeholder: "",
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (this.defaultValue != nVal) {
                this.defaultValue = nVal;
            }
        },
    },
    created() {
        this.placeholder = "请选择" + (this.title || "");
    },
    methods: {
        callBackChoosedData(data) {
            let codeArry = [];
            let nameArry = [];
            data.forEach(function (item) {
                codeArry.push(item.userName);
                nameArry.push(item.chnName);
            });
            let codes = codeArry.join(",");
            let names = nameArry.join(",");
            this.$emit("input", codes);
            this.$emit("update:names", names);
            this.$emit("callBackChoosedData", data, codes, names);
        },
    },
};
</script>

<style lang="scss">
</style>
