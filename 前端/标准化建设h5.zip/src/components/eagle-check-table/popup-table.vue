<template>
    <u-popup v-model="show" mode="right" width="100%" length="100%">
        <eagle-industry-select :show='industrySelectShow' @industryInformation="industryInformation"
            @close='industrySelectclose'></eagle-industry-select>
        <eagle-head @close="close"> 选择检查表</eagle-head>
        <view>
            <view style="margin-left: 20rpx; margin-top:20rpx;margin-bottom: 20rpx;" v-for="(item, index) in TagList">
                <u-tag :text="item.name" size="mini" closeable @close="tagClose(item, index)"></u-tag>
            </view>

            <view class="u-tabs-box ">
                <u-tabs-swiper activeColor="#2979ff" name="Name" :showBar="false" ref="tabs" :list="tabList"
                    :bar-width="100" :current="tabIndex" @change="onTabChanged" :is-scroll="false">
                </u-tabs-swiper>

                <!-- 	<view class="btn-search" @click.stop="searchWindow">
					<u-icon name="search"></u-icon>
				</view> -->
            </view>
            <swiper class="swiper-box" :class="tabIndex === 0 ? 'swiper-box1' : 'swiper-box1'" :current="tabIndex"
                @transition="transition" @animationfinish="animationfinish">
                <swiper-item class="swiper-item" v-if="isType">
                    <u-form :model="form" ref="uForm" :error-type="['toast']" :border-bottom="false"
                        label-position="left">
                        <u-form-item prop="area" :border-bottom="false" style="background: aliceblue;">
                            <text style="margin-left: 20px;" @click="btnClick0('company')">公司检查表目录:</text>
                            <text style="margin-left: 20px;" @click="btnClick0('company')">{{ opName0 }}</text>
                            <u-button style="margin-right: 10px;" type="primary" size="mini" @click="reset0()">重置
                            </u-button>
                            <selectAddress ref='selectAddress0' @selectAddress="successSelectAddress0"
                                @ShowMask="ShowMask0"></selectAddress>
                        </u-form-item>
                    </u-form>
                    <eagle-page-list :boolInitData="false" ref="eaglePageList0" :dataUrl="dataUrl" :showCheck="true"
                        @initList="_initList0" v-show="!showDetail" :controller="controller" dataType="list"
                        :marginBottom='180'>
                        <view slot="search" class="search-slot">
                            <view class="search">
                                <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled"
                                    :show-action="false" @clear="search"></eagle-search>
                            </view>
                        </view>
                        <view slot="list" class="list-wrap">
                            <view class="uni-media-cell" v-for="(item, index) in data0" :key="index">
                                <view class="uni-media-cell-content" @tap="choose0(item, true)">
                                    <view class="uni-media-list">
                                        <view class="uni-media-list-body">
                                            <view class="uni-media-list-text-top">{{ item.title }}</view>
                                        </view>
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose0(item, false)"
                                            shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-page-list>
                </swiper-item>

                <swiper-item class="swiper-item">
                    <u-form :model="form" ref="uForm" :error-type="['toast']" :border-bottom="false"
                        label-position="left">
                        <u-form-item prop="area" :border-bottom="false" style="background: aliceblue;">
                            <text style="margin-left: 20px;" @click="btnClick('company')">{{ btnClickName }}:</text>
                            <text style="margin-left: 20px;" @click="btnClick('company')">{{ opName1 }}</text>
                            <u-button style="margin-right: 10px;" type="primary" size="mini" @click="reset()">重置
                            </u-button>
                            <selectAddress ref='selectAddress' @selectAddress="successSelectAddress"
                                @ShowMask="ShowMask"></selectAddress>
                        </u-form-item>
                    </u-form>
                    <eagle-page-list :boolInitData="false" :isUseEnterprise="false" ref="eaglePageList"
                        :dataUrl="dataUrl" :showCheck="true" @initList="_initList" v-show="!showDetail"
                        :controller="controller" dataType="list" :marginBottom='180'>
                        <view slot="search" class="search-slot">
                            <view class="search">
                                <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled"
                                    :show-action="false" @clear="search"></eagle-search>
                            </view>
                        </view>
                        <view slot="list" class="list-wrap">
                            <view class="uni-media-cell" v-for="(item, index) in data" :key="index">
                                <view class="uni-media-cell-content" @tap="choose(item, true)">
                                    <view class="uni-media-list">
                                        <view class="uni-media-list-body">
                                            <view class="uni-media-list-text-top">{{ item.title }}</view>
                                        </view>
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose(item, false)"
                                            shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-page-list>
                </swiper-item>
                <swiper-item class="swiper-item">
                    <u-form :model="form" ref="uForm" :error-type="['toast']" :border-bottom="false"
                        label-position="left">
                        <u-form-item prop="area" :border-bottom="false" style="background: aliceblue;">
                            <text style="margin-left: 20px;" @click="btnClick2('public')">公共检查表目录:</text>
                            <text style="margin-left: 20px;" @click="btnClick2('public')">{{ opName2 }}</text>
                            <!-- <u-input style="margin-left: 20px;" v-model="opName2" placeholder="请选择公共检查表目录" @focus="btnClick2('public')" /> -->
                            <u-button type="primary" size="mini" style="margin-right: 10px;" @click="reset2()">重置
                            </u-button>
                            <selectAddress ref='selectAddress2' @selectAddress="successSelectAddress2"
                                @ShowMask="ShowMask2"></selectAddress>
                        </u-form-item>
                    </u-form>
                    <eagle-page-list :boolInitData="false" :isUseEnterprise="false" ref="eaglePageList2"
                        :dataUrl="dataUrl" :showCheck="true" @initList="_initList2" v-show="!showDetail"
                        :controller="controller" dataType="public" :marginBottom='180'>
                        <view slot="search" class="search-slot">
                            <view class="search">
                                <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled"
                                    :show-action="false" @clear="search"></eagle-search>
                            </view>
                        </view>
                        <view slot="list" class="list-wrap">
                            <view class="uni-media-cell" v-for="(item, index) in data2" :key="index">
                                <view class="uni-media-cell-content" @tap="choose2(item, true)">
                                    <view class="uni-media-list">
                                        <view class="uni-media-list-body">
                                            <view class="uni-media-list-text-top">{{ item.title }}</view>
                                        </view>
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose2(item, false)"
                                            shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-page-list>
                </swiper-item>
                <swiper-item class="swiper-item">
                    <eagle-page-list :boolInitData="false" :isUseEnterprise="false" ref="eaglePageList3"
                        :dataUrl="dataUrl" :showCheck="true" @initList="_initList3" v-show="!showDetail"
                        :controller="controller" dataType="Mylist" :marginBottom='120'>
                        <view slot="search" class="search-slot">
                            <view class="search">
                                <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled"
                                    :show-action="false" @clear="search"></eagle-search>
                            </view>
                        </view>
                        <view slot="list" class="list-wrap">
                            <view class="uni-media-cell" v-for="(item, index) in data3" :key="index">
                                <view class="uni-media-cell-content" @tap="choose3(item, true)">
                                    <view class="uni-media-list">
                                        <view class="uni-media-list-body">
                                            <view class="uni-media-list-text-top">{{ item.title }}</view>
                                        </view>
                                        <u-checkbox v-model="item.checked" @click.stop.native="choose3(item, false)"
                                            shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </eagle-page-list>
                </swiper-item>
            </swiper>
            <view v-if="isShowMask" class="bottom-btn">
                <u-button style="margin: 0;" type="success" @click="submit">确定</u-button>
            </view>
        </view>
        <popup-industry ref="popupIndustry"></popup-industry>
        </view>
    </u-popup>

</template>

<script>
import popupIndustry from '@/components/eagle-check-table/popup-industry.vue'
import common from '@/common/common.js'
import selectAddress0 from '@/components/yixuan-selectAddress/yixuan-selectAddress.vue'
import selectAddress from '@/components/yixuan-selectAddress/yixuan-selectAddress.vue'
import selectAddress2 from '@/components/yixuan-selectAddress/yixuan-selectAddress.vue'
export default {
    name: 'popup-table',
    components: {
        selectAddress0,
        selectAddress,
        selectAddress2,
        'popup-industry': popupIndustry
    },
    props: {
        value: {
            type: String,
            default() {
                return ''
            }
        },
        names: {
            type: String,
            default() {
                return ''
            }
        },
        show: {
            type: Boolean,
            default() {
                return false
            }
        },
        isMult: {
            type: Boolean,
            default() {
                return true
            }
        },
        TagList: {
            type: Array,
            default() {
                return []
            }
        },
    },
    data() {
        return {
            industrySelectShow: false,
            opName0: '全部',
            opCode0: '',
            opName1: '全部',
            opCode1: '',
            opName2: '全部',
            opCode2: '',
            profession: 'IAPT00001',
            professionName: '机械行业',
            form: { area: '全国', },

            rules: {
                area: [
                    {
                        required: true,
                        message: '请选择所在地区',
                        trigger: ['change', 'blur'],
                    }
                ],
            },
            searchValue2: {
                years: '',
                name: '',
                searchResults: ''
            },
            params2: {
                targetType: [],
                targetCycleType: [],
                year: []
            },
            dialogShowIndystry: false,
            show2: false,
            close1: true,
            tabIndex: 0,
            tabList: [{ name: '公司检查表' }, { name: '公共检查表' }, { name: '我的检查表' }],
            dataUrl: '/support/DagerTpl/getPageListData',
            searchValue: '',
            data0: [],
            data: [],
            data2: [],
            data3: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,
            // dialogShow:this.show,
            choosedNum: 1000,
            queryParams: {},
            detailHeigh: 0,
            chooseVal: '',
            isShowMask: true,
            controller: 'support/DagerTpl',
            btnClickName: '公司检查表目录',
            isType: false,
            companyCode: "",
        }
    },
    computed: {},
    watch: {
        // TagList(nVal, oVal) {
        // 	for (let i = 0; i < nVal.length; i++) {
        // 		this.tagClose(nVal[i],i);
        // 	}
        // }
    },
    created() {
        let enterpriseCode = this.$route.query.enterpriseCode;
        if (enterpriseCode) {
            this.companyCode = enterpriseCode
            // this.isType = true
            // this.tabList = [{ name: '公司检查表' }, { name: '机构检查表' }, { name: '公共检查表' }, { name: '我的检查表' }]
            this.tabList = [{ name: '机构检查表' }, { name: '公共检查表' }, { name: '我的检查表' }]
            this.btnClickName = '机构检查表目录'
        }

    },
    mounted() {

    },
    watch: {
        show: {
            handler(val) {
                if (val) {
                    this.search()
                }
            },
            immediate: true
        }
    },
    methods: {
        ShowMask0(bool) {
            this.isShowMask = true
        },
        ShowMask(bool) {
            this.isShowMask = true
        },
        ShowMask2(bool) {
            this.isShowMask = true
        },
        industrySelectclose(bool) {
            this.industrySelectShow = bool
        },
        industryInformation(res) {
            // let reg=new RegExp(',','g')//g代表全部
            // this.profession = res.industryIap.replace(reg,';');
            // this.professionName = res.industryName.replace(reg,';');
            this.profession = res.industryIap
            this.professionName = res.industryName

            this.industrySelectShow = false
            console.log('http=' + this.professionName, '===' + this.profession)
            this.search()
        },
        reset0() {
            this.opName0 = '全部'
            this.opCode0 = ''
            this.search();
            this.$refs.selectAddress0.goinfo()
        },
        reset() {
            this.opName1 = '全部'
            this.opCode1 = ''
            this.search();
            this.$refs.selectAddress.goinfo()
        },
        reset2() {
            this.opName2 = '全部'
            this.opCode2 = '',
                this.search();
            this.$refs.selectAddress2.goinfo()
        },
        btnClick0(type) {
            console.log('=AA=')
            this.isShowMask = false
            this.$refs.selectAddress0.show(type, this.companyCode)
        },
        btnClick(type) {
            console.log('=AA=')
            this.isShowMask = false
            this.$refs.selectAddress.show(type)
        },
        btnClick2(type) {
            console.log('=BB=')
            this.isShowMask = false

            this.$refs.selectAddress2.show(type)
        },
        successSelectAddress0(type, address, code) { //选择成功回调
            if (address && code) {
                this.opName0 = address
                this.opCode0 = code
                this.search()
            }
        },
        successSelectAddress(type, address, code) { //选择成功回调
            if (address && code) {
                this.opName1 = address
                this.opCode1 = code
                this.search()
            }
        },
        successSelectAddress2(type, address, code) {
            if (address && code) {
                this.opName2 = address
                this.opCode2 = code
                console.log(address, '=CC=' + code)
                this.search()
            }
        },
        funDialogShowIndystry() {
            // this.$refs.popupIndustry.show();
            this.industrySelectShow = true
        },
        change() {
            this.show2 = true
        },

        confirm(e) {
            // 省市区拼接
            if (e.province.label == e.city.label) {
                this.form.area = e.province.label
            } else {
                if (e.city.label == '市辖区') {
                    this.form.area = e.province.label + '/' + e.area.label
                } else {
                    this.form.area = e.province.label + '/' + e.city.label
                    //如果不需要地区    直接不取地区的值
                    // +"/"+ e.area.label
                }
            }
            this.search()
        },

        tagClose(obj, index) {
            for (let i = 0; i < this.data.length; i++) {

                let item = this.data[i]
                if (obj.id == item.tCode) {
                    item.checked = false
                }
            }
            for (let i = 0; i < this.data2.length; i++) {
                let item = this.data2[i]
                if (obj.id == item.tCode) {
                    item.checked = false
                }
            }
            for (let i = 0; i < this.data3.length; i++) {
                let item = this.data3[i]
                if (obj.id == item.tCode) {
                    item.checked = false
                }
            }
            this.TagList.splice(index, 1)
        },
        animationfinish(e) {
            let current = e.detail.current
            this.$refs.tabs.setFinishCurrent(current)
            this.tabIndex = current
        },
        onTabChanged(index) {
            this.tabIndex = index
        },
        transition(e) {
            let dx = e.detail.dx
            this.$refs.tabs.setDx(dx)
        },
        _initChoosedData() {
            if (this.chooseVal != this.value) {
                this.choosedData = []
                if (this.value) {
                    let arry = this.value.split(',')
                    let arryName = this.names.split(',')
                    for (let i = 0; i < arry.length; i++) {
                        this.choosedData.push({
                            userId: arry[i],
                            userName: arryName[i]
                        })
                    }
                    this.choosedNum = this.choosedData.length
                }
            }

            if (this.chooseVal == '') {
                this.choosedData = []
            }
        },
        _initList(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].userId == list[i].userId) {
                        list[i].checked = true
                    }
                }
            }
            this.data = list
            if (this.TagList.length > 0) {
                for (let i = 0; i < this.data.length; i++) {
                    let item = this.data[i]
                    for (var j = 0; j < this.TagList.length; j++) {
                        let obj = this.TagList[j]
                        if (obj.id == item.tCode) {
                            item.checked = true
                        }
                    }
                }
            }
        },
        _initList0(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].userId == list[i].userId) {
                        list[i].checked = true
                    }
                }
            }
            this.data0 = list
            if (this.TagList.length > 0) {
                for (let i = 0; i < this.data0.length; i++) {
                    let item = this.data0[i]
                    for (var j = 0; j < this.TagList.length; j++) {
                        let obj = this.TagList[j]
                        if (obj.id == item.tCode) {
                            item.checked = true
                        }
                    }
                }
            }
        },
        _initList2(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].userId == list[i].userId) {
                        list[i].checked = true
                    }
                }
            }
            this.data2 = list
            if (this.TagList.length > 0) {
                for (let i = 0; i < this.data2.length; i++) {
                    let item = this.data2[i]
                    for (var j = 0; j < this.TagList.length; j++) {
                        let obj = this.TagList[j]
                        if (obj.id == item.tCode) {
                            item.checked = true
                        }
                    }
                }
            }
        },
        _initList3(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].userId == list[i].userId) {
                        list[i].checked = true
                    }
                }
            }
            this.data3 = list
            if (this.TagList.length > 0) {
                for (let i = 0; i < this.data3.length; i++) {
                    let item = this.data3[i]
                    for (var j = 0; j < this.TagList.length; j++) {
                        let obj = this.TagList[j]
                        if (obj.id == item.tCode) {
                            item.checked = true
                        }
                    }
                }
            }
        },
        close() {
            // this.dialogShow = false;
            this.$emit('update:show', false)
        },
        search() {

            // this.queryParams.SearchValue = this.searchValue;
            // setTimeout(() => {
            // 	this.$refs.eaglePageList.search(
            // 	url: ""
            // 	);
            // });

            var conditions = []

            if (this.searchValue) {
                let obj = {}
                obj.name = 'title'
                obj.value = this.searchValue
                obj.operate = 'like'
                conditions.push(obj)
            }

            setTimeout(() => {
                // this.$refs.eaglePageList.search();
                if (this.isType) {
                    console.log('this.$refs.eaglePageList0', this.$refs.eaglePageList0)
                    this.$refs.eaglePageList0.search({
                        url: "support/DagerTpl/getPageListData?dataType=list",
                        conditions: conditions,
                        params: { opCode: this.opCode0, }
                    })
                }
                this.$refs.eaglePageList.search({
                    url: "support/DagerTpl/getPageListData?dataType=list",
                    conditions: conditions,
                    params: { opCode: this.opCode1, }
                })
                this.$refs.eaglePageList2.search({
                    url: "support/DagerTpl/getPageListData?dataType=public",
                    conditions: conditions,
                    params: {
                        profession: this.profession,
                        professionName: this.professionName,
                        applyAreaStr: this.form.area,
                        opCode: this.opCode2,
                        keywords: this.searchValue
                    }
                })
                this.$refs.eaglePageList3.search({
                    url: "support/DagerTpl/getPageListData?dataType=Mylist",
                    conditions: conditions,
                })
            }, 500)

        },
        //选中处理
        choose(obj, update) {

            let _this = this
            if (update) {
                obj.checked = !obj.checked
            }
            this.choosedData = []
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i]
                if (item.checked && obj.tCode == item.tCode) {
                    var data = { id: obj.tCode, name: obj.title }
                    _this.TagList.push(data)
                }
            }
            if (!obj.checked) {
                for (var j = 0; j < _this.TagList.length; j++) {
                    if (_this.TagList[j].id == obj.tCode) {
                        _this.TagList.splice(j, 1)
                    }
                }
            }
            this.choosedNum = this.choosedData.length
        },
        choose0(obj, update) {

            let _this = this
            if (update) {
                obj.checked = !obj.checked
            }
            this.choosedData = []
            for (let i = 0; i < this.data0.length; i++) {
                let item = this.data0[i]
                if (item.checked && obj.tCode == item.tCode) {
                    var data = { id: obj.tCode, name: obj.title }
                    _this.TagList.push(data)
                }
            }
            if (!obj.checked) {
                for (var j = 0; j < _this.TagList.length; j++) {
                    if (_this.TagList[j].id == obj.tCode) {
                        _this.TagList.splice(j, 1)
                    }
                }
            }
            this.choosedNum = this.choosedData.length
        },
        //选中处理
        choose2(obj, update) {

            let _this = this
            if (update) {
                obj.checked = !obj.checked
            }
            this.choosedData = []
            for (let i = 0; i < this.data2.length; i++) {
                let item = this.data2[i]
                if (item.checked && obj.tCode == item.tCode) {
                    var data = { id: obj.tCode, name: obj.title }
                    _this.TagList.push(data)
                }
            }
            if (!obj.checked) {
                for (var j = 0; j < _this.TagList.length; j++) {
                    if (_this.TagList[j].id == obj.tCode) {
                        _this.TagList.splice(j, 1)
                    }
                }
            }
            this.choosedNum = this.choosedData.length
        },
        //选中处理
        choose3(obj, update) {

            let _this = this
            if (update) {
                obj.checked = !obj.checked
            }
            this.choosedData = []
            for (let i = 0; i < this.data3.length; i++) {
                let item = this.data3[i]
                if (item.checked && obj.tCode == item.tCode) {
                    var data = { id: obj.tCode, name: obj.title }
                    _this.TagList.push(data)
                }
            }
            if (!obj.checked) {
                for (var j = 0; j < _this.TagList.length; j++) {
                    if (_this.TagList[j].id == obj.tCode) {
                        _this.TagList.splice(j, 1)
                    }
                }
            }
            this.choosedNum = this.choosedData.length
        },
        submit() {
            let Tagcodes = []
            let nameArry = []
            this.TagList.forEach(function (item) {
                Tagcodes.push(item.id)
                // nameArry.push(item.name);
            })
            let codes = Tagcodes.join(',')
            let names = nameArry.join(',')
            this.chooseVal = codes
            this.$emit('tableData', this.TagList, codes)
            this.close()

        },
        chooseAll() {
            let _this = this
            this.choosedData = []
            this.data.forEach(function (item) {
                item.checked = true
                _this.choosedData.push(item)
            })
            this.choosedNum = this.choosedData.length
        },
        cancelChoose() {
            this.choosedData = []
            this.data.forEach(function (item) {
                item.checked = false
            })
            this.choosedNum = 0
            this.showDetail = false
        },
        clear(obj, index) {
            this.choosedData.splice(index, 1)
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i]

                if (item.userId == obj.userId) {
                    item.checked = false
                }
            }
            this.choosedNum = this.choosedData.length
            if (this.choosedNum == 0) {
                this.showDetail = false
            }
        },
        funShowDetail() {
            this.showDetail = !this.showDetail

        },
        checkChange(e) {

        },

    }
}
</script>

<style lang="scss">
.uni-media-cell {
    margin: 0;
}

.view-botton {
    padding: 12rpx;
    width: 100%;
    bottom: 0px;
    position: fixed;
    background: #fff;
}

.choose-item {
    float: left;
    display: inline-block;
    line-height: 50rpx;
}

.choose-num {
    color: #2979ff;
}

.choose-btn {
    float: right;
    margin-left: 8rpx;
    margin: 10px;
}

.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}

.choosed-view {
    margin-bottom: 50rpx;
}

.swiper-box1 {
    height: calc(100vh - 145px);
}

.swiper-box2 {
    height: calc(100vh - 165px);
}

.bottom-btn {
    position: fixed;
    bottom: 0;
    margin-left: 0px;

    .button {
        margin: 0;
    }
}
</style>
