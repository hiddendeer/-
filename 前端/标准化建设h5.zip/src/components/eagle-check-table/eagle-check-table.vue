<template name="eagle-check-table">
    <!-- <view class="eagle-item eagle-check-table" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx;"> -->
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
        <view style="margin:20rpx;" v-for="(item, index) in TagList" :key="index">
            <u-tag :text="item.name" size="mini" closeable @close="tagClose(item,index)"></u-tag>
        </view>
        <u-icon name="edit-pen" label="选择检查表" @click="funDialogShow">
        </u-icon>
        <popup-table :isMult="isMult" :show.sync="dialogShow" :TagList="TagList" v-model="codes" @tableData="tableData"></popup-table>
    </u-form-item>

    <!-- </view>
    </view> -->
</template>

<script>
import popupTable from "@/components/eagle-check-table/popup-table.vue";
export default {
    name: "eagle-check-table",
    components: {
        "popup-table": popupTable,
    },
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
        placeholderVal: {
            type: String,
            default: "请选择员工",
        },
        TagList: {
            type: Array,
            default() {
                return [];
            },
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this.codes = nVal;
            }
        },
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        tagClose(item, index) {
            this.TagList.splice(index, 1);
            this.$emit("tagClose", item, index);
        },
        tableData(list, codes) {
            this.TagList = list;
            this.$emit("update:TagList", list);
            this.$emit("input", codes);
        },
        funDialogShow() {
            this.dialogShow = true;
        },
    },
};
</script>

<style lang="scss">
</style>
