<template>
    <u-popup v-model="dialogShowIndystry" mode="right" height="100%" length="100%">
        <eagle-head @close="close"> 选择行业</eagle-head>
        <view class="list">
            <u-row style="align-items: start;justify-content: flex-start;">
                <u-col span="4">
                    <!-- 一级 -->
                    <scroll-view class="list-left" scroll-y>
                        <view v-if="List.length>0" class="list-nav" @click="categoryClickMain(item)" :key="item.id" :class="index==categoryActive?'active':''" v-for="(item,index) in List">
                            {{item.name}}
                            <text>
                                <u-badge :count="item.count>0?item.count:0" size="mini" type="primary" :absolute='false'></u-badge>
                            </text>
                        </view>
                    </scroll-view>
                </u-col>
                <u-col span="8">
                    <!-- 二级 -->
                    <scroll-view class="list-right" scroll-y>
                        <u-row style="padding: 10px;">
                            <u-col span="4">
                                <u-image width="60px" height="60px" :src="rightView.logo"></u-image>
                            </u-col>
                            <u-col span="8">
                                <view>
                                    <view class="uni-media-list">
                                        <view class="uni-media-list-body">
                                            <view class="uni-media-list-text-top" Style="font-size: larger;font-weight: 900;">{{rightView.name}}</view>
                                        </view>
                                        <u-checkbox v-model="rightView.checked" @click.stop.native="choose(rightView)" shape="circle">
                                        </u-checkbox>
                                    </view>
                                </view>
                                <view style="color: #7c868e;"> {{rightView.note!=""?rightView.note:"暂无描述信息"}}</view>
                            </u-col>
                        </u-row>

                        <view style="background: aliceblue;padding: 10px;">包含以下子行业</view>
                        <view v-if="rightView.detail.length>0" class="list-nav" :key="item.id" :class="index==categoryActive?'active':''" v-for="(item,index) in rightView.detail">
                            <view class="uni-media-list">
                                <view class="uni-media-list-body">
                                    <view class="uni-media-list-text-top">{{item.name}}</view>
                                </view>
                                <u-checkbox v-model="item.checked" :disabled="rightView.checked" @click.stop.native="choose2(item,rightView)" shape="circle">
                                </u-checkbox>
                            </view>

                        </view>
                    </scroll-view>
                </u-col>
            </u-row>
            <u-toast ref="uToast" />
        </view>
    </u-popup>
</template>

<script>
import common from "@/common/common.js";
export default {
    name: "popup-industry",
    props: {
        value: {
            type: String,
            default() {
                return ""
            }
        },
        names: {
            type: String,
            default() {
                return ''
            }
        },
        isMult: {
            type: Boolean,
            default() {
                return true
            }
        },
        TagList: {
            type: Array,
            default() {
                return []
            }
        },
    },
    data() {
        return {
            dialogShowIndystry: false,
            loading: false,
            List: [],
            subList: [],
            height: 800,
            categoryActive: 0,
            scrollTop: 0,
            scrollHeight: 0,
            subs: [],
            datas: [],
            rightView: {},
            isShow: true,
            // img_url:this.$GLOBAL.BASE_IMG,
            "departmentLevel": 1,
            "gbDepartmentName": "",
            deptName: '',
            isActive: 0 //默认激活的选项卡
        };
    },
    methods: {
        //选中处理
        choose(obj) {
            console.log('obj===', obj)
            if (obj.checked) {
                if (this.datas.length >= 3) {
                    this.$set(obj, 'checked', false)
                    this.$refs.uToast.show({ title: '最多只能选三个行业', type: 'success', })
                    return
                } else {
                    this.$set(obj, 'checked', true)
                }
                this.$set(obj, 'count', 1)
                this.datas.push(obj);
                obj.detail.forEach((x) => {
                    this.$set(x, 'checked', false)
                    this.datas.forEach((da, index) => {
                        if (da.id == x.id) {
                            this.datas.splice(index, 1);
                        }
                    })
                })

                console.log('true===', this.datas)
            } else {
                this.$set(obj, 'count', 0)
                this.datas.forEach((da, index) => {
                    if (da.id == obj.id) {
                        this.datas.splice(index, 1);
                    }
                })
                console.log('false===', this.datas)
            }
        },
        //选中处理
        choose2(item, obj) {
            let num = 0;
            if (item.checked && !obj.checked) {
                if (this.datas.length >= 3) {
                    console.log('false===', this.datas)
                    this.$set(item, 'checked', false)
                    this.$refs.uToast.show({ title: '最多只能选三个行业', type: 'success', })
                    return
                }
                this.$set(item, 'checked', item.checked)
                this.datas.push(item);
                if (!obj.count) {
                    this.$set(obj, 'count', 0)
                } else {
                    num = obj.count
                }
                ++num
                console.log('count===', num)
                console.log(obj)
                this.$set(obj, 'count', num)
            } else {
                this.datas.forEach((da, index) => {
                    if (da.id == item.id) {
                        this.datas.splice(index, 1);
                        this.$set(obj, 'count', obj.count - 1)
                    }
                })
            }
            console.log('obj22===', item)
        },
        show() {
            this.dialogShowIndystry = true;
            this.getListData();
        },
        close() {
            // console.log('dialogShowIndystry===')
            this.dialogShowIndystry = false;
            // this.$emit('dialogShowIndystry', false);

        },
        categoryClickMain(item) {
            this.rightView = item
            console.log('data===', this.rightView)
        },
        getListData() {
            // uni.showToast({
            // 	icon: "loading"
            // });
            // this.loadStatus = "loading";
            this.loading = true;
            this.common.get("support/dangerlgclassify/GetListWithType",).then((res) => {
                this.loading = false;
                if (res.code == 200) {
                    let datas = res.data;
                    this.List = datas;
                    this.rightView = datas[0]
                    // this.List.concat(datas);
                    console.log(this.List);
                }
            });
        },
       

    }
}
</script>

<style lang="scss">
.list-nav {
    padding: 10px;
}
</style>
