<template>
    <view class="grid-bottom-btn">
        <slot></slot>
    </view>
</template>

<script>
export default {
    name: "eagle-grid-botton",
    data() {
        return {};
    },
};
</script>

<style lang="scss">
.grid-bottom-btn {
    font-size: $font-sm;
    color: #666666;
    padding-top: 5px;
    text-align: right;
    border-top: 1px solid $border-color-base;
    .eagle-row-span {
        border-right: 2rpx solid #f5f5f5;
        margin-right: 6rpx;
        padding-right: 6rpx;
        line-height: 50rpx;
    }
    .eagle-row-span:last-child {
        border-right: none;
        padding-right: 0rpx;
        margin-right: 0rpx;
    }
}
/deep/ .u-icon {
    margin-left: $spacing-base;
}
// /deep/ .grid-bottom-btn .u-icon__label {
//     color: #666;
// }
</style>
