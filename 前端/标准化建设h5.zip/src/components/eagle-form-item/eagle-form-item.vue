<template>
	<!-- <view style="background: #FFFFFF;">
		<view style="padding: 0 30rpx;"> -->
			<u-form-item ref="uFormItem" :label="title" :label-position="labelPositionVal" :left-icon="leftIcon"
				:right-icon="rightIcon" :right-icon-style="rightIconStyle" :required="required" :prop="prop"
				:label-width="labelWidth">
			</u-form-item>
		<!-- </view>
	</view> -->
</template>
<script>
	export default {
		name: "eagle-form-item",
		props: {
			maxlength: {
				type: [Number, String],
				default: -1
			},
			title: {
				type: [String],
				default: ''
			},
			prop: {
				type: [String],
				default: ''
			},
			required: {
				type: [Boolean],
				default () {
					return false
				}
			},
			volidMessage: {
				type: String,
				default: ""
			},
			labelPosition: {
				type: String,
				default: ""
			},
			labelWidth: {
				type: String,
				default: ''
			},
			// 右侧图标
			rightIcon: {
				type: String,
				default: ''
			},
			// 左侧图标
			leftIcon: {
				type: String,
				default: ''
			},
			// 左侧图标的样式
			leftIconStyle: {
				type: Object,
				default () {
					return {}
				}
			},
			// 左侧图标的样式
			rightIconStyle: {
				type: Object,
				default () {
					return {}
				}
			},
		},
		created() {
			this.placeholderVal = this.placeholderVal ? this.placeholderVal : ("请输入" + this.title);
			this.labelPositionVal = this.labelPosition ? this.labelPosition : this.consts.constLabelPosition;
		},
		data() {
			return {
				defaultValue: this.value,
				placeholderVal: "",
				labelPositionVal: "",
			}
		},
		watch: {
			defaultValue(nVal, oVal) {
				if (this.defaultValue != oVal) {
					this.defaultValue = nVal;
					this.$emit('input', this.defaultValue);
				}
			},
			value(nVal, oVal) {
				if (this.defaultValue != this.value) {
					this.defaultValue = this.value;
					this.$emit('input', this.defaultValue);
				}
			},
		},
		methods: {
			valid(val) {
				if (this.required) {
					this.$refs.uFormItem.validateMessage = this.placeholderVal;
				}
			},
		},
	}
</script>

<style lang="scss">
	.label-style .el-form-item__label {
		font-size: 18px;
		color: #aaaa33
	}

	.label-content .el-form-item__content {
		font-size: 20px;
		color: #aaaa33;
	}
</style>
