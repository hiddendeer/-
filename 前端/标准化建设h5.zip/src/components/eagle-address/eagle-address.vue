<template>

    <u-form-item ref="uFormItem" :label-position="labelPositionVal" :label="title" :required="required" :prop="prop" :label-width="labelWidth">
        <eagle-arrow-input v-model="defaultValue" :placeholder="placeholderVal" @input="inputChange" @confirm="confirmEvent" @click="regionShow=!regionShow"></eagle-arrow-input>
        <u-picker mode="region" :params="params" v-model="regionShow" @confirm="confirm"></u-picker>
    </u-form-item>

</template>

<script>
export default {
    name: "eagle-address",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        title: {
            type: [String],
            default: "地区",
        },
        model: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        // 输入框的类型，textarea，text，number
        type: {
            type: String,
            default: "text",
        },
        inputAlign: {
            type: String,
            default: "left",
        },
        placeholder: {
            type: String,
            default: "请选择地区",
        },
        isChoose: {
            type: Boolean,
            default: false,
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        maxlength: {
            type: [Number, String],
            default: -1,
        },
        placeholderStyle: {
            type: String,
            default: "color: #c0c4cc;",
        },
        confirmType: {
            type: String,
            default: "done",
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        // 输入框的自定义样式
        customStyle: {
            type: Object,
            default() {
                return {};
            },
        },
        // 如果 textarea 是在一个 position:fixed 的区域，需要显示指定属性 fixed 为 true
        fixed: {
            type: Boolean,
            default: false,
        },
        // 是否自动获得焦点
        focus: {
            type: Boolean,
            default: false,
        },
        // 密码类型时，是否显示右侧的密码图标
        passwordIcon: {
            type: Boolean,
            default: true,
        },
        // input|textarea是否显示边框
        border: {
            type: Boolean,
            default: false,
        },
        // 输入框的边框颜色
        borderColor: {
            type: String,
            default: "#dcdfe6",
        },
        autoHeight: {
            type: Boolean,
            default: true,
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        // type=select时，旋转右侧的图标，标识当前处于打开还是关闭select的状态
        // open-打开，close-关闭
        selectOpen: {
            type: Boolean,
            default: false,
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: "",
        },
        // 是否可清空
        clearable: {
            type: Boolean,
            default: true,
        },
        // 指定光标与键盘的距离，单位 px
        cursorSpacing: {
            type: [Number, String],
            default: 0,
        },
        // 光标起始位置，自动聚焦时有效，需与selection-end搭配使用
        selectionStart: {
            type: [Number, String],
            default: -1,
        },
        // 光标结束位置，自动聚焦时有效，需与selection-start搭配使用
        selectionEnd: {
            type: [Number, String],
            default: -1,
        },
        // 是否自动去除两端的空格
        trim: {
            type: Boolean,
            default: true,
        },
        // 是否显示键盘上方带有”完成“按钮那一栏
        showConfirmbar: {
            type: Boolean,
            default: true,
        },
        showBtn: {
            type: Boolean,
            default: false,
        },
        isNumber: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            regionShow: false,
            heightVal:
                this.height != ""
                    ? this.height
                    : this.type === "textarea"
                    ? "60px"
                    : "20px",
            placeholderVal: "",
            labelPositionVal: "",
            defaultValue: this.value,
            inputHeight: 70, // input的高度
            textareaHeight: 100, // textarea的高度
            validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
            focused: false, // 当前是否处于获得焦点的状态
            showPassword: false, // 是否预览密码
            lastValue: "", // 用于头条小程序，判断@input中，前后的值是否发生了变化，因为头条中文下，按下键没有输入内容，也会触发@input时间
            params: {
                year: true,
                month: true,
                day: true,
                hour: false,
                minute: false,
                second: false,
                province: true,
                city: true,
                area: true,
                timestamp: true,
            },
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请选择" + (this.title ? this.title : "内容");

        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    watch: {
        // defaultValue(nVal, oVal) {
        //     if (this.defaultValue != oVal) {
        //         if (this.isNumber) {
        //             this.$nextTick(function () {
        //                 nVal = nVal + "";

        //                 this.defaultValue = Number(
        //                     nVal.toString().match(/^\d+(?:\.\d{0,2})?/)
        //                 );
        //             });
        //         } else {
        //             this.defaultValue = nVal;
        //         }

        //         this.$emit("input", this.defaultValue);
        //     }
        // },
        value(nVal, oVal) {
            this.defaultValue = this.value;
            // this.$emit("input", this.defaultValue);
        },
    },
    methods: {
        confirm(e) {
            if (e.city.label === "市辖区") {
                this.defaultValue = e.province.label + "/" + e.area.label;
            } else if (e.province.label === "全国") {
                this.defaultValue = "全国";
            } else {
                this.defaultValue =
                    e.province.label + "/" + e.city.label + "/" + e.area.label;
            }
            this.$emit("input", this.defaultValue);
        },
        choose() {
            this.$emit("choose");
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue && _this.defaultValue !== 0) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.has-border {
    border: 1px solid #dcdfe6;
    width: 100%;
    box-sizing: border-box;
    border-radius: 4px;
    // background: #E2E2E5;
}

.d-flex {
    display: flex;
    width: 100%;
    align-items: center;
}

.text-style {
    margin-left: 20rpx;
    font-size: 28rpx;
    font-weight: 600;
    color: #2979ff;
}

.custom-style {
    width: 120rpx;
    height: 74rpx;
    color: #55aaff;
    margin-left: 20rpx;
}
</style>
