<template>
    <view class="row-attach" v-if="fileList.length > 0">
        <view v-if="title" class="label-attach">
            {{ title }}:
        </view>
        <view class="upload-list_item-preview" v-if="fileList && fileList.length > 0">
            <view class="fileContentRow" v-for="item in fileList" :key="item['attCode']" @click.stop="doPreviewDoc(item.attCode || item.AttCode)">
                <view>
                    <image class="fileIcon" :src="item.attSrc"></image>
                </view>
                <view>{{ item.name || item.AttName }}</view>
            </view>
        </view>
    </view>
</template>
 
<script>
export default {
    name: "eagle-grid-attach",
    props: {
        value: {
            type: Array | String,
            default() {
                return "";
            },
        },
        title: {
            type: String,
            default() {
                return "附件";
            },
        },
        // lableWidth: {
        // 	type: String,
        // 	default () {
        // 		return "44px";
        // 	},
        // },
    },
    data() {
        return {
            fileList: [],
        };
    },
    watch: {
        value(newvalue, oldvalue) {
            if (newvalue) {
                this.setFileList(newvalue);
            } else {
                this.fileList = [];
            }
        },
    },
    mounted() {
        this.setFileList(this.value);
    },
    methods: {
        doPreviewDoc(code) {
            var url = "/pages/common/pdfView?code=" + code;
            this.base.navigateTo(url);
        },
        setFileList(attachs) {
            if (attachs) {
                if (typeof attachs == "string") {
                    var arryFile = JSON.parse(attachs);
                    this.fileList = arryFile;
                } else {
                    this.fileList = attachs;
                }

                for (var i = 0; i < this.fileList.length; i++) {
                    var attach = this.fileList[i];
                    if (attach) {
                        var attExt = attach.attExt || attach.AttExt;
                        if (attExt.indexOf(".") >= 0) {
                            attExt = attExt.replace(".", "");
                        }
                        switch (attExt) {
                            case ("docx", "doc"):
                                attach.attSrc = "/static/img/kn/icon/doc.png";
                                break;
                            case ("pptx", "ppt"):
                                attach.attSrc = "/static/img/kn/icon/doc.png";
                                break;
                            case ("xls", "excel", "xlsx"):
                                attach.attSrc = "/static/img/kn/icon/xls.png";
                                break;
                            case "pdf":
                                attach.attSrc = "/static/img/kn/icon/pdf.png";
                                break;
                            case "mp4":
                                attach.attSrc = "/static/img/kn/icon/mp4.png";
                                break;
                            case "zip":
                                attach.attSrc = "/static/img/kn/icon/zip.png";
                                break;
                            case ("png", "jpeg", "jpg"):
                                attach.attSrc = "/static/img/kn/icon/png.png";
                                break;
                            default:
                                attach.attSrc = "/static/img/kn/icon/cou.png";
                                break;
                        }
                    }
                }
            }
        },
    },
};
</script>

<style lang="scss">
.row-attach {
    display: flex;
    flex-wrap: nowrap;
    word-break: break-all;

    //    border: 1px dashed #f5f5f5;
    // padding: 2px;
    //width: 300px;
}

.upload-list_item-preview {
    color: #0088ff;
    margin-left: 3px;
    flex: 1;
}

.upload-list_item-preview .fileContentRow {
    display: flex;
    flex-wrap: nowrap;
    align-content: space-between;
    grid-gap: 5px;
}

.upload-list_item-preview .fileIcon {
    width: 16px;
    height: 16px;
    margin-top: 2px;
}
</style>
