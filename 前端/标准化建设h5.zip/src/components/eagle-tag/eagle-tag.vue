<template>
    <span class="e-tag" :style="[{
			color: getColor(),
		}]">
        <slot></slot> {{text}}
    </span>
</template>
<script>
export default {
    name: "eagle-tag",
    props: {
        text: {
            //bg-color:{//标签的文字内容
            type: [String],
            default() {
                return "";
            },
        },
        type: {
            type: [String],
            default() {
                return "primary";
            },
        },
    },
    data() {
        return {};
    },
    created() {},
    methods: {
        getColor() {
            switch (this.type) {
                case "primary":
                    return "#0088ff";
                case "warning":
                    return "#E6A23C";
                case "success":
                    return "#67C23A";
                case "error":
                    return "#dd6161";
                default:
                    return "#666";
            }
        },
    },
    watch: {},
};
</script>
<style lang="scss">
.e-tag {
    position: absolute;
    right: 10px;
    top: 10px;
}
</style>