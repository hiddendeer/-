<template name="eagle-choosed-list">
    <u-popup v-model="dialogShow" mode="bottom" height="100%">
        <view class="eagle-layer">
            <eagle-head :title="title" @close="dialogShow=false" />
            <view class="eagle-choosed-list">
                <view class="seach-line">
                    <u-search v-model="keyword" height="76" :show-action="false" placeholder="请输入关键字查询" bg-color='#fff' shape="square">
                    </u-search>
                </view>
                <scroll-view scroll-y class="scroll" :scroll-top="120" :style="{ height:scrollHeight + 'px' }">
                    <view v-for="(item,index) in chooseArray" :key="index" class="list-wrap">
                        <eagle-row-card :hasImg="false" v-if="keyword==undefined||keyword==''||item[nameField].indexOf(keyword)>=0">
                            <view class="eagle-flex-between">
                                <view>
                                    <view v-if="!defaultRow">
                                        <slot name='body' :item="item" :$index="index"></slot>
                                    </view>
                                    <eagle-row-view isTitle v-else>
                                        {{item[nameField]}}
                                    </eagle-row-view>
                                </view>
                                <view class="del-btn" v-if="allowDel">
                                    <u-button size="mini" type="error" @click="unChoose(item,index)" plain>移除</u-button>
                                </view>
                            </view>
                        </eagle-row-card>
                    </view>
                </scroll-view>
            </view>
        </view>
    </u-popup>
</template>

<script>
export default {
    name: "eagle-choosed-list",
    props: {
        title: {
            type: String,
            default() {
                return "已选择";
            },
        },
        nameField: {
            type: String,
            default() {
                return "name";
            },
        },
        title: {
            type: String,
            default() {
                return "已选择";
            },
        },
        chooseArray: {
            type: Array,
            default() {
                return [];
            },
        },
        allowDel: {
            type: Boolean,
            default() {
                return true;
            },
        },
        defaultRow: {
            type: Boolean,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            dialogShow: false,
            // chooseArray: [],
            scrollHeight: 50,
            keyword: "",
        };
    },
    computed: {},
    created() {
        this.resetTableHeight();
    },
    methods: {
        show(obj) {
            this.dialogShow = true;
            console.log(this.chooseArray);
            // this.chooseArray = obj.chooseList;
        },

        unChoose(item, index) {
            this.$emit("unChoose", item);
        },
        resetTableHeight() {
            var _that = this;
            uni.getSystemInfo({
                success: function (res) {
                    _that.scrollHeight = res.windowHeight - 60;
                    //_that.marginBottom;
                },
            });
        },
        search() {},
    },
};
</script>

<style lang="scss">
.eagle-choosed-list {
    margin-top: 20rpx;
    .seach-line {
        margin: 20rpx;
    }
}
</style>
