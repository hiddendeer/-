<template>
    <view class="eagle-row-view s-between" :class="{'single-line':isSingleLine,'s-around':sAround}">
        <view class="single-line" :style="{'max-width':maxWidth}" :class="{'grid-row-title':isTitle,'s-between':spaceBetween}">
            <!--,'row-width':!spaceBetween -->
            <slot></slot>
        </view>
        <view class="row-block" :style="{color:getColor()}">
            <slot name="icon"></slot>
        </view>
    </view>
</template>

<script>
export default {
    components: {},
    name: "eagle-row-view",
    props: {
        isTitle: {
            type: Boolean,
            default: false,
        },
        isSingleLine: {
            type: Boolean,
            default: false,
        },
        spaceBetween: {
            type: Boolean,
            default: false,
        },
        sAround: {
            type: Boolean,
            default: false,
        },

        title: {
            type: String,
            default: "",
        },
        type: {
            type: String,
            default: "primary",
        },
        maxWidth: {
            type: String,
            default: "none",
        },
    },
    data() {
        return {};
    },
    methods: {
        getColor() {
            switch (this.type) {
                case "warn":
                    return "#E6A23C";
                case "success":
                    return "#67C23A";
                case "primary":
                    return "#0088ff";
                case "error":
                    return "#dd6161";
                default:
                    return "auto";
            }
        },
    },
};
</script>
 