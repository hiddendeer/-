<template name='eagle-radios'>
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :prop="prop" :label-width="labelWidth">
        <u-radio-group v-model="defaultVal" @change="change" :active-color="activeColor" :shape="shape" :wrap="wrap">
            <u-radio v-for="(item, index) in items" :key="index" :name="item[ID]" :disabled="disabled">
                {{item[Name]}}
            </u-radio>
        </u-radio-group>
        <!-- <view v-else style="font-size: 14px;">
                    {{displayText}}
                </view> -->
    </u-form-item>
</template>
<script>
export default {
    name: "eagle-radios",
    props: {
        value: {
            type: Number | String,
            default() {
                return "";
            },
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        ID: {
            type: String,
            default() {
                return "id";
            },
        },
        Name: {
            type: String,
            default() {
                return "name";
            },
        },
        text: {
            type: String,
            default() {
                return "";
            },
        },
        disabledValues: {
            type: String,
            default() {
                return "";
            },
        },
        checkedValues: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },

        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        activeColor: {
            type: String,
            default() {
                return "#2979ff";
            },
        },
        shape: {
            type: String,
            default() {
                return "circle";
            },
        },
        labelDisabled: false,
        max: {
            type: [Number, String],
            default() {
                return 999;
            },
        },
        labelWidth: {
            type: String,
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
    },
    data() {
        return {
            wrap: false,
            items: [],
            defaultVal: "",
            labelPositionVal: "",
            placeholderVal: "",
            displayText: "",
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : `请选择${this.title}`;
        this.defaultVal = this.value;
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        this.bind();
    },
    methods: {
        change: function (e) {
            this.defaultVal = e;
            if (e == "Custom") {
                this.customerDisable = false;
                this.customPlaceholder = "请输入自定义内容";
            } else {
                this.customerDisable = true;
                this.customerVal = "";
                this.customPlaceholder = "";
            }
            this.$emit("input", this.defaultVal);
            let obj = this.items.find((x) => x[this.ID] === this.defaultVal);
            this.$emit("update:text", obj[this.Name]);
            this.$emit("change", this.defaultVal, obj);
            this.valid();
        },
        customerChange() {
            this.$emit("input", val);

            this.$emit("change", val);
        },
        bind: function () {
            this.items = this.utils.deepClone(this.dataSource);
            this.setValue();
        },
        setValue() {
            var _this = this;
            var disabledArray = this.disabledValues
                ? this.disabledValues.split(",")
                : [];
            this.items.forEach((item, index) => {
                if (
                    _this.defaultVal &&
                    _this.defaultVal.toString() === item[_this.ID].toString()
                ) {
                    this.$set(item, "checked", true);
                    this.displayText = item[_this.Name];
                } else this.$set(item, "checked", false);

                if (this.disabled || disabledArray.includes(item[_this.ID]))
                    this.$set(item, "disabled", true);
                else this.$set(item, "disabled", false);
            });
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultVal) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
    watch: {
        value: function (nval, oval) {
            let _this = this;
            _this.defaultVal = nval;
            if (_this.disabled) {
                _this.dataSource.forEach((item, index) => {
                    if (_this.defaultVal === item[_this.ID]) {
                        _this.displayText = item[_this.Name];
                    }
                });
            } else {
                _this.setValue();
            }
        },
    },
};
</script>
<style  lang="scss">
.eagle-radios-block {
    .uni-list-cell {
        justify-content: flex-start;
        margin-top: 10rpx;
    }
    /deep/ .u-radio__icon-wrap--disabled {
        background-color: #cbced1;
    }
}
</style>
