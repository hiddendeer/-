<template name='eagle-fast-choose'>
    <u-form-item :label="title" ref="uFormItem" :class="border?'eagle-item-boder':''" :label-position="labelPositionVal" :required="required" :prop="prop" :label-width="labelWidth">
        <view class="date-warp">
            <view v-for="(item,index) in items" :key='index' :style='{width:"auto"}'>
                <view class="btn-item1" :style="{'width':itemWidth}" @click="chooseDate(item,index)" :class='{active:defaultVal===item[idField]}'>
                    {{item[textField]}}
                </view>
            </view>
        </view>
    </u-form-item>

</template>
<script>
export default {
    name: "eagle-fast-choose",
    components: {},
    props: {
        value: {
            type: Number | String,
            default: "",
        },
        names: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        idField: {
            type: String,
            default() {
                return "id";
            },
        },
        textField: {
            type: String,
            default() {
                return "name";
            },
        },

        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },

        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },

        shape: {
            type: String,
            default() {
                return "circle";
            },
        },
        labelDisabled: false,
        labelWidth: {
            type: String,
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        wrap: false,
        showCustomer: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        border: {
            type: Boolean,
            default: true,
        },
        itemWidth: {
            type: String,
            default: "",
        },
    },
    data() {
        return {
            items: [],
            defaultVal: "",
            defaultName: "",
            labelPositionVal: "",
            customerVal: "",
            customerDisable: true,
            customPlaceholder: "",
            dialog: false,
        };
    },
    mounted() {
        this.customPlaceholder = this.placeholder
            ? this.customPlaceholder
            : "请选择" + this.title;
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        this.bind();
        this.bindValue(this.value);
    },
    created() {},
    methods: {
        chooseDate(val, index) {
            // let data = this.dataSource.filter(
            //     (x) => x[this.idField] == val[this.idField]
            // )[0];
            this.defaultVal = val[this.idField];
            this.$emit("input", this.defaultVal);
            this.$emit("update:names", val[this.textField]);
            this.$emit("change", val);
            this.valid();
        },

        bind: function () {
            this.items = this.utils.deepClone(this.dataSource);
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultVal || _this.defaultVal === "Custom") {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.customPlaceholder;
                    return false;
                } else {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },

        bindValue(value) {
            this.defaultVal = value;
        },
    },
    watch: {
        value: function () {
            if (!this.value) {
                this.defaultName = "";
                this.customPlaceholder = this.placeholder
                    ? this.customPlaceholder
                    : "请选择" + this.title;
            }
            this.bindValue(this.value);
        },
    },
};
</script>
<style lang="scss" >
.title {
    font-size: 14px;
    padding: 3px;
    line-height: 28px;
    text-align: center;
    background-color: #fff;
    border-bottom: 1px solid #f5f5f5;
}

.eagle-fast-date {
    padding: 10px;
    background-color: #fff;
}

.year-warp {
    display: flex;
    padding-bottom: 10px;
    margin-bottom: 10px;
    border-bottom: 1px solid #f5f5f5;
}

.date-warp {
    display: flex;
    flex-wrap: wrap;
}

.btn-item1 {
    /* width: 70px; */
    height: 30px;
    line-height: 30px;
    text-align: center;
    // color: #333333;
    border-radius: 3px;
    margin: 0 20rpx 20rpx 0;
    padding: 0px 20rpx;
    background-color: #f5f5f5;
    border: 1px solid #f5f5f5;
    font-size: 14px;
    overflow: hidden;
    &.active {
        background-color: #ecf5ff;
        border-color: #0088ff;
        color: #0088ff;
    }
}

.uni-list-cell {
    justify-content: flex-start;
    margin-top: 10rpx;
}
</style>
