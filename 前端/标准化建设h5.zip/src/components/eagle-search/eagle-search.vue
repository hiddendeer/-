<template name="eagle-search">
    <view class="eagle-search">
        <view>
            <u-search v-model="keyword"  :placeholder="placeholder" @search="search" @clear="search" shape="square" :bg-color='bgColor' :borderColor="bgColor" :show-action="showAction" :action-text='actionText' @custom='custom'>
            </u-search>
            <slot></slot>
        </view>
    </view>
</template>

<script>
import uSearch from "@/uview-ui/components/u-search/u-search.vue";
export default {
    name: "eagle-search",
    exends: uSearch,
    props: {
        value: {
            type: [Number, String],
            default() {
                return "";
            },
        },
        placeholder: {
            type: String,
            default() {
                return "请输入关键词";
            },
        },
        // initSearch: {
        //     type: Boolean,
        //     default() {
        //         return false;
        //     },
        // },
        bgColor: {
            type: String,
            default: "#fff",
        },
        showAction: {
            type: Boolean,
            default() {
                return false;
            },
        },
        actionText: {
            type: String,
            default: "搜索",
        },
    },
    data() {
        return { keyword: "" };
    },
    watch: {
        keyword(nVal) {
            // 双向绑定值，让v-model绑定的值双向变化
            this.$emit("input", nVal);
            // 触发change事件，事件效果和v-model双向绑定的效果一样，让用户多一个选择
            this.$emit("change", nVal);
        },
        value: {
            immediate: true,
            handler(nVal) {
                this.keyword = nVal;
            },
        },
    },
    methods: {
        search() {
            var conditions = this.keyword
                ? [
                      {
                          Name: "keyWords",
                          Value: this.keyword,
                          Operato: "like",
                          // DataType: "String"
                      },
                  ]
                : undefined;
            this.$emit("search", conditions);
        },
        custom() {
            var conditions = this.keyword
                ? [
                      {
                          Name: "keyWords",
                          Value: this.keyword,
                          Operato: "like",
                          // DataType: "String"
                      },
                  ]
                : undefined;
            this.$emit("custom", conditions);
        },
    },
};
</script>

<style>
/deep/ .u-search {
    padding: 6rpx 16rpx;
}
</style>
