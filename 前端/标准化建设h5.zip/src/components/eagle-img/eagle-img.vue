<template>
    <view class="eagle-img">
        <view class="u-list-item u-preview-wrap" :style="{'width':width,'height':height}" v-for="(item, index) in srcArray" :key='index' v-if="showCount===0 || index<showCount">
            <img class="u-preview-image" :src="item" @click="doPreviewImage(index)" />
        </view>
    </view>
</template>

<script>
export default {
    // components: { view },
    name: "eagle-img",
    props: {
        src: "",
        width: "",
        height: "",
        previewFullImage: true,
        showCount: {
            type: Number,
            default: 0,
        },
    },
    data() {
        return {
            srcArray: [],
            noImgUrl: require("@/static/img/no-img.png"),
        };
    },
    watch: {
        src(nVal, oVal) {
            if (nVal !== oVal) {
                if (nVal) this.srcArray = nVal.split(";");
                else this.srcArray = [this.noImgUrl];
            }
        },
    },
    created() {
        if (this.src) this.srcArray = this.src.split(";");
        else this.srcArray = [this.noImgUrl];
    },
    methods: {
        doPreviewImage(index) {
            if (this.src && this.src.length > 0) {
                var _this = this;
                if (!_this.previewFullImage) {
                    _this.$emit("click");
                    return;
                }
                //this.lists.map(item => item.url || item.path);
                uni.previewImage({
                    urls: _this.srcArray,
                    current: _this.srcArray[index],
                    success: () => {
                        _this.$emit(
                            "on-preview",
                            _this.srcArray[index],
                            _this.srcArray,
                            index
                        );
                    },
                    fail: () => {
                        uni.showToast({
                            title: "预览图片失败",
                            icon: "none",
                        });
                    },
                });
            }
        },
    },
};
</script>

<style lang="scss">
.eagle-img {
    display: inline-flex;
    flex-flow: wrap;
    .u-preview-wrap {
        border: 1px solid rgb(235, 236, 238);
        border-radius: 30rpx;
    }

    .u-list-item {
        width: 200rpx;
        height: 200rpx;
        overflow: hidden;
        background: rgb(244, 245, 246);
        position: relative;
        border-radius: 10rpx;
        /* #ifndef APP-NVUE */
        display: flex;
        /* #endif */
        align-items: center;
        justify-content: center;

        .u-preview-image {
            display: block;
            width: 100%;
            height: 100%;
            border-radius: 10rpx;
        }
    }
}
</style>
