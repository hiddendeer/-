<template name="eagle-input">
    <u-form-item :label="title" ref="uFormItem" class="eagle-input eagle-form-item eagle-input-form-item" :label-position="labelPositionVal" :required="required || onlyShowRequired" :prop="prop" :label-width="labelWidth">
        {{ type == 'textarea' && height == '20px' ? areaHeight : height }}
        <u-input adjust-position="false" class="uni-input" :disabled="disabled" cursor-spacing="0" v-model="defaultValue" :maxlength="maxlength" @input="inputEvent" @confirm="confirmEvent" @blurEvent="blurEvent" @confirmEvent="confirmEvent" :height="height" :type="type" :placeholder="placeholderVal"></u-input>
        <slot></slot>
        <view v-if="$slots.topBotton" class="top-botton-block">
            <slot name="topBotton"></slot>
        </view>
    </u-form-item>
</template>
<script>
export default {
    name: "eagle-input",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        maxlength: {
            type: [Number, String],
            default: -1,
        },
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        volidMessage: {
            type: String,
            default: "",
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        valueType: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: [Number, String],
            default: "",
        },
        height: {
            type: String,
            default: "",
        },

        // send	右下角按钮为“发送”	微信、支付宝、百度小程序、快手小程序、app-nvue、app-vue和h5(2.9.9+，且要求设备webview内核Chrome81+、Safari13.7+)
        // search	右下角按钮为“搜索”
        // next	右下角按钮为“下一个”	微信、支付宝、百度小程序、快手小程序、app-nvue、app-vue和h5(2.9.9+，且要求设备webview内核Chrome81+、Safari13.7+)
        // go	右下角按钮为“前往”
        // done	右下角按钮为“完成”	微信、支付宝、百度小程序、快手小程序、app-nvue、app-vue和h5(2.9.9+，且要求设备webview内核Chrome81+、Safari13.7+)
        confirmType: {
            type: String,
            default: "done",
        },
        type: {
            type: String,
            default: "text",
        },
        placeholder: {
            type: String,
            default: "",
        },
        disabled: {
            type: Boolean,
            default: false,
        },
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请输入" + this.title;
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;

        if (this.disabled) {
            if (this.value == null || this.value == "") {
                this.defaultValue = "无";
            }
        }
    },
    data() {
        return {
            defaultValue: this.value,
            placeholderVal: "",
            labelPositionVal: "",
        };
    },
    watch: {
        defaultValue(nVal, oVal) {
            if (this.defaultValue != oVal) {
                this.defaultValue = nVal;
                this.$emit("input", this.defaultValue);
            }
        },
        value(nVal, oVal) {
            if (this.defaultValue != this.value) {
                this.defaultValue = this.value;
                this.$emit("input", this.defaultValue);
            }
        },
    },
    methods: {
        inputEvent() {
            this.$emit("input", this.defaultValue);
            this.valid();
        },
        focusEvent() {
            if (this.required && !this.defaultValue) {
            }
        },
        blurEvent() {
            this.$emit("input", this.defaultValue);
        },
        confirmEvent() {
            this.$emit("input", this.defaultValue);
            this.valid();
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.eagle-input {
    // padding: 0 30rpx;
    .eagle-input-form-item {
        position: relative;
    }

    .top-botton-block {
        position: absolute;
        right: 0px;
        top: 5px;
    }
}
</style>
