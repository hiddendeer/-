<template name="eagle-switch">
    <!-- <view class="eagle-item eagle-switch" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx;"> -->
    <u-form-item class="swich-content" :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :prop="prop" :label-width="labelWidth">
        <u-switch v-model="defaultVal" :disabled="disabled" :loading="loading" :active-color="activeColor" :size="size" :inactive-color="inactiveColor" @change="switchChange"></u-switch>
    </u-form-item>
    <!-- </view>
    </view> -->
</template>

<script>
export default {
    name: "eagle-switch",
    props: {
        title: {
            type: String,
            default() {
                return "";
            },
        },
        // 点击的时候传递事件出去的index（用于区分点击了哪一个）
        index: {
            type: [Number, String],
            default: "",
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        height: {
            type: String,
            default: "20px",
        },
        disabled: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        // 是否为加载中状态
        loading: {
            type: Boolean,
            default: false,
        },

        // 开关尺寸，单位rpx
        size: {
            type: [Number, String],
            default: 50,
        },
        // 打开时的背景颜色
        activeColor: {
            type: String,
            default: "#2979ff",
        },
        // 关闭时的背景颜色
        inactiveColor: {
            type: String,
            default: "#ffffff",
        },
        // 通过v-model双向绑定的值
        value: {
            type: [Number, String, Boolean],
            default: false,
        },
        // 是否使手机发生短促震动，目前只在iOS的微信小程序有效(2020-05-06)
        vibrateShort: {
            type: Boolean,
            default: false,
        },
        // 打开选择器时的值
        activeValue: {
            type: [Number, String, Boolean],
            default: true,
        },
        // 关闭选择器时的值
        inactiveValue: {
            type: [Number, String, Boolean],
            default: false,
        },
    },
    data() {
        return {
            defaultVal: this.value != false && this.value != "false",
        };
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        switchChange(val) {
            this.$emit("input", this.defaultVal);
            // console.log('val',val)
            this.$emit("change");
        },
    },
    watch: {
        value(nVal, oVal) {
            if (nVal !== oVal) {
                this.defaultVal = nVal != false && nVal != "false";
                //this.defaultVal = nVal;
            }
        },
    },
};
</script>

<style lang="scss" scoped>
.swich-content {
    line-height: 72rpx;
}
</style>
