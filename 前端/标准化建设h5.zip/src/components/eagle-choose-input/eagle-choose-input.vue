<template>
    <u-form-item class="eagle-text-form-item eagle-choose-input" :class="border?'eagle-item-boder':''" ref="uFormItem" :label-position="labelPositionVal" :label="label||title" :required="required||onlyShowRequired" :prop="prop" :label-width="labelWidth">
        <view class="choose-input-view">
            <span class="input-placeholder" v-if="!$slots.default&&!names">{{placeholderVal}}</span>
            <span v-else>
                <span v-if="$slots.default">
                    <slot></slot>
                </span>
                <span v-else>{{names}}</span>
            </span>
        </view>
        <u-button class="choose-input-btn" type="primary" @click="funDialogShow">
            <u-icon size="12" name="plus"></u-icon>{{btnName}}
        </u-button>
        <popup-window :keyWordName="keyWordName" :showChoose="showChoose" :hasSearch="hasSearch" :queryParams="queryParams" v-model="myCodes" v-if="!customer" :customItem="customItem" :queryUrl="queryUrl" ref="popupWindow" :addUrl="addUrl" @clear="clear" :isMult="isMult" :headTitle="headTitle" :idField="idField" :textField="textField" :controller="controller" :dataType="dataType" :names.sync="myNames" :conditions="conditions" :isUseEnterprise="isUseEnterprise" @callBackChoosedData="callBackChoosedData">
            <template v-slot:body="scope">
                <view>
                    <slot name='popupBody' :item="scope.item"></slot>
                </view>
            </template>
        </popup-window>
    </u-form-item>
</template>

<script>
import popupWindow from "@/components/eagle-window-choose/popup-window.vue";
export default {
    name: "eagle-choose-input",
    components: { "popup-window": popupWindow },
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        queryUrl: {
            type: String,
            default: "",
        },

        names: {
            type: String,
            default() {
                return "";
            },
        },
        keyWordName: {
            type: String,
            default() {
                return "";
            },
        },
        btnName: {
            type: String,
            default() {
                return "选择";
            },
        },
        title: {
            type: [String],
            default: "",
        },
        label: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        // input|textarea是否显示边框
        border: {
            type: Boolean,
            default: true,
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: "76",
        },
        addUrl: {
            type: String,
            default() {
                return "";
            },
        },
        headTitle: {
            type: String,
            default() {
                return "";
            },
        },
        idField: {
            type: String,
            default() {
                return "id";
            },
        },
        textField: {
            type: String,
            default() {
                return "name";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        dataType: {
            type: String,
            default() {
                return "list";
            },
        },
        conditions: {
            type: Object,
            default: function () {
                return {};
            },
        },
        customer: {
            type: Boolean,
            default: false,
        },
        isMult: {
            type: Boolean,
            default() {
                return true;
            },
        },
        customItem: {
            type: Boolean,
            default: true,
        },
        isUseEnterprise: {
            type: Boolean,
            default: true,
        },
        queryParams: {
            type: Object,
            default: function () {
                return {};
            },
        },
        hasSearch: {
            type: Boolean,
            default() {
                return true;
            },
        },
        showChoose: {
            type: Boolean,
            default() {
                return true;
            },
        },
    },
    watch: {
        value(nVal, oVal) {
            if (this.myCodes != nVal) {
                this.myCodes = nVal;
            }
        },
        names(nVal, oVal) {
            if (this.myNames != nVal) {
                this.myNames = nVal;
            }
        },
    },
    data() {
        return {
            myCodes: this.value,
            myNames: this.names,
            placeholderVal: "",
            labelPositionVal: "",
            // defaultValue: "",
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请选择" + (this.title || this.label || "");
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        funDialogShow() {
            if (!this.customer) {
                this.$refs.popupWindow.show();
            }
            this.$emit("click");
        },
        setValues(codes, names) {
            this.$emit("update:names", names);
            this.$emit("update", codes);
        },
        callBackChoosedData(choosedData, codes, names) {
            this.setValues(codes, names);
            this.$emit("callBackChoosedData", choosedData);
        },
        valid() {
            let _this = this;
            if (_this.required) {
                if (!_this.value && _this.value !== 0) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else {
                    _this.$refs.uFormItem.validateState = "";
                    return true;
                }
            }
            return true;
        },
    },
};
</script>

<style scoped lang="scss">
</style>
