<template name="eagle-upload">
  <u-form-item
    ref="uFormItem"
    :label-position="labelPositionVal"
    :label="title"
    :required="required"
    :prop="prop"
    :label-width="labelWidth"
    :label-align="labelAlign"
  >
    <u-upload
      :max-size="maxSize"
      ref="uUpload"
      :isNeedEdit="isNeedEdit"
      :disabled="disabled"
      :file-list="defaultValue"
      :action="action"
      :show-tips="false"
      :deletable="deletable"
      :width="160"
      :height="160"
      @on-success="onSuccess"
      @on-remove="onRemove"
      :before-upload="beforeUpload"
      :show-progress="showProgress"
      :max-count="maxCount"
      :header="uploadHead"
      :limitType="limitType"
      :showTips='showTips'
    >
    </u-upload>
    <u-toast ref="uToast" />
  </u-form-item>
</template>

<script>
export default {
  name: "eagle-upload",
  props: {
    value: {
      type: [String],
      default: ""
    },
    title: {
      type: [String],
      default: ""
    },
    prop: {
      type: [String],
      default: ""
    },

    showProgress: {
      type: Boolean,
      default: false
    },
    showTips: {
      type: Boolean,
      default: false
    },

    limitType: {
      type: Array,
      default() {
        return ["png", "jpg", "jpeg", "webp", "gif", "image"];
      }
    },
    maxCount: {
      type: Number,
      default: 3
    },
    maxSize: {
      type: Number,
      default: 52428800
    },

    required: {
      type: Boolean,
      default: false
    },
    onlyShowRequired: {
      type: Boolean,
      default: false
    },
    deletable: {
      type: Boolean,
      default: true
    },
    labelPosition: {
      type: String,
      default: ""
    },
    labelWidth: {
      type: String,
      default: "120"
    },
    disabled: {
      type: [Boolean],
      default() {
        return false;
      }
    },
    // 高度，单位rpx
    height: {
      type: [Number, String],
      default: ""
    },
    placeholder: {
      type: String,
      default: ""
    },
    hasPadding: {
      type: Boolean,
      default: true
    },
    labelAlign: {
      type: String,
      default: "left"
    },

    //拍照是否需要编辑图片 仅仅适用于App端交互
    isNeedEdit: {
      type: Boolean,
      default: false
    }
    // applicationId: {
    // 	type: [String],
    // 	default: '72e7d4a7e78643af9a33289d2b82253b'
    // },
    // appSecretKey: {
    // 	type: [String],
    // 	default: 'XtJMTI2e3fRChHA8vg7rUSN4dZKyD0FWuOY6'
    // },
  },
  data() {
    return {
      action: process.env.VUE_APP_BASE_API + "/file/upload",
      // action: "/prod-api/file/upload",
      labelPositionVal: "",
      defaultValue: [],
      inputHeight: 70, // input的高度
      textareaHeight: 100, // textarea的高度
      validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
      focused: false, // 当前是否处于获得焦点的状态
      showPassword: false, // 是否预览密码
      lastValue: "", // 用于头条小程序，判断@input中，前后的值是否发生了变化，因为头条中文下，按下键没有输入内容，也会触发@input时间
      // uploadFrom: {
      // 	applicationId: this.applicationId,
      // 	companyId: this.companyId
      // },
      uploadHead: { Authorization: "" },
      placeholderVal: ""
      // companyId: "a4328d3ee06c13cc4d3e76f4a0a5a220",
    };
  },
  created() {
    this.bindVal(this.value);
    this.placeholderVal = this.placeholder
      ? this.placeholder
      : "请上传" + (this.title ? this.title : "文件");
    this.labelPositionVal = this.labelPosition
      ? this.labelPosition
      : this.consts.constLabelPosition;
    //let userInfo = uni.getStorageSync('userInfo');
    // this.companyId=userInfo.CompanyCode;
    var token = uni.getStorageSync("token");
    this.uploadHead.Authorization = "Bearer " + token;
  },
  watch: {
    value(newValue, oldValue) {
      if (newValue != oldValue) {
        this.bindVal(newValue);
        if (!newValue) {
          this.$refs.uUpload.lists = [];
        }
      }
    }
  },
  methods: {
    bindVal(val) {
      console.log("val: ", val);
      if (val) {
        let me = this;
        let arry = val.split(";");
        arry.forEach(function (item) {
          me.defaultValue.push({
            url: item,
            progress: 100
          });
        });
      } else {
        this.defaultValue = [];
      }
    },
    clear() {
      this.$refs.uUpload.lists = [];
      this.$emit("input", "");
      this.$refs["uUpload"].clear();
    },
    beforeUpload() {},
    onRemove(index, lists) {
      this.imageUploads();
    },
    onSuccess(res, index) {
      let lists = this.$refs.uUpload.lists;
      if (res.code == 200) {
        var list = lists[index];
        console.log(list);
        list.url = res.data.filePath;
      } else {
        lists.splice(index, 1);
      }
      this.$emit("uploadSuccess", res.data);
      this.imageUploads();
    },
    imageUploads() {
      let files = [];
      let filePath = [];
      files = this.$refs.uUpload.lists.filter((val) => {
        return val.progress == 100;
      });
      files.forEach(function (item) {
        filePath.push(item.url);
      });
      this.defaultValue = files;
      this.$emit("input", filePath.join(";"));
      

      this.valid();
    },
    valid() {
      let _this = this;
      if (_this.required && _this.onlyShowRequired == false) {
        if (!_this.defaultValue || this.defaultValue.length <= 0) {
          _this.$refs.uFormItem.validateState = "error";
          _this.$refs.uFormItem.validateMessage = _this.placeholderVal;
          return false;
        } else if (
          _this.$refs.uFormItem.validateMessage === _this.placeholderVal
        ) {
          _this.$refs.uFormItem.validateState = "";
        }
      }
      return true;
    }
  }
};
</script>

<style lang="scss"></style>
