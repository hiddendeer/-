<template name="eagle-upload">
	<view>
		<u-upload ref="uUpload" :action="action" :show-tips="false" @on-remove="onRemove" :limit-type="limitType"
			:before-upload="beforeUpload">
			
			</u-upload>

	</view>
</template>

<script>
	export default {
		name: "eagle-upload",
		data() {
			return {
				action: "/api/Attachment/UploadFile",
				limitType: ["pdf"]
			};
		},
		methods: {
			beforeUpload() {},
			onRemove(index, lists) {
				console.log('图片已被移除')
			},
		}
	}
</script>


<style lang="scss">

</style>
