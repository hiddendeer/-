<template>
    <view>
        <Myunifab :pattern="pattern" :content="content" :horizontal="horizontal" :vertical="vertical" :icon="icon" :direction="direction" :popMenu='popMenu' @trigger="trigger" @fabClick='fabClick'></Myunifab>
    </view>
</template>

<script>
import Myunifab from './uni-fab/components/uni-fab/uni-fab.vue'
export default {
    name: "eagle-fab",
    components: { Myunifab },
    props: {
        icon: {
            type: String,
            default: 'plusempty',
        },
        pattern: {
            type: Object,
            default: () => {
                return {
                    color: '#3c3e49',
                    selectedColor: '#007AFF',
                    backgroundColor: '#fff',
                    buttonColor: '#007AFF',
                }
            }
            // {----配置对象的属性，均为字符串
            // 	color 文字默认颜色
            //  selectedColor 文字选中时的颜色
            //  backgroundColor	背景色
            //  buttonColor	按钮背景色
            //  }				
        },
        content: {
            type: Array,
            default: () => []
            //数组中为对象，下面为对象属性
            // iconPath	图片路径
            // selectedIconPath	选中后图片路径
            // text	文字
            // active	是否选中当前--布尔值
        },
        horizontal: {
            //水平对齐方式。left:左对齐，right：右对齐
            type: String,
            default: 'left',
        },
        vertical: {
            //垂直对齐方式。bottom:下对齐，top：上对齐
            type: String,
            default: 'bottom',
        },
        direction: {
            //展开菜单显示方式。horizontal:水平显示，vertical：垂直显示
            type: String,
            default: 'horizontal'
        },
        popMenu: {
            //是否使用弹出菜单
            type: Boolean,
            default: true
        },
    },
    methods: {
        /**展开菜单点击事件  index为下标，item为content里面的属性
         * @param {Object} index
         * @param {Object} item
         */
        trigger(index, item) {
            this.$emit('trigger', index, item)
        },
        /**
         * 点击悬浮按钮的事件
         */
        fabClick() {
            this.$emit('fabClick')
        }
    },
}
</script>

<style>
</style>
