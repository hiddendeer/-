<template>

    <u-form-item style="display:block" class="eagle-text-form-item" ref="uFormItem" :label-position="labelPositionVal" :label="title" :required="required||onlyShowRequired" :prop="prop" :label-width="labelWidth">
        <u-input :type="type" v-if="!disabled" fontSize="16px" :placeholder="placeholderVal" message="" v-model="defaultValue" :input-align="inputAlign" :maxlength="maxlength" :placeholder-style="placeholderStyle" :confirm-type="confirmType" :custom-style="customStyle" :fixed="fixed" :focus="focus" :password-icon="passwordIcon" :border="border" :border-color="borderColor" :auto-height="autoHeight" :select-open="selectOpen" :height="height" @focus="onFocus" @blur="handleBlur" @input="handleInput" @confirm="onConfirm" />
        <view v-else-if="height" style="font-size: 16px;" :style="{minHeight: height + 'rpx',lineHeight: height + 'rpx',width: '100%',}">
            {{defaultValue}} <slot></slot>
        </view>

        <view v-if="isChoose">
            <u-button size="mini" type="primary" plain @click="choose" :throttle-time="0">{{sufButton}}</u-button>
        </view>
        <view v-if="$slots.topBotton" class="top-botton-block">
            <slot name="topBotton"></slot>
        </view>

    </u-form-item>
</template>

<script>
export default {
    name: "eagle-textbox",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        // 输入框的类型，textarea，text，number
        type: {
            type: String,
            default: "text",
        },
        inputAlign: {
            type: String,
            default: "left",
        },
        placeholder: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        sufButton: {
            type: String,
            default: "选择",
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        maxlength: {
            type: [Number, String],
            default: -1,
        },
        placeholderStyle: {
            type: String,
            default: "color: #c0c4cc;",
        },
        confirmType: {
            type: String,
            default: "done",
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        // 输入框的自定义样式
        customStyle: {
            type: Object,
            default() {
                return {};
            },
        },
        // 如果 textarea 是在一个 position:fixed 的区域，需要显示指定属性 fixed 为 true
        fixed: {
            type: Boolean,
            default: false,
        },
        // 是否自动获得焦点
        focus: {
            type: Boolean,
            default: false,
        },
        // 密码类型时，是否显示右侧的密码图标
        passwordIcon: {
            type: Boolean,
            default: true,
        },
        // input|textarea是否显示边框
        border: {
            type: Boolean,
            default: false,
        },
        // 输入框的边框颜色
        borderColor: {
            type: String,
            default: "#dcdfe6",
        },
        autoHeight: {
            type: Boolean,
            default: true,
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        // type=select时，旋转右侧的图标，标识当前处于打开还是关闭select的状态
        // open-打开，close-关闭
        selectOpen: {
            type: Boolean,
            default: false,
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: "56",
        },

        // 是否自动去除两端的空格
        trim: {
            type: Boolean,
            default: true,
        },

        isNumber: {
            type: Boolean,
            default: false,
        },
        isChoose: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            industrySelectShow: false,
            heightVal:
                this.height != ""
                    ? this.height
                    : this.type === "textarea"
                    ? "60px"
                    : "20px",
            placeholderVal: "",
            labelPositionVal: "",
            defaultValue: this.value,
            inputHeight: 70, // input的高度
            textareaHeight: 100, // textarea的高度
            validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
            focused: false, // 当前是否处于获得焦点的状态
            showPassword: false, // 是否预览密码
            lastValue: "", // 用于头条小程序，判断@input中，前后的值是否发生了变化，因为头条中文下，按下键没有输入内容，也会触发@input时间
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请输入" + (this.title ? this.title : "内容");
        // 监听u-form-item发出的错误事件，将输入框边框变红色
        //this.$on('on-form-item-error', this.onFormItemError);
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        // if (this.disabled) {
        //     if (this.value == null || this.value == "") {
        //         this.defaultValue = "无";
        //     }
        // }
    },
    watch: {
        defaultValue(nVal, oVal) {
            if (this.defaultValue != oVal) {
                if (this.isNumber) {
                    this.$nextTick(function () {
                        nVal = nVal + "";

                        this.defaultValue = Number(
                            nVal.toString().match(/^\d+(?:\.\d{0,2})?/)
                        );
                    });
                } else {
                    this.defaultValue = nVal;
                }

                this.$emit("input", this.defaultValue);
            }
        },
        value(nVal, oVal) {
            this.defaultValue = this.value;
            this.$emit("input", this.defaultValue);
        },
        placeholder(nVal, oVal) {
            if (nVal != oVal) {
                this.placeholderVal = nVal;
            }
        },
    },
    methods: {
        // industryInformation(val) {
        //     this.$emit("industryInformation", val);
        //     this.industrySelectShow = false;
        // },

        /**
         * change 事件
         * @param event
         */
        handleInput(value) {
            var _this = this;
            // 判断是否去除空格
            if (_this.trim) value = _this.$u.trim(value);
            // vue 原生的方法 return 出去
            _this.$emit("input", value);
            // 当前model 赋值
            _this.defaultValue = value;
            // 过一个生命周期再发送事件给u-form-item，否则this.$emit('input')更新了父组件的值，但是微信小程序上
            // 尚未更新到u-form-item，导致获取的值为空，从而校验混论
            // 这里不能延时时间太短，或者使用this.$nextTick，否则在头条上，会造成混乱
            // setTimeout(() => {
            // 	// 头条小程序由于自身bug，导致中文下，每按下一个键(尚未完成输入)，都会触发一次@input，导致错误，这里进行判断处理
            // 	// #ifdef MP-TOUTIAO
            // 	if (_this.$u.trim(value) == _this.lastValue) return;
            // 	_this.lastValue = value;
            // 	// #endif
            // 	// 将当前的值发送到 u-form-item 进行校验
            // 	_this.dispatch('u-form-item', 'on-form-change', value);
            // }, 40)
        },
        /**
         * blur 事件
         * @param event
         */
        handleBlur(value) {
            var _this = this;
            // 最开始使用的是监听图标@touchstart事件，自从hx2.8.4后，此方法在微信小程序出错
            // 这里改为监听点击事件，手点击清除图标时，同时也发生了@blur事件，导致图标消失而无法点击，这里做一个延时
            setTimeout(() => {
                _this.focused = false;
            }, 100);
            // vue 原生的方法 return 出去
            _this.$emit("blur", value);
            this.valid();
        },
        onFormItemError(status) {
            this.validateState = status;
        },
        onFocus(event) {
            this.focused = true;
            this.$emit("focus");
        },
        onConfirm(e) {
            this.$emit("confirm", e.detail.value);
        },
        onClear(event) {
            this.$emit("input", "");
        },
        inputClick() {
            this.$emit("click");
        },
        choose() {
            // if (this.isSelect) {
            //     this.industrySelectShow = true;
            // } else {
            //     this.$emit("choose");
            // }
            this.$emit("choose");
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue && _this.defaultValue !== 0) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.eagle-textbox-block {
    // /deep/.u-input__textarea {
    //     font-size: 16px;
    // }
    .eagle-text-form-item {
        position: relative;
    }
    .top-botton-block {
        position: absolute;
        right: 0px;
        top: 5px;
    }
}
</style>
