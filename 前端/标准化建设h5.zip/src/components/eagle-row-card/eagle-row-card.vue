<template>
    <view class="eagle-row-card">
        <view class="card-content" :class="$slots.tag ? 'mt10' : ''">
            <view class="card-content-img" v-if="hasImg">
                <eagle-img :src="imgSrc ? imgSrc : defaultImg" :width="imgWidth" :height="imgHeight" :previewFullImage="previewFullImage" :showCount="showCount"></eagle-img>
            </view>
            <view class="card-content-body" @click="click">
                <slot></slot>
                <view class="card-tag" v-if="$slots.tag">
                    <slot name="tag"></slot>
                </view>
                <view v-if="!$slots.tag && tagName" class="status-tag">
                    <view :class="tagType">{{ tagName }}</view>
                </view>
                <view class="row-btn">
                    <slot name="rowBtn"> </slot>
                </view>
            </view>
        </view>
        <view class="grid-bottom-btn" v-if="hasButton || $slots.button">
            <view class="span-group">
                <slot name="span-group"> </slot>
            </view>
            <view class="eagle-button-group">
                <slot name="button"> </slot>
            </view>
            <!-- <slot name="button"></slot> -->
        </view>
    </view>
</template>
<script>
export default {
    components: {},
    name: "eagle-row-card",
    props: {
        imgSrc: { type: String, default: "" },
        hasImg: { type: Boolean, default: false },
        hasButton: { type: Boolean, default: false },
        tagName: { type: String, default: "" },
        tagType: { type: String, default: "" },
        imgWidth: { type: String, default: "200rpx" },
        imgHeight: { type: String, default: "160rpx" },
        previewFullImage: { type: Boolean, default: true },
        title: { type: String, default: "" },
        statusStr: { type: String, default: "" },
        ststusType: { type: String, default: "info" },
        showCount: { type: Number, default: 1 },
    },
    data() {
        return {
            defaultImg: require("@/static/img/no-img.png"),
        };
    },
    methods: {
        click() {
            this.$emit("click");
        },
    },
};
</script>

<style lang="scss">
.eagle-row-card {
    background: #fff;
    margin: $spacing-base;
    margin-top: 0px;
    padding: $spacing-base;
    border-radius: $border-radius-base;
    position: relative;

    .card-content {
        display: flex;
        font-size: $font-base;
        overflow: hidden;
        width: 100%;
        // margin-bottom: 10px;

        .card-content-img {
            margin-right: 20rpx;
        }

        .card-content-body {
            flex: 1 1;
            line-height: $line-height-base;
            justify-content: space-between;
            overflow: hidden;

            .card-tag {
                font-size: 24rpx;
            }

            .row-btn {
                position: absolute;
                right: 20rpx;
                bottom: 20rpx;

                /deep/.u-btn {
                    margin-left: 20rpx;
                }
            }
        }
    }

    .grid-bottom-btn {
        font-size: $font-sm;
        color: #666666;
        padding-top: 5px;
        text-align: right;
        // border-top: 1px solid $border-color-base;
    }

    .u-icon {
        margin-right: 8rpx;

        color: $grid-row-base;
        size: 28;
    }

    /deep/ .u-icon {
        color: #0088ff;
    }
}
</style>
