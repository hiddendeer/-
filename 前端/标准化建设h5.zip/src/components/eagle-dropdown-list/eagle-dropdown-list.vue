<template name="eagle-dropdown-list">
	<view class="">
		<view class="u-m-p-50">
			<view class="u-demo-area u-flex u-row-center">
				<u-dropdown :close-on-click-mask="mask" ref="uDropdown" :activeColor="activeColor"
					:borderBottom="borderBottom">
					<eagle-dropdown-item v-for="(item,index) in this._list" @change="change" :title="item.title"
						:prop-name="item.propName" :options="item.data" :key="index" v-model="values[index]">
					</eagle-dropdown-item>
				</u-dropdown>
			</view>
		</view>
	</view>
</template>
<script>
	export default {
		name: 'eagle-dropdown-list',
		props: {
			value: {
				default: Object,
				default: {}
			},
			dataSource: {
				type: Array,
				default: null
			},

		},
		data() {
			return {
				values: [],
				mask: true,
				borderBottom: false,
				activeColor: '#2979ff',
				active: false,
				checkValue: {}
			}
		},
		computed: {
			_list: {
				get() {
					return this.dataSource;
				},
				set(value) {
					this._list = value;
					this.$emit("update:dataSource", value);
					console.log(this._list)
				}
			},

		},
		created() {},
		methods: {
			change(val, propName) {
				this.$set(this.checkValue, propName, val);
				this.$emit('input', this.checkValue);
				this.$emit('change');
			},
			


		}
	}
</script>

<style scoped lang="scss">
	.u-config-wrap {
		padding: 40rpx;
	}

	.slot-content {
		background-color: #FFFFFF;
		padding: 24rpx;

		.item-box {
			margin-bottom: 50rpx;
			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;

			.item {
				border: 1px solid $u-type-primary;
				color: $u-type-primary;
				padding: 8rpx 40rpx;
				border-radius: 100rpx;
				margin-top: 30rpx;
			}

			.active {
				color: #FFFFFF;
				background-color: $u-type-primary;
			}
		}
	}

	.wrap {
		display: flex;
		flex-direction: column;
		height: calc(100vh - var(--window-top));
		width: 100%;
	}

	.swiper-box {
		flex: 1;
	}

	.swiper-item {
		height: 100%;
	}
</style>
