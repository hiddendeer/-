<template>
    <view class="wrapper" v-show="isShowMask">
        <transition name="content">
            <view class="content_view" v-show="isShow">
                <view class="title_view">
                    <view class="close_view" @click="hidden">取消
                        <!-- <icon class="close_icon" :type="'clear'" size="26"/> -->
                    </view>

                    <view class="title">目录选择</view>

                    <view class="close_view" @click="submit">确定</view>
                </view>
                <view class="select_top">
                    <view class="select_top_item" ref="select_top_item" v-for="(item,index) in dataList" :key="index" @click="select_top_item_click(item,index)">
                        <text class="address_value" v-if="index === dataList.length-1" style="color: #2979ff;">{{item}}</text>

                        <text class="address_value" v-else>{{item}}</text>
                    </view>
                    <view v-if="isindicatorStyleLeft" class="indicator" :style="{ left: indicatorStyleLeft + 'px' }" ref="indicator"></view>
                </view>
                <swiper class="swiper" :current="currentIndex" @change="swiperChange">
                    <swiper-item v-for="(swiper_item,swiper_index) in dataLists" :key="swiper_index">
                        <view class="swiper-item">
                            <scroll-view class="scroll-view-item" scroll-y="true">
                                <view class="address_item" v-for="(item,index) in cityAreaArray[swiper_index]" :key="index" @click="address_item_click(swiper_index,index)">
                                    <!-- <image v-if="selectIndexArr[swiper_index] === index" class="address_item_icon" src="../../static/yixuan-selectAddress/gou.png" mode=""></image> -->
                                    <view v-if="selectIndexArr[swiper_index] === index" style="    color: #2979ff;">
                                        {{item.opName}}
                                    </view>
                                    <view v-else>
                                        {{item.opName}}
                                    </view>
                                </view>
                            </scroll-view>
                        </view>
                    </swiper-item>
                </swiper>
            </view>
        </transition>
        <view class="mask" @click="hidden" v-show="isShowMask"></view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            companyCode: "",
            Type: "company",
            isindicatorStyleLeft: true,
            isShow: false,
            isShowMask: false,
            dataList: ["请选择"],
            dataListCode: ["请选择"],
            dataLists: [],
            currentIndex: 0,
            cityData: {},
            cityAreaArray: [],
            params: {},
            selectIndexArr: [],
            indicatorStyleLeft: 16,
        };
    },
    methods: {
        /**
         * 构造树型结构数据
         * @param {*} data 数据源
         * @param {*} id id字段 默认 'id'
         * @param {*} parentId 父节点字段 默认 'parentId'
         * @param {*} children 孩子节点字段 默认 'children'
         */
        handleTree(data, id, parentId, children) {
            let config = {
                id: id || "id",
                parentId: parentId || "parentId",
                childrenList: children || "children",
            };

            var childrenListMap = {};
            var nodeIds = {};
            var tree = [];

            for (let d of data) {
                let parentId = d[config.parentId];
                if (childrenListMap[parentId] == null) {
                    childrenListMap[parentId] = [];
                }
                nodeIds[d[config.id]] = d;
                childrenListMap[parentId].push(d);
            }

            for (let d of data) {
                let parentId = d[config.parentId];
                if (nodeIds[parentId] == null) {
                    tree.push(d);
                }
            }

            for (let t of tree) {
                adaptToChildrenList(t);
            }

            function adaptToChildrenList(o) {
                if (childrenListMap[o[config.id]] !== null) {
                    o[config.childrenList] = childrenListMap[o[config.id]];
                }
                if (o[config.childrenList]) {
                    for (let c of o[config.childrenList]) {
                        adaptToChildrenList(c);
                    }
                }
            }
            return tree;
        },

        getListData() {
            // uni.showToast({
            // 	icon: "loading"
            // });
            // this.loadStatus = "loading";
            this.loading = true;

            this.params.dataType = this.Type;
            if (this.companyCode) {
                this.params.companyCode = this.companyCode;
            }
            this.common
                .get("support/TplOp/getEagleOrgan", this.params)
                .then((res) => {
                    this.loading = false;
                    if (res.code == 200) {
                        let datas = res.data;
                        let list = this.handleTree(
                            datas,
                            "opNo",
                            "opPno",
                            "children"
                        );

                        this.dataLists = list[0].children;
                        // this.List = datas;
                        // this.rightView = datas[0]
                        // // this.List.concat(datas);
                        console.log("http===>", this.dataLists);
                        this.cityAreaArray.push(this.dataLists);
                    }
                });
        },
        show(type, companyCode) {
            if (companyCode) {
                this.companyCode = companyCode;
            }
            this.Type = type;
            this.isShow = true;
            this.isShowMask = true;
            // this.dataList= ['请选择'],
            // this.dataListCode= ['请选择'],
            // this.dataLists=[],
            // this.currentIndex= 0,
            // this.cityData= {},
            // this.cityAreaArray= [],
            this.getListData();
        },
        goinfo() {
            this.dataList = ["请选择"];
            this.dataListCode = ["请选择"];
            this.dataLists = [];
            this.currentIndex = 0;
            this.cityData = {};
            this.cityAreaArray = [];
            this.isindicatorStyleLeft = false;
        },
        hidden() {
            this.isShow = false;
            setTimeout(() => {
                this.isShowMask = false;
            }, 500);
            this.$emit("ShowMask", false);
        },
        select_top_item_click(item, index) {
            if (item !== "请选择") {
                this.currentIndex = index;
                this.dataList.splice(index + 1, this.dataList.length);
                this.dataList.push("请选择");
                this.$nextTick(() => {
                    this.changeIndicator(index);
                });
            }
            console.log("http===item>", item);
        },
        swiperChange(event) {
            let index = event.detail.current;
            this.currentIndex = index;

            this.changeIndicator(index);
        },
        changeIndicator(index) {
            /*
				let itemWidth = this.$refs.select_top_item[index].$children[0].$el.offsetWidth
				if (itemWidth > 80){
					itemWidth = 80
				}
				let itemCenterX = 10 + index * 80 + itemWidth / 2
				let indicatorWidth = this.$refs.indicator.$el.offsetWidth
				this.$refs.indicator.$el.style.left = itemCenterX - indicatorWidth / 2 + 'px'
				*/
            let indicatorWidth = 30;
            const query = uni.createSelectorQuery().in(this);
            let arr = query.selectAll(".select_top_item .address_value");
            arr.fields(
                {
                    size: true,
                    scrollOffset: false,
                },
                (data) => {
                    let itemWidth =
                        data[index]["width"] > 80 ? 70 : data[index]["width"];
                    let itemCenterX = 10 + index * 80 + itemWidth / 2;
                    let left = itemCenterX - indicatorWidth / 2;

                    // console.log('changeIndicator',itemWidth,index)

                    this.indicatorStyleLeft = left;
                }
            ).exec();
        },
        //确定按钮
        submit() {
            var list = [...this.dataList];
            list.splice(list.length - 1, 1);
            this.dataListCode.splice(this.dataListCode.length - 1, 1);
            console.log(
                "http===length>",
                list,
                this.dataListCode[this.dataListCode.length - 1]
            );
            if (this.Type && list && this.dataListCode) {
                this.$emit(
                    "selectAddress",
                    this.Type,
                    list[list.length - 1],
                    this.dataListCode[this.dataListCode.length - 1]
                );
            }
            this.hidden();
        },
        address_item_click(swiper_index, index) {
            this.isindicatorStyleLeft = true;
            // console.log(swiper_index,index)
            this.selectIndexArr.splice(swiper_index, 5, index);
            //判断当前是否为最下一级
            if (swiper_index === 0) {
                //第一级

                let currentObj = this.dataLists[index];
                let city = currentObj.opName;
                let Code = currentObj.opCode;

                this.dataList.splice(swiper_index, 5, city);
                this.dataList.splice(swiper_index + 1, 0, "请选择");

                this.dataListCode.splice(swiper_index, 5, Code);
                this.dataListCode.splice(swiper_index + 1, 0, "请选择");
                this.cityAreaArray.splice(
                    swiper_index + 1,
                    1,
                    currentObj["children"]
                );
                setTimeout(() => {
                    this.currentIndex = 1;
                    this.changeIndicator(1);
                }, 50);
            } else {
                let currentAreaArray = this.cityAreaArray[swiper_index];
                let currentObj = currentAreaArray[index];
                let area = currentObj["children"];
                // console.log(currentAreaArray)
                if (area !== undefined) {
                    let city = currentObj.opName;
                    let Code = currentObj.opCode;
                    this.dataList.splice(swiper_index, 5, city);
                    this.dataList.splice(swiper_index + 1, 0, "请选择");
                    this.dataListCode.splice(swiper_index, 5, Code);
                    this.dataListCode.splice(swiper_index + 1, 0, "请选择");
                    this.cityAreaArray.splice(
                        swiper_index + 1,
                        1,
                        currentObj["children"]
                    );

                    setTimeout(() => {
                        this.currentIndex = swiper_index + 1;
                        this.changeIndicator(swiper_index + 1);
                    }, 50);
                } else {
                    //是最下一级

                    let city = currentObj.opName;
                    let Code = currentObj.opCode;
                    this.dataList.splice(swiper_index, 1, city);
                    this.dataListCode.splice(swiper_index, 5, Code);
                    //选择成功返回数据
                    // this.$emit("selectAddress", this.dataList.join(''))
                    this.$emit(
                        "selectAddress",
                        this.Type,
                        this.dataList[this.dataList.length - 1],
                        this.dataListCode[this.dataListCode.length - 1]
                    );

                    this.$nextTick(() => {
                        this.changeIndicator(swiper_index);
                    });
                    //如果不需要选完最后一层关闭将以下代码注释
                    setTimeout(() => {
                        this.isShow = false;
                    }, 100);
                    setTimeout(() => {
                        this.isShowMask = false;
                    }, 500);
                    this.$emit("ShowMask", false);
                }
            }
        },
    },
    created() {
        // this.cityData = cityData
        // this.cityAreaArray.push(cityData)
    },
    mounted() {
        // this.changeIndicator(0)
    },
};
</script>

<style lang="scss">
// 不换行
@mixin no-wrap() {
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.wrapper {
    z-index: 1999;
    position: absolute;
    top: -44px;
    left: 0;
    bottom: 0;
    right: 0;
    .content_view {
        z-index: 999;
        background: white;
        position: absolute;
        height: 80%;
        left: 0;
        bottom: 0;
        right: 0;
        border-top-left-radius: 20px;
        border-top-right-radius: 20px;
        .title_view {
            // height: 12%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 $uni-spacing-row-sm;
            .title {
                font-size: uni-font-size-sm;
            }
            .close_view {
                height: 60px;
                width: 60px;
                display: flex;
                justify-content: center;
                align-items: center;
            }
        }
        .select_top {
            height: 5%;
            display: flex;
            justify-content: start;
            align-items: center;
            padding: 10px;
            position: relative;
            box-sizing: border-box;
            .select_top_item {
                width: 80px;
                font-size: 14px;
                @include no-wrap();
            }
            .indicator {
                position: absolute;
                width: 30px;
                height: 2px;
                background: #2979ff;
                left: 16px;
                bottom: 0;
                transition: left 0.5s ease;
            }
        }
        .swiper {
            height: 80%;
            position: relative;
            left: 0;
            top: 0;
            bottom: 0;
            right: 0;
            .swiper-item {
                height: 100%;
                .scroll-view-item {
                    height: 100%;
                    padding: 0 10px;
                    .address_item {
                        padding: 5px 0;
                        font-size: 14px;
                        display: flex;
                        align-items: center;
                        .address_item_icon {
                            width: 20px;
                            height: 20px;
                            margin-right: 10px;
                        }
                    }
                }
            }
        }
    }
    .mask {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background: $uni-text-color-grey;
        opacity: 0.7;
    }
}

.content-enter {
    transform: translateY(100%);
}
.content-enter-to {
    transform: translateY(0%);
}
.content-enter-active {
    transition: transform 0.5s;
}
.content-leave {
    transform: translateY(0%);
}
.content-leave-to {
    transform: translateY(100%);
}
.content-leave-active {
    transition: transform 0.5s;
}
</style>
