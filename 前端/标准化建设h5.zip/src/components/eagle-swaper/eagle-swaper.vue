<template>
    <view class="eagle-swaper">
        <view>
            <scroll-view scroll-x="true" class="scroll">
                <view class="scroll-item" v-for="(item,index) in list" :key="index" @tap="handleSelected(index)" :class="{'on':item.selected}">
                    <view class="">
                        {{ item[name] || item['name']}}
                    </view>
                </view>
            </scroll-view>
        </view>
    </view>
</template>

<script>
export default {
    name: "eagle-swaper",
    props: {
        //需循环的标签列表
        list: {
            type: Array,
            default() {
                return [];
            },
        },
        current: {
            type: [Number, String],
            default: 0,
        },
    },
    data() {
        return {};
    },
    methods: {
        handleSelected(index) {
            this.$emit("currentIndex");
            this.list[index].selected = true;
            for (let i = 0; i < this.list.length; i++) {
                if (i != index) {
                    this.list[i].selected = false;
                }
            }
        },
    },
};
</script>

<style scoped lang="scss">
.eagle-swaper {
    .container {
        height: 100vh;
    }

    .scroll {
        background-color: #eed8ae;
        border-bottom: 1upx solid #999999;
        white-space: nowrap; /*必须要有，规定段落中的文本不进行换行*/
    }

    .scroll-item {
        color: #333333;
        width: 150upx;
        text-align: center;
        height: 60upx;
        line-height: 60upx;
        display: inline-block; /*必须要有*/
    }

    .on {
        border-bottom: 2px solid orange;
        color: orange;
        border-radius: 40upx;
        font-size: 24px;
        font-weight: bolder;
    }
}
</style>