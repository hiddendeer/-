<template name='eagle-checkbox-group'>
    <!-- <view class="eagle-item eagle-checkbox-group" style="background: #FFFFFF;">
        <view style="padding: 0 30rpx;"> -->
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :prop="prop" :label-width="labelWidth">
        <u-checkbox-group @change="checkboxGroupChange" :max="max" :disabled="disabled" :label-disabled="labelDisabled" :active-color="activeColor" :shape="shape" :wrap="wrap">
            <u-checkbox :style="{'width':checkBoxWidth}" @change="checkboxChange" v-model="item.checked" v-for="(item, index) in items" :key="index" :value="item.id" :name="item.id">{{item.name}}</u-checkbox>
        </u-checkbox-group>
    </u-form-item>
    <!-- </view>
    </view> -->
</template>
<script>
export default {
    name: "eagle-checkbox-group",
    // model: {    // 使用model， 这儿2个属性，prop属性说，我要将msg作为该组件被使用时（此处为aa组件被父组件调用）v-model能取到的值，event说，我emit ‘cc’ 的时候，参数的值就是父组件v-model收到的值。
    //       prop: 'value',
    //       event: 'input'
    //     },
    props: {
        value: {
            type: [String, Boolean],
            default: "",
        },
        prop: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        disabledValues: {
            type: String,
            default() {
                return "";
            },
        },
        checkedValues: {
            type: String,
            default() {
                return "";
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        activeColor: {
            type: String,
            default() {
                return "#2979ff";
            },
        },
        shape: {
            type: String,
            default() {
                return "square";
            },
        },
        labelDisabled: false,
        disabled: false,
        max: {
            type: [Number, String],
            default() {
                return 999;
            },
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        checkBoxWidth: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        wrap: false,
        showCheckAll: false,
    },
    data() {
        return {
            items: [],
            checkedVals: "",
            labelPositionVal: "",
        };
    },
    created() {
        // console.log(" this.value: ", this.value);
        // this.checkedVals = this.value;

        this.$on("on-form-item-error", this.onFormItemError);
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请输入" + this.title;
        this.bind();
    },
    methods: {
        checkboxChange: function (e) {
            this.$emit("checkboxChange", e.name, e.value);
        },
        checkboxGroupChange: function (e) {
            this.checkedVals = e.join();
            this.$emit("input", this.checkedVals);

            this.$emit("checkboxGroupChange", e);
        },
        bind: function () {
            this.items = this.utils.deepClone(this.dataSource);
            let disabledArray = this.disabledValues
                ? this.disabledValues.split(",")
                : [];
            let checkedArray = this.value ? this.value.split(",") : [];
            this.items.forEach((item, index) => {
                if (checkedArray.includes(item.id)) {
                    this.$set(item, "checked", true);
                } else {
                    this.$set(item, "checked", false);
                }

                if (disabledArray.includes(item.id)) {
                    this.$set(item, "disabled", true);
                } else {
                    this.$set(item, "disabled", false);
                }
            });
        },
        valid() {
            let _this = this;
            console.log("_this.checkedVals: ", _this.checkedVals);
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.checkedVals) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
    watch: {
        // value: function(val) {
        // 	console.log("value: ",val);
        // 	//如果没有这个判断,每次value改变 都会去重新bind
        // 	if (this.checkedVals !== this.value) {
        // 		this.bind();
        // 	}
        // },

        value: {
            handler(val) {
                console.log("value: ", val);
                this.checkedVals = this.value;
                this.bind();
            },
            immediate: true,
        },

        dataSource: function () {
            this.bind();
        },
    },
};
</script>
<style>
.uni-list-cell {
    justify-content: flex-start;
    margin-top: 10rpx;
}
</style>
