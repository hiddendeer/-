<template name="eagle-form">
    <view class="eagleWrapForm">
        <view class="wrap eagle-form">
            <u-form :model="model" ref="uForm" :errorType="errorType" :rules="rules" :label-width="labelWidth" :label-align="labelAlign">
                <slot></slot>
            </u-form>
            <view class="form-bottom" :style="{height:marginBottom}"></view>
        </view>
        <!-- <scroll-view scroll-y :style="{ height: selfHeight?selfHeight:scrollHeight }">
           
        </scroll-view> -->
        <u-toast ref="uToast" />
        <eagle-comfirm ref='eagleConfirm'></eagle-comfirm>
    </view>

</template>

<script>
/**
 * form 表单
 * @property {Object} model 表单数据对象
 * @property {String} postUrl 提交表单add    接口地址 如果未传值 会用 Control/AddPost
 * @property {String} initUrl 获取初始化实体  接口地址 如果未传值 会用 Control/InitNewEntity
 * @property {String} detailUrl 获取编辑对象    接口地址 如果未传值 会用 Control/GetDetail
 * @property {String} control 后台Control名称
 */
export default {
    name: "eagle-form",
    props: {
        //value {Object}  传入的表单数据对象 赋值给model
        value: {
            type: Object,
            default() {
                return {};
            },
        },
        //postUrl 提交表单接口地址 如果未传值 会用调用 this.control + "/save"
        postUrl: {
            type: String,
            default() {
                return "";
            },
        },
        // delUrl 删除表单数据接口 如果未传值 会调用 this.control + "/deletes/" + this.model.id
        delUrl: {
            type: String,
            default() {
                return "";
            },
        },
        // initUrl 获取初始化实体接口地址 如果未传值 会调用 this.control + "/initData/0"
        initUrl: {
            type: String,
            default() {
                return "";
            },
        },
        // detailUrl 获取获取详情对象接口地址 如果未传值 会调用 this.control + "/getData/" + this.model.id
        detailUrl: {
            type: String,
            default() {
                return "";
            },
        },
        //control 后台control名称
        control: {
            type: String,
            default() {
                return "";
            },
        },

        // uView提供了多种校验的错误提示方式，传递给Form组件的errorType参数：
        // message：默认为输入框下方用文字进行提示
        // none：不会进行任何提示
        // border-bottom：配置作用域底部的下划线显示为红色，要求给form-item设置了borderBottom=true才有效
        // toast：以"toast"提示的方式弹出错误信息，每次只弹出最前面的那个表单域的错误信息

        errorType: {
            type: Array,
            default() {
                return ["message", "toast"];
            },
        },

        // outHeight 非滚动区域高度 用来计算滚动区域的高度
        // outHeight: {
        //     type: Number,
        //     default() {
        //         return 0;
        //     },
        // },

        //参考Uview官方文档 rules中的属性名和form的属性名是一致的，同时传递给u-form-item的prop参数绑定的也是相同的属性名，注意这里prop参数绑定的是 字符串(属性名)，而不是一个变量。
        rules: {
            type: Object,
            default() {
                return {};
            },
        },

        //boolInitData 是否需要初始化数据 有的地方不需要调用初始化接口来初始化相关数据
        boolInitData: {
            type: Boolean,
            default() {
                return true;
            },
        },

        // action 当前页面操作 init是初始化(一般新增页面使用) detail是详情(一般编辑or详情页面使用) 参数可以不传
        action: {
            type: String,
            default() {
                return "";
            },
        },
        //获取详情的时候 byCode是true的时候 接口调用 this.control +"/getDataByCode/" + this.model.code
        byCode: {
            type: Boolean,
            default() {
                return false;
            },
        },

        // label-width 提示文字的宽度，单位rpx（默认60）
        labelWidth: {
            type: String,
            default: "60",
        },
        //marginBottom 距离底部的高度
        marginBottom: {
            type: String,
            default: "65px",
        },

        // lable的对齐方式
        labelAlign: {
            type: String,
            default: "left",
        },

        //created方法里面逻辑是否被执行
        autoCreate: {
            type: Boolean,
            default() {
                return true;
            },
        },
        // 初始化接口是否传入companyCode
        isUseEnterprise: {
            type: Boolean,
            default() {
                return true;
            },
        },
        saveFunName: {
            type: String,
            default: "save",
        },
        queryParams: {
            type: Object,
            default: function () {
                return {};
            },
        },
        submitTotast: {
            type: String,
            default: "提交成功",
        },
    },
    data() {
        return {
            model: this.value,
            rulesVal: {},
            // scrollHeight: 600,
            initAction: "",
        };
    },
    created() {
        if (this.autoCreate) {
            if (this.$route.fullPath.indexOf("/view") > 0) {
                this.initAction = "detail";
            }
            if (this.$route.query.id) {
                this.model.id = this.$route.query.id;
                this.initAction = "detail";
                if (this.model.id == 0) {
                    this.initAction = "init";
                }
            } else if (this.$route.fullPath.indexOf("/detail") > 0) {
                if (!this.initUrl) {
                    this.model.id = 0;
                    this.initAction = "init";
                }
            }
            if (this.action) this.initAction = this.action;
            this.rulesVal = this.rules;
            if (this.boolInitData) {
                this.get();
            }
        }
    },
    watch: {
        value(nVal, oVal) {
            if (this.model !== nVal) {
                this.model = nVal;
            }
        },
    },
    mounted() {
        // this.resetTableHeight();
        this.setRules(this.rules);
    },
    methods: {
        refresh() {
            this.get();
        },
        post(config) {
            let _this = this;
            if (config && config.needValid === false) {
                if (config && typeof config.validCallback == "function") {
                    var flag = true;
                    flag = config.validCallback();
                    if (flag) {
                        _this.realPost(config);
                    }
                } else {
                    _this.realPost(config);
                }
            } else {
                if (!_this.valid()) return false;
                _this.$refs.uForm.validate((valid) => {
                    if (valid) {
                        var flag = true;
                        if (config && typeof config.validCallback == "function")
                            flag = config.validCallback();
                        if (flag) {
                            _this.realPost(config);
                        }
                    } else {
                        _this.$refs.uToast.show({
                            title: "验证失败",
                            type: "error",
                        });
                    }
                });
            }
        },
        validata(callBack) {
            if (!this.valid()) return false;
            this.$refs.uForm.validate((valid) => {
                if (valid) {
                    if (typeof callBack == "function") callBack();
                }
            });
        },

        realPost(config) {
            if (config && !config.UnShowLoading) {
                uni.showLoading({
                    mask: true,
                });
            }
            let _this = this;
            var url = config && config.url ? config.url : _this.getPostUrl();

            var model = config && config.model ? config.model : _this.model;

            _this.common.post(url, model).then(function (res) {
                if (res.code == 200) {
                    if (config && !config.UnShowMessage) {
                        _this.$refs.uToast.show({
                            title: _this.submitTotast,
                            type: "success",
                            callback: function () {},
                        });
                        if (
                            config &&
                            typeof config.successCallback == "function"
                        ) {
                            config.successCallback(res);
                        }
                        uni.hideLoading();
                    } else {
                        if (
                            config &&
                            typeof config.successCallback == "function"
                        ) {
                            config.successCallback(res);
                        }
                        if (config && !config.UnShowLoading) {
                            // uni.hideToast();
                            uni.hideLoading();
                        }
                    }
                } else {
                    if (config && !config.UnShowLoading) {
                        uni.hideLoading();
                    }
                    if (typeof config && config.errorCallback == "function") {
                        config.errorCallback(res);
                    }
                    // _this.$refs.uToast.show({
                    //     title: "提交失败:" + res.errorText,
                    //     type: "error",
                    //     callback: function () {
                    //         if (
                    //             typeof config &&
                    //             config.errorCallback == "function"
                    //         ) {
                    //             config.errorCallback(res);
                    //         }
                    //     },
                    // });
                }
            });
        },
        realDel(config) {
            let _this = this;
            uni.showLoading({
                mask: true,
            });
            var url = config && config.url ? config.url : _this.getDelUrl();
            this.common
                .del(url, null)
                .then(function (res) {
                    if (res.code == 200) {
                        _this.$refs.uToast.show({
                            title: "删除成功",
                            type: "success",
                            callback: function () {
                                if (
                                    typeof config.successCallback == "function"
                                ) {
                                    config.successCallback(res);
                                }
                            },
                        });
                    } else {
                        _this.$refs.uToast.show({
                            title: "删除失败：" + res.errMsg,
                            type: "error",
                            callback: function () {
                                if (typeof config.errorCallback == "function") {
                                    config.errorCallback(res);
                                }
                            },
                        });
                    }
                    uni.hideLoading();
                })
                .catch(function (res) {
                    uni.hideLoading();
                });
        },
        del(config) {
            let _this = this;
            // if (!config && !config.url && !_this.model.id && _this.model.id) {
            //     throw new Error("请配置id的值");
            // }

            this.$refs.eagleConfirm.showConfirm({
                content: "确认是否删除？",
                confirm: function () {
                    _this.realDel(config);
                },
                cancel: function () {
                    _this.$refs.uToast.show({
                        title: "取消删除了",
                        type: "error",
                    });
                },
            });
        },
        getAction() {
            return this.initAction;
        },
        confirm(content, callback, cancelBack) {
            this.$refs.eagleConfirm.showConfirm({
                content: content,
                confirm: () => {
                    callback && callback();
                },
                cancel: () => {
                    cancelBack && cancelBack();
                },
            });
        },
        errorMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "error",
                duration: 1500,
            });
        },
        successMsg(mes) {
            this.$refs.uToast.show({
                title: mes,
                type: "success",
                duration: 1500,
            });
        },
        get(action, initParams) {
            let _this = this;
            if (action) {
                this.initAction = action;
            }
            if (!this.initAction) {
                console.error("无法确定初始化状态");
                return false;
            }
            var url = this.getUrl();
            uni.showToast({
                icon: "loading",
            });
            if (!initParams) {
                initParams = {};
            }
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode && this.isUseEnterprise) {
                if (!initParams.companyCode) {
                    this.$set(initParams, "companyCode", enterpriseCode);
                }
            }
            initParams = this.utils.deepMerge(initParams, this.queryParams);
            this.common.get(url, initParams).then(function (res) {
                if (res.code === 200) {
                    _this.model = res.data ? res.data : {};
                    _this.$emit("input", _this.model);
                    _this.$emit("initCallBack", _this.model);
                } else {
                    _this.$refs.uToast.show({
                        title: "获取数据失败:" + res.errMsg,
                        type: "error",
                    });
                }
                uni.hideToast();
            });
        },
        getUrl() {
            if (this.initAction == "init") {
                if (this.initUrl) return this.initUrl;
                else return `/${this.control}/initData/0`;
                //"/" + this.control + "/initData/0";
            } else {
                if (this.detailUrl) return this.detailUrl;
                else {
                    if (this.byCode) {
                        return `/${this.control}/getDataByCode/${this.model.code}`;
                    } else {
                        return `/${this.control}/getData/${this.model.id}`;
                        //"/" + this.control + "/getData/" + this.model.id;
                    }
                }
            }
        },
        getPostUrl() {
            if (this.postUrl) {
                return this.postUrl;
            } else {
                return "/" + this.control + "/" + this.saveFunName;
            }
        },
        getDelUrl() {
            if (this.delUrl) {
                return this.delUrl;
            } else {
                return "/" + this.control + "/delete/" + this.model.id;
            }
        },
        setRules(obj) {
            this.$refs.uForm.setRules(obj);
        },
        // resetTableHeight() {
        //     let windowHeight = 0;
        //     var _that = this;
        //     uni.getSystemInfo({
        //         success: function (res) {
        //             _that.scrollHeight = res.windowHeight - _that.outHeight;
        //         },
        //     });
        // },

        // resetHeight(outHeight) {
        //     let windowHeight = 0;
        //     var _that = this;
        //     uni.getSystemInfo({
        //         success: function (res) {
        //             _that.scrollHeight = res.windowHeight - outHeight;
        //         },
        //     });
        // },

        getGetAllChildElement(childrens, array) {
            let _this = this;
            childrens.forEach((x) => {
                array = array.concat(x.$children);
                //array.push(x.$children);
                array = _this.getGetAllChildElement(x.$children, array);
            });
            return array;
        },

        valid() {
            let result = true;
            //var children = this.$refs.uForm.$children[0].$children;
            let array = [];

            array = this.getGetAllChildElement(
                this.$refs.uForm.$children,
                array
            );
            
            if (array.length > 0) {
                for (var i = 0; i < array.length; i++) {
                    if (array[i].$options.propsData.required) {
                        let el = array[i].$emit.apply(
                            array[i],
                            ["valid"].concat()
                        );
                        if (typeof el.valid === "function") {
                            let flag = el.valid();
                            console.log('flag',flag);
                            result = result ? flag : result;
                        }
                    }
                }
            }
            return result;
        },
    },
};
</script>

<style lang="scss" scoped>
.eagleWrapForm {
    // border-top: 1px solid #e4e7ed;

    .wrap {
        // padding: 30rpx;
        padding-top: 0rpx;
    }

    .warpLoding {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
    }

    .u-border,
    .u-border-bottom,
    .u-border-left,
    .u-border-right,
    .u-border-top,
    .u-border-top-bottom {
        position: sticky;
    }

    // /deep/.eagle-form .u-form-item {
    //     border-bottom: 1px solid #e4e7ed;
    //     padding: 20rpx 0;
    // }
}
</style>
