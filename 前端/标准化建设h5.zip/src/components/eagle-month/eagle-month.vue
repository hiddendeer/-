<template  name="eagle-month">
    <!-- <view> -->
    <u-form-item :label="title" ref="uFormItem" :label-position="placeholder" :required="required"
        :label-width="labelWidth">
        <u-input :placeholder="placeholder" :value="defaultValue" @click="showPopup" :disabled="true" :border='border'>
        </u-input>
        <view>
            <u-icon name="arrow-right" color="#e1e1e1" size="28"></u-icon>
        </view>
        <u-popup v-model="show" mode="bottom" @close="show = false">
            <view class="eagle-month-select-head">
                <view class="btn-cancel" @click="close">取消</view>
                <view class="btn-title"></view>
                <view class="btn-submit" @click="submit">确定</view>
            </view>
            <picker-view class="uni-datetime-picker-view" :value="dafaultArry" @change="bindChange">
                <picker-view-column :indicator-style="indicatorStyle">
                    <view class="item" v-for="(item, index) in years" :key="index">{{ item }}年</view>
                </picker-view-column>
                <picker-view-column>
                    <view class="item" v-for="(item, index) in months" :key="index">{{ item }}月</view>
                </picker-view-column>
            </picker-view>
        </u-popup>
    </u-form-item>
    <!-- </view> -->
</template>



<script>
import $timeFormat from "@/uview-ui/libs/function/timeFormat.js";
export default {
    name: "eagle-month",
    props: {
        value: {
            type: String,
            default: "",
        },
        type: {
            type: String,
            default: "month",
        },
        start: {
            type: Number,
            default: 2001,
        },
        end: {
            type: Number,
            default: 2030,
        },
        placeholder: {
            type: String,
            default: "请选择月份",
        },
        border: {
            type: Boolean,
            default: false,
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default: "120",
        },
    },
    computed: {
        years() {
            let yearArry = [];
            for (var i = this.start; i <= this.end; i++) {
                yearArry.push(i);
            }
            return yearArry;
        },
        months() {
            let monthArry = [];
            for (var i = 1; i <= 12; i++) {
                monthArry.push(i);
            }
            return monthArry;
        },
    },
    data() {
        return {
            // 起始时间
            startYear: 1920,
            startMonth: 1,
            // 结束时间
            endYear: 2120,
            endMonth: 12,
            indicatorStyle: `height: 50px;`,
            show: false,
            defaultValue: "",
            dafaultArry: [21, 0],
            testValue: "",
        };
    },
    created() {
        if (this.value) {
            this.defaultValue = $timeFormat(this.value.replace(/-/g, "/"), "yyyy-mm");
        }
    },
    watch: {
        value(newValue, oldValue) {
            if (newValue != oldValue) {
                if (newValue) {
                    this.defaultValue = $timeFormat(newValue.replace(/-/g, "/"), "yyyy-mm");
                } else {
                    this.defaultValue = "";
                }
                // this.setDefaultArry();
            }
        },
    },
    methods: {
        setDefaultArry() {
            if (this.defaultValue) {
                let arry = this.defaultValue.split("-");
                this.dafaultArry = [];
                let ii = 0;
                for (var i = this.start; i <= this.end; i++) {
                    if (i == arry[0]) {
                        this.dafaultArry.push(ii);
                    }
                    ii++;
                }
                ii = 0;
                for (var i = 1; i <= 12; i++) {
                    if (i == arry[1]) {
                        this.dafaultArry.push(ii);
                    }
                    ii++;
                }
            } else {
                this.dafaultArry = [21, 0];
            }
        },
        bindChange(e, item) {
            let inputValue = "";
            if (e.detail) {
                this.dafaultArry = [];
                if (e.detail.value.length > 0) {
                    this.dafaultArry.push(e.detail.value[0]);
                    inputValue = this.years[e.detail.value[0]] + "-";
                }
                if (e.detail.value.length > 1) {
                    this.dafaultArry.push(e.detail.value[1]);
                    inputValue = inputValue + this.months[e.detail.value[1]];
                } else {
                    this.dafaultArry.push(0);
                    inputValue = inputValue + this.months[0];
                }
                inputValue = inputValue + "-01";
            }
            this.$emit("input", inputValue);
            this.$emit("change", e);
        },
        close() {
            this.show = false;
        },
        submit() {
            if (
                !this.defaultValue &&
                this.dafaultArry &&
                this.dafaultArry.length > 0
            ) {
                let inputValue = this.years[this.dafaultArry[0]] + "-";
                if (this.dafaultArry.length > 1) {
                    inputValue = inputValue + this.months[this.dafaultArry[1]];
                } else {
                    inputValue = inputValue + this.months[0];
                }
                inputValue = inputValue + "-01";
                this.$emit("input", inputValue);
            }
            this.close();
        },
        showPopup() {
            this.setDefaultArry();
            this.show = true;
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage = _this.placeholder;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage === _this.placeholder
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>
<style  lang="scss" >
.uni-datetime-picker-view {
    height: 320rpx;
    width: calc(100%);
    cursor: pointer;
    text-align: center;
}

.eagle-month-select-head {
    display: flex;
    line-height: 40px;

    .btn-cancel {
        color: #606266;
        width: 120rpx;
        text-align: right;
        font-size: 16px;
    }

    .btn-title {
        flex: 1;
    }

    .btn-submit {
        color: #2979ff;
        width: 120rpx;
        text-align: left;
        font-size: 16px;
    }
}
</style>
