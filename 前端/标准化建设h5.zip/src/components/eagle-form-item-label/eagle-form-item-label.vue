<template>
    <uni-view class="u-form-item--left" style="width: 100%; flex: 0 0 100%; margin-bottom: 5px;">
        <uni-view class="u-form-item--left__content">
            <uni-text v-if="required" class="u-form-item--left__content--required"><span>*</span></uni-text>
            <uni-view class="u-form-item--left__content__label" style="justify-content: flex-start;">{{label}}</uni-view>
        </uni-view>
    </uni-view>
</template>

<script>
export default {
    name: "eagle-form-item-label",
    props: {
        label: {
            type: String,
            default: "",
        },
        required: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {};
    },
};
</script>

<style>
</style>
