<template>
    <view class="eagle-text-item" :class="['eagle-text-item--' + type]" @click="clickFun">
        <span :class="{ 'blod': blod }" :style="{ 'width': labelWidth }" class="label">{{ labelName }}</span>
        <span class="eagle-text-item-span" :class="['eagle-text-item-color--' + color, 'eagle-text-item-text']" v-if="!isOnlyShowTitle">
            <span class="eagle-text-value" v-if="!$slots.default">{{ value || "--" }}</span>
            <span>
                <slot></slot>
            </span>
        </span>
    </view>
</template>

<script>
export default {
    name: "eagle-text",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        label: {
            type: [String],
            default: "",
        },
        title: {
            type: [String],
            default: "",
        },
        type: {
            type: String,
            default: "text",
        },

        labelPosition: {
            type: String,
            default: "left",
        },

        blod: {
            type: Boolean,
            default: true,
        },
        //normal 普通模式
        //mini   迷你模式行间距缩小，无下划线
        type: {
            type: String,
            default: "normal",
        },
        //字体颜色
        color: {
            type: String,
            default: "normal",
        },
        //只显示标题
        isOnlyShowTitle: {
            type: Boolean,
            default: false,
        },

        //不显示
        isNoShowColon: {
            type: Boolean,
            default: false,
        },
        labelWidth: {
            type: String,
            default: "",
        },
    },
    data() {
        return {
            labelName: "",
        };
    },
    created() {
        let label = this.label || this.title;
        if (this.isOnlyShowTitle) {
            this.labelName = label;
        } else {
            if (this.isNoShowColon) {
                this.labelName = label ? label + "" : "";
            } else {
                this.labelName = label ? label + "： " : "";
            }
        }
    },
    watch: {},
    methods: {
        clickFun() {
            this.$emit("click");
        },
    },
};
</script>

<style scoped lang="scss">
.eagle-text-item--normal:last-child {
    border-bottom: none;
}

span{
    overflow: hidden;
    white-space: normal;
    word-wrap: break-word;
    word-break: break-all;
    text-overflow: ellipsis;
}
.eagle-text-item {
    &--normal {
        padding: 10rpx 15rpx 10rpx 15rpx;
        display: flex;
        // border-bottom: 1rpx solid $border-color-base;
    }

    &--mini {
        padding: 6rpx 30rpx 6rpx 30rpx;
    }

    &-color--red {
        color: $status-color-red;
    }

    &-color--orange {
        color: $status-color-orange;
    }

    &-color--green {
        color: $status-color-green;
    }

    &-color--purple {
        color: $status-color-purple;
    }

    &-color--blue {
        color: $status-color-blue;
    }

    .blod {
        // font-weight: 600;
    }

    // .label {
    //     font-size: $font-base;
    //     color: $font-color-dark;
    // }
    &-text {
        font-size: $font-base;
        color: $font-color-base;
    }

    /deep/ .u-form-item {
        padding: 0px;
    }

    .eagle-text-item-span {
        flex: 1;
    }
}
</style>
