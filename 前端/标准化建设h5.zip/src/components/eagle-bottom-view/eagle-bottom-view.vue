<template>
    <view class="view-botton" v-bind:style="{bottom: marginBottom,'border-top':borderTop,'padding-bottom':paddingBottom}">
        <slot></slot>
    </view>
</template>
<script>
export default {
    name: "eagle-bottom-view",
    props: {
        marginBottom: {
            type: [String],
            default: "0px",
        },
        paddingBottom: {
            type: [String],
            default: "20rpx",
        },
        borderTop: {
            type: [String],
            default: "1px solid #e4e7ed",
        },
    },
};
</script>
<style lang="scss">
.view-botton {
    // border-top: 1px solid #e4e7ed;
    position: fixed;
    width: 100%;
    bottom: 0px;
    z-index: 11;
    display: inline-flex;
    justify-content: space-between;
    background: #f3f4f6;
    padding-top: 10rpx;
    // padding-bottom: 38rpx;
    // background: #fff;
    /deep/ .u-size-medium {
        padding: 0 20px;
    }
    // /deep/ .u-size-default {
    //     height: 36px;
    //     line-height: 36px;
    // }
    // /deep/ .u-size-medium {
    //     padding: 0 20px;
    // }
}
</style>
