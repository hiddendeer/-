<template>
    <view>
        <u-popup v-model="show" mode="bottom" height="100%">
            <eagle-head :title="curTitle" @close="close"></eagle-head>
            <view class="radio-block">
                <view class="my-radio" v-for="(item, index) in items" :key="index" @click="change(item)">
                    <view style="display: flex;justify-content: space-around;width: 100%;">
                        <view class="radio-title">{{item[Name]}}</view>
                        <view class="radio-round">
                            <span :class="{'radio-checked':defaultVal==item[ID]}"></span>
                        </view>
                    </view>
                </view>
                <view class="my-radio" v-show="showCustomer&&this.defaultVal=='Custom'">
                    <u-input :clearable="false" v-model="customerVal" @blur="customerChange" :placeholder="customPlaceholder" label="自定义"></u-input>
                </view>
            </view>
        </u-popup>
        <u-toast ref="uToast" />
    </view>
</template>

<script>
export default {
    name: "popup-radio-group",
    props: {
        value: {
            type: Number | String,
            default: "",
        },

        ID: {
            type: String,
            default() {
                return "id";
            },
        },
        Name: {
            type: String,
            default() {
                return "name";
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        showCustomer: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        show: {
            type: Boolean,
            default() {
                return false;
            },
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            items: [],
            defaultVal: "",
            customerVal: "",
            customerDisable: true,
            curTitle: "",
            customPlaceholder: "请输入自定义内容",
        };
    },

    watch: {},

    created() {
        this.curTitle = "选择" + this.title;
    },
    methods: {
        customerChange() {
            if (!this.customerVal) {
                this.$refs.uToast.show({
                    title: "请输入自定义内容",
                    type: "error",
                });
                return false;
            }
            let val = "Custom-" + this.customerVal;
            this.$emit("change", val, this.customerVal);
        },
        change: function (e) {
            this.defaultVal = e[this.ID];
            if (this.defaultVal == "Custom") {
                this.customerVal = "";
                return false;
            } else {
                let obj = this.items.find(
                    (x) => x[this.ID] === this.defaultVal
                );
                this.$emit("change", this.defaultVal, obj);
            }
        },
        close() {
            this.$emit("update:show", false);
        },
        bind: function () {
            this.items = this.utils.deepClone(this.dataSource);
        },
    },
    watch: {
        value: function () {
            this.defaultVal = this.value;
            if (
                this.value != undefined &&
                this.value.toString().indexOf("Custom") == 0
            ) {
                this.defaultVal = "Custom";
                let arryCustom = this.value.split("-");
                if (arryCustom.length == 2) {
                    this.customerVal = arryCustom[1];
                }
            }
        },
        dataSource: function () {
            this.bind();
        },
    },
};
</script>

<style lang="scss" scoped>
.radio-block {
    line-height: 28px;
    font-size: 15px;
    color: #606266;
}
.my-radio {
    padding: 10px 20px;
    background: #fff;
    border-bottom: 1px solid #f1f1f1;
    line-height: 28px;
    display: flex;
}
.radio-title {
    flex: 1;
}
.radio-round {
    width: 20px;
    height: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
    margin-top: 5px;
}
.radio-checked {
    width: 16px;
    height: 16px;
    border-radius: 10px;
    background: #2b85e4;
    display: block;
    margin: 1px;
}
</style>
