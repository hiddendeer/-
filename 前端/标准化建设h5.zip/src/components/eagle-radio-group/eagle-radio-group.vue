<template name='eagle-radio-group'>
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required||onlyShowRequired" :prop="prop" :label-width="labelWidth">
        <!-- <u-input :placeholder="customPlaceholder" v-model="defaultName" disabled :required="required" v-if="items.length>7" @click="showType()"></u-input> -->
        <u-radio-group v-model="defaultVal" @change="change" :disabled="disabled" :active-color="activeColor" :shape="shape" :wrap="wrap">
            <u-radio v-for="(item, index) in items" :key="index" :name="item[ID]" :disabled="item.disabled">
                {{item[Name]}}
            </u-radio>
            <view v-if="showCustomer">
                <u-input :clearable="false" v-model="customerVal" @blur="customerChange" :placeholder="customPlaceholder" label="自定义"></u-input>
            </view>
        </u-radio-group>
        <!-- <popup-radio-group ref="popupRadioGroup" :prop="prop" :show.sync="dialog" :ID="ID" :Name="Name" :showCustomer="showCustomer" @close="dialog=false" v-model="defaultVal" @change="changeDangeType" :data-source="items">
        </popup-radio-group> -->
    </u-form-item>
</template>
<script>
import popupRadioGroup from "./popup-radio-group.vue";
export default {
    name: "eagle-radio-group",
    components: {
        "popup-radio-group": popupRadioGroup,
    },
    props: {
        value: {
            type: Number | String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        ID: {
            type: String,
            default() {
                return "id";
            },
        },
        Name: {
            type: String,
            default() {
                return "name";
            },
        },

        disabledValues: {
            type: String,
            default() {
                return "";
            },
        },
        checkedValues: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },

        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        activeColor: {
            type: String,
            default() {
                return "#2979ff";
            },
        },
        shape: {
            type: String,
            default() {
                return "circle";
            },
        },
        labelDisabled: false,
        labelWidth: {
            type: String,
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        wrap: false,
        showCustomer: {
            type: [Boolean],
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            items: [],
            defaultVal: "",
            defaultName: "",
            labelPositionVal: "",
            customerVal: "",
            customerDisable: true,
            customPlaceholder: "",
            dialog: false,
        };
    },
    mounted() {
        this.customPlaceholder = this.placeholder
            ? this.customPlaceholder
            : "请选择" + this.title;
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
        this.bind();
        this.bindValue(this.value);
    },
    created() {},
    methods: {
        showType() {
            this.dialog = true;
        },
        changeDangeType(e, obj) {
            this.defaultVal = e;
            // if (e == "Custom") {
            //     this.customerDisable = false;
            //     this.customPlaceholder = "请输入自定义内容";
            // } else {
            //     this.customerDisable = true;
            //     this.customerVal = "";
            // }
            // this.$emit("input", this.defaultVal);
            // this.$emit("change", this.defaultVal, obj);
            // this.valid();
            this.$emit("input", e);
            // this.$emit("update:text", this.customerVal);
            this.$emit("change", e, obj);
            this.dialog = false;
        },
        change: function (e) {
            this.defaultVal = e;
            if (e == "Custom") {
                this.customerDisable = false;
                this.customPlaceholder = "请输入自定义内容";
            } else {
                this.customerDisable = true;
                this.customerVal = "";
            }
            this.$emit("input", this.defaultVal);
            // this.$emit("update:text", obj[this.Name]);
            this.$emit("change", this.defaultVal, "");
            this.valid();
        },
        customerChange() {
            let val = "Custom-" + this.customerVal;
            this.$emit("input", val);
            // this.$emit("update:text", this.customerVal);
            this.$emit("change", val, this.customerVal);
        },
        bind: function () {
            this.items = this.utils.deepClone(this.dataSource);
            var _this = this;
            if (this.showCustomer) {
                let customerParams = {};
                this.$set(customerParams, this.ID, "Custom");
                this.$set(customerParams, this.Name, "自定义");
                this.items.push(customerParams);
            }
            var disabledArray = this.disabledValues
                ? this.disabledValues.split(",")
                : [];
            this.items.forEach((item, index) => {
                if (_this.defaultVal === item[_this.ID])
                    this.$set(item, "checked", true);
                else this.$set(item, "checked", false);

                if (this.disabled || disabledArray.includes(item[_this.ID]))
                    this.$set(item, "disabled", true);
                else this.$set(item, "disabled", false);
            });
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultVal || _this.defaultVal === "Custom") {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.customPlaceholder;
                    return false;
                } else {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
        setRadioName() {
            this.defaultName = null;
            if (
                this.defaultVal != undefined &&
                this.defaultVal.toString().indexOf("Custom") == 0
            ) {
                this.defaultName = this.customerVal;
            } else {
                let obj = this.items.find(
                    (x) => x[this.ID] === this.defaultVal
                );
                if (obj) {
                    this.defaultName = obj[this.Name];
                }
            }
        },
        bindValue(value) {
            this.defaultVal = value;
            if (
                this.value != undefined &&
                this.value.toString().indexOf("Custom") == 0
            ) {
                this.defaultVal = "Custom";
                let arryCustom = this.value.split("-");
                if (arryCustom.length == 2) {
                    this.customerVal = arryCustom[1];
                }
            }
            this.setRadioName();
        },
    },
    watch: {
        value: function () {
            if (!this.value) {
                this.defaultName = "";
                this.customPlaceholder = this.placeholder
                    ? this.customPlaceholder
                    : "请选择" + this.title;
            }
            this.bindValue(this.value);
        },
    },
};
</script>
<style>
.uni-list-cell {
    justify-content: flex-start;
    margin-top: 10rpx;
}
</style>
