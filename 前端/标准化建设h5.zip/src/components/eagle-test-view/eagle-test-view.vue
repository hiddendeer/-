<template name="eagle-test-view">
    <!-- <view style="background: #FFFFFF;padding: 0 30rpx;"> -->
    <u-form-item :label="label" ref="uFormItem" :label-position="labelPositionVal" :label-width="labelWidth">
        <view class="single-line " style="line-height:36px;height:36px;">
            {{value}}
            <slot></slot>
        </view>
    </u-form-item>
    <!-- </view> -->

</template>
<script>
export default {
    name: "eagle-test-view",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        label: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "130",
        },
        labelPositionVal: {
            type: String,
            default: "top",
        },
    },
    created() {},
    data() {
        return {};
    },
    watch: {},
    methods: {},
};
</script>

<style lang="scss">
</style>
