<template>
    <view class="add-round" @click="add" :style="{'bottom':bottom }">
        <u-icon :name="icon" size="70" color="#fff"></u-icon>
		<slot></slot>
    </view>
</template>

<script>
export default {
    name: "eagle-add-round",
    props: {
        icon: {
            type: String,
            default: "plus",
        },
        bottom: {
            type: String,
            default: "180rpx",
        },
    },
    data() {
        return {};
    },
    methods: {
        add() {
            this.$emit("click");
        },
    },
};
</script>

<style lang="scss">
.add-round {
    position: fixed;
    z-index: 999;
    right: 30rpx;
    // bottom: 50rpx;
    border-radius: 50%;
    width: 120rpx;
    height: 120rpx;
    color: #fff;
    text-align: center;
    line-height: 120rpx;
    font-weight: 100;
    font-size: 80rpx;
    background-color: #1b76d1;
}
</style>
