<template>
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required||onlyShowRequired" :prop="prop" :label-width="labelWidth">
        <u-input class="eagle-choose" type="select" ref="uInput" v-if="!disabled" :placeholder="placeholderVal" v-model="defaultValue" :select-open="selectOpenVal" @click="click" :height="height"></u-input>
        <u-input class="eagle-choose" v-else ref="uInput" :disabled="disabled" :placeholder="placeholderVal" v-model="defaultValue" @click="click" :height="height"></u-input>
    </u-form-item>
</template>

<script>
export default {
    name: "eagle-choose",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabledValues: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        height: {
            type: String,
            default: "",
        },
        selectOpen: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        placeholder: {
            type: String,
            default: "",
        },
        disabled: {
            type: [Boolean],
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            selectOpenVal: this.selectOpen,
            placeholderVal: "",
            labelPositionVal: "",
            defaultValue: this.value,
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请选择" + this.title;
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        click() {
            if (!this.disabled) {
                this.selectOpenVal = true;
                this.$emit("update:select-open", false);
                this.$emit("click", true);
            }
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
    watch: {
        value(nVal, oVal) {
            if (nVal !== oVal) {
                this.defaultValue = nVal;
                if (this.defaultValue) {
                    this.valid();
                }
            }
        },
        selectOpenVal(nVal, oVal) {
            if (nVal !== oVal) {
                this.$emit("update:select-open", nVal);
            }
        },
        selectOpen(nVal, oVal) {
            if (nVal !== oVal) {
                console.log("selectOpen", nVal);
                this.selectOpenVal = nVal;
            }
        },
    },
};
</script>

<style lang="scss" scoped>
.eagle-choose {
    padding: 0 5px !important;
}
</style>
