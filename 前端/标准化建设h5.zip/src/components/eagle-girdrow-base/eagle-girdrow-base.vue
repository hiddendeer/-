<template>
    <view class="grid-row-base" :class="{'grid-row-title':isTitle,'single-line':isSingleLine,'s-between':sBetween,'s-around':sAround}">
        <slot></slot>
    </view>
</template>

<script>
export default {
    name: "eagle-girdrow-base",
    props: {
        isTitle: {
            type: Boolean,
            default: false,
        },
        isSingleLine: {
            type: Boolean,
            default: false,
        },
        sBetween: {
            type: Boolean,
            default: false,
        },
        sAround: {
            type: Boolean,
            default: false,
        }
    },
    data() {
        return {

        };
    }
}
</script>

 