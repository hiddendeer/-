<template>
    <u-popup v-model="showDialog" mode="right" height="100%" length="100%">
        <uni-page-head uni-page-head-type="default">
            <div class="uni-page-head">
                <div class="uni-page-head-hd">
                    <div class="uni-page-head-btn" @click="close">
                        <i class="uni-btn-icon" style="font-size: 27px;"></i>
                    </div>
                </div>
                <div class="uni-page-head-bd">
                    <div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
                        {{headTitle}}
                    </div>
                </div>
            </div>
            <div class="uni-placeholder"></div>
        </uni-page-head>
        <view>
            <eagle-page-list ref="eaglePageList" :controller="controller" :dataType="dataType" :showCheck="true" @initList="_initList" :margin-bottom="50" v-show="!showDetail" :boolInitData="false">
                <view slot="search">
                    <view class="search">
                        <eagle-search v-model="searchValue" @search="search" :clearabled="clearabled" :show-action="false" @clear="search" placeholder="请输入订单编号进行模糊搜索"></eagle-search>
                    </view>
                </view>
                <view slot="list" class="list-wrap">
                    <view class="view_container" v-for="(item, index) in data" :key="item[idField]">
                        <view @tap="choose(item,true)">
                            <view class="view_row">
                                <view>
                                    <view class="uni-media-list-text-top">{{item[textField]}}</view>
                                    <view v-if="customer=='intentionOrder'" class="customerRow">
                                        <u-row>
                                            <u-col span="12">
                                                <view>
                                                    <eagle-icon name="account"></eagle-icon> 客户：{{item.customerName}}
                                                </view>
                                            </u-col>
                                        </u-row>
                                        <u-row>
                                            <u-col span="12">
                                                <view>
                                                    <eagle-icon name="kefu-ermai"></eagle-icon> 成单率(%)：{{item.rate}}
                                                </view>
                                            </u-col>
                                        </u-row>
                                    </view>
                                </view>
                                <u-checkbox v-model="item.checked" @click.stop.native="choose(item,false)" shape="circle">
                                </u-checkbox>
                            </view>
                        </view>
                    </view>
                </view>
            </eagle-page-list>
            <view class="view-choose-botton">
                <!-- <view class="choose-item" v-if="choosedNum>0&&isMult">
                    <text>已选择:</text>
                    <text class="choose-num" @click="funShowDetail">{{choosedNum}}条</text>
                </view> -->
                <u-button class="choose-btn" type="primary" @click="submit">确定</u-button>
                <u-button v-if="isMult" class="choose-btn" type="primary" @click="cancelChoose">取消选择</u-button>
                <!-- <u-button v-if="isMult&&!showDetail" class="choose-btn" type="primary"   @click="chooseAll">
                    全选
                </u-button> -->
            </view>
        </view>
    </u-popup>
</template>

<script>
export default {
    name: "popup-customer",
    props: {
        value: {
            type: String,
            default() {
                return "";
            },
        },

        names: {
            type: String,
            default() {
                return "";
            },
        },
        isMult: {
            type: Boolean,
            default() {
                return true;
            },
        },
        headTitle: {
            type: String,
            default() {
                return "";
            },
        },
        idField: {
            type: String,
            default() {
                return "id";
            },
        },
        textField: {
            type: String,
            default() {
                return "name";
            },
        },
        descText: {
            type: String,
            default() {
                return "";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        dataType: {
            type: String,
            default() {
                return "list";
            },
        },
        customer: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            // dataType: "list",
            searchValue: "",
            data: [],
            choosedData: [],
            clearabled: true,
            showDetail: false,
            choosedNum: 0,
            queryParams: {},
            detailHeigh: 0,
            chooseVal: "",
            showDialog: false,
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this._initChoosedData();
            }
        },
    },
    created() {
        let _that = this;
        this._initChoosedData();
    },
    methods: {
        show() {
            this.showDialog = true;
            this.search();
        },
        _initChoosedData() {
            this.choosedNum = 0;
            if (this.chooseVal != this.value) {
                this.choosedData = [];
                if (this.value) {
                    let arry = this.value.split(",");
                    let arryName = this.names.split(",");
                    for (let i = 0; i < arry.length; i++) {
                        this.choosedData.push({
                            idValue: arry[i],
                            textValue: arryName[i],
                        });
                    }
                    this.choosedNum = this.choosedData.length;
                }
            }
        },
        _initList(list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < this.choosedData.length; j++) {
                    if (this.choosedData[j].idValue == list[i][this.idField]) {
                        list[i].checked = true;
                    }
                }
            }
            this.data = list;
        },
        close() {
            this.showDialog = false;
        },
        search() {
            // conditions=[{"name":"orderno","operate":"like","value":"111"},{"name":"status","operate":"<","value":30}]

            var conditions = [];
            var str = "";
            if (this.searchValue) {
                let obj = {};
                obj.name = "orderno";
                obj.value = this.searchValue;
                obj.operate = "like";
                conditions.push(obj);
            }

            let obj1 = {};
            obj1.name = "status";
            obj1.value = "10";
            obj1.operate = "=";
            conditions.push(obj1);

            this.conditions = conditions;
            // this.queryPage();

            //          this.queryParams.keyword = this.searchValue;
            setTimeout(() => {
                this.$refs.eaglePageList.search({
                    conditions: this.conditions,
                });
            });
        },
        choose(obj, update) {
            let _this = this;
            if (update) {
                obj.checked = !obj.checked;
            }
            this.choosedData = [];
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (!_this.isMult) {
                    if (item[_this.idField] != obj[_this.idField]) {
                        item.checked = false;
                    }
                }
                if (item.checked) {
                    _this.choosedData.push({
                        idValue: item[_this.idField],
                        textValue: item[_this.textField],
                    });
                }
            }
            this.choosedNum = this.choosedData.length;
        },
        submit() {
            // 
            let codeArry = [];
            let nameArry = [];
            this.choosedData.forEach(function (item) {
                codeArry.push(item.idValue);
                nameArry.push(item.textValue);
            });
            let codes = codeArry.join(",");
            let names = nameArry.join(",");
            this.chooseVal = names;
            this.$emit("input", codes);
            this.$emit("change", codes, names);
            this.$emit("update:names", names);

            let choosedArr = [];
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];

                if (item.checked) {
                    choosedArr.push(item);
                }
            }

            this.$emit("callBackChoosedData", choosedArr);

            this.close();
        },
        chooseAll() {
            let _this = this;
            this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = true;
                _this.choosedData.push({
                    idValue: item[_this.idField],
                    textValue: item[_this.textField],
                });
            });
            this.choosedNum = this.choosedData.length;
        },
        cancelChoose() {
            let _this = this;
            _this.choosedData = [];
            this.data.forEach(function (item) {
                item.checked = false;
            });
            _this.choosedNum = 0;
        },
        clear(obj, index) {
            this.choosedData.splice(index, 1);
            for (let i = 0; i < this.data.length; i++) {
                let item = this.data[i];
                if (item[this.idField] == obj[this.idField]) {
                    item.checked = false;
                }
            }
            this.choosedNum = this.choosedData.length;
            if (this.choosedNum == 0) {
                this.showDetail = false;
            }
        },
        // funShowDetail() {
        //     this.showDetail = !this.showDetail;
        // },
        checkChange(e) { },
    },
};
</script>

<style lang="scss">
.view_container {
    background: #fff;
    line-height: 100rpx;
}
.customerRow {
    line-height: 56rpx;
    .view_container {
        background: #fff;
        line-height: 56rpx;
    }
}
/deep/.u-icon__icon {
    margin-right: 10rpx;
}

.view_row {
    display: flex;
    justify-content: space-between;
    margin: 0rpx 30rpx;
    border-bottom: 1px solid #ececec;
    background-color: #fff;
}
.uni-media-list-text-top {
    line-height: 100rpx;
    text-indent: 20rpx;
}

// .view-choose-botton {
//     position: fixed;
//     width: 100%;
//     bottom: 0px;
//     padding-bottom: 15px;
//     padding-top: 10px;
//     background: #fff;
//     .choose-item {
//         float: left;
//         display: inline-block;
//         line-height: 40px;
//         margin-left: 10px;
//         font-size: 16px;
//     }

//     .choose-num {
//         color: #2979ff;
//     }

//     .choose-btn {
//         float: right;
//         // margin-left: 8rpx;
//         margin-right: 20rpx;
//     }
// }

.uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
}

.choosed-view {
    margin-bottom: 50rpx;
}

.uni-page-head {
    background-color: $grid-row-base;
    color: white;
}
</style>
