<template name="eagle-choose-customer">
    <u-form-item :label="title" ref="uFormItem" :label-position="labelPositionVal" :required="required" :label-width="labelWidth">
        <u-input :placeholder="placeholderVal" :value="names" @click="funDialogShow" :disabled="true"></u-input>
        <view v-show="codes" class="uni-date__icon-clear" @click.stop="clear">
            <uni-icons type="clear" color="#e1e1e1" size="14"></uni-icons>
        </view>
        <popup-customer ref="popupWindow" :isMult="isMult" :customer="customer" :dataType="dataType" :headTitle="headTitle" :idField="idField" :textField="textField" :controller="controller" :names.sync="myNames" v-model="codes" @change="setValues" @callBackChoosedData="callBackChoosedData">
        </popup-customer>
    </u-form-item>
</template>

<script>
import popupCustomer from "@/components/eagle-choose-customer/popup-customer.vue";
export default {
    name: "eagle-choose-customer",
    components: {
        "popup-customer": popupCustomer,
    },
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        labelPosition: {
            type: String,
            default: "",
        },
        labelWidth: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        isMult: {
            type: Boolean,
            default() {
                return false;
            },
        },
        placeholderVal: {
            type: String,
            default: "请选择",
        },
        names: {
            type: String,
            default() {
                return "";
            },
        },
        headTitle: {
            type: String,
            default() {
                return "";
            },
        },
        idField: {
            type: String,
            default() {
                return "id";
            },
        },
        textField: {
            type: String,
            default() {
                return "name";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        dataType: {
            type: String,
            default() {
                return "list";
            },
        },
        customer: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            dialogShow: false,
            codes: this.value,
            myNames: this.names,
            labelPositionVal: "",
        };
    },
    computed: {},
    watch: {
        value(nVal, oVal) {
            if (nVal != oVal) {
                this.codes = nVal;
            }
        },
    },
    created() {
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    methods: {
        funDialogShow() {
            this.$refs.popupWindow.show();
        },
        setValues(codes, names) {
            this.$emit("update:names", names);
            this.$emit("input", codes);
            this.$emit("change", codes, names);
        },

        callBackChoosedData(choosedData) {
            this.$emit("callBackChoosedData", choosedData);
        },
        clear() {
            this.codes = "";
            this.$emit("update:names", "");
            this.$emit("input", "");
            this.$emit("change", "", "");
            this.$emit("callBackChoosedData", "");
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.value) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
</style>
