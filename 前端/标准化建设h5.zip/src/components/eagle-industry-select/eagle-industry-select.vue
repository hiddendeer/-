<template>
    <view class="industry-choose">
        <u-popup v-model="show" mode="bottom" height="100%" :mask-close-able='false'>
            <eagle-head :title="title" @close="close" v-if="isHeader"></eagle-head>
            <view class="sector-wrap">
                <view class="category">
                    <scroll-view class="scroll-subPro" scroll-y :style="[{ height: scrollHeight }]">
                        <block v-for="(item, index) in sectorData" :key="`catetory-${item.id}`">
                            <view class="category-items" :class="[{ active: index === catalogue }]"
                                @tap="onCheckCatalogue(index)">
                                <text class="u-line-2">{{ item.name }}</text>
                                <view class="count" v-if="checkedData[item.id] && checkedData[item.id].length > 0">
                                    {{checkedData[item.id].length }}
                                </view>
                            </view>
                        </block>
                    </scroll-view>
                </view>
                <view class="subs">
                    <swiper class="swiper-content" :current="catalogue" duration="300" vertical>
                        <block v-for="item in sectorData" :key="`swiper-${item.id}`">
                            <swiper-item @touchmove.stop='stopTouchMove'>
                                <scroll-view class="scroll" scroll-y>
                                    <view class="subs-items">
                                        <view class="subs-items__header"
                                            @tap="onCheckSector(item.id, item.id, item.name)">
                                            <view class="setImg">
                                                <img :src="item.logo" class="cover" />
                                            </view>
                                            <view class="setDescribe">
                                                <text class="label">{{ item.name }}</text>
                                                <text class="describe_top single-line"
                                                    v-if="item.note!==''">{{ item.note }}</text>
                                                <text class="describe_bot" v-else>暂无行业描述信息</text>
                                            </view>

                                            <u-checkbox class="checkbox_x" shape="circle" size="40"
                                                :value="checkedData[item.id] ? checkedData[item.id].check : false"
                                                :disabled="false" />
                                        </view>
                                        <view class="subs-items__guide">包括以下子行业：</view>
                                        <view class="subs-items__content">
                                            <block v-for="(sub,index) in item.detail" :key="index">
                                                <view class="subs-items__content-child" :class="[
                                                  { active: checkedData[item.id] && checkedData[item.id].children.includes(sub.id) },
                                                  { disabled: checkedData[item.id] && checkedData[item.id].check }
                                                ]" :key="`sub-${sub.name}`"
                                                    @tap="onCheckSector(item.id, sub.id, sub.name)">
                                                    <text>{{ sub.name }}</text>
                                                </view>
                                            </block>
                                        </view>
                                    </view>
                                </scroll-view>
                            </swiper-item>
                        </block>
                    </swiper>
                </view>
                <view class="setSave" :style="{marginBottom: marginBottom+'px'}" style="display:flex">
                    <u-button type="primary" size="medium" @click="close()">取消</u-button>
                </view>
                <view class="setSave2" :style="{marginBottom: marginBottom+'px'}" style="display:flex">
                    <u-button type="primary" size="medium" @click="post()">保存</u-button>
                </view>
            </view>
        </u-popup>
    </view>
</template>

<script>
import _ from "lodash";
const systemInfo = uni.getSystemInfoSync();
export default {
    name: "eagle-industry-select",
    props: {
        show: {
            type: Boolean,
            default() {
                return true;
            },
        },

        title: {
            type: String,
            default() {
                return "选择行业";
            },
        },
        //marginBottom 距离底部的高度
        marginBottom: {
            type: String,
            default: "20",
        },
        scrollHeight: {
            type: String,
            default: "0",
        },
        isHeader: {
            type: Boolean,
            default: true,
        },

        isType: {
            type: Boolean,
            default: false,
        },
        isClearData: {
            type: Boolean,
            default: false,
        }
    },
    data() {
        return {
            preset: {
                limit: 3,
            },
            catalogue: 0,
            sectorData: this.value,
            checkedData: {},
            checked: [],
            // isShow: this.show,
            industryInformation: {
                industryName: "", //行业名称
                industryIap: "", //行业iap
            },
        };
    },
    async created() {
        //行业列表
        this.getListWidthType();
    },
    computed: {},
    methods: {
        async getListWidthType() {
            let listWidthType = await this.common.get(
                "/support/dangerlgclassify/GetListWithType?isType=" +
                this.isType
            );
            this.sectorData = listWidthType.data;
            // console.log(listWidthType, "获取列表数据")
        },
        stopTouchMove() {
            return true;
        },
        close() {
            this.$emit("close", false);
        },
        onCheckCatalogue(e) {
            this.catalogue = e;
        },
        onCheckSector(key, value, label) {
            let { preset, checkedData, checked } = this;
            if (
                !_.isEmpty(checked) &&
                checked[1].length >= preset.limit &&
                !checked[1].includes(key) &&
                !checked[1].includes(value)
            ) {
                uni.showToast({
                    title: `仅允许选择${preset.limit}个行业`,
                    icon: "none",
                });
                return;
            }
            let current = checkedData[key] || {};

            if (_.isEmpty(current)) {
                current.check = _.isEqual(key, value) ? true : false;
                current.children = [];
                current.labels = [];
                if (!_.isEqual(key, value)) {
                    current.children.push(value);
                    current.labels.push(label);
                } else {
                    current.label = label;
                }

                current.length = 1;
            } else if (!_.isEqual(key, value)) {
                if (checked[1].includes(key)) {
                    uni.showToast({
                        title: "请取消父行业后进行选择",
                        icon: "none",
                    });
                    return;
                }

                const isChildChecked = current.children.includes(value);
                current.check = false;

                if (isChildChecked) {
                    current.children = current.children.filter(
                        (item) => item !== value
                    );
                    current.labels = current.labels.filter(
                        (item) => item !== label
                    );
                } else {
                    current.children.push(value);
                    current.labels.push(label);
                }

                current.length = current.children.length;
            } else {
                current.label = label;
                current.check = !current.check;

                current.children = [];
                current.labels = [];

                current.length = current.check ? 1 : 0;
                console.log(current);
            }

            checkedData[key] = current;
            this.checkedData = checkedData;
            const tempData = Object.entries(this.checkedData).reduce(
                (prev, e) => {
                    const labels = e[1].check ? [e[1].label] : e[1].labels;
                    const children = e[1].check ? [e[0]] : e[1].children;

                    return [
                        [...prev[0], ...labels],
                        [...prev[1], ...children],
                    ];
                },
                [[], []]
            );
            tempData[2] = checkedData;
            this.checked = tempData;
            //行业名称值
            let industryName = _.toString(this.checked[0]);
            //行业IAP值
            let industryIap = _.toString(this.checked[1]);
            this.industryInformation.industryName = industryName;
            this.industryInformation.industryIap = industryIap;
            // this.$emit("industryName", industryName)
            // this.$emit("industryIap", industryIap)
            // console.log(industryName, "行业名称")
            // console.log(industryIap, "行业iap")
            this.$forceUpdate();
        },
        post() {
            if (this.industryInformation.industryName == "") {
                uni.showToast({
                    title: `未有选择的行业`,
                    icon: "none",
                });
                return;
            } else {
                this.$emit("industryInformation", this.industryInformation);
                if (this.isClearData) {
                    this.checkedData = {};
                }

            }
        },
    },
    watch: {
        // show(val) {
        //     if (val) {
        //         this.checkedData = {};
        //     }
        // },
    },
};
</script>

<style lang="scss" scoped>
@import "@/uview-ui/libs/css/style.components.scss";

.industry-choose {
    uni-swiper {
        height: calc(100vh - 50px);
        background: #fff;
    }

    .sector-wrap {
        @include vue-flex;
        width: 100%;
        overflow: hidden;
    }

    .subs-items {
        background: #fff;
        height: 100%;
    }

    .sector-wrap>.category {
        flex: 0.25;
        background-color: #f4f4f4;
        width: 160rpx;
        font-size: 26rpx;

        .category-items {
            position: relative;
            height: 100rpx;
            padding: 30rpx 30rpx;
            border-bottom: 1rpx solid #eee;

            &.active {
                position: relative;
                width: 100%;
                background-color: #fff;

                &::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    bottom: 0;
                    width: 8rpx;
                    margin: 30rpx 0;
                    // background-color: rgb(255, 102, 0);
                    background-color: $uni-color-primary;
                }
            }

            .count {
                @include vue-flex;
                justify-content: center;
                align-items: center;
                position: absolute;
                top: 10rpx;
                right: 10rpx;
                width: 30rpx;
                height: 30rpx;
                padding: 5rpx;
                font-size: 24rpx;
                border-radius: 50%;
                background-color: $uni-color-primary;
                color: #fff;
            }
        }
    }

    .sector-wrap>.subs {
        flex: 0.75;

        .subs-items {
            &__header {
                @include vue-flex;
                align-items: center;
                //   @include flex-box(row, flex-start, center);
                padding: 20rpx 30rpx;
                min-height: 180rpx;
                border-bottom: 1rpx solid #eee;
                border-radius: 10rpx;

                .setImg {
                    width: 27%;

                    .cover {
                        width: 120rpx;
                        height: 120rpx;
                        margin-right: 30rpx;
                    }
                }

                .setDescribe {
                    width: 60%;
                    height: 100%;

                    .label {
                        flex: 1;
                        height: 35%;
                        font-size: 40rpx;
                        font-weight: bold;
                        display: block;
                    }

                    .describe_top {
                        width: 80%;
                        display: block;
                    }
                }
            }

            &__guide {
                padding: 30rpx 30rpx;
                width: 100%;
                line-height: 30rpx;
            }

            &__content {
                padding: 0 30rpx 30rpx;
                display: grid;
                grid-template-columns: 1fr 1fr;
                grid-row-gap: 20rpx;
                grid-column-gap: 20rpx;

                &-child {
                    @include vue-flex;
                    justify-content: center;
                    align-items: center;
                    padding: 10rpx 20rpx;
                    width: 100%;
                    height: 100%;
                    min-height: 100rpx;
                    text-align: center;
                    background-color: #f3f2f5;
                    border-radius: 10rpx;
                    border: solid 1rpx #f3f2f5;

                    &.active {
                        border: solid 1rpx $uni-color-primary;
                        background-color: $uni-color-primary;
                        color: #fff;
                    }

                    &.disabled {
                        color: $uni-text-color-disable;
                    }
                }
            }
        }
    }

    .sector-wrap>.setSave {
        position: fixed;
        bottom: 1%;
        left: 108px;
    }

    .sector-wrap>.setSave2 {
        position: fixed;
        bottom: 1%;
        right: 15px;
    }

    .u-drawer {
        display: block;
        position: fixed;
        top: 0px;
        left: 0;
        right: 0;
        bottom: 0;
        overflow: hidden;
    }
}
</style>