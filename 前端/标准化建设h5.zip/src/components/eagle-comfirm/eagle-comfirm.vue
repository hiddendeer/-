<template>
	<view>
		<u-modal ref="uModal" v-model="show" :show-cancel-button="true" :show-title="config.showTitle"
			:async-close="config.asyncClose" @confirm="confirm" @cancel="cancel" :content="config.content">
		</u-modal>
	</view>
</template>

<script>
	export default {
		name: "eagle-comfirm",
		data() {
			return {
				show: false,
				zoom: false,
				config: {					
					content: '',
					contentSlot: false,
					showTitle: true,
					asyncClose: false,
					confirm: null,
					cancel: null
				}
			};
		},
		methods: {
			showConfirm(op) {				
				this.config = this.utils.deepMerge(this.config, op);
				this.show=true;
			},
			confirm()
			{
				if (typeof this.config.confirm == 'function')
				 this.config.confirm();
			},
			cancel()
			{ 
				if (typeof this.config.cancel == 'function')
				 this.config.cancel();
			}
		}
	}
</script>

<style>

</style>
