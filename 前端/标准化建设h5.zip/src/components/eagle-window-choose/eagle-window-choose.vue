<template name="eagle-choose-user ">
  <u-form-item
    class="eagle-choose-input"
    :label="title"
    ref="uFormItem"
    :label-position="labelPositionVal"
    :required="required"
    :prop="prop"
    :label-width="labelWidth"
  >
    <view class="choose-input-view" @click="funDialogShow">
      <span class="input-placeholder" v-if="!$slots.default && !value">{{
        placeholderVal
      }}</span>
      <span v-else>
        <span v-if="$slots.default">
          <slot></slot>
        </span>
        <span v-else>{{ names }}</span>
      </span>
    </view>
    <u-button class="choose-input-btn" type="primary" @click="funDialogShow">
      <u-icon size="12" name="plus"></u-icon>{{ btnName }}
    </u-button>
    <popup-window
      ref="popupWindow"
      :customItem="customItem"
      :queryUrl="queryUrl"
      :queryParams="queryParams"
      :addUrl="addUrl"
      :isUseEnterprise="isUseEnterprise"
      :isMult="isMult"
      :headTitle="headTitle"
      :idField="idField"
      :textField="textField"
      :controller="controller"
      :dataType="dataType"
      :keyWordName="keyWordName"
      :otherDataShow="otherDataShow"
      :otherData="otherData"
      :names.sync="myNames"
      v-model="codes"
      @callBackChoosedData="callBackChoosedData"
    >
      <template v-slot:body="scope">
        <view>
          <slot name="popupBody" :item="scope.item"></slot>
        </view>
      </template>
    </popup-window>
  </u-form-item>
</template>

<script>
import popupWindow from "@/components/eagle-window-choose/popup-window.vue";
export default {
  name: "eagle-window-choose",
  components: { "popup-window": popupWindow },
  props: {
    value: {
      type: [String, Number],
      default: ""
    },
    labelPosition: {
      type: String,
      default: ""
    },
    labelWidth: {
      type: String,
      default: ""
    },
    title: {
      type: String,
      default() {
        return "";
      }
    },
    prop: {
      type: [String],
      default: ""
    },
    keyWordName: {
      type: String,
      default() {
        return "keyWords";
      }
    },
    onlyShowRequired: {
      type: Boolean,
      default: false
    },
    required: {
      type: [Boolean],
      default() {
        return false;
      }
    },
    otherDataShow: {
      type: Boolean,
      default() {
        return false;
      }
    },
    otherData: {
      type: Array,
      default() {
        return [];
      }
    },
    conditions: {
      type: Array,
      default: function () {
        return [];
      }
    },
    isMult: {
      type: Boolean,
      default() {
        return false;
      }
    },

    names: {
      type: String,
      default() {
        return "";
      }
    },

    isUseEnterprise: {
      type: Boolean,
      default() {
        return true;
      }
    },
    headTitle: {
      type: String,
      default() {
        return "";
      }
    },
    idField: {
      type: String,
      default() {
        return "id";
      }
    },
    textField: {
      type: String,
      default() {
        return "name";
      }
    },
    controller: {
      type: String,
      default() {
        return "";
      }
    },
    dataType: {
      type: String,
      default() {
        return "list";
      }
    },
    border: {
      type: Boolean,
      default: false
    },
    addUrl: {
      type: String,
      default() {
        return "";
      }
    },
    queryParams: {
      type: Object,
      default: function () {
        return {};
      }
    },
    customItem: {
      type: Boolean,
      default: false
    },
    queryUrl: {
      type: String,
      default: ""
    },
    btnName: {
      type: String,
      default() {
        return "选择";
      }
    }
  },
  data() {
    return {
      // dialogShow: false,
      codes: this.value,
      myNames: this.names,
      labelPositionVal: "",
      placeholder: "",
      placeholderVal: ""
    };
  },
  computed: {},
  watch: {
    value(nVal, oVal) {
      if (nVal != oVal) {
        this.codes = nVal;
      }
    }
  },
  created() {
    this.labelPositionVal = this.labelPosition
      ? this.labelPosition
      : this.consts.constLabelPosition;
    this.placeholderVal = this.placeholder
      ? this.placeholder
      : "请选择" + this.title;
    let self = this;
    uni.$on("_update_enterprise_list", () => {
      self.search();
    });
  },
  methods: {
    funDialogShow() {
      this.$refs.popupWindow.show();
    },
    setValues(codes, names) {
      this.$emit("update:names", names);
      this.$emit("input", codes);
    },

    callBackChoosedData(choosedData, codes, names) {
      this.setValues(codes, names);
      this.$emit("callBackChoosedData", choosedData);
    },
    search() {
      this.$refs.popupWindow.search();
    },

    valid() {
      let _this = this;
      if (_this.required && _this.onlyShowRequired == false) {
        if (!_this.value) {
          _this.$refs.uFormItem.validateState = "error";
          _this.$refs.uFormItem.validateMessage = _this.placeholderVal;
          return false;
        } else if (
          _this.$refs.uFormItem.validateMessage === _this.placeholderVal
        ) {
          _this.$refs.uFormItem.validateState = "";
        }
      }
      return true;
    }
  },
  beforeDestroy() {
    uni.$off("_update_enterprise_list");
  }
};
</script>

<style lang="scss">
.uni-date-clear {
  position: absolute;
  top: 10px;
}
</style>
