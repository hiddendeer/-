<template>
  <u-popup
    class="popup-window"
    v-model="showDialog"
    mode="right"
    height="100vh"
    length="100%"
  >
    <eagle-head @close="close">{{ headTitle }}</eagle-head>
    <view>
      <eagle-page-list
        ref="eaglePageList"
        :isUseEnterprise="isUseEnterprise"
        :conditions="conditions"
        :queryUrl="queryUrl"
        :queryParams="queryParams"
        :controller="controller"
        :dataType="dataType"
        :showCheck="true"
        @initList="_initList"
        :margin-bottom="marginBottom"
        v-show="!showDetail"
        :boolInitData="false"
      >
        <view slot="search" v-if="hasSearch">
          <view class="search">
            <eagle-search
              v-model="conditions.keyWords.value"
              @search="search"
              :clearabled="clearabled"
              :show-action="false"
              @clear="search"
            ></eagle-search>
          </view>
        </view>
        <view slot="list" class="list-wrap">
          <view class="page-row" v-for="(item, index) in data" :key="index">
            <eagle-row-card>
              <view @tap="choose(item, true)">
                <view class="eagle-flex-between">
                  <view class="list-body" v-if="customItem">
                    <slot name="body" :item="item" :$index="index"></slot>
                  </view>
                  <view class="uni-media-list-text-top list-body" v-else>
                    <p>
                      {{ item[textField] }}
                    </p>
                    <template v-if="otherDataShow && otherData.length != 0">
                      <p v-for="(oItem, oIndex) in otherData" :key="oIndex">
                        {{ item[oItem] || '--' }}
                      </p>
                    </template>
                  </view>
                  <u-checkbox
                    v-model="item.checked"
                    @click.stop.native="choose(item, false)"
                    :shape="isMult ? 'square' : 'circle'"
                  >
                  </u-checkbox>
                </view>
              </view>
            </eagle-row-card>
          </view>
        </view>
      </eagle-page-list>
      <view class="view-choose-botton">
        <view
          class="choose-item"
          v-if="choosedData.length >= 0 && isMult && showChoose"
          @click="showChoosed"
        >
          <text>已选择:</text>
          <text class="choose-num">{{ choosedData.length }}条</text>
        </view>
        <u-button
          class="choose-btn"
          v-if="isMult"
          type="primary"
          @click="submit"
          >确定</u-button
        >
        <u-button
          class="choose-btn"
          v-if="addUrl"
          type="primary"
          @click="handlerFabClick"
          >新增</u-button
        >
        <u-button
          class="choose-btn"
          v-if="allowClear"
          type="primary"
          @click="clear"
          >取消</u-button
        >
      </view>
      <u-toast ref="uToast" />
    </view>
    <eagle-choosed-list
      :chooseArray="choosedData"
      ref="EagleChoosedList"
      :nameField="textField"
      :idField="idField"
      :title="'已选择' + headTitle"
      @unChoose="unChoose"
    />
  </u-popup>
</template>

<script>
export default {
  name: "popup-window",
  props: {
    value: {
      type: String,
      default() {
        return "";
      }
    },
    queryUrl: {
      type: String,
      default: ""
    },
    marginBottom: {
      type: Number,
      default: 120
    },
    names: {
      type: String,
      default() {
        return "";
      }
    },
    isMult: {
      type: Boolean,
      default() {
        return true;
      }
    },
    showChoose: {
      type: Boolean,
      default() {
        return true;
      }
    },
    otherDataShow: {
      type: Boolean,
      default() {
        return false;
      }
    },
    otherData: {
      type: Array,
      default() {
        return [];
      }
    },
    headTitle: {
      type: String,
      default() {
        return "";
      }
    },
    idField: {
      type: String,
      default() {
        return "id";
      }
    },
    textField: {
      type: String,
      default() {
        return "name";
      }
    },
    descText: {
      type: String,
      default() {
        return "";
      }
    },

    controller: {
      type: String,
      default() {
        return "";
      }
    },
    dataType: {
      type: String,
      default() {
        return "";
      }
    },
    isUseEnterprise: {
      type: Boolean,
      default() {
        return true;
      }
    },
    addUrl: {
      type: String,
      default() {
        return "";
      }
    },
    allowClear: {
      type: Boolean,
      default() {
        return true;
      }
    },
    queryParams: {
      type: Object,
      default: function () {
        return {};
      }
    },
    customItem: {
      type: Boolean,
      default() {
        return false;
      }
    },
    autoValue: {
      type: Boolean,
      default() {
        return true;
      }
    },
    hasSearch: {
      type: Boolean,
      default() {
        return true;
      }
    },
    maxCount: {
      type: Number,
      default: 9999
    },
    keyWordName: {
      type: String,
      default() {
        return "keyWords";
      }
    }
  },
  data() {
    return {
      data: [],
      choosedData: [],
      clearabled: true,
      showDetail: false,
      chooseVal: "",
      showDialog: false,
      currentAction: "",
      conditions: {
        keyWords: {
          value: "",
          name: this.keyWordName
        }
      }
    };
  },
  computed: {},
  watch: {},
  created() {
    console.log(this.textField);
  },
  methods: {
    _initChoosedData() {
      // this.choosedNum = 0;
      this.currentAction = "initChoose";
      this.choosedData = [];
      if (this.value) {
        let arry = this.value.split(",");
        let arryName = this.names.split(",");
        for (let i = 0; i < arry.length; i++) {
          let obj = {};
          this.$set(obj, this.idField, arry[i]);
          this.$set(obj, this.textField, arryName[i]);
          this.choosedData.push(obj);
        }
      }
      // this.choosedNum = this.choosedData.length;
    },
    _initList(list) {
      let _this = this;
      for (let i = 0; i < list.length; i++) {
        for (let j = 0; j < this.choosedData.length; j++) {
          if (this.choosedData[j][_this.idField] == list[i][_this.idField]) {
            list[i].checked = true;
            if (this.currentAction == "initChoose") {
              this.choosedData[j] = this.utils.deepClone(list[i]);
            }
          }
        }
      }
      this.data = list;
      this.currentAction = "initList";
    },
    show() {
      this._initChoosedData();
      this.showDialog = true;
      this.conditions.keyWords.value = "";
      this.search();
    },
    close() {
      this.showDialog = false;
    },
    search() {
      if (this.showDialog) {
        setTimeout(() => {
          this.$refs.eaglePageList.search();
        });
      }
    },
    choose(obj, update) {
      let _this = this;
      let lastCheck = obj.checked;
      if (update) {
        lastCheck = !lastCheck;
      }
      if (!_this.isMult) {
        this.choosedData = [];
      }

      for (let i = 0; i < this.data.length; i++) {
        let item = this.data[i];
        if (item[_this.idField] == obj[_this.idField]) {
          this.$set(item, "isCurrent", true);
          if (_this.isMult) {
            item.checked = lastCheck;
          } else {
            item.checked = true;
          }
        } else {
          this.$set(item, "isCurrent", false);
          //单选
          if (!_this.isMult) {
            item.checked = false;
          }
        }
        if (item.isCurrent) {
          if (lastCheck) {
            this.pustOne(item);
          } else {
            this.removeOne(item);
          }
          break;
        }
      }
      if (!_this.isMult) {
        _this.submit();
      }
    },
    submit() {
      let _this = this;
      let codeArry = [];
      let nameArry = [];

      if (this.choosedData.length > this.maxCount) {
        this.$refs.eaglePageList.errorMsg("最多选择" + this.maxCount + "条");
        return;
      }
      this.choosedData.forEach(function (item) {
        codeArry.push(item[_this.idField]);
        nameArry.push(item[_this.textField]);
      });
      let codes = codeArry.join(",");
      let names = nameArry.join(",");

      this.chooseVal = names;
      if (this.autoValue) {
        this.$emit("input", codes);
        this.$emit("update:names", names);
      }
      this.$emit("callBackChoosedData", this.choosedData, codes, names);
      this.close();
    },
    chooseAll() {
      let _this = this;
      this.choosedData = [];
      this.data.forEach(function (item) {
        item.checked = true;
        _this.choosedData.push(item);
      });
      // this.choosedNum = this.choosedData.length;
    },
    cancelChoose() {
      this.choosedData = [];
      this.data.forEach(function (item) {
        item.checked = false;
      });
      // this.choosedNum = 0;
    },
    clear() {
      this.cancelChoose();
      this.$emit("input", "");
      this.$emit("update:names", "");
      this.$emit("callBackChoosedData", [], "", "");
      this.$emit("clear");
      this.close();
    },
    handlerFabClick() {
      let codeEnterprise = "";
      if (this.isUseEnterprise) {
        codeEnterprise = this.$route.query.enterpriseCode ?? "";
      }
      let linkUrl = this.common.getLinkUrl(this.addUrl, {
        id: 0,
        enterpriseCode: codeEnterprise,
        projectId: this.$route.query.projectId ?? ""
      });
      this.base.navigateTo(linkUrl);
    },
    pustOne(obj) {
      let has = false;
      for (let i = 0; i < this.choosedData.length; i++) {
        let item = this.choosedData[i];
        if (item[this.idField] == obj[this.idField]) {
          has = true;
          break;
        }
      }
      if (!has) {
        this.choosedData.push(obj);
      }
    },
    removeOne(obj) {
      let currentNum = -1;
      for (let i = 0; i < this.choosedData.length; i++) {
        let item = this.choosedData[i];
        if (item[this.idField] == obj[this.idField]) {
          currentNum = i;
          break;
        }
      }
      if (currentNum >= 0) {
        this.choosedData.splice(currentNum, 1);
      }
    },
    unChoose(item) {
      if (this.data && this.data.length > 0) {
        let obj = this.data.filter((x) => {
          x[this.idField] == item[this.idField];
        });
        if (obj) {
          this.choose(item, true);
        } else {
          this.removeOne(item);
        }
      } else {
        this.removeOne(item);
      }
    },
    showChoosed() {
      setTimeout(() => {
        this.$refs.EagleChoosedList.show();
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.popup-window {
  .view_row {
    display: flex;
    justify-content: space-between;
    // margin: 0rpx 30rpx;
    background-color: #fff;
  }

  .uni-media-list-text-top {
    line-height: 70rpx;
    text-indent: 20rpx;
  }

  .uni-date__icon-clear {
    top: 10rpx;
    right: 0;
    display: inline-block;
    box-sizing: border-box;
    border: 12rpx solid transparent;
    margin-right: 12rpx;
    cursor: pointer;
  }

  .uni-page-head {
    background-color: rgb(27, 118, 209);
    color: white;
  }

  .list-body {
    flex: 1;
  }
}
</style>
