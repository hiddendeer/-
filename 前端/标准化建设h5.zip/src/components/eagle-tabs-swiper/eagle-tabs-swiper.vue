<template name="eagle-tabs-swiper">
	<view class="u-tabs-box">
		<u-tabs-swiper activeColor="#2979ff" :name="Name" :showBar="false" ref="tabs" :list="dataSource"
			:bar-width="barWidth" :current="swiperCurrent" @change="tabsChange" :is-scroll="false"></u-tabs-swiper>
	</view>
</template>
<script>
	export default {
		name: "eagle-tabs-swiper",
		props: {
			// value: {
			// 	type: Number,
			// 	default () {
			// 		return 1
			// 	}
			// },
			dataSource: {
				type: Array,
				default () {
					return []
				}
			},
			Name: {
				type: String,
				default () {
					return "Name"
				}
			},
			barWidth: {
				Type: Number,
				default () {
					return 100
				}
			},
			showBar: {
				Type: Boolean,
				default () {
					return true
				}
			},
			defaultIndex: {
				Type: Number,
				default () {
					return 0
				}
			},
		},
		data() {
			return {
				swiperCurrent: this.defaultIndex,
			};
		},
		mounted() {
			//this.init();
		},
		computed: {},
		watch: {
			value(nVal, oVal) {
				if (nVal !== oVal) {
					this.swiperCurrent = nVal;
				}
			}
		},
		methods: {
			// init() {
			// 	this.swiperCurrent = this.value;
			// },
			tabsChange(index) {
				this.swiperCurrent = index;//this.current=index;				
				this.$emit("current", index);
				//console.log(this.current)
				//this.$emit("input", index);
				this.$emit("change", index, this.dataSource[index]);
			}
		}
	}
</script>

<style lang="scss">
	.u-tabs-box {
		margin-top: 10rpx;
		background-color: #fff;

		.u-tabs {
			background-color: #fff !important;
		}

		border-bottom: 1px solid #dcdde0;

		.u-tabs-scroll-box {
			.u-scroll-bar {
				margin-bottom: -2px !important;
			}
		}
	}
</style>
