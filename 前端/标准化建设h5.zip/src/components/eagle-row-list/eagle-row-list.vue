<template>
    <view class="list-wrap eagle-row-list">
        <template v-for="(item, index) in list">
            <view class="eagle-flex-between" v-if="index<showCnt" :key="index">
                <view class="row-body">
                    <slot name='list' :item="item" :$index="index"></slot>
                </view>
                <view class="row-item eagle-v-middle" v-if="allowDel">
                    <uni-icons class="del-btn" color='#FF0000' type="trash-filled" size="22" @click="handlerDel(item,index)">
                    </uni-icons>
                </view>
            </view>
            <view v-else-if="index==showCnt" :key="index">
                <u-button class="bottom-btn" type="primary" @click="showMore()" plain>查看更多>></u-button>
            </view>
        </template>
        <eagle-choosed-list :defaultRow="false" :allowDel="allowDel" :chooseArray="list" ref="EagleChoosedList" :title="headTitle" @unChoose="unChoose">
            <template slot="body" slot-scope="scope">
                <view>
                    <slot name='popupBody' :item="scope.item"></slot>
                </view>
            </template>
        </eagle-choosed-list>
    </view>
</template>

<script>
export default {
    name: "eagle-row-list",
    props: {
        list: {
            type: Array,
            default() {
                return [];
            },
        },
        showCnt: {
            type: Number,
            default() {
                return 5;
            },
        },
        allowDel: {
            type: Boolean,
            default() {
                return true;
            },
        },
        headTitle: {
            type: String,
            default() {
                return "更多";
            },
        },
    },
    data() {
        return {};
    },
    created() {},
    watch: {},
    methods: {
        handlerDel(item, index) {
            this.$emit("handlerDel", item, index);
        },
        unChoose(item, index) {
            this.$emit("handlerDel", item, index);
        },
        showMore() {
            this.$refs.EagleChoosedList.show();
        },
    },
};
</script>

<style scoped lang="scss">
.eagle-row-list {
    padding: 0 20rpx;
    .eagle-flex-between {
        border-bottom: 1rpx solid $border-color-light;
        line-height: $font-line-height;
    }
    .row-body {
        flex: 1;
    }
    .row-item {
        width: 40rpx;
    }
}

.eagle-row-list .eagle-flex-between:last-child {
    border-bottom: none;
}
</style>
