<template name="eagle-select-item">
    <u-form-item ref="uFormItem" :label-position="labelPositionVal" :label="title" :required="required" :prop="prop" :label-width="labelWidth">
        <view style="width:100%">
            <eagle-arrow-input @tap="show" v-model="defaultValue" placeholder="请选择行业"></eagle-arrow-input>
        </view>
        <eagle-industry-select :isType="isType" ref="eagleIndustrySelect" :isHeader="isHeader" scrollHeight="calc(100vh - 180rpx)" :marginBottom="marginBottom" :show='industrySelectShow' @industryInformation="industryInformation" @close='industrySelectShow=false'></eagle-industry-select>
    </u-form-item>

</template>

<script>
export default {
    name: "eagle-select-item",
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        title: {
            type: [String],
            default: "",
        },
        model: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        isHeader: {
            type: Boolean,
            default: true,
        },
        placeholder: {
            type: String,
            default: "",
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyShowRequired: {
            type: Boolean,
            default: false,
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        // 高度，单位rpx
        height: {
            type: [Number, String],
            default: "",
        },
        isNumber: {
            type: Boolean,
            default: false,
        },
        //marginBottom 距离底部的高度
        marginBottom: {
            type: String,
            default: "10",
        },
        isType: {
            type: Boolean,
            default: true,
        },
    },
    data() {
        return {
            industrySelectShow: false,
            heightVal:
                this.height != ""
                    ? this.height
                    : this.type === "textarea"
                    ? "60px"
                    : "20px",
            placeholderVal: "",
            labelPositionVal: "",
            defaultValue: this.value,
            inputHeight: 70, // input的高度
            textareaHeight: 100, // textarea的高度
            validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
            focused: false, // 当前是否处于获得焦点的状态
            showPassword: false, // 是否预览密码
            lastValue: "", // 用于头条小程序，判断@input中，前后的值是否发生了变化，因为头条中文下，按下键没有输入内容，也会触发@input时间
        };
    },
    created() {
        this.placeholderVal = this.placeholder
            ? this.placeholder
            : "请选择" + (this.title ? this.title : "内容");
        // 监听u-form-item发出的错误事件，将输入框边框变红色
        //this.$on('on-form-item-error', this.onFormItemError);
        this.labelPositionVal = this.labelPosition
            ? this.labelPosition
            : this.consts.constLabelPosition;
    },
    watch: {
        defaultValue(nVal, oVal) {
            if (this.defaultValue != oVal) {
                if (this.isNumber) {
                    this.$nextTick(function () {
                        nVal = nVal + "";

                        this.defaultValue = Number(
                            nVal.toString().match(/^\d+(?:\.\d{0,2})?/)
                        );
                    });
                } else {
                    this.defaultValue = nVal;
                }

                this.$emit("input", this.defaultValue);
            }
        },
        value(nVal, oVal) {
            this.defaultValue = this.value;
            this.$emit("input", this.defaultValue);
        },
        placeholder(nVal, oVal) {
            if (nVal != oVal) {
                this.placeholderVal = nVal;
            }
        },
    },
    methods: {
        show() {
            debugger;
            this.industrySelectShow = true;
        },
        industryInformation(val) {
            this.$emit("industryInformation", val);
            if (this.industrySelectShow) {
                this.industrySelectShow = false;
            }
        },
        textClick() {
            this.$emit("click");
        },
        valid() {
            let _this = this;
            if (_this.required && _this.onlyShowRequired == false) {
                if (!_this.defaultValue && _this.defaultValue !== 0) {
                    _this.$refs.uFormItem.validateState = "error";
                    _this.$refs.uFormItem.validateMessage =
                        _this.placeholderVal;
                    return false;
                } else if (
                    _this.$refs.uFormItem.validateMessage ===
                    _this.placeholderVal
                ) {
                    _this.$refs.uFormItem.validateState = "";
                }
            }
            return true;
        },
    },
};
</script>

<style lang="scss">
.has-border {
    border: 1px solid #dcdfe6;
    width: 100%;
    box-sizing: border-box;
    border-radius: 4px;
    // background: #E2E2E5;
}

.d-flex {
    display: flex;
    width: 100%;
    align-items: center;
}

.text-style {
    margin-left: 20rpx;
    font-size: 28rpx;
    font-weight: 600;
    color: #2979ff;
}

.custom-style {
    width: 120rpx;
    height: 74rpx;
    color: #55aaff;
    margin-left: 20rpx;
}
</style>
