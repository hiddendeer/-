<template>
    <view class="eagle-layer">
        <!-- <pdf v-for="i in pageTotalNum" v-if="i<=pageSize*(pageIndex-1)+defaultCount" :id="'pdf_'+i" :key="i" :src="url" :page="i">
        </pdf>
        <view v-if="pageIndex<pageCount" style="text-align: center;margin-top: 10px;margin-bottom: 10px;">
            <u-button size="mini" @click.stop="pageIndex=pageIndex+1"> 加载更多</u-button>
        </view> -->
        <iframe height="100%" width="100%" id="videoId" name="videoId" :src="htmlUrl" frameboder="0"></iframe>
        <!-- <eagle-add-round v-if="(!isVideo&&!isLib)&&!(env=='testAfx'||env=='afx')" icon="share" @click="share"></eagle-add-round> -->
    </view>
</template>

<script>
// import pdf from "vue-pdf";
export default {
    // metaInfo: {
    //     meta: [
    //         { charset: 'utf-8' },
    //         { name: 'viewport', content: 'width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=2.0, user-scalable=yes' }
    //     ]
    // },
    components: {
        // pdf,
    },
    name: "eagle-pdf-view",
    props: {
        url: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default: "文件分享",
        },
        summary: {
            type: String,
            default: "",
        },
    },
    data() {
        return {
            pageNum: 1,
            pageTotalNum: 1,
            loadedRatio: 0,
            pageIndex: 1,
            pageSize: 2,
            pageCount: 1,
            defaultCount: 10,
            scale: 100, //放大系数
            idx: -1,
            clauseTitle: "",
            loadedRatio: 0,
            env: "",
        };
    },
    created() {
        this.env = process.env.VUE_APP_ENV;
        uni.setNavigationBarTitle({
            title: this.summary,
        });
    },
    computed: {
        htmlUrl() {
            let isVideo = this.checkIsVideo(this.url);
            if (isVideo) {
                return "/pagehelp/ckplayer/viewer.html?file=" + this.url;
            } else {
                return "/pagehelp/pdfjs/web/viewer.html?file=" + this.url;
            }
        },
        isVideo() {
            return this.checkIsVideo(this.url);
        },
        isLib() {
            if (this.url) {
                if (this.url.indexOf("lib") > -1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
    },

    watch: {},
    methods: {
        // 上一页
        // prePage() {
        //     let page = this.pageNum;
        //     page = page > 1 ? page - 1 : this.pageTotalNum;
        //     this.pageNum = page;
        // },

        // // 下一页
        // nextPage() {
        //     let page = this.pageNum;
        //     page = page < this.pageTotalNum ? page + 1 : 1;
        //     this.pageNum = page;
        // },
        share() {
            console.log(this.summary);
            let param = {
                link: this.url,
                title: this.title,
                summary: this.summary,
            };
            serve.shareToWechat(param).then((x) => {});
        },
        checkIsVideo(url) {
            if (url) {
                if (url.indexOf("avi") > -1 || url.indexOf("mp4") > -1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
    },
};
</script>

<style lang="scss">
.pdf-btn {
    position: fixed;
    bottom: 20rpx;
    width: 100%;
}
</style>
