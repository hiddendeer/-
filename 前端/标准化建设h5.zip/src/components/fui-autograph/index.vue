<template>
  <view class="autograph-page">
    <FuiAutograph
      ref="autograph"
      @ready="ready"
      @autograph="autograph"
    ></FuiAutograph>
    <view class="buttonGroup">
      <view class="left">
        <u-button type="error" class="bottom-btn" @click="cancel()"
          >取消</u-button
        >
        <u-button type="warning" class="bottom-btn" @click="redraw()"
          >重签</u-button
        >
      </view>
      <view class="right">
        <u-button type="primary" class="bottom-btn" @click="goOn()"
          >继续</u-button
        >
        <u-button type="primary" class="bottom-btn" @click="complete()"
          >完成</u-button
        >
      </view>
    </view>
  </view>
</template>

<script>
import FuiAutograph from "./fui-autograph/fui-autograph.vue";
export default {
  onLoad(option) {},
  components: { FuiAutograph },
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      ID: "",
      CompanyCode: "",
      canvasId: "",
      base64List: [],
      watchAutograph: false
    };
  },
  watch: {
    show(nVal, oVal) {
      this.base64List = [];
    }
  },
  methods: {
    autograph(val) {
      this.watchAutograph = val;
    },
    ready(e) {
      console.log(e);
      this.canvasId = e.canvasId;
    },
    //重新签名
    redraw() {
      if (!this.canvasId) return;
      this.$refs.autograph.redraw();
    },
    //继续
    goOn() {
      let self = this;
      if (!self.canvasId) return;
      if (self.base64List.length < 4) {
        self.$refs.autograph.drawComplete(async (res) => {
          //res为签名图片
          self
            .rotateBase64Image(res)
            .then((rotatedBase64Image) => {
              self.base64List.push(rotatedBase64Image);
              self.$refs.autograph.redraw();
            })
            .catch((error) => {
              console.error(error);
            });
        });
      } else {
        uni.showToast({
          title: "仅能连续签字5次",
          icon: "none"
        });
      }
    },
    //完成签名
    complete() {
      let self = this;
      if (!self.canvasId) return;
      if (self.base64List.length == 0) {
        if (this.watchAutograph) {
          self.$refs.autograph.drawComplete(async (res) => {
            //res为签名图片
            self
              .rotateBase64Image(res)
              .then((rotatedBase64Image) => {
                self.base64List.push(rotatedBase64Image);
                self.$emit("complete", self.base64List);
                let timer = setTimeout(() => {
                  clearTimeout(timer);
                  self.cancel();
                }, 200);
              })
              .catch((error) => {
                console.error(error);
              });
          });
        }
      } else {
        if (this.watchAutograph) {
          self.$refs.autograph.drawComplete(async (res) => {
            //res为签名图片
            self
              .rotateBase64Image(res)
              .then((rotatedBase64Image) => {
                self.base64List.push(rotatedBase64Image);
                self.$emit("complete", self.base64List);
                let timer = setTimeout(() => {
                  clearTimeout(timer);
                  self.cancel();
                }, 200);
              })
              .catch((error) => {
                console.error(error);
              });
          });
        } else {
          self.$emit("complete", self.base64List);
          let timer = setTimeout(() => {
            clearTimeout(timer);
            self.cancel();
          }, 200);
        }
      }
    },

    rotateBase64Image(base64Image) {
      return new Promise((resolve, reject) => {
        const image = new Image();
        image.src = `${base64Image}`;

        image.onload = () => {
          const canvas = document.createElement("canvas");
          const context = canvas.getContext("2d");
          canvas.width = image.height;
          canvas.height = image.width;

          // 逆时针旋转 90 度
          context.rotate((-90 * Math.PI) / 180);
          context.drawImage(image, -image.width, 0);

          // 将旋转后的图片数据转为 Base64
          const rotatedBase64Image = canvas.toDataURL("image/png");

          resolve(rotatedBase64Image);
        };

        image.onerror = () => {
          reject(new Error("Failed to load the image."));
        };
      });
    },
    cancel() {
      this.redraw();
      this.$emit("cancel");
    }
  }
};
</script>
<style lang="scss" scoped>
.autograph-page {
  position: relative;
  .fui-autograph__wrap {
    position: absolute;
    top: 0;
    left: 0;
    width: 100vw !important;
    height: 100vh !important;
    /deep/uni-canvas {
      width: 100vw !important;
      height: 100vh !important;
    }
  }
  .buttonGroup {
    width: 90vh;
    display: flex;
    position: absolute;
    top: 50vh;
    left: -40vh;
    transform: rotate(90deg);
    justify-content: space-between;
    .left {
      display: flex;
    }
    .right {
      display: flex;
    }
    .bottom-btn {
      width: 200rpx;
    }
  }
}
</style>
