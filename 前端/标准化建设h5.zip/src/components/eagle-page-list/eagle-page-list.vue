<template name="eagle-page-list">
  <view class="eagle-page-list u-card-wrap">
    <view class="search-slot" v-if="$slots.search">
      <view class="search" :style="{ display: searchDisplay }">
        <slot name="search"></slot>
      </view>
    </view>
    <scroll-view
      scroll-y
      class="scroll page-list-scroll"
      :scroll-top="scrollTop"
      :refresher-enabled="refresherEnabled"
      :refresher-triggered="refresherTriggered"
      :style="{
        height: controllerHeight ? controllerHeight : scrollHeight + 'px'
      }"
      @scroll="scroll"
      @refresherpulling="onPulling"
      @refresherrefresh="onRefresh"
      @refresherrestore="onRestore"
      @refresherabort="onAbort"
      @scrolltolower="reachBottom"
      @showPages="showPages"
    >
      <!-- <u-empty class="eagle-page-empty" v-if="!list||list.length==0" style="height:150px;" text="暂无数据">
            </u-empty> -->
      <slot name="list" :data="list"> </slot>
      <u-loadmore
        :status="loadStatus"
        @loadmore="reachBottom"
        v-if="showPages"
      ></u-loadmore>
    </scroll-view>
    <view :style="{ height: marginBottom + 'px' }"></view>
    <u-toast ref="uToast" />
    <eagle-comfirm ref="eagleConfirm"></eagle-comfirm>
  </view>
</template>
<script>
export default {
  name: "eagle-page-list",
  props: {
    //controller 后台controller名称
    controller: {
      type: String,
      default: ""
    },
    queryUrl: {
      type: String,
      default: ""
    },
    // dataType 请求列表接口 dataType 默认list
    dataType: {
      type: String,
      default: "list"
    },
    // pageSize 每次请求的数量 默认20
    pageSize: {
      type: Number,
      default: 20
    },
    //marginBottom 距离底部的高度
    marginBottom: {
      type: Number,
      default: 0
    },
    cutHeight: {
      type: Number,
      default: 0
    },

    // showCheck 当前列表是不是可以选择
    showCheck: {
      type: Boolean,
      default: false
    },
    showPages: {
      type: Boolean,
      default: true
    },
    // 滚动区域高度
    controllerHeight: {
      type: String,
      default: ""
    },
    //boolInitData 是否需要组件直接调用获取列表接口数据
    boolInitData: {
      type: Boolean,
      default() {
        return true;
      }
    },
    // 列表接口是否需要传入companyCode
    isUseEnterprise: {
      type: Boolean,
      default() {
        return true;
      }
    },
    // 列表接口的其他参数通过queryParams传入
    queryParams: {
      type: Object,
      default: function () {
        return {};
      }
    },
    //搜索是否禁用
    searchDisplay: {
      type: String,
      default: "block"
    },
    conditions: {
      type: Object,
      default: function () {
        return {};
      }
    }
  },
  data() {
    return {
      list: [],
      firstPage: 1,
      params: {
        pageNum: 1,
        pageSize: this.pageSize
      },
      loading: false,
      loadStatus: "loadmore",
      refresherEnabled: false,
      refresherTriggered: false,
      id: "",
      attchFileName: "",
      scrollHeight: 50,
      scrollTop: 0,
      oldScrollTop: 0,
      query: {
        url: "",
        params: {}
        //conditions:""
      }
    };
  },
  created() {},

  computed: {},
  mounted() {
    this.resetTableHeight();
  },

  // onPullDownRefresh() {
  // 	this.getListData();
  // 	uni.stopPullDownRefresh();
  // },
  methods: {
    search(config) {
      var _this = this;
      if (config && config.dataType) {
        this.dataType = config.dataType;
      }
      this.query.url =
        config && config.url
          ? config.url
          : this.controller + "/getPageData?dataType=" + this.dataType;
      this.query.url = this.queryUrl || this.query.url;
      if (config && config.params) {
        this.query.params = this.utils.deepMerge(config.params, this.params);
      } else if (this.queryParams) {
        this.query.params = this.utils.deepMerge(this.queryParams, this.params);
      }
      if (config && config.conditions) {
        this.query.params.conditions = encodeURI(
          JSON.stringify(config.conditions)
        );
      } else {
        if (this.conditions) {
          this.query.params.conditions = this.getCondtionsNew();
        }
      }
      let enterpriseCode = this.$route.query.enterpriseCode;
      if (enterpriseCode && this.isUseEnterprise) {
        if (!this.query.params.companyCode) {
          this.$set(this.query.params, "companyCode", enterpriseCode);
        }
      }
      this.query.params.pageNum = this.firstPage;
      this.getListData();
      this.resetTop();
    },
    onPulling(e) {
      this.$emit("onPulling", e);
    },
    onRefresh() {
      if (this._freshing) return;
      this._freshing = true;
      this.search();
      this.refresherTriggered = "restore";
      setTimeout(() => {
        this.refresherTriggered = false;
        this._freshing = false;
      });
    },
    onRestore() {},
    onAbort() {
      this.refresherTriggered = false;
    },
    scroll(res) {
      this.oldScrollTop = res.detail.scrollTop;
    },
    reachBottom() {
      if (this.loadStatus == "loadmore" && this.showPages) {
        this.query.params.pageNum++;
        this.getListData();
      }
    },
    getListData() {
      uni.showToast({
        icon: "loading"
      });
      this.loadStatus = "loading";
      this.loading = true;
      this.common.get(this.query.url, this.query.params).then((res) => {
        this.loading = false;
        if (res.code == 200) {
          let me = this;
          let datas = res.data.records || res.data;
          if (this.showCheck && datas) {
            datas.forEach(function (item) {
              me.$set(item, "checked", false);
            });
          }
          if (this.query.params.pageNum > this.firstPage) {
            this.list = this.list.concat(datas);
          } else {
            this.list = datas;
          }
          if (!res.hasNextPage) {
            this.loadStatus = "nomore";
          } else {
            this.loadStatus = "loadmore";
          }
          uni.hideToast();
          this.$emit("initList", this.list, res);
        }
      });
    },
    resetTableHeight() {
      let windowHeight = 0;
      var _that = this;
      uni.getSystemInfo({
        success: function (res) {
          // res - 各种参数
          let info = uni.createSelectorQuery().select(".search-slot");
          info
            .boundingClientRect(function (data) {
              //data - 各种参数
              windowHeight =
                res.windowHeight - _that.marginBottom - _that.cutHeight;
              if (data && data.height) {
                windowHeight = windowHeight - data.height;
              }
              _that.scrollHeight = windowHeight;
              //
            })
            .exec();
        }
      });
    },
    resetTop() {
      this.scrollTop = this.oldScrollTop;
      this.$nextTick(function () {
        this.scrollTop = 0;
      });
    },
    realDel(config) {
      let _this = this;
      uni.showToast({
        icon: "loading"
      });
      var url = config.url;
      this.common.del(url, config.params).then(function (res) {
        if (res.code == 200) {
          _this.$refs.uToast.show({
            title: "删除成功",
            type: "success",
            callback: function () {
              if (typeof config.successCallback == "function") {
                config.successCallback(res);
              }
            }
          });
        } else {
          _this.$refs.uToast.show({
            title: "删除失败：" + res.errorText,
            type: "error",
            callback: function () {
              if (typeof config.errorCallback == "function") {
                config.errorCallback(res);
              }
            }
          });
        }
        uni.hideToast();
      });
    },
    del(config) {
      let _this = this;
      if (!config.url) {
        throw new Error("请配置url");
      }
      this.$refs.eagleConfirm.showConfirm({
        content: config.text || "确认是否删除？",
        confirm: function () {
          _this.realDel(config);
        },
        cancel: function () {
          _this.$refs.uToast.show({
            title: "取消删除了",
            type: "error"
          });
        }
      });
    },
    getCondtionsNew() {
      let conditionsArry = [];
      for (let key in this.conditions) {
        let op = this.conditions[key];
        let val = op.value;
        let name = op.name || key;
        let operate = op.operate;
        if (val) {
          conditionsArry.push({
            name: name,
            operate: !operate ? "like" : operate,
            value: val
          });
        }
      }
      return conditionsArry && conditionsArry.length > 0
        ? JSON.stringify(conditionsArry)
        : conditionsArry;
    },
    errorMsg(mes) {
      this.$refs.uToast.show({
        title: mes,
        type: "error"
      });
    },
    successMsg(mes) {
      this.$refs.uToast.show({
        title: mes,
        type: "success"
      });
    },
    fnEventBus(key, callback) {
      let _this = this;
      _this.$bus.$off(key).$on(key, function (data) {
        if (typeof callback == "function") {
          callback(data);
        }
        _this.$bus.$off(key);
      });
    }
  }
};
</script>
<style scoped lang="scss">
uni-page-body {
  overflow: hidden;
}

// .page-list-scroll {
//     background: #fff;
// }
.eagle-page-empty {
  background: #fff;
}

.u-card-wrap {
  overflow: hidden;
  // background-color: $u-bg-color;
  padding: 1px;
}

.search-slot {
  // border-bottom: 1px solid #e0e0e0;
  // background: #fff;
  // margin: 10rpx 20rpx;
  // border-radius: 10rpx;
}

.search {
  padding: 6rpx;
}

.scroll {
  overflow: scroll;
  touch-action: none;
}

.top-status {
  position: absolute;
  right: -28rpx;
  top: -28rpx;
  background-color: #71d5a1;
  padding: 8rpx 16rpx;
  font-size: 8rpx;
  color: #ffffff;
}

.body-content {
  display: flex;
  flex-direction: row;
}

.u-body-item {
  font-size: 32rpx;
  color: #333;
  padding: 10rpx 10rpx;
}

.u-body-item image {
  width: 120rpx;
  flex: 0 0 120rpx;
  height: 120rpx;
  border-radius: 8rpx;
  margin-left: 12rpx;
}

.right-content {
  margin: 20rpx 20rpx;
  font-size: 20rpx;
  font-weight: 500;

  .upload-time {
    margin-top: 20rpx;
    font-size: 10rpx;
    font-weight: 0;
    color: #999999;
  }
}

.foot-content {
  display: flex;
  flex-direction: row;
  justify-content: space-between;

  .btn {
    display: flex;
    flex-direction: row;
    font-size: 14rpx;

    .icon {
      margin-right: 5rpx;
    }
  }
}
</style>
