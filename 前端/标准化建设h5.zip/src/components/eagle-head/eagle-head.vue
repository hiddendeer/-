<template name="eagle-head">
	<view class="eagle-head">
		<uni-page-head uni-page-head-type="default">
		<div class="uni-page-head" style="background-color:rgb(27, 118, 209); color:rgb(255, 255, 255);">
			<div class="uni-page-head-hd">
				<div class="uni-page-head-btn" @click="close">
					<i class="uni-btn-icon" style="color: rgb(255, 255, 255); font-size: 27px;"></i>
				</div>
			</div>
			<div class="uni-page-head-bd">
				<div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
						<slot>
							{{title}}
						</slot>
					</div>
				</div>
			</div>
			<div class="uni-placeholder"></div>
		</uni-page-head>
		<!-- <uni-page-head uni-page-head-type="default">
			<div class="uni-page-head" style="background-color: #1B76D1; color:#FFFFFF">
				<div class="uni-page-head-hd">
					<div class="uni-page-head-btn" @click="close">
						<i class="uni-btn-icon" style="color:#FFFFFF; font-size: 27px;"></i>
					</div>
				</div>
				<div class="uni-page-head-bd">
					<div class="uni-page-head__title" style="font-size: 16px; opacity: 1;">
						 {{title}}
					</div>
				</div>
			</div>
			<div class="uni-placeholder"></div>
		</uni-page-head> -->
	</view>
</template>

<script>
	export default {
		name:"eagle-head",	
		props: {
			title: {
				type: String,
				default () {
					return ""
				}
			},
		},
		data() {
			return {
				
			};
		},
		methods:{
			close(){
				this.$emit("close");
			}
		}
	}
</script>

<style lang="scss">

</style>
