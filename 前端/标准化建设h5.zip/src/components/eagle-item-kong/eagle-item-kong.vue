<template>
	<view v-if="isItem.length===0" class="item-kong">
	 	<image :src="noImgUrl"></image>
	 	<view class="item-kong-text">
	 		暂无数据
	 	</view>
	 </view>	
</template>

<script>
	export default {
		props:{		
			isItem:{
				type: Array,
				default () {
					return []
				}
			}
		},
		data(){
			return{
				noImgUrl: require("@/static/img/no-img.png"),
			}
		}
	}
</script>

<style lang="scss">
	.item-kong{
		text-align: center;
		.item-kong-text{
			color: #c1c1c1;
		}
	}
	
</style>
