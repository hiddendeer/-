<template>
	<view class="eagle-condition">
		<view class="u-search" v-show="!sCondition">
			<view class="u-content" :style="{
					backgroundColor: bgColor,
					borderRadius: shape == 'round' ? '100rpx' : '10rpx',
					height: height + 'rpx'
				}">
				<view class="u-icon-wrap">
					<u-icon class="u-clear-icon" :size="30" :name="searchIcon"
						:color="searchIconColor ? searchIconColor : color"></u-icon>
				</view>
				<input  :disabled="true" :placeholder="placeholder" :value="defaultValue"
					:placeholder-style="`color: ${placeholderColor}`" class="u-input" type="text" @click="showCondition"
					:style="[{
						textAlign: inputAlign,
						color: color,
						backgroundColor: bgColor,
					}, inputStyle]" />
			</view>
			<view class="filter-btn" v-if="fiterShow" @click="handlerFilter">{{fiterTitle}}</view>
		</view>
		<u-mask :show="sCondition" @click="hide" :duration="10" :custom-style="{background: '#f7f7f7'}">
			<view class="condition-block" @tap.stop>
				<eagle-head title="查询" @close="hide" v-if="isHeader"></eagle-head>
				<view class="condition-block-content">
					<view>
						<u-form>
							<slot></slot>
						</u-form>
					</view>
					<view class="view-botton view-botton-row">
						<u-button type="primary" size="medium" style="margin-top: 10rpx;" @click="reset">重置
						</u-button>
						<u-button type="success" size="medium" style="margin-top: 10rpx;" @click="search">查询</u-button>
					</view>
				</view>
			</view>
		</u-mask>
	</view>
</template>

<script>
	import uSearch from '@/uview-ui/components/u-search/u-search.vue'
	export default {
		name: 'eagle-condition',
		props: {
			value: {
				type: String,
				default: ''
			},
			// 搜索框形状，round-圆形，square-方形
			shape: {
				type: String,
				default: 'square'
			},
			// 搜索框背景色，默认值#f2f2f2
			bgColor: {
				type: String,
				default: '#f2f2f2'
			},
			// 占位提示文字
			placeholder: {
				type: String,
				default: '请输入关键字'
			},


			// 输入框内容对齐方式，可选值为 left|center|right
			inputAlign: {
				type: String,
				default: 'left'
			},
			// 是否启用输入框
			disabled: {
				type: Boolean,
				default: false
			},
			// 是否展示查询导航头
			isHeader: {
				type: Boolean,
				default: true
			},
			// 搜索框高度，单位rpx
			height: {
				type: [Number, String],
				default: 64
			},
			// input输入框的样式，可以定义文字颜色，大小等，对象形式
			inputStyle: {
				type: Object,
				default () {
					return {}
				}
			},

			// 搜索图标的颜色，默认同输入框字体颜色
			searchIconColor: {
				type: String,
				default: ''
			},
			// 输入框字体颜色
			color: {
				type: String,
				default: '#606266'
			},
			// placeholder的颜色
			placeholderColor: {
				type: String,
				default: '#909399'
			},

			// 左边输入框的图标，可以为uView图标名称或图片路径
			searchIcon: {
				type: String,
				default: 'search'
			},
			initSearch: {
				type: Boolean,
				default: true
			},
			searchResults: {
				type: [Number, String],
				default: ''
			},
			//搜索框后面按钮
			fiterShow:{
				type: Boolean,
				default: false
			},
			fiterTitle:{
				type: String,
				default: '过滤'
			},
		},
		data() {
			return {

				defaultValue: this.searchResults,
				keyword: '',
				sCondition: false
			}
		},
		watch: {
			keyword(nVal) {
				console.log("nVal: ",nVal);
				this.defaultValue = nVal
				// 双向绑定值，让v-model绑定的值双向变化
				this.$emit('input', nVal)
				// 触发change事件，事件效果和v-model双向绑定的效果一样，让用户多一个选择
				this.$emit('change', nVal)
			},

			searchResults(nVal) {
				console.log("nVal: ",nVal);
				this.defaultValue = nVal
			},

			value: {
				immediate: true,
				handler(nVal) {
				console.log("nVal: ",nVal);
					this.keyword = nVal
					this.defaultValue = nVal
				}
			},

		},
	
		mounted() {
			if (this.initSearch) {
				this.search()
			}
		},
		methods: {
			search() {
				this.$emit('search',this.defaultValue)
				this.hide()
			},
			reset() {
				//this.$emit('input', {});
				this.$emit('reSearch', {})
				this.search()
			},
			showCondition() {
				this.sCondition = !this.sCondition
			},
			show() {
				this.sCondition = true
			},
			hide() {
				this.sCondition = false
			},
		}
	}
</script>


<style lang="scss" scoped>
	@import "@/uview-ui/libs/css/style.components.scss";


	.condition-block {
		background: #fff;
	}

	.condition-block-title {
		background: #f2f2f2;
		color: #000;
		line-height: 100rpx;
		text-align: center;
		font-size: 32rpx;
	}

	.head-icon {
		position: absolute;
		left: 20rpx;
		top: 24rpx;
	}

	.condition-block-content {
		padding: 10rpx;
	}

	.u-search {
		@include vue-flex;
		align-items: center;
		flex: 1;
		padding: 6rpx 16rpx;
	}

	.u-content {
		@include vue-flex;
		align-items: center;
		padding: 0 18rpx;
		flex: 1;
	}

	.u-clear-icon {
		@include vue-flex;
		align-items: center;
	}

	.u-input {
		flex: 1;
		font-size: 28rpx;
		line-height: 1;
		margin: 0 10rpx;
		color: $u-tips-color;
	}

	.u-close-wrap {
		width: 40rpx;
		height: 100%;
		@include vue-flex;
		align-items: center;
		justify-content: center;
		border-radius: 50%;
	}

	.u-placeholder-class {
		color: $u-tips-color;
	}

	.u-action {
		font-size: 28rpx;
		color: $u-main-color;
		width: 0;
		overflow: hidden;
		transition: all 0.3s;
		white-space: nowrap;
		text-align: center;
	}

	.u-action-active {
		width: 80rpx;
		margin-left: 10rpx;
	}
	
	.filter-btn{
		width: 100rpx;
		height: 100%;
		text-align: center;
		font-size: 30rpx;
		color: #999999;
	}
</style>
