<template>
    <Condition @search="search" @reSearch="reSearch" v-model='conditionValue'>
        <u-form-item ref="uFormItem" :label-position="labelPosition" :label="title" :prop="prop" :label-width="labelWidth">
            <u-input :height="76" v-model="selectValue" placeholder='统计年度' type="select" @click="selectShow = true" />
            <u-select :list="actionSheetList" v-model="selectShow" @confirm="handlerSelect">
            </u-select>
        </u-form-item>
    </Condition>
</template>

<script>
import Condition from "./eagle-condition.vue";
export default {
    name: "eagle-popup-search",
    components: { Condition },
    props: {
        title: {
            type: [String],
            default: "",
        },
        prop: {
            type: [String],
            default: "",
        },
        placeholder: {
            type: String,
            default: "统计年度",
        },
        labelPosition: {
            type: String,
            default: "top",
        },
        labelWidth: {
            type: String,
            default: "120",
        },
        height: {
            type: String,
            default: "70",
        },
        conditionValue: {
            type: String,
            default: "2022",
        },
    },
    data() {
        return {
            selectShow: false,
            selectValue: "2022",
            // conditionValue:"2022年",
            actionSheetList: [
                { label: "2019", value: "2019" },
                { label: "2020", value: "2020" },
                { label: "2021", value: "2021" },
                { label: "2022", value: "2022" },
                { label: "2023", value: "2023" },
                { label: "2024", value: "2024" },
                { label: "2025", value: "2025" },
                { label: "2026", value: "2026" },
                { label: "2027", value: "2027" },
            ],
        };
    },
    methods: {
        handlerSelect(val) {
            this.selectValue = val[0].label;
            this.conditionValue = val[0].value;
        },
        search(val) {
            this.$emit("search", val);
        },
        reset() {
            //this.$emit('input', {});
            this.$emit("reSearch", "");
            this.search();
        },
    },
};
</script>

<style>
</style>
