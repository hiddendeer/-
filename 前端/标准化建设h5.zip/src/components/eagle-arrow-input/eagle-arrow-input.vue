<template>
    <view class="u-input" :class="{
			'u-input--error': validateState
		}" @click.stop="handleClick">
        <input class="u-input__input auto-flex" style="width:100%" type="text" :disabled="disabled" :value="defaultValue" :placeholder="placeholder" confirmType="done" @input="handleInput" @confirm="onConfirm" />
        <view class="u-input__right-icon u-flex">
            <view class="u-input__right-icon--select u-input__right-icon__item">
                <u-icon name="arrow-down-fill" size="26" color="#c0c4cc"></u-icon>
            </view>
        </view>
    </view>
</template>

<script>
import Emitter from "@/uview-ui/libs/util/emitter.js";
export default {
    name: "eagle-arrow-input",
    mixins: [Emitter],
    props: {
        value: {
            type: [String, Number],
            default: "",
        },
        placeholder: {
            type: String,
            default: "",
        },
        disabled: {
            type: Boolean,
            default: true,
        },
    },

    data() {
        return {
            defaultValue: this.value,
            lastValue: "",
            validateState: false, // 当前input的验证状态，用于错误时，边框是否改为红色
        };
    },
    created() {
        this.$on("on-form-item-error", this.onFormItemError);
    },
    watch: {
        value(nVal, oVal) {
            this.defaultValue = nVal;
        },
    },
    methods: {
        handleInput(event) {
            let value = event.detail.value;
            if (this.trim) value = this.$u.trim(value);
            this.$emit("input", value);
            this.defaultValue = value;
            setTimeout(() => {
                // #ifdef MP-TOUTIAO
                if (this.$u.trim(value) == this.lastValue) return;
                this.lastValue = value;
                // #endif
                this.dispatch("u-form-item", "on-form-change", value);
            }, 40);
        },
        onConfirm(e) {
            this.$emit("confirm", e.detail.value);
        },
        onFormItemError(status) {
            this.validateState = status;
        },
        handleClick() {
            this.$emit("click");
        },
    },
};
</script>

<style scoped lang="scss">
.u-input {
    position: relative;
    display: flex;
    flex: 1;
    &__input {
        font-size: 28rpx;
        color: $u-main-color;
        flex: 1;
        min-height: 70rpx;
    }

    &--error {
        border-color: $u-type-error !important;
    }

    &__right-icon {
        &__item {
            margin-left: 10rpx;
        }

        &--select {
            transition: transform 0.4s;
            max-width: 70rpx;
            &--reverse {
                transform: rotate(-180deg);
            }
        }
    }
    .uni-input-placeholder {
        color: #ccc;
    }
}
</style>
