<template>
    <view class="eagle-form-block">
        <view class="eatle-form--title" v-if="title||subTitle">
            <view class="eagele-form-title" v-if="title">
                {{title}}
            </view>
            <view class="eagele-form-subtitle" v-if="subTitle||$slots.otherSolot">
                {{subTitle}}
                <slot name="otherSolot"></slot>
            </view>
        </view>
        <view>
            <slot></slot>
        </view>
    </view>
</template>

<script>
/**
 * form 表单
 * @property {Object} model 表单数据对象
 * @property {String} postUrl 提交表单add    接口地址 如果未传值 会用 Control/AddPost
 * @property {String} initUrl 获取初始化实体  接口地址 如果未传值 会用 Control/InitNewEntity
 * @property {String} detailUrl 获取编辑对象    接口地址 如果未传值 会用 Control/GetDetail
 * @property {String} control 后台Control名称
 */
export default {
    name: "eagle-form-block",
    props: {
        title: {
            type: String,
            default() {
                return "";
            },
        },
        subTitle: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {};
    },
    created() {},
    watch: {},
    mounted() {},
    methods: {},
};
</script>

<style lang="scss" scoped>
.eagle-form-block {
    background: #fff;
    border-radius: 10rpx;
    margin-bottom: 20rpx;
    overflow: hidden;
    margin: 20rpx;
    .eatle-form--title {
        padding: 26rpx;
        font-weight: 800;
        font-size: $font-base;
        border-bottom: 1rpx solid $border-color-base;
        justify-content: space-between;
        display: flex;
        .eagele-form-title {
            color: $font-color-dark;
            display: inline-block;
        }
        .eagele-form-subtitle {
            color: $font-color-base;
            display: inline-block;
        }
    }
}
</style>
