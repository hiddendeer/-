<template>
	  <u-icon v-bind="$attrs" v-on="$listeners" :color="color" :labelColor="color">
	        <slot />
	    </u-icon>
</template>

<script>
	export default {
		name:"eagle-icon",
		props:{
			color: {
				type: String,
				default: "#999",
			},
		},
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
