/**
 *所有需要全局注册的通用方法,在 utils.js 注册，具体看 utils.js 
 *所有需要全局注册的通用组件,在 components.js 注册，具体看 components.js 
 */
import Vue from 'vue';
import App from './App';
import $utils from '@/utils.js'
Vue.prototype.utils = $utils;
Vue.config.productionTip = false;
App.mpType = 'app';

// 引入echarts
import EcharStyle from '@/common/js/echarts-case.js'
Vue.prototype.$echartsCase = EcharStyle;

// 此处为演示Vue.prototype使用，非uView的功能部分
Vue.prototype.vuePrototype = '枣红';

import $consts from '@/consts.js'

Vue.prototype.consts = $consts;

Vue.prototype.$bus = new Vue();

let $off = Vue.prototype.$bus.$off;
let $on = Vue.prototype.$bus.$on;
let $emit = Vue.prototype.$bus.$emit;
Vue.prototype.$bus.$off = (key) => {
	//此处做交互
	//发现有交互，把事件递交到安卓或ios
	$off.call(Vue.prototype.$bus, key);
	// window.eventCallback = null;
	window["eventCallback" + key] = null;
	return Vue.prototype.$bus;
}

Vue.prototype.$bus.$on = (key, callback) => {
	$on.call(Vue.prototype.$bus, key, callback);

	// window.eventCallback = callback;

	window["eventCallback" + key] = (value) => {
		console.log("http======原始>", value + "");
		value = value.replace(/\r/g, "\\r");
		value = value.replace(/\n/g, "\\n");
		value = value.replace(/\t/g, "\\t");
		value = value.replace(/\\/g, "\\\\");
		// value = value.replace(/\'/g, "&#39;");
		// value = value.replace(/ /g, "&nbsp;");
		// value = value.replace(/</g, "$lt;");
		// value = value.replace(/>/g, "$gt;");

		console.log("http======eventCallback value>", value + "");
		console.log("http======eventCallbackJSONvalue>", JSON.parse(value + ""));
		callback(JSON.parse(value + ""))
	}

	console.log("http======key>", "eventCallback" + key);
	console.log("Vue.prototype.$bus.$on");
	// console.log(window);
	return Vue.prototype.$bus;
}

Vue.prototype.$bus.$emit = (key, value) => {
	let _this = this;
	let userAgent = navigator.userAgent;
	let isNext = true; //把获取的到值传给H5 还是交互

	if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
		isNext = true;
	} else if (window.jsListener) { // 安卓
		isNext = false;
		console.log("http========key>", key);
		console.log("http========value>", JSON.stringify(value));
		window.jsListener.eventCallbackWithKeyValue(key, JSON.stringify(value));
	} else {
		if (window.webkit) { //iOS
			if (window.webkit.messageHandlers) {
				if (window.webkit.messageHandlers.eventCallbackWithKeyValue) {
					isNext = false;

					console.log("http========key>", key);
					console.log("http========value>", JSON.stringify(value));

					window.webkit.messageHandlers.eventCallbackWithKeyValue.postMessage({ key: key, value: JSON.stringify(value) });
				}
			}
		}
	}

	if (isNext) {

		$emit.call(Vue.prototype.$bus, key, value);
	}




	return Vue.prototype.$bus;
}

// 引入全局uView
import uView from 'uview-ui';
Vue.use(uView);

//全局引用eagleBase文件夹下的组件
// import eagleBase from '@/components/eagle-base';
// Vue.use(eagleBase);

// 此处为演示vuex使用，非uView的功能部分
import store from '@/store';

// 引入uView提供的对vuex的简写法文件
let vuexStore = require('@/store/$u.mixin.js');
Vue.mixin(vuexStore);

// 引入uView对小程序分享的mixin封装
let mpShare = require('uview-ui/libs/mixin/mpShare.js');
Vue.mixin(mpShare);

// i18n部分的配置
// 引入语言包，注意路径
import Chinese from '@/common/locales/zh.js';
import English from '@/common/locales/en.js';

// VueI18n
import VueI18n from '@/common/vue-i18n.min.js';

//全局过滤
import * as filters from '@/common/filters.js'
Object.keys(filters).forEach(key => {
	Vue.filter(key, filters[key]) //插入过滤器名和对应方法
})

import "@/uni.scss";
import "@/common.scss";
// VueI18n
Vue.use(VueI18n);

const i18n = new VueI18n({
	// 默认语言
	locale: 'zh',
	// 引入语言文件
	messages: {
		'zh': Chinese,
		'en': English,
	}
});

import {
	router,
	RouterMount
} from './router/router.js'

Vue.use(router)

App.mpType = 'app'

Vue.mixin({
	onNavigationBarButtonTap({ type }) {
		if (type == 'home') {
			uni.reLaunch({
				url: '/pages/home/home'
			})
		}
	}
})

// 由于微信小程序的运行机制问题，需声明如下一行，H5和APP非必填
Vue.prototype._i18n = i18n;
const app = new Vue({
	i18n,
	store,
	...App //,
});

// http拦截器，将此部分放在new Vue()和app.$mount()之间，才能App.vue中正常使用
import httpInterceptor from '@/common/http.interceptor.js';
Vue.use(httpInterceptor, app);

// http接口API抽离，免于写url或者一些固定的参数
import httpApi from '@/common/http.api.js';
Vue.use(httpApi, app);

// 全局通用方法
import common from "@/common/common.js";
Vue.prototype.common = common;

// 全局通用方法
import base from "@/common/base.js";
Vue.prototype.base = base;




//v1.3.5起 H5端 你应该去除原有的app.$mount();使用路由自带的渲染方式
// #ifdef H5
RouterMount(app, router, '#app')
// #endif


// app.$mount(); //为了兼容小程序及app端必须这样写才有效果


