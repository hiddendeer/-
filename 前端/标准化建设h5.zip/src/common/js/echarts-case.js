import echarTopPie from './echarStyleJs/echarTopPie'
import echarBar from './echarStyleJs/echarBar'
import echarStyle4 from "./echarStyleJs/echarStyle4";

export default {
    echarTopPie,
    echarBar,
    echarStyle4
}
