import * as echarts from 'echarts'
const echarStyle = (id, data, label, score, bgcolor) => {
    let a = document.getElementById(id)
    if (!a) {return;}
    let myChart = echarts.init(document.getElementById(id))
    function dynamicFontSize(size) {
        return uni.upx2px(size)
    }

    // console.log('data', data);
    // console.log('label', label);
    // console.log('fullMark', fullMark);
    // console.log('score', score);

    var salvProMax = [];
    for (var i = 0; i < data.length; i++) {
        salvProMax.push(100);
    }

    let option = {
        title: {
            show: false
        },
        tooltip: {
            show: false
        },
        grid: {
            borderWidth: 0,
            top: "2%",
            left: "4%",
            right: "6%",
            bottom: "0%"
        },
        color: "rgba(255,75,75,1)",
        yAxis: [
            {
                type: "category",
                inverse: true,
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false
                },
                axisLabel: {
                    show: false,
                    inside: false
                },
                data: label
            },
        ],
        xAxis: {
            type: "value",
            axisTick: {
                show: false
            },
            axisLine: {
                show: false
            },
            splitLine: {
                show: false
            },
            axisLabel: {
                show: false
            }
        },
        series: [

            {
                name: "",
                type: "bar",
                zlevel: 2,
                barWidth: "7%",
                data: data,
                animationDuration: 1000,
                itemStyle: {
                    normal: {
                        show: true,
                        borderRadius: dynamicFontSize(10),
                        color: '#409EFF'
                    }
                },
                label: {
                    normal: {
                        color: "#b3ccf8",
                        rich: {
                            a1: {
                                width: 5,
                                height: 5,
                                backgroundColor: "#85c1ff",
                                borderRadius: 50
                            }
                        },
                        show: true,
                        position: [0, "-600%"],
                        textStyle: {
                            color: "#333333",
                            fontSize: dynamicFontSize(28),
                            fontWeight: 'bold'
                        },
                        formatter: function (a, b) {
                            return ["{a1|" + "}" + "  " + a.name].join("\n");
                        }
                    }
                }
            },
            {
                name: "",
                type: "bar",
                zlevel: 1,
                barWidth: "7%",
                data: salvProMax,
                animationDuration: 1000,
                itemStyle: {
                    normal: {
                        borderRadius: dynamicFontSize(10),
                        color: "#F4F5F7"
                    }
                },
                // label: {
                //     normal: {
                //         color: "#b3ccf8",
                //         show: true,
                //         position: ['80%', "-700%"],
                //         textStyle: {
                //             color: "#000",
                //             fontSize: dynamicFontSize(30),
                //         },
                //         formatter: function (a, b) {
                //             return `满分:${fullMark[a.dataIndex]}分`;
                //         }
                //     }
                // }
            },
            {
                name: "",
                type: "bar",
                zlevel: 1,
                barWidth: "7%",
                data: data,
                animationDuration: 1000,
                itemStyle: {
                    normal: {
                        borderRadius: dynamicFontSize(10),
                        color: "#F4F5F7"
                    }
                },
                label: {
                    normal: {
                        color: "#b3ccf8",
                        show: true,
                        position: ['95%', "-300%"],
                        textStyle: {
                            color: "#999999",
                            fontSize: dynamicFontSize(26),
                        },
                        formatter: function (a, b) {
                            return `${score[a.dataIndex]}分`;
                        }
                    }
                }
            },
            // {
            //     name: "",
            //     type: "bar",
            //     zlevel: 1,
            //     barWidth: "7%",
            //     data: data,
            //     animationDuration: 1000,
            //     itemStyle: {
            //         normal: {
            //             borderRadius: dynamicFontSize(10),
            //             color: "#F4F5F7"
            //         }
            //     },
            //     label: {
            //         normal: {
            //             color: "#b3ccf8",
            //             show: true,
            //             position: ['95%', "300%"],
            //             textStyle: {
            //                 color: "#999999",
            //                 fontSize: dynamicFontSize(26),
            //             },
            //             formatter: function (a, b) {
            //                 return `${a.data}%`;
            //             }
            //         }
            //     }
            // },
            {
                name: "",
                type: "scatter",
                zlevel: 3,
                data: data,
                label: {
                    normal: {
                        show: false
                    }
                },
                symbolSize: 12,
                itemStyle: {
                    normal: {
                        color: "#409EFF",
                        opacity: 1,
                        borderColor: "#85C1FF",
                        borderWidth: 4,
                    }
                }
            },
            {
                name: "",
                type: "bar",
                barWidth: "7%",
                barGap: "-100%",
                data: salvProMax,
                itemStyle: {
                    normal: {
                        borderRadius: 5,
                        color: "#F4F5F7"
                    }
                },
                tooltip: {
                    show: false
                }
            }
        ],
        animationEasing: "cubicOut"
    };

    myChart.setOption(option)
    window.addEventListener('resize', () => {
        myChart.resize()
    })
}

export default echarStyle
