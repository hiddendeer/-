import * as echarts from "echarts";
import "echarts-liquidfill";
import { getColor, getPaColor } from "./common";
const echarStyle4 = (id, value, title="总分") => {
	let data = [0.2, 0.18, 0.15, 0.1];
	let a = document.getElementById(id)
	if (!a) { return; }
	let myChart = echarts.init(document.getElementById(id));
	let option = {
		title: {
			text: value,
			textStyle: {
				fontSize: 32,
				color: (title && title == '绩效评价得分') ? getPaColor(value) : getColor(value),
			},
			x: "center",
			y: "20%",
		},
		graphic: [
			{
				type: "group",
				left: "center",
				top: "55%",
				children: [
					{
						type: "text",
						z: 100,
						top: "middle",
						style: {
							fill: "#666",
							text: title,
							fontSize: 12,
							fontWeight: 'bold'
						},
					},
				],
			},
		],
		series: [
			{
				type: "liquidFill",
				radius: "80%",
				center: ["50%", "50%"],
				data,
				color: new Array(data.length).fill((title && title == '绩效评价得分') ? getPaColor(value) : getColor(value)),
				backgroundStyle: {
					color: "#fff",
				},
				outline: {
					borderDistance: 0,
					itemStyle: {
						borderWidth: 2,
						borderColor: (title && title == '绩效评价得分') ? getPaColor(value) : getColor(value),
					},
				},
				label: {
					formatter: "",
				},
			},
		],
	};
	myChart.setOption(option);
	window.addEventListener("resize", () => {
		myChart.resize();
	});
};

export default echarStyle4;
