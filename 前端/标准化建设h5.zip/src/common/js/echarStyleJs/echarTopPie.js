import * as echarts from 'echarts'
const echarStyle = (id, data, label, proportion, bgcolor) => {
  document.getElementById(id).removeAttribute('_echarts_instance_')
  let myChart = echarts.init(document.getElementById(id))
  function dynamicFontSize(size) {
    return uni.upx2px(size)
  }
  let option = {
    title: {
      text: data[0] + '%',
      x: 'center',
      y: 'center',
      textStyle: {
        fontWeight: "normal",
        color: "#000",
        fontSize: dynamicFontSize(30),
        lineHeight: dynamicFontSize(30)
      },
    },
    tooltip: {
      show: false
    },
    toolbox: {
      show: false
    },
    legend: {
      show: false
    },
    polar: {
      radius: ['90%', '75%'],
      center: ['50%', '50%'],
    },
    angleAxis: {
      max: 100,
      show: false,
    },
    radiusAxis: {
      type: 'category',
      show: true,
      axisLabel: {
        show: false,
      },
      axisLine: {
        show: false,

      },
      axisTick: {
        show: false
      },
    },
    series: [
      {
        name: '',
        type: 'bar',
        roundCap: true,
        barWidth: 60,
        showBackground: true,
        backgroundStyle: {
          color: '#F4F5F7',
        },
        data: data,
        coordinateSystem: 'polar',
        itemStyle: {
          normal: {
            color: bgcolor
          }
        }
      },
      {
        name: '',
        type: 'pie',
        startAngle: 90,
        radius: ['0%', '60%'],
        hoverAnimation: false,
        center: ['50%', '50%'],
        itemStyle: {
          normal: {
            labelLine: {
              show: false
            },
            color: '#F4F5F7',
          }
        },
        data: [{
          value: 100,

        }]
      },

    ]
  }
  myChart.setOption(option)
  window.addEventListener('resize', () => {
    myChart.resize()
  })
}

export default echarStyle
