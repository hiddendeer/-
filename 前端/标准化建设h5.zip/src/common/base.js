var base = {
	isApp() {
		if (this.isWeixin()) {
			return false;
		} else if (window.jsListener) { // 安卓
			return true;
		} else {
			if (window.webkit) { //iOS
				if (window.webkit.messageHandlers) {
					if (window.webkit.messageHandlers.doBack) {
						return true;
					}
				}
			}
		}
		return false;
	},
	isGuanGuan() {
		let userAgent = navigator.userAgent;
		if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
			return true;
		}
		return false;
	},
	isWeixin() {
		var ua = navigator.userAgent.toLowerCase();
		if (ua.match(/MicroMessenger/i) == 'micromessenger') {//微信
			return true;
		} else if (ua.match(/wxwork/i) == 'wxwork') { //企业微信
			return true;
		} else {
			return false;
		}

	},

	navigateBack(num) {
		num = num || 1;
		let userAgent = navigator.userAgent;
		let isNext = true; //判断是否返回 还是交互

		if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
			isNext = true;
		} else if (this.isWeixin()) {
			isNext = true;
		} else if (window.jsListener) { // 安卓
			isNext = false;
			window.jsListener.doBackNum(num, false);

		} else {
			if (window.webkit) { //iOS
				if (window.webkit.messageHandlers) {
					if (window.webkit.messageHandlers.doBack) {
						isNext = false;
						window.webkit.messageHandlers.doBack.postMessage({ num: num, refresh: false });
					}
				}
			}
		}
		if (isNext) {
			console.log("navigateBack----num", num)
			uni.navigateBack({ delta: num });
		}
	},

	navigateTo(url) {
		let site = process.env.VUE_APP_Site_Url;
		let flag = process.env.VUE_APP_Flag;
		console.log(site);
		console.log(flag);
		let userAgent = navigator.userAgent;
		let isNext = true; //判断是否进入下一页。原生交互则不需要进行下一步
		if (userAgent && userAgent.indexOf("Guansafety") >= 0) {
			isNext = true;
		} else if (this.isWeixin()) {
			isNext = true;
		} else if (window.jsListener) { // 安卓
			isNext = false;
			//拼全路径
			url = site + flag + '#' + url;
			window.jsListener.NoPush(url);

		} else {
			if (window.webkit) { //iOS
				if (window.webkit.messageHandlers) {
					if (window.webkit.messageHandlers.NoPush) {
						isNext = false;
						//拼全路径
						url = site + flag + '#' + url;
						
						
						window.webkit.messageHandlers.NoPush.postMessage(url);
					}
				}
			}
		}
		if (isNext) {
			if (url.indexOf("http") >= 0) {
				window.location.href = url;
			} else {
				uni.navigateTo({ url: url });
			}
		}
	},

}
export default base
