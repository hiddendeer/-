import $timeFormat from '@/uview-ui/libs/function/timeFormat.js'

export function imageFormat(val) {
	if (val) {
		var arry = val.split(';');
		return arry[0];
	}
	return "";
}

export function dateFormat(val) {

	if (val) {
		try {
			if (val.length == 10)
				return val
			let date = $timeFormat(val.replace(/-/g, "/"), "yyyy-mm-dd")
			return date;
		} catch (error) {
			return val
		}
	}
	return "无";
}

export function dateTimeFormat(val) {
	if (val) {
		try {
			let date = $timeFormat(val.replace(/-/g, "/"), "yyyy-mm-dd hh:MM")
			return date;
		} catch (error) {
			return val
		}
	}
	return "";
}

export function timeFormat(val) {
	if (val) {


		try {
			let date = $timeFormat(val.replace(/-/g, "/"), "hh:MM")
			return date;
		} catch (error) {
			return val
		}
	}
	return "";
}

export function customFormat(val) {
	if (val && typeof (val) == "string") {
		val = val.replace("Custom-", "").replace("Custom", "");
		return val;
	}
	return "";
}

export function paramsFormat(val, list) {
	if (val) {
		if (list != undefined && list.length > 0) {
			for (let i = 0; i < list.length; i++) {
				if (val == list[i].id) {
					val = list[i].name;
				}
			}
		}
		var type = typeof (val);
		if (type == "string") {
			val = val.replace("Custom-", "").replace("Custom", "");
		}
		return val;
	}
	return "";
}


export function paramsMultFormat(val, list) {
	let returnVal = "";
	let retrunArry = [];
	if (val) {
		if (list != undefined && list.length > 0) {
			let arry = val.split(',');
			for (let i = 0; i < list.length; i++) {
				for (let ii = 0; ii < arry.length; ii++) {
					if (arry[ii] == list[i].id) {
						retrunArry.push(list[i].name);
					}
				}

			}
		}
	}
	if (retrunArry.length > 0) {
		returnVal = retrunArry.join(",");
	}
	return returnVal;
}



export function twoDecimal(val) {

	if (val) {
		var type = typeof (val);

		if (type == "string") {
			val = parseFloat(val);
		}
		val = val.toFixed(2);

		return val;
	}
	return "0.00";
}


export function splitParamsFormat(val, list) {
	if (val) {

		var arry = val.split(",");
		var strArr = [];
		for (let j = 0; j < arry.length; j++) {
			if (list != undefined && list.length > 0) {
				for (let i = 0; i < list.length; i++) {
					if (arry[j] == list[i].id) {
						strArr.push(list[i].name);
					}
				}
			}
		}
		return strArr.join(",");
	}
	return "";
}

export function splitCountFormat(val) {
	if (val) {
		var arry = val.split(",");
		return arry.length;
	}
	return 0;
}

export function nullFormat(val) {

	if (val) {
		return val;
	} else {
		return "无";
	}
}

export function attExtFormat(val) {
	if (val && typeof (val) == "string") {
		val = val.replace(".", "");
		val = val.toUpperCase();
		return val;
	}

	return ";"

}

export function toChinesNum(num) {
	let changeNum = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']; //changeNum[0] = "零"
	let unit = ["", "十", "百", "千", "万"];
	num = parseInt(num);
	let getWan = (temp) => {
		let strArr = temp.toString().split("").reverse();
		let newNum = "";
		for (var i = 0; i < strArr.length; i++) {
			newNum = (i == 0 && strArr[i] == 0 ? "" : (i > 0 && strArr[i] == 0 && strArr[i - 1] == 0 ? "" :
				changeNum[strArr[i]] + (strArr[i] == 0 ? unit[0] : unit[i]))) + newNum;
		}
		return newNum;
	}
	let overWan = Math.floor(num / 10000);
	let noWan = num % 10000;
	if (noWan.toString().length < 4) noWan = "0" + noWan;
	return overWan ? getWan(overWan) + "万" + getWan(noWan) : getWan(num);
}

export function moneyFormat(val) {
	if (val) {
		return number_format(val, 2);
	}
	return val;
}


function number_format(number, decimals, dec_point, thousands_sep) {
	/*
	 * 参数说明：
	 * number：要格式化的数字
	 * decimals：保留几位小数
	 * dec_point：小数点符号
	 * thousands_sep：千分位符号
	 * */
	number = (number + '').replace(/[^0-9+-Ee.]/g, '');
	var n = !isFinite(+number) ? 0 : +number,
		prec = !isFinite(+decimals) ? 2 : Math.abs(decimals),
		sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
		dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
		s = '',
		toFixedFix = function (n, prec) {
			var k = Math.pow(10, prec);
			return '' + Math.ceil(n * k) / k;
		};

	s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
	var re = /(-?\d+)(\d{3})/;
	while (re.test(s[0])) {
		s[0] = s[0].replace(re, "$1" + sep + "$2");
	}

	if ((s[1] || '').length < prec) {
		s[1] = s[1] || '';
		s[1] += new Array(prec - s[1].length + 1).join('0');
	}
	return s.join(dec);
}

// export function statusFormat(val, params, types) {
// 	let type = "primary";
// 	if (!types) {
// 		let typeObject = this.types.find(x => x.id == val);
// 		if (typeObject) {
// 			type = typeObject.type;
// 		}
// 	}
// 	let obj = params.find(x => x.id == val);
// 	if (obj)
// 		return `<span class='${type}'>${obj.name} </span>`
// 	else
// 		return "--"
// }
