import request from '@/common/request.js'
import $timeFormat from '@/uview-ui/libs/function/timeFormat.js'
import base from '@/common/base.js';

var common = {
	// *
	//  * 获取字典参数
	//  * @param {String} paramID

	getparams: function (paramid) {
		var params = {
			paramid: paramid
		}
		return request({
			url: "/danger/params/getParamslist",
			method: 'get',
			params
		})
	},
	formateStatus(datas, value, propId, propName) {
		let id = propId ? propId : 'id';
		let name = propName ? propName : 'name';
		if (!value && value != 0)
			return "";
		let obj = datas.find((x) => x[id] && x[id].toString() === value.toString());
		if (obj && obj[id])
			return `<span style='color:${obj["color"]}'>${obj["name"]}</span>`;
		return "";
	},
	getModuleSettins: function (moduleCode) {
		return request({
			url: "/danger/settingItem/settingKV/" + moduleCode,
			method: 'get'
		})
	},

	getCustomDict: function (keys) {
		let params = {
			paramsIds: keys
		}
		return request({
			url: "/danger/settingItem/getCustomDicts",
			method: 'get',
			params
		})
	},
	getparamsList: function (paramIDs) {
		var params = {
			paramIds: paramIDs
		}
		return request({
			url: "/system/dict/data/paramsLists",
			method: 'get',
			params
		})
	},
	post: function (url, data) {
		return request({
			url: url,
			method: 'post',
			data
		})
	},

	get: function (url, params) {
		return request({
			url: url,
			method: 'get',
			params
		})
	},

	put: function (url, params) {
		return request({
			url: url,
			method: 'put',
			data: params
		})
	},

	del: function (url, params) {
		return request({
			url: url,
			method: 'delete',
			params: params
		})
	},

	postBase64: function () {
		if (base.isApp() || base.isGuanGuan()) {
			return new Promise(function (resolve, reject) {
				serve.signature().then(res => {
					return request({
						url: "file/saveSinature",
						method: 'post',
						data: res.data
					}).then(resp => {
						resolve(resp);
					}).catch(err => {
						reject(err);
					})
				})
			})
		} else {
			return new Promise(function (resolve, reject) {
				let resp = {
					code: 200,
					data: []
				};
				resp.data.push("https://mky.ehsway.com/minio/eagle/20220823/09959/887596ad-51d1-49ac-9e5e-7f480df8081e.png");
				resp.data.push("https://mky.ehsway.com/minio/eagle/20220823/09959/887596ad-51d1-49ac-9e5e-7f480df8081e.png");
				resolve(resp);
			})
		}

	},

	fuiPostBase64: function (res) {
		return new Promise(function (resolve, reject) {
			return request({
				url: "file/saveSinature",
				method: 'post',
				data: res
			}).then(resp => {
				resolve(resp);
			}).catch(err => {
				reject(err);
			})
		})
	},

	paramsFormat: function (val, list) {
		if (val) {
			if (val.indexOf(",") >= 0) {
				val = paramsMultFormat(val, list);
				return val;
			}
			else {
				if (list != undefined && list.length > 0) {
					for (let i = 0; i < list.length; i++) {
						if (val == list[i].id) {
							val = list[i].name;
						}
					}
				}
				val = val.replace("Custom-", "").replace("Custom", "");
				return val;
			}

		}
		return "";
	},
	paramsMultFormat: function (val, list) {
		let returnVal = "";
		let retrunArry = [];
		if (val) {
			if (list != undefined && list.length > 0) {
				let arry = val.split(',');
				for (let i = 0; i < list.length; i++) {
					for (let ii = 0; ii < arry.length; ii++) {
						if (arry[ii] == list[i].id) {
							retrunArry.push(list[i].name);
						}
					}

				}
			}
		}
		if (retrunArry.length > 0) {
			returnVal = retrunArry.join(",");
		}
		return returnVal;
	},


	/***
	 * datas 字典数据源
	 * value 值 
	 * propId 值字典字段名 默认 'id'
	 * propName  显示 字典字段名 默认'name'
	 * separator 分割符 默认 ','
	 */
	formateDict: function (datas, value, propId, propName, separator) {
		if (!datas) return "";
		var currentSeparator = undefined === separator ? "," : separator;
		let id = propId ? propId : 'id';
		let name = propName ? propName : 'name';
		if (!value)
			return "";
		let array = [];
		if (typeof value === 'string') {
			let temp = value.split(currentSeparator);
			array = datas.filter(x => temp.includes(x[id].toString()));
		} else {
			array = datas.filter(x => x[id].toString() === value.toString());
		}
		if (array) {
			let rarray = []
			array.forEach(x => {
				rarray.push(x[name]);
			});
			return rarray.join(';')
		}
	},

	splitParamsFormat: function (val, list) {
		if (val || val === 0) {

			var arry = val.split(",");
			var strArr = [];
			for (let j = 0; j < arry.length; j++) {
				if (list != undefined && list.length > 0) {
					for (let i = 0; i < list.length; i++) {
						if (arry[j] == list[i].id) {
							strArr.push(list[i].name);
						}
					}
				}
			}
			return strArr.join(",");
		}
		return "";
	},
	getCondtions: function (vals) {
		let conditions = [];
		for (let key in vals) {
			let val = vals[key]["value"]
			let operate = vals[key]["operate"]
			if (val) {
				conditions.push({
					name: key,
					operate: !operate ? "like" : operate,
					value: val,
				});
			}
		}
		return conditions;
	},


	dateFormat: function (val) {
		// if (val) {
		// 	let date = $timeFormat(val, "yyyy-mm-dd")
		// 	return date;
		// }
		// return "无";

		if (val) {
			try {
				if (val.length == 10)
					return val
				let date = $timeFormat(val.replace(/-/g, "/"), "yyyy-mm-dd")
				return date;
			} catch (error) {
				return val
			}
		}
		return "无";

	},


	dateFormatStr: function (val) {
		if (val) {
			let date = $timeFormat(val, "yyyy-mm-dd").replace(/-/g, "")
			return date;
		}
		return "无";
	},

	dateTimeFormat: function (val) {
		// if (val) {
		// 	let date = $timeFormat(val, "yyyy-mm-dd hh:MM")
		// 	return date;
		// }
		// return "";

		if (val) {
			try {
				let date = $timeFormat(val.replace(/-/g, "/"), "yyyy-mm-dd hh:MM")
				return date;
			} catch (error) {
				return val
			}
		}
		return "";
	},




	/**
	* 传入对象返回url参数
	* @param {Object} data {a:1}
	* @returns {string}
	*/
	getLinkParam: function (data) {
		let url = '';
		for (var k in data) {
			let value = data[k] !== undefined ? data[k] : '';
			url += `&${k}=${encodeURIComponent(value)}`
		}
		return url ? url.substring(1) : ''
	},

	/**
	 * 将url和参数拼接成完整地址
	 * @param {string} url url地址
	 * @param {Json} data json对象
	 * @returns {string}
	 */
	getLinkUrl: function (url, data) {
		//看原始url地址中开头是否带?，然后拼接处理好的参数
		return url += (url.indexOf('?') < 0 ? '?' : '&') + this.getLinkParam(data)
	},

	sixDigitString(name) {
		if (name) {
			if (name.length <= 6) {
				return name;
			} else {
				name = name.slice(0, 6);//截取第二个到第四个之间的字符 cd
				name = name + "..."
				return name;
			}
		} else {
			return "";
		}
	},
	// getCurrentUser()
	// {
	//   let user=	uni.getStorageSync('userInfo');

	// }
	bindTag(val, params, types) {
		let type = "primary";
		if (types && types.length > 0) {
			let typeObject = types.find(x => x.id == val);
			if (typeObject) {
				type = typeObject.type;
			}
		}
		let obj = params.find(x => x.id == val);
		if (obj)
			return `<span class='${type}'>${obj.name} </span>`
		else
			return "--"
	},


}
export default common
