import request from "@/common/request.js";
/*获取附件列表*/
export function getPageData(params) {
	return request({
		url: '/CommonAttach/GetPageData',
		method: 'get',
		params
	})
}

/*编辑附件名称*/
export function editName(data) {
	return request({
		url: '/CommonAttach/EditName',
		method: 'post',
		data
	})
}

/*删除附件*/
export function deleteAttach(id) {
	return request({
		url: '/CommonAttach/Delete/' + id,
		method: 'get'
	})
}
