import request from "@/common/request.js";
import store from '@/store';
// import Cookies from 'js-cookie'

// const CookieKey = '.AspNetCore.Session'

/*获取token*/
export function getLogin(data) {
	return request({
		url: '/auth/loginSafety',
		method: 'post',
		data
	})
}

// export function setCookie(data) {
// 	return Cookies.set(CookieKey, data.cookie)
// }

/*获取token*/
export function getToken(params) {
	return request({
		url: '/auth/guanGuanLogin',
		method: 'get',
		params
	})
}

export function getAQXToken(params) {
	return request({
		url: '/auth/tokenLogin',
		method: 'get',
		params
	})
}


export function authToken(token, companyId, callBack) {
	var data = {
		token: token,
		companyId: companyId
	};

	getToken(data).then((res) => {
		if (res.success && res.data && res.data.userName) {
			let headToken = res.data.companyCode + ":" + res.data.token;
			uni.setStorageSync("token", headToken);
			uni.setStorageSync("userInfo", res.data);
			store.commit('login', res.data);
			if (typeof callBack == 'function') {
				callBack(res)
			}
		} else {
			uni.showToast({
				title: res.errorText
			})
			uni.navigateTo({
				url: "/pages/login/login"
			})
		}
	})
}

export function authAQxToken(token, callBack) {
	var data = {
		token: token
	};

	getAQXToken(data).then((res) => {
		if (res.success && res.data && res.data.userName) {
			let headToken = res.data.companyCode + ":" + res.data.token;
			uni.setStorageSync("token", headToken);
			uni.setStorageSync("userInfo", res.data);
			store.commit('login', res.data);
			if (typeof callBack == 'function') {
				callBack(res)
			}
		} else {
			uni.showToast({
				title: res.errorText
			})
			uni.navigateTo({
				url: "/pages/login/login"
			})
		}
	})
}

export function handleLogin(data, callBack) {
	getLogin(data).then((res) => {
		if (res.success && res.data && res.data.userName) {
			let headToken = res.data.companyCode + ":" + res.data.token;
			uni.setStorageSync("token", headToken);
			uni.setStorageSync("userInfo", res.data);
			store.commit('login', res.data);
			if (typeof callBack == 'function') {
				callBack(res)
			}
		} else {
			uni.showToast({
				title: res.errorText
			})
			uni.navigateTo({
				url: "/pages/login/login"
			})
		}
	})
}


export function getCurrentUser() {
	let userInfo = uni.getStorageSync("userInfo");
	if (typeof userInfo === "string") {
		userInfo = JSON.parse(userInfo);
	}
	return userInfo;
}

//公司管理员
export function isCompanyManager() {
	let userInfo = getCurrentUser();
	let userKind = userInfo ? userInfo.userKind : 0;
	return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 32768) > 0
}
//销售负责人
export function isSaleManager() {
	let userInfo = getCurrentUser();
	let userKind = userInfo ? userInfo.userKind : 0;
	return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 2048) > 0
}
//财务负责人
export function isFinanceManager() {
	let userInfo = getCurrentUser();
	let userKind = userInfo ? userInfo.userKind : 0;
	return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 16384) > 0
}
//咨询项目负责人
export function isConsultManager() {
	let userInfo = getCurrentUser();
	console.log(userInfo);
	let userKind = userInfo ? userInfo.userKind : 0;
	return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 8192) > 0
}

//是否机构版
export function isJGB() {
	let userInfo = getCurrentUser();
	console.log(userInfo);
	let companySysType = userInfo ? userInfo.companySysType : "";
	return (companySysType == "JGB" || companySysType == "JGBNEW");
}

//是否企业
export function isQY() {
	let userInfo = getCurrentUser();
	let companySysType = userInfo ? userInfo.companySysType : "";
	return !(companySysType == "JGB" || companySysType == "JGBNEW");
}

















