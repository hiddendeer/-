import request from '@/common/request.js'

export function getClassifyList(params={}) {
	return request({
		url: '/support/dangerlgclassify/getClassifyList',
		method: 'get',
		params
	})
}

export function getPageData(query = {}) {
  return request({
    url: '/support/dangerlg/getPageData',
    method: 'get',
    params: query
  })
}
