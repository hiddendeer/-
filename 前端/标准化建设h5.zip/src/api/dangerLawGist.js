import request from "@/common/request.js";
/*获取检查依据*/
export function getClassifys(params) {
	return request({
		url: '/DangerLawGist/GetClassifys',
		method: 'get',
		params
	})
}

/*获取检查依据页面数据*/
export function getPageData(params) {
	return request({
		url: '/DangerLawGist/GetPageData',
		method: 'get',
		params
	})
}