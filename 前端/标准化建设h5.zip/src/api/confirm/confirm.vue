<template>
	<view>
		组织架构
	</view>
</template>

<script>
	export default {
		name:"confirm",
		data() {
			return {
				
			};
		},
		methods:{
			
		}
	}
</script>

<style lang="scss">

</style>
