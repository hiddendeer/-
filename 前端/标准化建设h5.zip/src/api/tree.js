import request from "@/common/request.js";
/*获取附件列表*/
export function getList(params) {
	return request({
		url: '/CommonAttach/GetPageData',
		method: 'get',
		params
	})
}