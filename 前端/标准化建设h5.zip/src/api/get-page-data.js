import request from "@/common/request.js";
export function getPageData(params,url) 
{
	return request({
		url: url,
		method: 'get',
		params
	})
}


//'/CommonAttach/GetPageData'