# -*- coding: utf-8 -*-

"""
@author: 猿小天
@contact: QQ:1638245306
@Created on: 2021/6/3 003 0:30
@Remark: 角色管理
"""
import os

import upyun

import requests
import json

from rest_framework.views import APIView

from application import settings
from django.forms import model_to_dict
from rest_framework import serializers
from django.core.serializers import serialize
import requests, json
from django.http import JsonResponse
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated

from dvadmin.system.models import Role, Menu, MenuButton, Dept, OrderInfo, Users, UserDetail, OrderInfoDetail
from dvadmin.system.views.dept import DeptSerializer
from dvadmin.system.views.menu import MenuSerializer
from dvadmin.system.views.menu_button import MenuButtonSerializer
from dvadmin.system.views.role import RoleSerializer
from dvadmin.utils.crud_mixin import FastCrudMixin
from dvadmin.utils.json_response import SuccessResponse, DetailResponse, ErrorResponse
from dvadmin.utils.serializers import CustomModelSerializer
from dvadmin.utils.validator import CustomUniqueValidator
from dvadmin.utils.viewset import CustomModelViewSet
from django.db.models import OuterRef, Subquery
from django.db.models import F


class DeptSerializer(serializers.ModelSerializer):
    name1 = serializers.SerializerMethodField()

    def get_name1(self, instance):
        return '来来来来'

    class Meta:
        model = Dept
        fields = ['name', 'name1']


class UserDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserDetail
        fields = ['name']


class UsersSerializer(serializers.ModelSerializer):
    dept = DeptSerializer(read_only=True)

    user_detail = serializers.SerializerMethodField()

    def get_user_detail(self, instance):
        queryset = UserDetail.objects.filter(user_id=instance.id).first()
        serializer = UserDetailSerializer(queryset)
        return serializer.data

    class Meta:
        model = Users
        fields = "__all__"


class OrderInfoDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderInfoDetail
        fields = "__all__"
        read_only_fields = ["id"]


class OrderInfoSerializer(CustomModelSerializer):
    """
    订单-序列化器
    """
    user = UsersSerializer(read_only=True)
    status_name = serializers.SerializerMethodField()

    # detail_info = serializers.SerializerMethodField()
    # user_info = serializers.SerializerMethodField()

    def get_status_name(self, instance):
        return instance.get_status_display()

    # def get_user_info(self, instance):
    #     user_info = Users.objects.filter(id=instance.user_id).values('name', 'username', 'email', 'user_detail_id').first()
    #     user_detail = UserDetail.objects.filter(id=user_info['user_detail_id']).first()
    #     user_detail_dict = model_to_dict(user_detail)
    #     user_info['user_detail'] = user_detail_dict
    #     return user_info

    # def get_detail_info(self, instance):
    #     detail_info = OrderInfoDetail.objects.filter(id=instance.user_detail_id).values('name', 'code', 'u_id',
    #                                                                                'user_id').first()
    #     return detail_info

    # username = serializers.CharField(source='user.username', read_only=True)

    # third_info = serializers.SerializerMethodField(read_only=True)
    #
    # def get_third_info(self, instance):
    #     response = requests.get('http://localhost:2802/tvrjet-edz-supervision-app/dict/page/',
    #                             params={"dictTypeCode": "checkNum"})
    #
    #     return json.loads(response.text)

    class Meta:
        model = OrderInfo
        fields = "__all__"
        read_only_fields = ["id"]


# class RoleCreateUpdateSerializer(CustomModelSerializer):
#     """
#     角色管理 创建/更新时的列化器
#     """
#     menu = MenuSerializer(many=True, read_only=True)
#     dept = DeptSerializer(many=True, read_only=True)
#     permission = MenuButtonSerializer(many=True, read_only=True)
#     key = serializers.CharField(max_length=50,
#                                 validators=[
#                                     CustomUniqueValidator(queryset=Role.objects.all(), message="权限字符必须唯一")])
#     name = serializers.CharField(max_length=50, validators=[CustomUniqueValidator(queryset=Role.objects.all())])
#
#     def validate(self, attrs: dict):
#         return super().validate(attrs)
#
#     def save(self, **kwargs):
#         is_superuser = self.request.user.is_superuser
#         if not is_superuser:
#             self.validated_data.pop('admin')
#         data = super().save(**kwargs)
#         return data
#
#     class Meta:
#         model = Role
#         fields = '__all__'
#
#
# class MenuPermissonSerializer(CustomModelSerializer):
#     """
#     菜单的按钮权限
#     """
#     menuPermission = serializers.SerializerMethodField()
#
#     def get_menuPermission(self, instance):
#         is_superuser = self.request.user.is_superuser
#         if is_superuser:
#             queryset = MenuButton.objects.filter(menu__id=instance.id)
#         else:
#             menu_permission_id_list = self.request.user.role.values_list('permission', flat=True)
#             queryset = MenuButton.objects.filter(id__in=menu_permission_id_list, menu__id=instance.id)
#         serializer = MenuButtonSerializer(queryset, many=True, read_only=True)
#         return serializer.data
#
#     class Meta:
#         model = Menu
#         fields = ['id', 'parent', 'name', 'menuPermission']

class OrderInfoViewSet(CustomModelViewSet, FastCrudMixin, APIView):
    """
    角色管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = OrderInfo.objects.all()
    # create_serializer_class = OrderInfoCreateSerializer
    serializer_class = OrderInfoSerializer
    # update_serializer_class = RoleCreateUpdateSerializer
    search_fields = ['name']

    @action(methods=['GET'], detail=False)
    def get_view_detail(self, request):
        queryset = OrderInfoDetail.objects.all()
        page = self.paginate_queryset(queryset)
        serializer = OrderInfoDetailSerializer(page, many=True, read_only=True)
        return self.get_paginated_response(serializer.data)

    def get_queryset(self):
        queryset = OrderInfo.objects.all()
        has_sort = self.request.query_params.get("sort")
        name = self.request.query_params.get("name")
        if has_sort:
            queryset.filter(sort=has_sort)
        if name:
            queryset.filter(name=name)

        return queryset

    # 爬取接口数据
    @action(methods=['GET'], detail=False)
    def get_info(self, request):
        # 通过浏览器找到接口：
        url = 'http://127.0.0.1/afx-api/site/dangerCheckTask/getPageData?dataType=list&year=2023&enterpriseCode=&pageNum=1&pageSize=20'
        # hds = {
        #     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36'}
        hds = {'Authorization': "Bearer 4679579387b33df58e1ed42daeb2ad2f:ZmZhZDNlMDktYzU0Yy1mMjQ1LTJmYjEtZmVkMDk2OTkyYjQ4"}
        # resp = requests.get(url, headers=hds)
        # ct = resp.content.decode('utf-8')
        # ct = json.loads(ct)  # 转为json格式，ct是字典形式
        # print(ct)
        for item in range(1000):
            resp = requests.get(url, headers=hds)
            ct = resp.content.decode('utf-8')
            ct = json.loads(ct)  # 转为json格式，ct是字典形式
            data = ct['data']
            print(item)

        return SuccessResponse(data={}, msg='', status=200)

    @action(methods=['GET'], detail=False)
    def get_recent_info(self, request):
        hasName = request.query_params.get('name')
        queryset = OrderInfo.objects.all().order_by("-create_datetime")
        queryset_dict = [model_to_dict(instance) for instance in queryset]
        # data_range_list = list(set(queryset))
        # for item in data_range_list:
        #     print(item.name)
        if hasName is not None:
            queryset = queryset.filter(name=hasName)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True, request=request)
            return self.get_paginated_response(serializer.data)
        return SuccessResponse(data=page, msg='', status=200)

    @action(methods=['GET'], detail=False)
    def get_detail_info(self, request):
        orderId = request.query_params.get('id')
        queryset = OrderInfo.objects.filter(id=orderId).first()
        serializer = OrderInfoSerializer(queryset)
        return SuccessResponse(data=serializer.data, msg='成功')

    @action(methods=['POST'], detail=False)
    def add_order(self, request):
        name = request.data.get('name')
        code = request.data.get('code')
        user_id = request.data.get('user')
        status = request.data.get('status')
        queryset = OrderInfo.objects.create(name=name, code=code, user_id=user_id, status=status)
        serializer = OrderInfoSerializer(queryset)
        # orderId = request.query_params.get('id')
        # queryset = OrderInfo.objects.filter(id=orderId).first()
        # serializer = OrderInfoSerializer(queryset)
        return SuccessResponse(data=serializer.data, msg='成功')

    @action(methods=['POST'], detail=False)
    def file_order(self, request):
        validated_data = {}
        file = request.data.get('file')

        if file is None:
            return ErrorResponse(msg="没有传file", code=4000)
        file_size = file.size
        validated_data['name'] = str(file)
        validated_data['size'] = file_size
        validated_data['url'] = file
        fileName = os.path.join(settings.MEDIA_ROOT + '/files', file.name)
        with open(fileName, 'wb') as f:
            data = file.file.read()
            f.write(data)

        # 上传又拍云对象存储
        up = upyun.UpYun("shuaimao-youpaiyun", "csy", "3dr077ZYMGiEP8adGOPl51csnOU673C2")

        with open(fileName, 'rb') as f:
            res = up.put(settings.MEDIA_ROOT + '/files/' + file.name, f)
            print("tag" in res)
            if res and "tag" in res:
                print(res)


        # print(up.getlist())
        # list1 = []
        # for i in range(100):
        #     student = OrderInfo(name='你好', code='code10', user_id='1', status=0)
        #     list1.append(student)
        #
        # OrderInfo.objects.bulk_create(list1)
        return DetailResponse(data={'a': 1}, msg='成功')
