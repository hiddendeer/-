<template>
    <div id="app">
        <router-view />
    </div>
</template>

<script>
export default {
    name: "App",
    mounted() {
        window.addEventListener(
            "hashchange",
            () => {
                const currPath = window.location.hash.slice(1);
                if (this.$route.path !== currPath) {
                    // 不一致就跳转url的路由
                    this.$router.push(currPath);
                    window.history.go(-1);
                }
            },
            false
        );
    },
    metaInfo() {
        let modulesId = this.$route.meta.modulesId;
        console.log("metaInfo");
        console.log(modulesId);
        return {
            title:
                this.$store.state.settings.dynamicTitle &&
                this.$store.state.settings.title,
            titleTemplate: (title) => {
                if (!title) {
                    title = process.env.VUE_APP_TITLE;
                }
                switch (modulesId) {
                    case "system":
                        title = "系统管理";
                        break;
                    case "host":
                        title = "管家服务";
                        break;
                    case "dangerJg":
                        title = "隐患排查服务";
                        break;
                    case "site": //site是企业   其他的是机构
                        title = "应急管理";
                        break;
                    case "project":
                        title = "运营管理";
                        break;
                    default:
                        break;
                }
                return title;
            },
        };
    },
};
</script>

<style>
/* .el-scrollbar__wrap {
  overflow-x: hidden !important;
} */
/* .el-scrollbar__thumb {
  background-color: #1890ff;
} */

.os-scrollbar-handle {
    background: #1890ff !important;
    /* width: 20% !important; */
}
#app {
    background: #f0f0f0;
    overflow: auto;
}
</style>
