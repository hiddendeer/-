(function() { //监听子组件传递的数据
    window.addEventListener("message", function(event) {
        // console.log("来自parent data:" + JSON.stringify(event.data))
        if (event.data.type) {
            sendMessage(event.data)
        }
    })
    sendMessage({
        type: "initComplete",
        data: {}
    })

    // 发送数据
    function sendMessage(data) {
        let responseData = {}
        switch (data.type) {
            case "getSvgString": //获取svgString
                responseData.svgString = svgCanvas.getSvgString()
                break;
            case "setSvgString": //设置svgString
                svgCanvas.setSvgString(data.data.svgString)
                break;
            case 'clearSvgString': // clear svgString
                clear()
                break
            case 'initComplete': // clear svgString
                clear()
                break
            default:
                break;
        }
        //发送数据
        window.parent.postMessage({
                type: data.type,
                data: responseData
            }, '*') //* 代表不限制域,第一参数是传递的数据
    }
    /**
     * 新建画布
     */
    function clear() {
        let dims = state.get("canvasSize");
        state.set("canvasMode", "select")
        svgCanvas.clear();
        svgCanvas.setResolution(dims[0], dims[1]);
        editor.canvas.update(true);
        editor.zoom.reset();
        editor.panel.updateContextPanel();
        editor.paintBox.fill.prep();
        editor.paintBox.stroke.prep();
        svgCanvas.runExtensions('onNewDocument');
    }

    /**
   {
    type:"",//getSvgString,setSvgString,clearSvgString等等自定义
    data:"",自定义携带数据
}
   */

})();