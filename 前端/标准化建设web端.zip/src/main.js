import Vue from "vue"
import Element from "element-ui"
import App from "./App"
import store from "./store"
import router from "./router"
import Router from "vue-router"
import Cookies from "js-cookie"
import directive from "./directive"
import EcharStyle from '@/assets/js/echarts-case.js'



// 组件
import { registerGlobComp } from "@/components/Eagle"; // 益戈公共组件
import Pagination from "@/components/Pagination";
import RightToolbar from "@/components/RightToolbar"// 自定义表格工具组件

// 样式
import "./assets/icons" // icon
import "element-ui/lib/theme-chalk/icon.css"
import "./assets/styles/element-variables.scss"
import "@/assets/styles/index.scss" // global css
import "@/assets/styles/EageleRMC.scss" // EageleRMC css


// 接口方法
import http from "@/api/http.js";// 全局通用方法
import { getDicts } from "@/api/system/dict/data";
import common from "@/api/common.js";
import constParams from "@/api/constParams.js";

// 公共方法
import "@/utils/message"
import { parseTime, formateDict, formatDate, formateStatus } from "@/utils/EageleRMC";
import { inputFiltration1, inputFiltration2 } from "@/utils/inputReplace";
import { getToken } from "@/utils/auth"
import * as filters from "@/utils/format.js" // 全局过滤
import deepClone from "@/utils/deepClone.js";
import deepMerge from "@/utils/deepMerge.js";

// 插件
// 插件-图标  css
import fontawesome from "@fortawesome/fontawesome"
import FontAwesomeIcon from "@fortawesome/vue-fontawesome"
import solid from "@fortawesome/fontawesome-free-solid"
import regular from "@fortawesome/fontawesome-free-regular"
import brands from "@fortawesome/fontawesome-free-brands"

// 插件-滚动条  css
import "overlayscrollbars/css/OverlayScrollbars.css";
import OverlayScrollbars from "overlayscrollbars";
import { OverlayScrollbarsPlugin } from "overlayscrollbars-vue";

// 全局组件挂载
Vue.component("Pagination", Pagination)
Vue.component("RightToolbar", RightToolbar)
Vue.component("font-awesome-icon", FontAwesomeIcon)
registerGlobComp(Vue);


const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key]) //插入过滤器名和对应方法
})

fontawesome.library.add(solid)
fontawesome.library.add(regular)
fontawesome.library.add(brands)

window.getMyToken = getToken
Vue.prototype.http = http;
Vue.prototype.common = common;
Vue.prototype.constParams = constParams;
Vue.prototype.deepClone = deepClone;
Vue.prototype.deepMerge = deepMerge;
Vue.prototype.EventTrain = new Vue()
Vue.prototype.getDicts = getDicts
Vue.prototype.parseTime = parseTime
Vue.prototype.formateDict = formateDict
Vue.prototype.formateStatus = formateStatus
Vue.prototype.formatDate = formatDate
Vue.config.productionTip = false
Vue.prototype.inputFiltration1 = inputFiltration1
Vue.prototype.inputFiltration2 = inputFiltration2
Vue.prototype.$echartsCase = EcharStyle;


Vue.use(Element, { size: Cookies.get("size") || "medium" })
Vue.use(directive)
// 滚动条
Vue.use(OverlayScrollbarsPlugin);
Vue.use(OverlayScrollbars);
Vue.directive("fo", {
  inserted(el) {
    if (["INPUT", "TEXTAREA"].indexOf(el.tagName) !== -1) {
      el.focus()
    } else {
      let node = el.querySelector("input")
      if (node) {
        node.focus()
        return
      }
      node = el.querySelector("textarea")
      if (node) {
        node.focus()
        return
      }
      throw new Error("请把v-fo指令用到input或textarea上")
    }
  }
})

new Vue({
  el: "#app",
  router,
  store,
  watch: {
    // $route(to, from) {
    //   console.log(to.path, 11111);
    // }
  },
  render: h => h(App)
})


