export const scoreArray = [
	{
		score: "0-599分",
		scoreColor: getColor(590),
	},
	{
		score: "600-749分",
		scoreColor: getColor(600),
	},
	{
		score: "750-899分",
		scoreColor: getColor(750),
	},
	{
		score: "900-1000分",
		scoreColor: getColor(900),
	},
];
export function getColor(score) {
	if (score >= 900) {
		return "#0CAD7B";
	} else if (score >= 750 && score < 900) {
		return "#3980E6";
	} else if (score >= 600 && score < 750) {
		return "#FFAB00";
	} else {
		return "#E64040";
	}
}

// 绩效评价分数
export function getPaColor(score) {
	if (score >= 100) {
		return "#0CAD7B";
	} else if (score >= 80 && score < 100) {
		return "#3980E6";
	} else if (score >= 60 && score < 80) {
		return "#FFAB00";
	} else {
		return "#E64040";
	}
}
