import * as echarts from "echarts";
const echarStyle6 = (id, data, label, bgcolor) => {
	let sum = data.reduce((sum, item) => {
		return (sum += item);
	}, 0);
	let nowClientWidth = document.documentElement.clientWidth;
	let nowSize = function (val, initWidth = 1920) {
		return val * (nowClientWidth / initWidth);
	};
	document.getElementById(id).removeAttribute("_echarts_instance_");
	let myChart = echarts.init(document.getElementById(id));

	let option = {
		grid: {
			left: 140,
			right: 70,
			top: 10,
			bottom: 0,
		},
		tooltip: {
			trigger: "axis",

			textStyle: {
				color: "#111D4E",
				fontSize: 14,
			},
			formatter: function (params) {
				let res = `<div style="font-weight: 700;">${params[0].name}</div>
							<div>得分： <span style="color: #0052C7">${params[0].data}分</span></div>
						  `;
				return res;
			},
		},
		xAxis: {
			type: "value",
			show: true,
			splitLine: {
				show: false,
			},
		},
		yAxis: [
			{
				type: "category",
				axisTick: { show: false },
				offset: 0,
				axisLabel: {
					interval: 0,
					color: "#666",
					fontSize: nowSize(13),
					align: "left",
					margin:120,
					// formatter: function (value) {
					// 	let ret = ""; //拼接加\n返回的类目项
					// 	let maxLength = 20; //每项显示文字个数
					// 	let valLength = value.length; //X轴类目项的文字个数
					// 	let rowN = Math.ceil(valLength / maxLength); //类目项需要换行的行数
					// 	if (rowN > 1) {
					// 		//如果类目项的文字大于5,
					// 		for (let i = 0; i < rowN; i++) {
					// 			let temp = ""; //每次截取的字符串
					// 			let start = i * maxLength; //开始截取的位置
					// 			let end = start + maxLength; //结束截取的位置
					// 			//这里也可以加一个是否是最后一行的判断，但是不加也没有影响，那就不加吧
					// 			temp = value.substring(start, end) + "\n";
					// 			ret += temp; //凭借最终的字符串
					// 		}
					// 		return "\n" + "\n" + ret;
					// 	} else {
					// 		return value;
					// 	}
					// },
				},
				axisLine: {
					show: false,
				},
				inverse: true,
				data: label,
			},
			{
				type: "category",
				axisTick: { show: false },
				axisLine: {
					show: false,
				},
				axisLabel: {
					color: "#666",
					fontSize: nowSize(20),
				},
				inverse: true,
				// data: proportion.map((item) => item + "%"),
			},
		],
		series: [
			{
				data,
				type: "bar",
				barWidth: 20,
				label: {
					show: true,
					color: "#000",
					position: "right",
					textBorderColor: "#fff", // 描边颜色
					textShadowColor: "#fff",
					fontSize: 14,
					textBorderWidth: 2, // 描边宽度
					formatter: function (params) {
						return params.value ? params.value + "分" : "";
					},
				},
				itemStyle: {
					color: bgcolor,
				},
			},
			// {
			// 	data,
			// 	type: "bar",
			// 	label: {
			// 		show: true,
			// 		color: "#000",
			// 		position: "right",
			// 		formatter: function (params) {
			// 			let percent =
			// 				Number((params.value / sum) * 100).toFixed(2) + "%";
			// 			// if (params.value < 30) {
			// 			// 	return params.value + "件 " + percent;
			// 			// } else {
			// 			// 	return percent;
			// 			// }
			// 			return percent;
			// 		},
			// 	},
			// 	itemStyle: {
			// 		color: bgcolor,
			// 	},
			// },
		],
	};
	myChart.setOption(option);
	window.addEventListener("resize", () => {
		myChart.resize();
	});
};

export default echarStyle6;
