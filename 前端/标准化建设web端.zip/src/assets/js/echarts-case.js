import echarStyle4 from "./echarStyleJs/echarStyle4";
import echarStyle6 from "./echarStyleJs/echarStyle6";
export default {
	echarStyle4,
	echarStyle6,
};
