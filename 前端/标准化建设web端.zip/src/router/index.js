import Vue from "vue"
import Router from "vue-router"
import Cookies from "js-cookie"
import store from "../store"
import request from "@/utils/request"

/* Layout */
import Layout from "@/layout"
import NoMenu from "@/nomenu"
import "nprogress/nprogress.css"
import NProgress from "nprogress"

Vue.use(Router)
let site = process.env.VUE_APP_BASE_Site;

const whiteList = ['/login', '/auth-redirect', '/bind', '/register']

// 公共路由
export const constantRoutes = [
  {
    path: "/redirect",
    component: Layout,
    hidden: true,
    children: [{
      path: "/redirect/:path(.*)",
      component: (resolve) => require(["@/views/redirect"], resolve)
    }]
  },
  {
    path: "/login",
    component: (resolve) => require(["@/views/login"], resolve),
    hidden: true
  },
  {
    path: "/loginEagle",
    component: (resolve) => require(["@/views/loginEagle"], resolve),
    hidden: true
  },
  {
    path: "/404",
    component: (resolve) => require(["@/views/error/404"], resolve),
    hidden: true
  },
  {
    path: "/401",
    component: (resolve) => require(["@/views/error/401"], resolve),
    hidden: true
  },

  {
    path: "",
    component: NoMenu,
    redirect: "index",
    children: [{
      path: "index",
      component: (resolve) => require(["@/views/index1"], resolve),
      name: "首页",
    }]
  },
  {
    path: "/system/dict-data",
    component: Layout,
    hidden: true,
    children: [{
      path: "index/:dictId(\\d+)",
      component: (resolve) => require(["@/views/system/dict/data"], resolve),
      name: "Data",
      meta: {
        title: "字典数据",
        activeMenu: "/system/dict"
      }
    }]
  },

  {
    path: "/onlineEditBlock",
    component: Layout,
    children: [{
      path: "",
      component: (resolve) => require(["@/views/common/editBlock"], resolve),
      meta: {
        title: "在线编辑",
        icon: "dashboard",
        noCache: true,
        affix: true
      },
      hidden: true
    }]
  },
  // {
  //   path: '/companyTempEdit',
  //   component: Layout,
  //   children: [{
  //     path: '',
  //     component: (resolve) => require(['@/views/system/company/index'], resolve),
  //     meta: {
  //       title: '在线编辑',
  //       icon: 'dashboard',
  //       noCache: true,
  //       affix: true
  //     },
  //     hidden: true
  //   }]
  // },
  {
    path: "/onlineEditTempFile",
    component: Layout,
    children: [{
      path: "",
      component: (resolve) => require(["@/views/common/editTempFile"], resolve),
      meta: {
        title: "在线编辑",
        icon: "dashboard",
        noCache: true,
        affix: true
      },
      hidden: true
    }]
  },
]


let router = new Router({
  mode: "hash", // 去掉url中的#
  scrollBehavior: () => ({
    y: 0
  }),
  routes: constantRoutes,
  base: site,
})

router.$safeAddRoutes = (params) => {
  //router.matcher = new Router({ mode: 'history', routes: constantRoutes } ).matcher;
  router.addRoutes(params)
}

router.$GenerateRoutes = (to, next) => {
  let modulesId = to.meta.modulesId;
  if (!modulesId && to.path) {
    let path1 = to.path.substring(1, to.path.length - 1);
    path1 = path1.substring(0, path1.indexOf("/"));
    modulesId = path1;
  }
  store.dispatch("GenerateRoutes", modulesId).then(accessRoutes => {
    // console.log("accessRoutes", JSON.stringify(accessRoutes))
    router.$safeAddRoutes(accessRoutes)
    // router.push({
    //   path: to.path,
    //   query: to.query
    // })
    if (typeof next === "function") {
      next({ ...to, replace: true })
      //next();
    }
    // next({ ...to, replace: true }) // hack方法 确保addRoutes已完成
  }).catch(err => {
    store.dispatch("LogOut").then(() => {
      Message.error(err)
      next({
        path: "/"
      })
    })
  })
}
router.$setTitle = (to) => {
  let modulesId = to.meta.modulesId
  let title = "";
  switch (modulesId) {
    case "system":
      title = "系统管理";
      break;
    case "host":
      title = "管家服务";
      break;
    case "dangerJg":
      title = "隐患排查服务";
      break;
    case "site":
      title = "应急管理";
      break;
    case "project":
      title = "运营管理";
      break;
    case "ecologyEnvironment":
      title = "综合执法";
      break;
  }
  document.title = title;
}

router.$liginGuanGuan = (to) => {
  var url = "www.baidu.com";
  window.localtion.href = url;
}


router.beforeEach((to, from, next) => {
  NProgress.configure({ showSpinner: false })
  NProgress.start()

  store.dispatch("app/killSideBar", ["/train/certdef", "/pages/fireCheck/siteFirecheck", "/support/commonCase"].includes(to.path) ? true : false);

  let token = Cookies.get("Admin-Token")
//   let {userName} = JSON.parse( decodeURIComponent(window.atob(to.query.data)))||{}
//   console.log(to.query.companyId);
//  let {chnName,companyCode} =sessionStorage.getItem("user")? JSON.parse(sessionStorage.getItem("user")):{}
//   if(to.query.companyId !== companyCode && userName !==chnName){
//     console.log(1111);
//     localStorage.clear()
//     sessionStorage.clear()
//     removeToken();
//   }
  if (hasToken(to)) {
    if (to.matched.length > 0) {
      router.$setTitle(to);
      next()
    } else {
      if (to.query && to.query.companyId && to.query.token){
        request({
                url: "/auth/guanGuanLogin",
                method: "get",
                params: {
                  companyId: to.query.companyId,
                  token: to.query.token
                }
              }).then(function (res) {
                let token = res.data.companyCode + ":" + res.data.token;
                Cookies.set("Admin-Token", token);
                store.dispatch("SetLoginData", res.data);
                router.$GenerateRoutes(to, next);
              })
      }else{
        router.$GenerateRoutes(to, next)
      }
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      next()
    } else if (to.query && to.query.companyId && to.query.token) {
      request({
        url: "/auth/guanGuanLogin",
        method: "get",
        params: {
          companyId: to.query.companyId,
          token: to.query.token
        }
      }).then(function (res) {
        let token = res.data.companyCode + ":" + res.data.token;
        Cookies.set("Admin-Token", token);
        store.dispatch("SetLoginData", res.data);
        router.$GenerateRoutes(to, next);
      })
    } else if (to.query && to.query.token) {
      let token = to.query.token;
      request({
        url: "/auth/tokenLogin",
        method: "get",
        params: {
          token: to.query.token
        }
      }).then(function (res) {
        Cookies.set("Admin-Token", token);
        store.dispatch("SetLoginData", res.data);
        router.$GenerateRoutes(to, next)
      })
    }
    else {
      next(`/login?redirect=${to.fullPath}`) // 否则全部重定向到登录页
      NProgress.done()
    }
  }

})

// 全局路由后置守卫
router.afterEach((to, from) => {
  NProgress.done()
})

const hasToken = (to) => {
  return Cookies.get("Admin-Token")
}
export default router













