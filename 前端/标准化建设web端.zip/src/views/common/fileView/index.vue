<template>
    <div class="div-fileView-container app-container1">
        <div class="layer1">
      
            <div class="div-dialog-title">
                <div class="div_title">{{ fileName||title}}</div>
                <div style="margin-right:20px">
                    <!-- <a :href="sourceUrl" :download="fileName" target="_blank"> <i class="el-icon-download"></i> </a> -->
                    <el-button size="mini" type="primary" @click="downLoad('.docx')">导出Word报告</el-button>
                    <el-button size="mini" type="danger" @click="downLoad('.pdf')">导出Pdf报告</el-button>
                    <el-button size="mini" @click="backList()">{{buttonText}}</el-button>
                </div>
            </div>
            <div>
                <div :style="{'height':height+'px'}" class="div-pdf-conatiner" v-if="!isImage">
                    <eagle-pdf-view class="pdf-view" style="height:100%" v-if="url" :url="url" ref="eaglePdfView"></eagle-pdf-view>
                </div>
                <div style="min-height:490px;background:rgba(0, 0, 0, 0.7);" v-if="isImage">
                    <img v-if="url" :src="url" class="imageClass">
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import eagleImage from "./../../../components/Eagle/eagle-image.vue";
export default {
    components: { eagleImage },
    name: "eagle-file",
    props: {
        code: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            url: "",
            sourceUrl: "",
            fileName: "",
            open: false,
            width: "1000px",
            title: "文件浏览",
            attExt: "",
            isImage: false,
            fit: "contain",
            fileName: "",
            fileInfo: {},
            height: 0,
            modulesCode: "",
            buttonText: "",
        };
    },
    filters: {
        getBtnClass(isImage) {
            if (isImage) {
                return "btnMargin dialog-btn";
            } else {
                return "btnMargin dialog-btn";
            }
        },
    },
    created() {
        var page = this.$route.query.page;
        if (page && page == "HostResponse") {
            this.buttonText = "返回目标职责";
        } else if (page && page == "ProjectJgReportList") {
            this.buttonText = "返回项目总结";
        } else {
            this.buttonText = "返回报告列表";
        }
        this.modulesCode = this.$route.query.modulesCode;
        this.search();

        this.getDivHeight();
        window.addEventListener("resize", this.getDivHeight);
    },
    methods: {
        search() {
            this.url = "";
            this.sourceUrl = "";
            this.fileName = "";
            var _this = this;
            let attCode = this.$route.query.attcode;
            this.fileName = this.$route.query.attName;

            this.http.get("/file/getDataByAttCode/" + attCode).then((res) => {
                if (res.code == 200) {
                    var data = res.data;
                    _this.sourceUrl = data.attFilePath;
                    _this.fileName = data.attName + "." + data.attExt;

                    var isImageExt = _this.checkIsImage(data.attExt);
                    if (!isImageExt) {
                        if (data.status == 1) {
                            _this.$alert(`文件在转换中,请稍后再试!`);
                        } else if (data.status == 10) {
                            if (_this.checkIsVideo(data.attExt)) {
                                _this.url = data.attFilePath;
                            } else {
                                _this.url = data.attMiddlePath;
                            }
                            _this.attExt = data.attExt;
                            _this.open = true;
                            _this.fileInfo = res.data;
                        } else if (data.status == -1) {
                            this.$confirm(
                                "文件无法预览,是否下载后查看?",
                                "提醒",
                                {
                                    confirmButtonText: "确定",
                                    cancelButtonText: "取消",
                                    type: "warning",
                                }
                            )
                                .then(function () {
                                    _this.down();
                                })
                                .then((res) => {})
                                .catch(() => {});
                        }
                        if (data.attName != null && data.attName != "") {
                            _this.title = data.attName;
                        }

                        _this.isImage = false;
                    } else {
                        _this.open = true;
                        _this.title = data.attName;
                        _this.attExt = data.attExt;
                        _this.url = data.attFilePath;
                        _this.isImage = isImageExt;
                    }
                } else {
                    _this.$alert(`文件无法查到,请联系管理员处理!`);
                }
            });
        },
        down() {
            var _this = this;
            const a = document.createElement("a");
            fetch(_this.sourceUrl)
                .then((res) => res.blob())
                .then((blob) => {
                    a.href = URL.createObjectURL(blob);
                    a.download = _this.fileName; // 下载文件的名字
                    document.body.appendChild(a);
                    a.click();
                });
        },
        downLoad(type) {
            var _this = this;
            const a = document.createElement("a");
            var url =
                type == ".pdf"
                    ? _this.fileInfo.attMiddlePath
                    : _this.fileInfo.attFilePath;
            fetch(url)
                .then((res) => res.blob())
                .then((blob) => {
                    a.href = URL.createObjectURL(blob);
                    a.download = _this.fileInfo.attName + type; // 下载文件的名字
                    document.body.appendChild(a);
                    a.click();
                });
        },
        backList() {
            var _this = this;
            let name = "";
            var queryParams = {};
            //  {
            //         projectId: _this.$route.query.projectId,
            //         enterpriseCode: _this.$route.query.enterpriseCode
            //     }
            //  debugger;
            let page = _this.$route.query.page;
            switch (this.modulesCode) {
                case "rent":
                    name = "FactoryInPlantDangerReportList";
                    break;
                case "site":
                    name = "Site_DangerReportList";
                    if (page && page == "HostResponse") {
                        name = "SiteResponse";
                    }
                    break;
                case "host":
                    name = "SiteDangerReportList";
                    if (page && page == "HostResponse") {
                        name = "HostResponse";
                    }
                    queryParams.projectId = _this.$route.query.projectId;
                    queryParams.enterpriseCode =
                        _this.$route.query.enterpriseCode;
                    break;
                case "dangerJg":
                    name = "DangerJgReportListUs";
                    break;
                case "dangerJg_child":
                    name = "ProjectJgReportList";
                    if (page && page == "ProjectJgReportList") {
                        name = "ProjectJgReportList";
                    }
                    queryParams.projectId = _this.$route.query.projectId;
                    queryParams.enterpriseCode =
                        _this.$route.query.enterpriseCode;
                    break;
            }
            _this.$router.push({
                name: name,
                query: queryParams,
            });
        },
        checkIsVideo(attExt) {
            if (attExt) {
                if (attExt.indexOf("avi") > -1 || attExt.indexOf("mp4") > -1) {
                    return true;
                }
            }
            return false;
        },
        checkIsImage(attExt) {
            if (attExt) {
                if (
                    attExt.indexOf("png") > -1 ||
                    attExt.indexOf("jpg") > -1 ||
                    attExt.indexOf("jpeg") > -1 ||
                    attExt.indexOf("jpg") > -1 ||
                    attExt.indexOf("gif") > -1 ||
                    attExt.indexOf("bmp") > -1
                ) {
                    return true;
                } else {
                    return false;
                }
            }
        },
        handleClose(done) {
            if (!this.isImage && this.attExt.indexOf("mp4") > -1) {
                this.$refs.eaglePdfView.handleClose();
            }
            done();
        },
        getDivHeight() {
            switch (this.modulesCode) {
                case "host":
                case "dangerJg_child":
                    this.height = document.documentElement.clientHeight - 220;
                    break;
                default:
                    this.height = document.documentElement.clientHeight - 70;
                    break;
            }
        },
    },
};
</script>

<style lang="scss" scoped>
.div-fileView-container {
    .layer1 {
        width: 100%;
        position: relative;
    }
    .div-fileView-container {
        .layer {
            padding: 0px 0px -1px 0px;
        }
        .div-pdf-conatiner {
            height: 600px;
        }
        .btnMargin {
            margin-top: -15px;
        }
        .div-dialog-title {
            background: #f6f6f6;
            line-height: 40px;
            border-bottom: 1px solid #bbbbbb;

            .div_title {
                font-size: 16px;
                font-weight: 700;
                color: #3c4043;
                padding-left: 10px;
            }
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            position: absolute;
            z-index: 9999;
            width: 100%;
            right: 0px;
            top: 0px;
        }
        .pdf-dialog .el-dialog__header {
            background: #000;
            color: #fff;
            height: 48px;
            overflow: hidden;
        }
        .pdf-dialog .el-dialog__body {
            padding: 0px;
        }

        .dialog-btn {
            float: right;
            margin-right: 30px;
        }
        .div-pdf-conatiner {
            background-color: #dddddd;
            padding-top: 45px;
            min-height: 400px;
        }
        .pdf-view {
            // overflow: auto;
            // max-width: 795px;
            margin: 0px auto;
            height: 600px;
        }

        .avatar {
            margin: 0 auto;
            display: inherit;
            max-height: 600px;
        }
        .imageClass {
            max-width: 100%;
            max-height: 490px;
            position: absolute;
            top: 50px;
            right: 0;
            bottom: 0;
            left: 0;
            margin: auto;
            display: block;
        }
    }
}
</style>