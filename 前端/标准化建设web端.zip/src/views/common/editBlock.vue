<template>
    <div class="app-container editBlock">
        <el-form class="clearfix" :model="blockForm" ref="form">
            <el-scrollbar class="card1" v-if="blockForm.blockData.length > 0">
                <div v-for="(tempForm, index) in blockForm.blockData" :key="index" :id="tempForm.mainCode + '' + tempForm.templateCode">
                    <el-card class="mainFile" shadow="never">
                        <el-form-item label="">
                            <el-input class="title" v-model="tempForm.templateName" placeholder="请输入标题" prop="name">
                            </el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-col :span="18" style="border: 1px solid transparent">
                            </el-col>
                            <el-col :span="2">
                                <span>编制时间</span>
                            </el-col>
                            <el-col :span="4">
                                <el-date-picker type="date" placeholder="选择日期" v-model="tempForm.editFileDate">
                                </el-date-picker>
                            </el-col>
                        </el-form-item>
                        <el-form-item class="detail" v-for="(detail, subIndex) in tempForm.details" :key="subIndex">
                            <el-col v-if="parseInt(detail.leve) > 1" :span="0.5" :class="'el-col-blank_' + detail.leve">
                            </el-col>
                            <el-col :span="0.5">
                                <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="click">
                                    <div class="avatar-wrapper">
                                        <i class="el-icon-caret-bottom" />
                                    </div>
                                    <el-dropdown-menu slot="dropdown">
                                        <el-dropdown-item @click.native="dealLine('addTitle', index, subIndex)">
                                            <span>添加同级标题</span>
                                        </el-dropdown-item>
                                        <el-dropdown-item v-show="parseInt(detail.leve) < 4" @click.native="dealLine('addChildTitle', index, subIndex)">
                                            <span>添加下级标题</span>
                                        </el-dropdown-item>
                                        <el-dropdown-item @click.native="dealLine('addText', index, subIndex)">
                                            <span>添加文本</span>
                                        </el-dropdown-item>
                                        <el-dropdown-item @click.native="dealLine('addTable', index, subIndex)">
                                            <span>添加表格</span>
                                        </el-dropdown-item>
                                        <el-dropdown-item>
                                            <eagle-image-hidden :index="index" :subIndex="subIndex" v-bind:imgData="imgData" v-on:imgChanged="dealImg($event)">
                                            </eagle-image-hidden>
                                        </el-dropdown-item>
                                        <el-dropdown-item @click.native="dealLine('remove', index, subIndex)">
                                            <span>移除</span>
                                        </el-dropdown-item>
                                    </el-dropdown-menu>
                                </el-dropdown>
                            </el-col>
                            <el-col :span="0.5" style="
                  text-align: left;
                  padding-left: 10px;
                  padding-right: 10px;
                ">
                                <span style="font-weight: bolder">{{ detail.showNo }}</span>
                            </el-col>
                            <el-col :span="21" v-if="'Title' === detail.type">
                                <!--                                <el-input v-if="tempForm.currentOrder===detail.orderNo" v-fo class="borderNone" v-model="detail.text" @keyup.enter.native="dealLine('addTitle', index, subIndex)"></el-input>-->
                                <!--                                <el-input v-else class="borderNone" v-model="detail.text" @keyup.enter.native="dealLine('addTitle', index, subIndex)"></el-input>-->
                                <el-input type="textarea" autosize v-if="tempForm.currentOrder === detail.orderNo" v-fo class="borderNone" v-model="detail.text" @keyup.enter.native="
                                      textareaKeyup($event, 'addTitle', index, subIndex)
                                    "></el-input>
                                <el-input type="textarea" autosize v-else class="borderNone" v-model="detail.text" @keyup.enter.native="
                                      textareaKeyup($event, 'addTitle', index, subIndex)
                                    "></el-input>
                            </el-col>
                            <el-col :span="21" v-if="'Text' === detail.type">
                                <el-input type="textarea" autosize v-if="tempForm.currentOrder === detail.orderNo" v-fo class="borderNone" v-model="detail.text" @keyup.enter.native="
                                      textareaKeyup($event, 'addText', index, subIndex)
                                    "></el-input>
                                <el-input type="textarea" autosize v-else class="borderNone" v-model="detail.text" @keyup.enter.native="
                                      textareaKeyup($event, 'addText', index, subIndex)
                                    "></el-input>
                            </el-col>
                            <el-col :span="22" v-if="'Table' === detail.type">
                                <table class="editBlockTable">
                                    <thead>
                                        <tr>
                                            <th v-for="(item, index) in detail.value.columns" style="min-width: 5px" :style="{
                                                  width:
                                                    (item.Type == 'edit' ? '20' : item.Width) + '%',
                                                }" v-bind:colspan="
                          item.Colspan && item.Colspan > 0 ? item.Colspan : ''
                        " v-show="
                          !item.Colspan || item.Colspan > 0 || item.Colspan == 0
                        ">
                                                <div class="colum-btn">
                                                    <el-dropdown class="avatar-container right-menu-item" v-if="item.Type != 'edit'" trigger="click">
                                                        <div title="修改项" class="avatar-wrapper">
                                                            <i class="el-icon-edit-outline" />
                                                        </div>
                                                        <el-dropdown-menu slot="dropdown">
                                                            <div style="padding: 5px">
                                                                <div style="display: flex; padding: 5px">
                                                                    <div>
                                                                        <span style="line-height: 36px">标题:</span>
                                                                    </div>
                                                                    <a style="line-height: 36px" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'align-left'
                                                                      )
                                                                    "><i class="el-icon-s-fold"></i></a>
                                                                    <a style="line-height: 36px" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'align-center'
                                                                      )
                                                                    "><i class="el-icon-s-order"></i></a>
                                                                    <a style="line-height: 36px" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'align-right'
                                                                      )
                                                                    "><i class="el-icon-s-unfold"></i></a>
                                                                </div>
                                                                <div style="display: flex; padding: 5px">
                                                                    <div>
                                                                        <span style="line-height: 36px">内容:</span>
                                                                    </div>
                                                                    <a style="line-height: 36px" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'talign-left'
                                                                      )
                                                                    "><i class="el-icon-s-fold"></i></a>
                                                                    <a style="line-height: 36px" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'talign-center'
                                                                      )
                                                                    "><i class="el-icon-s-order"></i></a>
                                                                    <a style="line-height: 36px" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'talign-right'
                                                                      )
                                                                    "><i class="el-icon-s-unfold"></i></a>
                                                                </div>
                                                                <div style="display: flex; padding: 5px">
                                                                    <div>
                                                                        <span style="line-height: 36px">宽度:</span>
                                                                    </div>
                                                                    <el-input type="number" class="operateInput" v-model="item.Width"></el-input>
                                                                </div>
                                                                <div style="display: flex; padding: 5px">
                                                                    <div>
                                                                        <span style="line-height: 36px">跨列:</span>
                                                                    </div>
                                                                    <el-input type="number" class="operateInput" v-model="colspan"></el-input>
                                                                    <el-button type="primary" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'sure'
                                                                      )
                                                                    "><span>确定</span></el-button>
                                                                </div>
                                                                <div style="display: flex; padding: 5px">
                                                                    <div title="删除列" style="cursor: pointer" @click="
                                                                      columnClick(
                                                                        item,
                                                                        index,
                                                                        detail.value,
                                                                        'delete'
                                                                      )
                                                                    ">
                                                                        <i class="el-icon-delete" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </el-dropdown-menu>
                                                    </el-dropdown>
                                                    <div title="添加项" @click="
                                                      columnClick(item, index, detail.value, 'add')
                                                    ">
                                                        <i class="el-icon-circle-plus-outline" />
                                                    </div>
                                                    <div title="添加行" v-if="item.Type == 'edit'" @click="
                                                      columnClick(item, index, detail.value, 'addRow')
                                                    ">
                                                        <i class="el-icon-circle-plus" />
                                                    </div>
                                                </div>
                                                <div style="margin-top: 20px">
                                                    <span v-if="item.Type == 'edit'" style="font-weight: bolder">{{
                                                    item.Name }}</span>
                                                    <el-input v-else :class="'tableColumnInput_' + item.Align" v-model="item.Name"></el-input>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(dataItem, dataIndex) in detail.value.data">
                                            <td v-for="(item, index) in detail.value.columns">
                                                <div v-if="item.Type != 'edit'">
                                                    <el-input type="textarea" autosize :class="'tableDataInput_' + item.TAlign" v-model="dataItem[item.No]"></el-input>
                                                </div>
                                                <div v-else class="tableData-btn">
                                                    <div title="添加项" @click="
                                                      rowClick(dataItem, dataIndex, detail.value, 'add')
                                                    ">
                                                        <i class="el-icon-plus" />
                                                    </div>
                                                    <div title="删除项" @click="
                                                      rowClick(
                                                        dataItem,
                                                        dataIndex,
                                                        detail.value,
                                                        'delete'
                                                      )
                                                    ">
                                                        <i class="el-icon-delete" />
                                                    </div>
                                                    <div title="上移" @click="
                                                      rowClick(dataItem, dataIndex, detail.value, 'up')
                                                    ">
                                                        <i class="el-icon-top" />
                                                    </div>
                                                    <div title="下移" @click="
                                                      rowClick(
                                                        dataItem,
                                                        dataIndex,
                                                        detail.value,
                                                        'down'
                                                      )
                                                    ">
                                                        <i class="el-icon-bottom" />
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </el-col>
                            <el-col :span="22" v-if="'Image' === detail.type">
                                <div style="text-align: center; margin-top: 5px">
                                    <div>
                                        <el-image :style="{ width: detail.img.Width + 'px' }" :src="detail.img.Url">
                                        </el-image>
                                        <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="click">
                                            <div class="avatar-wrapper">
                                                <i class="el-icon-edit-outline" style="cursor: pointer" />
                                            </div>
                                            <el-dropdown-menu slot="dropdown">
                                                <div style="padding: 5px">
                                                    <div style="display: flex">
                                                        <div>
                                                            <span style="line-height: 36px">宽度:</span>
                                                        </div>
                                                        <el-input style="width: 100px" type="number" v-model="detail.img.Width"></el-input>
                                                    </div>
                                                </div>
                                            </el-dropdown-menu>
                                        </el-dropdown>
                                    </div>
                                    <el-input class="img-block" type="textarea" autosize v-if="tempForm.currentOrder === detail.orderNo" v-fo v-model="detail.img.Name">
                                    </el-input>
                                    <el-input class="img-block" type="textarea" autosize v-else v-model="detail.img.Name"></el-input>
                                </div>
                            </el-col>
                        </el-form-item>
                    </el-card>
                    <eagle-attach label="相关附件" v-model="tempForm.attachs"></eagle-attach>
                </div>
            </el-scrollbar>
            <el-scrollbar class="card2" v-if="blockForm.blockData.length > 0">
                <div class="tempSearch" style="text-align: right">
                    <el-button type="primary" @click="submitForm()">保 存</el-button>
                </div>
                <div class="tempSearch" v-for="(tempForm, index) in blockForm.blockData" :key="index">
                    <div class="clearfix" style="padding-bottom: 10px">
                        <div title="删除调研内容" style="cursor: pointer" @click="delTemplate(index)">
                            <i class="el-icon-delete" />
                        </div>
                        <span class="tempSearchTitle" @click="jump(tempForm)">
                            <span>{{ tempForm.templateName }}</span>
                        </span>
                        <el-button class="tempSearchButton" type="primary" v-show="
                          tempForm.searchList.length && tempForm.searchList.length > 0
                        " @click="clearSearch(index)"><span>重新调研</span></el-button>
                    </div>
                    <div style="padding-bottom: 10px">
                        <el-table v-if="
                          tempForm.searchList.length && tempForm.searchList.length > 0
                        " :data="tempForm.searchList">
                            <el-table-column prop="surveyContent" label="调研内容" width="250" align="left">
                            </el-table-column>
                            <el-table-column prop="value" label="调研结果" align="left">
                                <template slot-scope="scope">
                                    <el-form-item class="valueInput" :prop="
                                      'blockData.' +
                                      index +
                                      '.searchList.' +
                                      scope.$index +
                                      '.value'
                                    " :rules="fromaDataRules.value" label-width="100px">
                                        <el-input v-model="scope.row.value"></el-input>
                                    </el-form-item>
                                </template>
                            </el-table-column>
                        </el-table>
                        <span style="font-size: 14px" v-else>无调研内容</span>
                    </div>
                </div>
            </el-scrollbar>
            <el-scrollbar class="card0" v-if="imgShow">
              
                <el-empty :image-size="200" description="暂无数据"></el-empty>
            </el-scrollbar>
        </el-form>
    </div>
</template>

<script>
import http from "@/api/http";
import EagleNodata from "../../components/Eagle/eagle-nodata.vue";
export default {
    components: { EagleNodata },
    data() {
        return {
            imgShow: false,
            codes: "",
            mainCode: "",
            menuSysType: "",
            imgData: "",
            colspan: "",
            blockForm: {
                blockData: [],
            },
            // 表单参数
            fromaDataRules: {
                value: [
                    {
                        required: true,
                        message: "调研内容不能为空",
                        trigger: "blur",
                    },
                ],
            },
        };
    },
    created() {
        const menuSysType = this.$route.query && this.$route.query.menuSysType;
        const codes = this.$route.query && this.$route.query.codes;
        const mainCode = this.$route.query && this.$route.query.mainCode;
        // const codes = "00001";
        // const menuSysType = "SiteGuideline";
        // const mainCode = "510df63eac93495890bab4b190cb6392";
        this.loading = this.$loading({
            lock: true,
            text: "加载中",
            background: "rgba(0, 0, 0, 0.7)",
        });

        if (mainCode) {
            this.getData(mainCode, menuSysType);
        } else {
            this.getTemplate(codes, menuSysType);
        }
    },
    mounted() {},
    methods: {
        jump(tempForm) {
            document
                .getElementById(tempForm.mainCode + "" + tempForm.templateCode)
                .scrollIntoView({ behavior: "smooth" });
        },
        /** 获取模板 */
        getTemplate(codes, menuSysType) {
            this.codes = codes;
            this.menuSysType = menuSysType;
            //模板数据获取
            http.get(
                "/support/onlineTemp/getOnlineTemp?codes=" +
                    this.codes +
                    "&menuSysType=" +
                    this.menuSysType
            )
                .then((res) => {
                    let resultData = res.data;
                    this.imgShow = true;
                    if (resultData && resultData.length > 0) {
                        for (let i = 0; i < resultData.length; i++) {
                            let item = resultData[i];
                            item.currentOrder = null;
                            item.bisCode = item.mainCode;
                            item.mainCode = "";
                            if (item.details && item.details.length > 0) {
                                for (let j = 0; j < item.details.length; j++) {
                                    let itemDetail = item.details[j];
                                    itemDetail.orderNo = itemDetail.order;
                                    itemDetail.value = {};
                                    if (itemDetail.type === "Table") {
                                        itemDetail.value = JSON.parse(
                                            itemDetail.text
                                        );
                                        itemDetail.text = "";
                                    }
                                    if (itemDetail.type === "Image") {
                                        itemDetail.img = JSON.parse(
                                            itemDetail.text
                                        );
                                        itemDetail.text = "";
                                    }
                                }
                            }
                            if (item.searchList && item.searchList.length > 0) {
                                for (
                                    let k = 0;
                                    k < item.searchList.length;
                                    k++
                                ) {
                                    let search = item.searchList[k];
                                    search.value = search.defaultValue;
                                }
                            }
                        }
                        this.blockForm.blockData = resultData;
                        this.imgShow = false;
                    }
                    this.loading.close();
                })
                .catch(() => {
                    this.loading.close();
                });
        },
        getData(mainCode, menuSysType) {
            this.mainCode = mainCode;
            this.menuSysType = menuSysType;
            //模板数据获取
            http.get("/support/doc/onlineDocs/" + this.mainCode)
                .then((res) => {
                    let resultData = res.data;
                    this.imgShow = true;
                    if (resultData && resultData.length > 0) {
                        for (let i = 0; i < resultData.length; i++) {
                            let item = resultData[i];
                            this.menuSysType = item.menuSysType;
                            item.templateCode = item.tempCode;
                            item.templateName = item.name;
                            item.mainCode = this.mainCode;
                            item.currentOrder = null;
                            if (item.details && item.details.length > 0) {
                                for (let j = 0; j < item.details.length; j++) {
                                    let itemDetail = item.details[j];
                                    itemDetail.value = {};
                                    if (itemDetail.type === "Table") {
                                        itemDetail.value = JSON.parse(
                                            itemDetail.text
                                        );
                                        itemDetail.text = "";
                                    }
                                    if (itemDetail.type === "Image") {
                                        itemDetail.img = JSON.parse(
                                            itemDetail.text
                                        );
                                        itemDetail.text = "";
                                    }
                                }
                            }
                        }
                        this.blockForm.blockData = resultData;
                        this.imgShow = false;
                    }
                    this.loading.close();
                })
                .catch(() => {
                    this.loading.close();
                });
        },
        clearSearch(index) {
            for (
                let i = 0;
                i < this.blockForm.blockData[index].searchList.length;
                i++
            ) {
                let item = this.blockForm.blockData[index].searchList[i];
                item.value = "";
            }
        },
        dealImg(data) {
            let currentRow =
                this.blockForm.blockData[data.index].details[data.subIndex];
            let order = currentRow.orderNo;
            let obj = {};
            obj = {
                id: 0,
                type: "Image",
                leve: currentRow.leve,
                orderNo: order + 1,
                img: JSON.parse(data.data),
                text: "",
                showNo: "",
            };
            this.blockForm.blockData[data.index].details.splice(order, 0, obj);
            this.blockForm.blockData[data.index].currentOrder = obj.orderNo;
        },
        textareaKeyup(event, type, index, subIndex) {
            if (event.ctrlKey && event.key == "Enter") {
                this.dealLine(type, index, subIndex);
            }
        },
        /** 操作行数据 */
        dealLine(type, index, subIndex) {
            let currentRow = this.blockForm.blockData[index].details[subIndex];
            let order = currentRow.orderNo;
            let obj = {};
            switch (type) {
                case "addTitle":
                    order = this.getNextTitleOrder(
                        index,
                        order,
                        currentRow.leve
                    );
                    obj = {
                        id: 0,
                        type: "Title",
                        leve: currentRow.leve,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    this.blockForm.blockData[index].currentOrder = obj.orderNo;
                    break;
                case "addChildTitle":
                    order = this.getNextTitleOrder(
                        index,
                        currentRow.orderNo,
                        parseInt(currentRow.leve) + 1
                    );
                    obj = {
                        id: 0,
                        type: "Title",
                        leve: parseInt(currentRow.leve) + 1,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    this.blockForm.blockData[index].currentOrder = obj.orderNo;
                    break;
                case "addText":
                    obj = {
                        id: 0,
                        type: "Text",
                        leve: currentRow.leve,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    this.blockForm.blockData[index].currentOrder = obj.orderNo;
                    break;
                case "addTable":
                    obj = {
                        id: 0,
                        type: "Table",
                        leve: currentRow.leve,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                        value: {
                            columns: [this.getEditColumn()],
                            data: [],
                        },
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    break;
                case "addImg":
                    break;
                case "remove":
                    this.blockForm.blockData[index].details.splice(
                        order - 1,
                        1
                    );
                    break;
                default:
                    break;
            }

            if (type !== "addImg") {
                this.calculateShowNo(index);
            }
        },
        //得到插入标题的位置
        getNextTitleOrder: function (index, order, level) {
            for (
                let i = order;
                i < this.blockForm.blockData[index].details.length;
                i++
            ) {
                let item = this.blockForm.blockData[index].details[i];
                if (item.type !== "Title" || item.leve > level) {
                    order = item.orderNo;
                } else {
                    break;
                }
            }
            return order;
        },
        calculateShowNo: function (index) {
            let list = this.blockForm.blockData[index].details;
            let leve1No = 0;
            let leve2No = 0;
            let leve3No = 0;
            let leve4No = 0;
            let currentLeve = 1;

            for (let i = 0; i < list.length; i++) {
                let item = list[i];
                item.orderNo = i + 1;
                if (item.type === "Title") {
                    if (item.leve < currentLeve) {
                        if (item.leve == 3) {
                            leve4No = 0;
                        } else if (item.leve == 2) {
                            leve4No = 0;
                            leve3No = 0;
                        } else if (item.leve == 1) {
                            leve4No = 0;
                            leve3No = 0;
                            leve2No = 0;
                        }
                    } else {
                        currentLeve = item.leve;
                    }
                    if (item.leve == 1) {
                        leve1No = leve1No + 1;
                        item.showNo = leve1No;
                    }
                    if (item.leve == 2) {
                        leve2No = leve2No + 1;
                        item.showNo = leve1No + "." + leve2No;
                    }
                    if (item.leve == 3) {
                        leve3No = leve3No + 1;
                        item.showNo = leve1No + "." + leve2No + "." + leve3No;
                    }
                    if (item.leve == 4) {
                        leve4No = leve4No + 1;
                        item.showNo =
                            leve1No +
                            "." +
                            leve2No +
                            "." +
                            leve3No +
                            "." +
                            leve4No;
                    }
                } else {
                    item.showNo = "";
                }
            }
            this.blockForm.blockData[index].details = [];
            this.blockForm.blockData[index].details = list;
        },
        getEditColumn: function () {
            return {
                Name: "操作",
                No: "A",
                Width: 20,
                BWidth: "20px",
                Align: "center",
                TAlign: "center",
                Type: "edit",
            };
        },
        columnClick: function (item, index, value, type) {
            switch (type) {
                case "delete":
                    value.columns.splice(index, 1);
                    break;
                case "add":
                    let newcolum = {};
                    newcolum.Name = "新增";
                    newcolum.Width = 40;
                    newcolum.BWidth = newcolum.Width + "px";
                    newcolum.Align = "center";
                    newcolum.TAlign = "center";
                    newcolum.No = this.getColumnNo(value.columns);
                    value.columns.splice(index, 0, newcolum);
                    break;
                case "addRow":
                    value.data.splice(value.data.length, 0, { A: "edit" });
                    break;
                case "align-left":
                case "align-center":
                case "align-right":
                    value.columns[index].Align = type.replace("align-", "");
                    break;
                case "talign-left":
                case "talign-center":
                case "talign-right":
                    value.columns[index].TAlign = type.replace("talign-", "");
                    break;
                case "sure":
                    let hiddenCount = 0;
                    item.Colspan = this.colspan;
                    if (item.Colspan && item.Colspan > 1) {
                        hiddenCount = Number(item.Colspan) - 1;
                    }
                    for (let i = index + 1; i < value.columns.length; i++) {
                        let nextColum = value.columns[i];
                        if (hiddenCount > 0) {
                            nextColum.Colspan = -1;
                        } else if (nextColum.Colspan) {
                            if (nextColum.Colspan < 0) {
                                nextColum.Colspan = 0;
                            } else if (nextColum.Colspan > 0) {
                                hiddenCount = nextColum.Colspan;
                            }
                        }
                        hiddenCount--;
                    }
                    value.columns[index].Colspan = item.Colspan;
                    value.columns[index].Width = item.Width;
                    value.columns[index].BWidth = item.Width + "px";

                    this.colspan = "";
                    break;
            }
        },
        rowClick: function (item, index, value, type) {
            switch (type) {
                case "add":
                    value.data.splice(index + 1, 0, { A: "edit" });
                    break;
                case "delete":
                    value.data.splice(index, 1);
                    break;
                case "up":
                    if (index == 0) {
                        this.msgError("已经是最上层了");
                        return;
                    }
                    let pItem = value.data[index - 1];
                    let cItem = value.data[index];
                    value.data.splice(index - 1, 1, cItem);
                    value.data.splice(index, 1, pItem);
                    break;
                case "down":
                    if (index == value.data.length - 1) {
                        this.msgError("已经是最下层了");
                        return;
                    }
                    let nItem = value.data[index + 1];
                    let ccItem = value.data[index];
                    value.data.splice(index + 1, 1, ccItem);
                    value.data.splice(index, 1, nItem);
                    break;
                default:
                    break;
            }
        },
        getColumnNo: function (columns) {
            let maxCode = 65;
            for (let i = 0; i < columns.length; i++) {
                let item = columns[i];
                let code = item.No.charCodeAt();
                if (code > maxCode) {
                    maxCode = code;
                }
            }
            return String.fromCharCode(maxCode + 1);
        },
        delTemplate: function (index) {
            let mainLength = this.blockForm.blockData.length;
            if (mainLength == 1) {
                this.msgError("最后一个调研不能删除");
                return;
            }

            this.$confirm("确定删除吗？", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "info",
            })
                .then(() => {
                    this.blockForm.blockData.splice(index, 1);
                })
                .catch(() => {});
        },
        /** 提交按钮 */
        submitForm: function () {
            this.$refs["form"].validate((valid) => {
                if (valid) {
                    for (let i = 0; i < this.blockForm.blockData.length; i++) {
                        let item = this.blockForm.blockData[i];
                        if (item.details && item.details.length > 0) {
                            for (let j = 0; j < item.details.length; j++) {
                                let itemDetail = item.details[j];
                                if (itemDetail.type === "Table") {
                                    itemDetail.text = JSON.stringify(
                                        itemDetail.value
                                    );
                                }
                                if (itemDetail.type === "Image") {
                                    itemDetail.text = JSON.stringify(
                                        itemDetail.img
                                    );
                                }
                            }
                        }
                    }

                    this.loading = this.$loading({
                        lock: true,
                        text: "保存中",
                        background: "rgba(0, 0, 0, 0.7)",
                    });

                    http.post(
                        "/support/onlineTemp/saveOnlineTemp",
                        this.blockForm.blockData
                    )
                        .then((res) => {
                            this.msgSuccess("保存成功");
                            this.loading.close();

                            switch (this.menuSysType) {
                                case "SiteDuty":
                                    this.$router
                                        .push({ name: "SiteDutyFile" })
                                        .catch((err) => {
                                            console.log(err);
                                        });
                                    break;
                                case "SiteGuideline":
                                    this.$router
                                        .push({ name: "SiteGuidelineFile" })
                                        .catch((err) => {
                                            console.log(err);
                                        });
                                    break;
                                default:
                                    this.$router.push({ path: "/" });
                                    break;
                            }
                        })
                        .catch(() => {
                            this.loading.close();
                        });
                }
            });
        },
    },
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.mainFile {
    min-height: 600px;
}

.editMain .el-form-item {
    margin-bottom: 0px;
}

.operateInput {
    width: 60px;
    margin-right: 5px;
}

.operateInput input.el-input__inner {
    padding: 0 0;
}

.editBlock {
    .el-scrollbar__wrap {
        overflow-x: hidden;
    }

    .clearfix {
        display: flex;
        justify-content: space-between;
    }

    .card0 {
        width: 100%;
        height: calc(100vh - 104px);
        text-align: center;
    }

    .card1 {
        width: 70%;
        height: calc(100vh - 104px);

        .title {
            font-size: 26px;
        }

        .title input.el-input__inner {
            text-align: center;
            border: 2px white solid;
            font-weight: bolder;
        }

        // Margin
        .el-col-blank_2 {
            border: 5px solid transparent;
        }

        .el-col-blank_3 {
            border: 10px solid transparent;
        }

        .el-col-blank_4 {
            border: 15px solid transparent;
        }

        // Title/Text Input
        .borderNone input.el-input__inner {
            border: 2px white solid;
            padding: 0 0;
        }

        .borderNone input.el-input__inner:focus {
            border: 2px black solid;
        }

        .borderNone textarea.el-textarea__inner {
            font-family: Arial;
            border: 2px white solid;
            padding: 0 0 0 0;
            resize: none;
            line-height: 36px;
        }

        .borderNone textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        // Image Name Input
        .img-block {
            padding: 10px 10px;
        }

        .img-block textarea.el-textarea__inner {
            font-family: Arial;
            text-align: center;
            border: 2px white solid;
            resize: none;
        }

        .img-block textarea.el-textarea__inner:focus {
            text-align: center;
            border: 2px black solid;
        }

        .colum-btn {
            display: flex;
            float: right;
            line-height: 1px;
            margin-right: 3px;
        }

        .colum-btn i {
            cursor: pointer;
            width: 150%;
        }

        .tableData-btn {
            display: block;
            text-align: center;
        }

        .tableData-btn div {
            display: inline;
        }

        .tableData-btn i {
            cursor: pointer;
        }

        .tableColumnInput_center input.el-input__inner {
            text-align: center;
            border: 2px white solid;
            font-weight: bolder;
            color: #303133;
        }

        .tableColumnInput_center input.el-input__inner:focus {
            border: 2px black solid;
        }

        .tableColumnInput_left input.el-input__inner {
            text-align: left;
            border: 2px white solid;
            font-weight: bolder;
            color: #303133;
        }

        .tableColumnInput_left input.el-input__inner:focus {
            border: 2px black solid;
        }

        .tableColumnInput_right input.el-input__inner {
            text-align: right;
            border: 2px white solid;
            font-weight: bolder;
            color: #303133;
        }

        .tableColumnInput_right input.el-input__inner:focus {
            border: 2px black solid;
        }

        .tableDataInput_center textarea.el-textarea__inner {
            text-align: center;
            font-family: Arial;
            border: 2px white solid;
            resize: none;
        }

        .tableDataInput_center textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        .tableDataInput_left textarea.el-textarea__inner {
            text-align: left;
            font-family: Arial;
            border: 2px white solid;
            resize: none;
        }

        .tableDataInput_left textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        .tableDataInput_right textarea.el-textarea__inner {
            text-align: right;
            font-family: Arial;
            border: 2px white solid;
            resize: none;
        }

        .tableDataInput_right textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        .editBlockTable {
            width: 100%;
            border-spacing: 0px;
            border: 1px solid #cccccc;
        }

        .editBlockTable th {
            border: 1px solid #cccccc;
        }

        .editBlockTable td {
            border: 1px solid #cccccc;
        }

        .el-col-blank_2 {
            border: 5px solid transparent;
        }

        .el-col-blank_3 {
            border: 10px solid transparent;
        }

        .el-col-blank_4 {
            border: 15px solid transparent;
        }
    }

    .card2 {
        width: 30%;
        height: calc(100vh - 104px);

        .tempSearch {
            padding: 10px 30px;
        }

        .tempSearchTitle {
            width: 80%;
            cursor: pointer;
            border-bottom: 1px solid lightgray;
        }

        .tempSearchTitle span {
            font-size: 14px;
            font-weight: bolder;
        }

        .thisTempSearchButton {
            padding: 0 10px !important;
            height: 30px;
            padding: 0;
        }

        .thisTempSearchButton span {
            line-height: 30px;
        }
    }
}

.detail {
    margin-bottom: 0px;
}
</style>
