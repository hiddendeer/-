<template>
    <div class="app-container">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <el-col>
                <eagle-radio @change="search()" label-width="120px" label="隐患性质" prop="hiddenDangerTypeCode"
                    v-model="conditions.hiddenDangerTypeCode.value" :dataSource="params.dangerTypeConditions"
                    size="small" />
            </el-col>
            <el-col>
                <eagle-date @change="search()" :clearable="false" label-width="120px" label="年度" type="year"
                    format="yyyy" v-model="queryParams.year"></eagle-date>
            </el-col>
            <el-col>
                <eagle-radio @change="search()" label-width="120px" label="月份" prop="month" v-model="queryParams.month"
                    :data-source="params.month" size="small">
                </eagle-radio>
            </el-col>
            <eagle-input label-width="120px" @changeEnter="search()" label="其他筛选" prop="title"
                v-model="conditions.hiddenDangerDesc.value" placeholder="请输入隐患描述模糊查询" clearable size="small" />
        </eagle-condition>
        <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams">
            <template slot="slot-table">
                <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" />
                <el-table-column label="隐患图片" align="left" prop="attachs" width="300">
                    <template slot-scope="scope">
                        <eagle-row-image v-model="scope.row.attachs" />
                    </template>
                </el-table-column>
                <el-table-column v-if="setModel.correctiveArea==='true'" label="隐患区域" prop="correctiveArea" />

                <el-table-column label="隐患来源" align="left" width="120">
                    <template slot-scope="scope">
                        <span>{{formateDict( params.checkSource,scope.row.originType) }}</span>
                    </template>
                </el-table-column>
                <el-table-column v-if="setModel.hiddenDangerTypeCode==='true'" label="隐患性质" align="left" width="100">
                    <template slot-scope="scope">
                        <span>{{formateDict( params.dangerType,scope.row.hiddenDangerTypeCode) }}</span>
                    </template>
                </el-table-column>
                <el-table-column v-if="setModel.correctiveMeasure==='true'" label="整改措施" prop="correctiveMeasure" />

                <el-table-column label="检查时间" align="left" prop="createDate" width="140">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d} {h}:{i}") }}</span>
                    </template>
                </el-table-column>

                <el-table-column v-if="setModel.correctiveDeadline==='true'" label="整改期限" align="left"
                    prop="correctiveDeadline" width="100">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.correctiveDeadline , "{y}-{m}-{d}") ||"--"}}</span>
                    </template>
                </el-table-column>
                <el-table-column v-if="setModel.correctiveDeptName==='true'" label="整改部门" align="left"
                    prop="correctiveDeptName" width="100" />
                <el-table-column v-if="setModel.correctiveUserChName==='true'" label="整改人" align="left"
                    prop="correctiveUserChName" width="80" />
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="primary" icon="el-icon-edit" @click.stop="handleUpdate(scope.row,true)">
                    编辑</eagle-row-button>
                <eagle-row-button type="primary" icon="el-icon-view" @click.stop="handleUpdate(scope.row,false)">
                    详情</eagle-row-button>
                <eagle-row-button type="danger" v-if="scope.row.self" icon="el-icon-view"
                    @click.stop="handleDelete(scope.row)">
                    删除</eagle-row-button>
            </template>
        </eagle-page>
        <eagle-form ref="EagleForm" title="隐患信息" :model="model" :controller="controller" width="800px">
            <eagle-block border>
                <eagle-image label="隐患图片" prop="attachs" v-model="model.attachs" :isEdit="isEdit" />
                <eagle-input prop="correctiveArea" label="隐患区域" v-model="model.correctiveArea" :isEdit="isEdit" />
                <eagle-input label="隐患描述" prop="hiddenDangerDesc" v-model="model.hiddenDangerDesc" :isEdit="isEdit"
                    type="textarea" />
                <!-- <eagle-input label="隐患分类" prop="attachs" v-model="model.attachs" :isEdit="isEdit" type="textarea" /> -->
                <el-col :span="12">
                    <eagle-choose @clearChoose="clearHidden(model)" required :isEdit="isEdit" label="隐患分类"
                        v-model="model.hiddenName" @change="handleShowHidden()" />
                </el-col>
                <el-row>
                    <eagle-radio label="隐患性质" prop="hiddenDangerTypeCode" v-model="model.hiddenDangerTypeCode"
                        :isEdit="isEdit" type="textarea" :data-source="params.dangerType" />
                </el-row>
                <eagle-input label="整改措施" prop="correctiveMeasure" v-model="model.correctiveMeasure" :isEdit="isEdit"
                    type="textarea" />
                <eagle-date label="整改期限" prop="correctiveDeadline" quickChoose v-model="model.correctiveDeadline"
                    :isEdit="isEdit" />
                <eagle-input label="整改部门" prop="correctiveDeptName" v-model="model.correctiveDeptName" :isEdit="isEdit"
                    type="textarea" />
                <eagle-input label="整改人" prop="correctiveUserChName" v-model="model.correctiveUserChName"
                    :isEdit="isEdit" type="textarea" />
            </eagle-block>
        </eagle-form>

        <choose-danger-type ref="chooseDangerType" v-model="model.hiddenCode" @change="handleChooseDangerType" />

    </div>

</template>
<script>
import chooseDangerType from "@/views/components/danger/chooseDangerType";
import EagleBlock from "../../../components/Eagle/eagle-block.vue";
export default {
    components: {
        chooseDangerType,
        EagleBlock,
    },
    name: "checkTaskList",
    data() {
        return {
            model: {},
            isEdit: false,
            showSearch: true,
            queryParams: {
                dataType: "list",
                year: new Date(),
                month: null,
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            // 查询条件
            conditions: {
                hiddenDangerTypeCode: { value: "", options: "=" },
                hiddenDangerDesc: { value: "", options: "like" },
            },

            controller: "danger/simpleCheck", //对应后端控制器
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 标题
            title: "隐患",
            // 表单参数
            form: {},

            // 表单校验
            rules: {},
            ids: [],
            isSelf: false,
            rowShow: false,
            setModel: {},

            params: {
                checkSource: [
                    { id: null, name: "不限" },
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],

                dangerType: [],
                dangerTypeConditions: [],
                month: [
                    { id: null, name: "不限" },
                    { id: 1, name: "1月" },
                    { id: 2, name: "2月" },
                    { id: 3, name: "3月" },
                    { id: 4, name: "4月" },
                    { id: 5, name: "5月" },
                    { id: 6, name: "6月" },
                    { id: 7, name: "7月" },
                    { id: 8, name: "8月" },
                    { id: 9, name: "9月" },
                    { id: 10, name: "10月" },
                    { id: 11, name: "11月" },
                    { id: 12, name: "12月" },
                ],
            },
        };
    },

    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        clearHidden(obj) {
            obj.hiddenCode = "";
            obj.hiddenName = "";
            obj.hiddenTypeName = "";
            obj.hiddenTypeCode = "";
        },
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            _this.common
                .getCustomDict("danger_simple_danger_type")
                .then(function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) => p.paramId === "danger_simple_danger_type"
                    );
                    _this.params.dangerTypeConditions = res.data.filter(
                        (p) => p.paramId === "danger_simple_danger_type"
                    );
                    _this.params.dangerTypeConditions.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                });

            _this.common
                .getModuleSettins("danger_check_simple")
                .then(function (res) {
                    if (res.code == 200 && res.data) {
                        _this.setModel = res.data;
                    }
                });
        },

        handleUpdate(row, flag) {
            let _this = this;
            _this.isEdit = flag;
            _this.$refs.EagleForm.handleUpdate(row, {
                isEdit: flag,
                title: flag ? "编辑隐患" : "隐患详情",
                callback: function (data) {
                    _this.model = data;
                },
            });
        },
        //查询
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageList",
            });
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row);
        },

        //查询条件重置
        resetQuery() {
            this.queryParams.year = new Date();
            this.queryParams.month = null;
            this.conditions.hiddenDangerTypeCode.value = "";
            this.conditions.hiddenDangerDesc.value = "";
            this.search();
        },

        handleChooseDangerType(val, obj) {
            this.model.hiddenCode = val;
            this.model.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.model.hiddenTypeCode = obj.dType;
        },
        handleShowHidden() {
            this.$refs.chooseDangerType.show();
        },
    },
};
</script>
<style type="text/css">
.form-table {
    background-color: #dfe6ec;
    width: 100%;
    text-align: center;
}

.form-table tr,
.form-table th {
    border: none;
    background-color: #f8f8f9;
    height: 50px;
    line-height: 50px;
}

.form-table td {
    border: none;
    background-color: #ffffff;
    height: 50px;
    line-height: 50px;
}

.form-table .group td {
    background-color: #d2e2e870;
}

.item-title {
    text-align: left;
}

.item-title span {
    margin: 10px !important;
}
</style>
 