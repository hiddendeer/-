 <template name="templateItem">
    <div class="templateItem">
        <el-dialog v-dialogDrag :visible.sync="visible" width="800px" :title="isEdit?'编辑依据':'查看依据'">
            <div style="max-height:500px;overflow:auto;">
                <el-form ref="form" :model="model">
                    <eagle-block border>
                        <eagle-input label-width="100px" :is-edit="isEdit" isFullCol type="textarea" label="依据来源" prop="gistSource" v-model="model.gistSource" />
                        <!-- <eagle-input label-width="100px" :is-edit="isEdit" isFullCol type="textarea" label="隐患描述" prop="hiddenDangerDesc" v-model="model.hiddenDangerDesc" />
                    <eagle-input label-width="100px" :is-edit="isEdit" isFullCol type="textarea" label="整改建议" prop="correctiveAdvise" v-model="model.correctiveAdvise" /> -->
                        <eagle-input label-width="100px" :is-edit="isEdit" isFullCol type="textarea" label="法律责任" prop="legalLiability" v-model="model.legalLiability" />
                        <eagle-input label-width="100px" :is-edit="isEdit" isFullCol type="textarea" label="法律原文" prop="originalText" v-model="model.originalText" />
                    </eagle-block>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button @click="visible=false">{{isEdit?"取 消":"关 闭"}} </el-button>
                <el-button type="primary" v-if="isEdit" @click="confirmForm">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template> 
               
<script>
export default {
    name: "templateItem",
    data() {
        return {
            visible: false,
            model: {},
            tempModel: {},
            isEdit: true,
            params: {
                dangerType: [],
            },
        };
    },
    created() {},
    methods: {
        confirmForm() {
            for (let key in this.model) {
                this.tempModel[key] = this.model[key];
            }
            this.visible = false;
        },
        show(config) {
            this.model = this.deepClone(config.model);
            this.tempModel = config.model;
            this.isEdit = config.isEdit;
            this.visible = true;
        },
    },
};
</script>
 
<style lang="scss" scoped>
.templateItem .el-dialog__body {
    padding: 0 20px;
    .el-form-item__content {
        white-space: pre-line;
    }
}
</style>