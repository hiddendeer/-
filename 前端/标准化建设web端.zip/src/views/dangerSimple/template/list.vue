<template>
    <div class="app-container">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <!-- <eagle-select label-width="120px" label="所属类目" @change="search()" prop="opCode" v-model="conditionsVals.opCode" :data-source="params.opType" placeholder="请选择所属类目" clearable size="small">
            </eagle-select> -->
            <eagle-input label-width="120px" @changeEnter="search()" label="名称" prop="title" v-model="conditionsVals.title" placeholder="请输入名称模糊查询" clearable size="small" />
        </eagle-condition>
        <eagle-page :queryParams="queryParams" :controller="controller" @bindSelection="bindSelection" ref="EaglePage" :pageSize="2000">
            <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                        </el-button>
                    </el-col>
                </el-row>
            </template>
            <template slot="slot-table">
                <el-table-column label="名称" align="left" prop="title" />

                <!-- <el-table-column label="所属类目" align="center" width="180">
                    <template slot-scope="scope">
                        <span>{{ formateDict(params.opType, scope.row.opCode) }}</span>
                    </template>
                </el-table-column> -->

                <el-table-column label="检查说明" align="left" prop="remarks" />
                <el-table-column label="修改人" align="left" prop="createChnName" width="120" />
                <el-table-column label="修改日期" align="left" prop="createDate" width="180">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <div>
                    <eagle-row-button type="primary" icon="el-icon-view" @click="handShowView(scope.row)">详情
                    </eagle-row-button>
                    <eagle-row-button type="primary" icon="el-icon-document-copy" @click.stop="handleCopy(scope.row)">复制
                    </eagle-row-button>
                    <eagle-row-button type="primary" icon="el-icon-edit" v-if="scope.row.createUserName != 'system'" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>

                    <eagle-row-button type="danger" icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除
                    </eagle-row-button>
                </div>
            </template>
        </eagle-page>
        <eagle-form :controller="controller" :is-edit="isEdit" :title="title" :form="form" width="1000px" label-width="120px" ref="EagleForm" @afterSave="search" @bindData="bindData">
            <el-col :span="12">
                <eagle-input label="名称" :is-edit="isEdit" prop="title" required v-model="form.title" />
            </el-col>
            <eagle-input label="检查说明" :is-edit="isEdit" prop="remarks" type="textarea" :row="2" v-model="form.remarks" />
            <el-col :span="24">
                <div style="max-height:500px;overflow:auto">
                    <table class="form-table">
                        <thead>
                            <tr>
                                <th width="80px" style="text-align: center;">
                                    <div class="cell">序号</div>
                                </th>
                                <th style="text-align: center;">
                                    <div class="cell">检查内容</div>
                                </th>
                                <th style="text-align: center;" width="180px">
                                    <div class="cell">操作</div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="(item, index) in form.itemGroups">
                                <tr :key="index" class="group">
                                    <td>{{ index + 1 }}</td>
                                    <td class="item-title">
                                        <el-input v-if="isEdit" v-model="item.groupTitle" placeholder="请输入检查项分组标题" />
                                        <span v-else>{{ item.groupTitle }}</span>
                                    </td>
                                    <td>
                                        <eagle-row-button size="mini" v-if="isEdit" type="primary" icon="el-icon-plus" @click="handPushGroup(index)"></eagle-row-button>
                                        <eagle-row-button size="mini" v-if="isEdit && form.itemGroups.length > 1 && index > 0" type="primary" @click.stop="handUpGroup(index)" icon="el-icon-top"></eagle-row-button>
                                        <eagle-row-button size="mini" v-if="isEdit && form.itemGroups.length > 1 && (index + 1) < form.itemGroups.length" @click.stop="handDownGroup(index)" type="primary" icon="el-icon-bottom">
                                        </eagle-row-button>
                                        <eagle-row-button size="mini" v-if="isEdit" type="danger" @click.stop="handRemoveGroup(index)" icon="el-icon-delete">
                                        </eagle-row-button>
                                    </td>
                                </tr>
                                <template v-for="(citem, cindex) in item.items">
                                    <tr :key="index + '_' + cindex">
                                        <td>{{ index + 1 }}.{{ cindex + 1 }}</td>
                                        <td class="item-title">
                                            <el-input v-if="isEdit" v-model="citem.itemName" type="textarea" rows="3" placeholder="请输入检查项内容和规范" />
                                            <span v-else>{{ citem.itemName }}</span>
                                        </td>
                                        <td>
                                            <eagle-row-button size="mini" slot="append" icon="el-icon-folder-opened" @click="handleShowItem(citem)"></eagle-row-button>
                                            <eagle-row-button size="mini" v-if="isEdit" type="primary" @click="handleDangerLGShow(index, cindex, citem)" icon="el-icon-zoom-in">
                                            </eagle-row-button>

                                            <eagle-row-button size="mini" v-if="isEdit" type="primary" @click="handPushItems(index, cindex)" icon="el-icon-plus">
                                            </eagle-row-button>

                                            <eagle-row-button size="mini" v-if="isEdit && item.items.length > 1 && cindex > 0" type="primary" @click.stop="handUpItems(index, cindex)" icon="el-icon-top">
                                            </eagle-row-button>
                                            <eagle-row-button size="mini" v-if="isEdit && item.items.length > 1 && cindex + 1 < item.items.length" @click.stop="handDownItems(index, cindex)" type="primary" icon="el-icon-bottom"></eagle-row-button>
                                            <eagle-row-button size="mini" v-if="isEdit" type="danger" icon="el-icon-delete" @click.stop="handRemoveItems(index, cindex)">
                                            </eagle-row-button>
                                        </td>
                                    </tr>
                                </template>
                            </template>
                        </tbody>
                    </table>
                </div>
            </el-col>
        </eagle-form>

        <templateItem ref="templateItem" />
        <dangerlgAddWindow ref="dangerLG" @choosed="choosedDangerLg"></dangerlgAddWindow>
    </div>

</template>
<script>
// import templateItem from "@/views/site/components/danger/template/templateItem";

import templateItem from "@/views/dangerSimple/components/templateItem";

// import chooseDangerType from "@/views/components/danger/chooseDangerType";
import dangerlgAddWindow from "@/views/site/components/danger/dangerlg/dangerlgAddWindow";
export default {
    components: { templateItem, dangerlgAddWindow },
    name: "dangerTemplate",
    data() {
        return {
            isEdit: false,
            showSearch: true,
            queryParams: {
                dataType: "list",
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                opCode: "=",
                title: "like",
            },
            // 查询条件
            conditionsVals: {
                opCode: null,
                title: "",
            },
            controller: "danger/simpleTemplate", //对应后端控制器
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 标题
            title: "安全检查表",
            // 表单参数
            form: {},
            rowData: {},
            // 表单校验
            rules: {},
            ids: [],
            //   rowShow: false,
            params: {
                opType: [],
                dangerType: [],
            },
            lgIndex: 0,
            lgCIndex: 0,
        };
    },
    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        handleDangerLGShow(index, cindex, citem) {
            this.rowData = citem;
            //index,cindex
            this.lgIndex = index;
            this.lgCIndex = cindex;
            this.$refs.dangerLG.show({ opType: 3 });
        },
        choosedDangerLg(array) {
            let _this = this;
            if (array) {
                array.forEach(function (item, index) {
                    if (index === 0) {
                        _this.setVal(index, item);
                    } else {
                        _this.form.itemGroups[_this.lgIndex].items.splice(
                            _this.lgCIndex + index,
                            0,
                            {}
                        );
                        _this.setVal(index, item);
                    }
                });
            }
        },

        setVal(index, item) {
            let _this = this;
            let model =
                _this.form.itemGroups[_this.lgIndex].items[
                    _this.lgCIndex + index
                ];
            model.itemName = item.correctiveAdvise;
            model.originalText = item.originalText;
            model.legalLiability = item.legalLiability;
            model.gistSource = item.gistSource;
            model.correctiveAdvise = item.correctiveAdvise;
            if (item.hiddenDangerList && item.hiddenDangerList.length > 0) {
                model.hiddenDangerDesc =
                    item.hiddenDangerList[0].hiddenDangerDesc;
            }
        },

        arraySpanMethod({ row, column, rowIndex, columnIndex }) {
            if (!row.datas) {
                if (columnIndex === 0) {
                    return [0, 0];
                } else {
                    if (columnIndex === 1) return [1, 2];
                }
            }
        },
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.site_danger_check_template_type,
                    _this.constParams.hidden_danger_type,
                ],
                function (res) {
                    _this.params.opType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.site_danger_check_template_type
                    );
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },

        bindData(data) {
            this.form = data;
        },
        /** 新增按钮操作 */
        handleAdd() {
            this.isEdit = true;
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.isEdit = true;
            //  this.$refs.EagleForm.handleUpdate(row);
            let url = `${this.controller}/getTemplateItems?templateCode=${row.code}`;
            this.$refs.EagleForm.handleUpdate(row, { url: url });
        },
        handShowView(row) {
            this.isEdit = false;
            let url = `${this.controller}/getTemplateItems?templateCode=${row.code}`;
            this.$refs.EagleForm.handleUpdate(row, { url: url });
        },
        handleCopy(row) {
            this.isEdit = true;
            let _this = this;
            let url = `${this.controller}/getTemplateItems?templateCode=${row.code}`;
            this.$refs.EagleForm.handleUpdate(row, {
                title: "复制检查表",
                url: url,
                callback: () => {
                    _this.form.id = 0;
                    (_this.form.code = ""),
                        _this.form.itemGroups.forEach((x) => {
                            x.id = 0;
                            x.code = "";
                            x.items.forEach((p) => {
                                p.id = 0;
                                p.code = "";
                            });
                        });
                },
            });
        },

        bindSelection(selection) {
            this.ids = selection.map((item) => item.id);
            this.single = selection.length != 1;
            this.multiple = !selection.length;
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            var url = `${_this.controller}/deleteByCode/${row.code}`;
            this.$confirm("是否确认删除此行数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http.delLoading(_this.loading(), url, {}, function (res) {
                    _this.search();
                    _this.msgSuccess("删除成功");
                });
                // _this.http.del(url).then(function () {
                //     _this.search();
                //     _this.msgSuccess("删除成功");
                // });
            });
        },

        //查询
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getLibPageList",

                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },

        //查询条件重置
        resetQuery() {
            (this.conditionsVals.opCode = null),
                (this.conditionsVals.title = ""),
                this.search();
        },
        handPushGroup(index) {
            this.form.itemGroups.splice(index + 1, 0, { items: [{}] });
        },
        handUpGroup(index) {
            this.form.itemGroups.splice(
                index - 1,
                0,
                this.form.itemGroups[index]
            );
            this.form.itemGroups.splice(index + 1, 1);
            // this.form.itemGroups.splice(index + 1, 0, { items: [{}] });
        },
        handDownGroup(index) {
            this.form.itemGroups.splice(
                index + 2,
                0,
                this.form.itemGroups[index]
            );
            this.form.itemGroups.splice(index, 1);
        },
        handRemoveGroup(index) {
            this.form.itemGroups.splice(index, 1);
            if (this.form.itemGroups.length <= 0) {
                this.form.itemGroups.splice(0, 0, { items: [{}] });
            }
        },

        handPushItems(index, cindex) {
            this.form.itemGroups[index].items.splice(cindex + 1, 0, {});
        },
        handUpItems(index, cindex) {
            this.form.itemGroups[index].items.splice(
                cindex - 1,
                0,
                this.form.itemGroups[index].items[cindex]
            );
            this.form.itemGroups[index].items.splice(cindex + 1, 1);
        },
        handDownItems(index, cindex) {
            this.form.itemGroups[index].items.splice(
                cindex + 2,
                0,
                this.form.itemGroups[index].items[cindex]
            );
            this.form.itemGroups[index].items.splice(cindex, 1);
        },
        handRemoveItems(index, cindex) {
            this.form.itemGroups[index].items.splice(cindex, 1);
            if (this.form.itemGroups[index].items <= 0) {
                this.form.itemGroups[index].items.splice(0, 0, {});
            }
        },
        handleShowItem(row) {
            this.rowData = row;
            this.$refs.templateItem.show({ model: row, isEdit: this.isEdit });
        },
    },
};
</script>
<style type="text/css">
.form-table {
    background-color: #dfe6ec;
    width: 100%;
    text-align: center;
}

.form-table tr,
.form-table th {
    border: none;
    background-color: #f8f8f9;
    height: 50px;
    line-height: 50px;
}

.form-table td {
    border: none;
    background-color: #ffffff;
    height: 50px;
    line-height: 22px;
}

.form-table .group td {
    background-color: #d2e2e870;
}

.item-title {
    text-align: left;
}

.item-title span {
    margin: 10px !important;
}
</style>
<style rel="stylesheet/scss" lang="scss">
.form-table {
    button[type="primary"] {
        color: #409eff;
    }

    button[type="success"] {
        color: #67c23a;
    }

    button[type="info"] {
        color: #909399;
    }

    button[type="warning"] {
        color: #e6a23c;
    }

    button[type="danger"] {
        color: #f56c6c;
    }

    .el-button [class*="el-icon-"] + span {
        margin-left: 2px;
        //letter-spacing: 2px;
    }
}
</style>
 