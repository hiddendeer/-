<template name="choose-danger-type-dialog">

    <el-dialog v-dialogDrag :visible.sync="visible" width="800px" title="隐患分类" :append-to-body="true">
        <eagle-block border>
            <div class="choose-danger-type-dialog">
                <div>
                    <div class="item-title">现场管理</div>
                    <div class="item-group">
                        <div v-for="(item,index) in data2" :key="index" class="item">
                            <el-radio v-model="val" :label="item.dCode" border @change="handleChange(item)">{{item.dName}}</el-radio>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="item-title">基础管理</div>
                    <div class="item-group">
                        <div v-for="(item,index) in data1" :key="index" class="item">
                            <el-radio v-model="val" :label="item.dCode" border @change="handleChange(item)">{{item.dName}}</el-radio>
                        </div>
                    </div>
                </div>
            </div>
        </eagle-block>
        <span slot="footer" class="dialog-footer">
            <el-button @click="visible = false">取 消</el-button>
            <el-button type="primary" @click="handleConfirm">确 定</el-button>
        </span>
    </el-dialog>

</template>
<script>
export default {
    name: "chooseDangerType",
    props: {
        value: {
            type: Number | String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            val: this.value,
            visible: false,
            controller: "site/dangerTemplate", //对应后端控制器
            title: "选择隐患分类",
            data1: [],
            data2: [],
            chooseData: {},
        };
    },
    created() {
        this.val = this.value;
        console.log("created:val", this.value);
    },
    watch: {
        value(nVal, oVal) {
            console.log("watch:val", nVal);
            //  if (nVal !== oVal) {
            this.val = nVal;
            //  }
        },
        // val(nVal, oVal) {
        //     if (nVal !== oVal) {
        //         this.$emit("input", nVal);
        //     }
        // },
    },
    methods: {
        handleConfirm() {
            if (!this.val) {
                this.$message({ type: "info", message: "请选择隐患分类" });
                return;
            }
            this.$emit("input", this.val);
            if (this.chooseData) {
                this.$emit("change", this.val, this.chooseData);
            } else {
                this.chooseData = this.data.find((x) => x.dCode == this.val);
                this.$emit("change", this.val, this.chooseData);
            }
            this.visible = false;
        },
        handleChange(item) {
            this.chooseData = item;
        },
        show() {
            this.visible = true;
            if (!this.data || this.data == [] || this.data.length <= 0) {
                this.initData();
            }
        },
        initData() {
            let _this = this;
            _this.http
                .get("/site/dangerTemplate/getDangerType/1")
                .then((res) => {
                    _this.data2 = res.data.filter((x) => x.dType === "2");
                    _this.data1 = res.data.filter((x) => x.dType === "1");
                });
        },
    },
};
</script>
 
<style lang="scss" scoped>
.choose-danger-type-dialog {
    ::v-deep .el-radio__label {
        padding-left: 10px !important;
    }
    .el-dialog__body {
        padding: 0 20px;
    }
    .item-title {
        font-size: 16px;
        direction: ltr;
        line-height: 25px;
        padding: 1px 10px;
        background-color: #46a6ff;
        color: #fff;
    }
    .item-group {
        display: flex;
        flex-flow: row;
        flex-wrap: wrap;

        .item {
            width: 25%;
            margin-top: 5px;
            margin-bottom: 5px;
            .el-radio {
                width: 160px;
            }
        }
    }
}
</style>