<template>
    <div class="staff_role_tree">
        <div class="tree-title" :style="{ backgroundColor: bgColor }">{{ this.Title }}</div>
        <el-scrollbar class="scroll" :style="{ 'height': scrollHeight, backgroundColor: bgColor }">
            <el-tree
                class="tree-line"
                :data="menuList"
                node-key="opNo"
                :expand-on-click-node="false"
                default-expand-all
                @node-click="handleTreeClick"
            >
                <span class="custom-tree-node" slot-scope="{ data }">
                    <el-button
                        :title="data.moduleName"
                        v-if="data.type == 1"
                        type="text"
                        style="color: #666666; font-weight: bold"
                    >{{ ellipsis(data.moduleName, charlen) }}</el-button>
                    <span v-else>
                        <span
                            :title="data.moduleName"
                            style="display:inherit;margin-left:5px;font-size: 5px;"
                        >{{ ellipsis(data.moduleName, charlen) }}</span>
                    </span>

                    <span v-if="buttonShow" class="operate-btn">
                        <eagle-row-button
                            style="color:red"
                            size="mini"
                            v-if="data.type!=1"
                            @click.stop="handleDelete(data)"
                        >删除</eagle-row-button>
                    </span>
                </span>
            </el-tree>
        </el-scrollbar>
    </div>
</template>
<script>
import { Message, MessageBox } from "element-ui";
import { handleTree } from "@/utils/EageleRMC";
// import windowTpldataTemp from "./windowTpldataTemp.vue";
export default {
    components: {},
    name: "eagle-tree-temp-module-role",
    props: {
        Title: {
            type: String,
            default() {
                return "目录";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        mainNo: {
            type: String,
            default() {
                return "opNo";
            },
        },
        superiorNo: {
            type: String,
            default() {
                return "opPno";
            },
        },
        buttonShow: {
            type: Boolean,
            default() {
                return true;
            },
        },
        scrollHeight: {
            type: String,
            default: "600px",
        },
        bgColor: {
            type: String,
            default: "#fafafa",
        },
        charlen: {
            type: Number,
            default: 8,
        },
    },
    data() {
        return {
            docName: "",
            isMouseenter: true,
            menuList: [],
            opForm: {},
            windowTpDataTitle: "",
            originForm: {},
            origindata: { show: false }, //记录上一次点击的实体    用于清除显示操作状态
        };
    },
    created() {
        this.geMenuList();
    },
    methods: {
        ellipsis(value, len) {
            if (!value) return "";
            if (value.length > len) {
                return value.slice(0, len) + "...";
            }
            return value;
        },
        geMenuList() {
            this.http.get(this.controller).then((res) => {
                if (res.code === 200) {
                    this.menuList = handleTree(
                        res.data,
                        this.mainNo,
                        this.superiorNo,
                        "children"
                    );
                }
            });
        },
        handleTreeClick(val) {
            // if (this.origindata !== null) {
            //   this.$set(this.origindata, "show", false);
            // }
            // this.origindata = val;
            // this.docName = val.docName;
            // this.$set(val, "show", true);
            this.$emit("handleTreeClick", val);
        },

        handleDelete(val) {
            let _this = this;
            MessageBox.confirm("确定删除该角色吗？", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(() => {
                    let url = "system/eagleModuleRole/delete/" + val["id"];
                    _this.http.delLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.geMenuList();
                            _this.msgSuccess("删除成功");
                            _this.$emit("afterhandle");
                        }
                    );

                    // this.http.del("system/sysUserRole/deleteByRoleCode/" + val['userId'] + "/" + val['roleId'] + "/" + val['roleCode']).then((res) => {
                    //     if (res.code === 200) {
                    //         Message.success("删除成功");
                    //         this.geMenuList();
                    //     }
                    // });
                })
                .catch(() => {
                    return;
                });
        },
        // handleWindowTpDataClose(val) {
        //     this.dialogVisible = val;
        // },
        handleSubmitClose(val) {
            // this.dialogVisible = val;
            this.geMenuList();
        },
        getIcon: function (type) {
            switch (type) {
                case "2":
                    return require("@/assets/images/file_type_icon/file1.png");
                case "3":
                    return require("@/assets/images/file_type_icon/file2.png");
                case "4":
                    return require("@/assets/images/file_type_icon/file3.png");
                default:
                    return require("@/assets/images/file_type_icon/file4.png");
            }
        },
    },
};
</script>


<style rel="stylesheet/scss" lang="scss" scoped>
.staff_role_tree {
    .scroll {
        background-color: #fafafa;
    }
    .scroll .el-scrollbar__wrap {
        overflow-x: hidden;
    }

    .tree-title {
        width: 100%;
        height: 50px;
        line-height: 50px;
        text-align: center;
        border-bottom: 1px solid #e6e6e6;
        background-color: #fafafa;
        margin: 5px 0 0 0;
    }
    .custom-tree-node {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 14px;
        padding-right: 8px;
    }

    .el-tree {
        padding: 10px 0;
        background-color: #ffffff;
    }

    .el-tree .el-tree-node__content {
        padding-left: 0px !important;
        display: flex;
    }
    .el-tree .el-tree-node.is-current > .el-tree-node__content {
        background: rgba(22, 119, 255, 0.1);
        //border-right: 3px solid #1677ff;
        color: #187aff;
        .el-tree-node__expand-icon {
            color: rgb(0, 112, 255);
        }
        .is-leaf {
            color: rgba(0, 0, 0, 0);
        }
    }

    /* 树形结构节点添加连线 */
    .tree-line .el-tree-node {
        position: relative;
        padding-left: 16px;
    }
    .tree-line > .el-tree-node {
        padding-left: 10px;
    }

    .tree-line .el-tree-node__children {
        padding-left: 16px;
    }
    .tree-line .el-tree-node:last-child:before {
        height: 26px;
    }

    .tree-line .el-tree > .el-tree-node:before {
        border-left: none;
    }
    .scroll
        .el-tree
        > .el-tree-node
        > .el-tree-node__children
        > .el-tree-node:before {
        top: -10px;
    }
    .scroll .el-tree > .el-tree-node:after {
        border-top: none;
    }

    .tree-line .el-tree-node__children .el-tree-node:before {
        content: "";
        left: -3px;
        position: absolute;
        right: auto;
        border-width: 1px;
    }

    .tree-line .el-tree-node:after {
        content: "";
        left: -3px;
        position: absolute;
        right: auto;
        border-width: 1px;
    }
    .tree-line .el-tree-node__expand-icon.is-leaf {
        margin-left: -15px;
    }

    .tree-line .el-tree-node:before {
        border-left: 1px solid #dddddd;
        bottom: 0px;
        height: 100%;
        top: -12px;
        width: 1px;
    }

    .tree-line .el-tree-node:after {
        border-top: 1px solid #dddddd;
        height: 20px;
        top: 12px;
        width: 28px;
    }
    .tree-line .el-tree-node__expand-icon {
        font-size: 15px;
    }
}
</style>
<style rel="stylesheet/scss" scoped>
.el-tree /deep/ .is-current > .el-tree-node__content {
  background: rgba(22, 119, 255, 0.1) !important;
  color: #187aff !important;
}
</style>
