<template>
  <div class="company-table-container app-container">
    <div class="layer">
      <el-row>
        <el-col :span="6" class="left-content">
          <!-- 一级目录 -->
          <eagle-tree-temp-module-role Title="目录" ref="EagleTree" mainNo="moduleCode" superiorNo="roleCode"
            scrollHeight="calc(100vh - 125px)" :controller="EagleOrganController" @afterhandle="afterhandle"
            @handleTreeClick="handleTreeClick" />
        </el-col>
        <el-col :span="18" class="right-content">
          <el-row>
            <el-button type="primary" plain icon="el-icon-d-arrow-left" size="mini" :disabled="!isDisabled"
              @click="handleRolesImport">添加角色</el-button>
            <!-- <el-button type="primary" plain icon="el-icon-setting" size="mini" :disabled="isDisabled" @click="handleMenusImport">维护菜单</el-button> -->
          </el-row>
          <br />

          <!--  -->
          <el-tabs v-model="activeName1" @tab-click="handleClick">
            <el-tab-pane label="模块角色菜单配置" name="second">
              <el-row v-show="treeCurrentClick && treeCurrentClick.type == 2">
                <el-row>
                  <el-button type="primary" plain icon="el-icon-setting" size="mini" :disabled="isDisabled"
                    @click="handleMenusImport">维护菜单</el-button>
                </el-row>
                <el-table v-loading="loading_menu" :data="menuList" row-key="menuId" :tree-props="{
                  children: 'children',
                  hasChildren: 'hasChildren',
                }">
                  <el-table-column prop="menuName" label="菜单名称" :show-overflow-tooltip="true" width="200">
                  </el-table-column>
                  <el-table-column prop="icon" label="图标" align="left" width="100">
                    <template slot-scope="scope">
                      <svg-icon :icon-class="scope.row.icon" />
                    </template>
                  </el-table-column>
                  <el-table-column prop="orderNum" label="排序" width="60"></el-table-column>
                  <el-table-column prop="path" label="path" :show-overflow-tooltip="true"></el-table-column>
                  <el-table-column prop="component" label="组件路径" :show-overflow-tooltip="true"></el-table-column>
                </el-table>
              </el-row>
            </el-tab-pane>

            <el-tab-pane label="手机角色菜单配置" name="fourth">
              <el-row v-show="treeCurrentClick && treeCurrentClick.type == 2">
                <el-row>
                  <el-button type="primary" plain icon="el-icon-setting" size="mini" :disabled="isDisabled"
                    @click="handlePhoneMenusImport">维护菜单</el-button>
                </el-row>
                <el-table v-loading="loading_menu" :data="menuList" row-key="menuId" :tree-props="{
                  children: 'children',
                  hasChildren: 'hasChildren',
                }">
                  <el-table-column prop="menuName" label="菜单名称" :show-overflow-tooltip="true" width="200">
                  </el-table-column>
                  <el-table-column prop="icon" label="图标" align="left" width="100">
                    <template slot-scope="scope">
                      <svg-icon :icon-class="scope.row.icon" />
                    </template>
                  </el-table-column>
                  <el-table-column prop="orderNum" label="排序" width="60"></el-table-column>
                  <el-table-column prop="path" label="path" :show-overflow-tooltip="true"></el-table-column>
                  <el-table-column prop="component" label="组件路径" :show-overflow-tooltip="true"></el-table-column>
                </el-table>
              </el-row>
            </el-tab-pane>
          </el-tabs>
        </el-col>
      </el-row>
    </div>

    <eagle-form :customButtons="true" :controller="controller" :form="form" width="800px" label-width="120px"
      ref="EagleForm" @bindData="bindData" @afterSave="afterSave">
      <eagle-condition @search="search()" @resetQuery="resetQuery()" style="padding: 5px">
        <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="roleName"
          v-model="conditionsVals.roleName" placeholder="请输入角色名称进行模糊查询" clearable size="small" />
      </eagle-condition>
      <eagle-page :controller="controller" ref="EaglePage" btn-width="140px" :showBtn="false" selectTextField="roleName"
        selectField="id">
        <template slot="slot-table">
          <el-table-column label="角色名称" align="left" prop="roleName" />
          <el-table-column label="角色Value" align="left" prop="roleValue" />
        </template>
      </eagle-page>
      <div slot="buttons" class="dialog-footer">
        <el-button @click="cancel">关 闭</el-button>
        <el-button type="primary" @click="submitForm">保 存</el-button>
      </div>
    </eagle-form>

    <eagle-form :customButtons="true" controller="system/role/roleMenuTreeselect/2" :form="formMenu" width="800px"
      label-width="120px" ref="EagleFormMenu" @bindData="bindDataMenu" @afterSave="afterSaveMenu">
      <el-form-item label="菜单权限">
        <el-checkbox v-model="menuExpand" @change="handleCheckedTreeExpand($event, 'menu')">展开/折叠</el-checkbox>
        <el-checkbox v-model="menuNodeAll" @change="handleCheckedTreeNodeAll($event, 'menu')">全选/全不选</el-checkbox>
        <el-checkbox v-model="menuCheckStrictly" @change="handleCheckedTreeConnect($event, 'menu')">父子联动</el-checkbox>
        <el-tree class="tree-border" :data="menuOptions" show-checkbox ref="menu" node-key="id"
          :check-strictly="!menuCheckStrictly" empty-text="加载中，请稍后" :props="defaultProps"></el-tree>
      </el-form-item>
      <div slot="buttons" class="dialog-footer">
        <el-button @click="cancelMenu">关 闭</el-button>
        <el-button type="primary" @click="submitFormMenu">保 存</el-button>
      </div>
    </eagle-form>
    <!--手机模块提交 -->
    <eagle-form :customButtons="true" controller="system/role/roleMenuTreeselect/2" :form="formMenu" width="800px"
      label-width="120px" ref="EagleFormPhoneMenu" @bindData="bindDataMenu" @afterSave="afterSaveMenu">
      <el-form-item label="手机菜单权限">
        <el-checkbox v-model="menuExpand" @change="handleCheckedTreeExpand($event, 'menu')">展开/折叠</el-checkbox>
        <el-checkbox v-model="menuNodeAll" @change="handleCheckedTreeNodeAll($event, 'menu')">全选/全不选</el-checkbox>
        <el-checkbox v-model="menuCheckStrictly" @change="handleCheckedTreeConnect($event, 'menu')">父子联动</el-checkbox>
        <el-tree class="tree-border" :data="menuOptions" show-checkbox ref="menu" node-key="id"
          :check-strictly="!menuCheckStrictly" empty-text="加载中，请稍后" :props="defaultProps"></el-tree>
      </el-form-item>
      <div slot="buttons" class="dialog-footer">
        <el-button @click="cancelPhoneMenu">关 闭</el-button>
        <el-button type="primary" @click="submitFormPhoneMenu">保 存</el-button>
      </div>
    </eagle-form>
  </div>
</template>
<script>
import eagleTreeTempModuleRole from "./eagle-tree-temp-module-role.vue";
import {
  listMenu,
  getMenu,
  delMenu,
  addMenu,
  updateMenu,
} from "@/api/system/menu";
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";
import IconSelect from "@/components/IconSelect";
import { nextTick } from "process";
import { handleTree } from "@/utils/EageleRMC";

export default {
  components: { eagleTreeTempModuleRole, Treeselect, IconSelect },
  props: {},
  data() {
    return {
      activeName1: "second",
      code: this.$route.query.code, //台账模板选中数据的code值
      showBtn: true,
      controller: "system/eagleRole",
      EagleOrganController: "system/eagleModuleRole/getSysModuleRoleList",
      // 查询条件
      queryParams: {
        dataType: "list",
      },
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        roleName: "like",
      },
      // 查询条件
      conditionsVals: {
        roleName: "",
      },
      // controller: "support/DagerTpl", //对应后端控制器
      form: {},
      params: {
        fileOnlineTempDocType: [],
        docType: [],
        ledgerTempCatalogCategory: [],
        ledgerTempCatalogCategoryShow: [],
      },
      TreeTitle: "请选择目录",
      type: "", //节点类型
      name: "",
      treeCurrentCode: "",
      treeCurrentClick: "",
      //新增
      checkListVisible: false,
      activeName: "first",
      isDisabled: false, //true可以点击，false不能点击
      typeName: "",

      // ==================================菜单参数
      loading_menu: true,
      // 显示搜索条件
      showSearch: true,
      // 菜单表格树数据
      menuList: [],
      // 菜单树选项
      menuOptions: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 显示状态数据字典
      visibleOptions: [],
      // 菜单状态数据字典
      statusOptions: [],
      //=========================角色菜单
      formMenu: {},
      menuExpand: false,
      menuNodeAll: false,
      menuCheckStrictly: true,
      defaultProps: {
        children: "children",
        label: "label",
      },
    };
  },

  created() {
    this.initData();
  },
  mounted() {
    this.search();
  },
  methods: {
    splitLine(str) {
      if (str && str.includes(",")) {
        return str.replace(/,/g, "<br/>");
      } else return str;
    },

    ShowBtn() {
      this.showBtn = false;
    },
    //初始化页面所需字典等数据
    initData() {
      let _this = this;
      this.getDicts("sys_show_hide").then((response) => {
        this.visibleOptions = response.data;
      });
      this.getDicts("sys_normal_disable").then((response) => {
        this.statusOptions = response.data;
      });
    },
    // tabs change
    handleClick(e) {
      console.log(e);
    },
    //树点击事件
    handleTreeClick(val) {
      console.log(this.activeName1);
      if (this.activeName1 == "second") {
        this.treeCurrentClick = val;
        this.treeCurrentCode = val.moduleCode;
        this.type = val.type;
        //控制按钮是否可以点击
        if (val.type == "1") {
          this.isDisabled = true;
        } else {
          this.isDisabled = false;
          /** 获取该模块下该角色的菜单 */
          let url =
            "/system/eagleRoleMenu/roleMenuTreeselect?moduleCode=" +
            this.treeCurrentClick.roleCode +
            "&roleCode=" +
            this.treeCurrentClick.moduleCode;
          this.http.get(url).then((res) => {
            console.log(res);
            if (res.code == 200) {
              let selectMenus = res.data[0].checkedKeys;
              let resultmenus = res.data[0].menu.filter((item) => {
                if (selectMenus.indexOf(item.menuId) !== -1) {
                  return item;
                }
              });
              this.$nextTick(() => {
                this.menuList = handleTree(resultmenus, "menuId");
                this.loading_menu = false;
              });
            }
          });
        }
      } else {
        this.treeCurrentClick = val;
        this.treeCurrentCode = val.moduleCode;
        this.type = val.type;
        //控制按钮是否可以点击
        if (val.type == "1") {
          this.isDisabled = true;
        } else {
          this.isDisabled = false;
          /** 获取该模块下该角色的菜单 */
          let url =
            "/system/rolePhoneMenu/rolePhoneMenuTreeselect?moduleCode=" +
            this.treeCurrentClick.roleCode +
            "&roleCode=" +
            this.treeCurrentClick.moduleCode;
          this.http.get(url).then((res) => {
            console.log(res);
            if (res.code == 200) {
              let selectMenus = res.data[0].checkedKeys;
              let resultmenus = res.data[0].menu.filter((item) => {
                if (selectMenus.indexOf(item.menuId) !== -1) {
                  return item;
                }
              });
              this.$nextTick(() => {
                this.menuList = handleTree(resultmenus, "menuId");
                this.loading_menu = false;
              });
            }
          });
        }
      }
    },
    //树操作回调事件
    afterhandle(e) {
      console.log(e);
      this.menuList = [];
    },
    //查询
    search() {
      let _this = this;
      setTimeout(() => {
        _this.$refs.EagleTree.geMenuList();
        // _this.$refs.EaglePage.search({
        //     conditions: _this.$refs.EaglePage.getCondtions(
        //         _this.conditionsVals,
        //         _this.conditionsTypes
        //     )
        // });
      }, 1);
      // this.$nextTick(() => {
      // })
    },
    //查询条件重置
    resetQuery() {
      this.conditionsVals.roleName = "";
      this.search();
    },

    afterSave() {
      this.$refs.EagleTree.geMenuList();
    },
    bindData(val) {
      let _this = this;
      setTimeout(() => {
        _this.$refs.EaglePage.search({
          conditions: _this.$refs.EaglePage.getCondtions(
            _this.conditionsVals,
            _this.conditionsTypes
          ),
        });
      }, 1);
    },
    cancel() {
      this.$refs.EagleForm.cancel();
    },
    submitForm() {
      let _this = this;
      let ids = _this.$refs.EaglePage.getSelection().map((x) => x["id"]);
      let url =
        "system/eagleModuleRole/insertDataByIds/" +
        ids +
        "?moduleCode=" +
        this.treeCurrentCode;
      if (ids.length > 0) {
        _this.http.postLoading(_this.loading(), url, {}, function (res) {
          _this.search();
          _this.msgSuccess("保存成功");
          _this.$refs.EagleForm.cancel();
        });
      } else {
        _this.msgError("请选择数据");
      }
    },
    handleRolesImport() {
      let _this = this;

      if (_this.treeCurrentClick && _this.treeCurrentClick.type == "1") {
        let config = {
          title: "角色界面",
          url: _this.controller + "/getPageData",
        };
        _this.$refs.EagleForm.handleAdd(config);
      } else {
        _this.$refs.msgError("请选择模块");
      }
    },
    handleMenusImport() {
      let _this = this;
      if (_this.treeCurrentClick && _this.treeCurrentClick.type == "2") {
        _this.$refs.EagleFormMenu.handleUpdate(null, {
          url:
            "/system/eagleRoleMenu/roleMenuTreeselect?moduleCode=" +
            _this.treeCurrentClick.roleCode +
            "&roleCode=" +
            _this.treeCurrentClick.moduleCode,
          title: "添加菜单",
          callback: function (data) {
            _this.menuOptions = data[0].menus;
            /** 获取该模块下选中角色的角色，菜单列表 */
            let checkedKeys = data[0].checkedKeys;
            checkedKeys.forEach((v) => {
              _this.$nextTick(() => {
                _this.$refs.menu.setChecked(v, true, false);
              });
            });
          },
        });
      } else {
        _this.msgError("请选择模块下的角色");
      }
    },
    handlePhoneMenusImport() {
      let _this = this;
      if (_this.treeCurrentClick && _this.treeCurrentClick.type == "2") {
        _this.$refs.EagleFormPhoneMenu.handleUpdate(null, {
          url:
            "/system/rolePhoneMenu/rolePhoneMenuTreeselect?moduleCode=" +
            _this.treeCurrentClick.roleCode +
            "&roleCode=" +
            _this.treeCurrentClick.moduleCode,
          title: "添加手机菜单",
          callback: function (data) {
            _this.menuOptions = data[0].menus;
            /** 获取该模块下选中角色的角色，菜单列表 */
            let checkedKeys = data[0].checkedKeys;
            checkedKeys.forEach((v) => {
              _this.$nextTick(() => {
                _this.$refs.menu.setChecked(v, true, false);
              });
            });
          },
        });
      } else {
        _this.msgError("请选择手机模块下的角色");
      }
    },

    /** ===============================================菜单相关函数 */
    /** 查询菜单列表 */
    //==================================================角色
    afterSaveMenu() { },
    bindDataMenu(val) {
      this.menuOptions = val.menus;
    },
    submitFormMenu() {
      // let _this = this;
      let url =
        "/system/eagleRoleMenu/updateByRoleId?moduleCode=" +
        this.treeCurrentClick.roleCode +
        "&roleCode=" +
        this.treeCurrentClick.moduleCode;
      this.http.put(url, this.getMenuAllCheckedKeys()).then((res) => {
        let url =
          "/system/eagleRoleMenu/roleMenuTreeselect?moduleCode=" +
          this.treeCurrentClick.roleCode +
          "&roleCode=" +
          this.treeCurrentClick.moduleCode;
        this.http.get(url).then((res) => {
          console.log(res);
          if (res.code == 200) {
            let selectMenus = res.data[0].checkedKeys;
            let resultmenus = res.data[0].menu.filter((item) => {
              if (selectMenus.indexOf(item.menuId) !== -1) {
                return item;
              }
            });
            this.$nextTick(() => {
              this.menuList = handleTree(resultmenus, "menuId");
              this.loading_menu = false;
            });
          }
        });
      });
      this.$refs.EagleFormMenu.cancel();
    },
    cancelMenu() {
      this.$refs.EagleFormMenu.cancel();
    },
    // afterSaveMenu(){

    // },
    // bindDataMenu(val){
    //   this.menuOptions = val.menus;
    // },
    //手机模块保存
    submitFormPhoneMenu() {
      // let _this = this;
      let url =
        "/system/rolePhoneMenu/updateByRolePhoneId?moduleCode=" +
        this.treeCurrentClick.roleCode +
        "&roleCode=" +
        this.treeCurrentClick.moduleCode;
      this.http.put(url, this.getMenuAllCheckedKeys()).then((res) => {
        let url =
          "/system/rolePhoneMenu/rolePhoneMenuTreeselect?moduleCode=" +
          this.treeCurrentClick.roleCode +
          "&roleCode=" +
          this.treeCurrentClick.moduleCode;
        this.http.get(url).then((res) => {
          console.log(res);
          if (res.code == 200) {
            let selectMenus = res.data[0].checkedKeys;
            let resultmenus = res.data[0].menu.filter((item) => {
              if (selectMenus.indexOf(item.menuId) !== -1) {
                return item;
              }
            });
            this.$nextTick(() => {
              this.menuList = handleTree(resultmenus, "menuId");
              this.loading_menu = false;
            });
          }
        });
      });
      this.$refs.EagleFormPhoneMenu.cancel();
    },
    //手机模块关闭
    cancelPhoneMenu() {
      this.$refs.EagleFormPhoneMenu.cancel();
    },

    // 所有菜单节点数据
    getMenuAllCheckedKeys() {
      // 目前被选中的菜单节点
      let checkedKeys = this.$refs.menu.getCheckedKeys();
      // 半选中的菜单节点
      let halfCheckedKeys = this.$refs.menu.getHalfCheckedKeys();
      checkedKeys.unshift.apply(checkedKeys, halfCheckedKeys);
      return checkedKeys;
    },
    // 树权限（展开/折叠）
    handleCheckedTreeExpand(value, type) {
      if (type == "menu") {
        let treeList = this.menuOptions;
        for (let i = 0; i < treeList.length; i++) {
          this.$refs.menu.store.nodesMap[treeList[i].id].expanded = value;
        }
      } else if (type == "dept") {
        let treeList = this.deptOptions;
        for (let i = 0; i < treeList.length; i++) {
          this.$refs.dept.store.nodesMap[treeList[i].id].expanded = value;
        }
      }
    },
    // 树权限（全选/全不选）
    handleCheckedTreeNodeAll(value, type) {
      if (type == "menu") {
        this.$refs.menu.setCheckedNodes(value ? this.menuOptions : []);
      } else if (type == "dept") {
        this.$refs.dept.setCheckedNodes(value ? this.deptOptions : []);
      }
    },
    // 树权限（父子联动）
    handleCheckedTreeConnect(value, type) {
      if (type == "menu") {
        this.menuCheckStrictly = value ? true : false;
      } else if (type == "dept") {
        this.deptCheckStrictly = value ? true : false;
      }
    },
  },
};
</script>

<style scoped>
.title {
  width: 100%;
  height: 50px;
  line-height: 50px;
  text-align: left;
  border-bottom: 1px solid #e6e6e6;
  background-color: #fafafa;
  margin: 5px 0;
  padding-left: 10px;
  font-weight: 600;
}

.importButton {
  padding-top: 180px;
  padding-left: 12px;
}

.div-inline {
  display: inline;
}

.left-content {
  height: 100%;
  padding: 10px;
}

.right-content {
  border-left: 1px solid #d9d9d9;
  height: 100%;
  padding: 10px;
}
</style>
