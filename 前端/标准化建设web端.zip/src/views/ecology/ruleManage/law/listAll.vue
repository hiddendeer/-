<template>
    <div>
        <div class="page-content">
            <block-page v-for="(item,index) in firstTypeList" :title="item.name" :key="index" :childList="item.childList" :searchProject="item.searchProject" :pageData="item.pageData" ref="lawPageList"></block-page>
        </div>
    </div>
</template>

<script>
import blockPage from "./blockPage.vue";
export default {
    components: {
        blockPage
    },
    name: "site-law-all",
    data() {
        return {
            lawTypeList: [],
            firstTypeList: [],
            controller: "ecologyEnv/guidelinelaw"
        };
    },
    created() {},
    mounted() {
        this.search();
    },
    methods: {
        search() {
            this.loading = this.$loading({
                lock: true,
                text: "加载中",
                background: "rgba(0, 0, 0, 0.7)"
            });
            var _this = this;
            var homeSearchResult = [];
            var url = "/" + this.controller + "/getHomePageLaw?pageSize=6";
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "&companyCode=" + enterpriseCode;
            }
            this.http
                .get(url)
                .then(response => {
                    homeSearchResult = response.data.homeSearchResult;
                    if (
                        homeSearchResult != null &&
                        homeSearchResult.length > 0
                    ) {
                        for (var i = 0; i < homeSearchResult.length; i++) {
                            var projects = homeSearchResult[i].projects;
                            var projectModel = {};
                            var childList = [];

                            for (var a = 0; a < projects.length; a++) {
                                if (projects[a].parentId == "-1") {
                                    projectModel.iconUrl = projects[a].iconUrl;
                                    projectModel.id = projects[a].id;
                                    projectModel.name = projects[a].name;
                                    projectModel.orderId = projects[a].orderId;
                                    projectModel.parentId =
                                        projects[a].parentId;
                                    projectModel.projectId =
                                        projects[a].projectId;
                                    projectModel.status = projects[a].status;
                                } else {
                                    childList.push(projects[a]);
                                }
                            }
                            var lawSearchResult =
                                homeSearchResult[i].lawSearchResult;
                            var searchProject =
                                homeSearchResult[i].searchProject;
                            projectModel.searchProject = searchProject;
                            projectModel.pageData = lawSearchResult;
                            projectModel.childList = childList;
                            _this.firstTypeList.push(projectModel);
                        }
                    }
                    this.loading.close();
                })
                .catch(() => {
                    this.loading.close();
                });
        }
    }
};
</script>
<style scoped>
.condition-select {
    margin-left: 2px;
}

.block-page {
    width: 550px;
    margin: 10px;
    display: inline-block;
    border: 1px solid #d9d9d9;
    border-radius: 5px;
}

.block-page-head {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    border-bottom: 1px solid #d9d9d9;
}

.block-page-head-title {
    line-height: 28px;
}
.block-page-content {
    display: flex;
    overflow: overlay;
}
.page-content {
    display: flex;
    flex-wrap: wrap;
}
.left-content {
    width: 190px;
    border-right: 1px solid #d9d9d9;
    height: 100%;
    overflow: overlay;
}
.left-menu-container {
    margin-top: 15px;
    text-align: center;
}

.left-menu-container span {
    width: 125px;
    background: #f6f6f6;
    line-height: 36px;
    border-radius: 18px;
    padding-left: 5px;
    padding-right: 5px;
    display: -moz-inline-box;
    display: inline-block;
    cursor: pointer;
    font-size: 14px;
    margin-bottom: 5px;
    white-space: nowrap; /*内容超宽后禁止换行显示*/
    overflow: hidden; /*超出部分隐藏*/
    text-overflow: ellipsis; /*文字超出部分以省略号显示*/
}

.left-menu-container .selectedProject {
    background: #eaf5ff;
    color: #3998fc;
}

.left-menu-container .deletedProject {
    color: #d5d5d5;
}

.img-op-icon {
    position: absolute;
    top: -5px;
    right: 25px;
}
.right-content {
    height: 100%;
    flex: 1;
}

.page-card {
    display: flex;
    margin-top: 5px;
    width: 100%;
}
.page-card .icon-image {
    width: 48px;
    height: 56px;
}
.card-content {
    flex: 1;
    margin-left: 10px;
}
.card-content-title {
    font-size: 14px;
    color: #333;
    text-align: left;
    line-height: 28px;
    width: 215px; /*定义块元素的宽度*/
    white-space: nowrap; /*内容超宽后禁止换行显示*/
    overflow: hidden; /*超出部分隐藏*/
    text-overflow: ellipsis; /*文字超出部分以省略号显示*/
}
.card-content-sub-title {
    display: flex;
    justify-content: flex-start;
    grid-gap: 25px;
    color: #999;
    line-height: 28px;
}
.card-content-operat {
    line-height: 28px;
    text-align: right;
    width: 60px;
    color: #999;
}
.card-content-operat-icon {
    justify-content: flex-end;
    display: flex;
    grid-gap: 5px;
    font-size: 16px;
}
.card-content-operat-icon i {
    line-height: 28px;
}
.test {
    display: none;
}
/* ::-webkit-scrollbar {
    width: 2px;
    background: #dfdfdf;
}
::-webkit-scrollbar-thumb {
    background-color: #1890ff;
    background-clip: padding-box;
    min-height: 8px;
    border-radius: 10px;
} */
</style>