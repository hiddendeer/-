<template>
    <div class="block-page">
        <div class="block-page-head">
            <div class="block-page-head-title">{{title}}</div>
            <div class="head-nva">
                <el-radio-group v-model="queryParams.dataType" size="mini" @change="onSearch">
                    <el-radio-button label="All">全部</el-radio-button>
                    <el-radio-button label="Law">法律法规</el-radio-button>
                    <el-radio-button label="Standard">标准规范</el-radio-button>
                </el-radio-group>
            </div>
        </div>
        <div class="block-page-content" :style="{'height': '580px'}">
            <div class="left-content">
                <div class="left-menu-container">
                    <div v-for="(child,index) in childList" :key="index" style="position: relative;">
                        <span :title="child.name" @click="changeProject(child)"
                            :class="{selectedProject:isProjectSelected(child)}">{{ child.name }}</span>
                    </div>
                </div>
            </div>
            <div class="right-content">
                <eagle-page :queryParams="queryParams" :showBtn="false" :showHeader="false" :tableHeight="540" :page-size="6"
                    :controller="controller" ref="EaglePage" :showOrder="false" :showCheckColumn="false"
                    layout="prev, pager, next">
                    <template slot="slot-table">
                        <el-table-column align="left">
                            <template slot-scope="scope">
                                <div class="page-card">
                                    <div>
                                        <img class="icon-image" :src="scope.row|getIcon">
                                    </div>
                                    <div class="card-content">
                                        <div class="card-content-title">
                                            <div class="card-content-title-font" @click="viewLaw(scope.row)"
                                                :title="scope.row.artTitle">{{scope.row.artTitle}}</div>
                                            <div class="card-content-operat-icon">
                                                <div style="font-size:20px;">
                                                    <i v-show="scope.row.canCollect=='0'?true:false"
                                                        class="el-icon-star-on" @click="favFile(scope.row)"
                                                        style="cursor:pointer;color:#E6A23C">
                                                    </i>
                                                </div>
                                                <div style="font-size:16px;">
                                                    <i v-show="scope.row.canCollect=='1'?true:false"
                                                        class="el-icon-star-off" @click="favFile(scope.row)"
                                                        style="cursor:pointer;">
                                                    </i>
                                                </div>
                                                <i class="el-icon-delete" @click="delFile(scope.row)"
                                                    style="cursor:pointer">
                                                </i>
                                            </div>
                                        </div>
                                        <div class="card-content-sub-title">
                                            <div>
                                                实施日期:<span>{{ parseTime(scope.row.implementDate, "{y}-{m}-{d}")
                                                }}</span>
                                            </div>
                                            <div>
                                                <!-- <template slot-scope="scope"> -->
                                                <span>{{
                                                scope.row.status == "0" ? "正常" : "失效"
                                                }}</span>
                                                <!-- </template> -->
                                            </div>
                                            <div>{{scope.row.implementLevel}}</div>
                                        </div>
                                    </div>

                                </div>
                            </template>
                        </el-table-column>
                    </template>
                </eagle-page>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    components: {},
    name: "site-law-block-page",
    props: {
        value: {
            type: String | Number,
            default() {
                return "";
            },
        },
        title: {
            type: String,
            default() {
                return "标题";
            },
        },
        childList: {
            type: Array,
            default() {
                return [];
            },
        },
        pageData: {
            type: Object,
            default() {
                return {};
            },
        },
        searchProject: {
            type: Object,
            default() {
                return {};
            },
        },
    },
    data() {
        return {
            selected: "all",
            controller: "ecologyEnv/guidelinelaw",
            parentId: "",
            projectId: "",
            queryParams: { dataType: "" },
            favColor: "",
            classObject: "right-content",
        };
    },
    filters: {
        getIcon: function (item) {
            var implementLevel = item.implementLevel;
            if (implementLevel.indexOf("A") > -1) {
                return require("@/assets/images/file_icon/main_law.png");
            } else if (implementLevel.indexOf("B") > -1) {
                return require("@/assets/images/file_icon/main_regulation.png");
            } else if (implementLevel.indexOf("C") > -1) {
                return require("@/assets/images/file_icon/main_normative.png");
            } else {
                return require("@/assets/images/file_icon/main_standard.png");
            }
        },
        getClass: function (item, projectId, parentId) {
            if (item.projectId == projectId && item.parentId == parentId) {
                return "selectedProject";
            }
        },
        disabledRight: function (childList) {
            // var _this = this;
            // if (childList[0].status == "0") {
            //     return "right-content right-content-dis";
            // } else {
            //     return "right-content";
            // }
        },
    },
    watch: {
        pageData(newVal, oldVal) {
            this.pageData = newVal;
        },
    },
    created() {},
    mounted() {
        var searchProject = this.searchProject;

        this.projectId = searchProject.projectId;
        this.parentId = searchProject.parentId;

        if (!this.queryParams.dataType) {
            this.queryParams.dataType = "All";
        }

        this.$refs.EaglePage.setList({
            list: this.pageData.laws,
            pageNum: 1,
            pageSize: 6,
            total: this.pageData.total,
            url: "site/guidelinelaw/getPageData",
            queryParams: {
                params: {
                    project: this.projectId,
                    pageSize: 6,
                    dataType: this.queryParams.dataType,
                },
            },
        });

        // this.onSearch();
    },
    methods: {
        onSearch() {
            this.queryParams.project = this.projectId;
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                conditions: {},
            });
        },
        changeProject(item) {
            this.projectId = item.projectId;
            this.parentId = item.parentId;
            this.onSearch();
        },
        isProjectSelected(item) {
            return (
                item.projectId == this.projectId &&
                item.parentId == item.parentId
            );
        },
        changeType(dataType) {},
        favFile(row) {
            var _this = this;
            var title = "取消收藏成功";
            var tip = "取消收藏";
            var tempCanCollect = 1;
            var methodName = "cancelCollect";
            if (row.canCollect == "1") {
                methodName = "collect";
                title = "收藏成功";
                tip = "收藏";
                tempCanCollect = 0;
            }
            this.$confirm("确认" + tip + "【" + row.artTitle + "】吗？").then(
                (_) => {
                    var url =
                        "/" +
                        _this.controller +
                        "/" +
                        methodName +
                        "?" +
                        "artIds=" +
                        row.artId;
                    this.httpPost(url, title);
                    row.canCollect = tempCanCollect;
                }
            );
        },
        delFile(row) {
            var _this = this;
            this.$confirm("确认删除【" + row.artTitle + "】吗？").then((_) => {
                var url =
                    "/" +
                    _this.controller +
                    "/deleteLaw?" +
                    "artIds=" +
                    row.artId;
                // this.httpPost(url, "删除成功");
                this.http.post(url).then((response) => {
                    _this.onSearch();
                });
            });
        },
        httpPost(url, title) {
            var _this = this;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                _this.msgSuccess(title);
            });
            // _this.http.post(url).then(response => {
            //     _this.$message({
            //         message: title,
            //         type: "success"
            //     });
            // });
        },
        projectOp(item) {
            var title = "增加项目成功";
            var tip = "增加";
            var tempStatus = 1;
            var methodName = "cancelDeleteProject";
            if (item.status == "1") {
                methodName = "deleteProject";
                title = "删除项目成功";
                tip = "删除";
                tempStatus = 0;
            }
            var _this = this;

            var url =
                "/" +
                _this.controller +
                "/" +
                methodName +
                "?" +
                "id=" +
                item.id;
            this.$confirm("确认" + tip + "【" + item.name + "】吗？").then(
                (_) => {
                    this.httpPost(url, title);
                    item.status = tempStatus;
                }
            );
        },
        viewLaw(row) {
            var url = "http://www.ehsway.com/Article/LawDetailView";
            if (row) {
                url += "?ID=" + row.artId;
                window.open(url);
            }
        },
    },
};
</script>
<style scoped>
.right-content-dis {
    z-index: 9999;
    filter: alpha(Opacity=50);
    -moz-opacity: 0.5;
    opacity: 0.5;
    pointer-events: none;
}

.el-card {
    border: 1px solid #d9d9d9;
}

.el-card__header {
    border-bottom: 1px solid #d9d9d9;
}

.block-page {
    width: 550px;
    margin: 10px;
    display: inline-block;
    border: 1px solid #d9d9d9;
    border-radius: 5px;
}

.block-page-head {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    border-bottom: 1px solid #d9d9d9;
}

.block-page-head-title {
    line-height: 28px;
}

.block-page-content {
    display: flex;
    overflow: overlay;
}

.left-content {
    width: 160px;
    border-right: 1px solid #d9d9d9;
    height: 100%;
    overflow: overlay;
}

.left-menu-container {
    margin-top: 15px;
    text-align: center;
}

.left-menu-container span {
    width: 125px;
    background: #f6f6f6;
    line-height: 28px;
    border-radius: 18px;
    padding-left: 5px;
    padding-right: 5px;
    display: -moz-inline-box;
    display: inline-block;
    cursor: pointer;
    font-size: 14px;
    margin-bottom: 5px;
    white-space: nowrap;
    /*内容超宽后禁止换行显示*/
    overflow: hidden;
    /*超出部分隐藏*/
    text-overflow: ellipsis;
    /*文字超出部分以省略号显示*/
}

.left-menu-container .selectedProject {
    background: #eaf5ff;
    color: #3998fc;
}

.left-menu-container .deletedProject {
    color: #d5d5d5;
}

.img-op-icon {
    position: absolute;
    top: -5px;
    right: 25px;
}

.right-content {
    height: 100%;
    flex: 1;
}

.page-card {
    display: flex;
    margin-top: 5px;
    width: 100%;
}

.page-card .icon-image {
    width: 48px;
    height: 56px;
}

.card-content {
    display: flex;
    margin-left: 10px;
    flex-direction: column;
    width: 100%;
}

.card-content-title {
    display: flex;
    flex-direction: row;
}

.card-content-title div:last-child,
.card-content-sub-title div:last-child {
    margin-left: auto;
    margin-right: 5px;
}

.card-content-title-font {
    width: 230px;
    white-space: nowrap;
    /*内容超宽后禁止换行显示*/
    overflow: hidden;
    /*超出部分隐藏*/
    text-overflow: ellipsis;
    /*文字超出部分以省略号显示*/
    text-align: left;
    cursor: pointer;
}

.card-content-sub-title {
    display: flex;
    justify-content: flex-start;
    grid-gap: 15px;
    color: #999;
    line-height: 28px;
}

.card-content-operat {
    line-height: 28px;
    text-align: right;
    display: flex;
    flex-direction: row;
    white-space: nowrap;
    color: #999;
}

.card-content-operat-icon {
    display: flex;
    flex-direction: row;
    white-space: nowrap;
}

.card-content-operat-icon i {
    line-height: 28px;
}

.test {
    display: none;
}

/* ::-webkit-scrollbar {
    width: 2px;
    background: #dfdfdf;
}
::-webkit-scrollbar-thumb {
    background-color: #1890ff;
    background-clip: padding-box;
    min-height: 8px;
    border-radius: 10px;
} */
</style>