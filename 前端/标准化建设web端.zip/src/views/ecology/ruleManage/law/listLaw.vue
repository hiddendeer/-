<template>
    <div class="layer-law">
        <div class="condition-select">
            <span style="width: 90px;" class="el-form-item__label">筛选条件</span>
            <el-input labelWidth="80px" label="筛选条件" placeholder="请输入关键文字查询" v-model="searchText" size="small"
                style="width: 360px;">
            </el-input>
            <el-button style="margin-left: 8px" type="primary" icon="el-icon-search" size="mini" @click="search()">搜索
            </el-button>
            <el-button style="margin-left: 8px" icon="el-icon-refresh" size="mini" @click="resetSearch()">重置</el-button>
        </div>
        <div class="page-content">
            <div class="div-card-container">
                <el-card shadow="never" class="box-card" :bodyStyle="{ padding: '0px 0px 0px 0px', 'border-top': '0' }">
                    <div slot="header" class="clearfix">
                        <span>全部列表</span>
                        <div style="float: right; padding: 3px 0;">

                            <el-radio-group v-model="selected" @change="changeSearch" size="mini">
                                <el-radio-button label="All">全部</el-radio-button>
                                <el-radio-button label="Law">法律法规</el-radio-button>
                                <el-radio-button label="Standard">标准规范</el-radio-button>
                            </el-radio-group>
                            <!-- <el-button style="margin-left:10px" type="primary" size="mini" @click.stop="exportList()">导出</el-button> -->
                        </div>
                    </div>
                    <div class="text item">
                        <div class="div-card-flex">
                            <div class="div-card-start" :style="{ height: height + 'px', overflow: 'overlay' }">
                                <div :class="item | getClass(imgId)" v-for="(item, index) in firstTypeList"
                                    v-bind:key="index" @click="getSecondType(item)" :title="item.name"
                                    style="cursor: pointer">
                                    <el-tooltip class="item" effect="dark" :content="item.name" placement="right">
                                        <img :src="item.iconUrl" />
                                    </el-tooltip>
                                </div>
                            </div>
                            <div class="div-card-middle" :style="{ height: height + 'px', overflow: 'overlay' }">
                                <div v-for="(item, index) in secondTypeList" v-bind:key="index" class="div-card">
                                    <span @click="changeProject(item)"
                                        :class="{ selectedProject: isProjectSelected(item) }">{{ item.name }}</span>
                                </div>
                            </div>
                            <div class="div-card-end" :style="{ height: height + 'px', overflow: 'hidden' }">
                                <eagle-page :controller="controller" :tableHeight="height - 50" btnWidth="140px"
                                    ref="EaglePage" :style="{
                                        height: height + 'px',
                                        width: '100%',
                                        'margin-bottom': '10px',
                                    }" :showCheckColumn="false" :showBtn="modulesId != 'host'">
                                    <template slot="slot-table">
                                        <el-table-column label="文件名称" prop="artTitle" width="300">
                                            <template slot-scope="scope">
                                                <a style="cursor:pointer;color:#1890FF;" :title="scope.row.artTitle"
                                                    target="_blank" @click.stop="viewLaw(scope.row)">{{
                                                            scope.row.artTitle
                                                    }}</a>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="实施日期" align="left" prop="equipmentName" width="150">
                                            <template slot-scope="scope">
                                                <span>{{ parseTime(scope.row.implementDate, "{y}-{m}-{d}") }}</span>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="执行等级" align="left" prop="implementLevel" width="150" />
                                        <el-table-column label="状态" align="left">
                                            <template slot-scope="scope">
                                                <span>{{
                                                        scope.row.status == "0" ? "正常" : "失效"
                                                }}</span>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="发布部门" prop="equipmentName" width="250">
                                            <template slot-scope="scope">
                                                <span>{{ scope.row.unitName }}</span>
                                            </template>
                                        </el-table-column>

                                    </template>
                                    <template slot="slot-row-buttons" slot-scope="scope">
                                        <el-button size="mini" v-if="scope.row.canCollect == '0'" type="text"
                                            icon="el-icon-edit" @click="handleCancelCollect(scope.row)">取消收藏</el-button>
                                        <el-button size="mini" v-if="scope.row.canCollect == '1'" type="text"
                                            icon="el-icon-edit" @click="handleCollect(scope.row)">收藏</el-button>
                                        <eagle-row-button type="danger" icon="el-icon-delete"
                                            @click.stop="handleDelete(scope.row)">删除</eagle-row-button>
                                        <!-- <el-button size="mini" type="text" icon="el-icon-delete" @click="handleDelete(scope.row)">删除</el-button> -->
                                    </template>
                                </eagle-page>
                            </div>
                        </div>
                    </div>
                </el-card>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    components: {},
    name: "site-law-list",
    props: {
        fkUserId: {
            type: [String],
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            controller: "ecologyEnv/guidelinelaw",
            statistic: {},
            selected: "All",
            queryParams: {},
            firstTypeList: [],
            secondTypeList: [],
            lawTypeList: [],
            height: 0,
            project: "",
            searchText: "",
            imgId: "",
            initCount: 0,
            codeNo: "",
            companyCode: null,
            modulesId: "",
        };
    },
    filters: {
        getClass(item, imgId) {
            if (item.id == imgId) {
                return "isImgSelected";
            } else {
                return "isImgClass";
            }
        },
    },
    created() {
        this.height = window.screen.height - 470;
        this.companyCode = this.$route.query.enterpriseCode;
        this.modulesId = this.$route.meta.modulesId;
    },
    mounted() {
        this.getProjectList();
    },
    methods: {
        /** 新增按钮操作 */
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 收藏操作 */
        handleCollect(row) {
            var _this = this;

            if (row.canCollect == "0") {
                return;
            }
            var url =
                "/" + _this.controller + "/collect?" + "artIds=" + row.artId;
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "&companyCode=" + enterpriseCode;
            }
            this.$confirm("确认收藏【" + row.artTitle + "】吗？").then((_) => {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.msgSuccess("收藏成功！");
                        _this.$emit("afterOperate");
                        row.canCollect = 0;
                    }
                );
            });
        },
        handleCancelCollect(row) {
            var _this = this;
            if (row.canCollect == "1") {
                return;
            }

            this.$confirm("确认取消收藏【" + row.artTitle + "】吗？").then(
                (_) => {
                    var url =
                        "/" +
                        _this.controller +
                        "/cancelCollect?" +
                        "artIds=" +
                        row.artId;
                    let enterpriseCode = this.$route.query.enterpriseCode;
                    if (enterpriseCode) {
                        url += "&companyCode=" + enterpriseCode;
                    }
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            if (res.code == "200") {
                                _this.msgSuccess("取消收藏成功！");
                                _this.$emit("afterOperate");
                                row.canCollect = 1;
                            }
                        }
                    );

                    // _this.http.post(url).then((response) => {
                    //     _this.$message({
                    //         message: "取消收藏成功！",
                    //         type: "success",
                    //     });
                    //     _this.$emit("afterOperate");
                    //     row.canCollect = 1;
                    // });
                }
            );
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            var url =
                "/" + _this.controller + "/deleteLaw?" + "artIds=" + row.artId;
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "&companyCode=" + enterpriseCode;
            }
            this.$confirm("确认删除【" + row.artTitle + "】吗？").then((_) => {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        if (res.code == "200") {
                            _this.msgSuccess("删除成功");
                            _this.$emit("afterOperate");
                            _this.search();
                        }
                    }
                );

                // _this.http.post(url).then((response) => {
                //     _this.$message({
                //         message: "删除成功",
                //         type: "success",
                //     });
                //     _this.$emit("afterOperate");
                //     _this.search();
                // });
            });
        },
        getSecondType(item) {
            var _this = this;
            _this.secondTypeList = [];
            var newList = [];
            _this.imgId = item.id;
            for (var i = 0; i < _this.lawTypeList.length; i++) {
                if (_this.lawTypeList[i].parentId == item.id) {
                    newList.push(_this.lawTypeList[i]);
                }
            }
            _this.secondTypeList = newList;

            _this.project = _this.secondTypeList[0].projectId;
            _this.search();
        },
        changeSearch(dataType) {
            this.dataType = dataType;
            this.search();
        },
        changeProject(item) {
            this.project = item.projectId;
            this.search();
        },
        search() {
            /*this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                )*/
            var _this = this;
            this.queryParams.project = _this.project;
            this.queryParams.dataType = _this.dataType;

            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                this.queryParams.companyCode = enterpriseCode;
            }
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                params: this.queryParams,
                conditions: this.$refs.EaglePage.getCondtions(
                    { artTitle: this.searchText },
                    ["artTitle"]
                ),
            });
        },
        resetSearch() {
            var _this = this;
            _this.searchText = "";
            _this.search();
        },
        isProjectSelected(item) {
            return item.projectId == this.project;
        },
        isImgSelected(item) {
            return item.id == this.imgId;
        },
        getProjectList(fkUserId) {
            var _this = this;
            var url = "/" + this.controller + "/getProjectList";
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "?companyCode=" + enterpriseCode;
            }
            // const loading = this.$loading({
            //     lock: true,
            //     text: "加载中...",
            //     spinner: "el-icon-loading",
            //     background: "rgba(0, 0, 0, 0.7)"
            // });
            this.http
                .get(url)
                .then((response) => {
                    if (response.code == "200") {
                        var lawTypeList = response.data;
                        _this.lawTypeList = lawTypeList;
                        if (lawTypeList != null && lawTypeList.length > 0) {
                            for (var i = 0; i < lawTypeList.length; i++) {
                                if (
                                    lawTypeList[i].parentId == "-1" &&
                                    lawTypeList[i].iconUrl != null &&
                                    lawTypeList[i].iconUrl != ""
                                ) {
                                    _this.firstTypeList.push(lawTypeList[i]);
                                }
                            }

                            var code = _this.firstTypeList[0].id;
                            for (var i = 0; i < lawTypeList.length; i++) {
                                if (lawTypeList[i].parentId == code) {
                                    _this.secondTypeList.push(lawTypeList[i]);
                                }
                            }

                            if (_this.secondTypeList.length > 0) {
                                _this.project =
                                    _this.secondTypeList[0].projectId;
                                _this.search();
                            }
                        }
                        if (_this.lawTypeList.length > 0) {
                            _this.imgId = _this.lawTypeList[0].id;
                        }
                        if (_this.initCount == 0) {
                            _this.$emit("afterOperate");
                            _this.initCount = 1;
                        }
                        // loading.close();
                    }
                })
                .catch(() => { });
        },
        onDeleteProject(item) {
            let _this = this;
            var tempStatus = 0;
            var url = "/" + _this.controller + "/deleteProject?id=" + item.id;
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "&companyCode=" + enterpriseCode;
            }
            this.$confirm("确认删除项目【" + item.name + "】吗？").then((_) => {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        item.status = tempStatus;
                        _this.msgSuccess("删除成功");
                    }
                );

                // _this.http.post(url, {}).then((response) => {
                //     item.status = tempStatus;
                //     _this.$message({
                //         message: "删除成功",
                //         type: "success",
                //     });
                // });
            });
        },
        onAddProject(item) {
            let _this = this;
            var tempStatus = 1;
            var url =
                "/" + _this.controller + "/cancelDeleteProject?id=" + item.id;
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "&companyCode=" + enterpriseCode;
            }
            this.$confirm("确认增加项目【" + item.name + "】吗？").then((_) => {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        item.status = tempStatus;
                        _this.msgSuccess("增加成功");
                    }
                );

                // _this.http.post(url, {}).then((response) => {
                //     item.status = tempStatus;
                //     _this.$message({
                //         message: "增加成功",
                //         type: "success",
                //     });
                // });
            });
        },
        viewLaw(row) {
            var url = "http://www.ehsway.com/Article/LawDetailView";
            if (row) {
                url += "?ID=" + row.artId;
                window.open(url);
            }
            //h
        },
        exportList() {
            var _this = this;
            // var url = "";
            var dataVo = {};

            dataVo.codeNo = this.codeNo;
            dataVo.reportName = "目标职责汇编";
            if (_this.companyCode) {
                dataVo.company_code = _this.companyCode;
            }
            const loading = _this.$loading({
                lock: true,
                text: "文档生成中,请稍后...",
                spinner: "el-icon-loading",
                background: "rgba(0, 0, 0, 0.7)",
            });
            var url =
                "/ecologyEnv/fileToolDataSource/assemblyDoc?parameters=" +
                encodeURI(JSON.stringify(dataVo));
            _this.http
                .post(url)
                .then((res) => {
                    if (res.code == 200) {
                        let row = res.data;
                        _this.viewFile(row, loading);
                    } else {
                        _this.msgError("系统异常");
                    }
                })
                .catch(() => {
                    loading.close();
                });
        },
    },
};
</script>
<style  scoped>
.div-card-container {
    margin-top: 10px;
    margin-left: 9px;
}

.box-card {
    border: 1px solid #f3f3f3;
}

.el-card__header {
    border-bottom: 1px solid #f3f3f3;
    padding: 5px 15px 5px;
}

.el-card__body {
    border-bottom: 1px solid #f3f3f3;
    padding: 0px 0px 0px 0px;
}

.div-card-flex {
    display: flex;
    flex-direction: row;
}

.div-card-start {
    width: 125px;
    flex-direction: column;
    align-items: center;
    grid-gap: 20px;
    border-right: 1px solid #f3f3f3;
    margin-left: 20px;
}

.div-card-start div {
    margin-bottom: 10px;
}

.div-card-start div:first-child {
    margin-top: 10px;
}

.div-card-start img {
    height: 83px;
    width: 83px;
}

.div-card-middle {
    width: 160px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    color: #666666;
    text-align: center;
    border-right: 1px solid #f3f3f3;
    overflow: overlay;
}

.div-card-middle div:first-child {
    margin-top: 10px;
}

.div-card-middle div {
    margin-bottom: 10px;
}

.div-card-middle span {
    width: 130px;
    background: #f6f6f6;
    line-height: 28px;
    border-radius: 18px;
    padding-left: 5px;
    padding-right: 5px;
    display: -moz-inline-box;
    display: inline-block;
    cursor: pointer;
    white-space: nowrap;
    /*内容超宽后禁止换行显示*/
    overflow: hidden;
    /*超出部分隐藏*/
    text-overflow: ellipsis;
    /*文字超出部分以省略号显示*/
}

.div-card-middle .selectedProject {
    background: #eaf5ff;
    color: #3998fc;
}

.div-card-middle .deletedProject {
    color: #d5d5d5;
}

.div-card-end {
    display: flex;
    flex: 3;
}

/* ::-webkit-scrollbar {
    width: 2px;
    background: #dfdfdf;
}
::-webkit-scrollbar-thumb {
    background-color: #1890ff;
    background-clip: padding-box;
    min-height: 8px;
    border-radius: 10px;
} */

.img-op-icon {
    position: absolute;
    top: -5px;
    right: 25px;
}

.div-card {
    position: relative;
}

.isImgSelected {
    background: #eaf5ff;
    padding: 10px;
    margin-right: 20px;
    border-radius: 15px;
}

.isImgClass {
    background: transparent;
    padding: 10px;
    margin-right: 20px;
    border-radius: 15px;
}

.layer-law {
    background: #fff;
    padding-top: 10px;
}
</style>