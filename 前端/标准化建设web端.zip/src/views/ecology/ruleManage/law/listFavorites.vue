<template>
    <div class="app-container">
        <div class="condition-select">
            <el-input labelWidth="80px" label="筛选条件" placeholder="请输入关键文字查询" v-model="artTitle" size="small" clearable
                style="width: 360px; margin-left: 8px;">
            </el-input>
            <el-button style="margin-left: 8px;" type="primary" icon="el-icon-search" size="mini" @click="search()">搜索
            </el-button>
            <el-button style="margin-left: 8px;" icon="el-icon-refresh" size="mini">重置</el-button>
        </div>
        <eagle-page :controller="controller" ref="EaglePage"
            :style="{'width':'100%','margin-bottom':'10px','margin-top':'10px'}">
            <template slot="slot-table">
                <el-table-column label="文件名称" align="left" prop="artTitle" />
                <el-table-column label="实施日期" align="left" prop="equipmentName">
                    <template>
                        <span>暂无</span>
                    </template>
                </el-table-column>
                <el-table-column label="执行等级" align="left" prop="implementLevel" />
                <el-table-column label="状态" align="left">
                    <template slot-scope="scope">
                        <span>{{ scope.row.status=='0'?'正常':'失效'}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="发布部门" align="left" prop="equipmentName">
                    <template>
                        <span>暂无</span>
                    </template>
                </el-table-column>
                <el-table-column label="操作" align="left" class-name="small-padding fixed-width">
                    <template slot-scope="scope">
                        <el-button size="mini" :disabled="scope.row.canCollect=='0'?true:false" type="text"
                            icon="el-icon-edit" @click="handleCollect(scope.row)">收藏</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click="handleDelete(scope.row)">删除
                        </el-button>
                    </template>
                </el-table-column>
            </template>
        </eagle-page>
    </div>
</template>
<script>
export default {
    components: {},
    name: "site-law-fav-list",
    data() {
        return {
            controller: "ecologyEnv/guidelinelaw",
            artTitle: "",
            queryParams: {},
        };
    },
    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        initData() {
            /*默认字典查询条件*/
            let _this = this;
        },
        /** 收藏操作 */
        handleCollect(row) {
            var _this = this;
            this.$confirm("确认取消收藏吗？").then((_) => {
                var url =
                    "/" +
                    _this.controller +
                    "/cancelCollect" +
                    "artIds=" +
                    row.artId;

                _this.http.postLoading(_this.loading(), url, {}, function (res) {
                    _this.msgSuccess("取消成功！");
                    _this.search();
                })

                // _this.http.post(url).then((response) => {
                //     _this.$message({
                //         message: "取消成功！",
                //         type: "success",
                //     });
                //     _this.search();
                // });
            });
        },

        search() {
            var _this = this;

            this.queryParams.dataType = "MyFavorite";
            this.queryParams.project = "0";

            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                params: this.queryParams,
                conditions: {},
            });
        },
    },
};
</script>