<template>
    <div class="app-container law-index">
        <!-- <div class="layer"> -->
        <div class="app-head">
            <eagle-head-card title="适用法律法规" :value="statistic.lawQty" bgColor="linear-gradient(135deg, #7ba7ff, #6696f7)">
                <i class="el-icon-s-order"></i>
            </eagle-head-card>
            <eagle-head-card title="适用标准规范" :value="statistic.standardQty" bgColor="linear-gradient(135deg, #82dbb8,#65daac)">
                <i class="el-icon-s-order"></i>
            </eagle-head-card>
            <eagle-head-card title="我的收藏" :value="statistic.myFavoriteQty" bgColor="linear-gradient(135deg, #ffcd50, #f5bf39)">
                <i class="el-icon-s-order"></i>
            </eagle-head-card>
        </div>
        <div class="app-tab">
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <!-- <el-tab-pane label="全部适用法律法规" name="law">
                    <list-all :fkUserId="fkUserId" ref="listAll"></list-all>
                </el-tab-pane> -->
                <el-tab-pane label="全部列表" name="list">
                    <list-law :fkUserId="fkUserId" ref="listLaw" @afterOperate="afterOperate"></list-law>
                </el-tab-pane>
                <el-tab-pane label="我的收藏" name="save">
                    <list-fav v-if="activeName=='save'" :fkUserId="fkUserId" dataType="MyFavorite" ref="listLawFavorite" @afterOperate="afterOperate"></list-fav>
                </el-tab-pane>
                <el-tab-pane label="我删除的清单" name="deletes">
                    <list-fav v-if="activeName=='deletes'" :fkUserId="fkUserId" dataType="MyDeleted" ref="listLawDeleted" @afterOperate="afterOperate"></list-fav>
                </el-tab-pane>
            </el-tabs>
        </div>
        <!-- </div> -->
    </div>

</template>
<script>
import ListAll from "./listAll.vue";
import ListLaw from "./listLaw.vue";
import ListFav from "./listFavOrDel";

export default {
    name: "Law",
    components: {
        ListAll,
        ListLaw,
        ListFav,
    },
    data() {
        return {
            activeName: "list",
            key: "",
            controller: "ecologyEnv/guidelinelaw",
            fkUserId: "",
            statistic: {},
        };
    },
    created() {},
    mounted() {
        //this.$refs.listAll.search();
        // this.$refs.listLaw.getProjectList();
        // this.$refs.listLawFavorite.search();
        // this.$refs.listLawDeleted.search();
        //  this.getStatistic();
    },
    methods: {
        handleClick(tab, event) {},
        // initLawUserInfo() {
        //     //site/guidelinelaw/init
        //     var _this = this;
        //     var url = "/" + this.controller + "/init/";
        //     this.http.get(url).then((response) => {
        //         this.getStatistic();
        //     });
        // },
        getStatistic() {
            var _this = this;
            var url = "/" + this.controller + "/getStatistic";
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                url += "?companyCode=" + enterpriseCode;
            }
            // if(enterpriseCode){
            //     url+=""
            // }
            // const loading = this.$loading({
            //     lock: true,
            //     text: "加载中...",
            //     spinner: "el-icon-loading",
            //     background: "rgba(0, 0, 0, 0.7)",
            // });
            this.http
                .get(url)
                .then((response) => {
                    this.statistic = response.data;
                    //loading.close();
                })
                .catch(() => {
                    //loading.close();
                });
        },
        afterOperate() {
            this.getStatistic();
        },
    },
};
</script>
<style lang="scss" scoped>
.app-head {
    display: flex;
    flex-direction: row;
    // align-items: center;
    // justify-content: center;
}
.law-index {
    background: #fff;
    padding: 10px;
}
// .titel-tag {
//     margin: 8px;
//     background-color: antiquewhite;
//     padding: 8px;
//     border-radius: 4px;
//     .el-icon-document,
//     .el-icon-s-cooperation,
//     .el-icon-star-on,
//     .el-icon-delete-solid {
//         width: 46px;
//         height: 46px;
//         font-size: 36px;
//     }
//     .number {
//         font-size: 36px;
//         margin-left: 8px;
//     }
//     .word {
//         font-size: 16px;
//         margin-left: 8px;
//     }
// }
// .app-tab {
//     margin: 8px;
//     .condition-select {
//         display: flex;
//         flex-direction: row;
//         align-items: center;
//         justify-content: center;
//     }
// }
</style>