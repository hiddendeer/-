<template>
    <div class="app-container">
        <div class="condition-select">
            <el-row>
                <el-col :span="24">
                    <el-input labelWidth="80px" label="筛选条件" placeholder="请输入关键文字查询" v-model="searchText" size="small"
                        clearable style="width: 360px; margin-left: 8px">
                    </el-input>
                    <el-button style="margin-left: 8px" type="primary" icon="el-icon-search" size="mini"
                        @click="search()">搜索</el-button>
                    <el-button style="margin-left: 8px" icon="el-icon-refresh" size="mini" @click="resetSearch()">重置
                    </el-button>
                </el-col>
            </el-row>
            <el-row style="margin-top: 10px">
                <el-col :span="24">
                    <el-button style="margin-left: 8px" type="primary" v-show="dataType == 'MyFavorite' ? true : false"
                        size="mini" @click="favMore()">批量取消收藏</el-button>
                    <el-button style="margin-left: 8px" type="primary" v-show="dataType == 'MyDeleted' ? true : false"
                        size="mini" @click="delMore()">批量取消删除</el-button>
                </el-col>
            </el-row>
        </div>
        <eagle-page :queryParams="queryParams" selectField="artId" :controller="controller" ref="EaglePage" btnWidth="120"
            :style="{ width: '100%', 'margin-bottom': '10px', 'margin-top': '10px' }">
            <template slot="slot-table">
                <el-table-column label="文件名称" prop="artTitle">
                    <template slot-scope="scope">
                        <a style="cursor:pointer;color:#1890FF;" :title="scope.row.artTitle" target="_blank"
                            @click.stop="viewLaw(scope.row)">{{ scope.row.artTitle }}</a>
                    </template>
                </el-table-column>
                <el-table-column label="实施日期" align="left" prop="equipmentName">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.implementDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="执行等级" align="left" prop="implementLevel" />
                <el-table-column label="状态" align="left">
                    <template slot-scope="scope">
                        <span>{{ scope.row.status == "0" ? "正常" : "失效" }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="发布部门" prop="equipmentName">
                    <template slot-scope="scope">
                        <span>{{ scope.row.unitName }}</span>
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <el-button size="mini" v-show="dataType == 'MyDeleted' ? true : false" type="text"
                    @click="handleCancelDelete(scope.row)">取消删除</el-button>
                <el-button size="mini" v-show="dataType == 'MyFavorite' ? true : false" type="text"
                    @click="handleCancelCollect(scope.row)">取消收藏</el-button>
            </template>
        </eagle-page>
    </div>
</template>
<script>
export default {
    components: {},
    name: "site-law-fav-list",
    data() {
        return {
            controller: "ecologyEnv/guidelinelaw",
            artTitle: "",
            searchText: "",
            queryParams: {}
        };
    },
    props: {
        dataType: {
            type: [String],
            default() {
                return "";
            }
        }
    },
    created() {
        this.initData();
    },
    mounted() {
        // debugger;
        this.search();
    },
    methods: {
        initData() {
            /*默认字典查询条件*/
            let _this = this;
        },
        /** 收藏操作 */
        handleCancelCollect(row) {
            var _this = this;
            _this.onCancelCollect(row.artId, row.artTitle);
        },
        onCancelCollect(artId, artTitle) {
            var tipHtml = "确认取消收藏选中的数据吗？";
            if (artTitle) {
                tipHtml = "确认取消收藏【" + artTitle + "】吗？";
            }
            var _this = this;
            if (!artId) {
                return;
            }
            this.$confirm(tipHtml).then(_ => {
                var url =
                    "/" +
                    _this.controller +
                    "/cancelCollect?" +
                    "artIds=" +
                    artId;
                let enterpriseCode = this.$route.query.enterpriseCode;
                if (enterpriseCode) {
                    url += "&companyCode=" + enterpriseCode;
                }
                _this.http.postLoading(_this.loading(), url, {}, function (res) {
                    _this.msgSuccess("取消收藏成功！");
                    _this.$emit("afterOperate");
                    _this.search();
                });

                // _this.http.post(url).then(response => {
                //     _this.$message({
                //         message: "取消收藏成功！",
                //         type: "success"
                //     });
                //     _this.$emit("afterOperate");
                //     _this.search();
                // });
            });
        },
        favMore() {
            var _this = this;
            var artIds = this.getSelected();
            if (!artIds) {
                return;
            }
            _this.onCancelCollect(artIds);
        },
        handleCancelDelete(row) {
            var _this = this;
            var artIds = row.artId;
            _this.onDelete(artIds, row.artTitle);
        },
        onDelete(artIds, artTitle) {
            var tipHtml = "确认取消删除选中的数据吗？";
            if (artTitle) {
                tipHtml = "确认取消删除【" + artTitle + "】吗？";
            }

            var _this = this;
            if (!artIds) {
                return;
            }
            this.$confirm(tipHtml).then(_ => {
                var url =
                    "/" +
                    _this.controller +
                    "/cancelDeleteLaw?" +
                    "artIds=" +
                    artIds;
                let enterpriseCode = this.$route.query.enterpriseCode;
                if (enterpriseCode) {
                    url += "&companyCode=" + enterpriseCode;
                }
                _this.http.postLoading(_this.loading(), url, {}, function (res) {
                    _this.msgSuccess("取消删除成功！");
                    _this.search();
                    _this.$emit("afterOperate");
                });

                // _this.http.post(url).then(response => {
                //     _this.$message({
                //         message: "取消删除成功！",
                //         type: "success"
                //     });
                //     _this.search();
                //     _this.$emit("afterOperate");
                // });
            });
        },
        delMore() {
            var _this = this;
            var artIds = this.getSelected();
            if (!artIds) {
                return;
            }
            _this.onDelete(artIds);
        },
        search(fkUserId) {
            var _this = this;
            this.queryParams.dataType = _this.dataType;
            this.queryParams.project = "0";
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                this.queryParams.companyCode = enterpriseCode;
            }

            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                conditions: this.$refs.EaglePage.getCondtions(
                    { artTitle: this.searchText },
                    ["artTitle"]
                )
            });
        },
        resetSearch() {
            var _this = this;
            _this.searchText = "";
            _this.search();
        },
        getSelected() {
            var selections = this.$refs.EaglePage.getSelection();
            if (selections.length == 0) {
                this.msgError("请先选择数据项");
                return false;
            }
            var arryCodes = [];
            selections.forEach(element => {
                arryCodes.push(element.artId);
            });
            return arryCodes.join(",");
        },
        viewLaw(row) {
            var url = "http://www.ehsway.com/Article/LawDetailView";
            if (row) {
                url += "?ID=" + row.artId;
                window.open(url);
            }
            //http://www.ehsway.com/Article/LawDetailView?ID=68347
        }
    }
};
</script>