<!--<template>-->
<!--    <div class="app-container">-->
<!--        <div>-->
<!--            <div>规章制度</div>-->
<!--            <div>机构与职责</div>-->
<!--        </div>-->
<!--        <div>-->
<!--            <eagle-condition @search="search()" @resetQuery="resetQuery()">-->
<!--                <eagle-input label-width="120px" label="模板名称" @changeEnter="search()" :required="false" prop="name" v-model="conditionsVals.name.value" placeholder="请输入使用部门" clearable size="small" />-->
<!--            </eagle-condition>-->
<!--            <eagle-page :controller="controller" ref="EaglePage" :showCheckColumn="false">-->
<!--                <template slot="slot-buttons">-->
<!--                    <el-row :gutter="10" class="mb8">-->
<!--                        <el-col :span="1.5">-->
<!--                            <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增</el-button>-->
<!--                        </el-col>-->
<!--                    </el-row>-->
<!--                </template>-->
<!--                <template slot="slot-table">-->
<!--                    <el-table-column label="模板名称" prop="name" width="200" />-->
<!--                    <el-table-column label="修改日期"  align="left" prop="createDate" width="100">-->
<!--                        <template slot-scope="scope">-->
<!--                            <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d}") }}</span>-->
<!--                        </template>-->
<!--                    </el-table-column>-->
<!--                    <el-table-column label="修改人"  align="left" prop="createChnName" width="100" />-->
<!--                </template>-->
<!--                <template slot="slot-row-buttons" slot-scope="scope">-->
<!--                    <eagle-row-button icon="el-icon-edit" @click="handleUpdate(scope.row)">编辑</eagle-row-button>-->
<!--                    <eagle-row-button type="danger" icon="el-icon-delete" @click="handleDelete(scope.row)">删除</eagle-row-button>-->
<!--                </template>-->
<!--            </eagle-page>-->
<!--        </div>-->
<!--    </div>-->
<!--</template>-->

<!--<script>-->
<!--export default {-->
<!--    components: {-->
<!--        controller: "site/fileOnlineTemp", //对应后端控制器-->
<!--        conditions: {},-->
<!--        queryParams: {-->
<!--            dataType: "list",-->
<!--        },-->
<!--    },-->
<!--    name: "FileOnlineTemp",-->
<!--    data() {},-->
<!--    created() {},-->
<!--    mounted() {},-->
<!--    methods: {-->
<!--        handleDelete(row) {-->
<!--            var _this = this;-->
<!--            this.$refs.EaglePage.handleDelete(row, function (res) {-->
<!--                _this.refresh();-->
<!--            });-->
<!--        },-->
<!--    },-->
<!--};-->
<!--</script>-->
