<template>
    <div class="div-host-ent-safety">
        <!-- 安全附件登记 -->
        <eagle-dialog ref="EagleDialog" title="安全附件登记" width="1000px" show-close :close-on-click-modal="clickModal" @close="closeModal">
             <eagle-block border title="设备详情">
                <el-form label-width="80px">
                    <el-row>
                        <el-col :span="12">
                            <eagle-text label="设备型号">{{ newDetails.equipmentModel || "无" }}</eagle-text>
                        </el-col>
                        <el-col :span="12">
                            <eagle-text label="设备名称">{{ newDetails.equipmentName || "无" }}</eagle-text>

                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-text label="所在区域">{{ newDetails.locationName || "无" }}</eagle-text>
                        </el-col>
                    </el-row>
                </el-form>
            </eagle-block>
             <eagle-block class="mt10" border>
                <div slot="header" class="clearfix">
                    <span> 安全附件</span>
                    <el-button style="float:right;" @click="attachHandleAdd" type="primary" size="mini">新增
                    </el-button>
                </div>
                <el-table ref="multipleTable" :data="secureAttachmentList" tooltip-effect="dark" style="width: 100%" height="300">
                    <el-table-column label="序号" type="index" align="left" width="50">
                    </el-table-column>
                    <el-table-column prop="name" align="left" label="附件名称" show-overflow-tooltip width="160">
                    </el-table-column>
                    <el-table-column prop="count" align="left" label="数量" show-overflow-tooltip width="60">
                    </el-table-column>
                    <el-table-column align="left" label="下次检测日期" show-overflow-tooltip width="120">
                        <template slot-scope="scope">{{ parseTime(scope.row.nextCheckDate, "{y}-{m}-{d}")
                        }}</template>
                    </el-table-column>
                    <el-table-column align="left" label="安全附件检测预警" show-overflow-tooltip width="180">
                        <template slot-scope="scope">
                            <span> {{ parseTime(scope.row.nextCheckDate, "{y}-{m}-{d}") }}</span>
                            <div v-if="scope.row.nextCheckDate" v-html="getSuplusDate(scope.row.nextCheckDate)">
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column label="维保信息" align="left" prop="maintenanceFrequency" width="140px">
                        <template slot-scope="scope">
                            <eagle-row-button type="primary" @click="maintenance(scope.row)">维保
                            </eagle-row-button>
                            <span style="line-height: 24px;">({{ scope.row.counts != '' ? scope.row.counts : 0 }})次</span>
                        </template>
                    </el-table-column>

                    <el-table-column fixed="right" label="操作" align="left" width="180">
                        <template slot-scope="scope">
                            <eagle-row-button type="primary" size="mini" @click="editorAttach(scope.row)">编辑
                            </eagle-row-button>
                            <eagle-row-button type="danger" size="mini" @click="deleteAttach(scope.row)">删除
                            </eagle-row-button>
                        </template>
                    </el-table-column>
                    <template slot="empty">
                        <el-empty description="暂无数据"></el-empty>
                    </template>
                </el-table>
            </eagle-block>
            <!-- </el-card> -->

            <!-- <el-dialog title="检测信息" v-if="setTrainImpleVisible" :visible.sync="setTrainImpleVisible" width="25%" append-to-body show-close :close-on-click-modal="false">
                <el-form ref="formInline" :rules="rules" :model="attacHandleForm">
                    <el-form-item label="附件名称:" prop="name" label-width="125px">
                        <el-input placeholder="请输入附件名称" v-model="attacHandleForm.name" auto-complete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="下次检测日期:" prop="nextCheckDate" label-width="125px">
                        <el-date-picker v-model="attacHandleForm.nextCheckDate" type="date" :clearable="true" auto-complete="off" placeholder="选择日期">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item>
                        <div style="text-align: center">
                            <el-button type="primary" @click="submitAttach()">保存</el-button>
                            <el-button class="buttonText" @click="cancelAttach">取消</el-button>
                        </div>
                    </el-form-item>
                </el-form>
            </el-dialog> -->
        </eagle-dialog>

        <!-- // haiwood fix -->
        <eagle-form controller="site/attach" title="安全附件" :form="attacHandleForm" width="800px" label-width="120px" ref="EagleForm" @bindData="bindDataAttachInfo" @afterSave="afterSaveAttachInfo">
             <eagle-block border>
                <el-form-item label="附件名称:" prop="name" label-width="125px">
                    <el-input placeholder="请输入附件名称" v-model="attacHandleForm.name" auto-complete="off"></el-input>
                </el-form-item>

                <el-form-item label="数量:" prop="count" label-width="125px">
                    <el-input-number v-model="attacHandleForm.count" :min="1"></el-input-number>
                </el-form-item>
                <el-form-item label="下次检测日期:" prop="nextCheckDate" label-width="125px">
                    <el-date-picker v-model="attacHandleForm.nextCheckDate" type="date" :clearable="true" auto-complete="off" placeholder="选择日期">
                    </el-date-picker>
                </el-form-item>
            </eagle-block>
        </eagle-form>

        <safety-attachs-maintenance-dialog ref="safetyAttachsMaintenanceDialog" @afterSave="afterSaveInfo">
        </safety-attachs-maintenance-dialog>
    </div>
</template>
<script>
// import { handleTree } from "@/utils/EageleRMC";
import safetyAttachsMaintenanceDialog from "./safetyAttachs-maintenance-dialog.vue";
import { Message, MessageBox } from "element-ui";
export default {
    components: { safetyAttachsMaintenanceDialog },

    name: "host-ent-safety",
    props: {
        title: { type: String, default: "" },
        clickModal: { type: Boolean, default: false },
    },
    data() {
        return {
            trainImpleVisible: false,
            setTrainImpleVisible: false,
            newDetails: {},
            attacHandleForm: {},
            queryParams: {},
            attacHandleTitle: "",
            secureAttachmentList: [],
            rules: {
                name: [
                    {
                        required: true,
                        message: "请输入附件名称",
                        trigger: "blur",
                    },
                ],
                nextCheckDate: [
                    {
                        required: true,
                        message: "请选择下次检测日期",
                        trigger: "blur",
                    },
                ],
            },
        };
    },
    created() {},
    mounted() {},
    methods: {
        //安全附件删除
        deleteAttach(val) {
            let _this = this;
            this.$confirm("是否确认删除?", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(() => {
                    var url = "ecologyEnv/attach/deleteByCode/" + val.code;
                    _this.http.delLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.getAttacHandleFormList();
                            _this.msgSuccess("删除成功");
                        }
                    );

                    // this.http.del(url + val.code).then(res => {
                    //     if (res.code == "200") {
                    //         this.$message({
                    //             message: "删除成功",
                    //             type: "success"
                    //         });
                    //         this.getAttacHandleFormList();
                    //     } else {
                    //         this.$message({
                    //             message: "删除失败",
                    //             type: "warning"
                    //         });
                    //     }
                    // });
                })
                .catch(() => {});
        },
        editorAttach(row) {
            this.attacHandleTitle = "编辑";
            // this.setTrainImpleVisible = true;
            // let editObj = Object.assign({}, row);
            // this.attacHandleForm = editObj;

            let config = {
                title: "编辑检测信息",
            };
            this.$refs.EagleForm.handleUpdate(row, config);
        },
        // haiwood fix
        attachHandleAdd() {
            // this.attacHandleForm = {};
            // this.setTrainImpleVisible = true;
            // this.attacHandleForm.companyCode = this.$route.query.enterpriseCode??"";
            let config = {
                title: "检测信息",
                params: {
                    mainCode: this.queryParams.mainCode,
                },
            };
            this.$refs.EagleForm.handleAdd(config);
        },
        // haiwood add
        bindDataAttachInfo(val) {
            this.attacHandleForm = val;
            // this.attacHandleForm.mainCode = this.queryParams.mainCode;
        },
        // haiwood add
        afterSaveAttachInfo() {
            this.getAttacHandleFormList();
        },
        submitAttach() {
            let _this = this;
            if (
                _this.attacHandleForm.name &&
                _this.attacHandleForm.nextCheckDate
            ) {
                _this.setTrainImpleVisible = false;
                var url = "/ecologyEnv/attach/save";
                _this.http
                    .post(url, _this.attacHandleForm)
                    .then((response) => {
                        _this.msgSuccess("保存成功");
                        _this.getAttacHandleFormList();
                    })
                    .catch((e) => {});
            } else {
                this.$message({
                    message: "请填写附件信息",
                    type: "warning",
                });
            }
        },
        show(config) {
            var _this = this;
            if (config) {
                _this.newDetails.equipmentName = config.equipmentName;
                _this.newDetails.equipmentModel = config.equipmentModel;
                _this.queryParams.mainCode = config.mainCode;
                _this.newDetails.locationName = config.locationName;
                _this.newDetails.mainCode = config.mainCode;
                _this.getAttacHandleFormList();
            }
            setTimeout(() => {
                this.$refs.EagleDialog.show();
                // this.search();
            });
            // this.trainImpleVisible = true;
        },
        cancelAttach() {
            this.setTrainImpleVisible = false;
        },
        //安全附件查询列表
        getAttacHandleFormList() {
            let _this = this;
            let companyCode = this.$route.query.enterpriseCode ?? "";
            // var url =
            //     "site/attach/getListData?mainCode=" + this.queryParams.mainCode+"&companyCode="+companyCode;

            // haiwood fix (eg: getListData 不适用)
            var url = "ecologyEnv/attach/getAttachList";
            this.http
                .get(url, {
                    mainCode: this.queryParams.mainCode,
                    companyCode: companyCode,
                })
                .then((res) => {
                    this.secureAttachmentList = res.data;
                });

            // _this.http.postLoading(
            //     _this.loading(),
            //     url,
            //     _this.queryParams,
            //     function(res) {
            //         _this.secureAttachmentList = res.data;
            //     }
            // );
        },
        getSuplusDate(deadline) {
            var now = new Date();
            let day = 0;
            day = this.getDaysBetween(now, deadline);
            if (day >= 0) {
                var color = "#1990FE";
                if (day < 30) {
                    color = "#E6A23C";
                }
                return `<span style='color:${color}'>还剩${day}天</span>`;
            } else {
                return `<span style='color:#F56C6C'>逾期${day * -1}天</span>`;
            }
        },
        getDaysBetween(date1, date2) {
            date2 = date2.replace(/-/g, "/");
            var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));
            var endDate = Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
        closeModal() {
            this.$emit("afterSave");
        },
        afterSaveInfo() {
            this.getAttacHandleFormList();
        },
        //维保信息
        maintenance(row) {
            var _this = this;
            var config = {};
            config.name = row.name;
            config.nextCheckDate = row.nextCheckDate;
            config.code = row.code;
            config.mainCode = row.mainCode;
            _this.$refs.safetyAttachsMaintenanceDialog.show(config);
        },
    },
};
</script>
<style lang="scss" scoped>
.div-host-ent-safety {
    span {
        line-height: 28px;
    }

    .div_title {
        text-align: right;
        padding-right: 10px;

        span {
            font-size: 14px;
            color: #606266;
            font-weight: 700;
        }
    }
}

.div-table ::v-deep.el-card__body {
    padding: 0px 0px;
}

.setFontWeight {
    font-weight: 900;
}
</style>
