<template>
    <div class="div-host-ent-maintenance-dialog">
        <el-dialog class="div-host-ent-maintenance-dialog" ref="EagleDialog" v-dialogDrag :title="title" :visible.sync="setMaintenance" width="1000px" show-close :close-on-click-modal="false" @close="closeModal">
            <eagle-block border title="设备详情">
                <el-form size="small">
                    <el-row>
                        <el-col :span="12">
                            <eagle-text label="设备型号">{{ basicInformation.equipmentModel || "无" }}</eagle-text>
                        </el-col>
                        <el-col :span="12">
                            <eagle-text label="设备名称">{{ basicInformation.equipmentName || "无" }}</eagle-text>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-text label="所在区域">{{ basicInformation.locationName || "无" }}</eagle-text>
                        </el-col>
                        <el-col :span="12">
                            <eagle-text label="频次">{{ basicInformation.maintenanceFrequencyName || "无" }}</eagle-text>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <eagle-text label="维保事项">{{ basicInformation.maintenanceAttention || "无" }}</eagle-text>
                        </el-col>
                    </el-row>
                </el-form>
            </eagle-block>
            <el-form ref="formPage" :model="formInline" label-width="120px">
                <eagle-block class="mt10" border title="设备维保登记">
                    <el-row>
                        <el-col :span="12">
                            <eagle-date label="维保日期" required v-model="formInline.maintenanceDate" @change="addDateChange($event)"></eagle-date>
                        </el-col>
                        <el-col :span="12">
                            <eagle-input prop="maintenanceChnName" label="维保人" required v-model="formInline.maintenanceChnName"></eagle-input>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-date label="下次维保日期" v-model="formInline.nextMaintenanceDate"></eagle-date>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="22">
                            <eagle-input type="textarea" :rows="5" prop="maintenanceContent" label="维保事项" required v-model="formInline.maintenanceContent"></eagle-input>
                        </el-col>
                        <el-col :span="2">
                            <el-button type="text" :plain="false" class="enterprise_btn" @click.stop="openmaintenanceTemp">选择</el-button>
                            <!-- <eagle-row-button type="text" :plain="false" @click.stop="openmaintenanceTemp">选择</eagle-row-button> -->
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <eagle-input type="textarea" prop="remarks" label="备注" v-model="formInline.remarks">
                            </eagle-input>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <eagle-image label="维保图片" v-model.trim="formInline.attach" prop="attach"></eagle-image>
                        </el-col>
                    </el-row>

                    <!-- <el-row style="text-align:right;">
                        <el-button type="primary" size="mini" @click="addMaintenance">保存</el-button>
                    </el-row> -->
                </eagle-block>
            </el-form>

            <eagle-block class="mt10" border title="历史维保记录">
                <!-- <div slot="header" class="clearfix">
                    <span class="setFontWeight"><i class="el-icon-s-grid"></i>历史维保记录</span>
                </div> -->
                <eagle-page :queryParams="queryParams" :tableHeight="260" :show-check-column="false" :controller="detailController" ref="EaglePage">
                    <template slot="slot-table">
                        <el-table-column label="维保日期" align="left" width="120">
                            <template slot-scope="scope">{{ parseTime(scope.row.maintenanceDate, "{y}-{m}-{d}")
                            }}</template>
                        </el-table-column>
                        <el-table-column prop="maintenanceChnName" align="left" label="维保人" width="100">
                            <template slot-scope="scope">
                                <template>
                                    <span :title="scope.row.maintenanceChnName">{{
                                    ellipsis(scope.row.maintenanceChnName, 18)
                                    }}</span>
                                </template>
                            </template>
                        </el-table-column>
                        <el-table-column prop="maintenanceContent" align="left" label="维保内容" width="450">
                            <template slot-scope="scope">
                                <template>
                                    <span :title="scope.row.maintenanceContent">{{
                                    ellipsis(scope.row.maintenanceContent, 25)
                                    }}</span>
                                </template>
                            </template>
                        </el-table-column>
                        <el-table-column label="维保图片" prop="attach" width="100px">
                            <template slot-scope="scope">
                                <template>
                                    <eagle-row-image v-model="scope.row.attach"></eagle-row-image>
                                </template>
                            </template>
                        </el-table-column>
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button type="primary" @click="editorMaintenance(scope.row)">编辑
                        </eagle-row-button>
                        <eagle-row-button type="danger" @click="deleteMaintenance(scope.row)">删除
                        </eagle-row-button>
                    </template>
                </eagle-page>
            </eagle-block>

            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="mini" @click="addMaintenance">保存</el-button>
                <el-button @click="shutDownMaintenance">关闭</el-button>
            </div>
        </el-dialog>

        <!-- haiwood add -->
        <eagle-form :controller="detailController" :title="title" :form="newFormInline" width="800px" label-width="120px" ref="EagleForm" @afterSave="afterSaveAttachMaintenanceInfo" @bindData="bindDataAttachMaintenanceInfo">
             <eagle-block border>
                <el-row>
                    <el-col :span="12">
                        <eagle-date prop="maintenanceDate" label="维保日期" required v-model="newFormInline.maintenanceDate" @change="editDateChange($event)"></eagle-date>
                    </el-col>
                    <el-col :span="12">
                        <eagle-input prop="maintenanceChnName" label="维保人" required v-model="newFormInline.maintenanceChnName"></eagle-input>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <eagle-date label="下次维保日期" v-model="newFormInline.nextMaintenanceDate"></eagle-date>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="22">
                        <eagle-input type="textarea" :rows="5" prop="maintenanceContent" label="维保事项" :required="true" v-model="newFormInline.maintenanceContent"></eagle-input>
                    </el-col>
                    <el-col :span="2">
                        <el-button type="text" id="selectEdit" @click.stop="openmaintenanceTemp($event)">选择
                        </el-button>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <eagle-input label="备注" v-model="newFormInline.remarks"></eagle-input>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <eagle-image label="维保图片" v-model.trim="newFormInline.attach" prop="attach"></eagle-image>
                    </el-col>
                </el-row>
            </eagle-block>
        </eagle-form>

        <equipment-maintenance-dialog ref="equipmentMaintenance" @submit="handleMaintenanceSubmit">
        </equipment-maintenance-dialog>
    </div>
</template>

<script>
import equipmentMaintenanceDialog from "@/views/host/components/equipment/equipmentMaintenanceDialog.vue";
import { addMonth, addDate } from "@/utils/dateUtil";
export default {
    name: "host-ent-maintenance-dialog",
    components: { equipmentMaintenanceDialog },
    props: {
        title: {
            type: String,
            default() {
                return "设备维保信息";
            },
        },
    },
    data() {
        return {
            setMaintenance: false,
            editorMainDate: false,
            basicInformation: {},
            formInline: {
                maintenanceContent: "",
            },
            newFormInline: {},
            tableData: [],
            editorMain: "编辑设备维保信息",
            //分页设置
            total: 100,
            pagesize: 5, //每页的数据条数
            currentPage: 1, //默认开始页面
            queryParams: {},
            detailController: "ecologyEnv/maintenance",
            maintenanceContent: "",
            selectButton: "", //区分点击的选择是哪个按钮
        };
    },
    created() {},
    mounted() {},
    methods: {
        show(config) {
            var _this = this;
            if (config) {
                _this.basicInformation.equipmentModel = config.equipmentModel;
                _this.basicInformation.equipmentName = config.equipmentName;
                _this.basicInformation.locationName = config.locationName;
                _this.basicInformation.maintenanceFrequencyName =
                    config.maintenanceFrequencyName;
                _this.basicInformation.maintenanceAttention =
                    config.maintenanceAttention;
                _this.basicInformation.maintenanceFrequency =
                    config.maintenanceFrequency;

                // debugger;
                _this.maintenanceContent = config.maintenanceAttention;

                _this.formInline.maintenanceContent = this.maintenanceContent;
                _this.newFormInline.maintenanceContent =
                    this.maintenanceContent;
                _this.queryParams.mainCode = config.mainCode;
            }
            this.search();
            this.setMaintenance = true;
            // setTimeout(() => {
            //     this.$refs.EagleDialog.show();
            //     this.search();
            // });
        },
        search() {
            /**
             * 初始化表单信息
             */
            let _this = this;
            var url = "/" + this.detailController + "/initData/0";
            _this.http
                .get(url, {
                    companyCode: this.$route.query.enterpriseCode ?? "",
                    mainCode: this.queryParams.mainCode,
                })
                .then((response) => {
                    var data = response.data;
                    data.id = data.id || 0;
                    _this.formInline = data;
                    _this.formInline.maintenanceContent =
                        _this.basicInformation.maintenanceAttention;
                    _this.formInline.maintenanceDate = new Date();
                });
            setTimeout(() => {
                this.pageSearch();
            });
        },
        pageSearch() {
            this.$refs.EaglePage.search({
                url: this.detailController + "/getPageData",

                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        // haiwood add
        bindDataAttachMaintenanceInfo(val) {
            this.newFormInline = val;
        },
        // haiwood add
        afterSaveAttachMaintenanceInfo() {
            this.search();
        },
        // //保存编辑维保信息
        // mainSubmit(row) {
        //     this.editorMainDate = false;
        //     let _this = this;
        //     var url = "/site/maintenance/save";

        //     _this.newFormInline.mainCode = this.queryParams.mainCode;

        //     _this.http
        //         .post(url, _this.newFormInline)
        //         .then((response) => {
        //             _this.msgSuccess("保存成功");
        //             _this.newFormInline = {};
        //             _this.newFormInline.maintenanceContent =
        //                 _this.maintenanceContent;
        //             _this.search();
        //         })
        //         .catch((e) => {});
        // },
        cancelHandler() {
            this.editorMainDate = false;
        }, //编辑维保信息
        editorMaintenance(row) {
            // haiwood
            let config = {
                title: "编辑检测信息",
            };
            this.$refs.EagleForm.handleUpdate(row, config);
        },

        //删除维保信息
        deleteMaintenance(row) {
            let _this = this;
            this.$confirm(
                "是否确认删除" +
                    (row.maintenanceDate
                        ? "【" +
                          this.parseDate(row.maintenanceDate, "yyyy-MM-dd") +
                          "】的"
                        : "此条") +
                    "维保记录?",
                "提示",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            )
                .then(() => {
                    var url = "ecologyEnv/maintenance/deleteByCode/" + row.code;
                    _this.http.delLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.search();
                            _this.msgSuccess("删除成功");
                        }
                    );
                })
                .catch(() => {});
        },

        ellipsis(value, len) {
            if (!value) return "";
            if (value.length > len) {
                return value.slice(0, len) + "...";
            }
            return value;
        },
        //保存维保信息
        addMaintenance() {
            let _this = this;
            var url = "/ecologyEnv/maintenance/save";
            // _this.formInline.mainCode = _this.queryParams.mainCode;
            this.$refs["formPage"].validate((valid) => {
                if (valid) {
                    _this.http
                        .post(url, _this.formInline)
                        .then((response) => {
                            _this.msgSuccess("保存成功");
                            _this.$emit("afterSave");
                            _this.formInline = {
                                maintenanceContent: "",
                            };
                            if (_this.maintenanceContent) {
                                _this.formInline.maintenanceContent =
                                    _this.maintenanceContent;
                            }
                            _this.clearForm();
                            _this.pageSearch();
                        })
                        .catch((e) => {});
                }
            });
        },
        clearForm() {
            this.formInline = {};
        },
        //关闭维保信息窗口
        shutDownMaintenance() {
            this.setMaintenance = false;
        },
        closeModal() {
            this.$emit("afterSave");
        },
        openmaintenanceTemp(e) {
            this.selectButton = e.currentTarget.id;
            this.$refs.equipmentMaintenance.show();
        },
        handleMaintenanceSubmit(item) {
            //选择按钮绑定的同一事件，用于区分
            if ("selectEdit" == this.selectButton) {
                if (this.newFormInline.maintenanceContent) {
                    this.newFormInline.maintenanceContent = "";
                }
                for (var i = 0; i < item.length; i++) {
                    this.newFormInline.maintenanceContent =
                        this.newFormInline.maintenanceContent.concat(
                            i + 1 + ": ",
                            item[i].content ? item[i].content : "",
                            "\r\n"
                        );
                }
            } else {
                if (this.formInline.maintenanceContent) {
                    this.formInline.maintenanceContent = "";
                }
                for (var i = 0; i < item.length; i++) {
                    this.formInline.maintenanceContent =
                        this.formInline.maintenanceContent.concat(
                            i + 1 + ": ",
                            item[i].content ? item[i].content : "",
                            "\r\n"
                        );
                }
            }
        },
        parseDate(sourceDate, fmt) {
            var tempDate = new Date(sourceDate);
            var o = {
                "M+": tempDate.getMonth() + 1, //月份
                "d+": tempDate.getDate(), //日
                "h+": tempDate.getHours(), //小时
                "m+": tempDate.getMinutes(), //分
                "s+": tempDate.getSeconds(), //秒
                "q+": Math.floor((tempDate.getMonth() + 3) / 3), //季度
                S: tempDate.getMilliseconds(), //毫秒
            };
            if (/(y+)/.test(fmt))
                fmt = fmt.replace(
                    RegExp.$1,
                    (tempDate.getFullYear() + "").substr(4 - RegExp.$1.length)
                );
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt))
                    fmt = fmt.replace(
                        RegExp.$1,
                        RegExp.$1.length == 1
                            ? o[k]
                            : ("00" + o[k]).substr(("" + o[k]).length)
                    );
            return fmt;
        },
        addDateChange(event) {
            this.formInline.nextMaintenanceDate = this.getNextDate(event);
        },
        editDateChange(event) {
            this.newFormInline.nextMaintenanceDate = this.getNextDate(event);
        },

        getNextDate(event) {
            let tempDate = new Date(event);
            let type = "M";
            let mouth = 12;
            if (this.basicInformation.maintenanceFrequency) {
                let frequency = this.basicInformation.maintenanceFrequency;
                let num = Number(frequency.substring(2));
                if (frequency.indexOf("Y-") >= 0) {
                    mouth = 12 * num;
                } else if (frequency.indexOf("M-") >= 0) {
                    mouth = num;
                } else if (frequency.indexOf("D-") >= 0) {
                    type = "D";
                    mouth = num;
                }
            }
            if (type == "M") {
                return addMonth(tempDate, mouth);
            } else {
                return addDate(tempDate, mouth);
            }
        },
    },
};
</script>
<style lang="scss" scoped>
// .div-host-ent-maintenance-dialog {
// span {
//     line-height: 36px;
// }

// .divTitle {
//     text-align: right;
//     font-weight: 900;

//     span {
//         font-size: 14px;
//         color: #606266;
//         font-weight: 700;
//         margin-right: 10px;
//     }
// }
// }

// .div-table ::v-deep.el-card__body {
//     padding: 0px 0px;
// }

// .enterprise_btn {
//     float: right;
//     color: #1684fc;
//     background: none;
//     border: none;
//     cursor: pointer;
// }

// .setFontWeight {
//     font-weight: 900;
// }
</style>
