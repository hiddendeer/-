<template>
    <div class="div-host-ent-maintenance-dialog">
        <eagle-dialog ref="EagleDialog" :title="title" width="1000px" show-close :close-on-click-modal="false" @close="closeModal">
            <el-form>
                 <eagle-block border title="安全附件详情">
                    <el-row>
                        <el-col :span="12">
                            <eagle-text labelWidth="110px" label="安全附件名称">{{ basicInformation.name || "无" }}</eagle-text>
                        </el-col>
                        <el-col :span="12">
                            <eagle-text labelWidth="110px" label="下次检测日期">{{ parseTime(basicInformation.nextCheckDate, "{y}-{m}-{d}") || "无" }}
                            </eagle-text>
                        </el-col>
                    </el-row>
                </eagle-block>
            </el-form>
            <eagle-block border title="安全附件维保" class="mt10">
                <el-form ref="formPage" :model="formInline" label-width="80px">
                    <el-row>
                        <el-col :span="12">
                            <eagle-date required label="维保日期" prop="maintenanceDate" v-model="formInline.maintenanceDate"></eagle-date>
                        </el-col>
                        <el-col :span="12">
                            <eagle-input label="维保人" required prop="maintenanceChnName" v-model="formInline.maintenanceChnName"></eagle-input>
                        </el-col>
                    </el-row>
                    <el-row style="margin-bottom:10px;">
                        <el-col :span="22">
                            <eagle-input type="textarea" :rows="5" prop="maintenanceContent" label="维保事项" :required="true" v-model="formInline.maintenanceContent"></eagle-input>
                        </el-col>
                        <el-col :span="2">
                            <el-button class="enterprise_btn" @click.stop="openmaintenanceTemp">选择</el-button>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <eagle-input type="textarea" prop="remarks" label="备注" v-model="formInline.remarks">
                            </eagle-input>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <eagle-image label="维保图片" v-model.trim="formInline.attach" prop="attach"></eagle-image>
                        </el-col>
                    </el-row>

                    <el-row style="text-align:right;">
                        <el-button style="margin-left:300px" type="primary" size="mini" @click="addMaintenance">保存
                        </el-button>
                    </el-row>
                </el-form>
            </eagle-block>
            <eagle-block border title="历史维保记录" class="mt10">
                <eagle-page :queryParams="queryParams" :tableHeight="260" btnWidth="140px" :show-check-column="false" :controller="detailController" ref="EaglePage">
                    <template slot="slot-table">
                        <el-table-column label="维保日期" align="left" width="120">
                            <template slot-scope="scope">{{ parseTime(scope.row.maintenanceDate, "{y}-{m}-{d}")
                            }}</template>
                        </el-table-column>
                        <el-table-column prop="maintenanceChnName" align="left" label="维保人" width="100">
                            <template slot-scope="scope">
                                <template>
                                    <span :title="scope.row.maintenanceChnName">{{
                                    ellipsis(scope.row.maintenanceChnName, 18)
                                    }}</span>
                                </template>
                            </template>
                        </el-table-column>
                        <el-table-column prop="maintenanceContent" align="left" label="维保内容" width="270">
                            <template slot-scope="scope">
                                <template>
                                    <span :title="scope.row.maintenanceContent">{{
                                    ellipsis(scope.row.maintenanceContent, 18)
                                    }}</span>
                                </template>
                            </template>
                        </el-table-column>
                        <el-table-column label="维保图片" prop="attach" width="150px">
                            <template slot-scope="scope">
                                <template>
                                    <eagle-row-image v-model="scope.row.attach"></eagle-row-image>
                                </template>
                            </template>
                        </el-table-column>

                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button type="primary" @click="editorMaintenance(scope.row)">编辑
                        </eagle-row-button>
                        <eagle-row-button type="danger" @click="deleteMaintenance(scope.row)">删除
                        </eagle-row-button>
                    </template>
                </eagle-page>
            </eagle-block>
        </eagle-dialog>

        <eagle-form :controller="detailController" title="安全附件维保" :form="newFormInline" width="1000px" label-width="120px" ref="EagleForm" @afterSave="afterSaveAttachMaintenanceInfo" @bindData="bindDataAttachMaintenanceInfo">
             <eagle-block border>
                <el-row>
                    <el-col :span="12">
                        <eagle-date label="维保日期" prop="maintenanceDate" v-model="newFormInline.maintenanceDate">
                        </eagle-date>

                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="维保人" prop="maintenanceChnName" v-model="newFormInline.maintenanceChnName">
                        </eagle-input>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="22">
                        <eagle-input type="textarea" :rows="5" prop="maintenanceContent" label="维保事项" :required="true" v-model="newFormInline.maintenanceContent"></eagle-input>
                    </el-col>
                    <el-col :span="2">
                        <el-button class="enterprise_btn" id="selectEdit" @click.stop="openmaintenanceTemp($event)">选择
                        </el-button>
                    </el-col>
                </el-row>
                <el-row>
                    <eagle-input label="备注" prop="remarks" v-model="newFormInline.remarks"></eagle-input>
                </el-row>

                <el-row>
                    <eagle-image label="维保图片" prop="attach" v-model.trim="newFormInline.attach"></eagle-image>
                </el-row>
            </eagle-block>
        </eagle-form>

        <equipment-maintenance-dialog ref="equipmentMaintenance" @submit="handleMaintenanceSubmit">
        </equipment-maintenance-dialog>
    </div>
</template>

<script>
import equipmentMaintenanceDialog from "@/views/host/components/equipment/equipmentMaintenanceDialog.vue";
export default {
    name: "safety-attachs-maintenance-dialog",
    components: { equipmentMaintenanceDialog },
    props: {
        title: {
            type: String,
            default() {
                return "安全附件维保信息";
            },
        },
    },
    data() {
        return {
            setMaintenance: false,
            editorMainDate: false,
            basicInformation: {},
            formInline: {
                maintenanceContent: "",
            },
            conditionsVals: {
                mainCode: "",
            },
            conditionsTypes: {
                mainCode: "=",
            },
            showDialog: false,
            newFormInline: {},
            tableData: [],
            editorMain: "编辑维保信息",
            //分页设置
            total: 100,
            pagesize: 5, //每页的数据条数
            currentPage: 1, //默认开始页面
            queryParams: {
                dataType: "list",
            },
            detailController: "ecologyEnv/entEquipmentAttachMaintenance",
            maintenanceContent: "",
            selectButton: "", //区分点击的选择是哪个按钮
        };
    },
    created() {},
    mounted() {},
    methods: {
        show(config) {
            var _this = this;

            // this.setMaintenance = true;
            setTimeout(() => {
                this.$refs.EagleDialog.show();
            });
            if (config) {
                _this.basicInformation.name = config.name;
                _this.basicInformation.nextCheckDate = config.nextCheckDate;
                // _this.basicInformation.locationName = config.locationName;
                // _this.basicInformation.maintenanceFrequencyName =
                //     config.maintenanceFrequencyName;
                // _this.basicInformation.maintenanceAttention =
                //     config.maintenanceAttention;

                _this.maintenanceContent = config.maintenanceAttention
                    ? config.maintenanceAttention
                    : "";

                _this.formInline.maintenanceContent = this.maintenanceContent;
                _this.newFormInline.maintenanceContent =
                    this.maintenanceContent;

                _this.queryParams.code = config.code;
                _this.queryParams.mainCode = config.mainCode;
                _this.conditionsVals.mainCode = config.code;
            }
            /**
             *
             * 初始化表单信息
             */

            setTimeout(() => {
                this.search();
            });
        },
        // haiwood add
        bindDataAttachMaintenanceInfo(val) {
            this.newFormInline = val;
        },
        // haiwood add
        afterSaveAttachMaintenanceInfo() {
            this.search();
        },
        search() {
            /**
             * 初始化表单信息
             */
            // haiwood add
            let _this = this;
            var url = "/" + this.detailController + "/initData/0";
            _this.http
                .get(url, {
                    companyCode: this.$route.query.enterpriseCode ?? "",
                })
                .then((response) => {
                    var data = response.data;
                    data.id = data.id || 0;
                    _this.formInline = data;
                });

            this.$refs.EaglePage.search({
                url: this.detailController + "/getPageData",

                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        ellipsis(value, len) {
            if (!value) return "";
            if (value.length > len) {
                return value.slice(0, len) + "...";
            }
            return value;
        },
        //保存编辑维保信息
        mainSubmit(row) {
            this.editorMainDate = false;
            let _this = this;
            var url = "/ecologyEnv/entEquipmentAttachMaintenance/save";

            _this.newFormInline.mainCode = this.queryParams.code;
            _this.newFormInline.equipmentCode = this.queryParams.mainCode;

            _this.http
                .post(url, _this.newFormInline)
                .then((response) => {
                    _this.msgSuccess("保存成功");
                    _this.newFormInline = {};
                    _this.newFormInline.maintenanceContent =
                        _this.maintenanceContent;
                    _this.getMaintenanceList();
                })
                .catch((e) => {});
        },
        cancelHandler() {
            this.editorMainDate = false;
        },
        //编辑维保信息
        // haiwood add
        editorMaintenance(row) {
            // this.editorMainDate = true;
            // var url = "site/entEquipmentAttachMaintenance/getDataByCode/";
            // this.http.get(url + row.code).then(res => {
            //     this.newFormInline = res.data;
            // });
            // haiwood fix
            let config = {
                title: "编辑检测信息",
            };
            this.$refs.EagleForm.handleUpdate(row, config);
        },

        //删除维保信息
        deleteMaintenance(row) {
            let _this = this;
            this.$confirm(
                "是否确认删除" +
                    (row.maintenanceDate
                        ? "【" +
                          this.parseDate(row.maintenanceDate, "yyyy-MM-dd") +
                          "】的"
                        : "此条") +
                    "维保记录?",
                "提示",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            )
                .then(() => {
                    var url =
                        "ecologyEnv/entEquipmentAttachMaintenance/deleteByCode/" +
                        row.code;
                    _this.http.delLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.getMaintenanceList();
                            _this.msgSuccess("删除成功");
                        }
                    );
                })
                .catch(() => {});
        },
        getMaintenanceList() {
            this.search();
        },
        //保存维保信息
        addMaintenance() {
            let _this = this;
            _this.$refs["formPage"].validate((valid) => {
                if (valid) {
                    var url = "/ecologyEnv/entEquipmentAttachMaintenance/save";
                    _this.formInline.mainCode = _this.queryParams.code;
                    _this.formInline.equipmentCode = _this.queryParams.mainCode;
                    // console.log("-----------------------",_this.formInline);
                    // _this.formInline.companyCode =  this.$route.query.enterpriseCode ?? "";
                    _this.http
                        .post(url, _this.formInline)
                        .then((response) => {
                            _this.msgSuccess("保存成功");
                            _this.$emit("afterSave");
                            _this.formInline = {
                                maintenanceContent: "",
                            };
                            if (_this.maintenanceContent) {
                                _this.formInline.maintenanceContent =
                                    _this.maintenanceContent;
                            }
                            _this.getMaintenanceList();
                        })
                        .catch((e) => {});
                }
            });
        },
        //关闭维保信息窗口
        shutDownMaintenance() {
            this.setMaintenance = false;
        },
        closeModal() {
            this.$emit("afterSave");
        },
        openmaintenanceTemp(e) {
            this.selectButton = e.currentTarget.id;
            this.$refs.equipmentMaintenance.show();
        },
        handleMaintenanceSubmit(item) {
            //选择按钮绑定的同一事件，用于区分
            if ("selectEdit" == this.selectButton) {
                if (this.newFormInline.maintenanceContent) {
                    this.newFormInline.maintenanceContent = "";
                }
                for (var i = 0; i < item.length; i++) {
                    this.newFormInline.maintenanceContent =
                        this.newFormInline.maintenanceContent.concat(
                            i + 1 + ": ",
                            item[i].content ? item[i].content : "",
                            "\r\n"
                        );
                }
            } else {
                if (this.formInline.maintenanceContent) {
                    this.formInline.maintenanceContent = "";
                }
                for (var i = 0; i < item.length; i++) {
                    this.formInline.maintenanceContent =
                        this.formInline.maintenanceContent.concat(
                            i + 1 + ": ",
                            item[i].content ? item[i].content : "",
                            "\r\n"
                        );
                }
            }
        },
        parseDate(sourceDate, fmt) {
            var tempDate = new Date(sourceDate);
            var o = {
                "M+": tempDate.getMonth() + 1, //月份
                "d+": tempDate.getDate(), //日
                "h+": tempDate.getHours(), //小时
                "m+": tempDate.getMinutes(), //分
                "s+": tempDate.getSeconds(), //秒
                "q+": Math.floor((tempDate.getMonth() + 3) / 3), //季度
                S: tempDate.getMilliseconds(), //毫秒
            };
            if (/(y+)/.test(fmt))
                fmt = fmt.replace(
                    RegExp.$1,
                    (tempDate.getFullYear() + "").substr(4 - RegExp.$1.length)
                );
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt))
                    fmt = fmt.replace(
                        RegExp.$1,
                        RegExp.$1.length == 1
                            ? o[k]
                            : ("00" + o[k]).substr(("" + o[k]).length)
                    );
            return fmt;
        },
    },
};
</script>
<style lang="scss" scoped>
.div-host-ent-maintenance-dialog {
    span {
        line-height: 36px;
    }

    .divTitle {
        text-align: right;
        font-weight: 900;

        span {
            font-size: 14px;
            color: #606266;
            font-weight: 700;
            margin-right: 10px;
        }
    }
}

.div-table ::v-deep.el-card__body {
    padding: 0px 0px;
}

.enterprise_btn {
    float: right;
    color: #1684fc;
    background: none;
    border: none;
    cursor: pointer;
}

.setFontWeight {
    font-weight: 900;
}
</style>
