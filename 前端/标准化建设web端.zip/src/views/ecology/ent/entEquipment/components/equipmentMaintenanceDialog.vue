<template>
    <div>
        <el-dialog v-dialogDrag :visible.sync="open" width="1000px" title="设备维保事项库" append-to-body show-close
            :close-on-click-modal="false" v-loading="false">
            <eagle-block border>
                <eagle-window-choose :queryParams="queryParams" :controller="controller" :show-btn="true" ref="eagleWindowChoose"
                    :table-height="450" selectTextField="title" selectField="id">
                    <template slot="slot-search">
                        <eagle-condition @search="search()" @resetQuery="resetQuery()">
                            <eagle-input label-width="70px" label="标题" @changeEnter="search()" :required="false"
                                prop="title" v-model="conditionsVals.title" placeholder="请输入标题" clearable
                                size="small" />
                        </eagle-condition>
                    </template>
                    <template slot="slot-table">
                        <el-table-column label="标题" prop="title" width="200" />
                        <el-table-column label="行业" prop="applyProfessionNames" width="150" />
                        <el-table-column label="地区" prop="belongArea" width="150" />
                        <el-table-column label="内容" prop="content" />
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button @click="openDetail(scope.row)">详情</eagle-row-button>
                    </template>
                </eagle-window-choose>
            </eagle-block>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="submit">确 定</el-button>
                <el-button @click="cancel">关 闭</el-button>
            </div>
        </el-dialog>
        <equipment-maintenance-view-dialog ref="responseDeptView"></equipment-maintenance-view-dialog>
    </div>
</template>
<script>
import equipmentMaintenanceViewDialog from "@/views/lib/equipment/equipmentMaintenance/components/view.vue";
export default {
    components: {
        equipmentMaintenanceViewDialog,
    },
    name: "equipment-maintenance-temp-dialog",
    data() {
        return {
            open: false,
            loadingbuttext: "确 定",
            disabled: false,
            queryParams: {
                dataType: "list",
            },
            conditionsVals: {
                title: "",
            },
            conditionsTypes: {
                title: "like",
            },
            controller: "ecologyEnv/maintenanceTemp", //对应后端控制器
        };
    },
    methods: {
        show(config) {
            this.open = true;
            let _this = this;
            setTimeout((res) => {
                _this.search();
                _this.$refs.eagleWindowChoose.selection = [];
            });
        },
        search() {
            this.getCondtions();
            this.$refs.eagleWindowChoose.search({
                url: this.controller + "/getPageData",

                conditions: this.$refs.eagleWindowChoose.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        getCondtions() {
            let conditions = [];
            for (let key in this.conditionsVals) {
                let ops = this.conditionsTypes[key];
                let vals = this.conditionsVals[key];
                if (vals) {
                    conditions.push({
                        name: key,
                        operate: !ops ? "like" : ops,
                        value: vals,
                    });
                }
            }
            return conditions && conditions.length > 0
                ? JSON.stringify(conditions)
                : conditions;
        },
        resetQuery() {
            this.conditionsVals.title = "";
            this.search();
        },
        // 取消按钮
        cancel() {
            this.open = false;
        },
        submit() {
            let selectArr = this.$refs.eagleWindowChoose.selection;
            if (!selectArr || selectArr.length == 0) {
                this.msgError("请选择设备维保事项信息");
                return null;
            }
            let selectItem = selectArr;
            let result = this.deepClone(selectItem);
            this.$emit("submit", result);
            this.open = false;
        },
        openDetail(row) {
            this.$refs.responseDeptView.show(row.code);
        },
    },
};
</script>
<style lang="scss" scoped>
</style>
