<template>
    <!-- <el-col v-if="isFullCol || span<24" :span="span">
        <el-form-item :label="label" :label-width="labelWidth" :prop="prop" :required="required" :rules="rulesArray">
            <template v-if="!isEdit">{{formateDict(dataSource, value,id,name,',')}}</template>
            <template v-else>
                <el-select v-model="selectValue" :placeholder="placeholderVal" :disabled="disabled" @change="handleChange" :filterable="filterable" :clearable="clearable" :multiple="multiple">
                    <el-option v-for="item in dataSource" :key="item[id]" :label="item[name]" :value="item[id]"></el-option>
                </el-select>
            </template>
        </el-form-item>
    </el-col> -->

    <el-form-item :label="label" :label-width="labelWidth" :prop="prop" :required="required" :rules="rulesArray">
        <template v-if="!isEdit">{{formateDict(dataSource, value,id,name,',')}}</template>
        <template v-else>
            <el-select v-model="selectValue" :placeholder="placeholderVal" :disabled="disabled" @change="handleChange" :filterable="filterable" :clearable="clearable" :multiple="multiple">
                <el-option v-for="item in dataSource" :key="item[id]" :label="item[name]" :value="item[id]"></el-option>
            </el-select>
        </template>
    </el-form-item>

</template>
<script>
export default {
    name: "eagle-select",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            }
        },
        names: {
            type: String,
            default: ""
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            }
        },
        id: {
            type: String,
            default() {
                return "id";
            }
        },
        name: {
            type: String,
            default() {
                return "name";
            }
        },
        label: {
            type: String,
            default() {
                return "";
            }
        },
        value: {
            type: String | Number,
            default() {
                return null;
            }
        },
        span: {
            type: Number,
            default() {
                return 24;
            }
        },
        prop: {
            type: String,
            default() {
                return "";
            }
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            }
        },
        filterable: {
            type: Boolean,
            default() {
                return false;
            }
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            }
        },
        multiple: {
            type: Boolean,
            default() {
                return false;
            }
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            }
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            }
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            }
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            }
        },

        placeholder: {
            type: String,
            default() {
                return "";
            }
        },
        rules: {
            type: Array,
            default() {
                return [];
            }
        }
    },
    data() {
        return {
            selectValue: "",
            placeholderVal: this.placeholder
                ? this.placeholder
                : "请选择" + this.label,
            rulesArray: []
        };
    },
    created() {
        this.selectValue = this.value;
        this.initData();
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
            this.selectValue = this.value;
        }
    },
    methods: {
        initData() {
            var _this = this;
            let params = {};
            var url = "ecologyEnv/entBuilding/getListData";
            if (this.$route.query.enterpriseCode) {
                url += "?companyCode=" + this.$route.query.enterpriseCode;
            }

            _this.http.postLoading(_this.loading(), url, {}, function(res) {
                if (res.data) {
                    for (var i = 0; i < res.data.length; i++) {
                        _this.dataSource.push({
                            id: res.data[i].code,
                            name: res.data[i].buildName
                        });
                        _this.setRules();
                    }
                }
            });

            // this.http.post(url).then((res) => {
            //     if (res.code == "200") {
            //         if (res.data) {
            //             for (var i = 0; i < res.data.length; i++) {
            //                 _this.dataSource.push({
            //                     id: res.data[i].code,
            //                     name: res.data[i].buildName,
            //                 });
            //                 this.setRules();
            //             }
            //         }
            //     }
            // });
        },
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : "")
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach(x => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange(newvalue) {
            let _this = this;
            _this.$emit("input", newvalue);
            var data = {};
            data.buildCode = newvalue;
            data.buildName = _this.getBuildName(newvalue);
            this.$emit("update:names", data.buildName);
            // _this.$emit("afterChange", data);
        },
        getBuildName(buildCode) {
            var buildName = "";
            if (buildCode) {
                var tempArray = this.dataSource.filter(x => x.id == buildCode);
                if (tempArray && tempArray.length > 0) {
                    buildName = tempArray[0].name;
                }
            }
            return buildName;
        }
    }
};
</script>
