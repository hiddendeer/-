<template>
    <div class="app-container  div_ent_equipment_app-container">
        <div class="layer">

            <eagle-page :controller="controller" ref="EaglePage" :showCheckColumn="true" btn-width="180px" :conditions="conditions">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input class="setFilter" label-width="80px" @changeEnter="search()" label="筛选条2件" prop="equipmentName" v-model="conditions.equipmentName.value" placeholder="请输入设备名称进行模糊搜索" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-buttons">
                    <el-row :gutter="10">
                        <el-col :span="1.5">
                            <el-popover
                                placement="top-start"
                                width="200"
                                trigger="hover"
                                content="根据企业四色分级管理评分规则，若存在特种设备，未办理特种设备使用登记，每涉及一台，减10分；特种设备检测、检验报告，每缺少一份，减5分；"
                            >
                                <el-button
                                    icon="el-icon-warning-outline"
                                    slot="reference"
                                    type="text"
                                    key="text"
                                    >评分规则</el-button
                                >
                            </el-popover>
                        </el-col>
                        <el-col :span="1.5">
                            <el-button type="primary" icon="el-icon-plus" size="mini" @click="handleAdd">新增</el-button>
                        </el-col>
                        <el-col :span="1.5">
                            <el-button icon="el-icon-delete" size="mini" type="danger" @click="handleDelbatch">批量删除
                            </el-button>
                        </el-col>
                        <el-col :span="1.5">
                            <el-button icon="el-icon-upload2" size="mini" type="primary" @click="handleImport">导入
                            </el-button>
                        </el-col>
                        <el-col :span="1.5">
                            <el-button icon="el-icon-download" size="mini" type="primary" @click="handleExport">导出
                            </el-button>
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">
                    <el-table-column label="所在区域" align="left" prop="locationName" width="120px" />
                    <el-table-column label="部门" align="left" prop="orgName" width="100px" />
                    <el-table-column label="设备名称" align="left" prop="equipmentName" width="200px" />
                    <el-table-column label="设备照片" align="left" width="80px">
                        <template slot-scope="scope">
                            <div style="display:flex;flex-direction: row;">
                                <el-upload class="upload-demo" :headers="headers" :show-file-list="false" :action="uploadUrl" :on-success="function (res, file) { return handleUploadSuccess(res, file, scope.row) }" :multiple="false">
                                    <eagle-row-button-text imageValue="upload" type="text">上传</eagle-row-button-text>
                                </el-upload>
                                <eagle-row-image v-model="scope.row.equipmentPhoto"></eagle-row-image>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="维保信息" align="left" prop="maintenanceFrequency" width="140px">
                        <template slot-scope="scope">
                            <span>
                                <div style="display:flex;flex-direction: row;">
                                    <eagle-row-button type="primary" imageValue="upload" @click="maintenance(scope.row)">
                                        维保
                                    </eagle-row-button>
                                    <span style="line-height: 24px;">({{
                                            scope.row.maintenanceCount
                                    }})次</span>
                                </div>
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column label="安全附件" align="left" prop="" width="120px">
                        <template slot-scope="scope">
                            <span v-if="scope.row.equipmentType == 'true'">
                                <div style="display:flex;flex-direction: row;">
                                    <eagle-row-button type="primary" imageValue="upload" v-if="scope.row.equipmentType == 'true' && scope.row.isAttached" @click.stop="registration(scope.row)">登记
                                    </eagle-row-button>
                                    <span v-if="form.isAttached" style="line-height: 24px;">({{
                                            scope.row.secureAttachCount
                                    }})次</span>
                                </div>
                            </span>
                            <span v-else>--</span>
                        </template>
                    </el-table-column>
                    <!-- <el-table-column label="二维码"  align="left" prop="checkNames" /> -->
                    <el-table-column label="下次检验日期" align="left" prop="checkDate" width="200px">
                        <template slot-scope="scope">
                            <el-date-picker v-model="scope.row.checkDate" :clearable="false" v-if="scope.row.equipmentType == 'true'" value-format="yyyy-MM-dd" type="date" placeholder="请选择年月日" @change="onDateChange(scope.row)">
                            </el-date-picker>
                            <span v-else>--</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="设备检验预警" align="left" prop="" width="135px">
                        <template slot-scope="scope">
                            <span>{{ parseTime(scope.row.checkDate, "{y}-{m}-{d}") || "--" }}</span>
                            <div v-if="scope.row.checkDate" v-html="getSuplusDate(scope.row.checkDate)">
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column label="设备编号" align="left" prop="equipmentNo" width="180px" />
                    <el-table-column label="设备型号" align="left" prop="equipmentModel" />
                    <!-- <el-table-column label="安全附件检验预警"  align="left" prop="" width="220px" /> -->
                    <!-- <el-table-column label="风险辨识管控信息"  align="left" prop="" width="220px" /> -->
                    <!-- <el-table-column label="设备资料"  align="left" prop="attachs" width="180px">
                    <template slot-scope="scope">
                        <button class="setRegistration" @click="setUpAttachs(scope.row)">上传</button>
                    </template>
                </el-table-column> -->

                    <!-- <el-table-column label="设备照片"  align="left" prop="equipmentPhoto" width="180px">
                    <template slot-scope="scope">
                        <el-image v-if="scope.row.equipmentPhoto" style="width: 30px; height: 30px" :src="scope.row.equipmentPhoto" :preview-src-list="[scope.row.equipmentPhoto]">
                        </el-image>
                        <button class="setRegistration" style="float:right;margin-top:7px;margin-right:35px;" @click="setUp">上传</button>
                    </template>
                </el-table-column> -->
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="primary" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>
                    <!-- <eagle-row-button type="primary" @click.stop="setCopy()">复制</eagle-row-button> -->
                    <eagle-row-button type="danger" @click.stop="handleDelete(scope.row)">删除</eagle-row-button>
                    <eagle-row-button type="primary" @click.stop="viewAllInformation(scope.row)">详情</eagle-row-button>
                </template>
            </eagle-page>
            <eagle-form class="divForm" :controller="controller" title="设备信息" :rules="rules" :customButtons="true" :form="form" width="1000px" label-width="120px" ref="EagleForm" @afterSave="afterSave" @bindData="bindData">
                <eagle-block border>
                    <el-row>
                        <el-col :span="12">
                            <eagle-autocomplete required label="所在区域" prop="locationName" labelName="buildName" :code.sync="form.locationCode" v-model="form.locationName" url="/ecologyEnv/entBuilding/getListDataByName"></eagle-autocomplete>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item label="部门" prop="orgName">
                                <el-input style="display:inline-block" placeholder="请输入部门" v-model="form.orgName" required></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <el-form-item label="设备名称" prop="equipmentName">
                                <el-input style="display:inline-block" placeholder="请输入设备名称" v-model="form.equipmentName" required></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item label="设备型号" prop="equipmentModel">
                                <el-input style="display:inline-block" placeholder="请输入设备型号" v-model="form.equipmentModel"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="设备数量" v-if="!form.code" prop="equipmentCount" style="display:inline-block" required>
                                <el-input-number required placeholder="请输入设备数量" controls-position="right" :min="1" v-model="form.equipmentCount"></el-input-number>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <!-- </el-form-item> -->
                    <eagle-image label="设备照片" :count="1" v-model="form.equipmentPhoto" prop="equipmentPhoto">
                    </eagle-image>
                    <el-form-item class="attachmentJudge" label-width="0px">
                        <!-- <el-form-item label-width="125px" style="float:left" label="是否属于特种设备">
                            <el-radio-group prop="equipmentType" v-model="form.equipmentType">
                                <el-radio :label="'true'">是</el-radio>
                                <el-radio :label="'false'">否</el-radio>
                            </el-radio-group>
                        </el-form-item> -->
                        <el-form-item label-width="245px" style="float:left" v-if="form.equipmentType == 'true'" label="是否有安全附件">
                            <el-radio-group prop="isAttached" v-model="form.isAttached">
                                <el-radio :label="true">是</el-radio>
                                <el-radio :label="false">否</el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-form-item>
                    <eagle-checkgroup label="安全附件" v-if="form.equipmentType == 'true' && form.isAttached" prop="secureAttach" v-model="form.secureAttach" :data-source="params.equipmentSecureAttach" />
                    <el-form-item class="attachmentJudge" prop="specialEquipmentList" label-width="0px" v-if="form.equipmentType == 'true'">
                        <div v-for="(item, index) in form.specialEquipmentList" :key="index" class="special_div">
                            <span class="title" v-if="opType == 'update'">特种设备信息</span>
                            <span class="title" v-else>特种设备{{ index + 1 }}</span>
                            <el-row>
                                <el-col :span="10">
                                    <el-form-item label-width="125px" style="float:left" label="设备编号">
                                        <el-input style="display:inline-block" placeholder="请输入设备编号" v-model="item.equipmentNumber"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <eagle-date
                                        label-width="50px"
                                        :clearable="false"
                                        label="登记时间"
                                        labelWidth="80px"
                                        type="datetime"
                                        format="yyyy-MM-dd HH:mm:ss"
                                        v-model="item.registerDate"
                                    ></eagle-date>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="24">
                                    <eagle-attach label="使用登记证" :count="9" v-model="item.registerCertificateFile" prop="registerCertificateFile">
                                    </eagle-attach>
                                </el-col>
                                <!-- <el-col :span="24">
                                    <eagle-attach label="特种设备检测" :count="9" v-model="item.equipmentSpecialCheckFile" prop="equipmentSpecialCheckFile">
                                    </eagle-attach>
                                </el-col> -->
                                <el-col :span="24">
                                    <eagle-attach label="检测报告" :count="9" v-model="item.equipmentSpecialCheckReportFile" prop="equipmentSpecialCheckReportFile">
                                    </eagle-attach>
                                </el-col>
                            </el-row>
                        </div>
                    </el-form-item>
                    <!-- <el-button class="enterprise_fxd" @click="setForMoreInformation">
                        {{ forMoreInformation ? "隐藏更多信息" : "点击录入更多信息" }}
                    </el-button> -->
                    <!-- <el-row>
                        <el-col :span="24"> -->
                    <el-row>
                        <el-col :span="24">
                            <eagle-attach label="设备资料" :count="9" v-model="form.attachs" prop="attachs">
                            </eagle-attach>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="22">
                            <el-form-item label="维保事项">
                                <el-input :rows="3" type="textarea" prop="maintenanceAttention" v-model="form.maintenanceAttention" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="2">
                            <el-button class="enterprise_btn" type="text" @click.stop="openmaintenanceTemp">选择
                            </el-button>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-select label="维护保养频次" prop="maintenanceFrequency" v-model="form.maintenanceFrequency" :data-source="params.frequency" />
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="备注">
                                <el-input :rows="3" type="textarea" prop="remarks" v-model="form.remarks" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <!-- </el-col>
                    </el-row> -->
                </eagle-block>
                <div slot="buttons" class="dialog-footer">
                    <el-button @click="cancel">取 消</el-button>
                    <el-button type="primary" @click="submitForm">保 存</el-button>
                </div>
            </eagle-form>

            <!-- 查看全部信息 -->
            <el-dialog v-dialogDrag :title="informationDate" :visible.sync="allTheInformation" width="1000px" append-to-body show-close :close-on-click-modal="false">
                <el-form>
                    <el-card shadow="never">
                        <div slot="header" class="clearfix">
                            <span class="setFontWeight"><i class="el-icon-s-grid"></i>设备信息</span>
                        </div>
                        <div>
                            <el-row>
                                <el-col :span="3" class="divTitle">
                                    <span>所在区域</span>
                                </el-col>
                                <el-col :span="9">
                                    <span> {{ selectRowData.locationName || "无" }}</span>
                                </el-col>
                                <el-col :span="3" class="divTitle">
                                    <span>部门</span>
                                </el-col>
                                <el-col :span="9">
                                    <span> {{ selectRowData.orgName || "无" }}</span>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="3" class="divTitle"><span class="span_title">设备名称</span></el-col>
                                <el-col :span="9"><span>{{ selectRowData.equipmentName || "无" }}</span></el-col>
                                <el-col :span="3" class="divTitle"> <span>设备型号 </span></el-col>
                                <el-col :span="9"><span>{{ selectRowData.equipmentModel || "无" }}</span></el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="3" class="divTitle"> <span>设备照片</span></el-col>
                                <el-col :span="21">
                                    <el-image style="width: 110px; height: 110px" :src="selectRowData.equipmentPhoto || noImgUrl" :preview-src-list="[selectRowData.equipmentPhoto]">
                                    </el-image>
                                </el-col>
                            </el-row>
                            <el-row v-if="selectRowData.specialEquipmentList && selectRowData.specialEquipmentList.length > 0">
                                <div v-for="(item, index) in selectRowData.specialEquipmentList" :key="index" class="special_div detail_div">
                                    <p class="title">特种设备信息</p>
                                    <el-row>
                                        <el-col :span="3" class="divTitle"><span class="span_title">设备编号</span></el-col>
                                        <el-col :span="9"><span>{{ item.equipmentNumber || "无" }}</span></el-col>
                                        <el-col :span="3" class="divTitle"><span class="span_title">登记时间</span></el-col>
                                        <el-col :span="9"><span>{{ item.registerDate || "无" }}</span></el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="3" class="divTitle">
                                            <span>使用登记证</span>
                                        </el-col>
                                        <el-col :span="21">
                                            <eagle-attach v-if="item.registerCertificateFile && item.registerCertificateFile.length > 0" :isEdit="false" style="width:auto;" v-model="item.registerCertificateFile">
                                            </eagle-attach>
                                            <span v-else>无</span>
                                        </el-col>
                                    </el-row>
                                    <!-- <el-row>
                                        <el-col :span="3" class="divTitle">
                                            <span>特种设备检测</span>
                                        </el-col>
                                        <el-col :span="21">
                                            <eagle-attach v-if="item.equipmentSpecialCheckFile && item.equipmentSpecialCheckFile.length > 0" :isEdit="false" style="width:auto;" v-model="item.equipmentSpecialCheckFile">
                                            </eagle-attach>
                                            <span v-else>无</span>
                                        </el-col>
                                    </el-row> -->
                                    <el-row>
                                        <el-col :span="3" class="divTitle">
                                            <span>检测报告</span>
                                        </el-col>
                                        <el-col :span="21">
                                            <eagle-attach v-if="item.equipmentSpecialCheckReportFile && item.equipmentSpecialCheckReportFile.length > 0" :isEdit="false" style="width:auto;" v-model="item.equipmentSpecialCheckReportFile">
                                            </eagle-attach>
                                            <span v-else>无</span>
                                        </el-col>
                                    </el-row>
                                </div>
                            </el-row>
                            <el-row>
                                <el-col :span="3" class="divTitle">
                                    <span>设备资料</span>
                                </el-col>
                                <el-col :span="21">
                                    <eagle-attach v-if="selectRowData.attachs && selectRowData.attachs.length > 0" :isEdit="false" style="width:auto;" v-model="selectRowData.attachs">
                                    </eagle-attach>
                                    <span v-else>无</span>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="3" class="divTitle"> <span>维保事项</span></el-col>
                                <el-col :span="21"> <span>{{ selectRowData.maintenanceAttention || '无' }}</span>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="3" class="divTitle"> <span>频次</span></el-col>
                                <el-col :span="21"> <span>{{ selectRowData.frequencyName || '无' }}</span></el-col>
                            </el-row>
                        </div>
                    </el-card>
                    <el-card style="margin-top:10px;" shadow="never" class="div-table" :body-style="{ padding: '0px' }">
                        <div slot="header" class="clearfix">
                            <span class="setFontWeight"><i class="el-icon-s-grid"></i>安全附件检验信息</span>
                        </div>
                        <div>
                            <el-table ref="multipleTable" :data="secureAttachmentList" tooltip-effect="dark" style="width: 100%" height="300">
                                <el-table-column type="index" width="50" label="序号" align="left"> </el-table-column>
                                <el-table-column prop="name" align="left" label="附件名称" show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column align="left" label="下次检测日期" show-overflow-tooltip width="120">
                                    <template slot-scope="scope">{{ parseTime(scope.row.nextCheckDate, "{y}-{m}-{d}")
                                    }}</template>
                                </el-table-column>
                                <el-table-column align="left" label="安全附件检测预警" show-overflow-tooltip width="200">
                                    <template slot-scope="scope">
                                        <span> {{ parseTime(scope.row.nextCheckDate, "{y}-{m}-{d}") }}</span>
                                        <div v-if="scope.row.nextCheckDate" v-html="getSuplusDate(scope.row.nextCheckDate)">
                                        </div>
                                    </template>
                                </el-table-column>
                                <template slot="empty">
                                    <el-empty :image-size="100" description="暂无数据"></el-empty>
                                </template>
                            </el-table>
                        </div>
                    </el-card>

                    <el-card style="margin-top:10px;border-bottom:1px solid #e6ebf5;" shadow="never" class="div-table" :body-style="{ padding: '0px' }">
                        <div slot="header" class="clearfix">
                            <span class="setFontWeight"><i class="el-icon-s-grid"></i>历史维保记录</span>
                        </div>
                        <div>
                            <eagle-page :controller="maintenanceUrl" :tableHeight="350" ref="EaglePagesMaintenan" :showCheckColumn="false" :showBtn="false" :imageSize="100">
                                <template slot="slot-table">
                                    <el-table-column label="维保日期" width="200px" align="left">
                                        <template slot-scope="scope">
                                            <span>{{ parseTime(scope.row.maintenanceDate, '{y}-{m}-{d}') }}</span>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="维保人" prop="maintenanceUserName" align="left" width="280px">
                                        <template slot-scope="scope">
                                            <template>
                                                <span :title="scope.row.maintenanceUserName">{{
                                                        ellipsis(scope.row.maintenanceUserName, 18)
                                                }}</span>
                                            </template>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="维保内容" align="left" prop="maintenanceContent" width="330px">
                                        <template slot-scope="scope">
                                            <template>
                                                <span :title="scope.row.maintenanceContent">{{
                                                        ellipsis(scope.row.maintenanceContent, 18)
                                                }}</span>
                                            </template>
                                        </template>
                                    </el-table-column>
                                </template>
                            </eagle-page>
                        </div>
                    </el-card>
                </el-form>
            </el-dialog>
            <eagle-dialog-exce title="设施设备表格" ref="EagleDialogExce" :url="controller" fileName="entEquipment.xlsx" @refresh="refresh"></eagle-dialog-exce>
            <ent-safety-attachs-dialog ref="entSafetyAttachs" @afterSave="afterSaveInfo"></ent-safety-attachs-dialog>
            <ent-maintenance-dialog ref="entMaintenance" @afterSave="afterSaveInfo"></ent-maintenance-dialog>
            <equipment-maintenance-dialog ref="equipmentMaintenance" @submit="handleMaintenanceSubmit">
            </equipment-maintenance-dialog>
        </div>
    </div>
</template>

<script>
import EagleDialog from "@/components/Eagle/eagle-dialog.vue";
import eagleImage from "@/components/Eagle/eagle-image.vue";

import entSafetyAttachsDialog from "./components/safetyAttachs-dialog.vue";
import entMaintenanceDialog from "./components/maintenance-dialog.vue";
import entSelectBuild from "./components/select-build.vue";
import EagleDialogExce from "@/components/Eagle/eagle-dialog-exce.vue";

import equipmentMaintenanceDialog from "./components/equipmentMaintenanceDialog.vue";
import { getToken } from "@/utils/auth";
import { download } from "@/utils/request";

export default {
    components: {
        eagleImage,
        EagleDialog,
        entSafetyAttachsDialog,
        entMaintenanceDialog,
        entSelectBuild,
        EagleDialogExce,
        equipmentMaintenanceDialog,
    },
    name: "ent-equipment",
    data() {
        return {
            controller: "ecologyEnv/entEquipment",
            controllers: "ecologyEnv/entEquipment/saveEquipment",
            securityAttachment: "ecologyEnv/attach",
            maintenanceUrl: "ecologyEnv/maintenance",
            conditions: {
                equipmentName: { value: "", operate: "like" },
                checkType: { value: "", operate: "=" },
            },
            queryParams: {
                dataType: "list",
                mainCode: "",
            },

            checkType: [],
            params: {
                //字典
                checkType: [],
                equipmentSecureAttach: [],
                frequency: [],
            },
            form: {
                orgName: "模式部门",
                equipmentType: false,
                isAttached: false,
                specialEquipmentList: [],
            },
            rules: {
                equipmentCount: [
                    {
                        required: true,
                        message: "请输入设备数量",
                        trigger: "blur",
                    },
                ],
                locationName: [
                    {
                        required: true,
                        message: "请选择建构筑物",
                        trigger: "change",
                    },
                ],
                orgName: [
                    {
                        required: true,
                        message: "请输入部门",
                        trigger: "blur",
                    },
                ],
                // equipmentModel: [
                //     {
                //         required: true,
                //         message: "请输入设备型号",
                //         trigger: "blur",
                //     },
                // ],
                equipmentName: [
                    {
                        required: true,
                        message: "请输入设备名称",
                        trigger: "blur",
                    },
                ],
            },
            //安全附件
            security: {
                mainCode: "",
            },
            forMoreInformation: false,
            //登记标题
            impleTitle: "安全附件登记",
            //安全附件登记弹窗显隐
            trainImpleVisible: false,
            setTrainImpleVisible: false,
            //安全附件信息
            newDetails: "",
            //维保信息
            basicInformation: "",
            maintenanceTit: "上传维保信息",

            //查看全部信息
            allTheInformation: false,
            informationDate: "设备信息",
            selectRowData: {},
            //编辑维保信息
            editorMain: "编辑维保信息",
            //选项卡
            options: [
                {
                    name: "风险辨识记录",
                    key: "1",
                },
                {
                    name: "风险告知卡",
                    key: "2",
                },
                {
                    name: "检查表",
                    key: "3",
                },
                {
                    name: "安全操作规程",
                    key: "4",
                },
            ],
            num: 0,
            getCode: "",
            multipleSelection: [],

            //维保信息编辑
            newFormInline: {},
            getMainCode: "",
            //安全附件列表
            secureAttachmentList: [],
            attacHandleTitle: "新增",
            attacHandleForm: {},
            noImgUrl: require("@/assets/images/no-img.png"),
            opType: null,
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload",
        };
    },
    created() {
        this.initParams();
    },
    mounted() {
        this.search();
    },
    watch: {
        // "form.equipmentType"(newVal, oldVal) {
        //     if (newVal == 'true') {
        //         if ( this.opType == "update") {
        //             this.updateInfoList(1)
        //         } else {
        //             this.updateInfoList(this.form.equipmentCount)
        //         }
        //     }  else {
        //         this.form.specialEquipmentList = []
        //     }
        // },
        "form.equipmentCount"(newVal, oldVal) {
            if (newVal !== oldVal && this.opType != "update") {
                this.updateInfoList(newVal)
            }
        }
    },
    methods: {
        // 更新信息列表的函数
        updateInfoList(count) {
            let _this = this;
            if (_this.form.specialEquipmentList.length == 0) {
                for (var i = 0; i < count; i++) {
                    _this.form.specialEquipmentList.push({
                        equipmentNumber: "",
                        registerDate: "",
                        registerCertificateFile: [],
                        equipmentSpecialCheckFile: [],
                        equipmentSpecialCheckReportFile: []
                    });
                }
            } else {
                if (count < _this.form.specialEquipmentList.length) {
                    _this.form.specialEquipmentList.splice(count);
                } else {
                    for (var i = _this.form.specialEquipmentList.length; i < count; i++) {
                        _this.$set(
                            _this.form.specialEquipmentList,
                            i,
                            {
                                equipmentNumber: "",
                                registerDate: "",
                                registerCertificateFile: [],
                                equipmentSpecialCheckFile: [],
                                equipmentSpecialCheckReportFile: []
                            }
                        )
                    }
                }
            }
        },
        handleExport() {
            this.common.handleExport(
                this.loading(),
                "F00002",
                "",
                this.$route.query.enterpriseCode || ""
            );
        },
        toggleSelection(rows) {
            if (rows) {
                rows.forEach((row) => {
                    this.$refs.multipleTable.toggleRowSelection(row);
                });
            } else {
                this.$refs.multipleTable.clearSelection();
            }
        },
        ellipsis(value, len) {
            if (!value) return "";
            if (value.length > len) {
                return value.slice(0, len) + "...";
            }
            return value;
        },
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    //"danger_check_plan_type",
                    _this.constParams.site_equipment_secure_attach,
                    _this.constParams.fire_frequency,
                ],
                function (res) {
                    // _this.checkType = res.data.filter(
                    //     p => p.paramId === "danger_check_plan_type"
                    // );
                    // _this.params.checkType = res.data.filter(
                    //     p => p.paramId === "danger_check_plan_type"
                    // );
                    // _this.params.checkType.splice(0, 0, {
                    //     id: "",
                    //     name: "不限"
                    // });
                    _this.params.equipmentSecureAttach = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.site_equipment_secure_attach
                    );
                    _this.params.frequency = res.data.filter(
                        (p) => p.paramId === _this.constParams.fire_frequency
                    );
                }
            );
        },
        search() {
            this.$refs.EaglePage.search();
        },
        handleUpdate(row) {
            this.opType = "update";
            this.$refs.EagleForm.handleUpdate(row);
        },
        //查询条件重置
        resetQuery() {
            //this.conditions.checkType.value = "";
            this.conditions.equipmentName.value = "";
            this.search();
        },
        //设施设备新增
        handleAdd() {
            this.opType = "add";
            this.$refs.EagleForm.handleAdd(null);
        },

        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        handleImport() {
            this.$refs.EagleDialogExce.show();
        },
        // /** 导出按钮操作 */
        // handleExport() {
        //     download(
        //         this.controller + "/export",
        //         {
        //             ...this.queryParams,
        //         },
        //         `设备设施管理.xlsx`
        //     );
        // },
        bindData(data) {
            this.form = data;
            this.form.equipmentType = 'true'
            if (this.opType == 'add') {
                this.form.specialEquipmentList = []
            }
            this.updateInfoList(1)
        },

        /** 点击设置更多操作 */
        setForMoreInformation() {
            this.forMoreInformation = !this.forMoreInformation;
        },
        //复制
        setCopy() {
            return;
        },
        //查看全部信息
        viewAllInformation(row) {
            var _this = this;
            _this.allTheInformation = true;
            _this.selectRowData = row;
            setTimeout(() => {
                _this.searchMaintenan(row);
                _this.getAttacHandleFormList(row);
                _this.$set(
                    _this.selectRowData,
                    "frequencyName",
                    _this.getFrequencyName(row.maintenanceFrequency)
                );
            }, 1000);
        },
        onDateChange(row) {
            var _this = this;
            var url = "";
            _this.http.postLoading(
                _this.loading(),
                `/ecologyEnv/entEquipment/save`,
                row,
                function (res) {
                    _this.$emit("afterSave");
                    _this.search();
                    _this.visible = false;
                }
            );

            // _this.http.post(`/site/entEquipment/save`, row).then(res => {
            //     if (res.code === 200) {
            //         _this.$emit("afterSave");
            //         _this.search();
            //         _this.visible = false;
            //     } else {
            //         _this.msgError("保存失败!");
            //     }
            // });
        },
        getSuplusDate(deadline) {
            var now = new Date();
            let day = 0;
            day = this.getDaysBetween(now, deadline);
            if (day >= 0) {
                var color = "#1990FE";
                if (day < 30) {
                    color = "#E6A23C";
                }
                return `<span style='color:${color}'>还剩${day}天</span>`;
            } else {
                return `<span style='color:#F56C6C'>逾期${day * -1}天</span>`;
            }
        },
        getDaysBetween(date1, date2) {
            date2 = date2.replace(/-/g, "/");
            var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));
            var endDate = Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        //登记附件
        registration(row) {
            var _this = this;
            var config = {};
            config.equipmentName = row.equipmentName;
            config.equipmentModel = row.equipmentModel;
            config.locationName = row.locationName;
            config.mainCode = row.code;
            this.$refs.entSafetyAttachs.show(config);
        },
        //维保信息
        maintenance(row) {
            var _this = this;
            var config = {};
            config.equipmentName = row.equipmentName;
            config.equipmentModel = row.equipmentModel;
            config.mainCode = row.code;
            config.locationName = row.locationName;
            config.maintenanceAttention = row.maintenanceAttention;
            config.maintenanceFrequencyName = _this.getFrequencyName(
                row.maintenanceFrequency
            );
            config.maintenanceFrequency = row.maintenanceFrequency;
            _this.$refs.entMaintenance.show(config);
        },
        getFrequencyName(frequency) {
            var frequencyName = "";
            if (frequency) {
                var tempArray = this.params.frequency.filter(
                    (x) => x.id == frequency
                );
                if (tempArray && tempArray.length > 0) {
                    frequencyName = tempArray[0].name;
                }
            }
            return frequencyName;
        },
        setOptions(v) {
            this.num = v;
        },
        searchMaintenan(row) {
            var queryParams = {};
            queryParams.mainCode = row.code;
            var conditions = [];
            //conditions: [{"name":"equipmentName","operate":"like","value":"笔记本"}]
            // conditions.push({
            //     name: "mainCode",
            //     operate: "=",
            //     value: row.code
            // });
            this.$refs.EaglePagesMaintenan.search({
                url: this.maintenanceUrl + "/getPageData",
                params: queryParams,
            });
        },
        getAttacHandleFormList(row) {
            var _this = this;
            var url = "ecologyEnv/attach/getListData?mainCode=" + row.code;
            _this.http.postLoading(
                _this.loading(),
                url,
                this.queryParams,
                function (res) {
                    _this.secureAttachmentList = res.data;
                }
            );
            // _this.http.post(url, this.queryParams).then(res => {
            //     _this.secureAttachmentList = res.data;
            // });
        },
        cancel(data) {
            this.$refs.EagleForm.cancel();
        },
        submitForm() {
            let _this = this
            if (_this.form.equipmentType == 'false') {
                delete _this.form.specialEquipmentList
            }
            let config = {};
            if (_this.opType == "update") {
                config.url = `/ecologyEnv/entEquipment/save`;
            } else {
                config.url = `/ecologyEnv/entEquipment/saveEquipment`;
            }
            _this.$refs.EagleForm.submitForm(config);
        },
        afterSaveInfo() {
            this.search();
        },
        setUpAttachs(row) {
            //设备资料上传
            this.selectRowData = row;
            this.$refs.EagleFormAttach.handleAdd(null);
        },
        cancelAttach() {
            this.$refs.EagleFormAttach.cancel();
        },
        saveAttach() {
            if (!this.selectRowData.attachs) {
                this.msgError("请上传设备资料!");
                return;
            }
            let config = {
                url: `/ecologyEnv/entEquipment/saveEquipment`,
            };
            this.$refs.EagleFormAttach.submitForm(config);
        },
        openmaintenanceTemp() {
            this.$refs.equipmentMaintenance.show();
        },
        handleMaintenanceSubmit(item) {
            // this.form.maintenanceAttention = item.content ?? "";
            if (this.form.maintenanceAttention) {
                this.form.maintenanceAttention = "";
            }
            for (var i = 0; i < item.length; i++) {
                this.form.maintenanceAttention =
                    this.form.maintenanceAttention.concat(
                        i + 1 + ": ",
                        item[i].content ? item[i].content : "",
                        "\r\n"
                    );
            }
        },
        handleUploadSuccess(res, file, row) {
            let _this = this;
            var rowData = row;

            rowData.equipmentPhoto = res.data.filePath;
            _this.http.postLoading(
                _this.loading(),
                "ecologyEnv/entEquipment/save",
                rowData,
                function (res) {
                    _this.msgSuccess("更新成功");
                }
            );
        },
        handleDelbatch() {
            var _this = this;

            var selectRows = _this.$refs.EaglePage.getSelection();
            if (!selectRows || selectRows.length < 1) {
                this.$message.error("请选择要删除的数据!");
                return false;
            }
            var ids = selectRows.map((item) => item.id);

            _this.$refs.EaglePage.handleMultDelete(ids.join(), function (res) {
                _this.refresh();
            });
        },
        afterSave(res, action) {
            if (action == "edit") {
                this.$refs.EaglePage.refresh();
            } else {
                this.$refs.EaglePage.search();
            }
        },
    },
};
</script>
<style lang="scss" scoped >
.special_div {
    border: 1px solid #d2d2e6;
    width: 100%;
    padding: 6px 12px 12px;
    border-radius: 6px;
    margin-bottom: 12px;
    .title {
        color: #1890FF;
        font-size: 16px;
        font-weight: 600;
    }
}
.detail_div {
    padding: 0 12px 4px !important;
    .title {
        margin: 6px 0 !important;
    }
}
// .div_ent_equipment_app-containe {
//     .eagle-condition {
//         ::v-deep.el-form--inline .el-form-item {
//             margin-bottom: 0px;
//         }
//     }

//     ::v-deep .setFilter .el-form-item__content {
//         width: 250px;
//     }

//     .enterprise {
//         display: flex;
//         margin-bottom: 0;
//     }

//     ::v-deep .enterprise .el-input__inner {
//         width: 250px;
//     }

//     .divTitle {
//         text-align: right;
//         padding-right: 10px;

//         span {
//             font-size: 14px;
//             color: #606266;
//             font-weight: 700;
//         }
//     }

//     span {
//         line-height: 28px;
//     }

//     .attachmentJudge {
//         margin: 0;
//     }

//     .enterprise_fxd {
//         font-size: 15px;
//         font-weight: 600;
//         color: #1684fc;
//         /* margin-left: 15px; */
//         cursor: pointer;
//         border: none;
//         margin-bottom: 2px;
//         background: none;
//     }

//     .enterprise_building {
//         display: flex;
//         margin: 0;
//     }

//     ::v-deep .enterprise_building .el-input__inner {
//         width: 190px;
//     }

//     .enterprise_content {
//         margin-bottom: 0;
//     }

//     ::v-deep .enterprise_content .el-textarea__inner {
//         width: 480px;
//     }

//     .enterprise_con {
//         display: flex;
//     }

//     .enterprise_btn {
//         float: right;
//         color: #1684fc;
//         background: none;
//         border: none;
//         cursor: pointer;
//     }

//     .details {
//         &_tit {
//             font-weight: 600;
//             // color: coral;
//             font-size: 16px;
//         }

//         &_x {
//             width: 100%;

//             //    display: flex;
//             //    justify-content: space-between;
//             span {
//                 width: 250px;
//                 height: 35px;
//                 line-height: 35px;
//                 display: inline-block;
//                 margin-left: 100px;
//                 font-weight: 600;
//             }
//         }
//     }

//     .maintenance_top {
//         margin: 5px 0 0 5px;
//         height: 350px;
//         border: 1px solid #bababa;
//         font-size: 14px;
//         font-weight: 600;

//         &_t {
//             display: flex;
//             justify-content: space-around;
//             height: 40px;
//             line-height: 40px;
//         }

//         &_p {
//             margin-bottom: 10px;
//             display: flex;

//             &_a {
//                 width: 40%;
//                 margin-left: 38px;
//                 display: inline-block;
//                 display: flex;

//                 span {
//                     display: inline;
//                 }

//                 img {
//                     width: 160px;
//                     height: 160px;
//                     // background: #aaa;
//                 }
//             }

//             &_b {
//                 display: flex;
//                 width: 50%;
//                 display: inline-block;
//                 margin-left: 10px;
//                 display: flex;

//                 .equipmentDate {
//                     width: 80%;
//                     height: 160px;
//                     display: inline-block;
//                     border: 1px solid #aaa;
//                 }
//             }
//         }

//         &_s {
//             display: flex;
//             margin-bottom: 10px;

//             &_a {
//                 margin-left: 35px;
//             }

//             &_b {
//                 display: inline-block;
//                 width: 82%;
//                 height: 100px;
//                 border: 1px solid #aaa;
//             }
//         }

//         &_c {
//             margin-left: 60px;
//         }
//     }

//     .divForm {
//         ::v-deep.el-form-item {
//             width: 100%;
//         }

//         ::v-deep.el-select {
//             width: 100%;
//         }
//     }

//     .maintenance_center {
//         margin: 5px;
//         height: 400px;
//         border: 1px solid #bababa;
//     }

//     .maintenance_cen {
//         margin: 5px 0 0 5px;
//         height: 300px;
//         border: 1px solid #bababa;
//     }

//     .setOptions {
//         &_op {
//             width: 100%;
//             list-style: none;
//             display: flex;

//             li {
//                 width: 100px;
//                 height: 20px;
//                 line-height: 20px;
//                 text-align: center;
//                 cursor: pointer;
//             }
//         }
//     }

//     .maintenance_contents {
//         margin: 5px 0 0 5px;
//         border: 1px solid #bababa;
//         height: 350px;
//     }

//     .setRegistration {
//         background: none;
//         border: none;
//         color: #1890ff;
//         cursor: pointer;
//     }

//     .form-title {
//         margin-top: 15px;

//         span:nth-of-type(1) {
//             line-height: 36px;
//             font-weight: bold;
//         }

//         .mustField {
//             color: red;
//             line-height: 36px;
//         }
//     }

//     .maintenance_bottom {
//         height: 350px;

//         &_tit {
//             font-size: 15px;
//             font-weight: 600;
//             color: #000;
//         }
//     }

//     .setFontWeight {
//         font-weight: 900;
//     }

//     .setBottom {
//         border-bottom: 2px solid #1684fc;
//     }

//     .div-table {
//         border-bottom: 0px;
//     }

//     .div-table ::v-deep.el-card__body {
//         padding: 0px 0px;
//     }
// }
//
</style>
