<template>
  <div class="app-container div_ent_post_certificate layer">

    <eagle-page :queryParams="queryParams" style="margin-top:10px;width: 100%;" :conditions="conditions"
                :controller="controller" @bindSelection="bindSelection" ref="EaglePage" :showCheckColumn="true">
      <template slot="slot-search">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
          <eagle-select label-width="50px" @change="search()" label="状态" prop="status"
                        v-model="conditions.status.value" :dataSource="params.status" size="small"/>
          <eagle-input label-width="80px" label="筛选条件" @changeEnter="search" :required="false" prop="name"
                       v-model="conditions.name.value" placeholder="请输入姓名" clearable size="small"/>

        </eagle-condition>
      </template>
      <template slot="slot-buttons">
        <el-col :span="1.5">
          <el-popover
            placement="top-start"
            width="200"
            trigger="hover"
            content="根据企业四色分级管理评分规则，主要负责人、安全管理员未经考核合格就上岗的或证过期，每缺少或过期1个减10分；未设置特种设备安全管理人员，不得分；特种设备作业人员、安全管理人员证书过期，过期1个减10分">
            <el-button
              icon="el-icon-warning-outline"
              slot="reference"
              type="text"
              key="text"
            >评分规则
            </el-button
            >
          </el-popover>
        </el-col>
        <el-button type="primary" icon="el-icon-plus" size="mini" @click="handleAdd">新增</el-button>
        <el-button icon="el-icon-delete" size="mini" type="danger" @click="handleDelbatch">批量删除</el-button>
        <!--                <el-button icon="el-icon-upload2" size="mini" type="primary" @click="handleImport">导入</el-button>-->
        <el-button icon="el-icon-download" size="mini" type="primary" @click="handleExport">导出
        </el-button>
      </template>
      <template slot="slot-table">
        <el-table-column label="证书名称" prop="certificateName" width="150px"/>
        <el-table-column label="姓名" prop="name" width="150px"/>
        <!--        <el-table-column label="部门" prop="organName" width="150px"/>-->
        <!--        <el-table-column label="岗位" prop="postName" width="150px"/>-->
        <el-table-column label="证书类型" prop="certificateType" width="150px">
          <template slot-scope="scope">
            <span v-for="item in params.certKind" :key="item.id">
              <span v-if="scope.row.certificateType === item.id">{{ item.name }}</span>
            </span>
          </template>
        </el-table-column>

        <el-table-column label="初领日期" prop="certificateFirstGetDate" width="150px">
          <template slot-scope="scope">
            <span>{{ parseTime(scope.row.certificateFirstGetDate, "{y}-{m}-{d}") || "--" }}</span>
          </template>
        </el-table-column>

        <el-table-column label="证书有效期" prop="certificateValidityDate" width="230px">
          <template slot-scope="scope">
            <span>{{
                parseTime(scope.row.certificateValidityDateRangeList[0] ? scope.row.certificateValidityDateRangeList[0] : '', "{y}-{m}-{d}") || "--"
              }} 至 {{
                parseTime(scope.row.certificateValidityDateRangeList[1] ? scope.row.certificateValidityDateRangeList[1] : '', "{y}-{m}-{d}") || "--"
              }}</span>
            <!--             <span>{{ parseTime(scope.row.certificateValidityDate, '{y}-{m}-{d}') }}</span>-->
          </template>
        </el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <div v-html="getSuplusDate(scope.row)">
            </div>
          </template>
        </el-table-column>
        <el-table-column label="录入人" prop="createChnName" width="150px"/>
        <el-table-column label="录入时间" prop="createDate" width="150px"/>
        <!--        <el-table-column label="证书照片" prop="attachs" width="150px">-->
        <!--          <template slot-scope="scope">-->
        <!--            <div style="display:flex;flex-direction: row;">-->
        <!--              <el-upload class="upload-demo" :headers="headers" :show-file-list="false" :action="uploadUrl"-->
        <!--                         :on-success="function (res, file) { return handleUploadSuccess(res, file, scope.row) }"-->
        <!--                         :multiple="false">-->
        <!--                <eagle-row-button-text imageValue="upload" size="small" type="text">上传-->
        <!--                </eagle-row-button-text>-->
        <!--              </el-upload>-->
        <!--              <eagle-row-image v-model="scope.row.attachs"></eagle-row-image>-->
        <!--            </div>-->
        <!--          </template>-->
        <!--        </el-table-column>-->

      </template>
      <template slot="slot-row-buttons" slot-scope="scope">
        <eagle-row-button type="primary" size="mini" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>
        <eagle-row-button type="danger" size="mini" @click.stop="handleDelete(scope.row)">删除</eagle-row-button>
      </template>
    </eagle-page>

    <eagle-form :controller="controller" :title="title" :form="form" width="1000px" label-width="120px" ref="EagleForm"
                @afterSave="afterSave" @bindData="bindData">

      <eagle-block border>
        <el-row>
          <el-col :span="12">
            <eagle-input label="证书名称" v-model.trim="form.certificateName" prop="certificateName"
                         required></eagle-input>
            <div style=" margin-bottom: 10px;">
              <span style="color:#1890ff;margin-left:80px;margin-right:12px;">快选</span>
              <el-tag size="mini" style="margin-right: 10px; cursor:pointer;" @click.stop="fastChoose('main')">
                主要负责人证
              </el-tag>
              <el-tag size="mini" style="margin-right: 10px; cursor:pointer;" @click.stop="fastChoose('high')">
                高压电工证
              </el-tag>
              <el-tag size="mini" style="margin-right: 10px; cursor:pointer;" @click.stop="fastChoose('low')">
                低压电工证
              </el-tag>
            </div>
          </el-col>
          <el-col :span="12">
            <eagle-date label="证书有效期 " :isDaterange="true" v-model.trim="form.certificateValidityDateRangeList"
                        type="daterange"
                        prop="certificateValidityDateRangeList"
                        @change="changeRangeDate"
                        required></eagle-date>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <eagle-date label="证书初领日期" v-model.trim="form.certificateFirstGetDate" prop="certificateFirstGetDate"
                        required></eagle-date>
          </el-col>
          <el-col :span="12">
            <!--                    <eagle-date label="证书类型" v-model.trim="form.certificateValidityDate" prop="certificateValidityDate" required></eagle-date>-->
            <eagle-select label-width="120px" label="证书类型" required prop="certificateType"
                          @change="hdChangeResType" v-model="form.certificateType" :data-source="params.certKind"
                          clearable size="small"/>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <eagle-input label="姓名" v-model.trim="form.name" prop="name" required></eagle-input>
          </el-col>
          <el-col :span="12">
            <eagle-input label="岗位" v-model.trim="form.postName" prop="postName"></eagle-input>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <eagle-input label="部门" v-model.trim="form.organName" prop="organName">
            </eagle-input>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <eagle-input type="textarea" label="备注" v-model.trim="form.remarks" prop="remarks">
            </eagle-input>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <eagle-image label="证书照片" v-model.trim="form.attachs" prop="attachs"></eagle-image>
          </el-col>
        </el-row>
      </eagle-block>
    </eagle-form>

    <eagle-dialog-exce title="特殊岗位证书表格" ref="EagleDialogExce" :url="controller" fileName="certificate.xlsx"
                       @refresh="refresh"></eagle-dialog-exce>
  </div>
</template>

<script>
import eagleDate from "@/components/Eagle/eagle-date.vue";
import EagleDialogExce from "@/components/Eagle/eagle-dialog-exce.vue";
import {getToken} from "@/utils/auth";

export default {
  components: {eagleDate, EagleDialogExce},
  name: "ent-post-certificate",
  data() {
    return {
      fileList: [],
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        planname: "like",
      },
      // 查询条件
      conditions: {
        name: {
          value: "",
        },
        status: {
          value: "0",
        },
      },
      controller: "ecologyEnv/entPostCertificate",
      // 弹出层标题
      title: "特殊岗位证书",
      params: {
        status: [
          {id: "0", name: "不限"},
          {id: "20", name: "已过期"},
          {id: "30", name: "三个月内到期"},
          {id: "10", name: "正常"},
        ],
        certKind: [],
      },

      queryParams: {
        dataType: "list",
      },
      // 表单参数
      form: {},
      headers: {
        Authorization: "Bearer " + getToken(),
      },
      uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload",
    };
  },
  created() {
    this.initData();
  },
  mounted() {
    this.search();
  },
  methods: {
    handleExport() {
      this.common.handleExport(
        this.loading(),
        "F00004",
        "",
        this.$route.query.enterpriseCode || ""
      );
    },
    resetAttachs(attachs) {
      return `<span style='color:#1890ff'>${attachs}</span>`;
    },
    initData() {
      let _this = this;
      _this.common.getBatechParam(
        ['cert_type'],
        function (res) {
          _this.params.certKind = res.data.filter(
            (p) => p.paramId === 'cert_type'
          );
          console.log(_this.params.certKind)
        }
      );
    },
    changeRangeDate(e) {
      if (e.length > 0) {
        this.form.certificateValidityDateStart = e[0];
        this.form.certificateValidityDate = e[1];
      }
    },
    hdChangeResType() {
      // this.form.hdChangeResType = this.formateDict(
      //   this.params.certKind,
      //   this.form.hdChangeResType,
      //   "id"
      // );
    },
    bindData(data) {
      this.form = data;
    },

    /** 新增按钮操作 */
    handleAdd() {
      this.$refs.EagleForm.handleAdd(null);
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      let obj = JSON.parse(JSON.stringify(row));
      this.$refs.EagleForm.handleUpdate(obj);
    },
    bindSelection(selection) {
      this.ids = selection.map((item) => item.id);
      this.single = selection.length != 1;
      this.multiple = !selection.length;
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      var _this = this;
      this.$refs.EaglePage.handleDelete(row, function (res) {
        _this.refresh();
      });
    },
    handleImport() {
      this.$refs.EagleDialogExce.show();
    },
    //刷新
    refresh() {
      this.$refs.EaglePage.refresh(null);
    },
    updatefile(data) {
      let _this = this;
      _this.http
        .post(
          "/site/entPostCertificate/updateEntPostCertificateFile",
          data
        )
        .then(function (res) {
          _this.msgSuccess("上传成功");
          _this.search();
        });
    },
    search() {
      this.$refs.EaglePage.search();
    },
    //查询条件重置
    resetQuery() {
      this.conditions.name.value = "";
      this.conditions.status.value = "0";
      this.search();
    },
    fastChoose(action) {
      switch (action) {
        case "main":
          this.form.certificateName = "主要负责人证";
          break;
        case "high":
          this.form.certificateName = "高压电工证";
          break;
        case "low":
          this.form.certificateName = "低压电工证";
          break;
      }
    },
    handleUploadSuccess(res, file, row) {
      let _this = this;
      var rowData = row;

      rowData.attachs = res.data.filePath;
      _this.http.postLoading(
        _this.loading(),
        "site/entPostCertificate/save",
        rowData,
        function (res) {
          _this.msgSuccess("更新成功");
        }
      );
    },
    getSuplusDate(row) {
      // 有效期-当前日期
      if (row.statusName == '三个月内到期') {
        return `<span style='color:#E6A23C'>三个月内到期</span>`;
      } else if (row.statusName == '正常') {
        return `<span style='color:#1990FE'>正常</span>`;
      } else if (row.statusName == '已过期') {
        return `<span style='color:#F56C6C'>已过期</span>`;
      }

    },
    getDaysBetween(date1, date2) {
      date2 = date2.replace(/-/g, "/");
      var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));
      var endDate = Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
      var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
      return days > 0 ? parseInt(days) : parseInt(days);
    },
    handleDelbatch() {
      var _this = this;

      var selectRows = _this.$refs.EaglePage.getSelection();
      if (!selectRows || selectRows.length < 1) {
        this.$message.error("请选择要删除的数据!");
        return false;
      }
      var ids = selectRows.map((item) => item.id);

      _this.$refs.EaglePage.handleMultDelete(ids.join(), function (res) {
        _this.refresh();
      });
    },
    afterSave(res, action) {
      if (action == "edit") {
        this.$refs.EaglePage.refresh();
      } else {
        this.$refs.EaglePage.search();
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.div_ent_post_certificate {
  .eagle-condition {
    ::v-deep.el-form-item__label {
      width: auto;
    }
  }
}
</style>
