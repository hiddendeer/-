<template>
  <div class="app-container">
    <div class="layer">
      <eagle-page :controller="controller" ref="EaglePage" :showCheckColumn="true" btn-width="140px"
                  :conditions="conditions">
        <template slot="slot-search">
          <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <!-- <eagle-radio @change="search()"   label-width="50px" label="类型" prop="checkType" v-model="conditions.checkType.value" :dataSource="params.checkType" size="small" /> -->
            <eagle-input class="setFilter" label-width="80px" @changeEnter="search()" label="筛选条件"
                         prop="checkTaskName" v-model="conditions.name.value" placeholder="请输入相关方名称进行模糊搜索"
                         clearable size="small"/>
          </eagle-condition>
        </template>
        <template slot="slot-buttons">
          <el-row :gutter="10" class="mb8">
            <el-col :span="1.5">
              <el-button type="primary" icon="el-icon-plus" size="mini" @click="handleAdd">新增</el-button>
              <!-- <el-button icon="el-icon-download"  size="mini" type="info" @click="handleImport">导入</el-button> -->
              <!-- <el-button type="primary"  icon="el-icon-upload2" size="mini" @click="handleExport">导出记录</el-button>
          <el-button type="primary"  icon="el-icon-menu" size="mini" @click="management">批量管理</el-button>
          <el-button type="primary"  icon="el-icon-refresh" size="mini" @click="refresh">刷新</el-button> -->
            </el-col>
            <el-col :span="1.5">
              <el-button icon="el-icon-delete" size="mini" type="danger" @click="handleDelbatch">批量删除
              </el-button>
            </el-col>
            <el-col :span="1.5">
              <el-button icon="el-icon-upload2" size="mini" type="primary" @click="handleImport">导入
              </el-button>
            </el-col>
            <el-col :span="1.5">
              <el-button icon="el-icon-download" size="mini" type="primary" @click="handleExport">导出
              </el-button>
            </el-col>
          </el-row>
        </template>
        <template slot="slot-table">
          <el-table-column label="相关方名称" align="left" prop="name" width="220px"/>
          <el-table-column label="类型" align="left" prop="relateType" width="150px">
            <template slot-scope="scope">
              <span>{{ formateDict(params.relatedType, scope.row.relateType) }}</span>
            </template>
          </el-table-column>
          <el-table-column label="服务说明" align="left" prop="serviceDetail" width="350px"/>
          <el-table-column label="联系人" align="left" prop="contactPerson" width="150px"/>
          <el-table-column label="电话" align="left" prop="contactPhone" width="150px"/>
          <el-table-column label="安全协议" align="left" prop="secureProtocol">
            <template slot-scope="scope">
              <eagle-row-attach v-model="scope.row.secureProtocol"></eagle-row-attach>
            </template>
          </el-table-column>
        </template>
        <template slot="slot-row-buttons" slot-scope="scope">
          <eagle-row-button type="primary" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>
          <eagle-row-button type="danger" @click.stop="handleDelete(scope.row)">删除</eagle-row-button>
        </template>
      </eagle-page>

      <eagle-form :controller="controller" title="相关方信息" :form="form" width="700px" label-width="100px"
                  ref="EagleForm" @afterSave="afterSave" @bindData="bindData">
         
        <eagle-block border>
          <el-row>
            <eagle-input label="相关方名称" required prop="name" v-model="form.name"></eagle-input>
          </el-row>
          <el-row>
            <eagle-radio required label="类型" v-model="form.relateType" @change="relateTypeCall" prop="relateType"
                         :data-source="params.relatedType"></eagle-radio>
          </el-row>
          <el-row>
            <eagle-input label="服务说明" type="textarea" v-model="form.serviceDetail" prop="serviceDetail">
            </eagle-input>
          </el-row>
          <el-row>
            <eagle-input label="联系人" v-model="form.contactPerson" required prop="contactPerson">
            </eagle-input>
          </el-row>
          <el-row>
            <eagle-input label="联系电话" v-model="form.contactPhone" required prop="contactPhone">
            </eagle-input>
          </el-row>
          <el-row>
            <eagle-attach label="安全协议" v-model="form.secureProtocol" prop="secureProtocol"></eagle-attach>
          </el-row>
          <el-row>
            <eagle-attach label="其他附件" v-model="form.attachs" prop="attachs"></eagle-attach>
          </el-row>
        </eagle-block>
      </eagle-form>
      <eagle-dialog-exce title="相关方表格" ref="EagleDialogExce" :url="controller" fileName="relation.xlsx"
                         @refresh="refresh"></eagle-dialog-exce>
    </div>
  </div>
</template>

<script>
import EagleDialogExce from "@/components/Eagle/eagle-dialog-exce.vue";
import { download } from "@/utils/request"

export default {
  components: { EagleDialogExce },
  name: "ent-relation",
  data() {
    return {
      controller: "site/relation",
      conditions: {
        name: { value: "", operate: "like" },
      },
      queryParams: {
        dataType: "list",
      },
      checkType: [],
      params: {
        checkType: [],
        relatedType: [], //相关类型
      },
      form: {},
      setType: "请输入相关类型",
    };
  },
  created() {
    this.initParams();
  },
  mounted() {
    this.search();
  },
  methods: {
    handleExport() {
      this.common.handleExport(
        this.loading(),
        "F00008",
        "",
        this.$route.query.enterpriseCode || ""
      );
    },
    initParams() {
      let _this = this;
      _this.common.getBatechParam(
        [
          "danger_check_plan_type",
          _this.constParams.site_relation_type,
        ],
        function ( res ) {
          _this.checkType = res.data.filter(
            ( p ) => p.paramId === "danger_check_plan_type"
          );
          _this.params.checkType = res.data.filter(
            ( p ) => p.paramId === "danger_check_plan_type"
          );
          _this.params.checkType.splice(0, 0, {
            id: "",
            name: "不限",
          });
          _this.params.relatedType = res.data.filter(
            ( p ) =>
              p.paramId === _this.constParams.site_relation_type
          );
        }
      );
    },
    search() {
      this.$refs.EaglePage.search();
    },
    //查询条件重置
    resetQuery() {
      this.conditions.name.value = "";
      this.search();
    },
    handleAdd() {
      this.$refs.EagleForm.handleAdd(null);
    },
    /** 删除按钮操作 */
    handleDelete( row ) {
      var _this = this;
      this.$refs.EaglePage.handleDelete(row, function ( res ) {
        _this.refresh();
      });
    },
    handleUpdate( row ) {
      this.$refs.EagleForm.handleUpdate(row);
    },
    // pushPlan(code) {
    //     let _this = this;
    //     let url = `${this.controller}/pushPlan/${code}`;
    //     _this.http.post(url).then(function (res) {
    //         _this.search();
    //     });
    // },
    /** 导出按钮操作 */
    // handleExport() {
    //     download(
    //         this.controller + "/export",
    //         {
    //             ...this.queryParams,
    //         },
    //         `相关方.xlsx`
    //     );
    // },
    //导入
    handleImport() {
      this.$refs.EagleDialogExce.show();
    },
    bindData( data ) {
      this.form = data;
    },
    //刷新
    refresh() {
      this.$refs.EaglePage.refresh(null);
    },
    //批量管理
    management() {
      console.log("批量管理");
    },
    relateTypeCall( data, a ) {
    },
    handleDelbatch() {
      var _this = this;

      var selectRows = _this.$refs.EaglePage.getSelection();
      if (!selectRows || selectRows.length < 1) {
        this.$message.error("请选择要删除的数据!");
        return false;
      }
      var ids = selectRows.map(( item ) => item.id);

      _this.$refs.EaglePage.handleMultDelete(ids.join(), function ( res ) {
        _this.refresh();
      });
    },
    afterSave( res, action ) {
      if (action == "edit") {
        this.$refs.EaglePage.refresh();
      } else {
        this.$refs.EaglePage.search();
      }
    },
  },
};
</script>
<style scoped>
::v-deep .setFilter .el-form-item__content {
  width: 250px;
}

.enterprise {
  /* display: flex; */
  margin-bottom: 0;
}
</style>
