<template name="eagle-dialog-ledger-temp-online-world-template">
    <el-dialog v-dialogDrag :title="title" :visible.sync="showDialog" width="800px" append-to-body show-close
        :close-on-click-modal="false">
        <eagle-block border>
            <eagle-window-choose :queryParams="queryParams" :controller="controller" ref="EaglePage" table-height="500" :single="single"
                selectTextField="docName" selectField="code">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="docName"
                            v-model="conditionsVals.docName" placeholder="请输入报表名称进行模糊查询" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-table">
                    <el-table-column label="报表名称" align="left" prop="docName" />
                    <el-table-column label="报表应用场景描述" align="left" prop="docDesc" />
                    <el-table-column label="类型" align="left" prop="docType" width="120">
                        <template slot-scope="scope">
                            <span>{{ formateDict(params.docType, scope.row.docType + "") }}</span>
                        </template>
                    </el-table-column>
                </template>
            </eagle-window-choose>
        </eagle-block>
        <span slot="footer" class="dialog-footer">
            <el-button @click="showDialog = false">取 消</el-button>
            <el-button type="primary" @click="handleChoose">确 定</el-button>
        </span>
    </el-dialog>
</template>

<script>
export default {
    name: "eagle-dialog-ledger-temp-online-world-template",
    components: {},
    props: {
        single: { type: Boolean, default: true },
    },
    data() {
        return {
            queryParams: { dataType: "ledgerTempList" },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                docName: "like",
            },
            // 查询条件
            conditionsVals: {
                docName: "",
            },
            controller: "ecologyEnv/fileWordTempDoc", //对应后端控制器
            title: "选择word模板",
            showDialog: false,
            params: {
                fileOnlineTempDocType: [],
                docType: [],
            },
        };
    },
    created() {
        this.initData();
    },
    methods: {
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.file_online_temp_doc_type,
                    _this.constParams.doc_type,
                ],
                function (res) {
                    _this.params.fileOnlineTempDocType = res.data.filter(
                        p =>
                            p.paramId ===
                            _this.constParams.file_online_temp_doc_type
                    );
                    _this.params.docType = res.data.filter(
                        p => p.paramId === _this.constParams.doc_type
                    );
                }
            );
        },
        handleChoose(obj) {
            let chooseObj = this.$refs.EaglePage.selection;
            if (!chooseObj || chooseObj.length <= 0) {
                this.msgError("请选择服务类型");
                return;
            }
            let data = {};
            if (this.single) {
                data.code = chooseObj[0].code;
                data.name = chooseObj[0].docName;
            } else {
                let arryCode = [];
                let arryName = [];
                chooseObj.forEach((element) => {
                    arryCode.push(element.code);
                    arryName.push(element.docName);
                });
                data.code = arryCode.join(",");
                data.name = arryName.join(",");
            }
            this.$emit("callBack", data);
            this.showDialog = false;
        },
        //查询
        search() {
            setTimeout(() => {
                this.$refs.EaglePage.search({
                    conditions: this.$refs.EaglePage.getCondtions(
                        this.conditionsVals,
                        this.conditionsTypes
                    ),
                });
            });
        },
        resetQuery() {
            this.conditionsVals.docName = "";
            this.search();
        },
        show(code, name) {
            this.showDialog = true;
            setTimeout(() => {
                this.$refs.EaglePage.setInitCodes(code, name);
                this.search();
            });
        },
    },
};
</script>
