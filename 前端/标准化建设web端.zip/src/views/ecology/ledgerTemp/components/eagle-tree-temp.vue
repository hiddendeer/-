<template>
    <div class="ledger-temp-catalogue">
        <div class="tree-title" :title="Title" :style="{ backgroundColor: bgColor ,'font-weight': 600}">{{ ellipsis(this.Title,20) }}</div>
        <el-scrollbar class="scroll" :style="{ 'height': scrollHeight, backgroundColor: bgColor }">
            <el-tree class="tree-line" :data="menuList" node-key="opNo" :expand-on-click-node="false" default-expand-all @node-click="handleTreeClick">
                <span class="custom-tree-node" slot-scope="{ data }">
                    <el-button :title="data.docName" v-if="data.type == 1" type="text" style="color: #666666; font-weight: bold">
                        {{ ellipsis(data.docName, charlen) }}
                    </el-button>
                    <span v-else>
                        <div style="display:inherit;position: relative;"><img style="width:12px;height:13px;position:absolute;top:2px" :src="getIcon(data.type)" alt=""></div>
                        <span :title="data.docName" style="display:inherit;margin-left:20px;font-size: 10px;">{{ ellipsis(data.docName, charlen) }}</span>
                    </span>
                    <!-- </el-tooltip> -->
                    <span v-if="buttonShow" class="operate-btn">
                        <span class="btn-temp " v-if="data.type == 1" @click.stop="addOp(data, 'add')">新增</span>
                        <span class="btn-temp " v-if="data.parentCode && data.type == 1" size="mini" @click.stop="addOp(data, 'edit')">编辑</span>
                        <span class="btn-temp " style="color:red" v-if="!(data.children && data.children.length) && data.parentCode || data.type == 2 " @click.stop="handleDelete(data)">删除</span>
                        <span class="btn-temp el-icon-top" v-if="data.parentCode" @click.stop="handleUpOrder(data)"></span>
                        <span class="btn-temp el-icon-bottom" v-if="data.parentCode" @click.stop="handleDownOrder(data)"></span>
                        <!-- <eagle-row-button>上移</eagle-row-button>
                        <eagle-row-button>下移</eagle-row-button>
                        <eagle-row-button size="mini">新增</eagle-row-button>
                        <eagle-row-button>编辑</eagle-row-button>
                        <eagle-row-button size="mini">删除</eagle-row-button> -->

                    </span>
                    <span v-else>
                        <eagle-row-button size="mini" v-if="!data.parentCode && buttonChangeShow" @click.stop="handleChange">切换</eagle-row-button>
                    </span>

                </span>
            </el-tree>
        </el-scrollbar>
        <eagle-dialog-ledger-temp ref="eagleDialogLedgerTemp" @callBack="handelLedgerChoose"></eagle-dialog-ledger-temp>
        <window-tpldata-temp ref="windowTpldataTemp" @handleSubmitClose="handleSubmitClose"></window-tpldata-temp>
    </div>
</template>
<script>
import { Message, MessageBox } from "element-ui";
import windowTpldataTemp from "./windowTpldataTemp.vue";
import eagleDialogLedgerTemp from "@/views/ecology/components/ledgerTemp/eagle-dialog-ledger-temp.vue";
import { handleTree } from "@/utils/EageleRMC";

export default {
    components: { windowTpldataTemp, eagleDialogLedgerTemp },
    name: "eagle-tree-temp",
    props: {
        Title: {
            type: String,
            default() {
                return "目录";
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        mainNo: {
            type: String,
            default() {
                return "opNo";
            },
        },
        superiorNo: {
            type: String,
            default() {
                return "opPno";
            },
        },
        buttonShow: {
            type: Boolean,
            default() {
                return true;
            },
        },
        buttonChangeShow: {
            type: Boolean,
            default() {
                return true;
            },
        },
        scropWidth: {
            type: String,
            default: "200px",
        },
        scrollHeight: {
            type: String,
            default: "600px",
        },
        bgColor: {
            type: String,
            default: "#fafafa",
        },
        charlen: {
            type: Number,
            default: 8,
        },
    },
    data() {
        return {
            myController: "",
            entrustedBigCatalogName: "",
            entrustedBigCatalogCode: "",
            docName: "",
            isMouseenter: true,
            menuList: [],
            menuData: {},
            opForm: {},
            windowTpDataTitle: "",
            originForm: {},
            origindata: { show: false }, //记录上一次点击的实体    用于清除显示操作状态
        };
    },
    created() {
        // this.geMenuList();
        this.myController = this.controller;
        if (!this.buttonChangeShow) {
            this.geMenuList();
        }
    },
    methods: {
        ellipsis(value, len) {
            if (!value) return "";
            if (value.length > len) {
                return value.slice(0, len) + "...";
            }
            return value;
        },
        mouseenter(data) {
            //鼠标移入监听
            if (this.docName !== data.docName) {
                this.$set(data, "show", true);
            }
        },
        mouseleave(data) {
            //鼠标移出监听
            if (this.docName !== data.docName) {
                this.$set(data, "show", false);
            }
        },
        geMenuList() {
            this.http.get(this.myController).then((res) => {
                if (res.code === 200) {
                    if (res.data.length > 0) {
                        this.myController =
                            "ecologyEnv/ledgerTempList/getListDataByMainCode/" +
                            res.data[0].mainCode;
                    }
                    this.menuList = handleTree(
                        res.data,
                        this.mainNo,
                        this.superiorNo,
                        "children"
                    );
                }
            });
        },
        geMenuListData() {
            this.http.get(this.myController).then((res) => {
                if (res.code === 200) {
                    if (res.data.length > 0) {
                        this.myController =
                            "ecologyEnv/ledgerTempList/getListDataByMainCode/" +
                            res.data[0].mainCode;
                    }
                    this.menuData = res.data;
                    this.$emit("callBackMenuData", this.menuData);
                    let defaultMenuData =
                        res.data[1][Object.keys(this.menuData[1])[0]];
                    this.menuList = handleTree(
                        defaultMenuData,
                        this.mainNo,
                        this.superiorNo,
                        "children"
                    );
                }
            });
        },
        //电子台账设置节点数据数据的
        handleMenuData(menuData) {
            this.menuList = handleTree(
                menuData,
                this.mainNo,
                this.superiorNo,
                "children"
            );
        },
        handleTreeClick(val) {
            if (this.origindata !== null) {
                this.$set(this.origindata, "show", false);
            }
            this.origindata = val;
            this.docName = val.docName;
            this.$set(val, "show", true);
            this.$emit("handleTreeClick", val);
        },
        addOp(res, val1) {
            if (val1 == "add") {
                this.$refs.windowTpldataTemp.show("目录操作-【新增】", res, 1);
            } else {
                this.$refs.windowTpldataTemp.show("目录操作-【编辑】", res, 2);
            }
        },
        handleDownOrder(data) {
            var _this = this;

            _this.handleOrder(data.id, 2, "下移成功");
        },
        handleUpOrder(data) {
            var _this = this;

            _this.handleOrder(data.id, 1, "上移成功");
        },
        handleOrder(id1, id2, title) {
            var _this = this;
            var url =
                "/ecologyEnv/ledgerTempList/changerOlder?" +
                "id1=" +
                id1 +
                "&id2=" +
                id2;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                if (typeof success == "function") {
                    success(res);
                }
                _this.msgSuccess(title);
                _this.geMenuList();
            });
        },

        handleDelete(val) {
            let _this = this;
            MessageBox.confirm("确定删除该目录吗？", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(() => {
                    let url = "/ecologyEnv/ledgerTempList/delete/" + val["id"];
                    _this.http.delLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.geMenuList();
                            _this.msgSuccess("删除成功");
                        }
                    );
                })
                .catch(() => {
                    return;
                });
        },
        // handleWindowTpDataClose(val) {
        //     this.dialogVisible = val;
        // },
        handleSubmitClose(val) {
            // this.dialogVisible = val;
            this.geMenuList();
        },
        getIcon: function (type) {
            switch (type) {
                case "2":
                    return require("@/assets/images/file_type_icon/file1.png");
                case "3":
                    return require("@/assets/images/file_type_icon/file2.png");
                case "4":
                    return require("@/assets/images/file_type_icon/file3.png");
                default:
                    return require("@/assets/images/file_type_icon/file4.png");
            }
        },
        handelLedgerChoose(data) {
            this.$emit("handelLedgerChoose", data);
            // this.entrustedBigCatalogCode = data.code;
            // this.entrustedBigCatalogName = data.name;
            // let projectId = this.$route.query.projectId ?  this.$route.query.projectId :0;
            // this.controller = "site/ledgerTempList/getListDataByProjectId/"+projectId+"?entrustedBigCatalogCode=" + data.code;
            // setTimeout(() => {
            //   this.geMenuList();
            // })
        },
        handleChange() {
            this.$refs.eagleDialogLedgerTemp.show(
                this.entrustedBigCatalogCode,
                this.entrustedBigCatalogName
            );
        },
    },
};
</script>


<style scoped>
::v-deep .left-content[data-v-c34afb7a] {
    width: 300px;
}
.btn-temp {
    color: #1890ff;
    padding: 3px;
}
.tree-title {
    width: 100%;
    height: 50px;
    line-height: 50px;
    text-align: center;
    border-bottom: 1px solid #e6e6e6;
    background-color: #fafafa;
    margin: 5px 0 0 0;
}

.scroll {
    background-color: #fafafa;
}

.scroll /deep/ .el-scrollbar__wrap {
    overflow-x: hidden;
}

.custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12px;
    padding-right: 8px;
}

.el-tree {
    padding: 10px 0;
    background-color: #ffffff;
}

.el-tree /deep/ .el-tree-node__content {
    padding-left: 0px !important;
    display: flex;
}

.el-tree /deep/ .is-current > .el-tree-node__content {
    background: rgba(22, 119, 255, 0.1) !important;
    color: #187aff !important;
}

/* 树形结构节点添加连线 */
.tree-line /deep/ .el-tree-node {
    position: relative;
    padding-left: 16px;
}

.tree-line > /deep/ .el-tree-node {
    padding-left: 10px;
}

.tree-line /deep/ .el-tree-node__children {
    padding-left: 16px;
}

.tree-line /deep/ .el-tree-node:last-child:before {
    height: 26px;
}

.tree-line /deep/ .el-tree > .el-tree-node:before {
    border-left: none;
}

.scroll
    /deep/
    .el-tree
    > .el-tree-node
    > .el-tree-node__children
    > .el-tree-node:before {
    top: -11px;
}

.scroll /deep/ .el-tree > .el-tree-node:after {
    border-top: none;
}

.tree-line /deep/ .el-tree-node__children .el-tree-node:before {
    content: "";
    left: -3px;
    position: absolute;
    right: auto;
    border-width: 1px;
    top: -11px;
}

.tree-line /deep/ .el-tree-node:after {
    content: "";
    left: -3px;
    position: absolute;
    right: auto;
    border-width: 1px;
}

.tree-line /deep/ .el-tree-node__expand-icon.is-leaf {
    margin-left: -15px;
}

.tree-line /deep/ .el-tree-node:before {
    border-left: 1px solid #dddddd;
    bottom: 0px;
    height: 100%;
    top: -12px;
    width: 1px;
}

.tree-line /deep/ .el-tree-node:after {
    border-top: 1px solid #dddddd;
    height: 20px;
    top: 12px;
    width: 28px;
}

.tree-line /deep/ .el-tree-node__expand-icon {
    font-size: 15px;
}
.operate-btn span {
    padding-right: 2px;
}
</style>
