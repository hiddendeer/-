<template name="window-tpldata-temp">
    <div class="window-tpldata-temp">
        <eagle-form :controller="controller" title="日志" :form="form" width="800px" label-width="120px" ref="EagleForm" @bindData="bindData" @afterSave="afterSave">
            <eagle-block border>
                <eagle-input label="上级目录：" prop="parentName" v-model="form.parentName" :isEdit="false" />
                <el-row>
                    <el-col :span="24">
                        <eagle-radio v-model="form.type" prop="type" label="类型" :data-source="params.ledgerTempCatalogCategory" @change="change" required :isEdit="editFlag == 1" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" v-if="form.type == 2">
                        <eagle-choose label="文件名称" @change="openWorldTemplateChoose" @clearChoose="cleardocModuleNameChoose" v-model="form.docModuleName" required prop="docModuleName" />
                        <eagle-dialog-ledger-temp-online-world-template ref="eagleDialogLedgerTempOnlineWorldTemplate" :single="true" @callBack="handelChoose"></eagle-dialog-ledger-temp-online-world-template>
                    </el-col>
                    <el-col :span="24" v-else-if="form.type == 3">
                        <eagle-choose label="文件名称" @change="openTemplateChoose" @clearChoose="cleardocModuleNameChoose" v-model="form.docModuleName" required prop="docModuleName" />
                        <eagle-dialog-ledger-temp-online-template ref="eagleDialogLedgerTempOnlineTemplate" :single="true" @callBack="handelChoose"></eagle-dialog-ledger-temp-online-template>
                    </el-col>
                    <el-col :span="24" v-else-if="form.type == 4">
                        <eagle-choose label="文件名称" @change="openFileTypeChoose" @clearChoose="cleardocModuleNameChoose" v-model="form.docModuleName" required prop="docModuleName" />
                        <eagle-dialog-ledger-temp-online-file ref="eagleDialogLedgerTempOnlineFile" :single="true" @callBack="handelChoose"></eagle-dialog-ledger-temp-online-file>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" v-if="form.type == 1">
                        <eagle-input v-model="form.docName" prop="docName" label="要素名称" required />
                    </el-col>
                </el-row>
                <el-form-item label="顺序">
                    <el-input-number v-model="form.orderNo" :min="1" label="顺序"></el-input-number>
                </el-form-item>
            </eagle-block>
        </eagle-form>
    </div>
</template>


<script>
import eagleDialogLedgerTempOnlineTemplate from "./eagle-dialog-ledger-temp-online-template.vue";
import eagleDialogLedgerTempOnlineWorldTemplate from "./eagle-dialog-ledger-temp-online-world-template.vue";
import eagleDialogLedgerTempOnlineFile from "./eagle-dialog-ledger-temp-online-file.vue";
export default {
    components: {
        eagleDialogLedgerTempOnlineTemplate,
        eagleDialogLedgerTempOnlineFile,
        eagleDialogLedgerTempOnlineWorldTemplate,
    },
    name: "window-tpldata-temp",
    props: {},
    created() {
        this.initData();
    },
    data() {
        return {
            dialogVisible: false,
            form: {},
            title: "目录操作",
            controller: "ecologyEnv/ledgerTempList",
            params: {
                ledgerTempCatalogCategory: [],
            },
            rules: {},
            selectRow: {},
            editFlag: "",
        };
    },
    methods: {
        search() {},
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.ledger_temp_catalog_category],
                function (res) {
                    _this.params.ledgerTempCatalogCategory = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.ledger_temp_catalog_category
                    );
                }
            );
        },
        bindData(data) {
            let _this = this;
            _this.form = data;
            if (_this.editFlag == 1) {
                _this.form.parentCode = _this.selectRow.code;
                _this.form.parentName = _this.selectRow.docName;
                _this.form.mainCode = _this.selectRow.mainCode;
                _this.form.type = "1";
            }
            this.$emit("handleSubmitClose");
        },
        show(title, data, is) {
            let _this = this;
            _this.selectRow = data;
            let config = {
                title: "",
            };
            debugger;
            if (is == 2) {
                this.form = data;
                _this.editFlag = 2;
                config.title = title;
                _this.$refs.EagleForm.handleUpdate(data, config);
            }
            if (is == 1) {
                //新增操作
                _this.editFlag = 1;
                config.title = title;
                _this.$refs.EagleForm.handleAdd(config);
            }
        },
        afterSave() {
            console.log(this.form);
            this.$emit("handleSubmitClose");
        },
        openTemplateChoose(data) {
            this.$refs.eagleDialogLedgerTempOnlineTemplate.show(
                this.form.docModuleCode,
                this.form.docModuleName
            );
        },
        openFileTypeChoose(data) {
            this.$refs.eagleDialogLedgerTempOnlineFile.show(
                this.form.docModuleCode,
                this.form.docModuleName
            );
        },
        openWorldTemplateChoose(data) {
            this.$refs.eagleDialogLedgerTempOnlineWorldTemplate.show(
                this.form.docModuleCode,
                this.form.docModuleName
            );
        },
        handelChoose(data) {
            this.form.docModuleCode = data.code;
            this.form.docModuleName = data.name;
            this.form.docName = data.name;
        },
        change() {
            this.form.docModuleName = "";
        },
        cleardocModuleNameChoose() {
            this.form.docModuleName = "";
        },
    },
};
</script>

<style scoped lang="scss">
.window-tpldata-temp {
    .el-dialog__title {
        font-weight: 600 !important;
    }
}
</style>
