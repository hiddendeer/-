<template>
    <div class="company-table-container">
        <div class="layer">
            <div style="background: linear-gradient(0deg, #D6D6D6 0%, rgba(255,255,255,0) 100%);">
                <div class="div-book-container">
                    <div class="div-leftList">
                        <template v-for="(item, index) in bookList">
                            <div :class="index == currentBookIndex ? 'div-book-item div-book-pos' : 'div-book-item'" @click="handleBoookClick(item.code)">
                                <div :class="'div_book_image div_book_' + (index > 4 ? (index % 5 + 1) : (index + 1))">
                                    <div class="div_book_font" :title="item.docName">{{  item.docName.substring(0, 7)  }}
                                    </div>
                                </div>
                                <div class="div-delete-item" v-show="index == currentBookIndex">
                                    <div @click="handleUpdateBookClick(item, index)">
                                        <i class="el-icon-edit" style="color: #1890FF;font-size: 14px; margin-top: 8px; font-weight: 650;"></i>重命名
                                    </div>
                                    <div @click="handleDeleteBookClick(item)">
                                        <i class="el-icon-delete" style="color: #F56C6C;font-size: 14px; margin-top: 8px; font-weight: 650;"></i>
                                        删除
                                    </div>
                                </div>
                            </div>
                        </template>
                        <div class="div-book-item" @click="handleAddBookClick()">
                            <div class="div_book_image div_book_add">
                                <div class="div_book_font_add">增加</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="div-table-container">
            <div class="div-left-table">
                <template>
                    <div>
                        <div class="div_title">
                            <div class="icon_forder"></div>
                            <div class="div_title_font"> {{  currentName  }}</div>
                        </div>
                        <!-- <div style="margin-bottom:5px ;" class="div_title_font">安全台账文件管理</div> -->
                    </div>

                    <el-table :data="leftList" style="width: 100%;">
                        <el-table-column label="序号" type="index" width="50" />
                        <el-table-column label="台账名称" align="left" prop="docName" />
                        <el-table-column label="操作" width="120">
                            <template #default="scope">
                                <div class="div_button_list">
                                    <i title="上移" :class="scope.$index == 0 ? 'el-icon-top icon_grey' : 'el-icon-top icon_blue'" @click="handleUpOrder(scope.row, scope.$index == 0 ? true : false,scope.$index)"></i>
                                    <i title="下移" :class="scope.$index == leftList.length - 1 ? 'el-icon-bottom icon_grey' : 'el-icon-bottom icon_blue'" @click="handleDownOrder(scope.row, scope.$index == leftList.length - 1 ? true : false,scope.$index)"></i>
                                    <i title="删除" class="el-icon-right icon_delete" @click="handleDelete(scope.row)"></i>
                                </div>
                            </template>
                        </el-table-column>
                        <template v-if="leftList.length == 0" slot="empty">
                            <el-empty :image-size="100" description="暂无数据"></el-empty>
                        </template>
                    </el-table>
                </template>
            </div>
            <div class="div-button-table">
                <div class="button_delete div-button" @click="handleRemoveAll()">全部移除
                    <div class="button-right"></div>
                </div>
                <div class="button_import div-button" @click="handleImportAll()">
                    <div class="button-left"></div>全部导入
                </div>
            </div>
            <div class="div-right-table">
                <div>
                    <div class="div_title">
                        <div class="icon_book"></div>
                        <div class="div_title_font"> 台账模板库</div>
                    </div>
                </div>
                <eagle-page searchRight="20px" :hasTab="true" :controller="controller" ref="EaglePage" :showBtn="false" :imageSize="100" tableHeight="calc(100vh - 605px)" :showCheckColumn="true" style="width: 100%;" :conditions="conditions">
                    <template slot="slot-search">
                        <eagle-condition @search="search()" @resetQuery="resetQuery()" style="padding: 5px">
                            <eagle-radio @change="search()" label-width="55px" label="来源" prop="status" v-model="conditions.docType.value" :data-source="params.docType" size="small">
                            </eagle-radio>
                            <eagle-input label-width="80px" label="筛选条件" @changeEnter="search" :required="false" prop="docName" v-model="conditions.docName.value" placeholder="请输入报表名称" clearable size="small" />
                        </eagle-condition>
                    </template>
                    <template slot="slot-table">
                        <el-table-column label="操作" width="60">
                            <template slot-scope="scope">
                                <div class="div_button_list">
                                    <i title="删除" class="el-icon-back icon_blue" @click="handleImport(scope.row)"></i>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="所属栏目" align="left" prop="docType" width="120">
                            <template slot-scope="scope">
                                <span>{{
                                     formateDict(params.docType, scope.row.docType + "") 
                                    }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="台账名称" align="left" prop="docName" />
                        <el-table-column label="预览" align="left" prop="type" width="80">
                            <template slot-scope="scope">
                                <template v-if="scope.row.example">
                                    <eagle-row-attach-preview v-model="scope.row.example">
                                    </eagle-row-attach-preview>
                                </template>
                            </template>
                        </el-table-column>
                    </template>
                </eagle-page>
            </div>
        </div>
        <window-tpldata-temp :mainCode="code" ref="windowTpldataTemp" @handleSubmitClose="handleSubmitClose">
        </window-tpldata-temp>
    </div>
</template>
<script>
import { Message, MessageBox } from "element-ui";
import windowTpldataTemp from "@/views/site/components/ledgerTemp/windowTpldataTemp.vue";

export default {
    name: "ledgerTempConfig",
    components: { windowTpldataTemp },
    props: {
        controllerDetail: { type: String, default: "" },
        controller: "ecologyEnv/ledgerTempList",
    },
    data() {
        return {
            code: this.$route.query.code, //台账模板选中数据的code值
            // EagleOrganController: this.$route.query.templateName
            //     ? "site/ledgerTempList/getListDataByMainCodeName/" +
            //       this.$route.query.code +
            //       "/" +
            //       this.$route.query.templateName
            //     : "site/ledgerTempList/getListDataByMainCode/" +
            //       this.$route.query.code,
            bookList: [],
            leftList: [],
            // currentBookIndex: 0,
            currentDocCode: "", //当前类型编号
            // 查询条件
            // conditionsVals: {
            //     title: "",
            //     docType: "",
            //     type: "",
            // },
            conditions: {
                docName: {
                    value: "",
                },
                docType: {
                    value: "",
                },
                type: {
                    value: "",
                },
            },
            params: {
                fileOnlineTempDocType: [],
                docType: [],
                ledgerTempCatalogCategory: [],
                ledgerTempCatalogCategoryShow: [],
            },
            maxHeight: 0, //表格高度
        };
    },
    computed: {
        currentBookIndex() {
            let currentIndex = 0;
            if (this.bookList && this.bookList.length > 0) {
                for (var i = 0; i < this.bookList.length; i++) {
                    if (this.bookList[i].code == this.currentDocCode) {
                        currentIndex = i;
                    }
                }
            }
            return currentIndex;
        },
        currentName() {
            let name = "";
            if (this.bookList && this.bookList.length > 0) {
                for (var i = 0; i < this.bookList.length; i++) {
                    if (this.bookList[i].code == this.currentDocCode) {
                        name = this.bookList[i].docName;
                    }
                }
            }
            return name;
        },
    },
    created() {
        this.initData();
        this.initBookList();
        this.search();
    },
    mounted() {},
    methods: {
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.file_online_temp_doc_type,
                    _this.constParams.doc_type,
                    _this.constParams.ledger_temp_catalog_category,
                ],
                function (res) {
                    _this.params.fileOnlineTempDocType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.file_online_temp_doc_type
                    );
                    _this.params.docType = res.data.filter(
                        (p) => p.paramId === _this.constParams.doc_type
                    );
                    _this.params.ledgerTempCatalogCategory = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.ledger_temp_catalog_category
                    );
                    _this.params.docType.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                    _this.params.ledgerTempCatalogCategoryShow =
                        _this.params.ledgerTempCatalogCategory.filter(
                            (item) => {
                                return item.name != "目录";
                            }
                        );
                    _this.params.ledgerTempCatalogCategoryShow.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                }
            );
        },
        initBookList(code) {
            let _this = this;
            let url = "site/ledgerTempList/getCatalogByMainCode/" + this.code;
            this.http.get(url, {}).then((res) => {
                if (res.code == 200) {
                    if (res.data && res.data.length > 0) {
                        _this.bookList = res.data;
                        if (!code) {
                            code = res.data[0].code;
                        }
                        _this.handleBoookClick(code);
                    }
                }
            });
        },
        handleBoookClick(code) {
            this.currentDocCode = code;
            this.refreshLeftList();
        },
        refreshLeftList() {
            let _this = this;
            let url = "ecologyEnv/ledgerTempList/getListByParentCode";
            this.http
                .get(url, {
                    code: this.currentDocCode,
                    mainCode: this.code,
                })
                .then((res) => {
                    if (res.code == 200) {
                        _this.leftList = res.data;
                    }
                });
        },
        handleAddBookClick() {
            let res = { code: this.code };
            this.$refs.windowTpldataTemp.show("目录操作-【新增】", res, 1);
        },
        handleUpdateBookClick(item, index) {
            item.index = index;
            this.$refs.windowTpldataTemp.show("目录操作-【编辑】", item, 2);
        },
        //删除目录
        handleDeleteBookClick(row) {
            let ids = row["id"];
            this.handleDeleteMethod(ids, "catalogue");
        },
        search() {
            setTimeout(() => {
                this.$refs.EaglePage.search({
                    url: "ecologyEnv/ledgerTempList/getLedgerTempListPageData",
                });
            });
        },
        resetQuery() {
            this.conditions.docName.value = "";
            this.conditions.docType.value = "";
            this.conditions.type.value = "";
            this.search();
        },
        handleDownOrder(data, isReturn, index) {
            if (isReturn) {
                return;
            }
            let nextData = this.leftList[index + 1];
            this.handleOrderNew(data.id, nextData.id, "下移成功");
        },
        handleUpOrder(data, isReturn, index) {
            if (isReturn) {
                return;
            }
            let nextData = this.leftList[index - 1];
            this.handleOrderNew(data.id, nextData.id, "上移成功");
            // this.refreshLeftList();
        },
        handleOrderNew(id1, id2, title) {
            var _this = this;
            var url =
                "/ecologyEnv/ledgerTempList/changerOlderNew?" +
                "id1=" +
                id1 +
                "&id2=" +
                id2;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                if (typeof success == "function") {
                    success(res);
                }
                _this.refreshLeftList();
                _this.msgSuccess(title);
            });
        },
        handleOrder(id1, id2, title) {
            var _this = this;
            var url =
                "/ecologyEnv/ledgerTempList/changerOlder?" +
                "id1=" +
                id1 +
                "&id2=" +
                id2;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                if (typeof success == "function") {
                    success(res);
                    //_this.refreshLeftList();
                }
                _this.msgSuccess(title);
            });
        },
        //删除台账模板
        handleDelete(val) {
            let _this = this;
            let ids = val["id"];
            _this.handleDeleteMethod(ids, "book");
        },
        handleDeleteMethod(ids, action) {
            let _this = this;
            let mes = "确定删除该目录吗？";
            if (action == "book") {
                if (typeof ids == "string") {
                    mes = "确定删除该台账吗？";
                } else {
                    mes = "确定删除所有台账吗？";
                }
            }
            MessageBox.confirm(mes, "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(() => {
                    let url = "/ecologyEnv/ledgerTempList/delete/" + ids;
                    _this.http.delLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            if (action == "catalogue") {
                                _this.initBookList();
                            } else {
                                _this.refreshLeftList();
                            }
                            _this.msgSuccess("删除成功");
                        }
                    );
                })
                .catch(() => {
                    return;
                });
        },
        handleImport(row) {
            let _this = this;
            let codes = [row.code];
            let types = [row.type];
            _this.handleImportFunction(codes, types);
        },
        handleImportFunction(codes, types) {
            let _this = this;
            let url =
                "ecologyEnv/ledgerTempList/insertDataByIds/" +
                this.code +
                "/" +
                codes +
                "/" +
                types +
                "?dataType=1&treeCode=" +
                this.currentDocCode;
            if (codes.length > 0) {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.msgSuccess("保存成功");
                        _this.refreshLeftList();
                    }
                );
            } else {
                _this.msgError("请选择台账！");
            }
        },
        handleSubmitClose(code) {
            this.currentDocCode = code;
            this.initBookList(code);
        },
        //删除所有台账
        handleRemoveAll() {
            let ids = this.leftList.map((x) => x["id"]);
            if (ids && ids.length > 0) {
                this.handleDeleteMethod(ids, "book");
            } else {
                this.msgError("没有需要移除的台账");
                return false;
            }
        },
        handleImportAll() {
            if (!this.currentDocCode) {
                this.msgError("请先新增文件目录");
                return false;
            }
            let _this = this;
            let dataSourceList = this.$refs.EaglePage.getSelection();
            if (!dataSourceList || dataSourceList.length <= 0) {
                this.msgError("请先选择文件");
                return false;
            }
            let codes = dataSourceList.map((x) => x["code"]);
            let types = dataSourceList.map((x) => x["type"]);
            _this.handleImportFunction(codes, types);
        },
    },
};
</script>

<style  lang="scss" scoped>
.company-table-container {
    max-width: 1700px;

    .layer {
        padding: 0px !important;
    }

    .div-table-container {
        display: flex;
        flex-direction: row;
        margin-top: 20px;
        position: relative;
        // height: calc(100vh - 375px);

        .div_title_font {
            font-size: 16px;
            font-weight: 400;
            color: #303133;
        }

        .div_title {
            display: flex;
        }

        .icon_forder {
            height: 24px;
            width: 24px;
            background-repeat: no-repeat;
            margin-right: 5px;
            background-image: url("../../../assets/images/view/host/icon_forder.png");
        }

        .icon_book {
            height: 24px;
            width: 24px;
            background-repeat: no-repeat;
            margin-right: 5px;
            background-image: url("../../../assets/images/view/host/icon_book.png");
        }

        .div-left-table {
            background: #fff;
            width: 495px;
            min-width: 495px;
            margin-right: 125px;
            padding: 20px;
        }

        .div-button-table {
            display: flex;
            flex-direction: column;
            position: absolute;
            left: 495px;
            top: 30%;
            width: 125px;
            align-items: center;

            .div-button {
                width: 88px;
                height: 28px;
                line-height: 28px;
                text-align: center;
                margin-bottom: 15px;
                cursor: pointer;
                color: #fff;
                display: flex;
                align-items: center;
                padding-left: 10px;
            }

            .button-left {
                margin-right: 5px;
                width: 15px;
                height: 13px;
                background-image: url("../../../assets/images/view/host/button-to-left.png");
            }

            .button-right {
                margin-left: 5px;
                width: 15px;
                height: 13px;
                background-image: url("../../../assets/images/view/host/button-to-right.png");
            }

            .button_delete {
                background-color: #f56c6c;
                border-top-left-radius: 4px;
                border-bottom-left-radius: 4px;
                border-top-right-radius: 2em;
                border-bottom-right-radius: 2em;
            }

            .button_import {
                background-color: #409eff;
                border-top-left-radius: 2em;
                border-bottom-left-radius: 2em;
                border-top-right-radius: 4px;
                border-bottom-right-radius: 4px;
            }
        }

        .div-right-table {
            background: #fff;
            border-radius: 4px;
            padding: 20px;
        }
    }

    .div-book-container {
        width: 100%;
        height: 292px;
        background: url(../../../assets/images/view/host/book-bg.png) 50% 50% /
            cover no-repeat;
        background-repeat: no-repeat;
        display: flex;
    }

    .div-leftList {
        margin-left: 175px;
        margin-top: 95px;
        display: flex;
        flex-direction: row;
        cursor: pointer;
        position: relative;

        .div-book-item {
            writing-mode: vertical-rl;
            margin-right: 1px;
            height: 185px;
            position: relative;
        }

        .div-delete-item {
            width: 91px;
            height: 64px;
            background: #ffffff;
            box-shadow: 3px 4px 4px 0px rgba(234, 234, 233, 0.25);
            border-radius: 2px;
            display: flex;
            flex-direction: column;
            writing-mode: horizontal-tb;
            position: absolute;
            top: -65px;
            right: -25px;

            .icon {
                width: 14px;
                height: 14px;
                background-repeat: no-repeat;
                margin-top: 8px;
                margin-right: 5px;
            }

            .icon_edit {
                background-image: url("../../../assets/images/view/host/icon_edit.png");
            }

            .icon_delete {
                background-image: url("../../../assets/images/view/host/icon_delete.png");
            }

            div {
                display: flex;
                line-height: 32px;
                padding-left: 10px;
            }
        }

        .div-book-pos {
            margin-top: -20px;
        }

        .div_book_image {
            background-repeat: no-repeat;
            width: 42px;
            height: 183px;
        }

        .div_book_font {
            width: 42px;
            font-size: 14px;
            font-weight: 400;
            color: #303133;
            line-height: 45px;
            margin-top: 20px;
        }

        .div_book_font_add {
            width: 42px;
            font-size: 14px;
            font-weight: 400;
            color: #689fe9;
            line-height: 45px;
            margin-top: 65px;
        }

        .div_book_1 {
            background-image: url("../../../assets/images/view/host/book_1.png");
        }

        .div_book_2 {
            background-image: url("../../../assets/images/view/host/book_2.png");
        }

        .div_book_3 {
            background-image: url("../../../assets/images/view/host/book_3.png");
        }

        .div_book_4 {
            background-image: url("../../../assets/images/view/host/book_4.png");
        }

        .div_book_5 {
            background-image: url("../../../assets/images/view/host/book_5.png");
        }

        .div_book_add {
            background-image: url("../../../assets/images/view/host/book_add.png");
        }
    }

    .div_button_list {
        display: flex;
        flex-direction: row;
        cursor: pointer;

        div {
            width: 16px;
            height: 16px;
            margin-right: 5px;
        }

        // .icon_up {
        //     background-image: url("../../../assets/images/view/host/icon_up.png");
        // }

        .icon_grey {
            font-size: 18px;
            font-weight: bold;
            color: #e1e0e3;
        }

        .icon_blue {
            font-size: 18px;
            font-weight: bold;
            color: #1890ff;
        }

        .icon_red {
            font-size: 18px;
            font-weight: bold;
            color: #409eff;
        }

        .icon_delete {
            font-size: 18px;
            font-weight: bold;
            color: #f56c6c;
        }

        // .button-left-grey {
        //     background-image: url("../../../assets/images/view/host/button-left-grey.png");
        // }

        // .button-left-blue {
        //     background-repeat: no-repeat;
        //     background-image: url("../../../assets/images/view/host/button-left-blue.png");
        // }
    }
}
</style>
