<template>
    <div class="app-container-parent app-container">
        <div class="layer">
            <div v-for="(item, index) in LedgerTempList" :key="index" class="block-page-content">
                <div class="ledgerTempTitle" :title="item.name">
                    {{ item.name }}
                </div>
                <div class="ledgerTempDesc" :title="item.templateDesc">
                    {{ item.templateDesc }}
                </div>
                <div class="ledgerTempSource">
                    <span v-if="item.companyCode == '000000'">
                        来源：平台提供
                    </span>
                    <span v-else>
                        来源：{{ item.createChnName }}创建
                    </span>

                </div>
                <div class="ledgerTempButton">
                    <eagle-row-button type="primary" v-if="item.edit" @click.stop="handleConfig(item)">配置
                    </eagle-row-button>
                    <eagle-row-button type="success" v-if="!item.edit" @click.stop="handleDetail(item)">详情
                    </eagle-row-button>
                    <eagle-row-button type="primary" v-if="!item.edit" @click.stop="handleCopy(item)">复制
                    </eagle-row-button>
                    <eagle-row-button type="primary" v-if="item.edit" @click.stop="handleUpdate(item)">编辑
                    </eagle-row-button>
                    <eagle-row-button style="color:red" type="danger" v-if="item.edit" @click.stop="handleDelete(item)">
                        删除</eagle-row-button>
                </div>
            </div>
            <div class="block-page-content-button">
                <i class="el-icon-circle-plus-outline customerButton" @click.stop="handleAdd"></i>

                <!-- <eagle-row-button class="el-icon-circle-plus-outline" @click.stop="handleAdd"
                    style="margin: 50px 10px; font-size: 28px; color: #cbd3cb; "></eagle-row-button> -->
            </div>
            <eagle-form :controller="controller" title="体系模板" :form="form" width="1000px" label-width="120px" ref="EagleForm" @afterSave="search" @bindData="bindData">
                <eagle-block border>
                    <eagle-input label="模板名称" prop="name" v-model="form.name" required />
                    <el-row>
                        <eagle-choose-industry label="行业名称" v-model="form.applyProfession" required prop="applyProfession" :names.sync="form.applyProfessionName">
                        </eagle-choose-industry>
                    </el-row>
                    <eagle-input label="模板说明" v-model="form.templateDesc" prop="templateDesc" type="textarea">
                    </eagle-input>
                    <el-form-item label="顺序">
                        <el-input-number v-model="form.orderNo" :min="1" label="顺序"></el-input-number>
                    </el-form-item>
                </eagle-block>
            </eagle-form>
            <el-dialog v-dialogDrag title="模板详情" :visible.sync="showledgerTempConfigVisible" width="800px" append-to-body show-close :close-on-click-modal="false">
                <eagle-block border>
                    <el-row>
                        <el-col :span="24">
                            <eagle-tree-temp Title="目录" ref="EagleTree" mainNo="code" superiorNo="parentCode" scrollHeight="calc(100vh - 125px)" :charlen="30" v-if="showledgerTempConfigVisible" :buttonShow="false" :buttonChangeShow="false" :controller="controllerDetail">
                            </eagle-tree-temp>
                        </el-col>
                    </el-row>
                </eagle-block>

                <span slot="footer" class="dialog-footer">
                    <el-button @click="showledgerTempConfigVisible = false">关 闭</el-button>
                </span>
            </el-dialog>

            <el-dialog v-dialogDrag title="模板复制" :visible.sync="showledgerTempCopyVisible" width="800px" append-to-body show-close :close-on-click-modal="false">
                <eagle-block border>
                    <el-form ref="elForm" label-width="100px" :model="form" :rules="rules">
                        <el-form-item label="模板名称" prop="templateName">
                            <el-input v-model="form.templateName" />
                        </el-form-item>
                    </el-form>
                </eagle-block>

                <div slot="footer" class="dialog-footer">
                    <el-button @click="showledgerTempCopyVisible = false">取 消</el-button>
                    <el-button type="primary" @click="handleSave">确 定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
import eagleChooseIndustry from "@/views/support/libTemp/components/selectIndustry/eagle-choose-industry.vue";
import ledgerTempConfig from "./ledgerTempConfig.vue";
import eagleTreeTemp from "@/views/site/components/ledgerTemp/eagle-tree-temp.vue";

export default {
    components: { eagleTreeTemp, ledgerTempConfig, eagleChooseIndustry },
    name: "ledgerTemp",
    data() {
        return {
            queryParams: {
                dataType: "list",
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {},
            // 查询条件
            conditionsVals: {},
            controller: "ecologyEnv/ledgerTemp", //对应后端控制器
            // 标题
            title: "",
            // 表单参数
            form: {
                templateName: "",
            },
            // 表单校验
            rules: {
                templateName: [
                    {
                        required: true,
                        message: "请输入模板名称",
                        trigger: "blur",
                    },
                ],
            },
            ids: [],
            params: {},
            LedgerTempList: [], //数据源
            enterpriseCode: "",
            projectId: "",
            showledgerTempConfigVisible: false,
            showledgerTempCopyVisible: false,
            controllerDetail: "",
            templateName: "",
            templateCode: "",
        };
    },

    created() {
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";

        this.initData();
    },
    mounted() {
        // this.search();
    },
    methods: {
        /** 导出按钮操作 */
        handleExport() {},
        /** 导入按钮操作 */
        handleImport() {
            this.$refs.EagleDialogExce.show();
        },
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            let url_suffix =
                _this.enterpriseCode && _this.projectId
                    ? "?enterpriseCode=" +
                      _this.enterpriseCode +
                      "&projectId=" +
                      _this.projectId
                    : "";
            let url = "/" + this.controller + "/getLedgerTempList" + url_suffix;
            this.http.get(url).then((response) => {
                _this.LedgerTempList = response.data;
                console.log(_this.LedgerTempList);
            });
        },

        bindData(data) {
            this.form = data;
        },
        /** 新增按钮操作 */
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            var url = "/" + this.controller + "/delete/" + row["id"];
            this.$confirm("是否确认删除此行数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http.delLoading(_this.loading(), url, {}, function (res) {
                    _this.search();
                });
                // _this.http.del(url).then(function() {
                //     _this.msgSuccess("删除成功");
                //     _this.search();
                // });
            });
        },
        /** 复检 */
        handleCheck(row) {
            this.$refs.EquCheck.show(row);
        },

        handleConfig(row) {
            this.$router.push({
                name: "LedgerTempConfig",
                query: {
                    code: row.code,
                },
            });
        },

        handleMultDelete() {
            var _this = this;
            this.$refs.EaglePage.handleMultDelete(this.ids, function (res) {
                _this.refresh();
            });
        },

        /**详情 */
        handleDetail(row) {
            console.log(row);
            this.showledgerTempConfigVisible = true;
            this.controllerDetail =
                "secologyEnvite/ledgerTempList/getListDataByMainCodeDetail/" + row.code;
        },

        /**复制 */
        handleSave() {
            let _this = this;
            if (this.form.templateName == "") {
                // this.msgError("模板名称不为空");
                return;
            }

            this.http
                .get(
                    "ecologyEnv/ledgerTemp/copyTemp/" +
                        this.templateCode +
                        "/" +
                        this.form.templateName
                )
                .then((res) => {
                    if (res.code == 500) {
                        return;
                    } else if (res.code == 200) {
                        _this.$router.push({
                            name: "LedgerTempConfig",
                            query: {
                                code: res.data.code,
                                templateName: _this.form.templateName,
                            },
                        });
                        _this.showledgerTempCopyVisible = false;
                    }
                });
        },
        handleCopy(row) {
            this.form.templateName = row.name + "-复制";
            this.templateCode = row.code;
            this.showledgerTempCopyVisible = true;
        },

        //查询
        search() {
            let _this = this;
            let url_suffix =
                _this.enterpriseCode && _this.projectId
                    ? "?enterpriseCode=" +
                      _this.enterpriseCode +
                      "&projectId=" +
                      _this.projectId
                    : "";
            let url = "/" + this.controller + "/getLedgerTempList" + url_suffix;
            this.http.get(url).then((response) => {
                _this.LedgerTempList = response.data;
                console.log(_this.LedgerTempList);
            });
        },
        //刷新
        refresh() {
            this.search();
            // this.$refs.EaglePage.refresh(null);
        },
        //查询条件重置
        resetQuery() {
            this.conditionsVals.equmanagerChnname = "";
            this.conditionsVals.operateorgName = "";
            this.conditionsVals.equStatus = "";
            this.search();
        },
    },
};
</script>
<style lang="scss" scoped>
.div_card_content_num_blue {
    color: #1089ff;
}

.block-page-content {
    border: 1px solid #dedede;
    width: 365px;
    margin: 5px;
    padding: 10px;
    border-radius: 5px;
    float: left;
    cursor: pointer;
    /* flex-direction: row; */
}

.block-page-content-button {
    width: 365px;
    margin: 5px;
    padding: 10px;
    float: left;
    height: 165px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;

    .customerButton {
        margin: 50px 10px;
        font-size: 60px;
        color: #999;
    }

    .customerButton:hover {
        color: #409eff;
    }
}

.app-container-parent {
    /* display: flex; */
}

.ledgerTempTitle {
    height: 30px;
    font-size: 16px;
    color: #303133;
    margin: 5px;
    line-height: 16px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.ledgerTempDesc {
    height: 35px;
    font-size: 12px;
    color: #303133;
    margin: 5px;
    line-height: 12px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    padding-top: 4px;
}

.ledgerTempSource {
    height: 35px;
    font-size: 12px;
    color: #303133;
    margin: 5px;
    line-height: 12px;
}

.ledgerTempButton {
    text-align: right;
}
</style>
