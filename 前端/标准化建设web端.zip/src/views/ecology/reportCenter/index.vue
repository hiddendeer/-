<template>
    <div class="app-container div_site_report_center_container">
        <div class="layer">
         
            <eagle-page :queryParams="queryParams" :controller="controller" ref="EaglePage" :showCheckColumn="false" btn-width="160px">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input label-width="120px" label="报表名称" @changeEnter="search" :required="false"
                            prop="keyWords" v-model.trim="conditionsVals.keyWords" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                            </el-button>
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">
                    <el-table-column label="数据中心编号" align="left" prop="codeNo" width="300" />
                    <!-- <el-table-column label="类型"  align="left" prop="docType">
                        <template slot-scope="scope">
                            <span>{{ formateDict(params.fileOnlineTempDocType, scope.row.docType ) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="报表类型"  align="left" prop="reportTypeCode">
                        <template slot-scope="scope">
                            <span>{{ formateDict(params.reportType, scope.row.reportTypeCode ) }}</span>
                        </template>
                    </el-table-column> -->
                    <el-table-column label="报表名称" align="left" prop="name" />
                    <el-table-column label="描述" align="left" prop="remarks" width="300" />
                    <!-- <el-table-column label="模板"  align="left" prop="tempDoc" width="230px">
                        <template slot-scope="scope">
                            <eagle-row-attach v-model="scope.row.tempDoc"></eagle-row-attach>
                        </template>
                    </el-table-column> -->
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="text" size="mini" @click.stop="handleUpdate(scope.row)">编辑
                    </eagle-row-button>
                    <eagle-row-button type="danger" size="mini" @click.stop="handleDelete(scope.row)">删除
                    </eagle-row-button>
                </template>
            </eagle-page>
            <eagle-form :controller="controller" :title="title" :form="form" width="1000px" labelWidth="120px"
                ref="EagleForm" @afterSave="search" @bindData="bindData">
                <eagle-block border>
                    <eagle-input label="数据中心编号" prop="codeNo" required v-model="form.codeNo" />
                    <eagle-input label="数据名称" prop="name" required v-model="form.name" />

                    <eagle-input label="查询语句" type="textarea" :rows="setRows" prop="sqlText" required
                        v-model="form.sqlText" />
                    <eagle-input label="描述" type="textarea" prop="remarks" v-model="form.remarks" />
                </eagle-block>
            </eagle-form>
            <!-- <eagle-select-project-enterprise ref="projectEnterPriseDialog" :single="false" @callBack="handelEnterpriseChoose"></eagle-select-project-enterprise> -->
        </div>
    </div>
</template>

<script>
export default {
    name: "site-reportCenter",
    components: {
        // eagleSelectProjectEnterprise,
        // eagleChooseIndustry,
        // eagleChooseRegion
        // "eagle-attach": EagleAttach,
    },
    data() {
        return {
            conditionsVals: {
                keyWords: "",
            },
            conditionsTypes: {
                codeNo: "like",
            },
            queryParams: { dataType: "list" },
            params: {
                fileOnlineTempDocType: [],
                reportType: [],
            },
            controller: "ecologyEnv/commonReportForms",
            title: "报表中心",
            loading: true,
            form: { enterpriseNames: "", enterpriseCodes: "" },
            setRows: 15,
            selectIndustryVisible: false,
        };
    },
    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.doc_type,
                    _this.constParams.system_bi_report_type,
                ],
                function (res) {
                    _this.params.fileOnlineTempDocType = res.data.filter(
                        (p) => p.paramId === _this.constParams.doc_type
                    );
                    _this.params.reportType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.system_bi_report_type
                    );
                }
            );
        },
        resetQuery() {
            this.conditionsVals.keyWords = "";
            this.search();
        },
        bindData(data) {
            this.form = data;
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        openEnterpriseChoose() {
            this.$refs.projectEnterPriseDialog.show(
                this.form.enterpriseCodes,
                this.form.enterpriseNames
            );
        },
        handelEnterpriseChoose(data) {
            // debugger;
            this.form.enterpriseCodes = data.code;
            this.form.enterpriseNames = data.name;
        },
    },
};
</script>
<style  lang="scss"   scoped>
.div_site_report_center_container {
    width: auto;
}
</style>