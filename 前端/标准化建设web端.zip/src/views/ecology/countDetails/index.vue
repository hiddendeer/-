<!-- 分数详情 -->
<template>
  <div>
    <el-container>
      <el-main class="nopadding">
        <p class="date-title" v-if="$route.query.originPla==`appCenter`">
          <!-- <span>统计时间截止到：{{ lastDate }}</span> -->
          <span style="padding-left: 10px" v-if="this.$route.query.companyCode"
            ><el-button type="primary" size="medium" @click="historyClick"
              >返回</el-button
            ></span
          >
          <span style="padding-left: 10px" v-else>
            <span v-if="lastDate"  style="padding-right: 20px;">统计时间截止到：{{ lastDate }}</span>
            <el-button type="primary" size="medium" @click="historyClick"
              >历史记录</el-button
            >
          </span>
        </p>
        <section class="card top-container">
          <water-ball
            :totalMark="totalMark"
            :totalScore="totalScore"
            :loading="loading"
          ></water-ball>
        </section>
        <section class="card" v-if="$route.query.originPla==`appCenter`">
          <bar
            :loading="loading"
            setId="management"
            :width="'100%'"
            :height="'230px'"
            :riskMapData="state.riskMapData"
          >
            <p class="title">应急管理</p>
          </bar>
        </section>
        <section class="card" v-if="$route.query.originPla!==`PA`">
          <p class="title" v-if="$route.query.originPla==`appCenter`">综合执法</p>
          <div>
            <p class="setTitle">管理类</p>
            <bar
              :loading="loading"
              setId="managementA"
              style="margin-left: 50px"
              :width="'100%'"
              :height="'40px'"
              :comprehensiveLaw="state.comprehensiveLaw"
            >
              <p class="setNewTitle">特种设备管理</p>
            </bar>
            <bar
              :loading="loading"
              setId="managementD"
              style="margin-left: 50px"
              :width="'100%'"
              :height="'140px'"
              :ecologicalEnvironment="state.ecologicalEnvironment"
            >
              <p class="setNewTitle">
                生态环境类
                <span style="position: relative; top: 1px; cursor: pointer">
                  <el-popover
                    placement="bottom-start"
                    :width="150"
                    trigger="hover"
                    content="此项最多可得100分"
                  >
                    <template #reference>
                      <i class="el-icon-warning-outline"></i>
                    </template>
                  </el-popover>
                </span>
              </p>
            </bar>
          </div>
          <div>
            <p class="setTitle">执法类</p>
            <ul class="setLawSty">
              <li v-for="(item, index) in setLaw" :key="index">
                {{ item.label }} <span style="padding-left: 10px;">{{ item.score }}</span> 
              </li>
            </ul>
          </div>
        </section>
        <section class="card" v-if="$route.query.originPla==`appCenter`">
          <bar
            :loading="loading"
            setId="managementB"
            :width="'100%'"
            :height="'80px'"
            :evaluate="state.evaluate"
          >
            <p class="title">绩效评价</p>
          </bar>
        </section>
      </el-main>
    </el-container>
    <el-dialog
      :visible.sync="record_flag"
      title="历史积分记录"
      @close="close_history"
      v-dialogDrag
      width="40%"
      destroy-on-close
    >
      <el-table :data="record_table" height="400px" style="width: 100%">
        <template #empty>
          <el-empty description="暂无数据" />
        </template>
        <el-table-column
          prop="createTime"
          label="日期"
          align="center"
          width="180"
        />
        <el-table-column
          prop="totalScore"
          label="分数"
          align="center"
          width="180"
        />
        <el-table-column label="操作" align="center">
          <template #default="scope">
            <div>
              <el-button type="text" @click="jumpDetail(scope.row)"
                >查看详情</el-button
              >
            </div>
          </template>
        </el-table-column>
      </el-table>

      <template #footer>
        <div class="bodyPage">
          <el-pagination
            background
            @current-change="currentPageChange"
            @size-change="pageSizeChange"
            :page-size="pageSize"
            :current-page="page"
            :small="true"
            :page-sizes="[10, 20, 30, 40, 50]"
            :total="total"
            layout="total, sizes, prev, pager, next"
          ></el-pagination>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { useRoute } from "vue-router";
import waterBall from "./components/waterBall";
import Bar from "./components/bar";

export default {
  components: {
    waterBall,
    Bar,
  },
  data() {
    return {
      userInfoObj: JSON.parse(localStorage.getItem("user")),
      lastDate: "2023-09-25",
      totalScore: 0,
      record_flag: false,
      record_table: [],
      page: 1,
      pageSize: 10,
      total: 0,
      state: {
        riskMapData: [
          {
            label: "目标职责",
            value: 0,
          },
          {
            label: "制度化管理",
            value: 0,
          },
          {
            label: "教育培训",
            value: 0,
          },
          {
            label: "现场管理",
            value: 0,
          },
          {
            label: "安全风险管控",
            value: 0,
          },
          {
            label: "隐患排查",
            value: 0,
          },
          {
            label: "应急演练",
            value: 0,
          },
          {
            label: "事故查处",
            value: 0,
          },
        ],
        comprehensiveLaw: [
          {
            label: "特种设备管理",
            value: 100,
          },
        ],
        evaluate: [
          {
            label: "A类企业",
            value: 100,
          },
        ],
        ecologicalEnvironment: [
          {
            label: "审批管理",
            value: 100,
          },
          {
            label: "现场管理",
            value: 40,
          },
          {
            label: "涉环问题排查与整改",
            value: 60,
          },
        ],
      },
      loading: false,
      totalMark: [
        {
          image: require("@/assets/images/4.png"),
          label: "应急管理",
          dictCode: "SSDP_JFFL_YJGL",
          total: 0,
          id: "A",
        },
        {
          image: require("@/assets/images/5.png"),
          label: "综合执法",
          dictCode: "SSDP_JFFL_ZHZF",
          total: 0,
          id: "B",
        },
        {
          image: require("@/assets/images/6.png"),
          label: "绩效评价",
          dictCode: "SSDP_JFFL_JXPJ",
          total: 0,
          id: "C",
        },
      ],
      setLaw: [
        {
          name: "处罚结果：",
          content: "责令整改（-15）",
        },
        {
          name: "挂牌督办：",
          content: "无",
        },
        {
          name: "媒体曝光：",
          content: "无",
        },
        {
          name: "生产许可：",
          content: "无",
        },
        {
          name: "违法用地：",
          content: "无",
        },
        {
          name: "违法建筑：",
          content: "无",
        },
      ],
    };
  },
  mounted() {
    // this.lastDate = this.formatDate() || "2023-09-25";
    let url = "";
    if (this.$route.query?.companyCode) {
      url = "ecologyEnv/fourColor/homeStatistics/getHistoryScoreDetail";
      this.getInitData(url);
    } else {
      url = "ecologyEnv/fourColor/homeStatistics/getCompanyScoreDetail";
      this.gethistoryData();
      this.getInitData(url);
    }
    if (this.$route.query.originPla==`appCenter`) {
      document.title = '得分详情';
    } 
    else if(this.$route.query.originPla==`PA`) {
      document.title = '绩效评价';
    }    
    else {
      document.title = '分数详情';
    }
    
  },

  methods: {
    jumpDetail(row) {
      this.$router.push({
        name: "Firm",
        query: {
          companyCode:  this.userInfoObj?.companyCode,
          recordTime: row.createTime,
          originPla: "appCenter"
        },
      });
      this.record_flag = false;
      this.getInitData("ecologyEnv/fourColor/homeStatistics/getHistoryScoreDetail");
    },
    historyClick() {
    if (this.$route.query?.companyCode) {
      this.getInitData("ecologyEnv/fourColor/homeStatistics/getCompanyScoreDetail");
      this.$router.push({
        name: "Firm",
        query: {
          originPla: "appCenter"
        },
      });
    } else {
      this.gethistoryData();
      this.record_flag = true;
    }
    },
    gethistoryData() {
      var _this = this;
      _this.http
        .get("ecologyEnv/fourColor/homeStatistics/getScoreHistoryRecord", {
          companyId: _this.userInfoObj?.companyCode,
          // companyId: '5e09a41fb6974fa4fd2330cc98d8e04d',
          pageNo: _this.page,
          pageSize: _this.pageSize,
        })
        .then((res) => {
          if (res?.code == 200) {
            _this.record_table = res.data.records;
            _this.total = res.data.total;
          }
        });
    },
    close_history() {
      this.page = 1;
      this.pageSize = 10;
      this.record_flag = false;
    },
    getInitData(url) {
      var _this = this;
      let jsonData = {
        companyId: _this.userInfoObj?.companyCode,
        // companyId: '5e09a41fb6974fa4fd2330cc98d8e04d',
      }
      if (this.$route.query?.companyCode) {
        jsonData.recordTime = this.$route.query?.recordTime;
      }

      _this.http
        .get(url, jsonData)
        .then((res) => {
          if (res?.code == 200) {
            let currentScore = 0;
            if (_this.$route.query.originPla==`appCenter`) {
              currentScore = res?.data?.companyScore;
            } else if (_this.$route.query.originPla==`PA`) {
              currentScore = res?.data?.jxpjScore;
            } else {
              currentScore = res?.data?.zflScore;
            }
         
            _this.totalScore = currentScore;
            _this.lastDate = res?.data?.lastStaticticsTime;
            if (res.data?.tabList?.length > 0) {
              res.data?.tabList?.forEach((item) => {
                _this.totalMark.forEach((markItem) => {
                  if (item.dictCode == markItem.dictCode) {
                    markItem.total = item.score;
                  }
                });
                if (item.dictCode == "SSDP_JFFL_YJGL") {
                  _this.state.riskMapData = item.children;
                }
                if (item.dictCode == "SSDP_JFFL_ZHZF") {
                  item?.children?.forEach((zhzfItem) => {
                    if (zhzfItem.dictCode == "SSDP_JFFL_ZHZF_GLL") {
                      zhzfItem?.children?.forEach((manageItem) => {
                        if (
                          manageItem.dictCode == "SSDP_JFFL_ZHZF_GLL_TZSBGL"
                        ) {
                          _this.state.comprehensiveLaw = manageItem.children;
                        }
                        if (manageItem.dictCode == "SSDP_JFFL_ZHZF_GLL_SHWT") {
                          _this.state.ecologicalEnvironment =
                            manageItem.children;
                        }
                      });
                    }
                    if (zhzfItem.dictCode == "SSDP_JFFL_ZHZF_ZFL") {
                      _this.setLaw = zhzfItem.children;
                    }
                  });
                }
                if (item.dictCode == "SSDP_JFFL_JXPJ") {
                  _this.state.evaluate = item.children;
                }
              });
            }
          }
        });
    },
    formatDate() {
      let date = new Date();
      date.setHours(date.getHours() - 3);
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var day = date.getDate();
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var seconds = date.getSeconds();

      month = month < 10 ? "0" + month : month;
      day = day < 10 ? "0" + day : day;
      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      return (
        year +
        "-" +
        month +
        "-" +
        day +
        " " +
        hours +
        ":" +
        minutes +
        ":" +
        seconds
      );
    },
    currentPageChange(e) {
      this.page = e;
      this.gethistoryData();
    },
    pageSizeChange(e) {
      this.pageSize = e;
      this.gethistoryData();
    },
  },
};
</script>
<style lang="scss" scoped>
.date-title {
  font-size: 16px;
  color: #555555;
  line-height: 22px;
  padding: 10px;
  position: sticky;
  left: 0;
  top: 0;
  background: #f6f8f9;
  text-align: right;
}
.title {
  font-size: 20px;
  font-weight: bold;
  color: #222222;
  margin-bottom: 10px;
}
.setTitle {
  font-size: 20px;
  font-weight: bold;
  color: #222222;
  margin-left: 20px;
}
.setNewTitle {
  font-size: 17px;
  font-weight: 800;
  color: #222222;
}
.nopadding {
  background: transparent;
  section {
    & ~ section {
      margin-top: 20px;
    }
  }
  .card {
    background: #fff;
    border-radius: 8px;
    padding: 28px;
  }
  .top-container {
    display: flex;
    justify-content: center;
  }
}
.setLawSty {
  list-style: none;
  font-size: 14px;
  margin-left: 70px;
  color: #666;
  li {
    margin: 10px 0;
  }
}
</style>
