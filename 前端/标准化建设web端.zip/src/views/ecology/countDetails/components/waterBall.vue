<template>
	<div v-loading="loading" class="shell">
		<div class="setPoints">
		    <div id="waterBall" style="width: 200px; height: 200px;">{{ totalScore }}</div>
		</div>
		<ul class="setScore" v-if="$route.query.originPla==`appCenter`">
			<li v-for="(item) in totalMark" :key="item.id">
				<img :src="item.image" alt="">
				<div class="total">
					<div class="total_top">
						<span class="total_top_num">{{item.total}}</span> <span class="total_top_str">分</span>
					</div>
					<div class="total_bottom">
						{{item.label}}
					</div>
				</div>
			</li>
		</ul>
		<div v-if="$route.query.originPla==`PA`" style="display: flex;justify-content: center;font-weight: bold;font-size: 22px;">
			<span :style="{'color': paColor(totalScore)}">{{level}}类</span>
		</div>
	</div>
</template>

<script>
import { getPaColor } from "@/assets/js/echarStyleJs/common.js";
export default {
  props: {
    totalScore: {
      type: Number,
      default: 0,
    },
	totalMark: {
		type: Array,
		default:[]
	},
    loading: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
		level: ""
    //   totalMark: [
    //     {
    //       image:require('@/assets/images/4.png'),
    //       name: '应急管理',
    //       total: 446,
    //       id: 'A',
    //     },
    //     {
    //       image: require('@/assets/images/5.png'),
    //       name: '综合执法',
    //       total: 450,
    //       id: 'B',
    //     },
    //     {
    //       image: require('@/assets/images/6.png'),
    //       name: '绩效评价',
    //       total: 100,
    //       id: 'C',
    //     },
    //   ],
    };
  },
  mounted() {
	this.initWater();

  },
  watch: {
    totalScore(val) {
      this.initWater(val);
    },
  },
  methods: {
	paColor(value) {
		if (value >= 100) {
			this.level = "A";
	} else if (value >= 80 && value < 100) {
		this.level = "B";
	} else if (value >= 60 && value < 80) {
		this.level = "C";
	} else {
		this.level = "D";
	}
		return getPaColor(value)
	},
    initWater(val) {
		this.$nextTick(() => {
			let title = "";
			if (this.$route.query.originPla==`appCenter`) {
				title="总分";
            } else if (this.$route.query.originPla==`PA`) {
				title="绩效评价得分";
            } else {
				title="综合执法得分";
            }
        this.$echartsCase.echarStyle4('waterBall', val || 0, title);
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.shell{
	width: 100%;
}
.setPoints{
	display: flex;
    justify-content: center;
}
.setScore {
	display: flex;
    justify-content: space-around;
	list-style: none;
	li{
		display: flex;
		img{
			width: 80px;
			height: 80px;
			margin-right: 10px;
		}
		.total{
			display: flex;
			flex-direction: column;
			&_top{
				width: 100%;
				height: 50%;
				display: flex;
				align-items: center;
				line-height: 50%;
				justify-content: center;
				&_num{
					font-size: 34px;
					color: #222222;
					font-weight: 600;
				}
				&_str{
					display: inline-block;
					margin-top: 1vh;
					color: #666666;
				}
			}
			&_bottom{
				height: 50%;
				display: flex;
				align-items: center;
				line-height: 50%;
				justify-content: center;
				font-size: 17px;
				color: #666666;
				font-weight: 900;
			}
		}
	}
}
</style>
