<template>
	<div>
		<slot></slot>
		<div v-loading="loading" :id="setId" :style="{width:width,height:height,margin: 0,padding:0,}"></div>
	</div>
</template>

<script>
export default {
  props: {
    riskMapData: {
      type: Array,
      default: () => [],
    },
    comprehensiveLaw: {
      type: Array,
      default: () => [],
    },
    evaluate: {
      type: Array,
      default: () => [],
    },
    ecologicalEnvironment: {
      type: Array,
      default: () => [],
    },
    setId: {
      type: String,
      default: '',
    },
    loading: {
      type: Boolean,
      default: false,
    },
    width: {
      type: String,
      default: '',
    },
    height: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      waterContainer: null,
    };
  },
  watch: {
    riskMapData: {
      handler(val) {
        this.handleDataChange(val);
      },
      immediate: true,
    },
    comprehensiveLaw: {
      handler(val) {
        this.handleDataChange(val);
      },
      immediate: true,
    },
    evaluate: {
      handler(val) {
        this.handleDataChange(val);
      },
      immediate: true,
    },
    ecologicalEnvironment: {
      handler(val) {
        this.handleDataChange(val);
      },
      immediate: true,
    },
  },
  methods: {
    handleDataChange(data) {
      if (this.setId === 'management' && data.length > 0) {
        this.$nextTick(() => {
          this.initEchart(this.riskMapData);
        });
      } else if (this.setId === 'managementA' && data.length > 0) {
        this.$nextTick(() => {
          this.initEchart(data);
        });
      } else if (this.setId === 'managementB' && data.length > 0) {
        this.$nextTick(() => {
          this.initEchart(data);
        });
      } else if (this.setId === 'managementD' && data.length > 0) {
        this.$nextTick(() => {
          this.initEchart(data);
        });
      }
    },
    initEchart(data) {
      const label = data.map((item) => item.label);
      const value = data.map((item) => item.score);
      this.$echartsCase.echarStyle6(this.setId, value, label, "#409EFF");
    },
  },
  mounted() {},
};
</script>

<style lang="scss" scoped>
.select_style {
	display: flex;
	.el-form-item {
		margin-right: 50px;
	}
}
.serve-title {
	font-size: 18px;
	color: #222222;
	line-height: 25px;
	font-weight: bold;
	margin-bottom: 18px;
}
.water-container {
	margin-top: 30px;
	.water-group {
		margin-bottom: 18px;
		width: calc(50% - 18px);
		display: flex;
		flex-direction: column;
		background: #fff;
		border-radius: 10px;
		border: 1px solid #eeeeee;
		overflow: hidden;
		.water-header {
			display: flex;
			justify-content: space-between;
			background: #eee;
			padding: 14px 24px;
			color: #222;
			font-size: 16px;
			.title {
				font-weight: bold;
			}
			.val {
				i {
					font-style: normal;
				}
			}
		}
		.water-body {
			display: flex;
			flex-direction: column;
			padding: 20px 24px;
			&-header {
				display: flex;
				justify-content: space-between;
				color: #222;
				font-size: 14px;
				& ~ .water-body-header {
					margin-top: 20px;
				}
				.title {
					font-weight: bold;
				}
				.val {
					i {
						font-style: normal;
					}
				}
			}
			&-desc {
				margin-top: 6px;
				font-size: 14px;
				color: #666666;
				line-height: 20px;
			}
		}
	}
}
</style>
