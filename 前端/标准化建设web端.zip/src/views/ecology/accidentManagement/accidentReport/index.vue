<template>
  <div class="app-container">
    <div class="layer">
      <eagle-page
        :queryParams="queryParams"
        :controller="controller"
        @bindSelection="bindSelection"
        ref="EaglePage"
      >
        <template slot="slot-search">
          <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-select
              label-width="80px"
              @change="search()"
              label="事故类型"
              prop="equStatus"
              v-model="conditionsVals.accidentType"
              :data-source="params.siteAccidentType"
              placeholder="请选择事故类型"
              clearable
              size="small"
            >
            </eagle-select>
            <eagle-input
              label-width="70px"
              @changeEnter="search()"
              label="事故名称"
              :required="false"
              prop="keyWords"
              v-model.trim="conditionsVals.name"
              placeholder="请输入事故名称"
              clearable
              size="small"
            />
          </eagle-condition>
        </template>
        <template slot="slot-buttons">
          <el-button
            type="primary"
            icon="el-icon-plus"
            size="mini"
            @click="handleAdd"
            >新增</el-button
          >
          <el-button
            type="danger"
            icon="el-icon-delete"
            size="mini"
            @click="handleMultDelete"
            >批量删除
          </el-button>
        </template>
        <template slot="slot-table">
          <el-table-column label="事故名称" prop="name" align="left" />
          <el-table-column label="事故类型" align="left">
            <template slot-scope="scope">
              <span>{{
                formateDict(params.siteAccidentType, scope.row.accidentType)
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="事故等级" align="left">
            <template slot-scope="scope">
              <span>{{
                formateDict(params.siteAccidentLevel, scope.row.accidentLevel)
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="事故时间" align="left" prop="accidentDate">
            <template slot-scope="scope">
              <span>{{
                parseTime(scope.row.accidentDate, "{y}-{m}-{d} {h}:{i}")
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="事故发生方" align="left">
            <template slot-scope="scope">
              <span>{{
                formateDict(
                  params.siteAccidentHappenSide,
                  scope.row.accidentObj
                )
              }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="事故报告"
            align="left"
            prop="attachs"
            width="230px"
          >
            <template slot-scope="scope" v-if="scope.row.attachs">
              <eagle-row-attach v-model="scope.row.attachs" />
            </template>
          </el-table-column>
          <el-table-column label="修改人" prop="createChnName" align="left" />
          <el-table-column label="修改时间" align="left" prop="createDate">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d}") }}</span>
            </template>
          </el-table-column>
        </template>
        <template slot="slot-row-buttons" slot-scope="scope">
          <eagle-row-button type="primary" @click.stop="handleUpdate(scope.row)"
            >编辑</eagle-row-button
          >
          <eagle-row-button
            type="danger"
            size="mini"
            @click.stop="handleDelete(scope.row)"
            >删除
          </eagle-row-button>
        </template>
      </eagle-page>
      <eagle-form
        :controller="controller"
        :title="title"
        :form="form"
        width="1000px"
        labelWidth="120px"
        ref="EagleForm"
        @afterSave="afterSave"
        @bindData="bindData"
      >
        <eagle-block border>
          <el-row>
            <eagle-input
              label="事故名称"
              required
              v-model.trim="form.name"
              prop="name"
            >
            </eagle-input>
          </el-row>
          <el-row>
            <eagle-radio
              label="事故类型"
              prop="accidentType"
              v-model="form.accidentType"
              required
              :data-source="params.siteAccidentType"
            ></eagle-radio>
          </el-row>
          <el-row>
            <eagle-radio
              label="事故等级"
              required
              prop="accidentLevel"
              v-model.trim="form.accidentLevel"
              :data-source="params.siteAccidentLevel"
              @change="radioChangeAccidentLevel"
            ></eagle-radio>
          </el-row>
          <el-row>
            <eagle-date
              label="事故时间"
              type="datetime"
              format="yyyy-MM-dd HH:mm"
              required
              v-model="form.accidentDate"
              prop="accidentDate"
              :isPickerOptions="true"
            ></eagle-date>
          </el-row>
          <el-row>
            <eagle-radio
              label="事故发生方"
              required
              prop="accidentObj"
              v-model.trim="form.accidentObj"
              :data-source="params.siteAccidentHappenSide"
              @change="radioChangeType"
            ></eagle-radio>
          </el-row>
          <el-row>
            <eagle-input
              :label="this.accidentObjName"
              placeholder="请输入事故发生方部门/员工"
              v-model.trim="form.accidentOrgoruser"
              prop="accidentOrgoruser"
            ></eagle-input>
          </el-row>
          <el-row>
            <eagle-input
              label="事故备注"
              v-model.trim="form.remarks"
              prop="remarks"
            ></eagle-input>
          </el-row>
          <el-row>
            <eagle-attach
              label="事故报告"
              v-model="form.attachs"
              prop="attachs"
            ></eagle-attach>
          </el-row>
        </eagle-block>
      </eagle-form>
    </div>
    <window-check ref="WindowCheck"></window-check>
  </div>
</template>

<script>
import WindowCheck from "./windowCheck.vue";
import EagleRowAttach from "../../../../components/Eagle/eagle-row-attach.vue";
export default {
  components: {
    WindowCheck,
    EagleRowAttach,
  },
  name: "Attach",
  data() {
    return {
      accidentObjName: "本公司部门/员工",
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        name: "like",
        accidentType: "=",
      },
      // 查询条件
      conditionsVals: {
        name: "",
        accidentType: "",
      },
      controller: "site/accidentReport",
      accidentReportModulesController: "site/accidentReportModulesController",
      // 弹出层标题
      title: "事故记录",
      params: {
        siteAccidentType: [],
        siteAccidentHappenSide: [],
        siteAccidentLevel: [
          { id: "1", name: "一般事故" },
          { id: "2", name: "较大事故" },
          { id: "3", name: "重大事故" },
          { id: "4", name: "特大事故" },
        ],
      },
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,

      // 安全设施清单表格数据
      attachList: [],
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        dataType: "list",
      },
      // 表单参数
      form: { accidentType: "" },
    };
  },
  created() {
    this.initData();
  },
  mounted() {
    this.search();
  },
  methods: {
    radioChangeType(row) {
      if (row == "1") {
        this.accidentObjName = "本公司部门/员工";
      } else {
        this.accidentObjName = "相关方部门/员工";
      }
    },
    radioChangeAccidentLevel(row) {},
    //初始化页面所需字典等数据
    initData() {
      let _this = this;
      _this.common.getBatechParam(
        [
          _this.constParams.accident_type,
          _this.constParams.site_accident_happen_side,
        ],
        function (res) {
          _this.params.siteAccidentType = res.data.filter(
            (p) => p.paramId === _this.constParams.accident_type
          );
          _this.params.siteAccidentHappenSide = res.data.filter(
            (p) => p.paramId === _this.constParams.site_accident_happen_side
          );
        }
      );
    },
    bindData(data) {
      this.form = data;
    },
    search() {
      this.$refs.EaglePage.search(null);
    },
    handleModulesAdd() {
      this.$refs.WindowCheck.show();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.accidentObjName = "本公司部门/员工";
      this.$refs.EagleForm.handleAdd(null);
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      if (row.accidentObj == "2") {
        this.accidentObjName = "相关方部门/员工";
      } else {
        this.accidentObjName = "本公司部门/员工";
      }
      this.$refs.EagleForm.handleUpdate(row);
    },
    bindSelection(selection) {
      this.ids = selection.map((item) => item.id);
      this.single = selection.length != 1;
      this.multiple = !selection.length;
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      var _this = this;
      this.$refs.EaglePage.handleDelete(row, function (res) {
        _this.refresh();
      });
    },
    handleMultDelete() {
      var _this = this;
      var ids = this.$refs.EaglePage.getSelectionIds();
      this.$refs.EaglePage.handleMultDelete(ids, function (res) {
        _this.refresh();
      });
    },
    search() {
      this.$refs.EaglePage.search({
        conditions: this.$refs.EaglePage.getCondtions(
          this.conditionsVals,
          this.conditionsTypes
        ),
      });
    },
    //刷新
    refresh() {
      this.$refs.EaglePage.refresh(null);
    },
    //查询条件重置
    resetQuery() {
      this.conditionsVals.name = "";
      this.conditionsVals.accidentType = "";
      this.search();
    },
    afterSave(res, action) {
      if (action == "edit") {
        this.$refs.EaglePage.refresh();
      } else {
        this.$refs.EaglePage.search();
      }
    },
  },
};
</script>
