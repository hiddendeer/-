<template>
    <eagle-dialog :visible.sync="showSearch" title="事故报告模板" ref="Dialog" width="1000px">
        <div class="app-container">
            <eagle-condition @search="search()" @resetQuery="resetQuery()">
                <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" :required="false" prop="name" v-model="conditionsVals.name" placeholder="请输入模板名称" clearable size="small" />
            </eagle-condition>
            <eagle-page :queryParams="queryParams" :controller="controller" @bindSelection="bindSelection" ref="EaglePage" noPage="true" pageSize="999" :showCheckColumn="false">
                <!-- <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增</el-button>
                        </el-col>
                    </el-row>
                </template> -->
                <template slot="slot-table">
                    <el-table-column label="模板名称" align="left" prop="tName"></el-table-column>
                    <el-table-column label="附件" align="left" prop="attachs" width="230px">
                        <template slot-scope="scope" v-if="scope.row.attachs">
                            <eagle-row-attach v-model="scope.row.attachs" />
                        </template>
                    </el-table-column>
                    <el-table-column label="修改人" align="left" prop="createChnName" />
                    <el-table-column label="修改时间" align="left" prop="createDate" />
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button icon="el-icon-download" @click.stop="importTemplate(scope.row)">下载
                    </eagle-row-button>
                    <!-- <eagle-row-button type="danger" icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除</eagle-row-button> -->
                </template>
            </eagle-page>
            <!-- <eagle-form :controller="controller" :title="title" :form="form" width="800px" label-width="120px" ref="EagleForm" @afterSave="search" @bindData="bindData">
                <eagle-input label="模板名称"   v-model.trim="form.name" prop="name" required></eagle-input>
                <el-col>
                    <eagle-attach label="模板附件"   v-model="form.attachs" prop="attachs"></eagle-attach>
                </el-col>
            </eagle-form> -->
        </div>
    </eagle-dialog>
</template>


<script>
// import EagleAttach from "../../../components/Eagle/eagle-attach.vue";
// import EagleCheckbox from "../../../components/Eagle/eagle-checkbox.vue";
// import EagleDate from "../../../components/Eagle/eagle-date.vue";
// import EagleDialog from "../../../components/Eagle/eagle-dialog.vue";
// import EagleForm from "../../../components/Eagle/eagle-form.vue";
// import eagleInput from "../../../components/Eagle/eagle-input.vue";
export default {
    components: {
        // eagleInput,
        // EagleCheckbox,
        // EagleDate,
        // EagleAttach,
        // EagleForm,
        // EagleDialog,
    },
    name: "WindowCheck",
    data() {
        return {
            showSearch: true,
            queryParams: {
                name: "",
            },
            conditionsTypes: {
                name: "like",
            },
            conditionsVals: {
                name: "",
            },

            controller: "ecologyEnv/accidentReportModulesController",
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 标题
            title: "事故报告模板",
            // 表单参数
            form: {},
            // 表单校验
            rules: {},
            ids: [],
            params: {
                certKind: [],
            },
            isAdd: true,
            isneed: false,
        };
    },
    created() {},
    mounted() {},
    methods: {
        /** 下载模板操作 */
        importTemplate(row) {
            window.open(row.attFilePath);
        },
        show() {
            this.$refs.Dialog.show();
            this.initData();
            var _this = this;
            setTimeout(() => {
                _this.search();
            });
        },
        initData() {
            let _this = this;
        },
        bindData(data) {
            this.form = data;
        },
        /** 新增按钮操作 */
        handleAdd() {
            this.isAdd = true;
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.isAdd = false;
            this.$refs.EagleForm.handleUpdate(row);
        },
        bindSelection(selection) {
            this.ids = selection.map((item) => item.id);
            this.single = selection.length != 1;
            this.multiple = !selection.length;
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        handleMultDelete() {
            var _this = this;
            this.$refs.EaglePage.handleMultDelete(this.ids, function (res) {
                _this.refresh();
            });
        },
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        resetQuery() {
            this.conditionsVals.name = "";
            this.search();
        },
    },
};
</script>