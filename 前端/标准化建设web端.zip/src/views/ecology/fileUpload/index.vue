<template>
  <div class="app-container">
    <div class="layer">
      <el-card class="box-card">
        <el-form
          :form="ruleForm"
          width="600px"
          label-width="250px"
          ref="EagleForm"
          @afterSave="afterSave"
          @bindData="bindData"
        >
          <eagle-attach
            label="环境影响审批报告:"
            btnTitle="附件上传"
            fileFormat="image"
            v-model="ruleForm.attachs1"
            @handleChange="handleChange1"
            :count="1"
            prop="attachs"
          ></eagle-attach>
          <eagle-attach
            label="企业排污许可证:"
            btnTitle="附件上传"
            fileFormat="image"
            v-model="ruleForm.attachs2"
            @handleChange="handleChange2"
            :count="1"
            prop="attachs"
          ></eagle-attach>
          <!-- <eagle-attach
            label="污染防治设施安全风险评估报告:"
            btnTitle="附件上传"
            fileFormat="image"
            v-model="ruleForm.attachs3"
            @handleChange="handleChange3"
            :count="1"
            prop="attachs"
          ></eagle-attach> -->
        </el-form>
      </el-card>
    </div>
  </div>
</template>
  
  <script>
import eagleAttach from "./components/eagle-attach.vue";
import api from "./server/api.js";
export default {
  components: {
    eagleAttach,
  },
  data() {
    return {
      ruleForm: {
        docType: "2",
        docName: "",
        attachs1: [],
        attachs2: [],
        attachs3: [],
      },
      rules: {
        attachs: [
          {
            required: true,
            message: "请上传文件！",
            trigger: "blur",
          },
        ],
        docName: [
          {
            required: true,
            message: "请输入文件名称！",
            trigger: "blur",
          },
        ],
      },
    };
  },
  mounted() {
    this.getFileInfo();
  },

  methods: {
    async getFileInfo() {
      const res = await api.getAllFile({ businessDetailType: "" });
      if (res?.code == 200) {
        res?.data?.forEach(item => {
            if (item.businessDetailType == 'eia_report') {
                this.ruleForm.attachs1 = [item];
            }
            if (item.businessDetailType == 'epd_permit') {
                this.ruleForm.attachs2 = [item];
            }
            if (item.businessDetailType == 'ppf_sra_report') {
                this.ruleForm.attachs3 = [item];
            }
        })
      }
    },
    async handleChange1(e) {
      if (Array.isArray(e) && e?.length > 0) {
        let jsonData = {
          businessDetailType: "eia_report",
          fileIds: [e?.[0]?.id],
        };

        const res = await api.saveFile(jsonData);
        if (res?.code == "200") {
          this.$message.success("上传成功");
        }
      }
    },
    async handleChange2(e) {
      if (Array.isArray(e) && e?.length > 0) {
        let jsonData = {
          businessDetailType: "epd_permit",
          fileIds: [e?.[0]?.id],
        };

        const res = await api.saveFile(jsonData);
        if (res?.code == "200") {
          this.$message.success("上传成功");
        }
      }
    },
    async handleChange3(e) {
      if (Array.isArray(e) && e?.length > 0) {
        let jsonData = {
          businessDetailType: "ppf_sra_report",
          fileIds: [e?.[0]?.id],
        };

        const res = await api.saveFile(jsonData);
        if (res?.code == "200") {
          this.$message.success("上传成功");
        }
      }
    },
    afterSave(e) {},
    bindData(e) {},
  },
};
</script>