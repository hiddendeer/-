import request from '@/utils/request'

export default class api {
// 登录方法
static saveFile(data) {
  return request({
    url: '/ecologyEnv/fourColor/ecologicalEnvironment/saveFile',
    method: 'post',
    data
  })
}
static getAllFile(data) {
  return request({
    url: '/ecologyEnv/fourColor/ecologicalEnvironment/getAllFile',
    method: 'post',
    data
  })
}
}
