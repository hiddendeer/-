<template>
    <div class="app-container">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-input label-width="120px" label="文件名称" @changeEnter="search()" :required="false" prop="name"
                labelWidth="70px" v-model="conditionsVals.name" placeholder="请输入文件名称" clearable size="small" />
            <eagle-select label-width="120px" label="状态" @change="search()" prop="status"
                v-model="conditionsVals.status" :data-source="params.status" placeholder="请选择状态" clearable size="small">
            </eagle-select>
        </eagle-condition>
        <eagle-page :queryParams="queryParams" dataType="listMain" ref="EaglePage" :noPage="true" :pageSize="999" btnWidth="130px">
            <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleMultOnline()">批量编辑
                        </el-button>
                    </el-col>
                    <!-- <el-col :span="1.5">
                        <el-button type="primary" plain size="mini" @click="handleMultStart">批量启用</el-button>
                    </el-col>
                    <el-col :span="1.5">
                        <el-button type="danger" plain size="mini" @click="handleMultDisable">批量不适用</el-button>
                    </el-col> -->
                </el-row>
            </template>
            <template slot="slot-table">
                <el-table-column label="制度名称" align="left" prop="name" width="200" />
                <el-table-column label="描述" align="left" prop="desc">
                </el-table-column>
                <el-table-column label="制度文件" align="left" prop="unSignedAttachs" width="230px">
                    <template slot-scope="scope">
                        <eagle-row-attach v-model="scope.row.unSignedAttachs"></eagle-row-attach>
                    </template>
                </el-table-column>
                <!-- <el-table-column label="状态"  align="left" prop="status" width="80px">
                    <template slot-scope="scope">
                        <span>{{ statusFormat(scope.row.status) }}</span>
                    </template>
                </el-table-column> -->
                <el-table-column label="操作人" align="left" prop="editChnName" width="100px" />
                <el-table-column label="操作时间" align="left" prop="editDate" width="100px">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.editDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <!-- <eagle-row-button v-if="scope.row.status!=-10" @click.stop="handleDisable(scope.row)">不适用</eagle-row-button>
                <eagle-row-button v-if="scope.row.status==-10" @click.stop="handleStart(scope.row)">启用</eagle-row-button> -->
                <eagle-row-button v-if="scope.row.status==10" @click.stop="handleDelete(scope.row.code)">删除
                </eagle-row-button>
                <eagle-row-button v-if="scope.row.status!=-10&&scope.row.local!=true"
                    @click.stop="handleOnline(scope.row)">在线编辑</eagle-row-button>
            </template>
        </eagle-page>
    </div>
</template>

<script>
export default {
    components: {},
    name: "guideline-file",
    data() {
        return {
            showSearch: true,
            queryParams: {
                type: "A"
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                status: "=",
                name: "like"
            },
            // 查询条件
            conditionsVals: {
                status: null,
                name: ""
            },
            form: {
                libCode: "",
                attachs: "",
                chnName: "",
                signDate: null,
                isLocal: true
            },
            controller: "ecologyEnv/guidelineFile", //对应后端控制器
            params: {
                status: [
                    { id: "0", name: "未制定" },
                    { id: "5", name: "待签署" },
                    { id: "10", name: "已签署" },
                    { id: "-10", name: "不适用" }
                ]
            }
        };
    },

    created() { },
    mounted() {
        this.search();
    },
    methods: {
        handleOnline(row) {
            if (row.code) {
                this.$router.push({
                    path: "/onlineEditBlock",
                    query: {
                        menuSysType: "SiteGuideline",
                        codes: row.code,
                        mainCode: row.onlineCode
                    }
                });
            }
        },
        handleMultOnline() {
            var code = this.getUnLocalSelectionCodes();
            if (code) {
                this.$router.push({
                    path: "/onlineEditBlock",
                    query: {
                        menuSysType: "SiteGuideline",
                        codes: code,
                        mainCode: ""
                    }
                });
            }
        },

        // handleDisable(row) {
        //     this.disablePost(row.code);
        // },
        // handleStart(row) {
        //     this.startPost(row.code);
        // },
        //批量不适用
        // handleMultDisable() {
        //     var codes = this.getSelectionCodes();
        //     if (codes) {
        //         this.disablePost(codes);
        //     }
        // },
        // handleMultStart() {
        //     var codes = this.getSelectionCodes();
        //     if (codes) {
        //         this.startPost(codes);
        //     }
        // },
        handleDelete(code) {
            if (!code) {
                code = this.getSelectionCodes();
            }
            this.deletePost(code);
        },
        deletePost(codes) {
            var _this = this;
            var url = "/" + this.controller + "/deleteByCodes/" + codes;
            this.$confirm("是否确认废止选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            })
                .then(function () {
                    _this.http.postLoading(_this.loading(), url, {}, function (res) {
                        _this.refresh();
                        _this.msgSuccess("废止成功");
                    })
                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         _this.search();
                    //         _this.msgSuccess("废止成功");
                    //     } else {
                    //         _this.msgError("废止失败");
                    //     }
                    // });
                })
                .catch(() => { });
        },
        // disablePost(codes) {
        //     var _this = this;
        //     var url = "/" + this.controller + "/disableByCodes/" + codes;
        //     this.$confirm("是否确认不适用选中数据项吗?", "警告", {
        //         confirmButtonText: "确定",
        //         cancelButtonText: "取消",
        //         type: "warning",
        //     })
        //         .then(function () {
        //             return _this.http.post(url).then((res) => {
        //                 if (res.code == 200) {
        //                     _this.search();
        //                     _this.msgSuccess("作废成功");
        //                 } else {
        //                     _this.msgError("作废失败");
        //                 }
        //             });
        //         })
        //         .catch(() => {});
        // },
        // startPost(codes) {
        //     var _this = this;
        //     var url = "/" + this.controller + "/startByCodes/" + codes;
        //     return _this.http
        //         .post(url)
        //         .then((res) => {
        //             if (res.code == 200) {
        //                 _this.search();
        //                 _this.msgSuccess("启用成功");
        //             } else {
        //                 _this.msgError("启用失败");
        //             }
        //         })
        //         .catch(() => {});
        // },
        getSelectionCodes() {
            var selections = this.$refs.EaglePage.getSelection();
            if (selections.length == 0) {
                this.msgError("请先选择数据项");
                return false;
            }
            var arryCodes = [];
            selections.forEach(element => {
                arryCodes.push(element.code);
            });
            return arryCodes.join(",");
        },
        getUnLocalSelectionCodes() {
            var selections = this.$refs.EaglePage.getSelection();
            if (selections.length == 0) {
                this.msgError("请先选择数据项");
                return false;
            }
            var arryCodes = [];
            selections.forEach(element => {
                if (element.local != true) {
                    arryCodes.push(element.code);
                }
            });
            if (arryCodes.length == 0) {
                this.msgError("请先选择非本地上传数据项");
                return false;
            }
            return arryCodes.join(",");
        },
        //查询
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getLibList",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                )
            });
        },

        //查询条件重置
        resetQuery() {
            this.conditionsVals.status = null;
            this.conditionsVals.name = "";
            this.search();
        }
        // statusFormat(status) {
        //     switch (status) {
        //         case 0:
        //             return "待制定";
        //         case 5:
        //             return "待签署";
        //         case 10:
        //             return "已签署";
        //         case -10:
        //             return "不适用";
        //     }
        // },
    }
};
</script>