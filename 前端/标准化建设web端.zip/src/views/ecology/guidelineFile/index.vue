<template>
    <div class="app-container">
        <div class="layer">
            <eagle-page :queryParams="queryParams" ref="EaglePage" :rowClassName="getCompateClassName" :noPage="true"
                :controller="controller" :pageSize="999" btnWidth="200">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input @changeEnter="search()" label="制度名称" :required="false" prop="docName"
                            labelWidth="80px" v-model="conditionsVals.docName" placeholder="请输入制度名称" clearable
                            size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8" style="margin-left:10px">
                        <el-col :span="1.5">
                            <el-button type="primary" icon="el-icon-edit" size="mini" @click="handleMultOnline()">批量编辑
                            </el-button>
                        </el-col>
                        <el-col :span="1.5">
                            <el-button type="primary" icon="el-icon-circle-check" size="mini" @click="handleMult(1)">
                                批量适用</el-button>
                        </el-col>
                        <el-col :span="1.5">
                            <el-button type="danger" icon="el-icon-circle-close" size="mini" @click="handleMult(2)">
                                批量不适用</el-button>
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">

                    <el-table-column label="制度名称" align="left" prop="docName" width="230px" />
                    <el-table-column label="描述" align="left" prop="docDesc" width="260px">
                    </el-table-column>
                    <el-table-column label="文件" align="left" prop="wordAttachs" width="230px">
                        <template slot-scope="scope">
                            <eagle-row-attach v-model="scope.row.wordAttachs"></eagle-row-attach>
                        </template>
                    </el-table-column>
                    <el-table-column label="状态"> <template slot-scope="scope" width="60px">
                            <span v-if="scope.row.isApply == 1" style="color:green;">适用</span>
                            <span v-if="scope.row.isApply == 2" style="color:red;">不适用</span>
                        </template></el-table-column>
                    <el-table-column label="操作人" align="left" prop="editChnName" width="100px" />
                    <el-table-column label="更新时间" align="left" prop="editDate" width="100px">
                        <template slot-scope="scope">
                            <span>{{ parseTime(scope.row.editDate, "{y}-{m}-{d}") }}</span>
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <template v-if="scope.row.isApply == 1 && (scope.row.fStatus == 10 || scope.row.fStatus == 0)">
                        <eagle-row-button type="primary"
                            v-if="scope.row.wordAttachs != '' && scope.row.wordAttachs != '[]'"
                            @click.stop="handleOnlineAdd(scope.row)">更新</eagle-row-button>
                        <eagle-row-button type="primary" v-else @click.stop="handleOnlineAdd(scope.row)">编辑
                        </eagle-row-button>

                        <eagle-row-button type="danger" @click.stop="handleDisable(scope.row)">不适用</eagle-row-button>
                        <eagle-row-button type="danger" v-if="scope.row.fStatus == 10"
                            @click.stop="handleNullify(scope.row)">作废</eagle-row-button>
                    </template>

                    <template v-if="scope.row.isApply == 2">
                        <eagle-row-button type="primary" @click.stop="handleStart(scope.row)">启用</eagle-row-button>
                    </template>

                    <template v-if="scope.row.fStatus == -10">
                        <eagle-row-button type="primary" @click.stop="handleRecovery(scope.row)">恢复</eagle-row-button>
                    </template>

                </template>
            </eagle-page>
        </div>
    </div>
</template>

<script>
export default {
    components: {},
    name: "guideline-file",
    data() {
        return {
            projectId: "",
            queryParams: {
                dataType: "guideline",
                projectId: this.$route.query.projectId ?? "",
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                status: "=",
                name: "like",
            },
            // 查询条件
            conditionsVals: {
                status: null,
                name: "",
            },

            controller: "ecologyEnv/ledgerTempList", //对应后端控制器
            params: {},
        };
    },

    created() { },
    mounted() {
        this.search();
    },
    methods: {
        getCompateClassName(row) {
            return row.row.isApply == 1 ? "" : "notApply";
        },
        //查询
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        //批量编辑
        handleMultOnline() {
            let selections = this.$refs.EaglePage.getSelection();
            if (selections.length <= 0) {
                this.msgError("请选择数据");
                return;
            }
            let tempCodes = selections.map((item) => item.tempCode);
            tempCodes.join(",");
            let _this = this;
            var queryParams = {};
            queryParams.menuSysType = "SiteGuideline";
            queryParams.tempCode = tempCodes;
            queryParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
            queryParams.projectId = this.$route.query.projectId ?? "";

            _this.$router.push({
                path: "/onlineEditTempFile",
                query: queryParams,
            });
        },
        //批量不适用
        handleMult(action) {
            let selections = this.$refs.EaglePage.getSelection();
            if (selections.length <= 0) {
                this.msgError("请选择数据");
                return;
            }

            let applyIds = selections.map((item) => item.applyId);
            let tempCodes = selections.map((item) => item.mainCode);
            let mainCodes = selections.map((item) => item.code);
            let companyCode = this.$route.query.enterpriseCode;

            let url =
                "/ecologyEnv/ledgerTempListApply/updateByApply/" +
                action +
                "?id=" +
                applyIds +
                "&mainCode=" +
                mainCodes +
                "&ledgerTempCode=" +
                tempCodes +
                "&companyCode=" +
                companyCode;
            let _this = this;
            var html = "不适用";
            if (action == "1") {
                html = "适用";
            }
            this.$confirm("是否确认" + html + "选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.refresh();
                            _this.msgSuccess(html + "成功");
                        }
                    );

                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         _this.msgSuccess(html + "成功");
                    //         _this.refresh();
                    //     } else {
                    //         _this.msgError(html + "失败");
                    //     }
                    // });
                })
                .catch(() => { });
        },
        //批量启用
        handleMultStart() { },

        //编辑，更新
        handleOnlineAdd(row) {
            let _this = this;
            var queryParams = {};
            queryParams.menuSysType = "SiteGuideline";
            queryParams.tempCode = row.tempCode;
            queryParams.fileCode = row.fileCode;
            queryParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";

            queryParams.projectId = this.$route.query.projectId ?? "";

            _this.$router.push({
                path: "/onlineEditTempFile",
                query: queryParams,
            });
        },
        //不适用
        handleDisable(row) {
            let id = row.applyId;
            let url =
                "/site/ledgerTempListApply/updateByApply/2?id=" +
                id +
                "&mainCode=" +
                row.code +
                "&ledgerTempCode=" +
                row.mainCode +
                "&companyCode=" +
                row.companyCode;
            let _this = this;
            this.$confirm("是否确认不适用选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.refresh();
                            _this.msgSuccess("不适用成功");
                        }
                    );
                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         _this.msgSuccess("不适用成功");
                    //         _this.refresh();
                    //     } else {
                    //         _this.msgError("不适用失败");
                    //     }
                    // });
                })
                .catch(() => { });
        },
        //启用
        handleStart(row) {
            let id = row.applyId;
            let url =
                "/site/ledgerTempListApply/updateByApply/1?id=" +
                id +
                "&mainCode=" +
                row.code +
                "&ledgerTempCode=" +
                row.mainCode +
                "&companyCode=" +
                row.companyCode;
            let _this = this;
            this.$confirm("是否确认启用用选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.refresh();
                            _this.msgSuccess("启用成功");
                        }
                    );
                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         _this.msgSuccess("启用成功");
                    //         _this.refresh();
                    //     } else {
                    //         _this.msgError("启用失败");
                    //     }
                    // });
                })
                .catch(() => { });
        },

        //作废
        handleNullify(row) {
            var _this = this;

            var ids = [];
            ids.push(row.fId);
            ids.join(",");

            if (ids == "") {
                _this.msgError("请先选择数据项");
                return false;
            }
            var url = "/site/fileOnlineDoc/disable/" + ids;
            this.$confirm("是否确认作废选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.refresh();
                            _this.msgSuccess("作废成功");
                        }
                    );
                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         _this.msgSuccess("作废成功");
                    //         _this.refresh();
                    //     } else {
                    //         _this.msgError("作废失败");
                    //     }
                    // });
                })
                .catch(() => { });
        },
        //恢复
        handleRecovery(row) {
            var ids = [];
            ids.push(row.fId);
            ids.join(",");

            if (ids == "") {
                _this.msgError("请先选择数据项");
                return false;
            }
            var url = "/ecologyEnv/fileOnlineDoc/restore/" + ids;
            let _this = this;
            this.$confirm("是否确认恢复选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.refresh();
                            _this.msgSuccess("恢复成功");
                        }
                    );
                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         _this.msgSuccess("恢复成功");
                    //         _this.refresh();
                    //     } else {
                    //         _this.msgError("现行失败");
                    //     }
                    // });
                })
                .catch(() => { });
        },
        //刷新
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        resetQuery() {
            this.conditionsVals.docName = "";
            this.search();
        },
    },
};
</script>
