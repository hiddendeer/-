<template>
    <div class="app-container">
        <div class="layer">
      

            <eagle-page :queryParams="queryParams" :controller="controller" ref="EaglePage" :showCheckColumn="false" btn-width="160px">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input label-width="120px" :inputStyle="{ width: '360px' }" label="编码" @changeEnter="search" prop="planname" v-model="conditionsVals.codeNo" placeholder="请输入数据中心编号进行模糊查询" clearable size="small" />
                        <eagle-input label-width="120px" :inputStyle="{ width: '360px' }" label="名称" @changeEnter="search" prop="planname" v-model="conditionsVals.name" placeholder="请输入数据中心编号进行模糊查询" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                            </el-button>
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">
                    <el-table-column label="数据中心编号" align="left" prop="codeNo" width="300" />
                    <el-table-column label="类型" align="left" prop="docType">
                        <template slot-scope="scope">
                            <span>{{ formateDict(params.fileOnlineTempDocType, scope.row.docType) }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column label="报表类型" align="left" prop="reportTypeCode">
                        <template slot-scope="scope">
                            <span>{{ formateDict(report_type, scope.row.reportTypeCode) }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column label="报表名称" align="left" prop="name" />

                    <el-table-column label="描述" align="left" prop="remarks" width="300" />
                    <el-table-column label="模板" align="left" prop="tempDoc" width="230px">
                        <template slot-scope="scope">
                            <eagle-row-attach v-model="scope.row.tempDoc"></eagle-row-attach>
                        </template>
                    </el-table-column>
                    <el-table-column label="示例文件" prop="example" width="230px">
                        <template slot-scope="scope">
                            <eagle-row-attach v-model="scope.row.example"></eagle-row-attach>
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="primary" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>
                    <eagle-row-button type="danger" @click="handleDelete(scope.row)">删除</eagle-row-button>
                </template>
            </eagle-page>
            <eagle-form :controller="controller" title="模板信息" :form="form" width="800px" label-width="140px" ref="EagleForm" @afterSave="search" @bindData="bindData">
                <eagle-block border>
                    <eagle-input label="数据中心编号" prop="codeNo" required v-model="form.codeNo" />
                    <eagle-input label="数据名称" prop="name" required v-model="form.name" />

                    <el-row>
                        <eagle-choose-industry v-model="form.applyProfessionCode" prop="applyProfessionCode" required :names.sync="form.applyProfessionName"></eagle-choose-industry>
                    </el-row>

                    <el-row>
                        <eagle-choose-region :hasAll="true" :checkStrictly='{ checkStrictly: true }' label="所在地区" v-model="form.belongArea" prop="belongArea" required></eagle-choose-region>
                    </el-row>

                    <eagle-select label="类型" prop="docType" :data-source="params.fileOnlineTempDocType" required v-model="form.docType" />

                    <eagle-select label="报表类型" prop="reportTypeCode" :data-source="report_type" required v-model="form.reportTypeCode" />

                    <el-form-item label="是否指定企业">
                        <el-switch active-color="#13ce66" v-model="form.assign" />
                    </el-form-item>
                    <eagle-choose label="选择企业" v-if="form.assign == true" @change="openEnterpriseChoose" v-model="form.enterpriseNames" />

                    <eagle-input label="查询语句" type="textarea" :rows="setRows" prop="sqlText" required v-model="form.sqlText" />
                    <eagle-input label="描述" type="textarea" prop="remarks" v-model="form.remarks" />

                    <eagle-attach :count="1" label="模板" required v-model="form.tempDoc" prop="tempDoc">
                    </eagle-attach>
                    <eagle-attach accept=".doc,.docx,.pdf" :count="1" label="示例文件" prop="attach" v-model="form.example">
                    </eagle-attach>
                </eagle-block>
            </eagle-form>
            <eagle-select-project-enterprise ref="projectEnterPriseDialog" :single="false" @callBack="handelEnterpriseChoose"></eagle-select-project-enterprise>
            <!-- 行业组件 -->
            <!-- <SelectIndustry :selectIndustryVisible="selectIndustryVisible" @handleSelectClose="handleSelectClose" @handleSelectSubmit="handleSelectSubmit" /> -->
        </div>
    </div>
</template>

<script>
import eagleSelectProjectEnterprise from "@/views/project/components/selectProjectEnterprise/eagleSelectProjectEnterprise";
import eagleChooseIndustry from "@/views/ecologySupport/libTemp/components/selectIndustry/eagle-choose-industry.vue";
import eagleChooseRegion from "@/views/ecologySupport/libTemp/components/region/eagle-choose-region.vue";
// import EagleAttach from "@/components/Eagle/eagle-attach.vue";
// import EagleSelect from '../../../../components/Eagle/eagle-select.vue';
export default {
    name: "fileToolDataSource",
    components: {
        eagleSelectProjectEnterprise,
        eagleChooseIndustry,
        eagleChooseRegion,
        // "eagle-attach": EagleAttach,
    },
    data() {
        return {
            report_type: [],
            conditionsVals: {
                codeNo: "",
                name: "",
            },
            params: {
                fileOnlineTempDocType: [],
            },

            conditionsTypes: {
                codeNo: "like",
            },
            queryParams: {
                dataType: "list",
            },
            controller: "support/fileToolDataSource",
            form: {},
            setRows: 15,
            //行业
            selectIndustryVisible: false,
        };
    },
    created() {
        this.initData();
        this.initParams();
    },
    mounted() {
        this.search();
    },
    methods: {
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.doc_type],
                function (res) {
                    _this.params.fileOnlineTempDocType = res.data.filter(
                        (p) => p.paramId === _this.constParams.doc_type
                    );
                }
            );
        },
        openEnterpriseChoose() {
            this.$refs.projectEnterPriseDialog.show(
                this.form.enterpriseCodes,
                this.form.enterpriseNames
            );
        },
        handelEnterpriseChoose(data) {
            this.form.enterpriseCodes = data.code;
            this.form.enterpriseNames = data.name;
        },
        //formateDict(dataSource, value,id,name,',')
        initParams() {
            let _this = this;
            _this.common.getBatechParam(["sys_bi_report_type"], function (res) {
                _this.report_type = res.data.filter(
                    (p) => p.paramId === "sys_bi_report_type"
                );
            });
        },
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        //查询条件重置
        resetQuery() {
            this.conditionsVals.codeNo = "";
            this.search();
        },
        //行业
        handleChooseProfession() {
            this.selectIndustryVisible = true;
        },
        handleSelectClose() {
            this.selectIndustryVisible = false;
        },
        handleSelectSubmit(val) {
            this.selectIndustryVisible = false;
            let str = "";
            val.forEach((item) => {
                str += item.name + ";";
            });
            this.form.applyProfessionNames = str.substr(0, str.length - 1);
        },
        //地区
        handleChooseApplyArea(val) {
            this.from.belongArea = val;
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        bindData(data) {
            this.form = data;
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        //刷新
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
    },
};
</script>
<style  lang="scss">
.form-title {
    .mustField {
        color: red;
        line-height: 36px;
    }
}

.industry {
    margin-left: 65px;
    margin-bottom: 20px;
}

.col {
    padding-right: 240px;
}
</style>