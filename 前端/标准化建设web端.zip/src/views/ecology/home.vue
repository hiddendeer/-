<template>
    <div class="divSite_home_container app-container">
        <div class="layer">
            <div>
                <eagle-condition style="margin-bottom:10px;" @search="search()" :showReset="false">
                    <eagle-year label-width="50px" label="年度" type="years" @change="search()"
                        v-model="conditions.year" />
                </eagle-condition>
            </div>
            <div class="div_content">
                <div class="div_left_content">
                    <el-card :body-style="{ padding: '0px 10px 10px 10px' }">
                        <div slot="header" class="clearfix">
                            <!-- <span>一企一档</span> -->
                        </div>
                        <div class="div_one_ent_one_record_content">
                            <!-- <div>
                            <el-card shadow="never" :body-style="{ padding: '10px 0px' }">
                                <div slot="header" class="clearfix">
                                    <span><i class="el-icon-s-grid"></i>关键风险点</span>
                                </div>
                                <div>
                                    图一。图二。图三
                                </div>
                            </el-card>
                        </div> -->
                            
                            <div class="div_block_contet">
                                <div class="div_block_content_child" @click.stop="goto('EntPostCertificate')">
                                    <div class="div_block_content_title">
                                        <img :src="certificate[0].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[0].name }}</div>
                                    <div><span>{{ dataListLeft.certificateNum || 0 }}</span>{{ certificate[0].unit }}</div>
                                </div>
                                <!-- <div class="div_block_content_child" @click.stop="goto('EntBuilding')">
                                    <div class="div_block_content_title"> <img :src="certificate[1].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[1].name }}</div>
                                    <div><span>{{ dataListLeft.buildNum || 0 }}</span>{{ certificate[1].unit }}</div>
                                </div> -->
                                <div class="div_block_content_child" @click.stop="goto('EntPost')">
                                    <div class="div_block_content_title"> <img :src="certificate[2].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[2].name }}</div>
                                    <div><span>{{ dataListLeft.workNum || 0 }}</span>{{ certificate[2].unit }}</div>
                                </div>
                                <div class="div_block_content_child" @click.stop="goto('EntEquipment')">
                                    <div class="div_block_content_title"> <img :src="certificate[3].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[3].name }}</div>
                                    <div><span>{{ dataListLeft.equipmentNum || 0 }}</span>{{ certificate[3].unit }}</div>
                                </div>
                                <!-- <div class="div_block_content_child" @click.stop="goto('EntMaterial')">

                                    <div class="div_block_content_title"> <img :src="certificate[4].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[4].name }}</div>
                                    <div><span>{{ dataListLeft.materialNum || 0 }}</span>{{ certificate[4].unit }}</div>
                                </div>
                                <div class="div_block_content_child" @click.stop="goto('EntLimitSpace')">
                                    <div class="div_block_content_title"> <img :src="certificate[5].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[5].name }}</div>
                                    <div><span>{{ dataListLeft.spaceNum || 0 }}</span>{{ certificate[5].unit }}</div>
                                </div> -->
                                <div class="div_block_content_child" @click.stop="goto('EntRelation')">
                                    <div class="div_block_content_title"> <img :src="certificate[6].setImg" alt="">
                                    </div>
                                    <div> {{ certificate[6].name }}</div>
                                    <div><span>{{ dataListLeft.relationNum || 0 }}</span>{{ certificate[6].unit }}</div>
                                </div>
                            </div>
                        </div>
                    </el-card>
                    <el-card :body-style="{ padding: '10px 10px' }">
                        <div slot="header" class="clearfix">
                            <span>风险分级管控信息</span>
                        </div>
                        <div class="div_risk_container">
                            <div class="div_risk_control_container">
                                <div class="div_risk_title">风险分级管控信息</div>
                                <div class="div_risk_control_content">
                                    <div><span class="span_round span_round_green"></span>辨识风险点<span
                                            class="span_purple">{{ dataListLeft.pointNum }}</span>个</div>
                                    <div><span class="span_round span_round_yellow"></span>生成风险告知卡<span
                                            class="span_purple">{{ dataListLeft.cardNum }}</span>个</div>
                                    <!-- <div><span class="span_round span_round_yellow"></span>编制检查表<span class="span_purple">{{dataListLeft.checkNum}}</span>个</div> -->
                                    <div><span class="span_round span_round_yellow"></span>生成作业规程<span
                                            class="span_purple">{{ dataListLeft.regulationNum }}</span>个</div>
                                </div>
                            </div>
                            <div class="div_risk_point_container">
                                <div class="div_risk_title">重要风险点</div>
                                <div>
                                    <el-row>
                                        <template v-for="(item, index) in riskPointList">
                                            <el-col :span="12" v-bind:key="index">
                                                <div class="div_evaluation">
                                                    <div class="div_evaluation_rpName" :title="item.rp_name">
                                                        {{ item.rp_name }}</div>
                                                    <div :class="item.evaluation_value | get_levelClass"
                                                        :title="item.evaluation_name" size="mini"> {{
                                                                item.evaluation_name
                                                        }} </div>
                                                </div>
                                            </el-col>
                                        </template>
                                    </el-row>
                                </div>
                            </div>
                        </div>
                        <div class="div_risk_container">
                            <div class="div_risk_distributed_container">
                                <div class="div_risk_title">风险分布</div>
                                <div v-if="riskDistributed && riskDistributed.length > 0">
                                    <div id="myChartRiskDistributed" style="height:247px; width:100%;"></div>
                                </div>
                                <div v-else>
                                    <el-empty :image-size="50">
                                    </el-empty>
                                </div>
                            </div>
                        </div>
                    </el-card>
                </div>
                <div class="div_right_content">
                    <div class="div_right_top">
                        <div class="div_right_top_child">
                            <el-card style="height:155px" :body-style="{ padding: '10px 10px' }">
                                <div slot="header" class="clearfix">
                                    目标职责信息
                                </div>
                                <div>
                                    <!-- <div>
                                    <span class="span_round span_round_green"></span>{{responsibilityList[0].name}}：
                                    <span>0有没有？</span>
                                    {{responsibilityList[0].unit}}
                                </div> -->
                                    <div>
                                        <span class="span_round span_round_green"></span>{{ responsibilityList[1].name }}：
                                        <span>{{ dataListLeft.deptResponseNum || 0 }}</span>
                                        {{ responsibilityList[1].unit }}
                                    </div>
                                    <div>
                                        <span
                                            class="span_round span_round_yellow"></span>{{ responsibilityList[2].name }}：
                                        <span>{{ dataListLeft.postResponseNum || 0 }}</span>
                                        {{ responsibilityList[2].unit }}
                                    </div>
                                    <div>
                                        <span
                                            class="span_round span_round_yellow"></span>{{ responsibilityList[3].name }}：
                                        <span>{{ dataListLeft.meetingNum || 0 }}</span>
                                        {{ responsibilityList[3].unit }}
                                    </div>
                                </div>
                            </el-card>
                        </div>
                        <div class="div_right_top_child">
                            <el-card style="height:155px" :body-style="{ padding: '10px 10px' }">
                                <div slot="header" class="clearfix">
                                    制度化管理
                                </div>
                                <div>
                                    <div>
                                        <span class="span_round span_round_green"></span>生成规章制度：
                                        <span>{{ dataListLeft.rulesNum || 0 }}</span>
                                        份
                                    </div>
                                </div>
                                <!-- <div>
                                    <div>
                                        <span class="span_round span_round_green"></span>生成适用法律法规：
                                        <span>{{ Statistic.lawQty || 0 }}</span>
                                        条
                                    </div>
                                </div> -->
                            </el-card>
                        </div>
                    </div>
                    <div class="div_right_middle">
                        <el-card :body-style="{ padding: '10px 10px' }">
                            <div slot="header" class="clearfix">
                                <span>安全生产经费管理</span>
                            </div>
                            <div>
                                <div class="div_right_middle_cost">
                                    <div class="div_cost_content">
                                        <div>年度计划安全费用
                                        </div>
                                        <div class="div_money_plan"><span>{{ formatCurrency(dataListLeft.plan_cost ||
                                                0)
                                        }}</span>元</div>
                                    </div>
                                    <div class="div_cost_content">
                                        <div>年度实际提取费用</div>
                                        <div class="div_money_cost"><span>{{ formatCurrency(dataListLeft.real_cost ||
                                                0)
                                        }} </span>元</div>
                                    </div>
                                </div>
                            </div>
                        </el-card>
                    </div>
                    <div v-if="1 == 1" class="div_right_bottom">
                        <div class="div_right_bottom_left_child">
                            <el-card style="height:198px" :body-style="{ padding: '10px 10px' }">
                                <div slot="header" class="clearfix">
                                    计划性培训
                                </div>
                                <div v-if="histogramList && histogramList.length > 0">
                                    <div id="myChart" style="height:135px; width:100%;"></div>
                                </div>
                                <div v-else>
                                    <el-empty :image-size="30">
                                    </el-empty>
                                </div>
                            </el-card>
                        </div>
                        <div class="div_right_bottom_right_child">
                            <el-card style="height:198px" :body-style="{ padding: '10px 10px' }">
                                <div slot="header" class="clearfix">
                                    <span>三级安全培训</span>
                                </div>
                                <div>
                                    <div class="div_right_bottom_right_child">
                                        <div class="div_right_static">
                                            <span class="span_round span_round_green"></span>累计培训记录:
                                            <span>{{ dataListLeft.three_count || 0 }}</span>
                                            份
                                        </div>
                                    </div>
                                </div>
                            </el-card>
                        </div>
                    </div>
                    <div>
                        <el-card :body-style="{ padding: '10px 10px' }" style="height:542px;">
                            <div slot="header" class="clearfix">
                                <span>隐患排查治理</span>
                            </div>
                            <div class="div_danger_container">
                                <div class="div_danger_row1">
                                    <div>
                                        <el-card shadow="never" style="height:230px"
                                            :body-style="{ padding: '10px 10px' }">
                                            <div slot="header" class="clearfix">
                                                <span>计划性隐患排查</span>
                                            </div>
                                            <div>
                                                <div v-if="dataListLeft.dangerTaskNum || dataListLeft.dangerPlanNum">
                                                    <div id="myChart2" style="height:190px; width:100%;">图1</div>
                                                </div>
                                                <div v-else>
                                                    <el-empty :image-size="50">
                                                    </el-empty>
                                                </div>
                                            </div>
                                        </el-card>

                                    </div>
                                    <div>
                                        <el-card shadow="never" style="height:230px"
                                            :body-style="{ padding: '10px 10px' }">
                                            <div slot="header" class="clearfix">
                                                <span>隐患分布</span><span
                                                    style="float:right">累计发现隐患{{ dataListLeft.dangerTotalNum }}个</span>
                                            </div>
                                            <div>
                                                <div v-if="distributedList && distributedList.length > 0">
                                                    <div id="myChart3" style="height:190px; width:100%;">图二</div>
                                                </div>
                                                <div v-else>
                                                    <el-empty :image-size="50">
                                                    </el-empty>
                                                </div>
                                            </div>
                                        </el-card>
                                    </div>
                                </div>
                                <div class="div_danger_row2">
                                    <el-card shadow="never" style="height:230px" :body-style="{ padding: '10px 10px' }">
                                        <div slot="header" class="clearfix">
                                            <span>隐患排查治理情况</span>
                                        </div>
                                        <div>
                                            <div v-if="dangerCheck_rectifList.length > 0 || dangerCheck_findList.length > 0">
                                                <div id="myChart4" style="height:212px; width:100%;">图三</div>
                                            </div>
                                            <div v-else>
                                                <el-empty :image-size="50">
                                                </el-empty>
                                            </div>
                                        </div>
                                    </el-card>

                                </div>
                            </div>
                        </el-card>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import * as echarts from "echarts";
import { getCurrentUser } from "@/utils/auth";
export default {
    name: "site-home-page",
    filters: {
        get_levelClass(evaluationValue) {
            switch (evaluationValue) {
                case "A/1级":
                    return "span-risk bg_red";
                case "B/2级":
                    return "span-risk bg_orange ";
                case "C/3级":
                    return "span-risk bg_yellow";
                case "D/4级":
                    return "span-risk bg_blue";
                default:
                    return "span-risk bg_blue";
            }
        },
    },
    data() {
        return {
            isImg: "",
            codeNo: "R00001",
            //关键风险点
            riskPoint: [
                {
                    setUrl: require("../../../src/assets/images/homePageImg/riskLimitedSpace.png"),
                    name: "有限空间",
                },
                {
                    setUrl: require("../../../src/assets/images/homePageImg/riskChemicals.png"),
                    name: "危险化学品",
                },
                {
                    setUrl: require("../../../src/assets/images/homePageImg/riskSpraying.png"),
                    name: "喷涂场所",
                },
            ],
            //岗位列表
            certificate: [
                {
                    name: "特殊岗位证书",
                    setImg: require("../../../src/assets/images/homePageImg/specialPostCertificate_con.png"),
                    unit: "个",
                },
                {
                    name: "建构筑物",
                    setImg: require("../../../src/assets/images/homePageImg/building_con.png"),
                    unit: "栋",
                },
                {
                    name: "作业岗位",
                    setImg: require("../../../src/assets/images/homePageImg/workPost_con.png"),
                    unit: "个",
                },
                {
                    name: "设备设施",
                    setImg: require("../../../src/assets/images/homePageImg/facilities_con.png"),
                    unit: "台",
                },
                {
                    name: "生产原辅料",
                    setImg: require("../../../src/assets/images/homePageImg/rawMaterials_con.png"),
                    unit: "种",
                },
                {
                    name: "有限空间",
                    setImg: require("../../../src/assets/images/homePageImg/limitedSpace_con.png"),
                    unit: "个",
                },
                {
                    name: "相关方",
                    setImg: require("../../../src/assets/images/homePageImg/relatedParty_con.png"),
                    unit: "个",
                },
            ],
            //目标职责
            responsibilityList: [
                {
                    name: "安全生产基本文书",
                    num: 0,
                    unit: "份",
                },
                {
                    name: "部门安全生产目标责任书",
                    num: 0,
                    unit: "份",
                },
                {
                    name: "岗位安全生产责任制",
                    num: 0,
                    unit: "份",
                },
                {
                    name: "安全生产会议",
                    num: "1/4",
                    unit: "（计划）",
                },
            ],
            //echarts
            yAxisList: ["实际", "计划"],
            histogramList: [], //计划性培训数量
            dangerList: [], //隐患排查数量统计
            conditions: {
                year: new Date().getFullYear(),
            },
            companyCode: "",
            monthList: [
                "1月",
                "2月",
                "3月",
                "4月",
                "5月",
                "6月",
                "7月",
                "8月",
                "9月",
                "10月",
                "11月",
                "12月",
            ],
            dataListLeft: { plan_count: 0, real_count: 0 },
            myEchart_trainPlan: null, //计划性培训
            myEchart_trainSafety: null, //三级安全培训
            myEchart_plan_dangerCheck: null, //计划性隐患排查治理
            myEchart_distributed: null, //隐患分布（隐患性纸）
            myEchart_dangerCheck: null, //隐患排查治理情况
            myEchart_riskDistributed: null, //风险分布(风险等级)
            riskPointList: [], //重要风险点列表
            riskDistributed: [], //风险分布
            distributedList: [], //隐患分布
            dangerCheck_findList: [], //隐患排查治理情况(发现数)
            dangerCheck_rectifList: [], //隐患排查治理情况(整改数)
            Statistic: {},
        };
    },
    created() {
        let getCompanyCode = JSON.parse(localStorage.getItem("user"));
        this.companyCode = getCompanyCode.companyCode;
    },
    mounted() {
        this.getEnterpriseList_l();
        this.getStatistic();
        //this.getEnterpriseList_r();

        // window.addEventListener("resize", this.resizeCharts());
    },
    methods: {
        formatCurrency(num, withcents) {
            var originnum = num;
            num = num.toString().replace(/\$|\,/g, "");
            if (isNaN(num)) {
                num = "0";
            }
            var sign = num == (num = Math.abs(num));
            num = Math.floor(num * 100 + 0.50000000001);
            var cents = num % 100;
            num = Math.floor(num / 100).toString();
            if (cents < 10) {
                cents = "0" + cents;
            }
            for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
                num =
                    num.substring(0, num.length - (4 * i + 3)) +
                    "," +
                    num.substring(num.length - (4 * i + 3));
            }
            var rs = (sign ? "" : "-") + num + "." + cents;
            if (!withcents && parseInt(originnum) == parseFloat(originnum)) {
                return rs.split(".")[0];
            } else {
                return rs;
            }
        },
        search() {
            this.getEnterpriseList_l();
            this.getStatistic();
        },

        getStatistic() {
            // var _this = this;
            // var url = "site/guidelinelaw/getStatistic";
            // _this.http
            //     .get(url, { companyCode: _this.$route.query.enterpriseCode })
            //     .then((res) => {
            //         var res = res.data;
            //         if (res) {
            //             _this.Statistic = res;
            //         }
            //     });
        },

        getEnterpriseList_l() {
            var _this = this;
            var url = "/ecologyEnv/commonReportForms/getMainPageInfo";

            var conditionList = [];
            var condition = {};
            condition.codeNo = _this.codeNo;
            condition.year = _this.conditions.year;
            if (_this.$route.query.enterpriseCode) {
                condition.company_code = _this.$route.query.enterpriseCode;
            }
            conditionList.push(condition);
            _this.http
                .get(url, { conditions: JSON.stringify(conditionList) })
                .then((res) => {
                    var res = res.data;
                    if (res) {
                        _this.dataListLeft = res.M;
                        _this.histogramList = [];
                        _this.dangerList = [];
                        if (
                            _this.dataListLeft.real_count > 0 ||
                            _this.dataListLeft.plan_count > 0
                        ) {
                            _this.histogramList.push(
                                _this.dataListLeft.real_count
                            );
                            _this.histogramList.push(
                                _this.dataListLeft.plan_count
                            );
                        }

                        _this.dangerList.push(_this.dataListLeft.dangerTaskNum);
                        _this.dangerList.push(_this.dataListLeft.dangerPlanNum);

                        _this.riskPointList = res.M1;
                        _this.riskDistributed = res.M2;
                        // _this.riskDistributed = res.M2.sort(function(a, b) {
                        //     return a.evaluation_value > b.evaluation_value ? 1 : -1;
                        // });

                        _this.distributedList = res.M3;

                        _this.dangerCheck_findList = res.M4;
                        _this.dangerCheck_rectifList = res.M5;

                        _this.$nextTick(function () {
                            if (
                                _this.histogramList &&
                                _this.histogramList.length > 0
                            ) {
                                this.myEchart_trainPlan = echarts.init(
                                    document.getElementById("myChart")
                                );

                                _this.drawChart();
                            }

                            if (
                                _this.dataListLeft.dangerTaskNum > 0 ||
                                _this.dataListLeft.dangerPlanNum > 0
                            ) {
                                _this.myEchart_plan_dangerCheck = echarts.init(
                                    document.getElementById("myChart2")
                                );

                                _this.drawChart2();
                            }
                            if (
                                this.distributedList &&
                                this.distributedList.length > 0
                            ) {
                                _this.myEchart_distributed = echarts.init(
                                    document.getElementById("myChart3")
                                );
                                _this.drawChart3();
                            }

                            if (
                                _this.dangerCheck_rectifList.length > 0 ||
                                _this.dangerCheck_findList.length > 0
                            ) {
                                _this.myEchart_dangerCheck = echarts.init(
                                    document.getElementById("myChart4")
                                );
                                _this.drawChart4();
                            }

                            if (
                                _this.riskDistributed &&
                                _this.riskDistributed.length > 0
                            ) {
                                _this.myEchart_riskDistributed = echarts.init(
                                    document.getElementById(
                                        "myChartRiskDistributed"
                                    )
                                );

                                _this.drawChart5();
                            }
                            setTimeout(function () {
                                window.onresize = function () {
                                    _this.resizeCharts();
                                };
                            }, 200);
                        });
                    }
                });
        },
        //计划性培训信息
        drawChart() {
            let option = {
                title: { show: false },
                grid: {
                    left: "2%",
                    right: "3%",
                    bottom: "1%",
                    top: "2%",
                    containLabel: true,
                },
                tooltip: {
                    trigger: "axis",
                    axisPointer: {
                        type: "shadow",
                    },
                    // formatter: function(params) {
                    //     return params[0].name + "：" + params[0].data + "次";
                    // }
                },
                legend: {
                    show: false,
                },
                xAxis: {
                    type: "value",
                },
                yAxis: {
                    type: "category",
                    data: this.yAxisList,
                    splitLine: {
                        show: false,
                    },
                },
                series: [
                    {
                        type: "bar",
                        label: {
                            show: true,
                            position: "inside",
                            formatter: "{c0}",
                            color: "#fff",
                            fontSize: "16px",
                        },
                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    // 柱状图颜色
                                    var colorList = ["#6CBDF8", "#8FCD4E"];
                                    return colorList[params.dataIndex];
                                },
                            },
                        },
                        //柱状图宽度
                        barWidth: "40px",
                        //柱状图数据
                        data: this.histogramList,
                    },
                ],
            };
            this.myEchart_trainPlan.setOption(option);
        },
        //计划性隐患排查
        drawChart2() {
            let option = {
                title: { show: false },
                grid: {
                    left: "2%",
                    right: "20px",
                    bottom: "10%",
                    top: "5%",
                    containLabel: true,
                },
                tooltip: {
                    trigger: "axis",
                    formatter: function (params) {
                        return params[0].name + "：" + params[0].data + "次";
                    },
                },
                legend: {
                    show: false,
                },
                xAxis: {
                    type: "value",
                },
                yAxis: {
                    type: "category",
                    data: this.yAxisList,
                    splitLine: {
                        show: false,
                    },
                },
                series: [
                    {
                        type: "bar",

                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    // 柱状图颜色
                                    var colorList = ["#6CBDF8", "#8FCD4E"];
                                    return colorList[params.dataIndex];
                                },
                            },
                        },
                        //柱状图宽度
                        barWidth: "40%",
                        //柱状图数据
                        data: this.dangerList,
                    },
                ],
            };
            this.myEchart_plan_dangerCheck.setOption(option);
        },
        //隐患分布
        drawChart3() {
            var dataList = [];

            let option = {
                tooltip: {
                    trigger: "item",
                },
                grid: {
                    left: "2%",
                    right: "0",
                    bottom: "5%",
                    top: "2%",
                    containLabel: true,
                },
                series: [
                    {
                        name: "隐患分布",
                        type: "pie",
                        radius: ["40%", "70%"],
                        center: ["55%", "40%"],
                        label: {
                            //展示文本设置
                            normal: {
                                show: true, //展示
                                position: "outside", // outside表示文本显示位置为外部
                            },
                            emphasis: {
                                //文本样式
                                show: true, //展示
                                textStyle: {
                                    //文本样式
                                    fontSize: "14",
                                    fontWeight: "600",
                                },
                            },
                        },
                        labelLine: {
                            //引导线设置
                            normal: {
                                show: true, //引导线显示
                                length: 3,
                            },
                        },
                        data: this.distributedList,
                    },
                ],
            };
            this.myEchart_distributed.setOption(option);
        },
        //隐患排查治理情况
        drawChart4() {
            let option = {
                tooltip: {
                    trigger: "axis",
                    axisPointer: {
                        type: "cross",
                        crossStyle: {
                            color: "#999",
                        },
                    },
                },
                color: ["#1990FE", "#8FCD4E"],
                grid: {
                    show: false,
                    left: "3%",
                    right: "3%",
                    top: "3%",
                },
                xAxis: [
                    {
                        type: "category",
                        data: this.monthList,
                        axisPointer: {
                            type: "shadow",
                        },
                    },
                ],
                yAxis: [
                    {
                        type: "value",
                        axisLabel: {
                            formatter: "{value}",
                        },
                    },
                ],
                series: [
                    {
                        name: "整改数",
                        type: "bar",
                        yAxisIndex: 0,
                        tooltip: {
                            valueFormatter: function (value) {
                                return value;
                            },
                        },
                        barWidth: "40%",
                        data: [],
                    },
                    {
                        name: "发现数",
                        type: "line",
                        lineStyle: {
                            type: "dashed",
                            color: "#1990FE",
                        },
                        yAxisIndex: 0,
                        tooltip: {
                            valueFormatter: function (value) {
                                return value;
                            },
                        },
                        data: [],
                    },
                ],
            };
            var dangerCheck_findList = [];
            var dangerCheck_rectifList = [];

            var currentYear = new Date().getFullYear();
            var maxMonth = 12;
            if (currentYear == this.conditions.year) {
                //取出来当前年份的当前月份，如果查询当前年，当前月份后面的无数据就不循环赋值0
                maxMonth = new Date().getMonth();
            }
            if (this.dangerCheck_findList || this.dangerCheck_rectifList) {
                for (var j = 0; j < this.monthList.length; j++) {
                    if (j > maxMonth) {
                        break;
                    }
                    var monthValue = null; //发现数临时数字
                    var monthValue2 = null; //整改数临时数字
                    for (var i = 0; i < this.dangerCheck_findList.length; i++) {
                        if (
                            this.monthList[j] ==
                            this.dangerCheck_findList[i].monthname
                        ) {
                            monthValue = this.dangerCheck_findList[i].value;
                            break;
                        }
                    }
                    for (
                        var i = 0;
                        i < this.dangerCheck_rectifList.length;
                        i++
                    ) {
                        if (
                            this.monthList[j] ==
                            this.dangerCheck_rectifList[i].monthname
                        ) {
                            monthValue2 = this.dangerCheck_rectifList[i].value;
                            break;
                        }
                    }
                    if (monthValue) {
                        dangerCheck_findList.push(monthValue);
                    } else {
                        dangerCheck_findList.push(0);
                    }
                    if (monthValue2) {
                        dangerCheck_rectifList.push(monthValue2);
                    } else {
                        dangerCheck_rectifList.push(0);
                    }
                }
            }
            // if (this.dangerCheck_rectifList) {
            //     for (var i = 0; i < this.dangerCheck_rectifList.length; i++) {
            //         dangerCheck_rectifList.push(
            //             this.dangerCheck_rectifList[i].value
            //         );
            //     }
            // }
            option.series[0].data = dangerCheck_rectifList;
            option.series[1].data = dangerCheck_findList;
            this.myEchart_dangerCheck.setOption(option);
        },
        //风险分布
        drawChart5() {
            var dataList = [];
            if (this.riskDistributed) {
                for (var i = 0; i < this.riskDistributed.length; i++) {
                    if (
                        this.riskDistributed[i].evaluation_value.indexOf("A") !=
                        -1
                    ) {
                        dataList.push({
                            name: this.riskDistributed[i].name,
                            value: this.riskDistributed[i].value,
                            evaluation_value:
                                this.riskDistributed[i].evaluation_value,
                            itemStyle: { color: "#ff0000" },
                        });
                    } else if (
                        this.riskDistributed[i].evaluation_value.indexOf("B") !=
                        -1
                    ) {
                        dataList.push({
                            name: this.riskDistributed[i].name,
                            value: this.riskDistributed[i].value,
                            evaluation_value:
                                this.riskDistributed[i].evaluation_value,
                            itemStyle: { color: "#ffc000" },
                        });
                    } else if (
                        this.riskDistributed[i].evaluation_value.indexOf("C") !=
                        -1
                    ) {
                        dataList.push({
                            name: this.riskDistributed[i].name,
                            value: this.riskDistributed[i].value,
                            evaluation_value:
                                this.riskDistributed[i].evaluation_value,
                            itemStyle: { color: "#ffff00" },
                        });
                    } else if (
                        this.riskDistributed[i].evaluation_value.indexOf("D") !=
                        -1
                    ) {
                        dataList.push({
                            name: this.riskDistributed[i].name,
                            value: this.riskDistributed[i].value,
                            evaluation_value:
                                this.riskDistributed[i].evaluation_value,
                            itemStyle: { color: "#00b0f0" },
                        });
                    } else if (
                        this.riskDistributed[i].evaluation_value.indexOf("E") !=
                        -1
                    ) {
                        dataList.push({
                            name: this.riskDistributed[i].name,
                            value: this.riskDistributed[i].value,
                            evaluation_value:
                                this.riskDistributed[i].evaluation_value,
                            itemStyle: { color: "#00b0f0" },
                        });
                    } else {
                        dataList.push({
                            name: this.riskDistributed[i].name,
                            value: this.riskDistributed[i].value,
                            evaluation_value:
                                this.riskDistributed[i].evaluation_value,
                        });
                    }
                }
            }

            let option = {
                tooltip: {
                    trigger: "item",
                },

                series: [
                    {
                        name: "风险分布",
                        type: "pie",
                        radius: ["40%", "70%"],
                        label: {
                            //展示文本设置
                            normal: {
                                show: true, //展示
                                position: "outside", // outside表示文本显示位置为外部
                            },
                            emphasis: {
                                //文本样式
                                show: true, //展示
                                textStyle: {
                                    //文本样式
                                    fontSize: "14",
                                    fontWeight: "600",
                                },
                            },
                        },
                        labelLine: {
                            //引导线设置
                            normal: {
                                show: true, //引导线显示
                            },
                        },
                        data: dataList,
                    },
                ],
            };
            //riskDistributed

            this.myEchart_riskDistributed.setOption(option);
        },
        resizeCharts() {
            if (this.myEchart_trainPlan) {
                this.myEchart_trainPlan.resize();
            }
            if (this.myEchart_plan_dangerCheck) {
                this.myEchart_plan_dangerCheck.resize();
            }
            if (this.myEchart_distributed) {
                this.myEchart_distributed.resize();
            }
            if (this.myEchart_dangerCheck) {
                this.myEchart_dangerCheck.resize();
            }
            if (this.myEchart_riskDistributed) {
                this.myEchart_riskDistributed.resize();
            }
        },
        goto(action) {
            var currentUser = getCurrentUser();
            var modulesCode = this.$route.meta.modulesId;
            if (!currentUser.manager && modulesCode == "site") {
                return false;
            }
            var queryParams = {
                enterpriseCode: this.$route.query.enterpriseCode,
                projectId: this.$route.query.projectId,
            };
            // var modulesCode = this.$route.meta.modulesId;

            var addHtml = "";
            switch (modulesCode) {
                case "site":
                    addHtml = "Site";
                    break;
                case "host":
                    addHtml = "Host";
                    break;
            }
            this.$router.push({
                name: addHtml + action,
                query: queryParams,
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.divSite_home_container {
    ::v-deep.el-card__header {
        font-size: 16px;
        font-weight: 700;
        border-bottom: 0px;
        padding: 14px 15px 0px;
    }

    display: flex;
    flex-direction: column;

    .span-risk {
        margin-left: 0px;
        cursor: pointer;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        width: 76px;
        text-align: center;
    }

    .div_evaluation_rpName {
        margin-left: 0px;
        cursor: pointer;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        width: 86px;
        text-align: left;
    }

    .bg_red {
        background: #ff0000;
        color: white;
    }

    .bg_orange {
        background: #ffc000;
        color: white;
    }

    .bg_yellow {
        background: #ffff00;
    }

    .bg_blue {
        background: #00b0f0;
        color: white;
    }

    .div_content {
        display: flex;
        flex-direction: row;

        .span_round {
            display: inline-block;
            width: 10px;
            height: 10px;
            // border: 1px solid #aaaaaa;
            border-radius: 10px;
            opacity: 2; //透明度
            margin-right: 5px;
        }

        .span_red {
            line-height: 28x;
            margin-left: 5px;
            font-size: 16px;
            font-weight: bold;
            color: red;
        }

        .span_purple {
            line-height: 28x;
            margin-left: 5px;
            font-size: 16px;
            font-weight: bold;
            color: #3f3684;
        }

        .span_round_green {
            background-color: #8fcd4e;
        }

        .span_round_yellow {
            background-color: #ffa000;
        }

        .div_left_content {
            width: 600px;
            margin-right: 10px;

            .el-card {
                margin-bottom: 10px;
            }

            .div_one_ent_one_record_content {
                display: flex;
                flex-direction: column;
            }

            .div_block_contet {
                display: flex;
                flex-direction: row;

                .div_block_contet_area {
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    margin: 10px 0px;
                    margin-right: 10px;
                    cursor: pointer;

                    div {
                        margin: 10px;
                    }

                    flex: 1;

                    span {
                        line-height: 28x;
                        margin-left: 5px;
                        font-size: 16px;
                        font-weight: bold;
                        float: left;
                        margin-right: 5px;
                    }

                    .div_block_content_title {
                        img {
                            width: 25px;
                            height: 25px;
                            float: left;
                        }
                    }

                    .div_block_content_middle {
                        text-align: center;

                        img {
                            width: 100px;
                            height: 100px;
                            margin: 10px 0;
                        }
                    }
                }

                .div_block_contet_area:last-child {
                    margin-right: 0px;
                }

                .div_block_contet_alarm {
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    margin: 10px 0px;
                    display: flex;
                    flex-direction: column;

                    div {
                        margin: 10px;
                    }

                    width: 230px;

                    .span_alarm_title {
                        font-size: 16px;
                        font-weight: bold;
                    }
                }

                display: flex;
                flex-wrap: wrap;

                .div_block_content_child {
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                    cursor: pointer;

                    span {
                        font-size: 18px;
                        font-weight: bold;
                    }

                    height: 140px;
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    margin: 0px 10px 5px 0px;
                    text-align: center;
                    min-width: 134px;
                    padding-bottom: 10px;

                    .div_block_content_title {
                        margin-top: 10px;

                        img {
                            width: 50px;
                            height: 50px;
                        }
                    }
                }

                .div_block_content_child:last-child {
                    margin-right: 0px;
                }
            }

            .div_risk_container {
                display: flex;
                flex-direction: row;

                margin-bottom: 10px;

                .div_risk_title {
                    font-weight: bold;
                }

                .div_risk_control_container {
                    padding-left: 10px;
                    padding-top: 10px;
                    padding-bottom: 10px;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    width: 200px;
                    min-height: 165px;
                    margin-right: 10px;

                    .div_risk_control_content {
                        div {
                            line-height: 28px;
                        }
                    }
                }

                .div_risk_control_container:last-child {
                    margin-right: 0px;
                }

                .div_risk_point_container {
                    padding-left: 10px;
                    padding-top: 10px;
                    padding-bottom: 10px;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    flex: 1;
                    padding-right: 10px;

                    .div_evaluation {
                        line-height: 24px;
                        display: flex;
                        padding-right: 10px;
                        justify-content: space-between;
                        margin-bottom: 5px;
                    }
                }

                .div_risk_distributed_container {
                    padding-left: 10px;
                    padding-top: 10px;
                    padding-bottom: 10px;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    flex: 1;
                    min-height: 296px;
                }
            }
        }

        .div_right_content {
            min-width: 510px;
            display: flex;
            flex-direction: column;
            flex: 1;

            .div_card_content {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }

            .el-card {
                margin-bottom: 10px;
            }

            .div_right_top {
                display: flex;
                flex-direction: row;

                .div_right_top_child {
                    flex: 1;
                    margin-right: 10px;

                    div:first-child {
                        min-width: 215px;
                    }

                    .div_right_top_title {
                        font-size: 16px;
                        font-weight: bold;
                    }

                    span {
                        line-height: 28px;
                        font-size: 16px;
                        font-weight: bold;
                        color: #3f3684;
                    }
                }

                .div_right_top_child:last-child {
                    margin-right: 0px;
                }
            }

            .div_right_middle {
                display: flex;
                flex-direction: column;

                .div_right_middle_cost {
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    background-color: #f0f8ff;
                    height: 100px;
                    display: flex;

                    .div_cost_content {
                        display: flex;
                        flex: 1;
                        justify-content: center;
                        align-items: center;
                        flex-direction: column;
                        font-weight: bold;

                        div {
                            line-height: 36px;
                        }

                        span {
                            font-size: 20px;
                        }

                        .div_money_plan {
                            color: #61b8f5;
                        }

                        .div_money_cost {
                            color: #8fcd4e;
                        }
                    }
                }
            }

            .div_right_bottom {
                display: flex;
                flex-direction: row;

                .div_right_title {
                    font-size: 16px;
                    font-weight: bold;
                    margin-top: 10px;
                    margin-left: 10px;
                }

                .div_right_bottom_left_child {
                    flex: 1;

                    .div_right_chart {
                        margin: 10px 10px;
                    }

                    margin-right: 10px;
                }

                .div_right_bottom_right_child {
                    flex: 1;
                    max-width: 300px;

                    .div_right_static {
                        margin-top: 10px;
                        margin-left: 10px;

                        span {
                            font-size: 16px;
                            font-weight: bold;
                        }
                    }
                }
            }

            .div_danger_container {
                .div_risk_title {
                    font-weight: bold;
                }

                display: flex;
                flex-direction: column;

                .div_danger_row1 {
                    display: flex;
                    flex-direction: row;

                    div {
                        flex: 1;
                        margin-right: 10px;
                    }

                    .el-card__header {
                        span {
                            font-size: 14px;
                            font-family: Helvetica Neue, Helvetica, PingFang SC,
                                Hiragino Sans GB, Microsoft YaHei, Arial,
                                sans-serif;
                        }
                    }
                }
            }
        }
    }
}
</style>