<template name="build-danger-report">
    <div class="build-danger-report">
        <el-dialog v-dialogDrag :title="title" width="600px" :visible.sync="visible" label-width="120px" show-close :close-on-click-modal="false">
            <eagle-block border>
                <el-form ref="form" :model="model" label-width="120px" class="lg_form" size="small">
                    <el-row>
                        <eagle-input required label="报告名称" prop="reportName" v-model="model.reportName" />
                    </el-row>
                    <el-row>
                        <eagle-radio required label-width="120px" prop="reportTemplateCode" @change="changeReportSource" :data-source="params.reportSource" v-model="model.reportTemplateCode" label="报告模板" />
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-date label="检查开始时间" v-model="model.startDate" prop="startDate" required></eagle-date>
                        </el-col>
                        <el-col :span="12">
                            <eagle-date label="检查结束时间" v-model="model.endDate" prop="endDate" required>
                            </eagle-date>
                        </el-col>
                    </el-row>
                    <el-row>
                        <!-- <eagle-picker-range label-width="120px" type="daterange" format="yyyy-MM-dd" prop="datetimes" v-model="model.datetimes" label="检查起始时间" required @change="changeDatetimes" /> -->
                        <eagle-input type="textarea" label-width="120px" label="总结和建议" :rows="3" prop="remarks" v-model="model.remarks" />
                    </el-row>
                </el-form>
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible = false">关 闭</el-button>
                <el-button type="primary" @click="submitForm">生成报告</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
// import { resetForm } from "@/utils/EageleRMC";

export default {
    components: {},
    name: "build-danger-report",
    props: {},
    data() {
        return {
            title: "生成报告",
            controller: "ecologyEnv/dangerReport",
            visible: false,
            model: {},
            params: {
                reportSource: [],
            },
            taskCodes: "",
            taskNames: "",
            enterpriseCode: "",
            projectId: "",
            singer: true,
            modulesId: "",
        };
    },
    created() {
        this.modulesId = this.$route.meta.modulesId;
        this.getParams();
        // this.getModel();
    },
    methods: {
        submitForm() {
            let _this = this;
            let url = `${this.controller}/saveEntity`;
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        _this.model,
                        function (res) {
                            _this.msgSuccess("报告生成成功");
                            _this.visible = false;
                            if (res.data && res.data.reportAttach) {
                                let fileInfo = res.data.reportAttach;
                                let row = JSON.parse(fileInfo)[0];
                                let code = row.attCode || row.AttCode;
                                var params = { code: code };
                                params.fileName = row.name;
                                _this.$emit("afterSave", params);
                            }
                        }
                    );
                }
            });
        },
        changeReportSource() {
            this.model.reportTemplateName = this.formateDict(
                this.params.reportSource,
                this.model.reportTemplateCode
            );
        },
        getModel() {
            let _this = this;
            let url = `${this.controller}/initData/0`;
            _this.http
                .get(url, {
                    companyCode: _this.enterpriseCode ?? "",
                    taskCode: _this.taskCodes,
                })
                .then((res) => {
                    _this.bindData(res.data);
                });
        },
        // getReportContent() {
        //     var _this = this;
        //     var codeArray = _this.taskCodes.split(",");
        //     var taskCodes = _this.taskCodes;
        //     if (codeArray.length > 1) {
        //         taskCodes = codeArray[0];
        //     }
        //     _this.http
        //         .get("site/dangerCheckTask/getDataByCode/" + taskCodes)
        //         .then((res) => {
        //             if (res.data && res.data.checkAttachs) {
        //                 let row = JSON.parse(res.data.checkAttachs)[0];
        //                 let code = row.attCode || row.AttCode;
        //                 var params = { code: code };
        //                 params.fileName = row.name;

        //                 _this.$router.push({
        //                     name: "DangerFileView",
        //                     query: {
        //                         attcode: params.code,
        //                         name: params.name,
        //                         projectId: _this.$route.query.projectId,
        //                         enterpriseCode:
        //                             _this.$route.query.enterpriseCode,
        //                         modulesCode: _this.$route.meta.modulesId,
        //                     },
        //                 });
        //             }
        //         });
        // },
        bindData(data) {
            this.model = data;
            // let datetimes = [];
            // this.taskName = "";
            // if (this.singer) {
            //     this.model.reportName = this.taskNames;
            // }

            // this.model.taskNames = this.taskNames;
            // this.model.taskCodes = this.taskCodes;
            // this.model.enterpriseCode = this.enterpriseCode;
            // this.model.projectId = this.projectId;
            // this.$set(this.model, "datetimes", datetimes);
            // this.model.datetimes.push(this.model.startDate);
            // this.model.datetimes.push(this.model.endDate);
            this.model.reportTemplateCode = this.params.reportSource[0].id;
            this.model.reportTemplateName = this.params.reportSource[0].name;
            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
        },

        // getDateStr() {
        //     var date = new Date();
        //     var year = date.getFullYear();
        //     var month = date.getMonth() + 1;
        //     var day = date.getDate();

        //     return `${year}${month > 9 ? month : "0" + month}${day}`;
        // },
        changeDatetimes(data) {
            this.model.startDate = data[0];
            this.model.endDate = data[1];
        },
        getParams() {
            let _this = this;
            let type = "checkReport";
            if (this.modulesId == "site") {
                type = "siteDangerReport";
            }
            let url = "ecologyEnv/fileToolDataSource/getMap?reportType=" + type;
            _this.http.get(url).then((res) => {
                _this.params.reportSource = res.data;
            });
        },
        show(config) {
            this.taskCodes = config.taskCodes ?? "";
            this.taskNames = config.taskNames ?? "";
            this.enterpriseCode = config.enterpriseCode ?? "";
            this.projectId = config.projectId ?? "";
            this.visible = true;
            this.singer = config.singer ?? true;
            this.getModel();
        },
    },
};
</script>
<style scoped lang="scss">
.build-danger-report {
    ::v-deep.el-form-item {
        margin-bottom: 20px !important;
    }
}
</style>

// <style lang="scss" scoped>
// .build-danger-report {
//     ::v-deep.el-form-item {
//         margin-bottom: 20px;
//     }
// }
//
</style>
