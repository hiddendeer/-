<template name="site-danger-list-report">
    <div>
        <el-dialog v-dialogDrag :title="title" width="800px" :visible.sync="visible" label-width="150px" show-close
            :close-on-click-modal="false">
            <eagle-block border>
                <div class="site-danger-list-report">
                    <el-row>
                        <el-col :span="12">
                            <div class="item_a">
                                <span class="item-title">检查企业</span>
                                <span>{{ model.enterpriseName }}</span>
                            </div>
                        </el-col>
                        <el-col :span="12" v-if="model.projectName">
                            <div class="item_a">
                                <span class="item-title">所属项目</span>
                                <span>{{ model.projectName }}</span>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <div class="item_a">
                                <span class="item-title">检查人</span>
                                <span>{{ model.checkUserNames }}</span>
                            </div>
                        </el-col>
                        <el-col :span="12">
                            <div class="item_a">
                                <span class="item-title">隐患清单生成日期</span>
                                <span>{{ model.buildDate }}</span>
                            </div>
                        </el-col>
                    </el-row>
                    <el-table :data="model.dangerList" style="width: 100%">
                        <el-table-column label="序号" fixed align="left" width="50px">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="hiddenDangerArea" label="隐患区域" width="150">
                        </el-table-column>
                        <el-table-column prop="hiddenDangerDesc" label="隐患描述">
                        </el-table-column>
                    </el-table>
                    <!-- <el-row style="margin-top:30px">
                <el-col>
                    <span style="color:red">
                        说明：网页端无签字功能， 如需签字 ，请通过APP端打开该任务进行签字。
                    </span>
                </el-col>
            </el-row> -->
                    <el-row style="margin-top:30px">
                        <el-col :span="12">
                            <div class="item">
                                <span class="item-title">检查人</span>
                                <span
                                    style="margin-left:45px; display: block;border-bottom: 1px solid #000;width:120px"></span>
                            </div>
                        </el-col>
                        <el-col :span="12">
                            <div class="item">
                                <span class="item-title">被检查单位代表</span>
                                <span
                                    style="margin-left:100px; display: block;border-bottom: 1px solid #000;width:120px"></span>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <div class="item" style="margin-left:15px">
                                <span class="item-title">日期</span>
                            </div>
                        </el-col>
                        <el-col :span="12">
                            <div class="item" style="margin-left:70px">
                                <span class="item-title">日期</span>
                            </div>
                        </el-col>
                    </el-row>

                </div>
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="submitForm(false)">保 存</el-button>
                <el-button @click="visible = false">取 消</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
export default {
    components: {},
    name: "site-danger-list-report",
    props: {},
    data() {
        return {
            title: "生成隐患清单",
            controller: "ecologyEnv/dangerCheckTask",
            visible: false,
            model: {},
            taskCode: "",
            projectId: "",
        };
    },
    created() { },
    methods: {
        submitForm(down) {
            let _this = this;
            let url = `${this.controller}/buildDangerListReport/${_this.taskCode}`;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                if (res.data.result) {
                    _this.getReportContent();
                    // _this.msgSuccess("隐患清单保存成功");
                    _this.visible = false;
                    // _this.$emit("saved", res.data);
                    // console.log(res.data);
                    if (down) {
                        // console.log("2", res.data);
                    }
                } else {
                    _this.msgError(res.data.errorMsg);
                }
            });
        },
        changeReportSource() {
            this.model.reportTemplateName = this.formateDict(
                this.params.reportSource,
                this.model.reportTemplateCode
            );
        },
        getModel() {
            let _this = this;
            let url = `${this.controller}/getDangerListContent/${this.taskCode}`;
            _this.http.get(url).then((res) => {
                _this.model = res.data;
            });
        },
        getReportContent() {
            var _this = this;
            _this.http
                .get("ecologyEnv/dangerCheckTask/getDataByCode/" + _this.taskCode)
                .then((res) => {
                    if (res.data && res.data.dangerListReportAttach) {
                        let row = JSON.parse(
                            res.data.dangerListReportAttach
                        )[0];
                        let code = row.attCode || row.AttCode;
                        var params = { code: code };
                        params.fileName = row.name;

                        _this.$router.push({
                            name: "DangerFileView",
                            query: {
                                attcode: params.code,
                                name: params.name,
                                projectId: _this.projectId,
                                enterpriseCode:
                                    _this.$route.query.enterpriseCode,
                                modulesCode: _this.$route.meta.modulesId,
                            },
                        });
                    }
                });
        },
        show(config) {
            this.taskCode = config.taskCode;
            this.projectId = config.projectId;

            this.visible = true;
            this.getModel();
        },
    },
};
</script>
<style lang="scss" scoped>
.site-danger-list-report {
    padding: 15px;

    .item_a {
        vertical-align: middle;
        font-size: 14px;
        color: #606266;
        line-height: 28px;
        padding: 0 12px 0 0;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;

        .item-title {
            margin-right: 15px;
            color: #000;
            font-weight: bolder;
        }
    }
}
</style>