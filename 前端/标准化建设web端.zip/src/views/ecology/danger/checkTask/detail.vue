<template name="SiteDangerCheckTask">
    <div class="site-danger-check-task">
        <eagle-fold-block>
            <div slot="header" class="clearfix">
                <span><span class="eagle-label">检查任务详情</span>({{ model.checkTaskName }})</span>
                <el-button size="small" style="float: right;margin-left:10px" type="default" @click="back">返 回
                </el-button>
                <el-button size="small" style="float: right;margin-left:10px" type="danger" @click="submitEnd" v-if="otEdit && model.status == 10">结束本次检查并提交全部隐患</el-button>
                <!-- <el-button size="small" style="float: right;margin-left:10px" type="primary" v-if="model.projectId&&model.risk=='project'" @click="buildDangerListReport">生成隐患清单</el-button> -->
                <el-button size="small" style="float: right;margin-left:10px" type="primary" v-if="model.status == 100" @click="buildReport">生成检查报告</el-button>
            </div>
            <div>
                <el-form :model="model">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="100px" prop="checkTaskName" label="任务名称">
                                <span>
                                    {{ model.checkTaskName }}
                                </span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="100px" prop="createChnName" label="任务创建人">
                                <span>
                                    {{ model.createChnName }}
                                </span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="100px" label="创建日期">
                                <span>{{ parseTime(model.createDate, "{y}-{m}-{d} {h}:{i}") }}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="100px" label="检查人">
                                <span>{{ model.checkPersonChName }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="100px" label="任务检查时间">
                                <span>{{ parseTime(model.startDate, "{y}-{m}-{d}") }}~{{ parseTime(model.endDate,
                                "{y}-{m}-{d}")
                                }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="100px" label="当前状态">
                                <span v-html="getStatusDesc()"></span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <!-- <el-col :span="8" v-if="model.sourceType!='risk'">
                            <el-form-item label-width="100px" label="隐患清单">
                                <eagle-row-attach v-model="model.dangerListReportAttach"></eagle-row-attach>
                            </el-form-item>
                        </el-col> -->

                        <el-col :span="16">
                            <el-form-item label-width="100px" label="检查报告">
                                <eagle-row-attach :isReport="true" v-model="model.checkAttachs"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                    </el-row>

                </el-form>
            </div>
        </eagle-fold-block>
        <el-card shadow="never">
            <div slot="header" class="clearfix">
                <span>执行检查</span>
            </div>
            <div v-if="otEdit && model.status == 10 && model.sourceType != 'risk'">
                <p class="eagle-title-left-split">检查工具</p>
                <div>
                    <el-button type="primary" plain icon="el-icon-plus" size="small" @click.prevent.stop="handleChooseLibTemplateShow">检查表</el-button>
                    <el-button type="primary" plain icon="el-icon-pl
                    us" size="small" @click.prevent.stop="handleChooseYJ">依据检查</el-button>
                    <el-button type="primary" plain icon="el-icon-plus" size="small" @click.prevent.stop="handleShowRandForm">随手拍</el-button>
                </div>
            </div>
            <div>
                <p class="eagle-title-left-split">任务检查表</p>
                <div class="temp-block" v-for="(item, index) in model.relations" :key="index">
                    <div class="temp-title single-line">{{ index + 1 }}-{{ item.templateName }}</div>
                    <div class="temp-button">
                        <eagle-row-button v-if="otEdit && model.status == 10 && model.sourceType != 'risk'" type="danger" @click.prevent.stop="hdRemoverTemplate(index)">删除</eagle-row-button>
                        <eagle-row-button type="primary" @click.prevent.stop="showTemplate(item)">检查</eagle-row-button>
                    </div>
                    <!-- <ul>
                        <li v-for="(item,index) in model.relations" :key="index" style="list-style:none;line-height:30px;float:left;margin-right:15px; ">
                            <el-link style="margin-right:5px;" @click="showTemplate(item)" type="primary">
                                {{item.templateName}}
                            </el-link>
                            <i v-if="otEdit && model.status==10 &&model.sourceType!='risk'" class="el-icon-close" style="color:red;cursor:pointer;" title="移除检查表" @click="hdRemoverTemplate(index)"></i>
                        </li>
                    </ul> -->
                </div>
            </div>
        </el-card>
        <el-card shadow="never">
            <div slot="header" class="clearfix">
                <span>检查记录</span>
            </div>
            <div>
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <el-col>
                        <eagle-radio @change="search()" :data-source="params.status" v-model="conditionsVals.status" label="隐患状态" />
                    </el-col>
                    <el-col v-if="model.sourceType != 'risk'">
                        <eagle-radio @change="search()" :data-source="params.checkSource" v-model="conditionsVals.originType" label="隐患来源" />
                    </el-col>
                    <eagle-input @changeEnter="search()" label="筛选条件" label-width="80px" prop="title" v-model="conditionsVals.hiddenDangerDesc" placeholder="请输入隐患描述模糊查询" clearable size="small" />

                </eagle-condition>
                <eagle-page :queryParams="queryParams" :tableHeight="500" :show-check-column="false" :rowClassName="getCompateClassName" :controller="detailController" ref="EaglePage" btnWidth="200px">
                    <template slot="slot-table">
                        <!-- <el-table-column label="检查内容" align="left" prop="templateItemName" width="300" /> -->
                        <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" width="300" />
                        <el-table-column label="隐患区域" align="left" prop="correctiveArea" width="150" />
                        <el-table-column label="隐患图片" align="left" prop="attachs" width="80">
                            <template slot-scope="scope">
                                <eagle-row-image v-model="scope.row.attachs" />
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患状态" align="left" prop="createDate" width="80">
                            <template slot-scope="scope">
                                <span v-html="getCheckStatusDesc(scope.row.status)"></span>
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患性质" align="left" width="100">
                            <template slot-scope="scope">
                                <span>{{ formateDict(params.dangerType, scope.row.hiddenDangerTypeCode) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患分类" align="left" prop="attachs" width="200">
                            <template slot-scope="scope">
                                {{ scope.row.hiddenName || "--" }}
                            </template>
                        </el-table-column>
                        <el-table-column label="整改后图片" align="left" prop="attachs" width="90">
                            <template slot-scope="scope">
                                <eagle-row-image v-model="scope.row.correctiveAttachs" />
                            </template>
                        </el-table-column>

                        <el-table-column label="隐患来源" align="left" width="100" v-if="model.sourceType != 'risk'">
                            <template slot-scope="scope">
                                <span>{{ formateDict(params.checkSource, scope.row.originType) }}</span>
                            </template>
                        </el-table-column>

                        <el-table-column v-if="!isHost" label="整改负责人" align="left" prop="appointCorrectiveChnName" width="100" />
                        <el-table-column label="检查时间" align="left" prop="createDate" width="140">
                            <template slot-scope="scope">
                                <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d} {h}:{i}") }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="检查人" align="left" prop="attachs">
                            <template slot-scope="scope">
                                {{ scope.row.createChnName || "--" }}
                            </template>
                        </el-table-column>
                        <el-table-column label="复查人" align="left" prop="attachs" width="80">
                            <template slot-scope="scope">
                                {{ scope.row.correctiveUserChName || "--" }}
                            </template>
                        </el-table-column>
                        <el-table-column label="复查时间" align="left" prop="correctiveTime" width="140">
                            <template slot-scope="scope">
                                <span>{{ parseTime(scope.row.correctiveTime, "{y}-{m}-{d} {h}:{i}") || "--" }}</span>
                            </template>
                        </el-table-column>
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button type="primary" v-if="(scope.row.status == 30 || scope.row.status == 60) && !isHost" @click.prevent.stop="handleUpdate(scope.row, 2)">{{ scope.row.manager || scope.row.self ? "
                            整改/ 复查":"整改"}}</eagle-row-button>
                        <eagle-row-button type="primary" v-if="(scope.row.status == 60 && (scope.row.manager || isHost || scope.row.self)) || (scope.row.status < 100 && scope.row.status >= 30 && isHost)" @click.prevent.stop="handleVerify(scope.row, 5)">复查</eagle-row-button>
                        <eagle-row-button type="danger" v-if="scope.row.manager || modulesId == 'host' || (scope.row.self&&scope.row.status<30)" @click="handleDelete(scope.row)">删除</eagle-row-button>
                        <eagle-row-button type="success" @click.prevent.stop="handleView(scope.row, 0)">详情
                        </eagle-row-button>
                        <eagle-row-button type="primary" v-if="scope.row.status < 30" @click.prevent.stop="handleUpdate(scope.row, 1)">编辑</eagle-row-button>
                    </template>
                </eagle-page>
            </div>
        </el-card>
        <buildDangerReport ref="buildDangerReport" @afterSave="showReport" />
        <check-task-detail ref="checkTaskDetail" @afterSave="search"> </check-task-detail>
        <!-- 隐患分类 -->
        <choose-danger-type ref="ChooseDangerType" v-model="rowData.hiddenCode" @change="handleChooseDangerType" />
        <choose-lib-template :psotCompanyCode="companyCode" ref="chooseLibTemplate" @change="handleChooseLibTemplate" />
        <!-- <dangerlgAddWindow ref="dangerLG" @choosed="choosedDangerLg"></dangerlgAddWindow> -->
        <templateItem ref="templateItem" />
        <libTempDetails :companyCode="companyCode" :dataType="libDataType" @handleClose="libTempDetailsVisible = false" :libTempDetailsVisible="libTempDetailsVisible" @handlerSelectImg="handlerSelectImg" />
        <dangerListReport ref="dangerListReport" @saved="getData" />
        <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>
        <check-task-verify ref="checkTaskVerify" @afterSave="search"></check-task-verify>
        <check-task-view ref="checkTaskView"></check-task-view>
    </div>
</template>
<script>
/**
 * createdd() 调用初始化方法
 * mounted() 调用查询方法
 *
 **/
// import lib from "@/views/support/libTemp/components/libTempDetails"
import chooseDangerType from "@/views/components/danger/chooseDangerType";
import buildDangerReport from "@/views/ecology/danger/components/buildDangerReport";
import templateItem from "@/views/ecology/components/danger/template/templateItem";
import checkTaskDetail from "@/views/ecology/components/danger/checkTask/checkTaskDetail";
import chooseLibTemplate from "@/views/support/public/chooseLibTemplate";
// import dangerlgAddWindow from "@/views/site/components/danger/dangerlg/dangerlgAddWindow";
import libTempDetails from "@/views/support/libTemp/components/libTempDetails/libTempDetails";
import dangerListReport from "@/views/ecology/danger/checkTask/dangerListReport";
import EagleFoldBlock from "@/components/Eagle/eagle-fold-block.vue";
import checkTaskVerify from "@/views/ecology/components/danger/checkTask/checkTaskVerify";
import checkTaskView from "@/views/ecology/components/danger/checkTask/checkTaskView";

export default {
    components: {
        chooseDangerType,
        chooseLibTemplate,
        checkTaskDetail,
        // dangerlgAddWindow,
        templateItem,
        buildDangerReport,
        libTempDetails,
        dangerListReport,
        EagleFoldBlock,
        checkTaskVerify,
        checkTaskView,
    },
    name: "siteDangerCheckTask",
    data() {
        return {
            companyCode: "",
            libDataType: "img",
            libTempDetailsVisible: false,
            code: this.$route.query.code,
            otEdit: this.$route.query.op != "v", //操作类型 v :view e:edit
            lcEdit: false,
            model: {},
            controller: "ecologyEnv/dangerCheckTask",
            detailController: "ecologyEnv/dangerCheckTaskDetail",
            queryParams: {
                mainCode: "",
                companyCode: "",
                dataType: "list",
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                // mainCode: "=",
                checkResult: "=",
                originType: "=",
                status: "=",
                hiddenDangerDesc: "like",
            },
            // 查询条件
            conditionsVals: {
                // mainCode: "",
                originType: null,
                checkResult: "N",
                status: null,
                hiddenDangerDesc: "",
            },
            taskStatusArray: [
                {
                    value: 1,
                    text: "待实施",
                    color: "#909399",
                },
                {
                    value: 2,
                    text: "进行中",
                    color: "#409EFF",
                },
                {
                    value: 3,
                    text: "已逾期",
                    color: "#E6A23C",
                },
                {
                    value: 4,
                    text: "已完成",
                    color: "#67C23A",
                },
            ],
            // taskStatusArray: [
            //     { value: 10, text: "进行中", color: "#1890ff" },
            //     { value: 100, text: "已结束", color: "#67C23A" },
            // ],
            // templateVisible: false,
            templateCode: null,
            templateGroup: [],
            params: {
                opType: [],
                dangerType: [],
                checkSource: [
                    { id: null, name: "不限" },
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                // checkResult: [
                //     { id: "", name: "不限" },
                //     { id: "Y", name: "符合", color: "#67C23A" },
                //     { id: "N", name: "不符合", color: "#F56C6C" },
                //     { id: "NA", name: "不适用", color: "#E6A23C" },
                // ],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
                status: [
                    { id: null, name: "不限" },
                    // { id: 5, name: "暂存", color: "#F56C6C" },
                    { id: 10, name: "待提交", color: "#F56C6C" },
                    { id: 30, name: "待整改", color: "#F56C6C" },
                    { id: 60, name: "已整改", color: "#E6A23C" },
                    { id: 100, name: "已复查", color: "#67C23A" },
                ],
            },
            rowData: {},
            randVisible: false,
            randTitle: "随手拍",

            chooseYJModel: {},
            enterpriseCode: "",
            projectId: "",
            modulesId: "",
        };
    },
    created() {
        this.initData();
        this.getData();
    },
    computed: {
        isHost() {
            return (
                this.projectId ||
                (this.model.projectId && this.model.sourceType == "project")
            );
        },
    },
    mounted() {
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";
    },
    methods: {
        /**
         * 移除检查
         */
        hdRemoverTemplate(index) {
            let _this = this;
            let item = _this.model.relations[index];
            this.$confirm(`是否确认移除检查表[${item.templateName}]?`, "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http
                    .post(
                        `ecologyEnv/dangerCheckTask/removeRelation/${_this.model.code}/${item.checkTemplateCode}`
                    )
                    .then(function (res) {
                        _this.model.relations.splice(index, 1);
                    });
            });
        },
        showReport(params) {
            this.$refs.PdfDialog.show(params);
            this.getData();
        },
        /**生成隐患清单*/
        buildDangerListReport() {
            let _this = this;
            _this.http
                .get(
                    _this.controller +
                        "/checkDangerListReport/" +
                        _this.model.code
                )
                .then((res) => {
                    if (res.data.result) {
                        _this.$refs.dangerListReport.show({
                            taskCode: _this.model.code,
                            projectId: _this.model.projectId,
                        });
                    } else {
                        _this.msgError(res.data.errorMsg);
                    }
                });
        },
        handleVerify(row) {
            this.$refs.checkTaskVerify.show(row);
        },
        handleView(row) {
            this.$refs.checkTaskView.show(row);
        },
        goReportList() {
            this.$router.push({
                name: "SiteDangerReportList",
                query: {
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });
        },
        handleChooseYJ() {
            this.chooseYJModel = {};
            this.libTempDetailsVisible = true;
            this.companyCode = this.model.enterpriseCode;
        },

        handlerSelectImg(obj) {
            this.chooseYJModel.correctiveAdvise = obj.base.correctiveAdvise;
            this.chooseYJModel.gistSource = obj.base.gistSource;
            this.chooseYJModel.originalText = obj.base.originalText;
            this.chooseYJModel.attachs = obj.img.filePath;
            this.chooseYJModel.item = obj.item;
            this.chooseYJModel.lGCode = obj.base.lGCode;
            if (obj.item === "base-img") {
            }
            if (obj.item === "base-img-danger") {
                this.chooseYJModel.lGHDCode = obj.danger.lGHDCode;
                this.chooseYJModel.dFullName = obj.danger.dFullName;
                this.chooseYJModel.dCode = obj.danger.dCode;
                this.chooseYJModel.hiddenDangerDesc =
                    obj.danger.hiddenDangerDesc;
                this.chooseYJModel.hiddenDangerType =
                    obj.danger.hiddenDangerType;
                this.chooseYJModel.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                this.chooseYJModel.legalLiability = obj.danger.legalLiability;
            }
            this.libTempDetailsVisible = false;
            this.$refs.checkTaskDetail.show(
                { mainCode: this.model.code },
                { type: 4, lg: this.chooseYJModel }
            );
        },

        buildReport() {
            let _this = this;
            _this.$refs.buildDangerReport.show({
                taskCodes: this.model.code,
                taskNames: this.model.checkTaskName,
                enterpriseCode: this.model.enterpriseCode,
                projectId: this.model.projectId,
            });
        },
        /*
         *
         */
        choosedDangerLg(chooseData, opType) {
            if (opType == 1) {
                let row = { id: 0, mainCode: this.model.code };
                let config = { type: 4, lg: chooseData };

                this.$refs.checkTaskDetail.show(row, config);
            }
            if (opType == 3) {
                // this.$refs.checkTaskDetail.show(row, config);
            }
        },

        /**
         * 获取状态描述
         */
        getCheckStatusDesc(status) {
            let obj = this.params.status.find((x) => x.id === status);
            if (obj)
                return `<span style='color:${obj.color}}'>${obj.name}</span>`;
            return "";
        },
        /**
         * 提交
         */
        submitEnd() {
            let _this = this;
            _this.http.postLoading(
                _this.loading(),
                _this.controller + "/submit/" + _this.model.id,
                {},
                function (res) {
                    _this.msgSuccess("保存成功");
                    _this.getData();
                }
            );
        },
        /**
         * 选择检查表
         */
        handleChooseLibTemplateShow() {
            this.$refs.chooseLibTemplate.show();
        },
        /**
         * 选择检查表保存
         */
        handleChooseLibTemplate(array) {
            let _this = this;
            let relationsArray = [];
            let message = "";
            if (array && array.length > 0) {
                array.forEach((x) => {
                    if (
                        _this.model.relations.findIndex(
                            (p) => p.checkTemplateCode == x.tCode
                        ) > 0
                    ) {
                        message = (message ? "," : message) + `${x.title}`;
                    } else {
                        relationsArray.push({
                            checkTaskCode: _this.model.code,
                            checkTemplateCode: x.tCode,
                            templateName: x.title,
                        });
                    }
                });
                if (message) {
                    this.msgInfo(`${message}已经存在检查任务中`);
                }
                if (relationsArray && relationsArray.length > 0) {
                    _this.http
                        .post(
                            "ecologyEnv/dangerCheckTaskRelation/saveRelationsAndBack",
                            relationsArray
                        )
                        .then(function (res) {
                            _this.model.relations = res.data;
                        });
                }
            }
        },

        //检查表检查,查看依据
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({ model: item, isEdit: this.otEdit });
        },
        randVolid() {
            return true;
        },
        bindData(data) {
            this.rowData = data;
            this.rowData.mainCode = this.model.code;
            if (this.rowData.id == 0) {
                this.rowData.originType = 1;
                this.rowData.checkResult = "N";
            }
            this.randTitle = this.formateDict(
                this.params.checkSource,
                this.rowData.originType
            );
        },
        handleDelete(row) {
            this.$refs.EaglePage.handleDelete(row);
        },

        handleUpdate(row, type) {
            let config = { type: type };
            this.$refs.checkTaskDetail.show(row, config);
        },
        handleShowRandForm() {
            let row = {
                id: 0,
                mainCode: this.model.code,
                hiddenDangerTypeCode: "1",
            };
            let config = { type: 3, projectId: this.model.projectId };
            this.$refs.checkTaskDetail.show(row, config);
        },

        handleRandShowHidden() {
            this.$refs.ChooseDangerType.show();
        },
        handleShowHidden(row) {
            this.$refs.ChooseDangerType.show();
            this.rowData = row;
        },
        handleChooseDangerType(val, obj) {
            this.rowData.hiddenCode = val;
            this.rowData.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.model.hiddenTypeCode = obj.dType;
        },
        initData() {
            this.modulesId = this.$route.meta.modulesId;
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        handleChangeResult(row, status, source) {
            if (this.otEdit && (this.lcEdit || source == 1)) {
                row.checkResult = row.checkResult == status ? "" : status;
            }
        },
        back() {
            let params = {};
            params.enterpriseCode = this.$route.query.enterpriseCode ?? "";
            params.projectId = this.$route.query.projectId ?? "";
            this.$router.push({
                path: "DangerPlan",
                query: params,
            });
        },
        getStatusDesc() {
            let obj = this.taskStatusArray.find(
                (x) => x.value === this.model.serviceStatus
            );
            if (obj)
                return `<span style='color:${obj.color}'>${obj.text}</span>`;
            else return "";
        },
        getData() {
            let _this = this;
            _this.http
                .get(_this.controller + "/getDataByCode/" + _this.code)
                .then((res) => {
                    _this.model = res.data;
                    _this.queryParams.mainCode = _this.model.code;
                    _this.otEdit =
                        _this.$route.query.op != "v" &&
                        _this.model.status == 10;
                    _this.resetQuery();
                });
        },
        showTemplate(row) {
            // debugger;
            console.log(row);
            this.$router.push({
                name: "SiteDangerTemplateCheck",
                query: {
                    taskCode: this.model.code,
                    templateCode: row.checkTemplateCode,
                    isEdit: this.model.status == 10 ? 1 : 2,
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });
        },

        search() {
            this.$refs.EaglePage.search({
                url: this.detailController + "/getPageData",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        //查询条件重置
        resetQuery() {
            this.conditionsVals.originType = null;
            this.conditionsVals.status = null;
            this.conditionsVals.hiddenDangerDesc = "";
            this.search();
        },
        getCompateClassName(row) {
            return row.row.complete ? "" : "complete";
        },
    },
};
</script>
<style scoped lang="scss">
.site-danger-check-task {
    padding: 10px;

    ::v-deep.el-form-item {
        margin-bottom: 0px;
    }

    .el-card {
        margin-top: 10px;
    }

    .temp-block {
        background-color: #f4f9ff;
        width: 300px;
        padding: 5px 10px;
        display: inline-block;
        margin-right: 10px;
        border: 1px solid #e1f3d8;

        .temp-title {
            font-size: 15px;
            width: 245px;
            color: #303133;
            line-height: 28px;
        }

        .temp-button {
            text-align: right;
        }
    }
}

.el-dialog__body {
    padding: 0 20px 20px 20px;
}

.btn_group button {
    margin: 5px;
    margin-left: 5px !important;
}

.template-list {
    max-height: 600px;
    overflow-y: auto;
}

.eagle-table {
    font-family: verdana, arial, sans-serif;
    font-size: 11px;
    color: #333333;
    border-width: 1px;
    border-color: #666666;
    border-collapse: collapse;

    th {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #dedede;
    }

    td {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #ffffff;
    }
}
</style>