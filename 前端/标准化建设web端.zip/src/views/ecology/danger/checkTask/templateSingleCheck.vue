<template name="danger-lg-task-detail">
    <div>
        <el-dialog v-dialogDrag :title="title" :visible.sync="visible" width="1000px" append-to-body show-close :close-on-click-modal="false">
            <!-- <div slot="title">
                {{title}}
            </div> -->
            <el-form :form="form" label-width="120px" ref="EagleForm">
                <eagle-block border class="danger-lg-task-detail">
                    <eagle-image :is-edit="isEdit" label-width="100px" key="attachs" v-model="form.attachs" label="隐患图片" prop='attachs' :count="3" />
                    <eagle-input :is-edit="isEdit" :class="form.hiddenTypeCode=='2'?'is-required':''" :row="2" label-width="100px" label="隐患区域" v-model="form.correctiveArea" />
                    <div v-if="isEdit&&dangerSource&&dangerSource.length>0&&dangerSource[0].hiddenDangerDesc" style="margin-left:100px;max-heigth:200px">
                        <span>快捷选择隐患描述</span>
                        <template v-for="(sitem,sindex) in dangerSource">
                            <div class="using-content" :key="sindex">
                                <div class="using-content-item">{{sindex+1}}. {{sitem.hiddenDangerDesc}} <span class="btn-using" @click="setDangerDesc(sitem)">引用</span></div>
                            </div>
                        </template>
                    </div>
                    <div style="text-align: right;">
                        <el-button type="text" @click="hdTemplateCheckShowLg(form)"> {{isEdit?"编辑依据":"查看依据"}}</el-button>
                    </div>
                    <eagle-input :is-edit="isEdit" type="textarea" :row="2" label-width="100px" required label="隐患描述" v-model="form.hiddenDangerDesc" />
                    <eagle-input :is-edit="isEdit" type="textarea" :row="2" label-width="100px" label="整改建议" prop='correctiveAdvise' v-model="form.correctiveAdvise" />
                    <el-row>
                        <el-col :span="12">
                            <eagle-choose @clearChoose="clearHidden(form)" :is-edit="isEdit" :class="{'is-required':modulesId=='host'}" label-width="100px" label="隐患分类" v-model="form.hiddenName" @change="handleRandShowHidden()" />
                        </el-col>
                    </el-row>
                    <eagle-radio :is-edit="isEdit" class="is-required" label-width="100px" label="隐患性质" v-model="form.hiddenDangerTypeCode" :data-source="params.dangerType" />

                    <el-row v-if="!isHost">
                        <el-col :span="12" v-if="isEdit">
                            <eagle-choose-user label-width="100px" label="整改负责人" onlyShowRequired :single="true" :names.sync="form.appointCorrectiveChnName" v-model="form.appointCorrectiveName" />
                        </el-col>
                        <el-col :span="12" v-if="isEdit">
                            <el-button type="text" @click="hdSetMeCorrective">由我本人整改</el-button>
                        </el-col>
                        <el-col v-else>
                            <eagle-input :is-edit="!isEdit" prop='appointCorrectiveName' label-width="100px" label="整改负责人" v-model="form.appointCorrectiveChnName" required />
                        </el-col>
                    </el-row>
                    <eagle-radio :is-edit="isEdit" class="is-required" label-width="100px" label="整改方式" v-model="form.correctiveType" :data-source="params.correctiveType" />

                    <div v-if="form.correctiveType==1">
                        <eagle-image :is-edit="isEdit" class="is-required" label-width="100px" v-model="form.correctiveAttachs" label="整改图片" :count="3" />
                        <eagle-input :is-edit="isEdit" class="is-required" type="textarea" key="correctiveDesc" :row="2" label-width="100px" label="整改说明" v-model="form.correctiveDesc" />
                    </div>
                    <div v-if="form.correctiveType==2">
                        <el-row>
                            <el-col :span="12">
                                <eagle-date :is-edit="isEdit" label-width="100px" prop='correctiveDeadline' quickChoose label="整改期限" v-model="form.correctiveDeadline" />
                            </el-col>
                        </el-row>
                        <eagle-input :is-edit="isEdit" key="correctiveMeasure" type="textarea" prop='correctiveMeasure' :row="2" label-width="100px" label="整改措施" v-model="form.correctiveMeasure" />
                    </div>
                </eagle-block>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancel">{{isEdit?"取 消":"关 闭"}}</el-button>
                <el-button v-if="isEdit" type="primary" @click="submitForm">确 定</el-button>
            </div>

        </el-dialog>
        <choose-danger-type ref="chooseDangerType" v-model="form.hiddenCode" @change="handleChooseDangerType" />
        <templateItem ref="templateItem" />
    </div>
</template>

<script>
import templateItem from "@/views/ecology/components/danger/template/templateItem";
import chooseDangerType from "@/views/components/danger/chooseDangerType";
import { getCurrentUser } from "@/utils/auth";
import EagleBlock from "../../../../components/Eagle/eagle-block.vue";

export default {
    components: {
        chooseDangerType,
        templateItem,
        EagleBlock,
    },
    name: "danger-lg-task-detail",
    props: {},
    data() {
        return {
            title: "",
            visible: false,
            isEdit: false,
            form: {},
            oldForm: {},
            dangerSource: [],
            params: {
                dangerType: [],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
            },
            projectId: "",
            modulesId: "",
            action: "", //新增或者编辑
            isHost: "",
        };
    },
    created() {
        this.isHost = this.$route.meta.modulesId == "host";
        this.projectId = this.$route.query.projectId ?? "";
        this.modulesId = this.$route.meta.modulesId;
    },
    computed: {},
    methods: {
        hdSetMeCorrective() {
            let _this = this;
            let userInfo = getCurrentUser();
            _this.form.appointCorrectiveChnName = userInfo.chnName;
            _this.form.appointCorrectiveName = userInfo.userName;
        },
        setDangerDesc(sitem) {
            debugger;
            this.form.hiddenDangerDesc = sitem.hiddenDangerDesc;
            this.form.hiddenDangerTypeCode = sitem.hiddenDangerType;
            this.form.legalLiability = sitem.legalLiability;
            this.form.hiddenCode = sitem.dCode;
            this.form.hiddenTypeName =
                sitem.dType == "1" ? "基础管理" : "现场管理";
            this.form.hiddenTypeCode = sitem.dType;
            if (sitem.dType)
                this.form.hiddenName = `${
                    sitem.dType == "1" ? "基础管理" : "现场管理"
                }-${sitem.dName}`;
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        show(options) {
            this.title = "编辑隐患";
            this.visible = true;
            this.isEdit = options.isEdit;
            this.action = options.action;
            // this.form = options.model
            this.oldForm = options.model;
            this.form = this.deepClone(this.oldForm);
            this.dangerSource = options.dangerSource;
            console.log(this.dangerSource);
            this.form.correctiveType =
                this.form.correctiveType && this.form.correctiveType > 0
                    ? this.form.correctiveType
                    : 2;
            this.initData();
        },
        clearHidden(obj) {
            // obj.lgdType = "";
            obj.hiddenCode = "";
            obj.hiddenName = "";
        },
        choosedDangerLg(chooseData) {
            this.form = chooseData;
        },
        randVolid() {
            return true;
        },
        handleChooseDangerType(val, obj) {
            this.form.hiddenCode = val;
            this.form.hiddenName = obj.dFullName.replace(">", "-");
            this.form.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.form.hiddenTypeCode = obj.dType;
        },
        handleRandShowHidden() {
            this.$refs.chooseDangerType.show();
        },
        cancel() {
            this.visible = false;
        },
        submitForm() {
            for (var key in this.form) {
                this.oldForm[key] = this.form[key];
            }

            this.$emit("confirm", this.form, this.action);
            this.cancel();
        },
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({
                model: item,
                isEdit: this.isEdit,
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-lg-task-detail {
    .using-content {
        font-size: 13px;
        // max-height: 55px;
        overflow: auto;
        padding: 5px 20px;
        .using-content-item {
            display: inline-block;
        }
        .btn-using {
            color: #409eff;
            cursor: pointer;
            font-size: 13px;
        }
    }
}
</style>