<template name="danger-jg-template-check">
    <div class="div-danger-jg-template-check layer">
        <div class="div-left" :style="{height:leftHeight+'px'}">
            <div class="p-location">
                <div class="dh-title">导航</div>
                <div :style="{height:(leftHeight-50)+'px',overflow:'auto'}">
                    <ul>
                        <li class="cl-lv1" v-for="(item,index) in templateModel.details" :key="'li'+index">
                            <div class="title" @click="hdNav('item_' + index)" :class="navSelector==('item_' + index)?'act':''">{{index+1}} {{item.detailTitle}}</div>
                            <div v-if="item.grandsons.length>0" class="cl-lv2">
                                <ul>
                                    <li class="cl-lv2" v-for="(gitem,gindex) in item.grandsons" :key="'li_'+index+'_'+gindex">
                                        <div class="title" :title="gitem.itemName" @click="hdNav('item_' + index + '_' + gindex)" :class="navSelector==('item_' + index + '_' + gindex)?'act':''">
                                            {{index+1}}.{{gindex+1}} {{gitem.itemName}}</div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="div-right" :style="{height:leftHeight+'px'}">
            <el-form>
                <div class="tl-container">
                    <div class="block-content">
                        <div class="block-num waithCheck" :class="actBlockIndex==1?'activity':''" @click="hdBlockClick(1)">
                            <p>
                                <span class="min-icon"></span>
                                <span>待检查</span>
                            </p>
                            <div class="num-pl">
                                <span class="num">{{waithCheck}}</span>
                                <span class="num-unit">项</span>
                            </div>
                        </div>

                        <div class="block-num unUserCheck" :class="actBlockIndex==2?'activity':''" @click="hdBlockClick(2)">
                            <p> <span class="min-icon"></span>
                                <span>不适用</span>
                            </p>
                            <div class="num-pl">
                                <span class="num">{{unUserCheck}}</span>
                                <span class="num-unit">项</span>
                            </div>
                        </div>

                        <div class="block-num failCheck" :class="actBlockIndex==3?'activity':''" @click="hdBlockClick(3)">
                            <p><span class="min-icon"></span>
                                <span>发现隐患</span>
                            </p>
                            <div class="num-pl">
                                <span class="num">{{failCheck}}</span>
                                <span class="num-unit">项</span>
                            </div>
                        </div>

                        <div class="block-num waithInputCheck" :class="actBlockIndex==4?'activity':''" @click="hdBlockClick(4)">
                            <p> <span class="min-icon"></span>
                                <span>待完善</span>
                            </p>
                            <div class="num-pl">
                                <span class="num">{{waithInputCheck}}</span>
                                <span class="num-unit">项</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="check-title-m">
                    检查内容
                </div>
                <el-scrollbar ref="scrollbarRef" :style="{height: isProject? 'calc(100vh - 428px)':'calc(100vh - 288px)'}">
                    <table v-for="(item,index) in templateModel.details" :key="index" class="tftable">
                        <tbody>
                            <tr class="order-row" :key="'item_'+index">
                                <td class="order-col" width="80px">
                                    <div :id="'item_'+index">
                                        {{index+1}}
                                    </div>
                                </td>
                                <td>
                                    <span> {{item.detailTitle}}</span>
                                </td>
                            </tr>

                            <tr v-for="(gitem,gindex) in item.grandsons" :key="'item_'+index+'_'+gindex">
                                <td class="order-col">
                                    {{index+1}}.{{gindex+1}}
                                </td>
                                <td>
                                    <div class="btn-td">
                                        <span style="font-size:13px;">
                                            <div :id="'item_'+index+'_'+gindex"> {{gitem.itemName}} </div>
                                        </span>
                                        <div class="btn-group">
                                            <span :class="gitem.checkResult=='Y'?'btn Y checked':'btn Y'" @click="setCheck(gitem,'Y')">符合</span>
                                            <span :class="gitem.checkResult=='N'?'btn N checked':'btn N'" @click="setCheck(gitem,'N')">不符合</span>
                                            <span :class="gitem.checkResult=='NA'?'btn NA checked':'btn NA'" @click="setCheck(gitem,'NA')">不适用</span>
                                        </div>
                                    </div>
                                    <div class="div-op" v-if="gitem.checkResult" :key="'item2_'+index+'_'+gindex">
                                        <div v-show="gitem.checkResult==='N'" class="content-N">

                                            <div v-for=" (ditem, dindex) in gitem.checkDetails" :key="'item_' + index + '_' + gindex + '_' + dindex" :id="'item_' + index + '_' + gindex + '_' + dindex" class="cn-item">
                                                <div class="box-item">
                                                    <div style="display: flex;">

                                                        <div style="width: 170px;" v-if="ditem.attachs">
                                                            <eagle-image key="attachs" :showImgCount="1" show-default-img :isEdit="false" v-model="ditem.attachs" />
                                                        </div>

                                                        <!-- <div v-if="ditem.attachs">
                                                                    <eagle-image-preview key="attachs" prop='attachs' :showImgCount="1" v-model="ditem.attachs" />
                                                                </div> -->
                                                        <div style="margin-top:10px;">
                                                            <div>
                                                                <div class="double-line" style="text-indent: 2em; line-height: 22px;">
                                                                    隐患描述:
                                                                    {{ ditem.hiddenDangerDesc }}
                                                                </div>
                                                            </div>
                                                            <div style="margin-top: 15px;">
                                                                <div style="text-indent: 2em; line-height: 22px;">
                                                                    隐患位置:

                                                                    {{ ditem.correctiveArea }}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="position: absolute;right: 20px;bottom: 20px;" v-if="taskModel.status<30">
                                                        <el-button type="primary" size="small" icon="el-icon-edit-outline" @click="editCheck(ditem,gitem.greatGrandsons)" style="height: 30px;">编辑</el-button>
                                                        <el-button type="danger" size="small" icon="el-icon-delete" @click="removeDanger(gitem,dindex)" style="height: 30px;">删除</el-button>
                                                    </div>
                                                    <div class="isOverTag" v-if="fnValidIsOver(ditem)">
                                                        <span>待完善</span>
                                                    </div>
                                                </div>
                                                <hr style="border:1px dashed #DCDFE6;margin-top:10px" />

                                            </div>

                                            <div style="padding: 10px;" class="cn-item" v-if="taskModel.status<30">
                                                <el-button type="primary" icon="el-icon-circle-plus-outline" @click="pushDanger(gitem) ">新增隐患
                                                </el-button>
                                            </div>

                                        </div>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>

                    <div :style="{height: isProject? 'calc(100vh - 500px)':'calc(100vh - 380px)'}"></div>
                </el-scrollbar>
            </el-form>
            <div class="div-button-container">
                <template v-if="taskModel.sourceType=='risk'">
                    <el-button @click="backToRisk()" type="default">返回</el-button>
                    <el-button @click="saveDraftRisk()" v-if="taskModel.status==10" type="primary">暂存并返回</el-button>
                    <el-button :disabled='waithCheck != 0' @click="postRisk()" v-if="taskModel.status==10" type="danger">结束检查</el-button>
                </template>
                <template v-else>
                    <el-button @click="back()" type="default">返回</el-button>
                    <el-button :disabled='waithCheck != 0' @click="post()" v-if="isEdit" type="primary">保存并返回</el-button>
                </template>
            </div>
        </div>
        <templateSingleCheck @confirm="singleConfirm" ref="templateSingleCheck" />

    </div>
</template>
<script>
import templateSingleCheck from "@/views/ecology/danger/checkTask/templateSingleCheck";
export default {
    components: {
        templateSingleCheck,
    },
    data() {
        return {
            swaperPreIndex: 0,
            actBlockIndex: 0,
            taskCode: "",
            controller: "ecologyEnv/dangerCheckTaskDetail",
            templateCode: "",
            templateModel: {},
            chooseItem: {},
            tempCheckDetail: [],
            isEdit: false,
            params: {
                // dangerCheckTaskType: [],
                opType: [],
                dangerType: [],
                correctiveType: [
                    {
                        id: 1,
                        name: "立即整改",
                    },
                    {
                        id: 2,
                        name: "限时整改",
                    },
                ],
                checkResult: [
                    {
                        id: "Y",
                        name: "符合",
                        color: "#67C23A",
                    },
                    {
                        id: "N",
                        name: "不符合",
                        color: "#F56C6C",
                    },
                    {
                        id: "NA",
                        name: "不适用",
                        color: "#E6A23C",
                    },
                ],
            },
            urlParams: {
                projectId: "",
                enterpriseCode: "",
            },
            taskModel: {},
            isHost: false,
            leftHeight: window.innerHeight - 240,
            defaultArea: "",
            defaultCorrectiveDate: "",
            isProject: (this.$route.query.projectId ?? "") != "",
            navSelector: "",
        };
    },
    created() {
        this.isHost = this.$route.meta.modulesId == "host";
        this.leftHeight = window.innerHeight - (this.isProject ? 240 : 100);

        this.templateCode = this.$route.query.templateCode ?? "";
        this.taskCode = this.$route.query.taskCode ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
        this.isEdit = this.$route.query.isEdit == 1;
        this.initData();
        this.getTemplate();
        if (this.taskCode) {
            this.getTaskModel();
        }
    },
    mounted() {},
    computed: {
        waithCheck() {
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (!citem.checkResult) num++;
                    });
                });
            return num;
        },
        unUserCheck() {
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (citem.checkResult === "NA") num++;
                    });
                });
            return num;
        },

        failCheck() {
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (
                            citem.checkResult === "N" &&
                            citem.checkDetails &&
                            citem.checkDetails.length > 0
                        ) {
                            num = num + citem.checkDetails.length;
                        }
                    });
                });
            return num;
        },
        waithInputCheck() {
            let num = 0;
            let _this = this;

            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (
                            citem.checkResult === "N" &&
                            citem.checkDetails &&
                            citem.checkDetails.length > 0
                        ) {
                            citem.checkDetails.forEach((x) => {
                                if (_this.fnValidIsOver(x)) {
                                    num++;
                                }
                            });
                        }
                    });
                });
            return num;
        },
    },

    methods: {
        hdNav(selector) {
            this.navSelector = selector;
            this.goAnchor("#" + selector);
        },

        hdBlockClick(index) {
            this.fnSwaper(index);
        },

        fnSwaper(type) {
            let _this = this;
            if (type == _this.actBlockIndex)
                _this.swaperPreIndex = _this.swaperPreIndex + 1;
            else {
                _this.actBlockIndex = type;
                _this.swaperPreIndex = 0;
            }
            //定义min 是为了减少循环,且避免死循环
            let index = -1;
            let minIndex = -1;

            let flag = false;
            let minFlag = false;

            let selector = "";
            let minSelector = "";

            if (
                _this.templateModel.details &&
                _this.templateModel.details.length > 0
            )
                _this.templateModel.details.forEach((item, i) => {
                    item.grandsons.forEach((citem, ci) => {
                        switch (type) {
                            //待检查项
                            case 1:
                                index++;
                                if (minFlag == false && !citem.checkResult) {
                                    minIndex = index;
                                    minFlag = true;
                                    minSelector = `#item_${i}_${ci}`;
                                }
                                if (flag == false && !citem.checkResult) {
                                    if (index >= _this.swaperPreIndex) {
                                        _this.swaperPreIndex = index;
                                        flag = true;
                                        selector = `#item_${i}_${ci}`;
                                    }
                                }
                                break;
                            //不适用项
                            case 2:
                                index++;
                                if (
                                    minFlag == false &&
                                    citem.checkResult === "NA"
                                ) {
                                    minIndex = index;
                                    minFlag = true;
                                    minSelector = `#item_${i}_${ci}`;
                                }
                                if (
                                    flag == false &&
                                    citem.checkResult === "NA"
                                ) {
                                    if (index >= _this.swaperPreIndex) {
                                        flag = true;
                                        _this.swaperPreIndex = index;
                                        selector = `#item_${i}_${ci}`;
                                    }
                                }
                                break;

                            //隐患数
                            case 3:
                                if (citem.checkResult === "N")
                                    if (
                                        citem.checkDetails &&
                                        citem.checkDetails.length > 0
                                    ) {
                                        citem.checkDetails.forEach(
                                            (gitem, gi) => {
                                                index++;
                                                if (
                                                    minFlag == false &&
                                                    gitem.checkResult === "N"
                                                ) {
                                                    minIndex = index;
                                                    minFlag = true;
                                                    minSelector = `#item_${i}_${ci}_${gi}`;
                                                }
                                                if (
                                                    flag == false &&
                                                    gitem.checkResult === "N"
                                                ) {
                                                    if (
                                                        index >=
                                                        _this.swaperPreIndex
                                                    ) {
                                                        flag = true;
                                                        _this.swaperPreIndex =
                                                            index;
                                                        selector = `#item_${i}_${ci}_${gi}`;
                                                    }
                                                }
                                            }
                                        );
                                    }
                                break;
                            //待完善
                            case 4:
                                if (citem.checkResult === "N") {
                                    if (
                                        citem.checkDetails &&
                                        citem.checkDetails.length > 0
                                    ) {
                                        citem.checkDetails.forEach(
                                            (gitem, gi) => {
                                                index++;
                                                if (
                                                    minFlag == false &&
                                                    _this.fnValidIsOver(gitem)
                                                ) {
                                                    minIndex = index;
                                                    minFlag = true;
                                                    minSelector = `#item_${i}_${ci}_${gi}`;
                                                }
                                                if (
                                                    flag == false &&
                                                    _this.fnValidIsOver(gitem)
                                                ) {
                                                    if (
                                                        index >=
                                                        _this.swaperPreIndex
                                                    ) {
                                                        flag = true;
                                                        _this.swaperPreIndex =
                                                            index;
                                                        selector = `#item_${i}_${ci}_${gi}`;
                                                    }
                                                }
                                            }
                                        );
                                    }
                                }

                                break;
                        }
                    });
                });
            if (selector) {
                _this.goAnchor(selector);
            } else if (minSelector) {
                _this.swaperPreIndex = minIndex;
                _this.goAnchor(minSelector);
            }
        },

        fnValidIsOver(item) {
            return (
                (!item.correctiveArea && item.hiddenTypeCode == "2") ||
                (this.isHost && !item.hiddenName) ||
                !item.hiddenDangerDesc ||
                !item.hiddenDangerTypeCode ||
                !item.correctiveType ||
                (item.correctiveType == 1 &&
                    (!item.correctiveAttachs || !item.correctiveDesc)) ||
                (!item.appointCorrectiveChnName && !this.isHost)
            );
        },

        singleConfirm(item, opType) {
            if (opType == "add") {
                this.defaultArea = item.correctiveArea;
                this.defaultCorrectiveDate = item.correctiveDeadline;
            }
        },
        getTaskModel() {
            let _this = this;
            _this.http
                .get("ecologyEnv/dangerCheckTask/getDataByCode/" + _this.taskCode)
                .then((res) => {
                    _this.taskModel = res.data;
                });
        },
        removeDanger(model, index) {
            model.checkDetails.splice(index, 1);
            if (!model.checkDetails || model.checkDetails.length <= 0)
                model.checkResult = "";
        },
        editCheck(item, dangerSource, action) {
            console.log("editCheck");
            console.log(item);
            let _this = this;
            _this.$refs.templateSingleCheck.show({
                model: item,
                dangerSource: dangerSource,
                isEdit: true,
                action: action,
            });
        },
        pushDanger(item) {
            item.checkDetails.push(this.getPushModel(item, false));
            this.editCheck(
                item.checkDetails[item.checkDetails.length - 1],
                item.greatGrandsons,
                "add"
            );
        },
        clearHidden(obj) {
            obj.hiddenCode = "";
            obj.hiddenName = "";
            obj.hiddenTypeName = "";
            obj.hiddenTypeCode = "";
        },

        setDangerDesc(ditem, sitem, correctiveAdvise) {
            ditem.hiddenDangerDesc = sitem.hiddenDangerDesc;
            ditem.hiddenDangerTypeCode = sitem.hiddenDangerType;
            ditem.correctiveAdvise = correctiveAdvise;
            ditem.legalLiability = sitem.legalLiability;
            ditem.hiddenCode = sitem.dCode;
            ditem.hiddenTypeName = sitem.dType == "1" ? "基础管理" : "现场管理";
            ditem.hiddenTypeCode = sitem.dType;
            ditem.hiddenName = sitem.dName.replace(">", "-");
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        //锚点跳转
        goAnchor(selector) {
            let sss = document.querySelector(selector);
            let top = this.getAbsCoordinates(document.querySelector(selector));
            let tempPx = this.isProject ? 360 : 220;
            this.$refs.scrollbarRef.wrap.scrollTop = top - tempPx;
        },
        getAbsCoordinates(e) {
            var pos = {
                top: 0,
                left: 0,
            };
            while (e && e.className != "div-right") {
                pos.left += e.offsetLeft;
                pos.top += e.offsetTop;
                e = e.offsetParent;
            }
            return pos.top;
        },
        getCheckList() {
            let _this = this;
            let url = `${_this.controller}/getTempCheckItem/${_this.taskCode}/${_this.templateCode}`;

            _this.http.get(url).then((res) => {
                _this.tempCheckDetail = res.data;
                _this.reSetModel();
            });
        },
        setCheck(item, checkResult) {
            debugger;
            if (this.isEdit) {
                item.checkResult =
                    item.checkResult === checkResult ? "" : checkResult;
                if (item.checkResult == "N") {
                    if (
                        (item.checkDetails && item.checkDetails.length > 0) ==
                        false
                    ) {
                        item.checkDetails.push(this.getPushModel(item, true));
                        this.editCheck(
                            item.checkDetails[0],
                            item.greatGrandsons,
                            "add"
                        );
                    }
                }
            }
        },
        getPushModel(item, isInit) {
            var data = {
                gistSource: item.gistSource,
                templateItemName: item.itemName,
                templateItemCode: item.itemFullNo,
                hiddenDangerDesc: "",
                correctiveArea: this.defaultArea,
                hiddenDangerTypeCode: "1",
                correctiveAdvise: item.correctiveAdvise,
                hiddenName: "",
                hiddenCode: "",
                lgdType: "",
                hiddenTypeCode: "",
                hiddenTypeName: "",
                legalLiability: "",
                detailItemFullNo: "",
                templateCode: this.templateCode,
                mainCode: this.taskCode,
                templateName: this.templateModel.title,
                detailNo: "",
                checkResult: "N",
                originType: 3,
                correctiveDeadline: this.defaultCorrectiveDate,
                correctiveType: 2,
                originalText: item.originalText,
                appointCorrectiveChnName: "",
                appointCorrectiveName: "",
            };
            if (
                isInit &&
                item &&
                item.greatGrandsons &&
                item.greatGrandsons.length == 1
            ) {
                let itemDetial = item.greatGrandsons[0];
                data.hiddenDangerDesc = itemDetial.hiddenDangerDesc;
                data.hiddenDangerTypeCode = itemDetial.hiddenDangerType;
                data.legalLiability = itemDetial.legalLiability;
                data.hiddenCode = itemDetial.dCode;
                if (itemDetial.dName) {
                    data.hiddenTypeName =
                        itemDetial.dType == "1" ? "基础管理" : "现场管理";
                    data.hiddenName =
                        data.hiddenTypeName +
                        "-" +
                        itemDetial.dName.replace(">", "-");

                    data.hiddenTypeCode = itemDetial.dType;
                }
            }
            return data;
        },
        reSetModel() {
            let _this = this;
            _this.templateModel.details.forEach((item) => {
                if (item.grandsons && item.grandsons.length > 0) {
                    item.grandsons.forEach((citem) => {
                        _this.$set(citem, "checkResult", "");
                        _this.$set(citem, "checkDetail", {
                            templateItemName: citem.itemName,
                            templateItemCode: citem.itemFullNo,
                            checkResult: "",
                            attachs: "",
                            templateCode: _this.templateCode,
                            mainCode: _this.taskCode,
                            templateName: _this.templateModel.title,
                            originType: 3,
                        });
                        let array = _this.tempCheckDetail.filter(
                            (x) => x.templateItemCode == citem.itemFullNo
                        );
                        if (array && array.length > 0) {
                            _this.$set(citem, "checkDetails", array);
                            citem.checkResult = array[0].checkResult;
                            if (citem.checkResult !== "N") {
                                citem.checkDetail = array[0];
                            }
                        } else {
                            _this.$set(citem, "checkDetails", []);
                        }
                    });

                    //let array=_this.tempCheckDetail.find(x=>x.detailNo==item.)
                }
            });
        },
        getTemplate() {
            let _this = this;
            let url = `support/DagerTpl/GetTemplateByCode?tCode=${this.templateCode}`;
            _this.http.get(url).then((res) => {
                _this.templateModel = res.data;
                _this.getCheckList();
            });
        },
        back() {
            let params = {
                code: this.taskCode,
            };
            params.enterpriseCode = this.urlParams.enterpriseCode ?? "";
            params.projectId = this.urlParams.projectId ?? "";
            this.$router.push({
                path: "dangerCheckTask",
                query: params,
            });
        },
        checkRiskMustinput(successCall, needCheck) {
            let _this = this;
            let array = [];
            let selector = "";
            let message = "";
            let flag = true;
            this.templateModel.details.forEach((item, index) => {
                item.grandsons.forEach((citem, cindex) => {
                    if (citem.checkResult == "N") {
                        if (citem.checkDetails && citem.checkDetails.length > 0)
                            citem.checkDetails.forEach((gitem, dindex) => {
                                gitem.templateItemCode = citem.itemFullNo;
                                gitem.detailNo = citem.itemNo;
                                array.push(gitem);
                                if (needCheck) {
                                    let tmpInde = `第${index + 1}.${
                                        cindex + 1
                                    }.${dindex + 1}`;
                                    selector = `#item_${index}_${cindex}`;
                                    message = message + `${tmpInde}项隐患信息`;
                                    // if (!gitem.attachs) {
                                    //     message = message + `请上传隐患图片\n`;
                                    //     flag = false;
                                    // }
                                    if (
                                        !gitem.correctiveArea &&
                                        gitem.hiddenTypeCode == "2"
                                    ) {
                                        message = message + `请输入隐患区域\n`;
                                        flag = false;
                                    }
                                    if (!gitem.hiddenDangerDesc) {
                                        message = message + `请输入隐患描述\n`;
                                        flag = false;
                                    }

                                    if (!gitem.hiddenDangerTypeCode) {
                                        message = message + `请选择隐患性质\n`;
                                        flag = false;
                                    }
                                    if (gitem.correctiveType == 1) {
                                        if (!gitem.correctiveAttachs) {
                                            message =
                                                message +
                                                `选择的整改方式为立即整改,请上传整改图片\n`;
                                            flag = false;
                                        }
                                        if (!gitem.correctiveDesc) {
                                            message =
                                                message +
                                                `选择的整改方式为立即整改,请输入整改说明\n`;
                                            flag = false;
                                        }
                                    }
                                    if (
                                        !_this.isHost &&
                                        !gitem.appointCorrectiveName
                                    ) {
                                        message =
                                            message + `请选择整改负责人\n`;
                                        flag = false;
                                    }
                                }
                            });
                    }
                    if (citem.checkResult == "Y" || citem.checkResult == "NA") {
                        citem.checkDetail.checkResult = citem.checkResult;
                        array.push(citem.checkDetail);
                    }
                });
            });
            if (!flag) {
                _this.goAnchor(selector);
                _this.msgError(message);
                return false;
            }
            let url = `${_this.controller}/tempCheckCommit/${_this.taskCode}/${_this.templateCode}`;
            _this.http.postLoading(_this.loading(), url, array, function (res) {
                if (res.code == 200) {
                    if (typeof successCall === "function") {
                        successCall();
                    }
                }
            });
        },
        backRisk() {
            if (this.$route.query.isFromDanger == "1") {
                this.$router.push({
                    name: "DangerPlan",
                    query: {
                        enterpriseCode: this.urlParams.enterpriseCode,
                        projectId: this.urlParams.projectId,
                        activeName: "second",
                    },
                });
            } else {
                this.$router.push({
                    name: "HostRiskCheckList",
                    query: this.urlParams,
                });
            }
        },
        backToRisk() {
            let _this = this;
            this.$confirm("是否确认要退出当前检查?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.backRisk();
            });
        },
        saveDraftRisk() {
            let _this = this;
            this.checkRiskMustinput(function () {
                _this.backRisk();
            }, false);
        },
        postRisk() {
            let _this = this;
            this.checkRiskMustinput(function () {
                _this.http.postLoading(
                    _this.loading(),
                    "ecologyEnv/dangerCheckTask/submitByCode/" + _this.taskCode,
                    {},
                    function (res) {
                        _this.msgSuccess("保存成功");
                        //跳转
                        _this.backRisk();
                    }
                );
            }, true);
        },
        post() {
            let _this = this;
            let array = [];
            let message = "";
            // let flag = true;
            let selector = "";
            _this.templateModel.details.forEach((item, index) => {
                // if (!flag) return false;
                item.grandsons.forEach((citem, cindex) => {
                    if (citem.checkResult == "N") {
                        if (citem.checkDetails && citem.checkDetails.length > 0)
                            citem.checkDetails.forEach((gitem, dindex) => {
                                gitem.templateItemCode = citem.itemFullNo;
                                gitem.detailNo = citem.itemNo;
                                gitem.checkResult = citem.checkResult;
                                array.push(gitem);
                            });
                    }
                    if (citem.checkResult == "Y" || citem.checkResult == "NA") {
                        citem.checkDetail.checkResult = citem.checkResult;
                        array.push(citem.checkDetail);
                    }
                });
            });
            if (message) {
                _this.goAnchor(selector);
                _this.msgError(message);
                return false;
            }
            // let url = `${_this.controller}/${isTempPost ? "tempCheck" : "tempCheckCommit"
            let url = `${_this.controller}/tempCheckCommit/${_this.taskCode}/${_this.templateCode}`;

            // _this.http.post(url, array).then((res) => {
            //     _this.back();
            // });
            _this.http.postLoading(_this.loading(), url, array, function (res) {
                _this.back();
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.div-danger-jg-template-check {
    ::deep .app-main {
        min-height: calc(100vh - 50px);
    }
    .box-item {
        display: flex;
        justify-content: space-between;
    }

    .double-line {
        text-indent: 2em;
        line-height: 22px;
        display: -webkit-box;
        text-overflow: ellipsis;
        overflow: hidden;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    display: flex;
    margin-left: 10px;
    margin-right: 10px;
    display: flex;

    ::v-deep .el-form-item {
        margin: 10px;
    }

    .p-location {
        overflow: auto;
        // z-index: 9;
        // position: fixed;
        // padding: 5px 0px;
        text-align: center;
        width: 100%;
        min-height: 22px;

        .dh-title {
            height: 40px;
            background: #f5f7fa;
            font-size: 16px;
            line-height: 40px;
        }

        ul,
        li {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        li.cl-lv1 {
            padding: 2px 10px;
            .title {
                line-height: 35px;
                font-size: 12px;
                font-weight: 600;
                color: #303133;
            }
            .title.act {
                color: #409eff;
            }
        }
        li.cl-lv2 {
            height: 35px;
            .title {
                font-size: 12px;
                font-weight: 400;
                color: #606266;
                height: 35px;
                line-height: 35px;
                border-bottom: 1px solid #f5f7fa;
            }
            .title.act {
                color: #409eff;
            }
        }
        .title {
            text-align: left;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block;
            cursor: pointer;
            line-height: 25px;
            font-size: 12px;
            // margin: 0px auto 10px auto;
            color: #707070;
        }

        .cl-lv1 {
            padding-left: 10px;
        }

        // .cl-lv2 {
        //     // padding-left: 15px;
        // }
    }

    .div-left {
        width: 185px;
        // padding: 5px;
        border: 1px solid #e1e1e1;
        border-radius: 4px;
        margin-right: 10px;
        padding-bottom: 5px;
    }

    .div-right {
        flex: 1;
        margin-right: 10px;
        width: calc(100vw - 530px);
    }

    // .div-left,
    .div-right {
        padding: 15px;
        border: 1px solid #e1e1e1;
        border-radius: 4px;
        table.tftable {
            font-size: 12px;
            color: #333333;
            width: 100%;
            margin-bottom: 15px;
            // box-shadow: 1px #e4e4e4;
        }
        ::deep .el-scrollbar__wrap {
            overflow-x: hidden;
        }
        table.tftable td {
            border: 1px solid #e4e4e4;
            border-left: none;
            border-top: none;
            border-spacing: xpx;
            // padding: 5px;
            text-align: left;
        }

        table.tftable td span {
            line-height: 1.6;
        }

        table.tftable {
            border-radius: 5px;
            border-spacing: 0;
            .order-row {
                background-color: #ecf5ff;
                color: #409eff;
                td {
                    padding: 10px 5px;
                }
            }

            .order-col {
                text-align: center;
                width: 60px;
            }

            tr:first-child td {
                border-top: 1px solid #e4e4e4;
            }
            tr td:first-child {
                border-left: 1px solid #e4e4e4;
            }
            tr:first-child td:first-child {
                border-top-left-radius: 10px; /* 设置table左下圆角 */
            }
            tr:first-child td:last-child {
                border-top-right-radius: 10px; /* 设置table右下圆角 */
            }
            tr:last-child td:first-child {
                border-bottom-left-radius: 10px; /* 设置table左下圆角 */
            }
            tr:last-child td:last-child {
                border-bottom-right-radius: 10px; /* 设置table右下圆角 */
            }
            tr:first-child td {
                border-bottom: none;
            }
        }
        .isOverTag {
            padding: 0px 10px;
            color: #ff6600;
            background-color: #f6e4df;
            position: absolute;
            right: 0px;
            top: -1px;
            font-size: 12px;
            width: 56px;
            height: 28px;
            border-bottom-left-radius: 5px;
            line-height: 28px;
        }

        .cn-item {
            position: relative;
            text-align: left;

            .btn-rm {
                position: absolute;
                right: 10px;
                top: 10px;
                color: red;
                cursor: pointer;
                z-index: 100;
            }
        }

        .swp {
            display: flex;
            justify-content: space-between;
            border: 1px solid #e4e4e4;
            border-bottom: 0px;
            border-right: 0px;
            background: #ecf8ff;

            span {
                width: 25%;
                text-align: center;
                line-height: 35px;
                border-right: 1px solid #e4e4e4;
                font-size: 14px;
            }
        }

        .el-form-item {
            margin-bottom: 10px;
        }

        .item-title {
            text-align: left;
        }

        .item-title span {
            margin: 10px !important;
        }

        .btn-td {
            display: flex;
            justify-content: space-between;
            padding: 10px;

            .btn-group {
                display: flex;
                justify-content: space-between;

                .btn {
                    width: 80px;
                    display: block;
                    margin-left: 5px;
                    margin-right: 5px;
                    display: -webkit-box;
                    display: -webkit-flex;
                    display: flex;
                    -webkit-box-pack: center;
                    -webkit-justify-content: center;
                    justify-content: center;
                    height: 30px;
                    border-radius: 5px;
                    line-height: 30px;
                    cursor: pointer;
                    border: 1px solid #e4e4e4;
                }

                .btn.Y.checked {
                    background-color: #19be6b;
                    color: #ffffff;
                }

                .btn.N.checked {
                    background-color: red;
                    color: #ffffff;
                }

                .btn.NA.checked {
                    background-color: #ff976a;
                    color: #ffffff;
                }
            }
        }

        .div-op {
            background: #f5f7fa;
        }

        .div-op .content-N {
            .cn-item:first-child {
                border-top: 1px solid #e1e1e1;
            }

            .box-item {
                padding: 10px;
            }
        }

        .div-op .content-Y {
            padding: 10px;
            position: relative;
            .cn-item:first-child {
                border-top: 1px solid #e1e1e1;
            }
        }

        .using-content {
            font-size: 13px;
        }

        .btn-using {
            color: #409eff;
            cursor: pointer;
            font-size: 13px;
        }

        .div-button-container {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
            margin-top: 10px;
        }

        .tl-container {
            .block-content {
                display: flex;
                justify-content: flex-start;
                margin-bottom: 10px;
            }

            .block-num {
                width: 226px;
                height: 90px;
                border-radius: 4px;
                cursor: pointer;
                margin-right: 15px;
                p {
                    margin-top: 15px;
                    margin-left: 15px;
                }
                .min-icon {
                    width: 16px;
                    height: 16px;
                    margin-right: 5px;
                    float: left;
                }
                .num-pl {
                    margin-top: 5px;
                    text-align: center;
                    .num {
                        font-size: 36px;
                        font-weight: bold;
                        line-height: 42px;
                    }
                    .num-unit {
                        font-size: 12px;
                    }
                }
            }

            .block-num.waithCheck {
                background: url("../../../../assets/img/danger/bg-num1.png")
                    no-repeat;
                color: #409eff;
                .min-icon {
                    background: url("../../../../assets/img/danger/num1-ico.png")
                        no-repeat;
                }
            }

            .block-num.waithCheck:hover,
            .block-num.waithCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num1.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num1-ico.png")
                        no-repeat;
                }
            }

            .block-num.unUserCheck {
                background: url("../../../../assets/img/danger/bg-num2.png")
                    no-repeat;
                color: #e6a23c;
                .min-icon {
                    background: url("../../../../assets/img/danger/num2-ico.png")
                        no-repeat;
                }
            }

            .block-num.unUserCheck:hover,
            .block-num.unUserCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num2.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num2-ico.png")
                        no-repeat;
                }
            }

            .block-num.failCheck {
                background: url("../../../../assets/img/danger/bg-num3.png")
                    no-repeat;
                color: #f56c6c;
                .min-icon {
                    background: url("../../../../assets/img/danger/num3-ico.png")
                        no-repeat;
                }
            }
            .block-num.failCheck:hover,
            .block-num.failCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num3.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num3-ico.png")
                        no-repeat;
                }
            }

            .block-num.waithInputCheck {
                background: url("../../../../assets/img/danger/bg-num4.png")
                    no-repeat;
                color: #a254dd;
                .min-icon {
                    background: url("../../../../assets/img/danger/num4-ico.png")
                        no-repeat;
                }
            }
            .block-num.waithInputCheck:hover,
            .block-num.waithInputCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num4.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num4-ico.png")
                        no-repeat;
                }
            }

            .check-title-m {
                height: 20px;
                font-size: 14px;
                font-weight: bold;
                color: #303133;
                line-height: 20px;
                margin-top: 10px;
                margin-bottom: 10px;
            }
        }
    }
}
</style>
