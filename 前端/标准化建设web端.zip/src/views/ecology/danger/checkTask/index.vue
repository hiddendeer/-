<template>
  <div class="app-container">
    <div class="layer">
      <eagle-page
        id="table-page"
        :controller="controller"
        ref="EaglePage"
        btnWidth="200"
        :showCheckColumn="false"
        :queryParams="queryParams"
      >
        <template slot="slot-search">
          <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <!-- <eagle-radio labelWidth="80px" label="隐患类型" @change="search()" prop="certKind" v-model="conditionsVals.correctiveUserType" :data-source="params.correctiveUserType" size="small" /> -->
            <eagle-select
              labelWidth="80px"
              v-if="pageType !== 3"
              label="隐患状态"
              @change="search()"
              prop="certKind"
              v-model="conditionsVals.status"
              :data-source="params.status"
              size="small"
            >
            </eagle-select>
            <eagle-select
              labelWidth="80px"
              v-if="pageType !== 3"
              label="隐患性质"
              @change="search()"
              prop="certKind"
              v-model="conditionsVals.hiddenDangerTypeCode"
              :data-source="params.dangerTypeConditions"
              size="small"
            ></eagle-select>
            <eagle-select
              labelWidth="80px"
              v-if="pageType !== 3"
              label="隐患来源"
              @change="search()"
              prop="certKind"
              v-model="conditionsVals.originType"
              :data-source="params.checkSource"
              size="small"
            ></eagle-select>
            <eagle-input
              labelWidth="80px"
              @changeEnter="search()"
              label="筛选条件"
              prop="title"
              v-model="conditionsVals.hiddenDangerDesc"
              placeholder="请输入隐患描述模糊查询"
              clearable
              size="small"
            />
          </eagle-condition>
        </template>
        <template slot="slot-buttons">
          <el-button
            type="primary"
            icon="el-icon-plus"
            size="mini"
            @click="handleExport"
            >导出</el-button
          >
        </template>

        <template slot="slot-table">
          <el-table-column
            label="检查任务"
            align="left"
            prop="taskPlanName"
            width="250"
          >
            <template slot-scope="scope">
              <el-link
                style="color: #46a6ff"
                @click.prevent.stop="goPlanDetail(scope.row.mainCode)"
              >
                {{ scope.row.taskPlanName }}</el-link
              >
            </template>
          </el-table-column>
          <el-table-column
            label="隐患描述"
            align="left"
            prop="hiddenDangerDesc"
            width="300"
          />
          <el-table-column
            label="隐患图片"
            align="left"
            prop="attachs"
            width="100"
          >
            <template slot-scope="scope">
              <eagle-row-image v-model="scope.row.attachs" />
            </template>
          </el-table-column>

          <el-table-column
            label="隐患状态"
            align="left"
            prop="createDate"
            width="80"
          >
            <template slot-scope="scope">
              <span v-html="getCheckResultDesc(scope.row.status)"></span>
            </template>
          </el-table-column>
          <el-table-column label="隐患性质" align="left">
            <template slot-scope="scope">
              <span>{{
                formateDict(params.dangerType, scope.row.hiddenDangerTypeCode)
              }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="整改期限"
            align="left"
            prop="createDate"
            width="100"
          >
            <template slot-scope="scope">
              <span>{{
                parseTime(scope.row.correctiveDeadline, "{y}-{m}-{d}") || "--"
              }}</span>
              <div
                v-if="scope.row.correctiveDeadline && scope.row.status == 30"
                v-html="getSuplusDate(scope.row.correctiveDeadline)"
              ></div>
            </template>
          </el-table-column>
          <el-table-column
            label="整改后图片"
            align="left"
            prop="receiveAttach"
            width="100"
          >
            <template slot-scope="scope">
              <eagle-row-image
                v-if="scope.row.receiveAttach"
                v-model="scope.row.receiveAttach"
              />
              <eagle-row-image v-else v-model="scope.row.correctiveAttachs" />
            </template>
          </el-table-column>
          <el-table-column
            label="检查人"
            align="left"
            prop="createChnName"
            width="120"
          />
          <el-table-column
            label="检查时间"
            align="left"
            prop="createDate"
            width="140"
          >
            <template slot-scope="scope">
              <span>{{
                parseTime(scope.row.createDate, "{y}-{m}-{d} {h}:{i}")
              }}</span>
            </template>
          </el-table-column>
          <el-table-column
            v-if="pageType != 2"
            label="整改负责人"
            align="left"
            prop="appointCorrectiveChnName"
            width="100"
          />

          <el-table-column
            label="复查人"
            align="left"
            prop="attachs"
            width="120"
          >
            <template slot-scope="scope">
              {{ scope.row.correctiveUserChName || "--" }}
            </template>
          </el-table-column>
          <el-table-column
            label="复查时间"
            align="left"
            prop="createDate"
            width="140"
          >
            <template slot-scope="scope">
              <span>{{
                parseTime(scope.row.correctiveTime, "{y}-{m}-{d} {h}:{i}") ||
                "--"
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="隐患来源" align="left" width="120">
            <template slot-scope="scope">
              <span>{{
                formateDict(params.checkSource, scope.row.originType)
              }}</span>
            </template>
          </el-table-column>
        </template>
        <template slot="slot-row-buttons" slot-scope="scope">
          <eagle-row-button
            type="success"
            @click.prevent.stop="handleView(scope.row)"
            >详情</eagle-row-button
          >
          <eagle-row-button
            type="primary"
            v-if="
              pageType === 2 &&
              (scope.row.status == 30 || scope.row.status == 60) &&
              !isHost
            "
            @click.prevent.stop="handleUpdate(scope.row, 2)"
            >{{
              scope.row.manager || scope.row.self ? "整改/复查" : "整改"
            }}</eagle-row-button
          >
          <eagle-row-button
            type="primary"
            v-if="pageType !== 2 && scope.row.status == 30 && !isHost"
            @click.prevent.stop="handleUpdate(scope.row, 2)"
            >{{ scope.row.manager || scope.row.self ? "整改/复查" : "整改" }}
          </eagle-row-button>
          <eagle-row-button
            type="primary"
            v-if="
              (scope.row.status == 60 &&
                (scope.row.manager || isHost || scope.row.self)) ||
              (scope.row.status < 100 && scope.row.status >= 30 && isHost)
            "
            @click.prevent.stop="handleVerify(scope.row, 5)"
            >复查
          </eagle-row-button>
          <eagle-row-button
            type="danger"
            v-if="(scope.row.manager || isHost) && scope.row.status < 60"
            @click="handleDelete(scope.row)"
            >删除
          </eagle-row-button>
        </template>
      </eagle-page>

      <choose-danger-type
        ref="chooseDangerType"
        v-model="form.hiddenCode"
        @change="handleChooseDangerType"
      />
      <!-- 随手拍eg -->
      <check-task-detail ref="checkTaskDetail" @afterSave="afterSave">
      </check-task-detail>
      <check-task-verify
        ref="checkTaskVerify"
        @afterSave="search"
      ></check-task-verify>
      <check-task-view ref="checkTaskView"></check-task-view>
    </div>
  </div>
</template>
<script>
import checkTaskDetail from "@/views/ecology/components/danger/checkTask/checkTaskDetail";
import checkTaskVerify from "@/views/ecology/components/danger/checkTask/checkTaskVerify";
import checkTaskView from "@/views/ecology/components/danger/checkTask/checkTaskView";
import chooseDangerType from "@/views/components/danger/chooseDangerType";
export default {
  components: {
    chooseDangerType,
    checkTaskDetail,
    checkTaskVerify,
    checkTaskView,
  },
  name: "checkTaskList",
  data() {
    return {
      activeName: "first",
      title: "隐患",
      isEdit: false,
      showSearch: true,
      queryParams: {
        dataType: "siteList",
        month: null,
        enterpriseCode: "",
        // projectId: "",
        //correctiveUserType: null,
      },
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        originType: "=",
        status: "=",
        hiddenDangerTypeCode: "=",
        hiddenDangerDesc: "like",
        //correctiveUserType: "=",
      },
      // 查询条件
      conditionsVals: {
        status: null,
        originType: null,
        hiddenDangerTypeCode: "",
        hiddenDangerDesc: "",
      },
      controller: "ecologyEnv/dangerCheckTaskDetail", //对应后端控制器
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 标题
      title: "隐患",
      // 表单参数
      form: {},

      // 表单校验
      rules: {},
      ids: [],
      isSelf: false,
      rowShow: false,
      params: {
        checkSource: [
          { id: null, name: "不限" },
          { id: 1, name: "随手拍" },
          { id: 2, name: "依据检查" },
          { id: 3, name: "检查表检查" },
        ],
        status: [
          { id: null, name: "不限" },
          { id: 30, name: "待整改", color: "#F56C6C" },
          { id: 60, name: "已整改", color: "#E6A23C" },
          { id: 100, name: "已复查", color: "#67C23A" },
        ],
        dangerType: [],
        dangerTypeConditions: [],
        month: [
          { id: null, name: "不限" },
          { id: 1, name: "1月" },
          { id: 2, name: "2月" },
          { id: 3, name: "3月" },
          { id: 4, name: "4月" },
          { id: 5, name: "5月" },
          { id: 6, name: "6月" },
          { id: 7, name: "7月" },
          { id: 8, name: "8月" },
          { id: 9, name: "9月" },
          { id: 10, name: "10月" },
          { id: 11, name: "11月" },
          { id: 12, name: "12月" },
        ],
        correctiveType: [
          { id: 1, name: "立即整改" },
          { id: 2, name: "限时整改" },
        ],
        correctiveUserType: [
          { id: null, name: "不限" },
          { id: 1, name: "我的待整改隐患" },
          { id: 2, name: "我的待复查隐患" },
        ],
      },
      pageType: 1,
      modulesId: "",
      projectId: "",
    };
  },
  computed: {
    isHost() {
      return this.modulesId == "host";
    },
  },

  created() {
    this.modulesId = this.$route.meta.modulesId;
    this.queryParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
    this.projectId = this.$route.query.projectId ?? "";
    let routeName =
      typeof this.$route.name == "string"
        ? this.$route.name
        : this.$route.name[0];

    switch (routeName) {
      case "SiteDangerRecord": //隐患记录
        this.pageType = 1;
        this.queryParams.dataType = "siteList";
        break;
      case "HostDangerRecord": //管家的隐患记录
        this.pageType = 2;
        this.queryParams.dataType = "siteList";
        break;
      case "SiteMyDangerRecord": //我的隐患
        this.pageType = 3;
        this.queryParams.dataType = "siteMyList";
        break;
    }
    this.initData();
    setTimeout(() => {
      this.search();
    });
  },
  mounted() {
    // this.search();
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    getSuplusDate(deadline) {
      var now = new Date();
      let day = this.getDaysBetween(now, deadline);
      if (day >= 0) {
        return `<span style='color:#E6A23C'>还剩${day}天</span>`;
      } else {
        return `<span style='color:#F56C6C'>逾期${day * -1}天</span>`;
      }
    },
    getDaysBetween(date1, date2) {
      var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));
      var endDate = Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
      var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
      return days > 0 ? parseInt(days) : parseInt(days);
    },

    getCheckResultDesc(status) {
      let obj = this.params.status.find((x) => x.id === status);
      if (obj && obj.id)
        return `<span style=color:'+${obj.color}'>${obj.name}</span>`;
    },

    //初始化页面所需字典等数据
    initData() {
      let _this = this;
      _this.common.getBatechParam(
        [_this.constParams.hidden_danger_type],
        function (res) {
          _this.params.dangerType = res.data.filter(
            (p) => p.paramId === _this.constParams.hidden_danger_type
          );
          _this.params.dangerTypeConditions = res.data.filter(
            (p) => p.paramId === _this.constParams.hidden_danger_type
          );
          _this.params.dangerTypeConditions.splice(0, 0, {
            id: "",
            name: "不限",
          });
          console.log(_this.params.dangerType);
        }
      );
    },

    handleUpdate(row, type) {
      let config = { type: type };
      this.$refs.checkTaskDetail.show(row, config);
    },
    handleVerify(row) {
      this.$refs.checkTaskVerify.show(row);
    },
    handleView(row) {
      this.$refs.checkTaskView.show(row);
    },
    //查询
    search() {
      this.$refs.EaglePage.search({
        //   url: "site/dangerCheckTaskDetail/getPageList",
        // params: this.queryParams,
        conditions: this.$refs.EaglePage.getCondtions(
          this.conditionsVals,
          this.conditionsTypes
        ),
      });
    },
    handleDelete(row) {
      var _this = this;
      this.$refs.EaglePage.handleDelete(row);
    },

    //查询条件重置
    resetQuery() {
      // this.queryParams.year = new Date();

      this.queryParams.month = null;
      this.conditionsVals.status = null;
      this.conditionsVals.hiddenDangerTypeCode = "";
      this.conditionsVals.hiddenDangerDesc = "";
      this.conditionsVals.originType = null;
      this.search();
    },

    handleChooseDangerType(val, obj) {
      this.form.hiddenCode = val;
      this.form.hiddenName = obj.dFullName.replace(">", "-");
      this.model.hiddenTypeName = obj.dType == "1" ? "基础管理" : "现场管理";
      this.model.hiddenTypeCode = obj.dType;
    },
    handleRandShowHidden() {
      this.$refs.chooseDangerType.show();
    },
    goPlanDetail(code) {
      this.$router.push({
        path: "dangerCheckTask",
        query: {
          code: code,
          enterpriseCode: this.queryParams.enterpriseCode,
          projectId: this.projectId,
        },
      });
    },
    /** 导出按钮操作 */
    handleExport() {
      this.common.writeXLSXFile("隐患排查台账", "");
    },
    afterSave(res, action) {
      if (action == "edit") {
        this.$refs.EaglePage.refresh();
      } else {
        this.$refs.EaglePage.search();
      }
    },
  },
};
</script>
<style type="text/css">
/* .form-table {
    background-color: #dfe6ec;
    width: 100%;
    text-align: center;
}

.form-table tr,
.form-table th {
    border: none;
    background-color: #f8f8f9;
    height: 50px;
    line-height: 50px;
}

.form-table td {
    border: none;
    background-color: #ffffff;
    height: 50px;
    line-height: 50px;
}

.form-table .group td {
    background-color: #d2e2e870;
}
.item-title {
    text-align: left;
}

.item-title span {
    margin: 10px !important;
} */
</style>
