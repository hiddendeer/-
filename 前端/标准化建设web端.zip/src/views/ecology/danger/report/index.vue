<template>
    <div class="app-container site-danger-repoet">
        <div class="layer">
        

            <eagle-page :controller="controller" ref="EaglePage" btn-width="230px" :conditions="conditions" :showCheckColumn="false">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input label-width="80px" label="筛选条件" @changeEnter="search" :required="false" prop="planname" v-model="conditions.reportName.value" placeholder="请输入检查报告名称" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-table">
                    <el-table-column label="检查报告名称" align="left" prop="reportName" width="380" />
                    <el-table-column label="报告文件" align="left" prop="plan" width="280px">
                        <template slot-scope="scope">
                            <eagle-row-attach :isReport="true" v-model="scope.row.reportAttach"></eagle-row-attach>
                        </template>
                    </el-table-column>
                    <el-table-column label="报告类型" align="left" prop="reportTemplateName" width="140px">
                        <template slot-scope="scope">
                            {{ scope.row.reportTemplateName }}
                        </template>
                    </el-table-column>
                    <el-table-column label="报告人" align="left" prop="plan">
                        <template slot-scope="scope">
                            {{ scope.row.createChnName }}
                        </template>
                    </el-table-column>
                    <el-table-column label="报告生成日期" align="left" prop="plan" width="180px">
                        <template slot-scope="scope">
                            {{ scope.row.createDate|dataFormat }}
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="danger" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
                    <eagle-row-button type="primary" @click.prevent.stop="downLoad(scope.row, '.docx')">word报告
                    </eagle-row-button>
                    <eagle-row-button type="warning" @click.prevent.stop="downLoad(scope.row, '.pdf')">pdf报告
                    </eagle-row-button>
                </template>
            </eagle-page>
        </div>
    </div>

</template>
<script>
export default {
    name: "site-danger-repoet",
    data() {
        return {
            model: {},
            showSearch: false,
            controller: "ecologyEnv/dangerReport", //对应后端控制器
            enterpriseCode: "",
            projectId: "",
            conditions: {
                reportName: { value: "" },
            },
        };
    },
    created() {
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";
        setTimeout(() => {
            this.search();
        });
    },
    mounted() {},
    methods: {
        search() {
            this.$refs.EaglePage.search({
                params: {
                    dataType: "list",
                    enterpriseCode: this.companyCode,
                    // projectId: this.projectId,
                },
            });
        },
        resetQuery() {
            this.conditions.reportName.value = "";
            this.search();
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, () => {
                _this.search();
            });
        },
        downLoad(item, type) {
            let jsostr = [];
            if (item.reportAttach) {
                jsostr = JSON.parse(item.reportAttach);
            }
            var _this = this;
            this.http
                .get("/file/getDataByAttCode/" + jsostr[0].attCode)
                .then((res) => {
                    if (res.code == 200) {
                        const a = document.createElement("a");
                        var url =
                            type == ".pdf"
                                ? res.data.attMiddlePath
                                : res.data.attFilePath;
                        fetch(url)
                            .then((res) => res.blob())
                            .then((blob) => {
                                a.href = URL.createObjectURL(blob);
                                a.download = res.data.attName + type; // 下载文件的名字
                                document.body.appendChild(a);
                                a.click();
                            });
                    }
                });
        },
    },
};
</script>
<style  lang="scss">
.check-task-list-v2 {
    .transition-box {
        display: flex;
        margin-bottom: 10px;
        width: 200px;
        height: 100px;
        border-radius: 4px;
        background-color: #409eff;
        text-align: center;
        color: #fff;
        padding: 20px 20px;
        box-sizing: border-box;
        margin-right: 20px;

        i {
            font-size: 50px;
        }

        .content {
            display: block;
        }

        .num {
            font-size: 35px;
            font-weight: 600;
        }
    }

    .transition-box.primary {
        background-color: #409eff;
    }

    .transition-box.danger {
        background-color: #f56c6c;
    }

    .transition-box.info {
        background-color: #909399;
    }

    .transition-box.success {
        background-color: #67c23a;
    }

    .transition-box.total {
        background-color: #e6a23c;
    }
}
</style>
 