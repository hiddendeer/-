<template>
    <div class="app-container">
        <div class="layer">
            <template>
                <el-tabs v-model="activeName" @tab-click="handleClick">
                    <el-tab-pane label="普通检查计划" name="first">
                        <eagle-page :controller="controller" ref="EaglePage" btn-width="220px" :countHeight="countHeight">
                            <template slot="slot-search">
                                <eagle-condition @search="search()" :showReset="false">
                                    <eagle-date label-width="50px" :clearable="false" label="年度" type="year" format="yyyy" @change="search" v-model="buildModel.year"></eagle-date>
                                </eagle-condition>
                            </template>
                            <template slot="slot-buttons">
                                <el-button type="primary" icon="el-icon-plus" size="mini" @click="handleAdd">
                                    新增检查任务</el-button>
                                <el-button icon="el-icon-download" size="mini" type="primary" @click="handleExport">导出
                                </el-button>
                                <eagle-more-button type="primary" size="small">
                                    <el-dropdown-item command="mouth" type="primary" icon="el-icon-plus" @click.native="buildTask(1)">按月度生成任务</el-dropdown-item>
                                    <el-dropdown-item command="quarter" type="primary" icon="el-icon-plus" @click.native="buildTask(2)">按季度生成任务</el-dropdown-item>
                                    <el-dropdown-item command="halfYear" type="primary" icon="el-icon-plus" @click.native="buildTask(3)">按半年度生成任务</el-dropdown-item>
                                    <el-dropdown-item command="batchBuidReport" type="danger" icon="el-icon-collection" @click.native="batchBuidReport">合并生成检查报告</el-dropdown-item>
                                    <el-dropdown-item command="deleteAll" type="danger" icon="el-icon-delete" @click.native="batchDel">批量删除</el-dropdown-item>
                                </eagle-more-button>
                            </template>
                            <template slot="slot-table">
                                <el-table-column label="检查计划" align="left" prop="checkTaskName" min-width="200" />
                                <el-table-column label="检查表" align="left" prop="plan" width="200">
                                    <template slot-scope="scope">
                                        <eagle-row-button size="mini" v-if="scope.row.status == 10" type="text" @click="handleChooseLibTemplateShow('set', scope.row)">检查报表<span v-if="scope.row.relations">({{ scope.row.relations.length }})</span>
                                        </eagle-row-button>
                                        <div v-else-if="scope.row.relations && scope.row.relations.length > 0" v-for="(item, index) in scope.row.relations" :key="index">
                                            {{ item.templateName }}
                                        </div>
                                    </template>
                                </el-table-column>
                                <el-table-column label="检查类型" align="left" prop="checkType" width="180">
                                    <template slot-scope="scope">
                                        <span>{{ formateDict(params.dangerCheckTaskType, scope.row.checkType) }}</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="隐患及整改情况" align="left" prop="plan" width="200">
                                    <template slot-scope="scope">
                                        {{ scope.row.rectifyNum }}/{{ scope.row.totalNum }}
                                    </template>
                                </el-table-column>
                                <el-table-column label="状态" align="left" width="80">
                                    <template slot-scope="scope"><span v-html="formateStatus(params.status, scope.row.serviceStatus)"></span></template>
                                </el-table-column>
                                <el-table-column label="检查报告" align="left" width="230px">
                                    <template slot-scope="scope">
                                        <div style="display: flex; justify-content: space-between">
                                            <eagle-row-attach :isReport="true" v-model="scope.row.checkAttachs">
                                            </eagle-row-attach>
                                        </div>
                                    </template>
                                </el-table-column>
                                <el-table-column label="任务时间" align="left" prop="plan" width="200">
                                    <template slot-scope="scope">
                                        {{ parseTime(scope.row.startDate, "{y}-{m}-{d}") }} ~
                                        {{ parseTime(scope.row.endDate, "{y}-{m}-{d}") }}
                                    </template>
                                </el-table-column>
                                <el-table-column label="检查人" align="left" prop="plan" width="100">
                                    <template slot-scope="scope">
                                        {{ scope.row.checkPersonChName }}
                                    </template>
                                </el-table-column>
                                <el-table-column label="检查日期" align="left" prop="plan" width="180">
                                    <template slot-scope="scope">
                                        {{ scope.row.submitDate }}
                                    </template>
                                </el-table-column>
                            </template>
                            <template slot="slot-row-buttons" slot-scope="scope">
                                <eagle-row-button type="danger" v-if="scope.row.manager || modulesId == 'host' || (scope.row.status == 10 && scope.row.self)" @click.prevent.stop="handleDelete(scope.row)">删除
                                </eagle-row-button>
                                <eagle-row-button type="primary" v-if="scope.row.status < 100" @click="handleUpdate(scope.row)">编辑</eagle-row-button>
                                <eagle-row-button type="primary" v-if="scope.row.status == 100" @click="buildReport(scope.row)">生成报告</eagle-row-button>
                                <eagle-row-button type="success" v-if="scope.row.status == 10" @click="goPlanDetail(scope.row.code)">实施</eagle-row-button>
                                <eagle-row-button type="success" v-if="scope.row.status != 10" @click="goPlanDetail(scope.row.code)">详情</eagle-row-button>
                            </template>
                        </eagle-page>
                    </el-tab-pane>
                    <el-tab-pane v-if="modulesId == 'site'" label="风险管控排查" name="second">
                        <eagle-page :conditions="conditions" :controller="controller" :showCheckColumn="false" ref="EaglePage2" btn-width="190px" :countHeight="countHeight">
                            <template slot="slot-search">
                                <eagle-condition @search="search()" :showReset="false">
                                    <eagle-date label-width="50px" :clearable="false" label="年度" type="year" format="yyyy" @change="search" v-model="conditions.year.value"></eagle-date>
                                </eagle-condition>
                            </template>
                            <template slot="slot-table">
                                <el-table-column label="检查计划" align="left" prop="checkTaskName" min-width="200" />
                                <el-table-column label="隐患及整改情况" align="left" prop="plan" width="200">
                                    <template slot-scope="scope">
                                        {{ scope.row.correctiveCnt }}/{{ scope.row.hiddenDangerCnt }}
                                    </template>
                                </el-table-column>
                                <el-table-column label="状态" align="left" width="80">
                                    <template slot-scope="scope"><span v-html="formateStatus(params.taskstatus, scope.row.status)"></span></template>
                                </el-table-column>
                                <el-table-column label="检查人" align="left" prop="plan" width="100">
                                    <template slot-scope="scope">
                                        {{ scope.row.checkPersonChName }}
                                    </template>
                                </el-table-column>
                            </template>
                            <template slot="slot-row-buttons" slot-scope="scope">
                                <eagle-row-button type="primary" v-if="scope.row.status == 100" @click="buildReportPoint(scope.row)">生成报告</eagle-row-button>
                                <eagle-row-button type="danger" v-if="currentUser.manager || (scope.row.status == 10 && scope.row.checkPersonName.indexOf(currentUser.userName) > -1)" @click.prevent.stop="handleDelete(scope.row)">删除
                                </eagle-row-button>
                                <eagle-row-button type="success" v-if="scope.row.status == 10" @click="goPlanDetailRisk(scope.row.code)">实施</eagle-row-button>
                                <eagle-row-button type="success" v-if="scope.row.status != 10" @click="goPlanDetailRisk(scope.row.code)">详情</eagle-row-button>
                            </template>
                        </eagle-page>
                    </el-tab-pane>
                </el-tabs>
            </template>
            <eagle-form saveFun="saveEntity" @afterSave="afterSave" :controller="controller" title="检查任务" :form="model" width="800px" label-width="120px" ref="EagleForm" @bindData="bindData">
                <eagle-block border>

                    <eagle-select label="检查类型" prop="checkType" :data-source="params.dangerCheckTaskType" required v-model="model.checkType" @change="changType" />
                    <eagle-input label="任务名称" prop="checkTaskName" required v-model="model.checkTaskName" />
                    <eagle-picker-range label-width="120px" type="daterange" format="yyyy-MM-dd" prop="datetimes" v-model="model.datetimes" label="起始时间" required @change="changeDatetimes" />
                    <eagle-choose-user label-width="120px" label="检查人" prop="checkPersonName" :single="false" :names.sync="model.checkPersonChName" v-model="model.checkPersonName" required />

                    <el-form-item label="检查表">
                        <el-button size="mini" type="primary" @click.prevent.stop="handleChooseLibTemplateShow('add', {})">选择检查表</el-button>
                        <div>
                            <ul class="temp">
                                <li class="temp-item" v-for="(item, index) in model.relations" :key="index" tabindex="0">
                                    <span class="temp-item-name"><i class="el-icon-document"></i>
                                        {{ item.templateName }}</span>
                                    <el-button size="mini" type="text" class="el-icon-delete" @click.prevent.stop="deleteTemp(index)" />
                                </li>
                            </ul>
                        </div>
                    </el-form-item>

                </eagle-block>
            </eagle-form>
            <choose-lib-template ref="chooseLibTemplate" @change="handleChooseLibTemplate" />
            <buildDangerReport ref="buildDangerReport" @afterSave="showReport" />
            <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>
        </div>
    </div>
</template>
<script>
import chooseLibTemplate from "@/views/ecologySupport/public/chooseLibTemplate.vue";
import buildDangerReport from "@/views/ecology/danger/components/buildDangerReport";
import { getCurrentUser } from "@/utils/auth";
import EagleMoreButton from "@/components/Eagle/eagle-more-button.vue";
export default {
    components: {
        chooseLibTemplate,
        EagleMoreButton,
        buildDangerReport,
    },
    name: "dangerTaskList",
    data() {
        return {
            model: {},
            isEdit: false,
            showSearch: true,
            statisticsModel: {},
            chooseItem: {},
            controller: "ecologyEnv/dangerCheckTask", //对应后端控制器
            buildModel: {
                year: "",
            },
            params: {
                dangerCheckTaskType: [],
                cycleType: [
                    { id: "1", name: "月度" },
                    { id: "2", name: "季度" },
                    { id: "3", name: "半年度" },
                ],
                status: [
                    { id: 1, name: "待实施", color: "#909399" },
                    { id: 2, name: "进行中", color: "#409EFF" },
                    { id: 3, name: "已逾期", color: "#E6A23C" },
                    { id: 4, name: "已完成", color: "#67C23A" },
                ],
                taskstatus: [
                    { id: 10, name: "进行中", color: "#409EFF" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
            chooseType: "",
            enterpriseCode: "",
            projectId: "",
            activeName: "first",
            modulesId: "",
            currentUser: {},
            conditions: {
                year: {
                    value: "",
                },
            },
            countHeight: 90,
        };
    },
    created() {
        if (this.$route.query.activeName) {
            this.activeName = this.$route.query.activeName;
        }
        this.modulesId = this.$route.meta.modulesId;
        if (this.modulesId == "host") {
            this.countHeight = 218;
        }
        var date = new Date();
        this.buildModel.year = date.getFullYear().toString();
        this.conditions.year.value = date.getFullYear().toString();
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";
        this.currentUser = getCurrentUser();
        this.initData();
    },
    mounted() {
        this.refreshPage();
    },
    methods: {
        handleExport() {
            this.common.handleExport(
                this.loading(),
                "F00021",
                this.buildModel.year,
                this.enterpriseCode
            );
        },
        showReport(params) {
            this.search();
            this.$refs.PdfDialog.show(params);
            this.getModel();
        },
        // resetQuery2() {
        //     var date = new Date();
        //     this.conditions.year = date.getFullYear().toString();
        //     this.search();
        // },
        handleClick(tab, event) {
            // console.log(tab, event);
            this.search();
        },
        afterSave(res) {
            this.goPlanDetail(res.data.code);
        },
        changType() {
            let _this = this;
            this.model.checkTypeName = this.formateDict(
                this.params.dangerCheckTaskType,
                this.model.checkType
            );
            // this.$confirm("是否被覆盖任务名称?", "警告", {
            //     confirmButtonText: "确定",
            //     cancelButtonText: "取消",
            //     type: "warning",
            // }).then(function (res) {
            //     _this.model.checkTaskName = `${_this.model.createChnName}_检查任务${_this.getDateStr()}`
            // });
        },
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.danger_plan_check_type],
                function (res) {
                    _this.params.dangerCheckTaskType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.danger_plan_check_type
                    );
                }
            );
        },
        batchDel() {
            var _this = this;
            let array = this.$refs.EaglePage.selection;
            if (!array || array.length <= 0) {
                _this.msgError("请先选择需要删除的检查任务");
                return;
            }
            let ids = array.map((x) => x.id);
            this.$refs.EaglePage.handleMultDelete(ids);
        },
        batchBuidReport() {
            let _this = this;
            let array = this.$refs.EaglePage.selection;
            if (!array || array.length <= 0) {
                _this.msgError("请先选择需要合并生成报告的检查任务");
                return;
            }
            if (array.findIndex((x) => x.status == 10) >= 0) {
                _this.msgError("选择了未结束的检查任务");
                return;
            }
            let codes = array.map((x) => x.code).join(",");
            let checkTaskNames = array.map((x) => x.checkTaskName).join(",");
            _this.$refs.buildDangerReport.show({
                taskCodes: codes,
                taskNames: checkTaskNames,
                enterpriseCode: _this.enterpriseCode,
                projectId: _this.projectId,
                singer: false,
            });
        },
        buildReport(item) {
            let _this = this;
            _this.$refs.buildDangerReport.show({
                taskCodes: item.code,
                taskNames: item.checkTaskName,
                enterpriseCode: item.enterpriseCode,
                projectId: item.projectId,
                singer: true,
            });
        },
        buildReportPoint(item) {
            let _this = this;
            _this.$refs.buildDangerReport.show({
                taskCodes: item.code,
                taskNames: item.checkTaskName,
                enterpriseCode: _this.enterpriseCode,
                projectId: item.projectId,
                singer: true,
            });
        },
        refreshPage() {
            this.search();
            // this.getStatisticsNums();
        },
        goPlanDetail(code) {
            this.$router.push({
                nanme: "DangerCheckTask",
                query: {
                    code: code,
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });
        },
        goPlanDetailRisk(code) {
            let _this = this;
            this.http
                .get("ecologyEnv/dangerCheckTask/getDataByCode/" + code)
                .then((res) => {
                    let data = res.data;
                    if (data && data.relations && data.relations.length > 0) {
                        var relations = data.relations[0].checkTemplateCode;
                        _this.$router.push({
                            name: "SiteDangerTemplateCheck",
                            query: {
                                taskCode: data.code,
                                templateCode: relations,
                                isEdit: data.status == 10 ? 1 : 2,
                                isFromDanger: "1",
                                enterpriseCode:
                                    data.enterpriseCode || data.companyCode,
                                projectId:
                                    data.sourceType == "project"
                                        ? data.projectId
                                        : "",
                            },
                        });
                    }
                });
        },
        changeDatetimes(data) {
            this.model.startDate = data[0];
            this.model.endDate = data[1];
        },
        deleteTemp(index) {
            this.model.relations.splice(index, 1);
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        bindData(data) {
            this.model = data;
            let datetimes = [];
            if (this.model) {
                datetimes.push(this.model.startDate);
                datetimes.push(this.model.endDate);
            }
            this.$set(this.model, "datetimes", datetimes);
            this.model.projectId = this.projectId;
            this.model.enterpriseCode = this.enterpriseCode;

            console.log(data);

            if (!data.id || data.id === "0") {
                this.model.checkType = this.params.dangerCheckTaskType[0].id;
                this.model.checkTypeName =
                    this.params.dangerCheckTaskType[0].name;
                this.model.checkTaskName = `${
                    this.model.createChnName
                }_检查任务${this.getDateStr()}`;
            }
        },
        getDateStr() {
            var date = new Date();
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();
            return `${year}${month > 9 ? month : "0" + month}${day}`;
        },
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        handleChooseLibTemplateShow(chooseType, item) {
            this.chooseType = chooseType;
            let array = [];
            if (chooseType == "set") {
                this.chooseItem = item;
                if (
                    this.chooseItem.relations &&
                    this.chooseItem.relations.length > 0
                )
                    this.chooseItem.relations.forEach((x) => {
                        array.push({
                            tCode: x.checkTemplateCode,
                            title: x.templateName,
                        });
                    });
            }
            if (chooseType == "add") {
                if (this.model.relations && this.model.relations.length > 0)
                    this.model.relations.forEach((x) => {
                        array.push({
                            tCode: x.checkTemplateCode,
                            title: x.templateName,
                        });
                    });
            }

            this.$refs.chooseLibTemplate.show(array);
        },

        handleChooseLibTemplate(array) {
            var _this = this;

            let relationArray = [];
            if (array && array.length > 0) {
                array.forEach((x) => {
                    relationArray.push({
                        checkTemplateCode: x.tCode,
                        templateName: x.title,
                        checkTaskCode: _this.chooseItem.code,
                    });
                });
            }
            if (this.chooseType == "set") {
                let url = `${_this.controller}/setRelation/${_this.chooseItem.code}?enterpriseCode=${this.enterpriseCode}`;
                // _this.http.post(url, relationArray).then((res) => {
                //     this.refreshPage();
                // });

                _this.http.postLoading(
                    _this.loading(),
                    url,
                    relationArray,
                    function (res) {
                        _this.refreshPage();
                    }
                );
            }
            if (this.chooseType == "add") {
                _this.model.relations = relationArray;
            }
        },
        getStatisticsNums() {
            let _this = this;
            let url = `${_this.controller}/getStatisticsNums?enterpriseCode=${this.enterpriseCode}&projectId=${this.projectId}`;
            _this.http.get(url).then((res) => {
                _this.statisticsModel = res.data;
            });
        },
        buildTask(op) {
            let _this = this;
            var title = "";
            switch (op) {
                case 1:
                    title = "月度任务";
                    break;
                case 2:
                    title = "季度任务";
                    break;
                case 3:
                    title = "半年度任务";
                    break;
            }
            this.$confirm(
                "确定生成" + _this.buildModel.year + "年的【" + title + "】吗?",
                "警告",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            ).then(function (res) {
                if (_this.buildModel.year) {
                    let url = `${_this.controller}/buildTask/${_this.buildModel.year}/${op}?enterpriseCode=${_this.enterpriseCode}&projectId=${_this.projectId}`;
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {
                            checkType: _this.params.dangerCheckTaskType[0].id,
                            checkTypeName:
                                _this.params.dangerCheckTaskType[0].name,
                        },
                        function (res) {
                            _this.refreshPage();
                        }
                    );
                }
            });
        },
        search() {
            if (this.activeName == "first") {
                this.$refs.EaglePage.search({
                    params: {
                        dataType: "list",
                        year: this.buildModel.year,
                        enterpriseCode: this.enterpriseCode,
                        // projectId: this.projectId,
                    },
                });
            } else {
                this.$refs.EaglePage2.search({
                    params: {
                        dataType: "riskCorrectiveDetailList",
                        year: this.buildModel.year,
                        enterpriseCode: this.enterpriseCode,
                        // projectId: this.projectId,
                    },
                });
            }
        },

        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, () => {
                _this.refreshPage();
            });
        },

        goPlanDetail(code) {
            this.$router.push({
                name: "DangerCheckTask",
                query: {
                    code: code,
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });

            // this.$router.push({
            //     path: "dangerCheckTask",
            //     query: {
            //         code: code,
            //     },
            // });
        },
    },
};
</script>
<style  lang="scss" scoped>
.check-task-list-v2 {
    .transition-box {
        display: flex;
        margin-bottom: 10px;
        width: 200px;
        height: 100px;
        border-radius: 4px;
        background-color: #409eff;
        text-align: center;
        color: #fff;
        padding: 20px 20px;
        box-sizing: border-box;
        margin-right: 20px;

        i {
            font-size: 50px;
        }

        .content {
            display: block;
        }

        .num {
            font-size: 35px;
            font-weight: 600;
        }
    }

    .transition-box.primary {
        background-color: #409eff;
    }

    .transition-box.danger {
        background-color: #f56c6c;
    }

    .transition-box.info {
        background-color: #909399;
    }

    .transition-box.success {
        background-color: #67c23a;
    }

    .transition-box.total {
        background-color: #e6a23c;
    }
}
</style>
 