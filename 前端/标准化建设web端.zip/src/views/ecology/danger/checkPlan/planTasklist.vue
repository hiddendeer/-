<template name="SiteDangerCheckTask">
    <div class="app-container">

        <el-card class="box-card">
            <div slot="header" class="clearfix">
                <span>隐患排查计划详情</span>
            </div>
            <div>
                <el-form :model="model">
                    <el-col :span="8">
                        <el-form-item prop="name" label="计划名称">
                            <span>
                                {{ model.name }}
                            </span>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item prop="checkPersonChName" label="检查负责人">
                            <span>{{ model.checkPersonChName }}</span>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item prop="checkTypeCode" label="检查类型">
                            <span>{{ formateDict(params.dangerCheckTaskType, model.checkTypeCode) }}</span>
                        </el-form-item>
                    </el-col>

                    <el-col :span="24">
                        <el-form-item prop="checkRequirement" label="检查要求">
                            <span>{{ model.checkRequirement }}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16">
                        <el-form-item label="检查表">
                            <el-link type="primary" v-for="(item, index) in model.templates" :key="index"
                                style="margin-right:10px" @click="hdShowTemplate(item)">{{ item.templateName }}
                            </el-link>

                        </el-form-item>
                    </el-col>
                </el-form>
            </div>
        </el-card>

        <el-card class="box-card">
            <div slot="header" class="clearfix">
                <span>历次检查实施隐患表</span>
            </div>
            <div>
                <eagle-page ref="EaglePage" controller="ecologyEnv/dangerCheckTaskDetail" :showCheckColumn="false">
                    <template slot="slot-table">
                        <el-table-column label="检查名称" align="left" prop="checkTaskName" />
                        <el-table-column label="检查人" align="left" prop="createChnName" />
                        <el-table-column label="检查实施日期" align="left" prop="">
                            <template slot-scope="scope">
                                {{ formatDate(scope.row.createDate, "yyyy-MM-dd") }}
                            </template>
                        </el-table-column>

                        <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" width="200" />
                        <el-table-column label="隐患图片" align="left" prop="attachs" width="300">
                            <template slot-scope="scope">
                                <eagle-row-image v-model="scope.row.attachs" />
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患来源" align="left" width="120">
                            <template slot-scope="scope">
                                <span>{{ formateDict(params.checkSource, scope.row.originType) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患性质" align="left">
                            <template slot-scope="scope">
                                <span>{{ formateDict(params.dangerType, scope.row.hiddenDangerTypeCode) }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="检查人" align="left" prop="createChnName" width="120" />
                        <el-table-column label="检查时间" align="left" prop="createDate" width="140">
                            <template slot-scope="scope">
                                <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d} {h}:{i}") }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="整改期限" align="left" prop="createDate" width="100">
                            <template slot-scope="scope">
                                <span>{{ parseTime(scope.row.correctiveDeadline, "{y}-{m}-{d}") || "--" }}</span>
                                <div v-if="scope.row.correctiveDeadline && scope.row.status == 30"
                                    v-html="getSuplusDate(scope.row.correctiveDeadline)">
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患状态" align="left" prop="createDate" width="80">
                            <template slot-scope="scope">
                                <span v-html="getCheckStatusDesc(scope.row.status)"></span>
                            </template>
                        </el-table-column>
                        <el-table-column label="整改后图片" align="left" prop="attachs" width="300">
                            <template slot-scope="scope">
                                <eagle-row-image v-model="scope.row.correctiveAttachs" />
                            </template>
                        </el-table-column>
                        <el-table-column label="复查人" align="left" prop="attachs" width="120">
                            <template slot-scope="scope">
                                {{ scope.row.correctiveUserChName || "--" }}
                            </template>
                        </el-table-column>
                        <el-table-column label="复查时间" align="left" prop="correctiveTime" width="140">
                            <template slot-scope="scope">
                                <span>{{ parseTime(scope.row.correctiveTime, "{y}-{m}-{d} {h}:{i}") || "--" }}</span>
                            </template>
                        </el-table-column>
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <!-- <eagle-row-button type="primary" icon="el-icon-edit" v-if="scope.row.status!=100" @click.prevent.stop="handleUpdate(scope.row,2)">{{scope.row.self?"整改/复查":"整改"}}</eagle-row-button>
                        <eagle-row-button type="primary" icon="el-icon-view" @click.prevent.stop="handleUpdate(scope.row,0)">详情</eagle-row-button>
                        <eagle-row-button type="danger" v-if="scope.row.self" icon="el-icon-view" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button> -->

                        <eagle-row-button type="success" @click="handleUpdate(scope.row, 0)">详情</eagle-row-button>
                        <eagle-row-button type="primary" v-if="scope.row.status == 10"
                            @click="handleUpdate(scope.row, 1)">编辑</eagle-row-button>
                        <eagle-row-button type="primary" v-if="scope.row.status == 30 || scope.row.status == 60"
                            @click.prevent.stop="handleUpdate(scope.row, 2)">{{ modulesId == 'host' || scope.row.self ?
        "
                            整改/ 复查":"整改"}}</eagle-row-button>
                        <eagle-row-button type="danger"
                            v-if="scope.row.manager || modulesId == 'host' || (scope.row.self && scope.row.status == 10)"
                            @click="handleDelete(scope.row)">删除</eagle-row-button>

                    </template>
                </eagle-page>
            </div>
        </el-card>
        <check-task-detail ref="checkTaskDetail" @afterSave="search"> </check-task-detail>

        <danger-template-detail ref="dangerTemplateDetail" />
    </div>
</template>
<script>
/**
 * created() 调用初始化方法
 * mounted() 调用查询方法
 **/
//import chooseDangerType from "@/views/components/danger/chooseDangerType";

import dangerTemplateDetail from "@/views/ecology/components/danger/template/dangerTemplateDetail";
import checkTaskDetail from "@/views/ecology/components/danger/checkTask/checkTaskDetail";
export default {
    components: {
        "check-task-detail": checkTaskDetail,
        "danger-template-detail": dangerTemplateDetail,
    },
    // components: { chooseDangerType },
    data() {
        return {
            code: this.$route.query.code,
            model: {},
            planController: "ecologyEnv/dangerCheckPlan",
            taskController: "ecologyEnv/dangerCheckTask",
            queryParams: {
                cpCode: this.$route.query.code,
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {},
            form: {},
            isEdit: false,
            // 查询条件
            conditionsVals: {},
            taskStatusArray: [
                { value: 1, text: "进行中", color: "#F56C6C" },
                { value: 10, text: "已结束", color: "#67C23A" },
            ],
            modulesId: "",
            params: {
                dangerCheckTaskType: [],
                opType: [],
                dangerType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkResult: [
                    { id: "Y", name: "符合", color: "#67C23A" },
                    { id: "N", name: "不符合", color: "#F56C6C" },
                    { id: "NA", name: "不适用", color: "#E6A23C" },
                ],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
                status: [
                    { id: 100, name: "已复查", color: "#67C23A" },
                    { id: 60, name: "已整改", color: "#409EFF" },
                    { id: 30, name: "待整改", color: "#F56C6C" },
                    { id: 10, name: "待提交", color: "#E6A23C" },
                    { id: 0, name: "待提交", color: "#F56C6C" },
                ],
            },
        };
    },
    created() {
        this.modulesId = this.$route.meta.modulesId;
        this.initData();
        this.bindData();
    },

    methods: {
        hdShowTemplate(item) {
            this.$refs.dangerTemplateDetail.show({ code: item.templateCode });
        },
        getSuplusDate(deadline) {
            var now = new Date();
            let day = this.getDaysBetween(now, deadline);
            if (day >= 0) {
                return `<span style='color:#E6A23C'>还剩${day}天</span>`;
            } else {
                return `<span style='color:#F56C6C'>逾期${day * -1}天</span>`;
            }
        },
        getDaysBetween(date1, date2) {
            var startDate = Date.parse(this.formatDate(date1, "yyyy-MM-dd"));

            var endDate = Date.parse(this.formatDate(date2, "yyyy-MM-dd"));
            var days = (endDate - startDate) / (1 * 24 * 60 * 60 * 1000);
            return days > 0 ? parseInt(days) : parseInt(days);
        },
        submitForm() {
            this.$refs.EagleForm.submitForm();
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.hidden_danger_type,
                    _this.constParams.danger_plan_check_type,
                ],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                    _this.params.dangerCheckTaskType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.danger_plan_check_type
                    );
                }
            );
        },

        getCheckResultDesc(checkResult) {
            console.log(checkResult);
            let obj = this.params.checkResult.find((x) => x.id === checkResult);
            if (obj && obj.id)
                return (
                    "<span style='color:" +
                    obj.color +
                    "'>" +
                    obj.name +
                    "</span>"
                );
        },
        getCheckStatusDesc(status) {
            let obj = this.params.status.find((x) => x.id === status);
            if (obj && obj.id)
                return (
                    "<span style='color:" +
                    obj.color +
                    "'>" +
                    obj.name +
                    "</span>"
                );
        },
        bindData() {
            let _this = this;
            _this.http
                .get(`${_this.planController}/getDataByCode/${_this.code}`)
                .then((res) => {
                    _this.model = res.data;
                    _this.queryParams.cpCode = this.model.code;
                    _this.search();
                });
        },
        bindDataDetail(data) {
            this.form = data;
        },
        cancel(data) {
            this.$refs.EagleForm.cancel();
        },
        search() {
            let _this = this;
            _this.$refs.EaglePage.search({
                url: `${_this.planController}/getTaskDetailPageList`,
                params: _this.queryParams,
                conditions: _this.$refs.EaglePage.getCondtions(
                    _this.conditionsVals,
                    _this.conditionsTypes
                ),
            });
        },

        handleChooseDangerType(val, obj) {
            this.form.hiddenCode = val;
            this.form.hiddenName = obj.dFullName.replace(">", "-");
            this.model.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.model.hiddenTypeCode = obj.dType;
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row);
        },
        /** 修改按钮操作 */
        handleUpdate(row, type) {
            let config = { type: type };
            this.$refs.checkTaskDetail.show(row, config);
        },

        randVolid() {
            return true;
        },
    },
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0 20px 20px 20px;
}
</style>
<style lang="scss">
.template-list {
    max-height: 600px;
    overflow-y: auto;
}

.eagle-table {
    font-family: verdana, arial, sans-serif;
    font-size: 11px;
    color: #333333;
    border-width: 1px;
    border-color: #666666;
    border-collapse: collapse;

    th {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #dedede;
    }

    td {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #ffffff;
    }
}
</style>