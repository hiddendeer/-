<template name="SiteDangerCheckTask">
    <div class="app-container">

        <el-card class="box-card">
            <div slot="header" class="clearfix">
                <span>检查计划详情</span>
            </div>
            <div>
                <el-form :model="model">
                    <el-col :span="8">
                        <el-form-item prop="checkTaskName" label="检查计划名称">
                            <span>
                                {{model.name}}
                            </span>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item prop="createDate" label="检查负责人">
                            <span>{{model.checkPersonChName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="createDate" label="检查类型">
                            <span>{{formateDict(params.dangerCheckTaskType,model.checkTypeCode) }}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-form-item prop="createDate" label="检查要求">
                            <span>{{model.checkRequirement}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16">
                        <el-form-item prop="createDate" label="检查表">
                            <el-link type="primary" v-for="(item,index) in model.templates" :key="index" style="margin-right:10px" @click="hdShowTemplate(item)">{{item.templateName}}</el-link>
                        </el-form-item>
                    </el-col>
                </el-form>
            </div>
        </el-card>

        <el-card class="box-card">
            <div slot="header" class="clearfix">
                <span>历次检查实施情况一览表</span>
            </div>
            <div>
                <eagle-page ref="EaglePage" :showCheckColumn="false" :controller="taskController">
                    <template slot="slot-table">
                        <el-table-column label="检查名称" align="left" prop="checkTaskName" />

                        <el-table-column label="检查人" align="left" prop="createChnName" />
                        <el-table-column label="检查实施日期" align="left" prop="">
                            <template slot-scope="scope">
                                {{ formatDate(scope.row.createDate, "yyyy-MM-dd") }}
                            </template>
                        </el-table-column>
                        <el-table-column label="任务状态" align="left" prop="checkPersonChName">
                            <template slot-scope="scope">
                                <span v-if="scope.row.status===10" style="color:#F56C6C">进行中</span>
                                <span v-if="scope.row.status!==10" style="color:#67C23A">已结束</span>

                            </template>
                        </el-table-column>

                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button type="primary" icon="el-icon-edit" @click.prevent.stop="handleUpdate(scope.row)" v-if=" scope.row.self && scope.row.status===10">继续检查</eagle-row-button>
                        <eagle-row-button  type="success"  icon="el-icon-view" @click.prevent.stop="handShowView(scope.row)">详情</eagle-row-button>
                        <eagle-row-button type="danger" v-if="scope.row.self &&  scope.row.status===10" icon="el-icon-view" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
                    </template>
                </eagle-page>
            </div>
        </el-card>

        <dangerTemplateDetail ref="dangerTemplateDetail" />
    </div>
</template>
<script>
/**
 * createdd() 调用初始化方法
 * mounted() 调用查询方法
 **/

import dangerTemplateDetail from "@/views/ecology/components/danger/template/dangerTemplateDetail";
export default {
    components: { dangerTemplateDetail },
    name: "siteDangerCheckPlanView",
    data() {
        return {
            code: this.$route.query.code,
            model: {},
            planController: "ecologyEnv/dangerCheckPlan",
            taskController: "ecologyEnv/dangerCheckTask",
            queryParams: {
                dataType: "list"
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                cpCode: "="
            },
            // 查询条件
            conditionsVals: {
                cpCode: ""
            },
            taskStatusArray: [
                { value: 1, text: "进行中", color: "#F56C6C" },
                { value: 10, text: "已结束", color: "#67C23A" }
            ],
            params: { dangerCheckTaskType: [] }
        };
    },
    created() {
        this.initData();
        this.bindData();
    },

    methods: {
        hdShowTemplate(item) {
            console.log(item);
            this.$refs.dangerTemplateDetail.show({ code: item.templateCode });
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.danger_plan_check_type],
                function(res) {
                    _this.params.dangerCheckTaskType = res.data.filter(
                        p =>
                            p.paramId ===
                            _this.constParams.danger_plan_check_type
                    );
                }
            );
        },
        bindData() {
            let _this = this;
            _this.http
                .get(`${_this.planController}/getDataByCode/${_this.code}`)
                .then(res => {
                    _this.model = res.data;
                    _this.conditionsVals.cpCode = this.model.code;
                    _this.search();
                });
        },
        handleUpdate(row) {
            let _this = this;
            _this.$router.push({
                path: "dangerCheckTask",
                query: {
                    op: "e",
                    code: row.code
                }
            });
        },
        handShowView(row) {
            let _this = this;
            _this.$router.push({
                path: "dangerCheckTask",
                query: {
                    op: "v",
                    code: row.code
                }
            });
        },
        search() {
            let _this = this;
            _this.$refs.EaglePage.search({
                url: `${_this.taskController}/getPageData`,
                params: _this.queryParams,
                conditions: _this.$refs.EaglePage.getCondtions(
                    _this.conditionsVals,
                    _this.conditionsTypes
                )
            });
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row);
        }
    }
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0 20px 20px 20px;
}
</style>
<style lang="scss">
.template-list {
    max-height: 600px;
    overflow-y: auto;
}
.eagle-table {
    font-family: verdana, arial, sans-serif;
    font-size: 11px;
    color: #333333;
    border-width: 1px;
    border-color: #666666;
    border-collapse: collapse;

    th {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #dedede;
    }
    td {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #666666;
        background-color: #ffffff;
    }
}
</style>