<template>
    <div class="app-container">
        <div class="layer">
            <fireEquipmentType ref="fireEquipmentType" />
        </div>
    </div>
</template>

<script>
import fireEquipmentType from "@/views/ecology/components/fireCheck/fireEquipmentType.vue";
/**
 * createdd() 调用初始化方法
 * mounted() 调用查询方法
 **/

export default {
    components: { fireEquipmentType },

    data() {
        return {
            // 标题
            title: "平台消费器材类型"
            // 表单参数
        };
    },

    mounted() {},
    methods: {}
};
</script>