<template>
    <div class="app-container">
        <div class="layer">
            <el-tabs v-model="activeName" @tab-click="handleChooseTab">
                <el-tab-pane label="消防器材清单" name="first">
                    <fireEquipment ref="fireEquipment"></fireEquipment>
                </el-tab-pane>
                <el-tab-pane label="点检异常清单" name="second">
                    <checkTaskList ref="checkTaskList" />
                </el-tab-pane>
                <!-- <el-tab-pane label="消防器材分布图" name="third"  >消防器材分布图</el-tab-pane>  -->
                <el-tab-pane label="消防器材类型" name="fourth">
                    <fireEquipmentType ref="fireEquipmentType" />
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
import fireEquipment from "@/views/ecology/components/fireCheck/fireEquipment.vue";
import fireEquipmentType from "@/views/ecology/components/fireCheck/fireEquipmentType.vue";
import checkTaskList from "@/views/ecology/components/fireCheck/checkTaskList.vue";
/**
 * createdd() 调用初始化方法
 * mounted() 调用查询方法
 **/

export default {
    components: { fireEquipmentType, fireEquipment, checkTaskList },

    data() {
        return {
            dialog: {
                checkList: false
            },
            activeName: "first",
            // 标题
            title: "消费器材清单"
            // 表单参数
        };
    },

    mounted() {
        this.handleChooseTab();
    },
    methods: {
        handleChooseTab() {
            switch (this.activeName) {
                case "first":
                    this.$refs.fireEquipment.search();
                    break;

                case "second":
                    this.$refs.checkTaskList.search();
                    break;

                case "fourth":
                    this.$refs.fireEquipmentType.search();
                    break;
            }
        }
    }
};
</script>