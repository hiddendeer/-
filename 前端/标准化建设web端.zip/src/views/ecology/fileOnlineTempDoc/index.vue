<template>
    <div class="app-container">
        <div class="layer">
            

            <eagle-page :queryParams="queryParams" :controller="controller" ref="EaglePage" :showCheckColumn="false" btn-width="200px">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">

                        <eagle-input label-width="80px" label="筛选条件" @changeEnter="search" :required="false" prop="planname" v-model="conditionsVals.docName" placeholder="请输入报表名称" clearable size="small" />
                        <eagle-select @change="search()" label-width="80px" label="类型" prop="status" v-model="conditionsVals.docType" :data-source="params.fileOnlineTempDocType" size="small" :clearable="true">
                        </eagle-select>
                    </eagle-condition>
                </template>
                <template slot="slot-buttons">
                    <el-button type="primary" icon="el-icon-plus" size="mini" @click="handleAdd">新增
                    </el-button>
                </template>
                <template slot="slot-table">
                    <el-table-column label="报表名称" align="left" prop="docName" width="200px" />
                    <el-table-column label="所属行业" align="left" prop="applyProfessionNames" width="200px" />
                    <el-table-column label="所在地区" align="left" prop="belongArea" width="200px" />
                    <el-table-column label="报表应用场景描述" align="left" prop="docDesc" width="200px" />
                    <el-table-column label="类型" align="left" prop="docType">
                        <template slot-scope="scope">
                            <span>{{ formateDict(params.fileOnlineTempDocType, scope.row.docType + "") }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="示例文件" align="left" width="280px">
                        <template slot-scope="scope">
                            <eagle-row-attach v-model="scope.row.example"></eagle-row-attach>
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="primary" @click.stop="handleUpdate(scope.row)">编辑
                    </eagle-row-button>
                    <eagle-row-button type="primary" @click.stop="handleFileEdit(scope.row)">文件编辑
                    </eagle-row-button>
                    <eagle-row-button type="danger" size="mini" @click.stop="handleDelete(scope.row)">删除
                    </eagle-row-button>
                </template>
            </eagle-page>

            <eagle-form :controller="controller" title="模板信息" :form="form" width="800px" label-width="140px" ref="EagleForm" @afterSave="afterSave" @bindData="bindData">
                <eagle-block border>
                    <eagle-input label="报表名称" prop="docName" required v-model="form.docName" />
                    <el-row>
                        <eagle-choose-industry v-model="form.applyProfessionCodes" prop="applyProfessionCodes" required :names.sync="form.applyProfessionNames"></eagle-choose-industry>
                    </el-row>

                    <el-row>
                        <eagle-choose-region :hasAll="true" :checkStrictly='{ checkStrictly: true }' label="所在地区" v-model="form.belongArea" prop="belongArea" required></eagle-choose-region>
                    </el-row>
                    <eagle-select label="类型" prop="docType" :data-source="params.fileOnlineTempDocType" required v-model="form.docType" />
                    <eagle-input label="报表应用场景描述" type="textarea" prop="docDesc" v-model="form.docDesc" />
                    <eagle-attach label="示例文件" accept=".docx,.doc,.pdf" v-model.trim="form.example" prop="example">
                    </eagle-attach>
                </eagle-block>
            </eagle-form>
        </div>
    </div>
</template>

<script>
import eagleChooseIndustry from "@/views/ecologySupport/libTemp/components/selectIndustry/eagle-choose-industry.vue";
import eagleChooseRegion from "@/views/ecologySupport/libTemp/components/region/eagle-choose-region.vue";
export default {
    components: { eagleChooseIndustry, eagleChooseRegion },
    name: "FileOnlineTempDoc",
    data() {
        return {
            //行业
            selectIndustryVisible: false,
            conditionsVals: {
                docName: "",
                docType: "",
            },
            conditionsTypes: {
                docName: "like",
            },
            queryParams: {
                dataType: "list",
            },
            controller: "ecologyEnv/fileOnlineTempDoc",
            form: {},
            params: {
                fileOnlineTempDocType: [],
            },
        };
    },
    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.doc_type],
                function (res) {
                    _this.params.fileOnlineTempDocType = res.data.filter(
                        (p) => p.paramId === _this.constParams.doc_type
                    );
                    _this.params.fileOnlineTempDocType =
                        _this.params.fileOnlineTempDocType.filter(
                            (fileOnlineTempDocType) =>
                                fileOnlineTempDocType.id == "guideline" ||
                                fileOnlineTempDocType.id == "risk" ||
                                fileOnlineTempDocType.id == "response"
                        );
                }
            );
        },
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        //查询条件重置
        resetQuery() {
            this.conditionsVals.docName = "";
            this.conditionsVals.docType = "";
            // this.conditionsVals.planname = "";
            this.search();
        },
        //行业
        handleChooseProfession() {
            this.selectIndustryVisible = true;
        },
        handleSelectClose() {
            this.selectIndustryVisible = false;
        },
        handleSelectSubmit(val) {
            this.selectIndustryVisible = false;
            let str = "";
            val.forEach((item) => {
                str += item.name + ";";
            });
            this.form.applyProfessionNames = str.substr(0, str.length - 1);
        },
        //地区
        handleChooseApplyArea(val) {
            this.from.belongArea = val;
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        handleFileEdit(row) {
            let routerPath = "";
            if (this.$route.name == "EntFileOnlineTempDoc") {
                routerPath = "entFileOnlineTempDetail";
            } else {
                routerPath = "siteFileOnlineTempDetail";
            }
            this.$router.push({
                path: routerPath,
                query: {
                    id: row.id,
                },
            });
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            let _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.search();
            });
        },
        bindData(data) {
            this.form = data;
        },
        afterSave(res, action) {
            if (action == "edit") {
                this.$refs.EaglePage.refresh();
            } else {
                this.$refs.EaglePage.search();
            }
        },
    },
};
</script>
<style  lang="scss">
.form-title {
    .mustField {
        color: red;
        line-height: 36px;
    }
}

.industry {
    margin-left: 65px;
    margin-bottom: 20px;
}

.col {
    padding-right: 60px;
}
</style>
