<template>
    <div class="fileOnlineTempDocDetail">
        <el-form :model="blockForm" ref="form">
            <eagle-block border>
                <div class="clearfix">
                    <el-scrollbar class="card1">
                        <div v-for="(tempForm, index) in blockForm.blockData" :key="index" class="editMain">
                            <el-card class="mainFile" shadow="never">
                                <!-- Title -->

                                <el-form-item label="">
                                    <el-input class="title" v-model="tempForm.name" placeholder="请输入标题" prop="name">
                                    </el-input>
                                </el-form-item>
                                <!-- Time -->
                                <div style="display: flex;  justify-content: flex-end;">
                                    <div>
                                        <span class="el-form-item__label">编制时间</span>
                                        <el-date-picker style="width:200px;" type="date" placeholder="选择日期" v-model="tempForm.editFileDate">
                                        </el-date-picker>

                                    </div>
                                </div>
                                <!-- Detail -->
                                <el-form-item v-for="(detail, subIndex) in tempForm.details" :key="subIndex">
                                    <!-- Margin-Left -->
                                    <el-col v-if="parseInt(detail.leve) > 1" :span="0.5" :class="'el-col-blank_' + detail.leve">
                                    </el-col>
                                    <!-- Dropdown Function -->
                                    <el-col :span="0.5">
                                        <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="click">
                                            <div class="avatar-wrapper">
                                                <i class="el-icon-caret-bottom" />
                                            </div>
                                            <el-dropdown-menu slot="dropdown">
                                                <el-dropdown-item @click.native="dealLine('addTitle', index, subIndex)">
                                                    <span>添加同级标题</span>
                                                </el-dropdown-item>
                                                <el-dropdown-item v-show="parseInt(detail.leve) < 4" @click.native="dealLine('addChildTitle', index, subIndex)">
                                                    <span>添加下级标题</span>
                                                </el-dropdown-item>
                                                <el-dropdown-item @click.native="dealLine('addText', index, subIndex)">
                                                    <span>添加文本</span>
                                                </el-dropdown-item>
                                                <el-dropdown-item @click.native="dealLine('addTable', index, subIndex)">
                                                    <span>添加表格</span>
                                                </el-dropdown-item>
                                                <el-dropdown-item>
                                                    <eagle-image-hidden :index="index" :subIndex="subIndex" v-bind:imgData="imgData" v-on:imgChanged="dealImg($event)">
                                                    </eagle-image-hidden>
                                                </el-dropdown-item>
                                                <el-dropdown-item @click.native="dealLine('remove', index, subIndex)">
                                                    <span>移除</span>
                                                </el-dropdown-item>
                                            </el-dropdown-menu>
                                        </el-dropdown>
                                    </el-col>
                                    <!-- No -->
                                    <el-col :span="0.5" style="text-align: left;padding-left: 10px;padding-right: 10px;">
                                        <span style="font-weight: bold">{{ detail.showNo }}</span>
                                    </el-col>
                                    <!-- Title -->
                                    <!-- @keyup.enter.native="textareaKeyup($event, 'addTitle', index, subIndex)" -->
                                    <el-col :span="21" v-if="'Title' === detail.type">
                                        <el-input type="textarea" autosize v-if="tempForm.currentOrder === detail.orderNo" v-fo class="borderNone" v-model="detail.text" @keydown.native="textareaKeyup($event, 'addTitle', index, subIndex)" @paste.native="pasteMe($event, index, subIndex)"></el-input>
                                        <el-input type="textarea" autosize v-else class="borderNone" v-model="detail.text" @keydown.native="textareaKeyup($event, 'addTitle', index, subIndex)" @paste.native="pasteMe($event, index, subIndex)"></el-input>
                                    </el-col>
                                    <!-- Text -->
                                    <el-col :span="21" v-if="'Text' === detail.type">
                                        <el-input type="textarea" autosize v-if="tempForm.currentOrder === detail.orderNo" v-fo class="borderNone" v-model="detail.text" @keydown.native="textareaKeyup($event, 'addText', index, subIndex)" @paste.native="pasteMe($event, index, subIndex)"></el-input>
                                        <el-input type="textarea" autosize v-else class="borderNone" v-model="detail.text" @keydown.native="textareaKeyup($event, 'addText', index, subIndex)" @paste.native="pasteMe($event, index, subIndex)"></el-input>
                                    </el-col>
                                    <!-- Table -->
                                    <el-col :span="22" v-if="'Table' === detail.type">
                                        <table class="editBlockTable">
                                            <thead>
                                                <tr>
                                                    <th v-for="(item, index) in detail.value.columns" style="min-width: 5px" :key="index" :style="{ width: (item.Type == 'edit' ? '20' : item.Width) + '%' }" v-bind:colspan="item.Colspan && item.Colspan > 0 ? item.Colspan : ''" v-show="!item.Colspan || item.Colspan > 0 || item.Colspan == 0">
                                                        <div class="colum-btn">
                                                            <el-dropdown class="avatar-container right-menu-item" v-if="item.Type != 'edit'" trigger="click">
                                                                <div title="修改项" class="avatar-wrapper">
                                                                    <i class="el-icon-edit-outline" />
                                                                </div>
                                                                <el-dropdown-menu slot="dropdown">
                                                                    <div style="padding: 5px">
                                                                        <div style="display: flex; padding: 5px">
                                                                            <div>
                                                                                <span style="line-height: 36px">标题:</span>
                                                                            </div>
                                                                            <a style="line-height: 36px" @click="columnClick(item, index, detail.value, 'align-left')">
                                                                                <i class="el-icon-s-fold"></i>
                                                                            </a>
                                                                            <a style="line-height: 36px" @click="columnClick(item, index, detail.value, 'align-center')">
                                                                                <i class="el-icon-s-order"></i>
                                                                            </a>
                                                                            <a style="line-height: 36px" @click="columnClick(item, index, detail.value, 'align-right')">
                                                                                <i class="el-icon-s-unfold"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div style="display: flex; padding: 5px">
                                                                            <div>
                                                                                <span style="line-height: 36px">内容:</span>
                                                                            </div>
                                                                            <a style="line-height: 36px" @click="columnClick(item, index, detail.value, 'talign-left')">
                                                                                <i class="el-icon-s-fold"></i>
                                                                            </a>
                                                                            <a style="line-height: 36px" @click="columnClick(item, index, detail.value, 'talign-center')">
                                                                                <i class="el-icon-s-order"></i>
                                                                            </a>
                                                                            <a style="line-height: 36px" @click="columnClick(item, index, detail.value, 'talign-right')">
                                                                                <i class="el-icon-s-unfold"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div style="display: flex; padding: 5px">
                                                                            <div>
                                                                                <span style="line-height: 36px">宽度:</span>
                                                                            </div>
                                                                            <el-input type="number" class="operateInput" v-model="item.Width"></el-input>
                                                                        </div>
                                                                        <div style="display: flex; padding: 5px">
                                                                            <div>
                                                                                <span style="line-height: 36px">跨列:</span>
                                                                            </div>
                                                                            <el-input type="number" class="operateInput" v-model="colspan"></el-input>
                                                                            <el-button type="primary" @click="columnClick(item, index, detail.value, 'sure')">
                                                                                <span>确定</span>
                                                                            </el-button>
                                                                        </div>
                                                                        <div style="display: flex; padding: 5px">
                                                                            <div title="删除列" style="cursor: pointer" @click="columnClick(item, index, detail.value, 'delete')">
                                                                                <i class="el-icon-delete" />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </el-dropdown-menu>
                                                            </el-dropdown>

                                                            <div title="添加项" @click="columnClick(item, index, detail.value, 'add')">
                                                                <i class="el-icon-circle-plus-outline" />
                                                            </div>
                                                            <div title="添加行" v-if="item.Type == 'edit'" @click="columnClick(item, index, detail.value, 'addRow')">
                                                                <i class="el-icon-circle-plus" />
                                                            </div>
                                                        </div>
                                                        <div style="margin-top: 20px">
                                                            <span v-if="item.Type == 'edit'" style="font-weight: bolder">{{
                                                                        item.Name
                                                                }}</span>
                                                            <el-input v-else :class="'tableColumnInput_' + item.Align" v-model="item.Name"></el-input>
                                                        </div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="(dataItem, dataIndex) in detail.value.data" :key="dataIndex">
                                                    <td v-for="(item, index) in detail.value.columns" :key="index">
                                                        <div v-if="item.Type != 'edit'">
                                                            <el-input type="textarea" autosize :class="'tableDataInput_' + item.TAlign" v-model="dataItem[item.No]"></el-input>
                                                        </div>
                                                        <div v-else class="tableData-btn">
                                                            <div title="添加项" @click="rowClick(dataItem, dataIndex, detail.value, 'add')">
                                                                <i class="el-icon-plus" />
                                                            </div>
                                                            <div title="删除项" @click="rowClick(dataItem, dataIndex, detail.value, 'delete')">
                                                                <i class="el-icon-delete" />
                                                            </div>
                                                            <div title="上移" @click="rowClick(dataItem, dataIndex, detail.value, 'up')">
                                                                <i class="el-icon-top" />
                                                            </div>
                                                            <div title="下移" @click="rowClick(dataItem, dataIndex, detail.value, 'down')">
                                                                <i class="el-icon-bottom" />
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </el-col>
                                    <!-- Image -->
                                    <el-col :span="22" v-if="'Image' === detail.type">
                                        <div style="text-align: center; margin-top: 5px">
                                            <div>
                                                <el-image :style="{ width: detail.img.Width + 'px' }" :src="detail.img.Url">
                                                </el-image>
                                                <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="click">
                                                    <div class="avatar-wrapper">
                                                        <i class="el-icon-edit-outline" style="cursor: pointer" />
                                                    </div>
                                                    <el-dropdown-menu slot="dropdown">
                                                        <div style="padding: 5px">
                                                            <div style="display: flex">
                                                                <div>
                                                                    <span style="line-height: 36px">宽度:</span>
                                                                </div>
                                                                <el-input style="width: 100px" type="number" v-model="detail.img.Width"></el-input>
                                                            </div>
                                                        </div>
                                                    </el-dropdown-menu>
                                                </el-dropdown>
                                            </div>
                                            <el-input class="img-block" type="textarea" autosize v-if="tempForm.currentOrder === detail.orderNo" v-fo v-model="detail.img.Name" />
                                            <el-input class="img-block" type="textarea" autosize v-else v-model="detail.img.Name" />
                                        </div>
                                    </el-col>
                                </el-form-item>
                            </el-card>
                            <eagle-attach label="附件" labelWidth="60px" v-model="tempForm.attachs">
                            </eagle-attach>
                            <eagle-attach label="源模板" labelWidth="60px" accept=".doc,.docx" :count="1" v-model="tempForm.tempDoc">
                            </eagle-attach>
                        </div>
                    </el-scrollbar>
                    <el-scrollbar class="card2">
                        <div class="tempSearch" style="text-align: right">
                            <el-button type="primary" @click="handleBack()">返 回</el-button>
                            <el-button type="primary" @click="submitForm()">保 存</el-button>
                        </div>
                        <div class="tempSearch" v-for="(tempForm, index) in blockForm.blockData" :key="index">
                            <div class="clearfix" style="padding-bottom: 10px">
                                <span class="tempSearchTitle" @click="jump(tempForm)">
                                    <span></span>
                                </span>
                                <el-button class="thisTempSearchButton" type="primary" @click="identify">识别占位符
                                </el-button>
                                <!-- <el-button class="thisTempSearchButton" type="primary" @click="openDialog">查看默认通配符</el-button>
                        <el-button class="thisTempSearchButton" type="primary" @click="addPlace(index)">添加占位符</el-button> -->
                            </div>
                            <div style="padding-bottom: 10px">
                                <el-table :data="tempForm.searchList" v-if="tempForm.searchList.length > 0" class="editMain">
                                    <el-table-column prop="placeholder" label="占位符" width="120" align="left" />
                                    <el-table-column prop="surveyContent" label="占位内容" align="left">
                                        <template slot-scope="scope">
                                            <el-form-item class="valueInput" :prop="'blockData.' + index + '.searchList.' + scope.$index + '.surveyContent'" :rules="fromaDataRules.surveyContent" label-width="0">
                                                <el-input v-model="scope.row.surveyContent"></el-input>
                                            </el-form-item>
                                        </template>
                                    </el-table-column>
                                </el-table>
                                <span style="font-size: 14px" v-else>无调研内容</span>
                            </div>
                        </div>
                    </el-scrollbar>
                </div>
            </eagle-block>
        </el-form>

        <wild-char ref="charDialog"></wild-char>
    </div>
</template>

<script>
import $ from "jquery";
import http from "@/api/http";
import WildChar from "./wildChar.vue";
import { typeOf } from "mathjs";
export default {
    components: {
        WildChar,
    },
    data() {
        return {
            imgData: "",
            colspan: "",
            fromaDataRules: {
                surveyContent: [
                    {
                        required: true,
                        message: "占位符内容不能为空",
                        trigger: "blur",
                    },
                ],
            },
            blockForm: {
                blockData: [],
            },
        };
    },
    created() {
        this.loading = this.$loading({
            lock: true,
            text: "加载中",
            background: "rgba(0, 0, 0, 0.7)",
        });
        const id = this.$route.query.id;
        this.getData(id);
    },
    mounted() {},
    methods: {
        pasteMe($event, $index, $subIndex) {
            var item = this.blockForm.blockData[$index].details[$subIndex];
            // debugger;
            var clipboardData = $event.clipboardData;
            var html_content = clipboardData.getData("text/html");

            if (html_content) {
                $event.preventDefault();
                var html = $.parseHTML(html_content);
                var pArry = [];
                for (var i = 0; i < html.length; i++) {
                    var p = html[i];
                    var obj = {};
                    obj.value = {};
                    if (p.tagName == "P") {
                        var index = p.outerHTML.indexOf("level");
                        if (index > 0) {
                            obj.type = "Title";
                            obj.leve = p.outerHTML.substring(
                                index + 5,
                                index + 6
                            );
                            obj.text = p.innerText;
                            var titleIndex =
                                p.innerHTML.indexOf("<!--[endif]-->");
                            if (titleIndex > 0) {
                                obj.text = "";
                                var objHtml = $.parseHTML(
                                    p.innerHTML.substr(titleIndex + 14)
                                );
                                for (var j = 0; j < objHtml.length; j++) {
                                    if (objHtml[j].nodeValue) {
                                        obj.text =
                                            obj.text + objHtml[j].nodeValue;
                                    } else {
                                        if (objHtml[j].innerText) {
                                            obj.text =
                                                obj.text + objHtml[j].innerText;
                                        }
                                    }
                                }
                            }
                            pArry.push(obj);
                        } else {
                            obj.type = "Text";
                            obj.text = p.innerText;
                            pArry.push(obj);
                        }
                    } else if (p.tagName == "TABLE") {
                        obj.type = "Table";
                        obj.value.columns = [];
                        obj.value.data = [];
                        var thead = {};
                        var tbody = {};
                        var boolhead = false;
                        if (p && p.childNodes && p.childNodes.length > 0) {
                            for (var j = 0; j < p.childNodes.length; j++) {
                                var tableObj = p.childNodes[j];
                                if (tableObj.tagName == "THEAD") {
                                    thead = tableObj;
                                    boolhead = true;
                                }
                                if (tableObj.tagName == "TBODY") {
                                    tbody = tableObj;
                                    break;
                                }
                            }
                        }
                        if (thead || tbody) {
                            if (boolhead) {
                                for (
                                    var j = 0;
                                    j < thead.childNodes.length;
                                    j++
                                ) {
                                    var trObj = thead.childNodes[j];
                                    if (trObj.tagName == "TR") {
                                        for (
                                            var h = 0;
                                            h < trObj.childNodes.length;
                                            h++
                                        ) {
                                            var tdObj = trObj.childNodes[h];
                                            if (tdObj.tagName == "TD") {
                                                var colum = this.getNewColumn(
                                                    tdObj,
                                                    obj.value.columns
                                                );
                                                obj.value.columns.push(colum);
                                            }
                                        }
                                        obj.value.columns.push(
                                            this.getEditColumn()
                                        );
                                    }
                                }
                            }
                            for (var j = 0; j < tbody.childNodes.length; j++) {
                                var trObj = tbody.childNodes[j];
                                if (trObj.tagName == "TR") {
                                    if (obj.value.columns.length == 0) {
                                        for (
                                            var h = 0;
                                            h < trObj.childNodes.length;
                                            h++
                                        ) {
                                            var tdObj = trObj.childNodes[h];
                                            if (tdObj.tagName == "TD") {
                                                var colum = this.getNewColumn(
                                                    tdObj,
                                                    obj.value.columns
                                                );
                                                obj.value.columns.push(colum);
                                            }
                                        }
                                        obj.value.columns.push(
                                            this.getEditColumn()
                                        );
                                    } else {
                                        var row = {};
                                        var tdNum = 0;
                                        for (
                                            var h = 0;
                                            h < trObj.childNodes.length;
                                            h++
                                        ) {
                                            var tdObj = trObj.childNodes[h];
                                            if (tdObj.tagName == "TD") {
                                                var text = tdObj.innerText;
                                                if (text) {
                                                    text = text.replace(
                                                        /[\r\n]/g,
                                                        ""
                                                    );
                                                }
                                                var no =
                                                    obj.value.columns[tdNum].No;
                                                row[no] = text;
                                                tdNum++;
                                            }
                                        }
                                        row.A = "edit";
                                        obj.value.data.push(row);
                                    }
                                }
                            }
                        }
                        pArry.push(obj);
                    }
                }
                if (pArry.length > 0) {
                    var list = this.blockForm.blockData[$index].details;
                    var currentOrder = item.orderNo;
                    var maxLeve = 1;
                    var minLeve = 11;
                    for (var i = 0; i < pArry.length; i++) {
                        var obj = pArry[i];
                        if (obj.type == "Title") {
                            if (obj.leve > maxLeve) {
                                maxLeve = obj.leve;
                            }
                            if (obj.leve < minLeve) {
                                minLeve = obj.leve;
                            }
                        }
                    }
                    item.text = pArry[0].text;
                    item.type = pArry[0].type;
                    item.value = pArry[0].value;
                    for (var i = 1; i < pArry.length; i++) {
                        var obj = pArry[i];
                        obj.orderNo = currentOrder + 1;
                        if (obj.type != "Title") {
                            if (obj.type == "Text") {
                                obj.leve = list[obj.orderNo - 2].leve;
                            } else if (obj.type == "Table") {
                                obj.leve = 1;
                            }
                            list.splice(currentOrder, 0, obj);
                        } else if (obj.type == "Title") {
                            obj.leve = obj.leve - minLeve + parseInt(item.leve);
                            if (obj.leve > 4) {
                                obj.leve = 4;
                            }
                            list.splice(currentOrder, 0, obj);
                        }
                        currentOrder++;
                    }
                    this.blockForm.blockData[$index].currentOrder =
                        currentOrder - 1;
                    this.calculateShowNo($index);
                    return false;
                }
            }
        },
        identify() {
            var set = new Set();
            this.identifyChar(this.blockForm.blockData, set);

            var searchList = [];

            set.forEach((item) => {
                searchList.push({
                    placeholder: item,
                    surveyContent: "",
                });
            });

            this.blockForm.blockData[0].searchList = searchList;
        },
        identifyChar(obj, set) {
            if (Array.isArray(obj)) {
                var param = [];
            } else if (obj && typeof obj == "object") {
                var param = {};
            } else {
                if (typeof obj == "string") {
                    obj.replace(/【占位符.*?】/g, function ($1) {
                        set.add($1);
                    });
                }
                return obj;
            }

            for (var k in obj) {
                if (k == "searchList") continue;
                param[k] = this.identifyChar(obj[k], set);
            }

            return param;
        },
        openDialog() {
            this.$refs.charDialog.open();
        },
        getData(id) {
            http.get("/ecologyEnv/fileOnlineTempDoc/getData/" + id).then((res) => {
                let resultData = res.data.fileOnlineTemp;
                this.imgShow = true;
                if (resultData && resultData.length > 0) {
                    for (let i = 0; i < resultData.length; i++) {
                        let item = resultData[i];
                        item.currentOrder = null;

                        if (item.details && item.details.length > 0) {
                            // 始终比下表大 1, 方便处理插入位置
                            var orderNo = 1;
                            for (let j = 0; j < item.details.length; j++) {
                                let itemDetail = item.details[j];
                                itemDetail.orderNo = itemDetail.order;
                                itemDetail.value = {};
                                if (itemDetail.type === "Table") {
                                    itemDetail.value = JSON.parse(
                                        itemDetail.text
                                    );
                                    itemDetail.text = "";
                                }
                                if (itemDetail.type === "Image") {
                                    itemDetail.img = JSON.parse(
                                        itemDetail.text
                                    );
                                    itemDetail.text = "";
                                }
                                // 新增时的基础值赋值
                                itemDetail.leve = itemDetail.leve || 1;
                                itemDetail.type = itemDetail.type || "Title";
                                itemDetail.orderNo = orderNo++;
                                //itemDetail.showNo = itemDetail.showNo || "1";
                            }
                        }
                        // if (item.searchList && item.searchList.length > 0) {
                        //     var char = 'A'
                        //     for (let k = 0; k < item.searchList.length; k++) {
                        //         let search = item.searchList[k];

                        //         if (!search.placeholder) {
                        //             search.placeholder = '【占位符' + char + '】'
                        //         }
                        //         char =  String.fromCharCode(search.placeholder.charCodeAt(4) + 1)
                        //     }
                        // }
                    }
                    this.blockForm.blockData = resultData;
                    this.imgShow = false;
                }
                this.loading.close();

                console.log(this.blockForm);
            });
        },
        dealImg(data) {
            let currentRow =
                this.blockForm.blockData[data.index].details[data.subIndex];
            let order = currentRow.orderNo;
            let obj = {};
            obj = {
                id: 0,
                type: "Image",
                leve: currentRow.leve,
                orderNo: order + 1,
                img: JSON.parse(data.data),
                text: "",
                showNo: "",
            };
            this.blockForm.blockData[data.index].details.splice(order, 0, obj);
            this.blockForm.blockData[data.index].currentOrder = obj.orderNo;
        },
        dealLine(type, index, subIndex) {
            let currentRow = this.blockForm.blockData[index].details[subIndex];
            let order = currentRow.orderNo;
            let obj = {};

            // 只是处理了有 showNo的情况
            let { showNo, leve } = currentRow;
            let details = this.blockForm.blockData[index].details;

            switch (type) {
                case "addTitle":
                    order = this.getNextTitleOrder(
                        index,
                        order,
                        currentRow.leve
                    );
                    obj = {
                        id: 0,
                        // Use to differentiate display controls
                        type: "Title",
                        // Level be used to set the Margin and Get the Place
                        leve: currentRow.leve,
                        // Order & Get the Place to set the new Item
                        orderNo: order + 1,
                        text: "",
                        // No. be showed at the prev place
                        showNo: "",
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    this.blockForm.blockData[index].currentOrder = obj.orderNo;
                    break;
                case "addChildTitle":
                    order = this.getNextTitleOrder(
                        index,
                        currentRow.orderNo,
                        parseInt(currentRow.leve) + 1
                    );
                    obj = {
                        id: 0,
                        type: "Title",
                        leve: parseInt(currentRow.leve) + 1,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    this.blockForm.blockData[index].currentOrder = obj.orderNo;
                    break;
                case "addTable":
                    obj = {
                        id: 0,
                        type: "Table",
                        leve: currentRow.leve,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                        value: {
                            columns: [this.getEditColumn()],
                            data: [],
                        },
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    break;
                case "addText":
                    obj = {
                        id: 0,
                        type: "Text",
                        leve: currentRow.leve,
                        orderNo: order + 1,
                        text: "",
                        showNo: "",
                    };
                    this.blockForm.blockData[index].details.splice(
                        order,
                        0,
                        obj
                    );
                    this.blockForm.blockData[index].currentOrder = obj.orderNo;
                    break;
                case "remove":
                    if (this.blockForm.blockData[index].details.length == 1) {
                        this.msgError("最后一条明细，不能删除");
                        return;
                    }
                    this.blockForm.blockData[index].details.splice(
                        order - 1,
                        1
                    );
                    break;
                case "ChildTitle":
                    // showNo = String(showNo)
                    // if (showNo == 1) return

                    // let lastIdx = showNo.lastIndexOf('.')
                    // let No = showNo.slice(0, lastIdx)
                    // let Reg = new RegExp('^' + No +  '\.\\d+$')
                    // let sibling = details.find(item => Reg.test(item.showNo.toString()))
                    // if (leve > 1 && !sibling || sibling.showNo == showNo) break
                    if (currentRow.type == "Text") return;
                    if (currentRow.leve == 4) {
                        currentRow.type = "Text";
                    } else {
                        currentRow.leve = parseInt(currentRow.leve) + 1;
                    }
                    break;
                case "Title":
                    if (currentRow.type == "Text") {
                        currentRow.type = "Title";
                        break;
                    }
                    if (currentRow.leve == 1) {
                        break;
                    }
                    // let oldLeve = parseInt(currentRow.leve)
                    // let place = 0;
                    // for (let i = 0; i < details.length; i++) {
                    //     if (details[i].orderNo == currentRow.orderNo) {
                    //         details.splice(i, 1)
                    //         i--
                    //     }
                    //     if (details[i].leve == oldLeve) {
                    //         place = i;
                    //     }
                    // }
                    // currentRow.leve = oldLeve - 1
                    // details.splice(place, 0, currentRow);
                    currentRow.leve = parseInt(currentRow.leve) - 1;
                    break;
            }

            if (type !== "addImg") {
                this.calculateShowNo(index);
            }
        },
        //得到插入标题的位置
        getNextTitleOrder: function (index, order, level) {
            for (
                let i = order;
                i < this.blockForm.blockData[index].details.length;
                i++
            ) {
                let item = this.blockForm.blockData[index].details[i];
                if (item.type !== "Title" || item.leve > level) {
                    order = item.orderNo;
                } else {
                    break;
                }
            }
            return order;
        },
        getEditColumn: function () {
            return {
                Name: "操作",
                No: "A",
                Width: 20,
                BWidth: "20px",
                Align: "center",
                TAlign: "center",
                Type: "edit",
            };
        },
        getNewColumn(tdObj, columns) {
            var colum = {};
            colum.Name = tdObj.innerText;
            if (colum.Name) {
                colum.Name = colum.Name.replace(/[\r\n]/g, "");
            }
            colum.Width = 20;
            //var arryWidth = tdObj.style.width.match(false ? /[1-9]\d{1,}/g : /\d{2,}/g);
            //if (arryWidth && arryWidth.length > 0) {
            //    colum.Width = arryWidth[0];
            //}
            colum.Align = "center";
            colum.TAlign = "left";
            colum.GroupTitle = "";
            colum.Colspan = "";
            colum.BWidth = colum.Width + "%";
            colum.No = this.getColumnNo(columns);
            return colum;
        },
        columnClick: function (item, index, value, type) {
            switch (type) {
                case "delete":
                    value.columns.splice(index, 1);
                    break;
                case "add":
                    let newcolum = {};
                    newcolum.Name = "新增";
                    newcolum.Width = 40;
                    newcolum.BWidth = newcolum.Width + "px";
                    newcolum.Align = "center";
                    newcolum.TAlign = "center";
                    newcolum.No = this.getColumnNo(value.columns);
                    value.columns.splice(index, 0, newcolum);
                    break;
                case "addRow":
                    value.data.splice(value.data.length, 0, { A: "edit" });
                    break;
                case "align-left":
                case "align-center":
                case "align-right":
                    value.columns[index].Align = type.replace("align-", "");
                    break;
                case "talign-left":
                case "talign-center":
                case "talign-right":
                    value.columns[index].TAlign = type.replace("talign-", "");
                    break;
                case "sure":
                    let hiddenCount = 0;
                    item.Colspan = this.colspan;
                    if (item.Colspan && item.Colspan > 1) {
                        hiddenCount = Number(item.Colspan) - 1;
                    }
                    for (let i = index + 1; i < value.columns.length; i++) {
                        let nextColum = value.columns[i];
                        if (hiddenCount > 0) {
                            nextColum.Colspan = -1;
                        } else if (nextColum.Colspan) {
                            if (nextColum.Colspan < 0) {
                                nextColum.Colspan = 0;
                            } else if (nextColum.Colspan > 0) {
                                hiddenCount = nextColum.Colspan;
                            }
                        }
                        hiddenCount--;
                    }
                    value.columns[index].Colspan = item.Colspan;
                    value.columns[index].Width = item.Width;
                    value.columns[index].BWidth = item.Width + "px";

                    this.colspan = "";
                    break;
            }
        },
        getColumnNo: function (columns) {
            let maxCode = 65;
            for (let i = 0; i < columns.length; i++) {
                let item = columns[i];
                let code = item.No.charCodeAt();
                if (code > maxCode) {
                    maxCode = code;
                }
            }
            return String.fromCharCode(maxCode + 1);
        },
        rowClick: function (item, index, value, type) {
            switch (type) {
                case "add":
                    value.data.splice(index + 1, 0, { A: "edit" });
                    break;
                case "delete":
                    value.data.splice(index, 1);
                    break;
                case "up":
                    if (index == 0) {
                        this.msgError("已经是最上层了");
                        return;
                    }
                    let pItem = value.data[index - 1];
                    let cItem = value.data[index];
                    value.data.splice(index - 1, 1, cItem);
                    value.data.splice(index, 1, pItem);
                    break;
                case "down":
                    if (index == value.data.length - 1) {
                        this.msgError("已经是最下层了");
                        return;
                    }
                    let nItem = value.data[index + 1];
                    let ccItem = value.data[index];
                    value.data.splice(index + 1, 1, ccItem);
                    value.data.splice(index, 1, nItem);
                    break;
                default:
                    break;
            }
        },
        textareaKeyup(event, type, index, subIndex) {
            if (event.key == "Enter") {
                this.dealLine(type, index, subIndex);
                event.preventDefault();
            }
            if (event.key == "Tab") {
                event.preventDefault();
                if (event.shiftKey) {
                    this.dealLine("Title", index, subIndex);
                } else {
                    this.dealLine("ChildTitle", index, subIndex);
                }
            }
        },
        calculateShowNo: function (index) {
            let list = this.blockForm.blockData[index].details;
            let leve1No = 0;
            let leve2No = 0;
            let leve3No = 0;
            let leve4No = 0;
            let currentLeve = 1;

            for (let i = 0; i < list.length; i++) {
                let item = list[i];
                item.orderNo = i + 1;
                if (item.type === "Title") {
                    if (item.leve < currentLeve) {
                        if (item.leve == 3) {
                            leve4No = 0;
                        } else if (item.leve == 2) {
                            leve4No = 0;
                            leve3No = 0;
                        } else if (item.leve == 1) {
                            leve4No = 0;
                            leve3No = 0;
                            leve2No = 0;
                        }
                    } else {
                        currentLeve = item.leve;
                    }
                    if (item.leve == 1) {
                        leve1No = leve1No + 1;
                        item.showNo = leve1No;
                    }
                    if (item.leve == 2) {
                        leve2No = leve2No + 1;
                        item.showNo = leve1No + "." + leve2No;
                    }
                    if (item.leve == 3) {
                        leve3No = leve3No + 1;
                        item.showNo = leve1No + "." + leve2No + "." + leve3No;
                    }
                    if (item.leve == 4) {
                        leve4No = leve4No + 1;
                        item.showNo =
                            leve1No +
                            "." +
                            leve2No +
                            "." +
                            leve3No +
                            "." +
                            leve4No;
                    }
                } else {
                    item.showNo = "";
                }
            }
            this.blockForm.blockData[index].details = [];
            this.blockForm.blockData[index].details = list;
        },
        addPlace(index) {
            let searchList = this.blockForm.blockData[index].searchList;
            if (searchList.length > 0) {
                var char = String.fromCharCode(
                    searchList[searchList.length - 1].placeholder.charCodeAt(
                        4
                    ) + 1
                );
                searchList.push({
                    placeholder: "【占位符" + char + "】",
                    surveyContent: "",
                });
            } else {
                searchList.push({
                    placeholder: "【占位符A】",
                    surveyContent: "",
                });
            }
        },
        copy(item) {
            const input = document.createElement("input");
            document.body.appendChild(input);
            input.setAttribute("value", item.placeholder);
            input.select();
            if (document.execCommand("copy")) {
                document.execCommand("copy");

                this.$message.success("已复制");
            }
            document.body.removeChild(input);
        },
        deleteRow(index, subIndex) {
            this.blockForm.blockData[index].searchList.splice(subIndex, 1);
        },
        jump(tempForm) {
            // document
            //     .getElementById(tempForm.mainCode + "" + tempForm.templateCode)
            //     .scrollIntoView({ behavior: "smooth" });
        },
        /** 提交按钮 */
        submitForm: function () {
            this.$refs["form"].validate((valid) => {
                if (!valid) return false;
                for (let i = 0; i < this.blockForm.blockData.length; i++) {
                    let item = this.blockForm.blockData[i];
                    if (item.details && item.details.length > 0) {
                        for (let j = 0; j < item.details.length; j++) {
                            let itemDetail = item.details[j];
                            if (itemDetail.type === "Table") {
                                itemDetail.text = JSON.stringify(
                                    itemDetail.value
                                );
                            }
                            if (itemDetail.type === "Image") {
                                itemDetail.text = JSON.stringify(
                                    itemDetail.img
                                );
                            }
                        }
                    }
                }

                this.loading = this.$loading({
                    lock: true,
                    text: "保存中",
                    background: "rgba(0, 0, 0, 0.7)",
                });

                http.post(
                    "/ecologyEnv/fileOnlineTemp/saveOnlineTemp",
                    this.blockForm.blockData
                )
                    .then((res) => {
                        this.msgSuccess("保存成功");
                        this.loading.close();
                        this.$router.go(-1);
                        // if (this.$route.name=="entFileOnlineTempDetail") {
                        //    this.$router.push({
                        //     name: "EntFileOnlineTempDoc",
                        //   });
                        // }else{
                        //   this.$router.push({
                        //     name: "SiteFileOnlineTempDoc",
                        //   });
                        // }
                    })
                    .catch(() => {
                        this.loading.close();
                    });
            });
        },
        handleBack() {
            this.$router.go(-1);
            // this.$router.push({
            //   path: "/System/systemPlatform/siteFileOnlineTempDoc"
            // });
            // if (this.$route.name=="EntFileOnlineTempDetail") {
            //   this.$router.push({
            //     name: "entFileOnlineTempDetail"
            //   }).catch(err => {
            //     console.log(err);
            //   });
            // }else{
            //   this.$router.push({
            //     path: "siteFileOnlineTempDoc",
            //   });
            // }
        },
    },
};
</script>

<style rel="stylesheet/scss" lang="scss">
.editMain .el-form-item {
    margin-bottom: 0px;
}

.operateInput {
    width: 60px;
    margin-right: 5px;
}

.operateInput input.el-input__inner {
    padding: 0 0;
}

.fileOnlineTempDocDetail {
    .el-scrollbar__wrap {
        overflow-x: hidden;
    }

    .clearfix {
        display: flex;
        justify-content: space-between;
    }

    .card1 {
        width: 70%;
        min-width: 560px;
        height: calc(100vh - 104px);

        .title {
            font-size: 26px;
        }

        .title input.el-input__inner {
            text-align: center;
            border: 2px white solid;
            font-weight: bolder;
        }

        // Margin
        .el-col-blank_2 {
            border: 5px solid transparent;
        }

        .el-col-blank_3 {
            border: 10px solid transparent;
        }

        .el-col-blank_4 {
            border: 15px solid transparent;
        }

        // Title/Text Input
        .borderNone input.el-input__inner {
            border: 2px white solid;
            padding: 0 0;
        }

        .borderNone input.el-input__inner:focus {
            border: 2px black solid;
        }

        .borderNone textarea.el-textarea__inner {
            font-family: Arial;
            border: 2px white solid;
            padding: 0 0 0 0;
            resize: none;
            line-height: 36px;
        }

        .borderNone textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        // Image Name Input
        .img-block {
            padding: 10px 10px;
        }

        .img-block textarea.el-textarea__inner {
            font-family: Arial;
            text-align: center;
            border: 2px white solid;
            resize: none;
        }

        .img-block textarea.el-textarea__inner:focus {
            text-align: center;
            border: 2px black solid;
        }

        .colum-btn {
            display: flex;
            float: right;
            line-height: 1px;
            margin-right: 3px;
        }

        .colum-btn i {
            cursor: pointer;
            width: 150%;
        }

        .tableData-btn {
            display: block;
            text-align: center;
        }

        .tableData-btn div {
            display: inline;
        }

        .tableData-btn i {
            cursor: pointer;
        }

        .tableColumnInput_center input.el-input__inner {
            text-align: center;
            border: 2px white solid;
            font-weight: bolder;
            color: #303133;
        }

        .tableColumnInput_center input.el-input__inner:focus {
            border: 2px black solid;
        }

        .tableColumnInput_left input.el-input__inner {
            text-align: left;
            border: 2px white solid;
            font-weight: bolder;
            color: #303133;
        }

        .tableColumnInput_left input.el-input__inner:focus {
            border: 2px black solid;
        }

        .tableColumnInput_right input.el-input__inner {
            text-align: right;
            border: 2px white solid;
            font-weight: bolder;
            color: #303133;
        }

        .tableColumnInput_right input.el-input__inner:focus {
            border: 2px black solid;
        }

        .tableDataInput_center textarea.el-textarea__inner {
            text-align: center;
            font-family: Arial;
            border: 2px white solid;
            resize: none;
        }

        .tableDataInput_center textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        .tableDataInput_left textarea.el-textarea__inner {
            text-align: left;
            font-family: Arial;
            border: 2px white solid;
            resize: none;
        }

        .tableDataInput_left textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        .tableDataInput_right textarea.el-textarea__inner {
            text-align: right;
            font-family: Arial;
            border: 2px white solid;
            resize: none;
        }

        .tableDataInput_right textarea.el-textarea__inner:focus {
            border: 2px black solid;
        }

        .editBlockTable {
            width: 100%;
            border-spacing: 0px;
            border: 1px solid #cccccc;
        }

        .editBlockTable th {
            border: 1px solid #cccccc;
        }

        .editBlockTable td {
            border: 1px solid #cccccc;
        }

        .el-col-blank_2 {
            border: 5px solid transparent;
        }

        .el-col-blank_3 {
            border: 10px solid transparent;
        }

        .el-col-blank_4 {
            border: 15px solid transparent;
        }
    }

    .card2 {
        width: 30%;
        height: calc(100vh - 104px);

        .tempSearch {
            padding: 10px 30px;
        }

        .tempSearchTitle {
            width: 80%;
            cursor: pointer;
            border-bottom: 1px solid lightgray;
        }

        .tempSearchTitle span {
            font-size: 14px;
            font-weight: bolder;
        }

        .thisTempSearchButton {
            padding: 0 10px !important;
            height: 30px;
            padding: 0;
        }

        .thisTempSearchButton span {
            line-height: 30px;
        }
    }
}
</style>
