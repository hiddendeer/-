<template>
    <el-dialog v-dialogDrag :visible.sync="visible" :close-on-click-modal="false" width="600px" v-if="visible">
        <eagle-block border>
            <eagle-page :controller="controller" ref="EaglePage" :showCheckColumn="false" btn-width="140px">
                <template slot="slot-table">
                    <el-table-column label="占位符编号" align="left" prop="dictionaryCode" />
                    <el-table-column label="占位符内容" align="left" prop="dictionaryName" />
                </template>
                <el-table-column label="操作" align="left" width="80">
                    <template slot-scope="scope">
                        <el-button icon="el-icon-edit" size="mini" type="text" @click="copy(scope.row)">复制</el-button>
                    </template>
                </el-table-column>
            </eagle-page>
        </eagle-block>
    </el-dialog>
</template>

<script>
export default {
    data() {
        return {
            visible: false,
            controller: "ecologyEnv/ledgerTempDictionary",
        };
    },
    methods: {
        search() {
            this.$refs.EaglePage.search({
                url: this.controller + "/getPageData",
            });
        },
        open() {
            this.visible = !this.visible;
            this.$nextTick(() => {
                this.search();
            });
        },
    },
};
</script>