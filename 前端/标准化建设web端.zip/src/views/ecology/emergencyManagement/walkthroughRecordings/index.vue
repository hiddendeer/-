<template>
    <div class="app-container" id="app-container">
        <div class="layer">
            <eagle-page :queryParams="queryParams" ref="EaglePage" :noPage="false" :pageUrl="pageUrl"
                :controller="controller" :pageSize="10" btnWidth="160" :showCheckColumn="false" :showBtn="false">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input @changeEnter="search()" label="演练名称" :required="false" prop="drillName"
                            :width="'160px'" labelWidth="70px" v-model="conditionsVals.drillName" placeholder="请输入演练名称"
                            maxlength="30" clearable size="small" />
                        <eagle-input @changeEnter="search()" label="演练组织方" :required="false" prop="agencyName"
                            :width="'160px'" labelWidth="90px" v-model="conditionsVals.agencyName" placeholder="请输入演练组织方"
                            maxlength="30" clearable size="small" />
                        <eagle-select label="演练数据来源" :required="false" prop="drillTypeEnum" labelWidth="100px" name="label"
                            id="value" placeholder="请选择演练类别" v-model="conditionsVals.drillTypeEnum" :width="160"
                            :dataSource="walkthroughCategory" size="small" />
                        <eagle-date :isDaterange="true" type="daterange" label="演练时间" :required="false"
                            prop="WalkthroughRecordingsTime" labelWidth="70px" v-model="WalkthroughRecordingsTime"
                            placeholder="请输入演练时间" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-table">
                    <el-table-column label="演练名称" align="center" prop="drillName">
                        <template #default="scope">
                            {{ scope.row.drillName }}
                        </template>
                    </el-table-column>
                    <el-table-column label="演练时间" align="center" prop="drillDate" width="180">
                        <template #default="scope">
                            <div>
                                {{ getFormatTime(scope.row.drillDate) }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="演练组织方" align="center" prop="agencyName">
                        <template #default="scope">
                            {{ scope.row.agencyName || '-' }}
                        </template>
                    </el-table-column>
                    <el-table-column label="演练数据来源" align="center" prop="drillTypeEnum" width="200">
                        <template #default="scope">
                            <div>
                                {{ scope.row.drillTypeEnum }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="演练文件" align="center">
                        <template #default="scope">
                            <el-button type="text" :disabled="!getFileLists(scope.row).length" class="fileItem attach-item"
                                @click.stop="toViewFiles(getFileLists(scope.row))">查看附件</el-button>
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                </template>
            </eagle-page>
        </div>
        <fileViewer ref="fileViewerRef" />
    </div>
</template>

<script>
import { dataFormat } from "@/utils/format.js"
import { Loading } from "element-ui"
import fileViewer from './components/fileViewer'
export default {
    name: "walkthroughRecordings",
    components: {
        fileViewer
    },
    data() {
        return {
            projectId: "",
            queryParams: {
                dataType: "list",
                pageNum: 1,
                conditions: this.conditionsVals
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                status: "=",
                name: "like",
            },
            // 查询条件
            conditionsVals: {
                status: null,
                drillName: "",
                agencyName: '',
                drillTypeEnum: "全部",
                searchBeginTime: '',
                searchEndTime: ''
            },
            WalkthroughRecordingsTime: [],
            pageUrl: "ecologyEnv/planDrillPlan/entGetPageData",
            controller: "ecologyEnv/planDrillPlan/entGetPageData", //对应后端控制器
            params: {},
            getSearchEndTime: '',
            getSearchBeginTime: '',
            walkthroughCategory: [
                {
                    "label": "全部",
                    "value": "全部"
                },
                {
                    "label": "易演练",
                    "value": "易演练"
                },
                {
                    "label": "企业自主填报",
                    "value": "企业自主填报"
                },
            ]
        };
    },
    watch: {
        WalkthroughRecordingsTime(val) {
            if (Array.isArray(val) && val?.length == 2) {
                this.conditionsVals.searchBeginTime = val[0]
                this.conditionsVals.searchEndTime = val[1]
            } else {
                this.conditionsVals.searchBeginTime = ''
                this.conditionsVals.searchEndTime = ''
            }
        }
    },
    created() { },
    mounted() {
        this.search();
    },
    methods: {
        getFormatTime(time) {
            return dataFormat(time)
        },
        isValidJson(str) {
            try {
                JSON.parse(str);
                return true;
            } catch (e) {
                return false;
            }
        },
        getFileLists(listdata) {
            if (!listdata) return [];
            let loopFileArray = [];
            if (listdata?.drillTypeEnum == '企业自主填报') {
                const fileLists = [listdata?.docAttach, listdata?.drillScript, listdata?.recordAttachs];
                fileLists.forEach(fileList => {
                    if (this.isValidJson(fileList)) {
                        loopFileArray = loopFileArray.concat(this.getFiles(fileList));
                    }
                });
            } else {
                loopFileArray = (listdata?.drillLinks || []).map((i) => {
                    return {
                        attFilePath: i.url,
                        name: i.name
                    }
                })
            }
            if (!Array.isArray(loopFileArray)) {
                loopFileArray = [];
            }
            return loopFileArray;
        },
        getFiles(listdata) {
            let fileList = Array.isArray(listdata) ? listdata : JSON.parse(listdata || "[]");
            fileList.forEach(file => {
                if (!file.name || !file.attExt) {
                    const fileName = file.attFilePath.substring(file.attFilePath.lastIndexOf('/') + 1);
                    [file.name, file.attExt] = fileName.split('.');
                }
                file.name = `${file.name}.${file.attExt}`;
            });
            return fileList;
        }
        ,
        toViewFiles(files) {
            this.$refs.fileViewerRef?.show({
                fileList: files,
                title: "查看演练文件",
                isReport: false,
            })
        },
        //查询
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        //刷新
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        resetQuery() {
            this.WalkthroughRecordingsTime = []
            this.conditionsVals = {
                drillName: "",
                agencyName: '',
                drillTypeEnum: "全部",
                searchBeginTime: '',
                searchEndTime: ''
            }
            this.search();
        }
    },
};
</script>
<style lang="scss">
.filesContainer {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    .fileItem {
        cursor: pointer;
        transition: all 0.4s;
        width: 100%;
        text-align: center;

        &:hover {
            color: #1b76d1;
        }
    }
}
</style>