<template>
    <el-dialog v-dialogDrag v-if="open" :visible.sync="open" :width="width" append-to-body :show-close="false"
        :close-on-click-modal="false" custom-class="pdf-dialog">
        <div slot="title" class="dialog-title">
            <div>{{ title || "文件浏览" }}</div>
            <div class="btnMargin dialog-btn">
                <div style="display:inline-block;margin-top:-7px;">
                    <el-button size="mini" type="primary" v-if="ownLoad" @click="downSource" :disabled="loading">导出</el-button>
                    <el-button size="mini" @click="cancel">关闭</el-button>
                </div>
            </div>
        </div>
        <div class="file-container" style="height:600px;" v-loading="loading" element-loading-text="文件导出中">
            <slot>
                <div class="file-list">
                    <el-checkbox-group v-model="checkList">
                        <el-checkbox v-for="item of fileList" :key="item.attFilePath" :label="item.attFilePath">
                            <span class="fileName" :class="url == item.attFilePath ? 'isview' : ''" :title="item.name"
                                @click.prevent="toView(item)">{{ item.name }}</span>
                        </el-checkbox>
                    </el-checkbox-group>
                </div>
                <div class="file-view">
                    <div v-if="fileType == '0'"></div>
                    <template style="min-height: 400px" v-else-if="fileType == '1'">
                        <eagle-pdf-view class="pdf-view" v-if="url" :url="url" ref="eaglePdfView"></eagle-pdf-view>
                    </template>
                    <div v-else-if="fileType == '2'">
                        <el-image class="imageClass" v-if="url" :src="url" :zoom-rate="1.2" :preview-src-list="[url]"
                            :fit="fit" />
                    </div>
                    <div v-else class="unview-file">
                        当前文件类型不可预览，请下载文件
                    </div>
                </div>
            </slot>
        </div>
    </el-dialog>
</template>

<script>
import eagleImage from "./eagle-image.vue";
export default {
    components: { eagleImage },
    name: "fileViewer",
    props: {
        ownLoad: {
            type: Boolean,
            default: true,
        },
        isReport: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            fileList: [],
            url: "",
            pdfUrl: "",
            sourceUrl: "",
            open: false,
            width: "1000px",
            title: "文件浏览",
            attExt: "",
            isImage: false,
            isPdf: false,
            fit: "contain",
            fileName: "",
            checkList: [],
            fileType: '0',
            loading:false
        };
    },
    computed: {
        isLib() {
            return this.url && this.url.indexOf("lib") >= 0;
        },
    },
    filters: {},
    created() { },
    methods: {
        toView(file) {
            let { attFilePath, attExt, name } = file;
            let fileType = name?.split(".").pop();
            if (fileType == 'pdf' || fileType == 'PDF') {
                localStorage.removeItem("pdfjs.history");
                this.fileType = '1';
            } else if (fileType == 'jpg' || fileType == 'png' || fileType == 'jpeg') {
                this.fileType = '2';
            } else {
                this.fileType = '3';
            }
            this.url = attFilePath;
        },
        show(config) {
            this.fileList = config.fileList || [];
            if(!!this.fileList?.length){
                this.url=this.fileList[0].attFilePath;
                this.toView(this.fileList[0])
            }
            this.title = config.title || "文件浏览";
            this.open = true;
        },
        downSource() {
            if (!this.checkList || !this.checkList?.length) {
                this.$message.error('暂无文件可导出');
                return;
            }
            let downLoadFiles = [];
            this.checkList.forEach(item => {
                let file = this.fileList.find(file => file.attFilePath == item);
                downLoadFiles.push(file);
            });
            this.loading=true;
            let downloadedFiles = 0;
            downLoadFiles.forEach(file => {
                const a = document.createElement("a");
            fetch(file.attFilePath)
                .then((res) => {
                    if(!res.ok){
                        this.$message.error(`${file.name}文件不存在或下载失败`);
                        throw new Error('文件下载失败'); 
                    }
                    return res.blob()                                       
                })
                .then((blob) => {
                    a.href = URL.createObjectURL(blob);
                    a.download = file.name; // 下载文件的名字
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    downloadedFiles++;
                    if(downloadedFiles == downLoadFiles.length){
                        this.loading=false;
                    }
                }).catch((err)=>{
                    downloadedFiles++;
                    if(downloadedFiles == downLoadFiles.length){
                        this.loading=false;
                    }
                })
            });
        },
        cancel() {
            this.$refs.eaglePdfView?.handleClose();
            this.checkList = [];
            this.url = '';
            this.fileType = '0';
             this.loading=false;
            this.open = false;
            this.checkList = [];
            this.url = '';
            this.fileType = '0';
             this.loading=false;
        },
    },
};
</script>

<style lang="scss"  scoped>
.dialog-botton {
    color: #409eff;
}

.dialog-title {
    display: flex;
    justify-content: space-between;
    width: 930px;
    margin-right: 30px;
}

// .btnMargin {
//     margin-top: -15px;
// }
.pdf-dialog .el-dialog__header {
    background: #000;
    color: #fff;
    height: 48px;
    overflow: hidden;
}

::v-deep .pdf-dialog .el-dialog__body {
    padding: 0px;
}

// .dialog-btn {
//     float: right;
//     margin-right: 30px;
// }

.pdf-view {
    // height: 600px;
    // overflow: auto;
    height: 100%;
}

.avatar {
    margin: 0 auto;
    display: inherit;
    max-height: 600px;
}

.imageClass {
    max-width: 100%;
    max-height: 490px;
    position: absolute;
    top: 50px;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    display: block;
}

.file-container {
    display: flex;
    height: 100%;
    width: 100%;
}

.file-list {
    width: 300px;
    padding: 16px;
    border-right: 1px solid #ccc;

    .el-checkbox {
        width: 100%;
        display: flex;
        align-items: center;
    }

    .fileName {
        display: block;
        height: 100%;
        width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .isview {
        font-weight: 600;
        color: #1b76d1;
    }
}

.file-view {
    flex: 1;
}

.unview-file {
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: 600;
    width: 100%;
    height: 100%;
    font-size: 24px;
}
::v-deep .el-checkbox{
    margin-bottom:8px;
}
::v-deep .el-checkbox__input.is-checked+.el-checkbox__label {
    color: #606266;
}

::v-deep .el-checkbox__input.is-checked .el-checkbox__inner {
    background-color: #1b76d1;
    border-color: #1b76d1;
}
</style>