<template>
    <el-form-item :label="label" :prop="prop" :label-width="labelWidth" :required="required" :rules="rulesArray">
        <div class="eagle-image">
            <div v-if="isEdit || (imageUrls && imageUrls.length>0)" class="img-pannel">
                <div v-for="(item,index) in imageUrls" :key="index" class="img-content">
                    <template v-if="showImgCount<=0 || index<showImgCount">
                        <img :src="item" class="avatar" />
                        <span class="el-upload-list__item-actions">
                            <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(item)">
                                <i class="el-icon-zoom-in"></i>
                            </span>
                            <span v-if="!disabled && isEdit" class="el-upload-list__item-delete" @click="removeImg(index)">
                                <i class="el-icon-delete"></i>
                            </span>
                        </span>
                    </template>
                </div>
                <div v-if="imageUrls.length<count  && isEdit && !disabled " class="img-content">
                    <el-upload class="avatar-uploader" ref="elUpload" :multiple="multiple" :action="uploadUrl" :show-file-list="false" :on-remove="handleRemove" :on-change="handleChange" :on-error="handleError" :on-success="handleAvatarSuccess" :headers="headers" :before-upload="beforeAvatarUpload">
                        <i class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </div>
            </div>
            <div v-else-if="showDefaultImg && isEdit==false" class="img-pannel">
                <div class="img-content">
                    <img :src="defaultUrl" class="avatar" />
                </div>
            </div>
        </div>
        <el-dialog title="图片预览" v-dialogDrag :visible.sync="dialogVisible" width="500px" append-to-body show-close custom-class="imag-dialog">
            <img width="100%" :src="dialogImageUrl" alt="">
        </el-dialog>
    </el-form-item>
</template>
<script>
import { getToken } from "@/utils/auth";
export default {
    name: "eagle-image",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },

        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        required: {
            type: Boolean,
            default() {
                return false;
            },
        },
        count: {
            type: Number,
            default() {
                return 3;
            },
        },
        value: {
            type: String,
            default() {
                return "";
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        showDefaultImg: {
            type: Boolean,
            default() {
                return false;
            },
        },
        showImgCount: {
            type: Number,
            default() {
                return 0;
            },
        },
        fileSize: {
            type: Number,
            default() {
                return 0;
            },
        },
        multiple: {
            type: Boolean,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload", // 上传的图片服务器地址
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            imageUrls: [],
            dialogImageUrl: "",
            dialogVisible: false,
            rulesArray: [],
            defaultUrl: require("@/assets/images/no-img.png"),

            imageVals: [],

            //imageUrl: this.value,
        };
    },

    watch: {
        value(nval, oval) {
            if (nval != oval) {
                this.imageUrls = !nval ? [] : this.value.split(";");
            }
        },
        imageUrls(nval, oval) {
            this.$emit("input", nval.join(";"));
        },
    },
    created() {
        this.imageUrls = !this.value ? [] : this.value.split(";");
        this.setRules();
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请上传" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleRemove(file, fileList) {},
        handleError(err, file, fileList) {},
        handleChange(event, file, fileList) {},
        handlePictureCardPreview(url) {
            this.dialogImageUrl = url;
            this.dialogVisible = true;
        },
        removeImg(index) {
            this.imageUrls.splice(index, 1);
            // if (this.$refs.elUpload) this.$refs.elUpload.clearFiles();
        },
        handleAvatarSuccess(res, file, fileList) {
            if (res.code == 200) {
                if (this.imageUrls.length < this.count) {
                    this.imageUrls.push( res.data.filePath);
                }
            } else {
                this.$message.error("图片上传失败!");
            }
        },
        beforeAvatarUpload(file) {
            if (this.imageUrls.length > this.count) {
                file.abort();
            }
            const isJPG = file.type === "image/jpeg";
            const isPNG = file.type === "image/png";
            const isHEIC = file.type === "image/heic";
           
            if (!isPNG && !isJPG && !isHEIC) {
                this.$message.error("格式不符");
                return false;
            }
            if (this.fileSize && this.fileSize > 0) {
                 const isLtSize = file.size / 1024 / 1024 < this.fileSize;
                 if (!isLtSize) {
                    this.$message.error("大小超过限制");
                    return false;
                }
            }
            return true;
        },
        onExceed(files, fileList) {
            this.$message.warning(
                `当前限制选择 ${this.count} 个文件，本次选择了 ${
                    files.length
                } 个文件，共选择了 ${files.length + fileList.length} 个文件`
            );
        },
    },
};
</script>
<style lang="scss" scoped>
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
.avatar-uploader .el-upload:hover {
    border-color: #409eff;
}
.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    background-color: #fbfdff;
    border: 1px dashed #c0ccda;
    border-radius: 6px;
    width: 110px;
    height: 110px;
    line-height: 110px;
    text-align: center;
}
.avatar {
    width: 110px;
    height: 110px;
    display: block;
    border-radius: 6px;
    padding: 2px;
    background: #fff;
}
.img-pannel {
    display: flex;
    flex-wrap: wrap;
    .img-content {
        margin: 5px;
        display: flex;
        position: relative;
        display: block;
        text-align: center;
        .icon {
            opacity: 0.5;
            width: 101px;
            background-color: #d9d9d9;
            position: absolute;
            bottom: 0px;
            color: red;
            cursor: pointer;
        }
    }
}
.img-content .el-upload-list__item-actions {
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    cursor: default;
    text-align: center;
    color: #fff;
    opacity: 0;
    font-size: 20px;
    background-color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    line-height: 110px;
    border-radius: 6px;
}

.img-content .el-upload-list__item-actions:hover {
    opacity: 1;
}
.img-content .el-upload-list__item-actions:hover span {
    display: inline-block;
}
.img-content .el-upload-list__item-actions .el-upload-list__item-delete {
    position: static;
    font-size: inherit;
    color: inherit;
    margin-left: 3px;
}
.imag-dialog .el-dialog__body {
    padding: 0;
}
</style>