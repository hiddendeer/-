<template>
    <div class="app-container">
        <eagle-condition style="margin-top: 10px;margin-bottom:10px;" @search="search()" :showReset="false">
            <eagle-year label="年度" type="years" @change="search()" v-model="conditions.year" />
        </eagle-condition>
        <el-row :gutter="10" class="parameter_left">
            <div class="parameter_con_left">
                <el-card shadow="never">
                    <div class="parameter_title">
                        <span>一企一档</span>
                    </div>
                    <!-- <el-card shadow="never" class="parameter_risk" :body-style="{padding:'15px 5px 20px 10px'}">
                        <div class="parameter_risk_tit">关键风险点</div>
                        <ul class="parameter_risk_poi">
                            <li v-for="(item,index) of riskPoint" :key="index" class="parameter_risk_poi_li">
                                <img class="parameter_r_img" :src="item.setUrl" alt="">
                                <span class="parameter_r_span">{{item.name}}</span>
                            </li>
                        </ul>
                    </el-card> -->

                    <el-row :gutter="10" class="parameter_con_center">
                        <el-card shadow="never" class="parameter_content">
                            <div class="parameter_content_tit">
                                <img src="../../../src/assets/images/homePageImg/organizationalStructure_tit.png" alt="">
                                <span>组织架构图</span>
                            </div>
                            <div class="parameter_content_pot">
                                <img src="../../../src/assets/images/homePageImg/organizationalStructure_con.png" alt="">
                            </div>
                            <div class="parameter_content_num">
                                <div class="parameter_content_num_x">
                                    <span>{{dataListLeft.enterpriseNum || 0}}</span>
                                    <span>个</span>
                                </div>
                                <!-- <img :src="isImg" alt=""> -->
                            </div>
                        </el-card>

                        <el-card shadow="never" class="parameter_content">
                            <div class="parameter_content_tit">
                                <img src="../../../src/assets/images/homePageImg/productionProcess_tit.png" alt="">
                                <span>生产工艺</span>
                            </div>
                            <div class="parameter_content_pot">
                                <img src="../../../src/assets/images/homePageImg/productionProcess_con.png" alt="">
                            </div>
                            <div class="parameter_content_num">
                                <div class="parameter_content_num_x">
                                    <span>{{dataListLeft.processNum || 0}}</span>
                                    <span>幅</span>
                                </div>
                                <!-- <img :src="isImg" alt=""> -->
                            </div>
                        </el-card>

                        <el-card shadow="never" class="parameter_cen_right">
                            <div class="warningInformation">预警信息</div>
                            <div class="certificate">
                                <span></span>
                                <span>证书即将过期:</span>
                                <span>5</span>
                                <span>个</span>
                            </div>
                            <div class="equipment">
                                <span></span>
                                <span>特种设备即将过期:</span>
                                <span>5</span>
                                <span>台</span>
                            </div>
                        </el-card>
                    </el-row>

                    <div class="jobsList">
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[0].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[0].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.certificateNum || 0}}</span>
                                    <span>{{certificate[0].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[1].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[1].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.buildNum || 0}}</span>
                                    <span>{{certificate[1].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[2].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[2].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.workNum || 0}}</span>
                                    <span>{{certificate[2].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[3].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[3].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.equipmentNum || 0}}</span>
                                    <span>{{certificate[3].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[4].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[4].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.materialNum || 0}}</span>
                                    <span>{{certificate[4].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[5].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[5].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.spaceNum || 0}}</span>
                                    <span>{{certificate[5].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                        <div class="jobsList_li">
                            <el-card shadow="never" class="jobsList_li_card">
                                <div class="jobsList_li_img">
                                    <img :src="certificate[6].setImg" alt="">
                                </div>
                                <div class="jobsList_li_content">
                                    {{certificate[6].name}}
                                </div>
                                <div class="jobsList_li_num">
                                    <span>{{dataListLeft.relationNum || 0}}</span>
                                    <span>{{certificate[6].unit}}</span>
                                </div>
                            </el-card>
                        </div>
                    </div>
                </el-card>
            </div>
            <div class="parameter_con_right">
                <div class="parameter_con_right_top">
                    <el-card shadow="never" class="targetResponsibility">
                        <div class="target_tit">
                            <span>目标职责</span>
                        </div>
                        <ul class="responsibility">
                            <li class="responsibility_li">
                                <span></span>
                                <span>{{responsibilityList[0].name}}:</span>
                                <span>0</span>
                                <span>{{responsibilityList[0].unit}}</span>
                            </li>
                            <li class="responsibility_li">
                                <span></span>
                                <span>{{responsibilityList[1].name}}:</span>
                                <span>{{dataListRight.deptResponseNum || 0}}</span>
                                <span>{{responsibilityList[1].unit}}</span>
                            </li>
                            <li class="responsibility_li">
                                <span></span>
                                <span>{{responsibilityList[2].name}}:</span>
                                <span>{{dataListRight.postResponseNum || 0}}</span>
                                <span>{{responsibilityList[2].unit}}</span>
                            </li>
                            <li class="responsibility_li">
                                <span></span>
                                <span>{{responsibilityList[3].name}}:</span>
                                <span>{{dataListRight.meetingNum || 0}}</span>
                                <span>{{responsibilityList[3].unit}}</span>
                            </li>
                        </ul>
                    </el-card>
                    <el-card shadow="never" class="systemManagement">
                        <div class="systemManagement_tit">
                            <span>制度化管理</span>
                        </div>
                        <div class="systemManagement_cer">
                            <span></span>
                            <span>生成规章制度:</span>
                            <span>{{dataListRight.rulesNum || 0}}</span>
                            <span>份</span>
                        </div>
                        <!-- <div class="systemManagement_cer">
                            <span></span>
                            <span>生成适用法律法规:</span>
                            <span>0</span>
                            <span>份</span>
                        </div> -->
                    </el-card>
                </div>

                <el-card shadow="never" class="fundsManagement">
                    <div class="fundsManagement_tit">
                        <span>制度化管理</span>
                    </div>
                    <div class="fundsManagement_con">
                        <div class="fundsManagement_con_plan">
                            <div class="funds_con_plan">年度计划安全费用</div>
                            <div class="funds_con_money">{{formatCurrency(dataListRight.plan_cost || 0)}} <span>元</span> </div>
                        </div>
                        <div class="fundsManagement_con_actual">
                            <div class="funds_con_plan">年度实际提取费用</div>
                            <div class="funds_con_money">{{formatCurrency(dataListRight.real_cost || 0)}} <span>元</span></div>
                        </div>
                    </div>
                </el-card>

                <div class="training_bottom">

                    <el-card shadow="never" class="training_bottom_left">
                        <div class="training_l_tit">
                            <img src="../../../src/assets/images/homePageImg/plannedTraining_tit.png" alt="">
                            <span>计划性培训</span>
                        </div>
                        <!-- <div id="myChart" style="height:300px;"></div> -->

                        <div id="myChart" style="height:230px; width:100%;"></div>
                    </el-card>
                    <el-card shadow="never" class="training_bottom_right">
                        <div class="training_r_tit">
                            <img src="../../../src/assets/images/homePageImg/levelSafety_tit.png" alt="">
                            <span>三级安全培训</span>
                        </div>
                        <div class="training_r_cont">
                            <span></span>
                            <span>累计培训记录:</span>
                            <span>{{dataListRight.three_count}}</span>
                            <span>份</span>
                        </div>
                    </el-card>
                </div>
            </div>
        </el-row>
    </div>
</template>

<script>
import * as echarts from "echarts";

export default {
    name: "host-standing-page",
    data() {
        return {
            isImg: "",
            //关键风险点
            riskPoint: [
                {
                    setUrl: require("../../../src/assets/images/homePageImg/riskLimitedSpace.png"),
                    name: "有限空间",
                },
                {
                    setUrl: require("../../../src/assets/images/homePageImg/riskChemicals.png"),
                    name: "危险化学品",
                },
                {
                    setUrl: require("../../../src/assets/images/homePageImg/riskSpraying.png"),
                    name: "喷涂场所",
                },
            ],
            //岗位列表
            certificate: [
                {
                    name: "特殊岗位证书",
                    setImg: require("../../../src/assets/images/homePageImg/specialPostCertificate_con.png"),
                    unit: "个",
                },
                {
                    name: "建构筑物",
                    setImg: require("../../../src/assets/images/homePageImg/building_con.png"),
                    unit: "栋",
                },
                {
                    name: "作业岗位",
                    setImg: require("../../../src/assets/images/homePageImg/workPost_con.png"),
                    unit: "个",
                },
                {
                    name: "设备设施",
                    setImg: require("../../../src/assets/images/homePageImg/facilities_con.png"),
                    unit: "台",
                },
                {
                    name: "生产原辅料",
                    setImg: require("../../../src/assets/images/homePageImg/rawMaterials_con.png"),
                    unit: "种",
                },
                {
                    name: "有限空间",
                    setImg: require("../../../src/assets/images/homePageImg/limitedSpace_con.png"),
                    unit: "个",
                },
                {
                    name: "相关方",
                    setImg: require("../../../src/assets/images/homePageImg/relatedParty_con.png"),
                    unit: "个",
                },
            ],
            //目标职责
            responsibilityList: [
                {
                    name: "安全生产基本文书",
                    num: 12,
                    unit: "份",
                },
                {
                    name: "安全生产目标责任书",
                    num: 12,
                    unit: "份",
                },
                {
                    name: "安全生产责任制",
                    num: 12,
                    unit: "岗位",
                },
                {
                    name: "安全生产会议",
                    num: "1/4",
                    unit: "（计划）",
                },
            ],
            //echarts
            yAxisList: ["实际", "计划"],
            histogramList: [],
            conditions: {
                year: new Date().getFullYear(),
            },
            companyCode: "",
            dataListLeft: {
                enterpriseNum: 0,
            },
            dataListRight: { plan_count: 0, real_count: 0 },
        };
    },
    created() {
        let getCompanyCode = JSON.parse(localStorage.getItem("user"));
        this.companyCode = getCompanyCode.companyCode;
    },
    mounted() {
        this.getEnterpriseList_l();
        this.getEnterpriseList_r();
    },
    methods: {
        formatCurrency(num, withcents) {
            var originnum = num;
            num = num.toString().replace(/\$|\,/g, "");
            if (isNaN(num)) {
                num = "0";
            }
            var sign = num == (num = Math.abs(num));
            num = Math.floor(num * 100 + 0.50000000001);
            var cents = num % 100;
            num = Math.floor(num / 100).toString();
            if (cents < 10) {
                cents = "0" + cents;
            }
            for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
                num =
                    num.substring(0, num.length - (4 * i + 3)) +
                    "," +
                    num.substring(num.length - (4 * i + 3));
            }
            var rs = (sign ? "" : "-") + num + "." + cents;
            if (!withcents && parseInt(originnum) == parseFloat(originnum)) {
                return rs.split(".")[0];
            } else {
                return rs;
            }
        },
        search() {
            this.getEnterpriseList_r();
        },
        getEnterpriseList_l() {
            var _this = this;
            var url =
                "/ecologyEnv/siteInfoStatistics/getArchivesData?companyCode=" +
                _this.companyCode;
            _this.http.get(url).then((res) => {
                if (res.data) {
                    _this.dataListLeft = res.data;
                }
            });
        },
        getEnterpriseList_r() {
            var _this = this;
            var url =
                "/ecologyEnv/siteInfoStatistics/getResponseData?companyCode=" +
                _this.companyCode +
                "&year=" +
                _this.conditions.year;
            _this.http.get(url).then((res) => {
                _this.dataListRight = res.data;

                _this.histogramList.push(_this.dataListRight.real_count);
                _this.histogramList.push(_this.dataListRight.plan_count);
                _this.$nextTick(function () {
                    _this.drawChart();
                });
            });
        },
        drawChart() {
            let name = document.getElementById("myChart");
            let myEchart = echarts.init(name);

            let option = {
                title: { show: false },
                grid: {
                    show: false,
                },
                tooltip: {
                    trigger: "axis",
                    formatter: function (params) {
                        return params[0].data + "次";
                    },
                },
                legend: {
                    show: false,
                },

                xAxis: {
                    type: "value",
                    data: [30, 60, 90, 120, 150],
                },
                yAxis: {
                    type: "category",
                    data: this.yAxisList,
                },
                series: [
                    {
                        type: "bar",
                        label: {
                            show: true,
                            position: "inside",
                            formatter: "{c0}次",
                            color: "#fff",
                            fontSize: "16px",
                        },
                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    // 柱状图颜色
                                    var colorList = ["#6CBDF8", "#8FCD4E"];
                                    return colorList[params.dataIndex];
                                },
                            },
                        },
                        //柱状图宽度
                        barWidth: "70%",
                        //柱状图数据
                        data: this.histogramList,
                    },
                ],
            };
            myEchart.setOption(option);
        },
    },
};
</script>
<style lang="scss" scoped>
.parameter_left {
    display: flex;
    flex-direction: row;
    column-gap: 10px;
    .parameter_con_left {
        min-width: 700px;
        max-width: 700px;
    }
    .parameter_title {
        margin-bottom: 10px;
        span {
            font-size: 19px;
            font-weight: 900;
        }
    }
    .parameter_risk {
        margin-bottom: 10px;
        &_tit {
            font-size: 16px;
            font-weight: 900;
        }
        &_poi {
            display: flex;
            list-style: none;

            &_li {
                display: flex;
                width: 27%;
                // flex: 1;
                // justify-content: space-around;
                .parameter_r_img {
                    width: 60px;
                    height: 60px;
                    border-radius: 5px;
                    background-size: 100% 100%;
                }
                .parameter_r_span {
                    width: 50%;
                    margin: 10% 5%;
                    color: #a19bcf;
                }
            }
        }
    }
    .parameter_con_center {
        display: flex;
        flex-wrap: wrap;
        align-content: space-between;
        margin-left: 0px !important;
        margin-right: 0px !important;
        .parameter_content {
            display: flex;
            height: 200px;
            width: 165px;
            margin-right: 10px;
            &_tit {
                display: flex;
                img {
                    width: 25px;
                    height: 25px;
                }
                span {
                    margin-left: 10px;
                    font-size: 16px;
                    font-weight: 600;
                }
            }
            &_pot {
                justify-content: center;
                align-items: center;
                img {
                    width: 100px;
                    height: 100px;
                    margin: 10px 0;
                }
            }
            &_num {
                display: flex;
                justify-content: space-between;
                margin: 0 10px;
                &_x {
                    span:nth-of-type(1) {
                        font-size: 18px;
                        color: #332aa6;
                        font-weight: 700;
                    }
                    span:nth-of-type(2) {
                        color: #a19bcf;
                        font-weight: 600;
                    }
                }
                img {
                    width: 12%;
                    height: 12%;
                }
            }
        }
        .parameter_cen_right {
            display: flex;
            flex-direction: column;
            height: 200px;
            width: 308px;
            .warningInformation {
                font-size: 16px;
                font-weight: 900;
                margin-left: 10px;
            }
            .certificate {
                margin-left: 5%;
                height: 9.2vh;
                line-height: 9.2vh;
                span:nth-of-type(1) {
                    width: 8px;
                    height: 8px;
                    background: rgb(8, 235, 8);
                    display: inline-block;
                    border-radius: 50%;
                    margin-bottom: 0.2vh;
                }
                span:nth-of-type(2) {
                    display: inline-block;
                    margin-left: 4%;
                    font-size: 15px;
                    color: rgb(148, 143, 143);
                    font-weight: 600;
                }
                span:nth-of-type(3) {
                    display: inline-block;
                    margin-left: 4%;
                    font-size: 22px;
                    font-weight: 600;
                    color: rgb(245, 11, 11);
                }
                span:nth-of-type(4) {
                    display: inline-block;
                    margin-left: 4%;
                    font-size: 14px;
                    font-weight: 600;
                    color: #6860cf;
                }
            }
            .equipment {
                height: 9vh;
                line-height: 7vh;
                margin-left: 5%;
                span:nth-of-type(1) {
                    width: 8px;
                    height: 8px;
                    background: rgb(235, 212, 8);
                    display: inline-block;
                    border-radius: 50%;
                    margin-bottom: 0.2vh;
                }
                span:nth-of-type(2) {
                    display: inline-block;
                    margin-left: 4%;
                    font-size: 15px;
                    color: rgb(148, 143, 143);
                    font-weight: 600;
                }
                span:nth-of-type(3) {
                    display: inline-block;
                    margin-left: 4%;
                    font-size: 22px;
                    font-weight: 600;
                    color: rgb(245, 11, 11);
                }
                span:nth-of-type(4) {
                    display: inline-block;
                    margin-left: 4%;
                    font-size: 14px;
                    font-weight: 600;
                    color: #6860cf;
                }
            }
        }
    }
    .jobsList {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        margin-top: 10px;
        gap: 10px;
        &_li {
            display: flex;
            width: 130px;
            &_card {
                width: 100%;
                .jobsList_li_img {
                    text-align: center;
                    img {
                        width: 60px;
                        height: 60px;
                        margin: 10% 0;
                        border-radius: 5%;
                    }
                }
                .jobsList_li_content {
                    text-align: center;
                    color: #a19bcf;
                    font-weight: 600;
                    margin: 3% 0;
                    font-size: 10%;
                }
                .jobsList_li_num {
                    text-align: center;
                    span:nth-of-type(1) {
                        font-size: 16px;
                        font-weight: 700;
                        color: #332aa6;
                    }
                    span:nth-of-type(2) {
                        color: #a19bcf;
                        font-weight: 600;
                    }
                }
            }
        }
    }
    .parameter_con_right {
        flex: 1;
        display: flex;
        flex-direction: column;
        &_top {
            display: flex;
            .targetResponsibility {
                width: 60%;
                height: 230px;
                .target_tit {
                    span {
                        font-size: 16px;
                        font-weight: 800;
                    }
                }
                .responsibility {
                    float: left;
                    list-style: none;
                    font-size: 10%;
                    width: 100%;
                    &_li {
                        line-height: 36px;
                        span:nth-of-type(1) {
                            width: 8px;
                            height: 8px;
                            background: rgb(8, 235, 8);
                            display: inline-block;
                            border-radius: 50%;
                            margin-bottom: 0.2vh;
                        }
                        span:nth-of-type(2) {
                            display: inline-block;
                            margin-left: 3%;
                            font-size: 15px;
                            color: rgb(148, 143, 143);
                            font-weight: 600;
                        }
                        span:nth-of-type(3) {
                            display: inline-block;
                            margin-left: 1%;
                            font-size: 25px;
                            font-weight: 600;
                            color: #3f3684;
                        }
                        span:nth-of-type(4) {
                            display: inline-block;
                            margin-left: 1%;
                            font-size: 14px;
                            font-weight: 600;
                            color: #6860cf;
                        }
                    }
                }
            }

            .systemManagement {
                width: 40%;
                height: 230px;
                margin-left: 10px;
                margin-right: 10px;
                .systemManagement_tit {
                    span {
                        font-size: 16px;
                        font-weight: 800;
                    }
                }
                .systemManagement_cer {
                    height: 7vh;
                    line-height: 11vh;
                    margin-left: 5%;
                    span:nth-of-type(1) {
                        width: 8px;
                        height: 8px;
                        background: rgb(8, 235, 8);
                        display: inline-block;
                        border-radius: 50%;
                        margin-bottom: 0.2vh;
                    }
                    span:nth-of-type(2) {
                        display: inline-block;
                        margin-left: 4%;
                        font-size: 15px;
                        color: rgb(148, 143, 143);
                        font-weight: 600;
                    }
                    span:nth-of-type(3) {
                        display: inline-block;
                        margin-left: 4%;
                        font-size: 25px;
                        font-weight: 600;
                        color: #3f3684;
                    }
                    span:nth-of-type(4) {
                        display: inline-block;
                        margin-left: 4%;
                        font-size: 14px;
                        font-weight: 600;
                        color: #6860cf;
                    }
                }
            }
        }

        .fundsManagement {
            // width: 41.7vw;
            margin: 10px 10px 10px 0px;
            background: #f0f8ff;
            &_tit {
                span {
                    font-size: 16px;
                    font-weight: 800;
                }
            }
            &_con {
                display: flex;
                justify-content: space-around;
                &_plan {
                    .funds_con_plan {
                        font-size: 14px;
                        font-weight: 600;
                        margin: 10px 0;
                        text-align: center;
                    }
                    .funds_con_money {
                        font-size: 22px;
                        font-weight: 600;
                        color: #52b7f5;
                        text-align: center;
                        span {
                            font-size: 15px;
                        }
                    }
                }
                &_actual {
                    .funds_con_plan {
                        font-size: 14px;
                        font-weight: 600;
                        margin: 10px 0;
                        text-align: center;
                    }
                    .funds_con_money {
                        font-size: 22px;
                        font-weight: 600;
                        color: #8fcd4e;
                        text-align: center;
                        span {
                            font-size: 15px;
                        }
                    }
                }
            }
        }

        .training_bottom {
            display: flex;
            &_left {
                width: 60%;
                height: 233px;
                .training_l_tit {
                    display: flex;
                    text-align: center;
                    width: 20vw;
                    img {
                        width: 25px;
                        height: 25px;
                    }
                    span {
                        font-size: 16px;
                        font-weight: 900;
                        margin-left: 3%;
                    }
                }
                #main {
                    width: 20vw;
                    height: 22vh;
                    top: -3vh;
                }
            }
            &_right {
                width: 39%;
                height: 233px;
                margin-left: 10px;
                margin-right: 10px;
                .training_r_tit {
                    display: flex;
                    text-align: center;
                    width: 20vw;
                    img {
                        width: 25px;
                        height: 25px;
                    }
                    span {
                        font-size: 16px;
                        font-weight: 900;
                        margin-left: 3%;
                    }
                }
                .training_r_cont {
                    height: 15vh;
                    line-height: 15vh;
                    margin-left: 7%;
                    span:nth-of-type(1) {
                        width: 8px;
                        height: 8px;
                        background: rgb(235, 212, 8);
                        display: inline-block;
                        border-radius: 50%;
                        margin-bottom: 0.2vh;
                    }
                    span:nth-of-type(2) {
                        display: inline-block;
                        margin-left: 4%;
                        font-size: 15px;
                        color: rgb(148, 143, 143);
                        font-weight: 600;
                    }
                    span:nth-of-type(3) {
                        display: inline-block;
                        margin-left: 4%;
                        font-size: 22px;
                        font-weight: 600;
                        color: #3f3684;
                    }
                    span:nth-of-type(4) {
                        display: inline-block;
                        margin-left: 4%;
                        font-size: 14px;
                        font-weight: 600;
                        color: #6860cf;
                    }
                }
            }
        }
    }
}
</style>