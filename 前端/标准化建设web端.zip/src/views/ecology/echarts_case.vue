<template>
    <div :id="ids"></div>
</template>
<script>
import * as echarts from "echarts";
export default {
    props: {
        ids: {
            type: String,
            default() {
                return "";
            }
        },
        yAxisList: {
            type: Array,
            default() {
                return [];
            }
        },
        histogramList: {
            type: Array,
            default() {
                return [];
            }
        },
        title: {
            type: String,
            default() {
                return "";
            }
        }
    },
    data() {
        return {};
    },
    mounted() {
        this.drawChart();
    },
    methods: {
        drawChart() {
            let myEchart = echarts.init(document.getElementById(this.ids));
            // debugger;
            let option = {
                title: {
                    text: this.title
                },
                grid: {
                    left: "11%",
                    top: "25%",
                    right: "14%",
                    bottom: "30%",
                    containLabel: false
                },
                tooltip: {
                    trigger: "axis",
                    formatter: function (params) {
                        return params[0].data + "次";
                    }
                },
                legend: {
                    show: false
                },

                xAxis: {
                    type: "value",
                    data: [30, 60, 90, 120, 150]
                    // axisLabel: {
                    //     interval: 0,    //强制文字产生间隔
                    //     rotate: 45,     //文字逆时针旋转45°
                    //     textStyle: {    //文字样式
                    //         color: "black",
                    //         fontSize: 16,
                    //         fontFamily: 'Microsoft YaHei'
                    //     }
                    // }
                },
                yAxis: {
                    type: "category",
                    data: this.yAxisList
                },
                series: [
                    {
                        type: "bar",
                        label: {
                            show: true,
                            position: "inside",
                            formatter: "{c0}次",
                            color: "#fff",
                            fontSize: "16px"
                        },
                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    // 柱状图颜色
                                    var colorList = ["#6CBDF8", "#8FCD4E"];
                                    return colorList[params.dataIndex];
                                }
                            }
                        },
                        //柱状图宽度
                        barWidth: "70%",
                        //柱状图数据
                        data: this.histogramList
                    }
                ]
            };
            myEchart.setOption(option);
        }
    },
    beforeDestroy() { },
    components: {}
};
</script>

<style scoped>
</style>
