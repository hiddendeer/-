<template name="danger-template-detail">
    <div class="danger-template-detail">
        <eagle-form :is-edit="false" :form="form" width="1000px" label-width="120px" ref="EagleForm" @bindData="bindData">
            <eagle-block border>
                <eagle-input label="名称" :is-edit="isEdit" prop="title" v-model="form.title" />
                <eagle-input label="检查说明" :is-edit="isEdit" prop="remarks" type="textarea" :row="2" v-model="form.remarks" />

                <el-row>
                    <div style="max-height:500px;overflow:auto">
                        <table class="form-table">
                            <thead>
                                <tr>
                                    <th width="80px" style="text-align: center;">
                                        <div class="cell">序号</div>
                                    </th>
                                    <th style="text-align: center;">
                                        <div class="cell">检查内容</div>
                                    </th>
                                    <!-- <th style="text-align: center;" width="280px">
                                    <div class="cell">操作</div>
                                </th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <template v-for="(item,index) in form.itemGroups">
                                    <tr :key="index" class="group">
                                        <td>{{index+1}}</td>
                                        <td class="item-title">
                                            <span>{{item.groupTitle}}</span>
                                        </td>
                                        <!-- <td>
                                    </td> -->
                                    </tr>
                                    <template v-for="(citem,cindex) in item.items">
                                        <tr :key="index+'_'+cindex">
                                            <td>{{index+1}}.{{cindex+1}}</td>
                                            <td class="item-title">
                                                <span>{{citem.itemName}}</span>
                                            </td>
                                            <!-- <td>
                                            <el-button size="mini" slot="append" icon="el-icon-folder-opened" @click="handleShowItem(citem)"></el-button>
                                        </td> -->
                                        </tr>
                                    </template>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </el-row>
            </eagle-block>
        </eagle-form>
    </div>
</template>



<script>
export default {
    name: "danger-template-detail",
    props: {},

    data() {
        return {
            isEdit: false,
            params: { opType: [], hidden_danger_type: [] },
            visible: false,
            form: {},
        };
    },
    methods: {
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.site_danger_template_op,
                    _this.constParams.hidden_danger_type,
                ],
                function (res) {
                    _this.params.opType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.site_danger_template_op
                    );
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        bindData(data) {
            this.form = data;
        },
        show(config) {
            let _this = this;
            _this.$refs.EagleForm.handleUpdate(
                {},
                {
                    title: "安全检查表详情",
                    url: `ecologyEnv/dangerTemplate/getTemplateItems?templateCode=${config.code}`,
                }
            );
        },
    },
};
</script>


<style type="text/css">
.form-table {
    background-color: #dfe6ec;
    width: 100%;
    text-align: center;
}

.form-table tr,
.form-table th {
    border: none;
    background-color: #f8f8f9;
    height: 50px;
    line-height: 50px;
}

.form-table td {
    border: none;
    background-color: #ffffff;
    height: 50px;
    line-height: 22px;
}

.form-table .group td {
    background-color: #d2e2e870;
}
.item-title {
    text-align: left;
}

.item-title span {
    margin: 10px !important;
}
</style>