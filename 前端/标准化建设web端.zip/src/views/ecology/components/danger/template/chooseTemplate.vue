<template name="choose-template">
    <div class="choose-template">
        <el-dialog v-dialogDrag title="选择公司检查表" :visible.sync="visible" width="800px" show-close @open="initData" :close-on-click-modal="false">
            <eagle-block border>
                <eagle-page :queryParams="queryParams" table-height="500" :controller="controller" ref="EaglePage" showCheck selectTextField="title">
                    <!-- <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-select label-width="120px" label="所属类目" @change="search()" prop="opCode" v-model="conditionsVals.opCode" :data-source="params.opType" placeholder="请选择所属类目" clearable size="small">
                        </eagle-select>
                        <eagle-input label-width="120px" label="名称" @changeEnter="search()" prop="title" v-model="conditionsVals.title" placeholder="请输入名称模糊查询" clearable size="small" />
                    </eagle-condition>
                </template> -->

                    <template slot="slot-table">
                        <el-table-column label="名称" align="left" prop="title" />
                        <el-table-column label="检查说明" align="left" prop="remarks" />
                    </template>
                </eagle-page>
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button type="into" @click="visible=false">取 消</el-button>
                <el-button type="primary" @click="confirmDialog">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    name: "choose-template",
    props: {},
    data() {
        return {
            selectValue: [],
            queryParams: {
                dataType: "list",
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                opCode: "=",
                title: "like",
            },
            // 查询条件
            conditionsVals: {
                opCode: null,
                title: "",
            },
            controller: "ecologyEnv/dangerTemplate", //对应后端控制器
            title: "选择公司检查表",
            checkList: false,
            visible: false,
            params: {
                opType: [],
                dangerType: [],
            },
        };
    },
    methods: {
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    _this.constParams.site_danger_template_op,
                    _this.constParams.hidden_danger_type,
                ],
                function (res) {
                    _this.params.opType = res.data.filter(
                        (p) =>
                            p.paramId ===
                            _this.constParams.site_danger_template_op
                    );
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                    _this.search();
                }
            );
        },
        confirmDialog() {
            let resultArray = [];
            let array = this.$refs.EaglePage.selection;
            array.forEach((x) => {
                resultArray.push({ code: x.code, title: x.title });
            });
            this.$emit("change", resultArray);
            this.visible = false;
        },

        show() {
            this.visible = true;
        },
        //查询
        search() {
            this.$refs.EaglePage.search({
                // url: "site/fireEquipmentType/getPageList",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },

        //查询条件重置
        resetQuery() {
            this.conditionsVals.opCode = "";
            this.conditionsVals.title = "";
            this.search();
        },

        /** 新增按钮操作 */

        resetQuery() {
            this.conditionsVals.key = "";
            this.search();
        },

        handleChoose(obj) {
            this.checkList = true;
            this.selectRow = obj;
        },
    },
};
</script>