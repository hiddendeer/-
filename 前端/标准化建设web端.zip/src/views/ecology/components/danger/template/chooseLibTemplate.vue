<template name="choose-lib-template">
    <div class="choose-lib-template">
        <!-- @open="initData" -->
        <el-dialog v-dialogDrag :title="title" :visible.sync="visible" width="800px" show-close
            :close-on-click-modal="false">
            <eagle-block border>
                <eagle-window-choose :queryParams="queryParams" table-height="500" :controller="controller" ref="EagleWindowPage"
                    select-field="code" select-text-field="title" :names.sync="names" :v-model="codes">
                    <template slot="slot-search">
                        <eagle-condition @search="search()" @resetQuery="resetQuery()">
                            <eagle-input label-width="120px" @changeEnter="search()" label="名称" prop="title"
                                v-model="conditionsVals.title" placeholder="请输入名称模糊查询" clearable size="small" />
                        </eagle-condition>
                    </template>
                    <template slot="slot-table">
                        <el-table-column label="名称" align="left" prop="title" />
                        <el-table-column label="检查说明" align="left" prop="remarks" />
                    </template>
                </eagle-window-choose>
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button type="into" @click="visible = false">取 消</el-button>
                <el-button type="primary" @click="confirmDialog">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import eagleWindowChoose from "../../../../../components/Eagle/eagle-window-choose.vue";
export default {
    components: { eagleWindowChoose },
    name: "choose-lib-template",
    props: {},
    data() {
        return {
            names: "",
            codes: "",
            queryParams: {
                dataType: "list",
                opCode: ""
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                title: "like"
            },
            // 查询条件
            conditionsVals: {
                title: ""
            },
            controller: "ecologyEnv/dangerTemplate", //对应后端控制器
            title: "选择检查表",
            checkList: false,
            visible: false,
            params: {
                // opType: [],
                dangerType: []
            }
        };
    },
    onReady() { },
    methods: {
        initData() {
            let _this = this;
            _this.$refs.EagleWindowPage.setInitCodes(this.codes, this.names);
            _this.common.getBatechParam(
                [
                    // _this.constParams.site_danger_check_task_type,
                    _this.constParams.hidden_danger_type
                ],
                function (res) {
                    // _this.params.opType = res.data.filter(
                    //   (p) => p.paramId === _this.constParams.site_danger_check_task_type
                    // );
                    _this.params.dangerType = res.data.filter(
                        p => p.paramId === _this.constParams.hidden_danger_type
                    );
                    _this.search();
                }
            );
        },
        confirmDialog() {
            let resultArray = [];
            let array = this.$refs.EagleWindowPage.selection;
            array.forEach(x => {
                resultArray.push({ code: x.code, title: x.title });
            });
            this.$emit("change", resultArray);
            this.visible = false;
        },

        show(selectValue) {
            let _this = this;
            this.names = "";
            this.codes = "";
            if (selectValue) {
                let arryName = [];
                let arryValue = [];
                selectValue.forEach(function (item) {
                    arryName.push(item.Name);
                    arryValue.push(item.ID);
                });
                this.names = arryName.join(",");
                this.codes = arryValue.join(",");
            }

            setTimeout(() => {
                //_this.search();
                _this.initData();
            });
            this.visible = true;
        },
        //查询
        search() {
            let url = "site/dangerTemplate/getLibPageList";
            this.$refs.EagleWindowPage.search({
                url: url,
                conditions: this.$refs.EagleWindowPage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                )
            });
        },

        //查询条件重置
        resetQuery() {
            this.conditionsVals.title = "";
            this.search();
        }
    }
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0px 20px;
}
</style>