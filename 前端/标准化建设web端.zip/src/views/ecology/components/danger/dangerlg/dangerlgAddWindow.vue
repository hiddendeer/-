<template name="danger-lg-add-window">
    <div class="danger-lg-add-window">
        <el-dialog v-dialogDrag :title="title" :visible.sync="visible" width="1000px" show-close
            :close-on-click-modal="false">
            <eagle-block border>
                <eagle-page :queryParams="queryParams" table-height="500" :controller="controller" ref="EaglePage" :showCheckColumn="opType == 3"
                    select-field="lgCode">
                    <template slot="slot-search">
                        <eagle-condition @search="search()" @resetQuery="resetQuery()">
                            <eagle-radio :data-source="params.ownTypes" v-model="conditionsVals.ownType"
                                @change="search()" label="归属类别" />
                            <eagle-input label-width="80px" label="筛选条件" prop="keywords"
                                v-model="conditionsVals.keywords" placeholder="请输入关键词,整改建议,检查对象进行模糊查询" clearable
                                size="small" />
                        </eagle-condition>
                    </template>
                    <template slot="slot-table">
                        <el-table-column label="关键词" align="left" prop="keyword" width="100px" />
                        <el-table-column label="整改建议" align="left" prop="correctiveAdvise" width="320px" />
                        <el-table-column label="检查对象" align="left" prop="cfullName" width="100px" />
                        <el-table-column label="适用地区" align="left" prop="applyArea" width="100px" />
                        <el-table-column label="归属类别" align="left" prop="ownType" width="100px"
                            :formatter="ownTypeFormatter" />
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button @click.stop="toDetailView(scope.row.lgCode)">详情</eagle-row-button>
                        <eagle-row-button v-if="opType === 2" @click.stop="chooseSingerConfirm(scope.row)">使用
                        </eagle-row-button>
                        <el-upload ref="elUpload" v-if="opType === 1" :limit="1" :multiple="false" :action="uploadUrl"
                            :show-file-list="false" :on-success="onUploadSuccess" :headers="headers"
                            :before-upload="onBeforeUpload">
                            <eagle-row-button @click="chooseImg(scope.row)">选择照片</eagle-row-button>
                        </el-upload>
                    </template>
                </eagle-page>
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <div style="margin-top:10px;">
                    <el-button @click="visible = false">{{ opType == 3 ? "取 消" : "关 闭" }}</el-button>
                    <el-button type="primary" v-if="opType == 3" @click="confirmDialog">确 定</el-button>
                </div>
            </span>
        </el-dialog>
        <dangerlgDetailView ref="dangerlgDetailView"></dangerlgDetailView>
    </div>
</template>
<script>
import dangerlgDetailView from "@/views/ecology/components/danger/dangerlg/dangerlgDetailView";
import { getToken } from "@/utils/auth";

export default {
    components: { dangerlgDetailView },
    name: "danger-lg-add-window",
    props: {},
    data() {
        return {
            opType: 1, // 1:依据查,2 隐患选择依据,3 检查表选择依据
            selectValue: [],
            queryParams: {
                dataType: "Public",
            },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                ownType: "=",
                keywords: "like",
            },
            // 查询条件
            conditionsVals: {
                ownType: "",
                keywords: "",
            },
            controller: "ecologyEnv/dangerlg", //对应后端控制器
            title: "选择检查依据",
            checkList: false,
            visible: false,
            params: {
                ownTypes: [
                    { id: "", name: "全部" },
                    { id: "A", name: "通用" },
                    { id: "B", name: "行业专属" },
                ],
            },
            uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload", // 上传的图片服务器地址
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            simpleModel: {},
            model: {},
        };
    },
    methods: {
        //查询
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        confirmDialog() {
            let resultArray = [];
            let array = this.$refs.EaglePage.selection;
            // array.forEach((x) => {
            //     resultArray.push({ code: x.code, title: x.title });
            // });
            this.$emit("choosed", array, this.opType);
            console.log(array);

            this.visible = false;
        },
        show(config) {
            this.opType = config.opType;
            this.model = config.model;
            this.visible = true;

            setTimeout(() => {
                this.$refs.EaglePage.selection = [];
                this.search();
            });
        },
        //查询条件重置
        resetQuery() {
            this.conditionsVals.keywords = "";
            this.search();
        },
        handleChoose(obj) {
            this.checkList = true;
            this.selectRow = obj;
        },
        toDetailView(lgCode) {
            this.$refs.dangerlgDetailView.show(lgCode);
        },
        ownTypeFormatter(row, column) {
            var ownType = row.ownType;
            let ownTypeItem = this.params.ownTypes.filter(
                (item) => item.id === ownType
            );
            return ownTypeItem[0].name;
        },
        // onOwnTypeChanged(value) {
        //     this.search();
        // },
        onUploadSuccess(response, file, fileList) {
            if (response.code == 200) {
                let model = {};
                model.attachs = response.data.filePath;
                this.setModel(model, this.simpleModel);

                // this.chooseConfirm();
                this.$emit("choosed", model, this.opType);
                this.visible = false;
            } else {
                this.$message.error("图片上传失败!");
            }
        },
        onBeforeUpload(file) {
            const isJPG = file.type === "image/jpeg";
            const isPNG = file.type === "image/png";
            const isHEIC = file.type === "image/heic";
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isPNG && !isJPG && !isHEIC) {
                this.$message.error("上传头像图片只能是 JPG或PNG 格式!");
                return false;
            }
            return true;
        },
        chooseSingerConfirm(obj) {
            // debugger;
            let _this = this;
            if (_this.model && _this.model.hiddenDangerDesc) {
                this.$confirm("是否覆盖此数据?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.setModel(_this.model, obj);
                });
            } else {
                _this.setModel(_this.model, obj);
                this.$emit("choosed", obj, this.opType);
            }
            this.visible = false;
        },

        setModel(model, obj) {
            let _this = this;
            model.itemName = obj.correctiveAdvise;
            model.originalText = obj.originalText;
            model.legalLiability = obj.legalLiability;
            model.gistSource = obj.gistSource;
            model.correctiveAdvise = obj.correctiveAdvise;
            if (obj.hiddenDangerList && obj.hiddenDangerList.length > 0) {
                model.hiddenCode = obj.hiddenDangerList[0].dCode;
                model.hiddenName = obj.hiddenDangerList[0].dfullName.replace(
                    ">",
                    "-"
                );
                model.hiddenTypeCode =
                    obj.hiddenDangerList[0].dfullName.split("-")[0] ===
                        "基础管理"
                        ? "1"
                        : "2";
                model.hiddenTypeName =
                    obj.hiddenDangerList[0].dfullName.split("-")[1];
                model.hiddenDangerDesc =
                    obj.hiddenDangerList[0].hiddenDangerDesc;
                model.hiddenDangerTypeCode =
                    obj.hiddenDangerList[0].hiddenDangerTypeName == "一般隐患"
                        ? "1"
                        : "2";
            }
        },
        // chooseSingerConfirm(model) {
        //     this.$emit("choosed", model);
        //     this.visible = false;
        // },
        // chooseConfirm() {
        //     this.$emit("choosed", this.simpleModel, this.opType);
        //     this.visible = false;
        // },
        chooseImg(item) {
            this.simpleModel = item;
            // let hiddenItem = item.hiddenDangerList[0];
            // this.simpleModel.lgCode = item.lgCode;
            // this.simpleModel.gistSource = item.gistSource;
            // this.simpleModel.correctiveAdvise = item.correctiveAdvise;
            // this.simpleModel.legalLiability = item.legalLiability;
            // this.simpleModel.originalText = item.originalText;
            // this.simpleModel.hiddenDangerDesc = hiddenItem.hiddenDangerDesc;
            // this.simpleModel.lgHDCode = hiddenItem.lgHDCode;
            // this.refid = refid;
        },
    },
};
</script>