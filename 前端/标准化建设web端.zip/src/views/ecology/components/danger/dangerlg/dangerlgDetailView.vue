<template name="danger-lg-detail-view">
    <div class="danger-lg-detail-view">
        <el-dialog v-dialogDrag :title="title" :visible.sync="visible" width="1000px" show-close :close-on-click-modal="false">
            <el-form ref="form" :model="data" label-width="80px" class="lg_form" size="small">
                <eagle-block border>
                    <eagle-label label="依据来源" v-model="data.gistSource" />
                    <eagle-label label="整改要求" v-model="data.correctiveAdvise" />
                    <eagle-label label="适用地区" v-model="data.applyArea" />
                    <eagle-label label="适用行业" v-model="data.applyProfessionName" />
                    <eagle-label label="法律责任" v-model="data.legalLiability" />
                    <eagle-label label="法律原文" v-model="data.originalText" />
                    <eagle-label label="常见隐患" />
                    <div class="hidden-block" v-for="hiddenItem in data.hiddenDangerList" :key="hiddenItem.lgHDCode">
                        <div class="hidden-item">
                            <eagle-label label="隐患描述" v-model="hiddenItem.hiddenDangerDesc" />
                            <eagle-label label="隐患分类" v-model="hiddenItem.dfullName" />
                            <eagle-label label="隐患性质" v-model="hiddenItem.hiddenDangerTypeName" />
                            <eagle-image label="隐患图例" :is-edit="false" v-model="hiddenItem.ngImgs" />
                            <eagle-image label="正确图例" :is-edit="false" v-model="hiddenItem.okImgs" />
                            <!-- <eagle-display-image label="隐患图例" v-model="hiddenItem.ngImgs" />
                        <eagle-display-image label="正确图例" v-model="hiddenItem.okImgs" /> -->
                        </div>
                    </div>
                    <!-- <eagle-label label="关键词" v-model="data.keyword" /> -->
                    <!-- <eagle-label label="归属类别" v-model="data.ownType" /> -->
                    <eagle-label label="法律法规" v-if="data.textList!=null && data.textList!=''" />
                    <div class="text-block" v-for="textItem in textList" :key="textItem.ID">
                        <div class="text-item" @click="toLaw(textItem)">{{textItem.Name}}</div>
                    </div>
                    <eagle-label label="配套文件" v-if="data.matchTextList!=null && data.matchTextList!=''" />
                    <div class="text-block" v-for="textItem in matchTextList" :key="textItem.ID">
                        <div class="text-item" @click="toLaw(textItem)">{{textItem.Name}}</div>
                    </div>
                </eagle-block>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible=false">关 闭</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
export default {
    name: "danger-lg-detail-view",
    props: {},
    data() {
        return {
            title: "检查依据[详情]",
            visible: false,
            data: {},
            textList: [],
            matchTextList: [],
        };
    },
    methods: {
        show(lgCode) {
            this.visible = true;
            this.data = {};
            this.textList = [];
            this.matchTextList = [];
            this.http
                .get("/ecologyEnv/dangerlg/getViewEntity", { lgCode: lgCode })
                .then((result) => {
                    this.data = result.data;
                    // console.log(this.data);
                    if (this.data.textList) {
                        this.textList = JSON.parse(this.data.textList);
                        // console.log(this.textList);
                    }
                    if (this.data.matchTextList) {
                        this.matchTextList = JSON.parse(
                            this.data.matchTextList
                        );
                        // console.log(this.matchTextList);
                    }
                });
        },
        toLaw(textItem) {
            let link =
                "http://www.ehsway.com/Article/LawDetailView?ID=" + textItem.ID;
            window.open(link);
        },
    },
};
</script>
<style lang="scss" scoped>
.lg_form {
    height: 600px;
    overflow: auto;
}

.hidden-block {
    margin: 10px 0px;

    .hidden-item {
        border: 2px dashed #eee;
        padding: 5px;
    }
}

.text-block {
    .text-item {
        margin-left: 80px;
        color: #42b983;
        padding: 5px 0px 5px 0px;
        cursor: pointer;
    }
}
</style>