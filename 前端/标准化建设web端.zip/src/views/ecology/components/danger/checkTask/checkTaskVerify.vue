<template name="check-task-verify">
    <div class="check-task-verify">
        <eagle-form :controller="controller" title="隐患复查" :save-volid-fun="randVolid" @afterSave="afterSave" :form="form" width="1000px" label-width="120px" ref="EagleForm" @bindData="bindDataDetail" :customButtons="true">
            <eagle-block border title="隐患信息">
                <div>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="隐患来源" label-width="100px">
                                <span>{{formateDict( params.checkSource,form.originType) }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="检查人" label-width="100px">
                                <span>{{form.createChnName}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="检查时间" label-width="100px">
                                <span>{{ parseTime(form.createDate, "{y}-{m}-{d}") }}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>

                <eagle-image label-width="100px" key="attachs" :is-edit="false" v-model="form.attachs" label="隐患图片" prop='attachs' :count="3" />
                <eagle-input :is-edit="false" :row="2" label-width="100px" label="隐患区域" v-model="form.correctiveArea" />
                <div style="text-align: right;">
                    <el-button type="text" @click="hdTemplateCheckShowLg(form)"> 查看依据</el-button>
                </div>
                <eagle-input type="textarea" :is-edit="false" :row="2" label-width="100px" label="隐患描述" prop='hiddenDangerDesc' v-model="form.hiddenDangerDesc" />
                <eagle-input type="textarea" autosize :is-edit="false" :row="2" label-width="100px" label="整改建议" prop='correctiveAdvise' v-model="form.correctiveAdvise" />
                <el-row>
                    <el-col :span="12">
                        <eagle-input :is-edit="false" prop='hiddenName' label-width="100px" label="隐患分类" v-model="form.hiddenName" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <eagle-radio label-width="100px" :is-edit="false" label="整改方式" prop='correctiveType' v-model="form.correctiveType" :data-source="params.correctiveType" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <eagle-radio label-width="100px" :is-edit="false" label="隐患性质" v-model="form.hiddenDangerTypeCode" :data-source="params.dangerType" />
                    </el-col>
                </el-row>
                <el-row v-if="!isHost">
                    <el-col>
                        <eagle-input :is-edit="false" prop='appointCorrectiveName' label-width="100px" label="整改负责人" v-model="form.appointCorrectiveChnName" />
                    </el-col>
                </el-row>
                <div v-if="form.correctiveType==2">
                    <el-row v-if="form.correctiveDeadline">
                        <eagle-date label-width="100px" :is-edit="false " prop='correctiveDeadline' quickChoose label="整改期限" v-model="form.correctiveDeadline" />
                    </el-row>
                    <el-row v-if="form.correctiveMeasure">
                        <eagle-input type="textarea" :is-edit="false" prop='correctiveMeasure' key="correctiveMeasure" :row="2" label-width="100px" label="整改措施" v-model="form.correctiveMeasure" />
                    </el-row>
                </div>

                <eagle-image v-if="form.correctiveAttachs" label-width="100px" :is-edit="false" prop='correctiveAttachs' v-model="form.correctiveAttachs" label="整改图片" :count="3" />
                <eagle-input v-if="form.correctiveDesc" :is-edit="false" key="correctiveDesc" type="textarea" prop='correctiveDesc' :row="2" label-width="100px" label="整改说明" v-model="form.correctiveDesc" />

            </eagle-block>

            <eagle-block class="mt10" title="复查">
                <el-form-item label="复查结论" label-width="100px">
                    <el-tag :type="form.pass?'success':'info'" style="cursor: pointer;" @click="form.pass=true"> 复查通过 </el-tag>
                    <el-tag :type="!form.pass?'danger':'info'" style="margin-left:10px;cursor: pointer;" @click="form.pass=false"> 复查不通过 </el-tag>
                </el-form-item>
                <eagle-image label-width="100px" :is-edit="true" prop='receiveAttach' v-model="form.receiveAttach" label="复查图片" :count="3" />
                <eagle-input key=" receiveRemark" type="textarea" prop='receiveRemark' :row="2" label-width="100px" label="复查说明" v-model="form.receiveRemark" />
            </eagle-block>
            <div slot="buttons" class="dialog-footer">
                <el-button @click="cancel">关 闭</el-button>
                <el-button type="primary" @click="submitForm">提 交</el-button>
            </div>
        </eagle-form>
        <templateItem ref="templateItem" />
    </div>
</template>

<script>
import templateItem from "@/views/ecology/components/danger/template/templateItem";
import { getCurrentUser } from "@/utils/auth";
export default {
    components: {templateItem},
    name: "check-task-verify",
    props: {},
    data() {
        return {
            libDataType: "base",
            controller: "ecologyEnv/dangerCheckTaskDetail",
            form: {},
            // type: 0, //查看,1:编辑,2整改,3随手拍,4 依据查,5 复查
            mainCode: "",
            params: {
                // dangerCheckTaskType: [],
                opType: [],
                dangerType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkResult: [
                    { id: "Y", name: "符合", color: "#67C23A" },
                    { id: "N", name: "不符合", color: "#F56C6C" },
                    { id: "NA", name: "不适用", color: "#E6A23C" },
                ],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
                status: [
                    { id: 100, name: "已复查", color: "#67C23A" },
                    { id: 60, name: "已整改", color: "#409EFF" },
                    { id: 30, name: "待整改", color: "#F56C6C" },
                    { id: 10, name: "待提交", color: "#E6A23C" },
                    { id: 5, name: "暂存", color: "#F56C6C" },
                ],
            },

            tempModel: {}, //依据查model
            projectId: "",
            modulesId: "",
        };
    },
    computed: {
        isHost() {
            return (
                this.projectId ||
                (this.form.projectId && this.form.sourceType == "project")
            );
        },
    },
    created() {
        this.projectId = this.$route.query.projectId ?? "";
        this.modulesId = this.$route.meta.modulesId;
        this.initData();
    },
    methods: {
        clearHidden(obj) {
            obj.hiddenCode = "";
            obj.hiddenName = "";
            obj.hiddenTypeName = "";
            obj.hiddenTypeCode = "";
        },
        hdSetMeCorrective() {
            let _this = this;
            let userInfo = getCurrentUser();
            _this.form.appointCorrectiveChnName = userInfo.chnName;
            _this.form.appointCorrectiveName = userInfo.userName;
        },
        setHidderDangerDesc(obj) {
            let _this = this;
            _this.form.correctiveAdvise = obj.base.correctiveAdvise;
            _this.form.gistSource = obj.base.gistSource;
            _this.form.originalText = obj.base.originalText;
            _this.form.lgCode = obj.base.lGCode;
            if (obj.item === "base-danger") {
                if (obj.danger.dFullName) {
                    _this.form.hiddenCode = obj.danger.dCode;
                    _this.form.hiddenName = obj.danger.dFullName.replace(
                        ">",
                        "-"
                    );
                    _this.form.hiddenTypeName =
                        _this.form.hiddenName.split("-")[0];
                    if (_this.form.hiddenTypeName === "现场管理")
                        _this.form.hiddenTypeCode = "2";
                    if (_this.form.hiddenTypeName === "基础管理")
                        _this.form.hiddenTypeCode = "1";
                }
                _this.form.lgHdCode = obj.danger.lGHDCode;
                _this.form.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.form.hiddenDangerTypeCode = obj.danger.hiddenDangerType;
                _this.form.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.form.legalLiability = obj.danger.legalLiability;
            }
        },

        //检查表检查,查看依据
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({
                model: item,
                isEdit: false,
            });
        },

        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        bindDataDetail(data) {
            let _this = this;
            _this.form = data;
            _this.form.mainCode = _this.mainCode;
            _this.form.correctiveType =
                _this.form.correctiveType && _this.form.correctiveType > 0
                    ? _this.form.correctiveType
                    : 2;
            if (_this.form.id == 0) {
                _this.form.originType = 1;
                _this.form.checkResult = "N";
                if (_this.type == 4) {
                    //依据查
                    _this.form.originType = 2;
                    _this.form.attachs = _this.tempModel.attachs;
                    _this.form.hiddenDangerDesc =
                        _this.tempModel.hiddenDangerDesc;
                    _this.form.correctiveAdvise =
                        _this.tempModel.correctiveAdvise;
                    _this.form.gistSource = _this.tempModel.gistSource;
                    _this.form.originalText = _this.tempModel.originalText;
                    _this.form.lgCode = _this.tempModel.lGCode;

                    if (_this.tempModel.item === "base-img-danger") {
                        if (_this.tempModel.dFullName) {
                            _this.form.hiddenCode = _this.tempModel.dCode;
                            _this.form.hiddenName =
                                _this.tempModel.dFullName.replace(">", "-");
                            _this.form.hiddenTypeName =
                                _this.form.hiddenName.split("-")[0];
                            if (_this.form.hiddenTypeName === "现场管理")
                                _this.form.hiddenTypeCode = "2";
                            if (_this.form.hiddenTypeName === "基础管理")
                                _this.form.hiddenTypeCode = "1";
                        }
                        _this.form.lgHdCode = _this.tempModel.lGHDCode;
                        _this.form.hiddenDangerTypeCode =
                            _this.tempModel.hiddenDangerType;
                        _this.form.hiddenDangerTypeName =
                            _this.tempModel.hiddenDangerTypeName;
                        _this.form.legalLiability =
                            _this.tempModel.legalLiability;
                    }
                }
            }
            _this.form.pass = true;
        },
        show(params, config) {
            let _this = this;
            _this.mainCode = params.mainCode;
            _this.$refs.EagleForm.handleUpdate(params, config);
        },
        randVolid() {
            return true;
        },
        handleChooseDangerType(val, obj) {
            this.form.hiddenCode = val;
            this.form.hiddenName = obj.dFullName.replace(">", "-");
            this.form.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.form.hiddenTypeCode = obj.dType;
        },
        handleRandShowHidden() {
            this.$refs.chooseDangerType.show();
        },
        cancel(data) {
            this.$refs.EagleForm.cancel();
        },
        submitForm() {
            let isVolid = true;
            let method = "rectify";
            let config = {
                url: `${this.controller}/${method}`,
                isVolid: isVolid,
            };
            this.$refs.EagleForm.submitForm(config);
        },
        afterSave() {
            this.$emit("afterSave");
        },
    },
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0px 20px;
}
</style>