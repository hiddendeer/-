<template name="check-task-detail">
    <div class="check-task-detail">
        <eagle-form :controller="controller" :is-edit="type==1 ||type==3" :save-volid-fun="randVolid" @afterSave="afterSave" :form="form" width="1000px" label-width="120px" ref="EagleForm" @bindData="bindDataDetail" :customButtons="true">
            <eagle-block border>
                <div v-if="type!=1 && type!=3 && type!=4">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="隐患来源" label-width="100px">
                                <span>{{formateDict( params.checkSource,form.originType) }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="检查人" label-width="100px">
                                <span>{{form.createChnName}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="检查时间" label-width="100px">
                                <span>{{ parseTime(form.createDate, "{y}-{m}-{d}") }}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>

                <div v-if="form.checkResult=='N'">
                    <eagle-image label-width="100px" key="attachs" :is-edit="type==1 ||type==3 || type==4" v-model="form.attachs" label="隐患图片" prop='attachs' :count="3" />
                    <eagle-input :class="form.hiddenTypeCode=='2'?'is-required':''" :is-edit="type==1 ||type==3|| type==4" :row="2" label-width="100px" label="隐患区域" v-model="form.correctiveArea" />
                    <div style="text-align: right;">
                        <el-button type="text" v-if="type==1 ||type==3|| type==4" @click="hdTemplateCheckChooseLg()">选择依据</el-button>
                        <el-button type="text" @click="hdTemplateCheckShowLg(form)"> {{type==1 ||type==3|| type==4?"编辑依据":"查看依据"}}</el-button>
                    </div>
                    <eagle-input class="is-required" type="textarea" :is-edit="type==1 ||type==3|| type==4" :row="2" label-width="100px" label="隐患描述" prop='hiddenDangerDesc' v-model="form.hiddenDangerDesc" />
                    <eagle-input type="textarea" autosize :is-edit="type==1 ||type==3|| type==4" :row="2" label-width="100px" label="整改建议" prop='correctiveAdvise' v-model="form.correctiveAdvise" />
                    <el-row>
                        <el-col :span="12">
                            <eagle-choose v-if="type!=5" :class="{'is-required':modulesId=='host'}" @clearChoose="clearHidden(form)" label-width="100px" :is-edit="type==1 ||type==3|| type==4" label="隐患分类" v-model="form.hiddenName" @change="handleRandShowHidden()" />
                            <eagle-input v-else :is-edit="false" prop='hiddenName' label-width="100px" label="隐患分类" v-model="form.hiddenName" :class="{'is-required':modulesId=='host'}" />
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-radio class="is-required" label-width="100px" :is-edit="type==1 ||type==3|| type==4" label="整改方式" prop='correctiveType' v-model="form.correctiveType" :data-source="params.correctiveType" />
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-radio class="is-required" label-width="100px" :is-edit="type!=0&& type!=5" label="隐患性质" v-model="form.hiddenDangerTypeCode" :data-source="params.dangerType" />
                        </el-col>
                    </el-row>
                    <el-row v-if="!isHost">
                        <el-col :span="12" v-if="type==1 ||type==3 ||type==4">
                            <eagle-choose-user label-width="100px" label="整改负责人" prop="appointCorrectiveName" onlyShowRequired :single="true" :names.sync="form.appointCorrectiveChnName" v-model="form.appointCorrectiveName" />
                        </el-col>
                        <el-col :span="12" v-if="type==1 ||type==3 ||type==4">
                            <el-button type="text" @click="hdSetMeCorrective">由我本人整改</el-button>
                        </el-col>
                        <el-col v-else>
                            <eagle-input :is-edit="false" prop='appointCorrectiveName' label-width="100px" label="整改负责人" v-model="form.appointCorrectiveChnName" />
                        </el-col>
                    </el-row>
                    <div v-if="form.correctiveType==2">
                        <el-row>
                            <el-col :span="12">
                                <eagle-date label-width="100px" :is-edit="isEdit" prop='correctiveDeadline' quickChoose label="整改期限" v-model="form.correctiveDeadline" />
                            </el-col>
                        </el-row>
                        <eagle-input type="textarea" :is-edit="type!=0 && type!=5" prop='correctiveMeasure' key="correctiveMeasure" :row="2" label-width="100px" label="整改措施" v-model="form.correctiveMeasure" />
                    </div>
                    <div v-if="form.correctiveType==1 || (type!=1 && type!=3 && type!=4) ">
                        <eagle-image label-width="100px" :is-edit="type!=0 && type!=5" prop='correctiveAttachs' v-model="form.correctiveAttachs" label="整改图片" :count="3" required />
                        <eagle-input :is-edit="type!=0 && type!=5" key="correctiveDesc" type="textarea" prop='correctiveDesc' :row="2" label-width="100px" label="整改说明" v-model="form.correctiveDesc" required />
                    </div>

                    <div v-if="type==5">
                        <el-form-item label="复查结论" label-width="100px">
                            <el-tag :type="form.pass?'success':'info'" style="cursor: pointer;" @click="form.pass=true"> 复查通过 </el-tag>
                            <el-tag :type="!form.pass?'danger':'info'" style="margin-left:10px;cursor: pointer;" @click="form.pass=false"> 复查不通过 </el-tag>
                        </el-form-item>
                    </div>
                    <eagle-image label-width="100px" v-if="(type==2 && form.receiveCount>0 )|| type==5" :is-edit="type==5" prop='receiveAttach' v-model="form.receiveAttach" label="复查图片" :count="3" />
                    <eagle-input v-if="(type==2 && form.receiveCount>0 )|| type==5" :is-edit="type==5" key="receiveRemark" type="textarea" prop='receiveRemark' :row="2" label-width="100px" label="复查说明" v-model="form.receiveRemark" />

                </div>
            </eagle-block>
            <div slot="buttons" class="dialog-footer">
                <el-button @click="cancel" v-if="type!=0">取 消</el-button>
                <el-button @click="cancel" v-if="type===0">关 闭</el-button>
                <el-button v-if="type!=0 && type!=5" type="primary" @click="submitForm"> {{(form.self || form.manager) &&  type===2 ?"整改/复查":"提 交"}}</el-button>
                <el-button v-if="type==5" type="primary" @click="submitForm">提 交</el-button>
            </div>
        </eagle-form>
        <choose-danger-type ref="chooseDangerType" v-model="form.hiddenCode" @change="handleChooseDangerType" />
        <templateItem ref="templateItem" />
        <libTempDetails :dataType="libDataType" @handleClose="libTempDetailsVisible=false" :libTempDetailsVisible="libTempDetailsVisible" @handlerSelectBase="handlerSelectBase" />
    </div>
</template>

<script>
import chooseDangerType from "@/views/components/danger/chooseDangerType";
import templateItem from "@/views/ecology/components/danger/template/templateItem";
import libTempDetails from "@/views/ecologySupport/libTemp/components/libTempDetails/libTempDetails";
import { getCurrentUser } from "@/utils/auth";
export default {
    components: { chooseDangerType, libTempDetails, templateItem },
    name: "check-task-detail",
    props: {},
    data() {
        return {
            libDataType: "base",
            libTempDetailsVisible: false,
            controller: "ecologyEnv/dangerCheckTaskDetail",
            form: {},
            type: 0, //查看,1:编辑,2整改,3随手拍,4 依据查,5 复查
            mainCode: "",
            params: {
                // dangerCheckTaskType: [],
                opType: [],
                dangerType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkResult: [
                    { id: "Y", name: "符合", color: "#67C23A" },
                    { id: "N", name: "不符合", color: "#F56C6C" },
                    { id: "NA", name: "不适用", color: "#E6A23C" },
                ],
                correctiveType: [
                    { id: 1, name: "立即整改" },
                    { id: 2, name: "限时整改" },
                ],
                status: [
                    { id: 100, name: "已复查", color: "#67C23A" },
                    { id: 60, name: "已整改", color: "#409EFF" },
                    { id: 30, name: "待整改", color: "#F56C6C" },
                    { id: 10, name: "待提交", color: "#E6A23C" },
                    { id: 5, name: "暂存", color: "#F56C6C" },
                ],
            },

            tempModel: {}, //依据查model
            projectId: "",
            modulesId: "",
        };
    },
    computed: {
        isHost() {
            return (
                this.projectId ||
                (this.form.projectId && this.form.sourceType == "project")
            );
        },
        isEdit() {
            return this.type == 1 || this.type == 3 || this.type == 4;
        },
    },
    created() {
        this.projectId = this.$route.query.projectId ?? "";
        this.modulesId = this.$route.meta.modulesId;
        this.initData();
    },
    methods: {
        clearHidden(obj) {
            obj.hiddenCode = "";
            obj.hiddenName = "";
            obj.hiddenTypeName = "";
            obj.hiddenTypeCode = "";
        },
        hdSetMeCorrective() {
            let _this = this;
            let userInfo = getCurrentUser();
            _this.form.appointCorrectiveChnName = userInfo.chnName;
            _this.form.appointCorrectiveName = userInfo.userName;
        },
        setHidderDangerDesc(obj) {
            let _this = this;
            _this.form.correctiveAdvise = obj.base.correctiveAdvise;
            _this.form.gistSource = obj.base.gistSource;
            _this.form.originalText = obj.base.originalText;
            _this.form.lgCode = obj.base.lGCode;
            if (obj.item === "base-danger") {
                if (obj.danger.dFullName) {
                    _this.form.hiddenCode = obj.danger.dCode;
                    _this.form.hiddenName = obj.danger.dFullName.replace(
                        ">",
                        "-"
                    );
                    _this.form.hiddenTypeName =
                        _this.form.hiddenName.split("-")[0];
                    if (_this.form.hiddenTypeName === "现场管理")
                        _this.form.hiddenTypeCode = "2";
                    if (_this.form.hiddenTypeName === "基础管理")
                        _this.form.hiddenTypeCode = "1";
                }
                _this.form.lgHdCode = obj.danger.lGHDCode;
                _this.form.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.form.hiddenDangerTypeCode = obj.danger.hiddenDangerType;
                _this.form.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.form.legalLiability = obj.danger.legalLiability;
            }
        },
        handlerSelectBase(obj) {
            let _this = this;
            if (obj.item == "base" && _this.form.correctiveAdvise) {
                this.$confirm("是否确认覆盖整改建议?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.setHidderDangerDesc(obj);
                });
            } else if (
                obj.item === "base-danger" &&
                (_this.form.hiddenDangerDesc || _this.form.correctiveAdvise)
            ) {
                this.$confirm("是否确认覆盖隐患描述和整改建议?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.setHidderDangerDesc(obj);
                });
            } else _this.setHidderDangerDesc(obj);
            this.libTempDetailsVisible = false;
        },
        //检查表检查,查看依据
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({
                model: item,
                isEdit: this.type !== 0 && this.type !== 2,
            });
        },

        hdTemplateCheckChooseLg(op) {
            this.libTempDetailsVisible = true;
            this.libDataType = "base";
        },

        //检查表检查选择依据
        // hdTemplateCheckChooseLg(model) {
        //     this.$refs.dangerLG.show({ model: model, opType: 2 });
        // },
        /*
         *
         */
        choosedDangerLg(chooseData) {
            this.model = chooseData;
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        bindDataDetail(data) {
            let _this = this;
            _this.form = data;
            _this.form.mainCode = _this.mainCode;
            _this.form.correctiveType =
                _this.form.correctiveType && _this.form.correctiveType > 0
                    ? _this.form.correctiveType
                    : 2;
            if (_this.form.id == 0) {
                _this.form.originType = 1;
                _this.form.checkResult = "N";
                if (_this.type == 4) {
                    //依据查
                    _this.form.originType = 2;
                    _this.form.attachs = _this.tempModel.attachs;
                    _this.form.hiddenDangerDesc =
                        _this.tempModel.hiddenDangerDesc;
                    _this.form.correctiveAdvise =
                        _this.tempModel.correctiveAdvise;
                    _this.form.gistSource = _this.tempModel.gistSource;
                    _this.form.originalText = _this.tempModel.originalText;
                    _this.form.lgCode = _this.tempModel.lGCode;

                    if (_this.tempModel.item === "base-img-danger") {
                        if (_this.tempModel.dFullName) {
                            _this.form.hiddenCode = _this.tempModel.dCode;
                            _this.form.hiddenName =
                                _this.tempModel.dFullName.replace(">", "-");
                            _this.form.hiddenTypeName =
                                _this.form.hiddenName.split("-")[0];
                            if (_this.form.hiddenTypeName === "现场管理")
                                _this.form.hiddenTypeCode = "2";
                            if (_this.form.hiddenTypeName === "基础管理")
                                _this.form.hiddenTypeCode = "1";
                        }
                        _this.form.lgHdCode = _this.tempModel.lGHDCode;
                        _this.form.hiddenDangerTypeCode =
                            _this.tempModel.hiddenDangerType;
                        _this.form.hiddenDangerTypeName =
                            _this.tempModel.hiddenDangerTypeName;
                        _this.form.legalLiability =
                            _this.tempModel.legalLiability;
                    }
                }
            }
            if (_this.type == 2 && (_this.form.self || _this.form.manager)) {
                _this.form.pass = true;
            }
            if (_this.type == 5) {
                _this.form.pass = true;
            }
        },
        handleChangeResult(status) {
            console.log(this.type);
            if (this.type == 1) this.form.checkResult = status;
        },
        show(params, config) {
            let _this = this;
            _this.type = config.type;
            _this.mainCode = params.mainCode;
            switch (config.type) {
                case 0:
                    config.title = "隐患详情";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
                case 1:
                    config.title = "隐患编辑";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
                case 2:
                    config.title = "隐患整改";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
                case 3:
                    config.title = "随手拍";
                    // config.params = { projectId: config.projectId ?? "" }
                    _this.$refs.EagleForm.handleAdd(config);
                    break;
                case 4:
                    config.title = "依据查";
                    _this.tempModel = config.lg;
                    // config.params = { projectId: config.projectId ?? "" }
                    _this.$refs.EagleForm.handleAdd(config);

                    break;
                case 5:
                    config.title = "隐患复查";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
            }
        },
        randVolid() {
            return true;
        },
        handleChooseDangerType(val, obj) {
            this.form.hiddenCode = val;
            this.form.hiddenName = obj.dFullName.replace(">", "-");
            this.form.hiddenTypeName =
                obj.dType == "1" ? "基础管理" : "现场管理";
            this.form.hiddenTypeCode = obj.dType;
        },
        handleRandShowHidden() {
            this.$refs.chooseDangerType.show();
        },
        cancel(data) {
            this.$refs.EagleForm.cancel();
        },
        submitForm() {
            let isVolid = true;
            let method = "rectify";
            if (this.type === 1 || this.type === 3 || this.type === 4) {
                method = "save";
                isVolid = false;
            }
            let config = {
                url: `${this.controller}/${method}`,
                isVolid: isVolid,
            };
            this.$refs.EagleForm.submitForm(config);
        },
        afterSave() {
            this.$emit("afterSave");
        },
    },
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0px 20px;
}
</style>