<template>
    <el-dialog v-dialogDrag close="train-dialog" :visible.sync="showSearch" title="上传记录" ref="Dialog" width="1000px" :before-close="handleClose">
        <eagle-block border>
            <el-form ref="form" :model="form" :rules="rules" label-width="150px" size="small">
                <div v-if="this.istraincount" style="background-color:#F8F8F8;padding:10px;margin-bottom:10px;border-radius: 10px;">
                    <eagle-input label="姓名" prop="userChnName" required v-model="form.userChnName"></eagle-input>

                    <eagle-attach label="三级安全培训教育卡" v-model="form.levelThreeTrainEducationCard" required prop="levelThreeTrainEducationCard"></eagle-attach>
                    <eagle-attach label="培训考核记录" v-model="form.inspectionRecords" prop="inspectionRecords">
                    </eagle-attach>
                    <el-button type="primary" style="display:block;margin:0 auto" @click="submitForm">保存并继续</el-button>
                </div>
                <eagle-page :controller="controller" @bindSelection="bindSelection" ref="EaglePage" :pageSize="5" :showCheckColumn="false">
                    <!-- <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" plain size="mini" @click="refresh">刷新</el-button>
                        </el-col>
                    </el-row>
                </template> -->
                    <template slot="slot-table">
                        <el-table-column label="姓名" align="left" prop="userChnName" width="100px" />
                        <el-table-column label="三级安全培训教育卡" prop="levelThreeTrainEducationCard" width="230px">
                            <template slot-scope="scope">
                                <eagle-row-attach v-model="scope.row.levelThreeTrainEducationCard"></eagle-row-attach>
                            </template>
                        </el-table-column>
                        <el-table-column label="培训考核记录" prop="inspectionRecords">
                            <template slot-scope="scope">
                                <eagle-row-attach v-model="scope.row.inspectionRecords"></eagle-row-attach>
                            </template>
                        </el-table-column>
                        <el-table-column label="上传时间" align="left" prop="createDate" width="100px">
                            <template slot-scope="scope">
                                <span> {{ scope.row.createDate | formatDate }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="上传人" align="left" prop="createChnName" width="120px" />
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button type="danger" @click="handleDelete(scope.row)">删除</eagle-row-button>
                    </template>
                </eagle-page>
            </el-form>
        </eagle-block>
        <div slot="footer" class="dialog-footer">
            <el-button @click="cancel">关 闭</el-button>
        </div>

    </el-dialog>
</template>


<script>
import EagleDialog from "@/components/Eagle/eagle-dialog.vue";
// import { resetForm } from "@/utils/EageleRMC";

export default {
    components: {
        EagleDialog,
    },
    name: "trainRecordList3",
    props: {
        afterSubmit: {
            type: Function,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            showSearch: false,
            queryParams: {
                pageSize: 5,
            },
            conditionsTypes: {
                trainPlanCode: "=",
            },
            conditionsVals: {
                trainPlanCode: "",
            },
            controller: "ecologyEnv/trainrecordthree",
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 标题
            title: "其他安全培训记录",
            // 表单校验
            rules: {},
            // 表单参数
            form: { userChnName: null },
            open: false,
            ids: [],
            params: {
                certKind: [],
                isNeedReview: [],
            },
            code: "",
            istraincount: true,
        };
    },
    created() {
        this.initData();
    },
    mounted() {},
    methods: {
        handleClose(done) {
            done();
            this.$emit("handleClose");
        },
        show(type, code) {
            this.istraincount = true;
            this.conditionsVals.trainPlanCode = "";
            if (type == "list1") {
                this.conditionsVals.trainPlanCode = code;
                this.istraincount = false;
            }
            if (type == "list") {
                this.form.trainPlanCode = code;
            }

            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
            // this.form.inspectionRecords = "";
            // this.form.levelThreeTrainEducationCard = "";

            this.$set(this.form, "inspectionRecords", "");
            this.$set(this.form, "levelThreeTrainEducationCard", "");

            this.showSearch = true;
            setTimeout(() => {
                this.search();
            });
        },

        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.cert_kind],
                function (res) {
                    _this.params.certKind = res.data.filter(
                        (p) => p.paramId === _this.constParams.cert_kind
                    );
                }
            );
        },
        realSubmit() {
            let _this = this;
            var url = "";
            url = "/" + this.controller + "/" + "save";
            this.form.id = 0;
            this.form.trainRecordsName = "新员工三级安全培训";
            // this.http.post(url, this.form).then(response => {
            //     this.msgSuccess("保存成功");
            //     this.$emit("afterSave");
            //     resetForm("form");
            //     this.refresh();
            //     this.form.levelThreeTrainEducationCard = "";
            //     this.form.inspectionRecords = "";
            // });

            _this.http.postLoading(
                _this.loading(),
                url,
                _this.form,
                function (res) {
                    _this.msgSuccess("保存成功");
                    _this.$emit("afterSave");
                    if (_this.$refs["form"]) {
                        _this.$refs["form"].resetFields();
                    }
                    _this.refresh();
                    _this.form.levelThreeTrainEducationCard = "";
                    _this.form.inspectionRecords = "";
                }
            );
        },
        submitForm() {
            // var url = "";
            // url = "/" + this.controller + "/" + "save";
            // this.form.id = 0;
            // this.http.post(url, this.form).then((response) => {
            //     this.msgSuccess("保存成功");
            //     this.$emit("afterSave");
            //     resetForm("form");
            //     this.refresh();
            //     this.form.levelThreeTrainEducationCard = "";
            //     this.form.inspectionRecords = "";
            // });
            let _this = this;
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    if (typeof _this.afterSubmit === "function") {
                        if (_this.afterSubmit()) _this.realSubmit();
                    } else _this.realSubmit();
                }
            });
        },
        bindData(data) {
            this.form = data;
        },
        cancel() {
            this.showSearch = false;
            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
            this.$emit("handleClose");
        },
        reVolid() {
            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
        },
        /** 新增按钮操作 */
        handleAdd() {
            this.isAdd = true;
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.$refs.form.handleUpdate(row);
        },
        bindSelection(selection) {
            this.ids = selection.map((item) => item.id);
            this.single = selection.length != 1;
            this.multiple = !selection.length;
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        handleMultDelete() {
            var _this = this;
            this.$refs.EaglePage.handleMultDelete(this.ids, function (res) {
                _this.refresh();
            });
        },
        search(code) {
            this.queryParams.certDefCode = this.code3;
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        resetQuery() {
            this.queryParams.certDefCode = "";
            this.search();
        },
    },
};
</script>
<style lang="scss" scoped>
.train-dialog {
    padding: 10px;
}
</style>
