<template name="fire-check-form">
    <div>
        <eagle-dialog title="上传记录" ref="Dialog" width="1000px">
            <eagle-page :controller="controller" ref="EaglePage" :table-height="650" :show-check="false"
                :showCheckColumn="false">
               
                <template slot="slot-table">
                    <el-table-column label="培训名称" align="left" prop="trainRecordsName" />
                    <el-table-column label="培训类型" align="left" prop="trainRecordsKind">
                        <template slot-scope="scope">
                            <span>{{ formateDict(params.trainRecordsKind, scope.row.trainRecordsKind) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="计划制定人" align="left" prop="createChnName" width="120px" />
                 
                    <el-table-column label="实际完成日期" align="left" prop="actualFinishDate" width="100px">
                        <template slot-scope="scope">
                            <span>{{ parseTime(scope.row.actualFinishDate, "{y}-{m}-{d}") }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="参与人员" align="left" prop="trainingRecordsChnName" width="120" />
                    <el-table-column label="培训记录" align="left" prop="trainRecordsAttachs" width="230px">
                        <template slot-scope="scope">
                            <eagle-row-attach v-model="scope.row.trainRecordsAttachs"></eagle-row-attach>
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="success" @click.stop="handleView(scope.row)">详情</eagle-row-button>
                </template>
            </eagle-page>
            <eagle-form :controller="controller" :title="title" :isEdit="isEdit" :form="form" width="800px"
                labelWidth="120px" ref="EagleForm" @afterSave="search" @bindData="bindData">
                <eagle-block border>
                    <eagle-input label="培训名称" prop="trainRecordsName" :isEdit="isEdit" :required="isEdit"
                        v-model="form.trainRecordsName"></eagle-input>
                    <eagle-select label="培训类型" v-model="form.trainRecordsKind" :isEdit="isEdit" :required="isEdit"
                        :data-source="params.trainRecordsKind" prop="trainRecordsKind"></eagle-select>
                    <eagle-date label="培训时间" v-model="form.actualFinishDate" :isEdit="isEdit" :required="isEdit"
                        prop="actualFinishDate" format="yyyy-MM-dd"></eagle-date>
                    <eagle-input label="参训人员" v-model="form.trainingRecordsChnName" :isEdit="isEdit" :required="isEdit"
                        prop="trainingRecordsChnName"></eagle-input>
                    <!-- <eagle-input label="培训内容简介" type="textarea" :rows="2" :isEdit="isEdit" v-model="form.introduce" prop="introduce"></eagle-input> -->
                    <eagle-attach label="上传培训记录" v-model="form.trainRecordsAttachs" :isEdit="isEdit"
                        prop="trainRecordsAttachs"></eagle-attach>
                    <eagle-image label="上传培训现场图片" v-model="form.picturesTrainSite" :isEdit="isEdit"
                        prop="picturesTrainSite"></eagle-image>
                </eagle-block>
            </eagle-form>
          
        </eagle-dialog>
    </div>
</template>
<script>
import eagleInput from "../../../../components/Eagle/eagle-input.vue";
import EagleSelect from "../../../../components/Eagle/eagle-select.vue";
import EagleDialog from "@/components/Eagle/eagle-dialog.vue";
export default {
    components: { eagleInput, EagleSelect, EagleDialog },
    // components: {
    //     eagleInput,
    //     EagleCheckbox,
    //     EagleDate,
    //     EagleAttach,
    //     EagleForm,
    //     windowCertCheckHis,
    //     EagleRadio,
    //     EagleSelect,
    //     EagleRowImage,
    //     EagleImage,
    //     EagleRowAttach,
    // },
    name: "trainRecordList",
    data() {
        return {
            showSearch: true,
            queryParams: {},
            conditionsTypes: {
                trainPlanCode: "=",
            },
            conditionsVals: {
                trainPlanCode: "",
            },
            controller: "ecologyEnv/trainrecords",
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 标题
            title: "培训记录",
            // 表单校验
            rules: {},
            // 表单参数
            form: {},
            ids: [],
            params: {
                trainRecordsKind: [],
            },
            isEdit: true,
        };
    },
    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.train_records_kind],
                function (res) {
                    _this.params.trainRecordsKind = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.train_records_kind
                    );
                }
            );
        },
        show(code) {
            this.conditionsVals.trainPlanCode = "";
            if (code != "") {
                this.conditionsVals.trainPlanCode = code;
            }
            this.$refs.Dialog.show();
            setTimeout(() => {
                this.search();
            });
        },
        bindData(data) {
            this.form = data;
        },
        /** 新增按钮操作 */
        handleAdd() {
            this.isEdit = true;
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.isEdit = true;
            this.$refs.EagleForm.handleUpdate(row);
        },
        handleView(row) {
            this.isEdit = false;
            this.$refs.EagleForm.handleUpdate(row);
        },
        bindSelection(selection) {
            this.ids = selection.map((item) => item.id);
            this.single = selection.length != 1;
            this.multiple = !selection.length;
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        handleMultDelete() {
            var _this = this;
            this.$refs.EaglePage.handleMultDelete(this.ids, function (res) {
                _this.refresh();
            });
        },
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        resetQuery() {
            this.conditionsVals.trainingRecordsChnName = "";
            this.conditionsVals.trainRecordsName = "";
            this.conditionsVals.remarks = "";
            this.search();
        },
    },
};
</script>