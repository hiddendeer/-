<template name="train-res-lib">
    <div class=" train-res-lib res-lib">
        <eagle-page :queryParams="queryParams" ref="EaglePage" :pageSize="30" max-height="800px" customize :pageSizes="[15, 30, 50, 100]">

            <template slot-scope="scope">
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <!-- <eagle-select label-width="120px" label="课件分类" id="dCode" prop="dCode" @change="search" v-model="queryParams.dCode" :data-source="params.resourceType" clearable size="small" /> -->
                    <eagle-input label="课件名称" @changeEnter="search()" v-model="conditionsVals.resName"></eagle-input>
                    <template slot="slot-buttons">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleChooseAll">全选</el-button>
                    </template>
                </eagle-condition>
                <div style="max-height:500px;overflow: auto;">
                    <el-card v-for="(item,key,index) in scope.data" :key="index" :body-style="{ padding: '0px' }" class="res-card">
                        <div style="padding: 15px 10px 5px 10px;;width: 100%;">
                            <div class="card-title-check" :title="item.resName">
                                <div class="card-title">
                                    <span>{{item.resName}}</span>
                                </div>
                                <div class="card-title-checkbox">
                                    <el-checkbox v-if="mutipleSelect" :value="selectionList" :label="item.resCode" @change="changeResCodes(item)" class="card-box-checkbox">{{ "" }}</el-checkbox>
                                </div>
                            </div>
                            <div>
                                <img v-if="item.cover" class="block-page-item-cover" @click="changeResCodes(item)" :src="item.cover">
                                <div v-else class="block-page-item-cover"></div>
                            </div>
                        </div>

                    </el-card>
                </div>
            </template>

        </eagle-page>
        <div>
            <nodata v-if="isShowEmpty1"></nodata>
        </div>
    </div>
</template>

<script>
import nodata from "../../../../components/Eagle/eagle-nodata.vue";
export default {
    components: { nodata },
    name: "trainResLib",
    data() {
        return {
            queryParams: {
                dataType: "list",
                dCode: "",
            },
            conditionsTypes: {
                resName: "like",
            },
            conditionsVals: {
                resName: null,
            },
            controller: "ecologyEnv/trainRes",
            controller2: "ecologyEnv/trainLearnResourceslib", //对应后端控制器
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 标题
            title: "培训课件库",
            // 表单参数
            form: {},
            mutipleSelect: true,
            selectionList: [],
            apps: {},
            // imgUrl: "http://libnew.safetyhua.com/Uploads/00000/20190522/56145b31-1e33-44b7-860f-f2bd9307595d.jpg",
            list: [],
            resData: [],
            isLib: false,
            isShowEmpty: false,
            params: {
                resourceType: [],
            },
        };
    },
    created() {
        this.getParams();
        this.initData();
        this.getResList();
    },
    mounted() {
        this.search();
    },
    methods: {
        getParams() {
            let _this = this;
            let url = `${_this.controller2}/getResourceType`;
            _this.http.get(url).then((res) => {
                _this.params.resourceType = res.data;
            });
        },

        initData() {
            let _this = this;
            _this.resData = [];
            _this.selectionList = [];
        },
        bindData(data) {
            this.form = data;
        },
        bindSelection(selection) {
            this.codes = selection.map((item) => item.code);
            this.single = selection.length != 1;
            this.multiple = !selection.length;
        },
        search() {
            this.isShowEmpty1 = false;
            this.getCondtions();
            this.$refs.EaglePage.search({
                url: "site/trainRes/getLibPageData",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        resetQuery() {
            this.queryParams.dCode = "";
            this.conditionsVals.resName = "";
            this.search();
        },

        getCondtions() {
            let conditions = [];
            for (let key in this.conditionsVals) {
                let ops = this.conditionsTypes[key];
                let vals = this.conditionsVals[key];
                if (vals) {
                    conditions.push({
                        name: key,
                        operate: !ops ? "like" : ops,
                        value: vals,
                    });
                }
            }
            return conditions && conditions.length > 0
                ? JSON.stringify(conditions)
                : conditions;
        },
        changeCodes(val) {
            let codes = this.selectionList;
            let data = this.resData;
            //检索下标,判断当前值(或对象是否在数组中); 在则返回下标,不在则返回-1
            var resCode = val.code;
            if (!val.code) {
                resCode = val.resCode;
            }
            let index = this.indexOf(resCode, codes);
            if (codes.length > 0 && index > -1) {
                //删除数组中的某个元素(在取消勾选时,删除数组中的值)
                codes.splice(index, 1);
                data.splice(index, 1);
            } else {
                //添加到数组中
                codes.push(resCode);
                //用逗号隔开
                codes.join(",");
                data.push(val);
            }
        },
        //获取数组中数值的下标
        indexOf(val, codes) {
            for (let i = 0; i < codes.length; i++) {
                //获取当前值的下标
                if (codes[i] === val) return i;
            }
            return -1;
        },
        getResList() {
            this.isShowEmpty1 = false;
            var url = "/" + this.controller + "/getList";
            this.http.get(url).then((response) => {
                this.list = response.data;
                if (response.data.length == 0) {
                    this.isShowEmpty1 = true;
                }
            });
        },
        submit() {
            this.$emit();
        },
        handleWatch(val) {
            let _this = this;
            if (val) {
                _this.resData = val;
                _this.selectionList = [];
                for (var i = 0; i < _this.resData.length; i++) {
                    let resCode = _this.resData[i].code;
                    if (!resCode || resCode == "") {
                        resCode = _this.resData[i].resCode;
                    }
                    if (resCode) {
                        if (_this.selectionList.indexOf(resCode) == -1) {
                            _this.selectionList.push(resCode);
                        }
                    }
                }
            } else {
                _this.resData = [];
                _this.selectionList = [];
            }
        },
        changeResCodes(val) {
            let codes = this.selectionList;
            let data = this.resData;
            //检索下标,判断当前值(或对象是否在数组中); 在则返回下标,不在则返回-1
            let index = this.indexOf(val.resCode, codes);
            if (codes.length > 0 && index > -1) {
                //删除数组中的某个元素(在取消勾选时,删除数组中的值)
                codes.splice(index, 1);
                data.splice(index, 1);
            } else {
                //添加到数组中
                codes.push(val.resCode);
                //用逗号隔开
                codes.join(",");
                data.push(val);
            }
        },
    },
};
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
// .train-res-lib ::v-deep.el-dialog__body {
//     max-height: 1000px;
// }

.block-page-item {
    display: -webkit-box;
    flex-direction: row;
    margin-bottom: 10px;
}

.row-box {
    width: 100%;
}

.el-icon-delete-solid {
    font-size: 18px;
}

.card-first {
    background-color: #665b5b;
    color: #fff;
}

.card-second {
    background-color: #7039ff;
    color: #fff;
}

.card-third {
    background-color: #7039ff;
    color: #fff;
}

.card-content {
    min-width: 14rem;
    min-height: 12rem;
    padding-right: 0;
}

.el-card {
    width: 100%;
    height: 100%;
    margin-right: 20px;
    transition: all 0.5s;
}

.card-box-checkbox {
    float: right;
}

.active {
    background-color: #ffffff !important;
    border: 1px solid #61c0d5;
}

.block-page-item-cover {
    height: 7.5rem;
    width: 16.5rem;
}

.res-lib {
    height: 600px;
}

.block-page-item-title-t {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    font-weight: bold;
    font-size: 15px;
}

.card-title {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    -webkit-box-orient: vertical;
    font-weight: bold;
    font-size: 14px;
    width: 90%;
    flex: 10;
}

.card-title-check {
    display: flex;
}

.card-title-checkbox {
    flex: 2;
}

.res-card {
    display: inline-block;
    width: 300px;
    margin: 10px;
    padding: 5px;
}
</style>