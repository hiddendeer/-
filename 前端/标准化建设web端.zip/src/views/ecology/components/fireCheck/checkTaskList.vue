<template name="fire-check-form">
    <div>
        <eagle-page :queryParams="queryParams" :controller="controller" :select-value="selectValue" ref="EaglePage" :table-height="650" :show-check="false">
            <template slot="slot-search">
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <!-- <eagle-radio  -->
                    <eagle-input label-width="80px" @changeEnter="search()" :inputStyle="{ width: '360px' }" label="筛选条件" prop="keyWords" v-model="conditionsVals.keyWords" placeholder="请输入消防器材类型,编号,位置进行模糊查询" clearable size="small" />
                </eagle-condition>
            </template>
            <template slot="slot-table">
                <el-table-column label="消防器材类型" align="left" prop="typeName" />
                <el-table-column label="消防器材编号" align="left" prop="no" />
                <el-table-column label="所属部门" align="left" prop="orgName" />
                <el-table-column label="位置" align="left" prop="location" />
                <el-table-column label="规格" align="left" prop="specifications" />
                <el-table-column label="点检条目" align="left" prop="checkListDetailItem" width="200" />
                <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" width="200" />
                <el-table-column label="隐患图片" align="left" prop="attachs" width="300">
                    <template slot-scope="scope">
                        <eagle-row-image v-model="scope.row.attachs" />
                        <!-- <img :src="scope.row.attachs" width="80px" /> -->
                    </template>
                </el-table-column>
                <el-table-column label="复查图片" align="left" prop="verifyAttachs" width="300">
                    <template slot-scope="scope">
                        <eagle-row-image v-model="scope.row.verifyAttachs" />
                        <!-- <img :src="scope.row.verifyAttachs" width="80px" /> -->
                    </template>
                </el-table-column>
                <!-- <el-table-column label="整改状态"  align="left" prop="status" /> -->
                <el-table-column label="整改状态" align="left" prop="status" width="80">
                    <template slot-scope="scope">
                        <span v-if="scope.row.status === 0" style="color:#F56C6C">待整改</span>
                        <span v-if="scope.row.status === 10" style="color:#67C23A">已整改</span>
                    </template>
                </el-table-column>

                <el-table-column label="点检人" align="left" prop="createChnName" width="120" />
                <el-table-column label="点检日期" align="left" prop="createDate" width="100">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button v-if="scope.row.status === 0" type="primary" icon="el-icon-edit" @click.stop="showCheckTaskForm(scope.row)">整改</eagle-row-button>
                <eagle-row-button type="success" icon="el-icon-view" @click.stop="showCheckTaskDetail(scope.row)">详情
                </eagle-row-button>
            </template>
        </eagle-page>
        <el-dialog v-dialogDrag :title="isEdit ? '点检异常整改' : '点检异常详情'" :visible.sync="fireCheckTaskDetailVisible" width="800px" append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <el-form :model="form" ref="form" size="small" label-width="100px">
                    <el-col :span="12">
                        <eagle-input label="消防器材类型" prop="typeName" :is-edit="false" v-model="form.typeName" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="消防器材编号" prop="typeName" :is-edit="false" v-model="form.no" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="所属部门" prop="typeName" :is-edit="false" v-model="form.orgName" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="位置" prop="typeName" :is-edit="false" v-model="form.location" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="规格" prop="specifications" :is-edit="false" v-model="form.specifications" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="点检条目" prop="checkListDetailItem" :is-edit="false" v-model="form.checkListDetailItem" />
                    </el-col>
                    <el-col :span="24">
                        <eagle-input label="隐患描述" prop="hiddenDangerDesc" :is-edit="false" v-model="form.hiddenDangerDesc" />
                    </el-col>
                    <el-col>
                        <eagle-image label="隐患图片" :is-edit="false" prop="attachs" v-model="form.attachs" />
                    </el-col>
                    <el-col>
                        <eagle-image label="整改图片" required prop="verifyAttachs" v-model="form.verifyAttachs" :is-edit="isEdit" :count="3" />
                    </el-col>
                    <el-col :span="24">
                        <eagle-input type="textarea" prop="verifyRemarks" :row="2" :isEdit="isEdit" label="整改说明" required v-model="form.verifyRemarks" />
                    </el-col>
                </el-form>
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button type="info" v-if="isEdit" @click="fireCheckTaskDetailVisible = false">{{ "取 消" }}</el-button>
                <el-button v-else @click="fireCheckTaskDetailVisible = false">{{ "关 闭" }}</el-button>
                <el-button type="primary" v-if="isEdit" @click="postForm">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
export default {
    name: "fire-check-form",
    props: {
        readOnly: false,
        selectValue: { type: String | Array | Number, default: "" },
    },
    data() {
        return {
            isEdit: false,
            //检查卡
            queryParams: { dataType: "list" },
            conditionsTypes: { keyWords: "like", checkResult: "=" },
            // 查询条件
            conditionsVals: { keyWords: "", checkResult: "N" },
            controller: "ecologyEnv/fireCheckTask", //对应后端控制器
            fireCheckTaskDetailVisible: false,
            form: {},
            rules: {
                verifyAttachs: [{ require: true, message: "请上传整改图片" }],
                verifyRemarks: [
                    {
                        require: true,
                        message: "请输入整改说明",
                        trigger: "blur",
                    },
                ],
            },
            //form: { verifyAttachs: "", verifyRemarks: "", id: "" },
        };
    },
    methods: {
        resetQuery() {
            this.conditionsVals.keyWords = "";
            this.search();
        },
        search() {
            this.$refs.EaglePage.search({
                url: "ecologyEnv/fireCheckTask/getPageList",
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        showCheckTaskForm(row) {
            this.isEdit = true;
            this.form = this.deepClone(row);
            this.fireCheckTaskDetailVisible = true;
        },

        showCheckTaskDetail(row) {
            this.isEdit = false;
            this.form = row;
            this.fireCheckTaskDetailVisible = true;
        },
        postForm() {
            let _this = this;
            if (_this.isEdit) {
                _this.$refs["form"].validate((valid) => {
                    if (valid) {
                        let url = "site/fireCheckTaskDetail/updateCheck";
                        var form = _this.form;
                        // _this.http.post(url, _this.form).then((response) => {
                        //     _this.msgSuccess("保存成功");
                        //     this.fireCheckTaskDetailVisible = false;
                        //     _this.search();
                        // });
                        _this.http.postLoading(
                            _this.loading(),
                            url,
                            _this.form,
                            function (res) {
                                _this.msgSuccess("保存成功");
                                this.fireCheckTaskDetailVisible = false;
                                _this.search();
                            }
                        );
                    }
                });
            } else {
                this.fireCheckTaskDetailVisible = false;
            }
        },
    },
};
</script>