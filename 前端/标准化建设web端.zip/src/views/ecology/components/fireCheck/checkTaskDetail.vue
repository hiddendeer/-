<template name="check-task-detail">
    <div>
        <el-dialog v-dialogDrag :visible.sync="visible" width="1000px" title="点检" append-to-body show-close
            :close-on-click-modal="false">
            <el-form ref="form" :model="form">
                <eagle-block border>
                    <el-table :data="form.details" style="width: 100%" max-height="500" border>

                        <el-table-column label="#" align="left" width="80">
                            <template slot-scope="scope">
                                {{scope.$index+1}}
                            </template>
                        </el-table-column>
                        <el-table-column label="检查内容" align="left">
                            <template slot-scope="scope">
                                <div>{{scope.row.checkListDetailItem}}</div>
                                <div v-if="scope.row.checkResult=='N'">
                                    <el-form-item label="隐患图片">
                                        <el-col :span="24">
                                            <eagle-image :count="3" v-model="scope.row.attachs" />
                                        </el-col>
                                    </el-form-item>
                                    <eagle-input type="textarea" :row="2" label-Width="100px" label="隐患描述"
                                        v-model="scope.row.hiddenDangerDesc" />
                                </div>

                            </template>
                        </el-table-column>

                        <el-table-column label="操作" align="left" width="240px">
                            <template slot-scope="scope">
                                <el-button size="mini" :type="scope.row.checkResult=='Y'?'success':'info'"
                                    @click="handleSetResult(scope.row,'Y')">符合</el-button>
                                <el-button size="mini" :type="scope.row.checkResult=='N'?'danger':'info'"
                                    @click="handleSetResult(scope.row,'N')">不符合</el-button>
                                <el-button size="mini" :type="scope.row.checkResult=='NA'?'warning':'info'"
                                    @click="handleSetResult(scope.row,'NA')">不适用</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </eagle-block>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible = false">取 消</el-button>
                <el-button type="primary" @click="submit">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import eagleImage from "../../../../components/Eagle/eagle-image.vue";
export default {
    components: { eagleImage },
    name: "check-task-detail",
    data() {
        return {
            visible: false,
            controller: "ecologyEnv/fireCheckTask", //对应后端控制器
            form: {},
            // checkListCode: "",
        };
    },

    methods: {
        InitData(fireEquipmentCode) {
            let _this = this;
            _this.visible = true;
            _this.http
                .get(_this.controller + "/initData/" + fireEquipmentCode)
                .then(function (res) {
                    _this.form = res.data;
                    console.log(_this.form);
                });
        },
        handleSetResult(row, result) {
            row.checkResult = row.checkResult == result ? "" : result;
        },
        submit() {
            let _this = this;
            _this.http
                .post(_this.controller + "/save", _this.form)
                .then((res) => {
                    this.$message.success("保存成功");
                    _this.visible = false;
                });
        },
    },
};
</script>