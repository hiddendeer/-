<template name="fire-equipment-type">
  <div>
    <eagle-block border>
      <eagle-window-choose :queryParams="queryParams" :showBtn="true" :controller="controller" ref="EaglePage" table-height="500"
        :select-value="selectValue" single showCheck>
        <template slot="slot-search">
          <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="key" v-model="conditionsVals.key"
              placeholder="请输入消防器材类型进行模糊查询" clearable size="small" />
          </eagle-condition>
        </template>
        <template slot="slot-table">
          <el-table-column label="消防器材类型" align="left" prop="name" />
          <el-table-column label="检查卡" align="left">
            <template slot-scope="scope">
              <a style="color: red" v-if="!scope.row.checkListName" @click.stop="handleChoose(scope.row)">请选择检查卡</a>
              <a v-else style="color: #46a6ff" @click.stop="showCheckListDetails(scope.row.checkListCode)">{{
              scope.row.checkListName
              }}</a>
            </template>
          </el-table-column>
          <el-table-column label="来源" align="left" prop="editChnName">
            <template slot-scope="scope">
              <span v-if="scope.row.companyCode == '000000'">平台</span>
              <span v-else>{{ scope.row.editChnName }}</span>
            </template>
          </el-table-column>
          <el-table-column label="最新修改日期" align="left" prop="editDate">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.editDate, "{y}-{m}-{d}") }}</span>
            </template>
          </el-table-column>
        </template>
      </eagle-window-choose>
    </eagle-block>
    <el-dialog title="选择检查卡" :visible.sync="checkList" width="800px" @opened="search_checkList" append-to-body
      show-close :close-on-click-modal="false" v-dialogDrag>
      <eagle-block border>
        <fire-check-form ref="fireCheckForm" :select-value="selectRow.checkListCode" />
      </eagle-block>
      <span slot="footer" class="dialog-footer">
        <el-button @click="checkList = false">取 消</el-button>
        <el-button type="primary" @click="handleChooseFire">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="检查卡" :visible.sync="fireCheckListDetailVisible" width="800px" @opened="search_CheckListDetail"
      append-to-body show-close :close-on-click-modal="false" v-dialogDrag>
      <eagle-block border>
        <show-check-list-details :checkListCode="showCheckListCode" ref="showCheckListDetails" />
      </eagle-block>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="fireCheckListDetailVisible = false">关 闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import fireCheckForm from "@/views/ecology/components/fireCheck/fireCheckForm";
export default {
  name: "choose-fire-equipment-type",
  components: { fireCheckForm },
  props: {
    readOnly: false,
    selectValue: { type: String | Array | Number, default: "" },
  },
  data() {
    return {
      queryParams: { dataType: "list" },
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        name: "like",
      },
      // 查询条件
      conditionsVals: {
        key: "",
      },
      controller: "ecologyEnv/fireEquipmentType", //对应后端控制器
      form: {},
      rules: {}, // 表单校验
      title: "消防器材类型",
      checkList: false,
      selectRow: {},
      fireCheckListDetailVisible: false,
      showCheckListCode: "",
    };
  },
  methods: {
    handleChoose(obj) {
      this.checkList = true;
      this.selectRow = obj;
      console.log(this.selectRow);
    },

    handleChooseFire() {
      let _this = this;
      let chooseObj = _this.$refs.fireCheckForm.getSelection();
      if (!chooseObj || chooseObj.length <= 0) {
        this.msgError("请选择检查卡");
        return;
      }
      _this.selectRow.checkListCode = chooseObj[0].code;
      console.log(_this.selectRow);

      _this.http
        .post(_this.controller + "/save", _this.selectRow)
        .then((response) => {
          _this.msgSuccess("保存成功");
          _this.checkList = false;
          _this.selectRow.checkListName = chooseObj[0].name;
        });
    },

    getSelection() {
      return this.$refs.EaglePage.selection;
    },
    //查询
    search() {
      this.$refs.EaglePage.search({
        // url: "site/fireEquipmentType/getPageList",
        conditions: this.$refs.EaglePage.getCondtions(
          this.conditionsVals,
          this.conditionsTypes
        ),
      });
    },

    //查询条件重置
    resetQuery() {
      this.search();
    },

    /** 新增按钮操作 */

    resetQuery() {
      this.conditionsVals.key = "";
      this.search();
    },

    handleChoose(obj) {
      this.checkList = true;
      this.selectRow = obj;
      console.log(this.selectRow);
    },
    search_checkList() {
      this.$refs.fireCheckForm.search();
    },
    search_CheckListDetail() {
      this.$refs.showCheckListDetails.search();
    },
    showCheckListDetails(code) {
      this.showCheckListCode = code;
      this.fireCheckListDetailVisible = true;
    },
  },
};
</script>