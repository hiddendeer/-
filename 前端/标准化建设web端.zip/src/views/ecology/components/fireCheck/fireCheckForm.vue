<template name="fire-check-form">
    <div>
        <eagle-block border>
            <eagle-window-choose :queryParams="queryParams" :controller="controller" :show-btn="true" :select-value="selectValue" ref="EaglePage"
                :table-height="450" single>
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="key"
                            v-model="conditionsVals.name" placeholder="请输入检查卡" clearable size="small" />
                    </eagle-condition>
                </template>

                <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                            </el-button>
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">
                    <el-table-column label="检查卡" align="left">
                        <template slot-scope="scope">
                            <a style="color: #46a6ff" @click.stop="showCheckListDetails(scope.row.code)">{{
                            scope.row.name
                            }}</a>
                        </template>
                    </el-table-column>
                    <el-table-column label="来源" align="left" prop="editChnName">
                        <template slot-scope="scope">
                            <span v-if="scope.row.companyCode == '000000'">平台</span>
                            <span v-else>{{ scope.row.editChnName }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="最近修改日期" align="left" prop="editDate" width="180">
                        <template slot-scope="scope">
                            <span>{{ parseTime(scope.row.editDate, "{y}-{m}-{d}") }}</span>
                        </template>
                    </el-table-column>
                </template>

                <template slot="slot-row-buttons" slot-scope="scope">
                    <template>
                        <eagle-row-button type="primary" icon="el-icon-edit"
                            @click.stop="handCopyByTemplate(scope.row)">复制
                        </eagle-row-button>
                        <eagle-row-button type="primary" v-if="scope.row.companyCode == currentCompanyCode"
                            icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>
                        <eagle-row-button type="danger" v-if="scope.row.companyCode == currentCompanyCode"
                            icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除</eagle-row-button>
                    </template>
                </template>
            </eagle-window-choose>
        </eagle-block>
        <eagle-form :controller="controller" :title="title" :form="form" width="800px" label-width="120px"
            ref="EagleForm" @afterSave="search" @bindData="bindData">
            <eagle-block border>
                <eagle-input is-ful-col label="检查卡名称" v-model="form.name" required prop="name"></eagle-input>
                <el-form-item label-width="0px">
                    <el-table :data="form.details" style="width: 100%">
                        <el-table-column type="index" label="序号" width="80">
                        </el-table-column>
                        <el-table-column label="检查标准">
                            <template slot-scope="scope">
                                <el-input v-model="scope.row.checkListDetailItem" required placeholder="请输入检查标准" />
                            </template>
                        </el-table-column>

                        <el-table-column label="操作" width="180">
                            <template slot-scope="scope">
                                <el-button size="small" type="primary" icon="el-icon-plus"
                                    @click.stop="handleChildAppend(scope.$index)">添加</el-button>
                                <el-button size="small" type="danger" icon="el-icon-delete"
                                    @click.stop="handleChildRemove(scope.$index)">删除</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-form-item>
            </eagle-block>
        </eagle-form>
        <el-dialog v-dialogDrag title="检查卡" :visible.sync="fireCheckListDetailVisible" width="800px"
            @opened="search_CheckListDetail" append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <show-check-list-details :checkListCode="showCheckListCode" ref="showCheckListDetails" />
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="fireCheckListDetailVisible = false">关 闭</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import { getCurrentCompany } from "@/utils/auth";
import showCheckListDetails from "../fireCheck/showCheckListDetails";
export default {
    components: { showCheckListDetails },
    name: "fire-check-form",
    props: {
        readOnly: false,
        selectValue: { type: String | Array | Number, default: "" },
    },
    data() {
        return {
            //检查卡
            queryParams: { dataType: "list" },
            conditionsTypes: { name: "like" },
            // 查询条件
            conditionsVals: { name: "" },
            controller: "ecologyEnv/fireCheck", //对应后端控制器
            form: { name: "", details: [{}] },
            rules: {}, // 表单校验
            title: "检查卡",
            single: true,
            selectItems: [],
            selectionval: [],
            fireCheckListDetailVisible: false,
            currentCompanyCode: getCurrentCompany(),
            showCheckListCode: "",
        };
    },
    created() { },
    methods: {
        getSelection() {
            return this.$refs.EaglePage.selection;
        },
        handleChildAppend(index) {
            this.form.details.splice(index + 1, 0, {});
        },
        handleChildRemove(index) {
            this.form.details.splice(index, 1);
            if (!this.form.details || this.form.details.length <= 0) {
                this.form.details.splice(0, 0, {});
            }
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        resetQuery() {
            this.conditionsVals.name = "";
            this.search();
        },
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleMultDelete(row.id);
        },
        /**复制按钮操作 */
        handCopyByTemplate(row) {
            var _this = this;
            var url = "/" + this.controller + "/initData/0";
            var params = {};
            this.http.get(url, params).then((response) => {
                var data = response.data;
                var url_s = "/" + _this.controller + "/save_template";
                data.name = row.name;
                data.id = data.id || 0;
                data.code = row.code;
                // _this.http.post(url_s, data).then((response) => {
                //     _this.msgSuccess("复制成功");
                //     _this.search();
                // });
                _this.http.postLoading(
                    _this.loading(),
                    url_s,
                    data,
                    function (res) {
                        _this.msgSuccess("复制成功");
                        _this.search();
                    }
                );
            });
            //  this.$refs.EagleForm.copyByTemplate(row);
        },

        bindData(data) {
            if (!data.details || data.details.length <= 0) {
                data.details = [];
                data.details.push({});
            }
            this.form = data;
        },
        search_CheckListDetail() {
            this.$refs.showCheckListDetails.search();
        },
        showCheckListDetails(code) {
            this.showCheckListCode = code;
            this.fireCheckListDetailVisible = true;
        },
    },
};
</script>