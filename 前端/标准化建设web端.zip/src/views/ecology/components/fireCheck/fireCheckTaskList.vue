<template name="fire-check-form">
    <div>
        <eagle-page :queryParams="queryParams" :controller="controller" :select-value="selectValue" ref="EaglePage" :table-height="450" show-check
            single>
            <template slot="slot-search">
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="key"
                        v-model="conditionsVals.name" placeholder="请输入检查卡" clearable size="small" />
                </eagle-condition>
            </template>

            <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                        </el-button>
                    </el-col>
                </el-row>
            </template>
            <template slot="slot-table">
                <el-table-column label="检查卡" align="left"> <template slot-scope="scope">
                        <span>{{scope.row.name}}</span>
                    </template>
                </el-table-column>
                <el-table-column label="最近修改人" align="left" prop="editChnName" />
                <el-table-column label="最近修改日期" align="left" prop="editDate" width="180">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.editDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
                <!-- <el-table-column label="操作"  align="left" fixed="right" class-name="small-padding fixed-width">
                    <template slot-scope="scope">
                        <el-button size="mini" type="primary" icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">修改</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除</el-button>
                    </template>
                </el-table-column> -->
            </template>

            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="primary" icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">编辑
                </eagle-row-button>
                <eagle-row-button type="danger" icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除
                </eagle-row-button>
            </template>

        </eagle-page>

    </div>
</template>
<script>
export default {
    name: "fire-check-form",
    props: {
        readOnly: false,
        selectValue: { type: String | Array | Number, default: "" },
    },
    data() {
        return {
            //检查卡
            queryParams: { dataType: "list" },
            conditionsTypes: { name: "like" },
            // 查询条件
            conditionsVals: { name: "" },
            controller: "ecologyEnv/fireChecktask", //对应后端控制器
            form: { name: "", details: [{}] },
            rules: {}, // 表单校验
            title: "检查卡",
            single: true,
            selectItems: [],
            selectionval: [],
        };
    },
    methods: {
        getSelection() {
            return this.$refs.EaglePage.selection;
        },
        handleChildAppend(index) {
            this.form.details.splice(index + 1, 0, {});
        },
        handleChildRemove(index) {
            this.form.details.splice(index, 1);
            if (!this.form.details || this.form.details.length <= 0) {
                this.form.details.splice(0, 0, {});
            }
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        resetQuery() {
            this.conditionsVals.name = "";
            this.search();
        },
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row);
        },
        bindData(data) {
            if (!data.details || data.details.length <= 0) {
                data.details = [];
                data.details.push({});
            }
            this.form = data;
        },
    },
};
</script>