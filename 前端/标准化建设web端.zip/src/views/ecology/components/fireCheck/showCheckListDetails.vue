<template name="show-check-list-details">
  <div>
    <eagle-page :queryParams="queryParams"
      :controller="controller"
      ref="EaglePage"
      table-height="500"
      :showCheckColumn="false"
      :show-btn="false"
    >
      <template slot="slot-search">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
          <eagle-input
            label-width="120px"
            @changeEnter="search()"
            label="筛选条件"
            prop="key"
            v-model="conditionsVals.checkListDetailItem"
            placeholder="请输入检查标准进行模糊查询"
            clearable
            size="small"
          />
        </eagle-condition>
      </template>
      <template slot="slot-table">
        <el-table-column
          label="检查标准"
          align="left"
          prop="checkListDetailItem"
        />
      </template>
    </eagle-page>
  </div>
</template>

<script>
export default {
  name: "show-check-list-details",

  props: {
    readOnly: false,
    selectValue: { type: String | Array | Number, default: "" },
    checkListCode: { type: String, default: "" },
  },
  data() {
    return {
      queryParams: { dataType: "list" },
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        checkListDetailItem: "like",
        mainCode: "=",
      },
      // 查询条件
      conditionsVals: {
        checkListDetailItem: "",
        mainCode: this.checkListCode,
      },
      controller: "ecologyEnv/fireCheckListDetail", //对应后端控制器
      form: {},
      rules: {}, // 表单校验
      title: "检查标准",
      checkList: false,
      selectRow: {},
    };
  },
  methods: {
    //查询
    search() {
      this.conditionsVals.mainCode = this.checkListCode;
      this.$refs.EaglePage.search({
        conditions: this.$refs.EaglePage.getCondtions(
          this.conditionsVals,
          this.conditionsTypes
        ),
      });
    },

    resetQuery() {
      this.conditionsVals.checkListDetailItem = "";
      this.search();
    },

    handleChoose(obj) {
      this.checkList = true;
      this.selectRow = obj;
      console.log(this.selectRow);
    },
    search_checkList() {
      this.$refs.fireCheckForm.search();
    },
  },
};
</script>