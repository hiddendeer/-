<template name="fire-equipment-type">
    <div>
        <eagle-page :queryParams="queryParams" :controller="controller" ref="EaglePage" :showCheckColumn="false">
            <template slot="slot-search">
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <eagle-input label-width="80px" @changeEnter="search()" :inputStyle="{ width: '360px' }" label="筛选条件"
                        prop="name" v-model="conditionsVals.name" placeholder="请输入消防器材类型进行模糊查询" clearable
                        size="small" />
                </eagle-condition>
            </template>

            <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                        </el-button>
                    </el-col>
                </el-row>
            </template>
            <template slot="slot-table">
                <el-table-column label="消防器材类型" prop="name" />
                <el-table-column label="检查卡">
                    <template slot-scope="scope">
                        <template v-if="scope.row.companyCode == '000000'">
                            <span v-if="!scope.row.checkListName">----</span>
                            <a v-else style="color: #46a6ff"
                                @click.stop="showCheckListDetails(scope.row.checkListCode)">{{ scope.row.checkListName
                                }}</a>
                        </template>
                        <template v-else>
                            <span style="color: red" v-if="!scope.row.checkListName">请选择检查卡</span>
                            <a v-else style="color: #46a6ff"
                                @click.stop="showCheckListDetails(scope.row.checkListCode)">{{ scope.row.checkListName
                                }}</a>
                        </template>
                    </template>

                    <!--  
                    <template slot-scope="scope">
                        <a>{{scope.row.checkListName?scope.row.checkListName:'请选择检查卡'}}</a>
                    </template> -->
                </el-table-column>

                <el-table-column label="来源" align="left" prop="editChnName">
                    <template slot-scope="scope">
                        <span v-if="scope.row.companyCode == '000000'">平台</span>
                        <span v-else>{{ scope.row.editChnName }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="最新修改日期" align="left" prop="editDate">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.editDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
                <!-- <el-table-column label="操作"  align="left" fixed="right" class-name="small-padding fixed-width">
                    <template slot-scope="scope" width="120px">
                        <div>
                            <el-button size="small" type="primary" plain icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">修改</el-button>
                        </div>
                        <div style="margin-top:2px;">
                            <el-button size="small" type="warning" plain icon="el-icon-folder-opened" @click.stop="handleChoose(scope.row)">选择检查卡</el-button>
                        </div>
                        <div style="margin-top:2px;">
                            <el-button size="small" type="danger" plain icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除</el-button>
                        </div>
                    </template>
                </el-table-column> -->
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <template>
                    <eagle-row-button type="primary" icon="el-icon-edit" @click.stop="handCopyByTemplate(scope.row)">复制
                    </eagle-row-button>
                    <!-- </template>
                <template v-else> -->
                    <eagle-row-button v-if="scope.row.companyCode == currentCompanyCode" type="primary"
                        icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">编辑</eagle-row-button>
                    <eagle-row-button v-if="scope.row.companyCode == currentCompanyCode" type="danger"
                        icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除</eagle-row-button>
                    <eagle-row-button v-if="scope.row.companyCode == currentCompanyCode" type="warning"
                        icon="el-icon-zoom-opened" @click.stop="handleChoose(scope.row)">选择检查卡</eagle-row-button>
                </template>
            </template>
        </eagle-page>
        <eagle-form :controller="controller" :title="title" :form="form" width="600px" label-width="120px"
            ref="EagleForm" @afterSave="search" @bindData="bindData">
            <eagle-block border>
                <eagle-input label="消防器材类型" v-model="form.name" required prop="name"></eagle-input>
            </eagle-block>
        </eagle-form>
        <el-dialog v-dialogDrag title="选择检查卡" :visible.sync="checkList" width="800px" @opened="search_checkList"
            append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <fire-check-form ref="fireCheckForm" :select-value="selectRow.checkListCode" />
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button @click="checkList = false">取 消</el-button>
                <el-button type="primary" @click="handleChooseFire">确 定</el-button>
            </span>
        </el-dialog>

        <el-dialog v-dialogDrag title="检查卡详情" :visible.sync="fireCheckListDetailVisible" width="800px"
            @opened="search_CheckListDetail" append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <show-check-list-details :checkListCode="showCheckListCode" ref="showCheckListDetails" />
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button @click="fireCheckListDetailVisible = false">关 闭</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import { getCurrentCompany } from "@/utils/auth";
import fireCheckForm from "@/views/ecology/components/fireCheck/fireCheckForm.vue";
import showCheckListDetails from "../fireCheck/showCheckListDetails";
export default {
    name: "fire-equipment-type",
    components: { fireCheckForm, showCheckListDetails },
    props: {
        readOnly: false,
    },
    data() {
        return {
            queryParams: { dataType: "list" },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                name: "like",
            },
            // 查询条件
            conditionsVals: {
                name: "",
            },
            controller: "ecologyEnv/fireEquipmentType", //对应后端控制器
            form: {},
            rules: {}, // 表单校验
            title: "消防器材类型",
            checkList: false,
            selectRow: {},
            fireCheckListDetailVisible: false,
            showCheckListCode: false,
            currentCompanyCode: getCurrentCompany(),
        };
    },
    created() {},
    methods: {
        handleChooseFire() {
            let _this = this;
            let chooseObj = _this.$refs.fireCheckForm.getSelection();
            if (!chooseObj || chooseObj.length <= 0) {
                this.msgError("请选择检查卡");
                return;
            }
            _this.selectRow.checkListCode = chooseObj[0].code;
            console.log(_this.selectRow);

            _this.http
                .post(_this.controller + "/save", _this.selectRow)
                .then((response) => {
                    _this.msgSuccess("保存成功");
                    _this.checkList = false;
                    _this.selectRow.checkListName = chooseObj[0].name;
                });
        },
        getSelection() {
            return this.$refs.EaglePage.selection;
        },
        //查询
        search() {
            setTimeout(() => {
                this.$refs.EaglePage.search({
                    // url: "site/fireEquipmentType/getPageList",
                    conditions: this.$refs.EaglePage.getCondtions(
                        this.conditionsVals,
                        this.conditionsTypes
                    ),
                });
            });
        },
        //导出
        handleExport() {},
        //导入
        handleImport() {},
        //查询条件重置
        resetQuery() {
            this.conditionsVals.name = "";
            this.search();
        },
        bindData(data) {
            this.form = data;
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },

        /**
         * 复制按钮
         */
        handCopyByTemplate(row) {
            var _this = this;
            var url = "/" + this.controller + "/initData/0";
            var params = {};
            this.http.get(url, params).then((response) => {
                var data = response.data;
                var url_s = "/" + _this.controller + "/save_template";
                console.log(data);
                data.id = data.id || 0;
                data.checkListCode = row.checkListCode;
                data.checkListName = row.checkListName;
                data.name = row.name;
                // _this.http.post(url_s, data).then((response) => {
                //   _this.msgSuccess("复制成功");
                //   _this.search();
                // });
                _this.http.postLoading(
                    _this.loading(),
                    url_s,
                    data,
                    function (res) {
                        _this.msgSuccess("复制成功");
                        _this.search();
                    }
                );
            });
            //  this.$refs.EagleForm.copyByTemplate(row);
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },

        bindData(data) {
            this.form = data;
        },
        /** 新增按钮操作 */

        // resetQuery() {
        //     this.conditionsVals.key = "";
        //     this.search();
        // },

        handleChoose(obj) {
            this.checkList = true;
            this.selectRow = obj;
            console.log(this.selectRow);
        },
        search_checkList() {
            this.$refs.fireCheckForm.search();
        },

        search_CheckListDetail() {
            this.$refs.showCheckListDetails.search();
        },
        showCheckListDetails(code) {
            this.showCheckListCode = code;
            this.fireCheckListDetailVisible = true;
        },
    },
};
</script>
<style scoped >
.el-dialog__body {
    padding: 0px 20px;
}
</style>