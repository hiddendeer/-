<template name="fire-equipment">
    <div>
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-input label-width="80px" @changeEnter="search()" :inputStyle="{width:'360px'}" label="筛选条件" :required="false" prop="keyWords" v-model="conditionsVals.keyWords" placeholder="请输入位置,消防器材编号进行模糊查询" clearable size="small" />
        </eagle-condition>
        <eagle-page :queryParams="queryParams" :controller="controller" ref="EaglePage" :showCheckColumn="false">
            <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增
                        </el-button>
                    </el-col>
                    <!-- <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-download" size="mini" @click="handleExport">导出</el-button>
                    </el-col>
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-upload2" size="mini" @click="handleImport">导入</el-button>
                    </el-col> -->
                </el-row>
            </template>
            <template slot="slot-table">
                <el-table-column label="消防器材类型" prop="typeName" width="100" />
                <el-table-column label="消防器材编号" prop="no" width="100" />
                <el-table-column label="所属部门" prop="orgName" />
                <el-table-column label="检查卡" align="left">
                    <template slot-scope="scope">
                        <a style="color:red" v-if="!scope.row.checkListName" @click.stop="handleChoose(scope.row)">请选择检查卡</a>
                        <!-- <span style="color:red" v-if="!scope.row.checkListName">请选择检查卡</span> -->
                        <a v-else style="color:#46a6ff" @click.stop="showCheckListDetails(scope.row.checkListCode)">{{scope.row.checkListName}}</a>
                    </template>
                </el-table-column>
                <el-table-column label="位置" prop="location" />
                <el-table-column label="规格" align="left" prop="specifications" />
                <el-table-column label="数量" align="left" prop="cnt" />
                <el-table-column label="最近点检日期" align="left" prop="checkDay" width="180">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.checkDay, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="点检频率" align="left">
                    <template slot-scope="scope">
                        <span>{{formateDict( params.FrequencyArray,scope.row.frequency) }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建日期" align="left" prop="createDate" width="180">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d}") }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建人" align="left" prop="createChnName" />

            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="primary" icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">编辑
                </eagle-row-button>
                <eagle-row-button v-if="scope.row.checkListName" type="primary" icon="el-icon-zoom-in" @click.stop="handleCheck(scope.row)">点检</eagle-row-button>
                <eagle-row-button type="danger" icon="el-icon-delete" @click.stop="handleDelete(scope.row)">删除
                </eagle-row-button>
            </template>
        </eagle-page>
        <eagle-form :controller="controller" title="消防器材" :form="form" width="800px" label-width="120px" ref="EagleForm" @afterSave="search" @bindData="bindData">
            <eagle-block border>
                <el-row>
                    <el-col :span="24">
                        <eagle-choose label="消防器材类型" is-ful-col v-model="form.typeName" @change="chooseFireType" required prop="typeName" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <eagle-input label="消防器材编号" v-model="form.no" required prop="no" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="所属部门" v-model="form.orgName" required prop="orgName" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <eagle-input label="位置" v-model="form.location" required prop="location" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <eagle-input label="规格" v-model="form.specifications" required prop="specifications" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-input label="数量" type="number" v-model.number="form.cnt" required prop="cnt" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <eagle-select label="点检频率" prop="frequency" v-model="form.frequency" required :data-source="params.FrequencyArray" />
                    </el-col>
                    <el-col :span="12">
                        <eagle-date label="最近点检日期" v-model="form.checkDay" required prop="checkDay" />
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <eagle-input label="备注" v-model="form.remarks" prop="remarks"></eagle-input>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <eagle-attach label="附件" v-model="form.attachs" prop="attachs"></eagle-attach>
                    </el-col>
                </el-row>
            </eagle-block>
        </eagle-form>
        <el-dialog v-dialogDrag title="选择消防器材类型" :visible.sync="chooseFireVisible" width="800px" @opened="search_checkList" append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <choose-fire-equipment-type ref="chooseFireEquipmentType" :select-value="form.typeCode" />
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button @click="chooseFireVisible = false">取 消</el-button>
                <el-button type="primary" @click="handleChooseFireType">确 定</el-button>
            </span>
        </el-dialog>

        <el-dialog v-dialogDrag title="检查卡详情" :visible.sync="fireCheckListDetailVisible" width="800px" @opened="search_CheckListDetail" append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <show-check-list-details :checkListCode="showCheckListCode" ref="showCheckListDetails" />
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button @click="fireCheckListDetailVisible=false">关 闭</el-button>
            </span>
        </el-dialog>

        <el-dialog v-dialogDrag title="选择检查卡" :visible.sync="checkList" width="800px" @opened="search_chooseCheckList" append-to-body show-close :close-on-click-modal="false">
            <eagle-block border>
                <fire-check-form ref="fireCheckForm" :select-value="selectRow.checkListCode" />
            </eagle-block>
            <span slot="footer" class="dialog-footer">
                <el-button @click="checkList = false">取 消</el-button>
                <el-button type="primary" @click="handleChooseFire">确 定</el-button>
            </span>
        </el-dialog>

        <check-task-detail ref="checkTaskDetail" />
    </div>
</template>

<script>
// import eagleDate from "../../../../components/Eagle/eagle-date";
import chooseFireEquipmentType from "../fireCheck/chooseFireEquipmentType";
import showCheckListDetails from "../fireCheck/showCheckListDetails";
import checkTaskDetail from "../fireCheck/checkTaskDetail";
import fireCheckForm from "@/views/ecology/components/fireCheck/fireCheckForm.vue";
export default {
    components: {
        fireCheckForm,
        chooseFireEquipmentType,
        showCheckListDetails,
        checkTaskDetail,
    },
    name: "fire-equipment",
    props: {
        readOnly: false,
    },
    data() {
        return {
            queryParams: { dataType: "list" },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                keyWords: "like",
            },
            // 查询条件
            conditionsVals: {
                keyWords: "",
            },
            controller: "ecologyEnv/fireEquipment", //对应后端控制器
            form: {},
            rules: {}, // 表单校验
            params: {
                FrequencyArray: [],
            },
            title: "消防器材",
            chooseFireVisible: false,
            showCheckListVisibel: false,
            fireCheckListDetailVisible: false,
            showCheckListCode: "",
            checkList: false,
            selectRow: {},
        };
    },
    created() {
        this.initData();
    },
    methods: {
        search_chooseCheckList() {
            this.$refs.fireCheckForm.search();
        },
        handleChoose(obj) {
            this.checkList = true;
            this.selectRow = obj;
            console.log(this.selectRow);
        },
        handleChooseFire() {
            //checkListCode

            let _this = this;
            let chooseObj = _this.$refs.fireCheckForm.getSelection();
            if (!chooseObj || chooseObj.length <= 0) {
                this.msgError("请选择检查卡");
                return;
            }

            _this.selectRow.checkListCode = chooseObj[0].code;

            let obj = {
                code: this.selectRow.typeCode,
                checkListCode: _this.selectRow.checkListCode,
            };

            _this.http
                .post("site/fireEquipmentType/setCard", obj)
                .then((response) => {
                    _this.msgSuccess("保存成功");
                    _this.checkList = false;
                    _this.selectRow.checkListName = chooseObj[0].name;
                });
        },
        //查询
        search() {
            this.$refs.EaglePage.search({
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        //初始化页面所需字典等数据
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.fire_frequency],
                function (res) {
                    _this.params.FrequencyArray = res.data.filter(
                        (p) => p.paramId === _this.constParams.fire_frequency
                    );
                }
            );
        },
        //点检
        handleCheck(row) {
            this.$refs.checkTaskDetail.InitData(row.code);
        },
        //导出
        handleExport() {},
        //导入
        handleImport() {},
        //查询条件重置
        resetQuery() {
            this.conditionsVals.keyWords = "";
            this.search();
        },
        bindData(data) {
            this.form = data;
        },
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            this.$refs.EaglePage.handleDelete(row);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            this.$refs.EagleForm.handleUpdate(row);
        },
        chooseFireType() {
            this.chooseFireVisible = true;
        },
        search_checkList() {
            this.$refs.chooseFireEquipmentType.search();
        },
        handleChooseFireType() {
            let chooseObj = this.$refs.chooseFireEquipmentType.getSelection();
            if (!chooseObj || chooseObj.length <= 0) {
                this.msgError("请选择消防设备类型");
                return;
            }
            this.form.typeCode = chooseObj[0].code;
            this.form.typeName = chooseObj[0].name;
            this.chooseFireVisible = false;
        },
        search_CheckListDetail() {
            this.$refs.showCheckListDetails.search();
        },
        showCheckListDetails(code) {
            this.showCheckListCode = code;
            this.fireCheckListDetailVisible = true;
        },
    },
};
</script>