<template>
    <div class="projectCustomerTrack">
        <!-- <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-input label-width="120px" label="筛选条件" @changeEnter="search" :required="false" prop="customerCode" v-model="conditionsVals.customerCode" placeholder="请输入合作区域名称" clearable size="small" />
        </eagle-condition> -->

        <eagle-page :controller="controller" @bindSelection="bindSelection" ref="EaglePage" :showCheckColumn="false" btnWidth="160">
            <!-- <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd">新增</el-button>
                    </el-col>
                </el-row>
            </template> -->
            <template slot="slot-table">
                <el-table-column label="跟踪人" prop="userName" />
                <el-table-column label="跟踪日期" align="left" prop="trackDate">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.trackDate, '{y}-{m}-{d}') }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="跟踪结果" prop="result" width="350" />
                <el-table-column label="跟踪方式" prop="mode" />
                <el-table-column label="联系人" prop="contact" />
                <el-table-column label="联系方式" prop="mobile" />
                <el-table-column label="下次跟踪日期" align="left" prop="nextTrackDate">
                    <template slot-scope="scope">
                        <span>{{ parseTime(scope.row.nextTrackDate, '{y}-{m}-{d}') }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="预计成单率" prop="rate" />

            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button size="mini" icon="el-icon-edit" @click.stop="handleUpdate(scope.row)">编辑
                </eagle-row-button>
                <eagle-row-button type="danger" size="mini" icon="el-icon-delete" @click.stop="handleDelete(scope.row)">
                    删除</eagle-row-button>
            </template>
        </eagle-page>

        <eagle-form :controller="controller" :title="title" :form="form" width="1000px" label-width="120px" ref="EagleForm" @afterSave="search" @bindData="bindData">
            <eagle-block border>
                <!-- <eagle-radio label="文件类型" prop="plantype" v-model="form.plantype" :data-source="params.site_plan_type" required></eagle-radio> -->
                <eagle-input label="客户编号" v-model="form.customerCode" prop="customerCode" required>
                </eagle-input>
                <eagle-input label="跟踪人" v-model="form.userName" prop="userName" required></eagle-input>
                <eagle-date label="跟踪日期" v-model="form.trackDate" prop="trackDate" required></eagle-date>
                <eagle-input label="跟踪方式" v-model="form.mode" prop="mode" required></eagle-input>
                <eagle-input label="联系人" v-model="form.contact" prop="contact" required></eagle-input>
                <eagle-input label="联系方式" v-model="form.mobile" prop="mobile" required></eagle-input>
                <eagle-input label="预计成单率" v-model="form.rate" prop="rate" required></eagle-input>
                <eagle-date label="下次跟踪日期" v-model="form.nextTrackDate" prop="nextTrackDate" required>
                </eagle-date>
                <eagle-input type="textarea" :autosize="{ minRows: 4, maxRows: 8 }" label="跟踪结果" v-model.trim="form.result" prop="result" required></eagle-input>
            </eagle-block>
        </eagle-form>
    </div>
</template>

<script>
export default {
    name: "projectCustomerTrack",
    props: {
        customerCodeN: { type: String, default: "" },
    },
    data() {
        return {
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                customerCode: "=",
            },
            // 查询条件
            conditionsVals: {
                customerCode: this.customerCodeN,
            },
            controller: "ecologyEnv/projectCustomerTrack",
            // 弹出层标题
            title: "合作区域",
            // params: {
            //     site_plan_type: [],
            // },
            // 遮罩层
            loading: true,
            // 选中数组
            ids: [],
            // 非单个禁用
            single: true,
            // 非多个禁用
            multiple: true,
            // 显示搜索条件
            showSearch: true,

            // 安全设施清单表格数据
            attachList: [],
            // 是否显示弹出层
            open: false,
            // 查询参数
            queryParams: {
                customerCode: "list",
            },

            // 表单参数
            form: {},
        };
    },
    created() {
        this.initData();
    },
    mounted() {
        this.search();
    },
    methods: {
        initData() {
            let _this = this;
        },
        bindData(data) {
            this.form = data;
        },
        /** 新增按钮操作 */
        handleAdd() {
            this.$refs.EagleForm.handleAdd(null);
        },
        /** 修改按钮操作 */
        handleUpdate(row) {
            console.log(row);
            this.$refs.EagleForm.handleUpdate(row);
        },
        bindSelection(selection) {
            console.log(selection);
            this.ids = selection.map((item) => item.id);
            this.single = selection.length != 1;
            this.multiple = !selection.length;
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.refresh();
            });
        },
        //刷新
        refresh() {
            this.$refs.EaglePage.refresh(null);
        },
        search() {
            this.conditionsVals.customerCode = this.customerCodeN;
            console.log(this.customerCodeN);
            this.$refs.EaglePage.search({
                //  url: "site/projectCustomerTrack/getcustomerCode",
                // params: this.queryParams,
                conditions: this.$refs.EaglePage.getCondtions(
                    this.conditionsVals,
                    this.conditionsTypes
                ),
            });
        },
        // 查询条件重置
        resetQuery() {
            this.conditionsVals.customerCode = "";
            this.search();
        },
        //拼装查询条件
        getCondtions() {
            let conditions = [];
            for (let key in this.conditionsVals) {
                let ops = this.conditionsTypes[key];
                let vals = this.conditionsVals[key];
                if (vals) {
                    conditions.push({
                        name: key,
                        operate: !ops ? "like" : ops,
                        value: vals,
                    });
                }
            }
            return conditions != [] ? JSON.stringify(conditions) : [];
        },
    },
};
</script>