<template>
    <div class="div_main_customer_card">
        <el-row>
            <el-col v-bind:span="24">
                <div class="div_customer_title" :class="bgColor|getClass(bgColor)">{{title}}</div>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="24" class="div_card_content">
                <slot>

                </slot>
            </el-col>
        </el-row>
    </div>
</template>
<script>
export default {
    name: "eagle-main-cart",
    props: {
        value: {
            type: String | Number,
            default() {
                return "";
            }
        },
        bgColor: {
            type: String,
            default() {
                return "blue";
            }
        },
        title: {
            type: String,
            default() {
                return "";
            }
        }
    },
    data() {
        return {};
    },
    filters: {
        getClass: function(bgColor) {
            switch (bgColor) {
                case "blue":
                    return "div_customer_blue";
                case "green":
                    return "div_customer_green";
                case "red":
                    return "div_customer_red";
            }
        }
    },
    created() {},
    watch: {}
};
</script>
<style scoped>
.div_main_customer_card {
    width: 265px;
    height: 150px;
    border: 1px solid #f6f7f8;
    box-shadow: 0 2px 6px 0 rgb(0 0 0 / 5%);
    border-radius: 5px;
}

.div_main_customer_card .div_customer_title {
    line-height: 28px;
    border-radius: 5px 0px 5px 0px;
    display: inline-block;
    padding-left: 10px;
    padding-right: 10px;
}

.div_customer_blue {
    background-color: #cae9ff;
    color: #118aff;
}

.div_customer_green {
    background-color: #e3fff0;
    color: #60d394;
}

.div_customer_red {
    background-color: #ffdfe0;
    color: #fd777a;
}

.div_card_content {
    padding: 10px;
    line-height: 28px;
    font-size: 14px;
}

.div_card_content_num_blue {
    color: #1089ff;
}
.div_card_content_num_red {
    color: #fd777a;
}
.div_card_content_num_green {
    color: #60d394;
}
</style>