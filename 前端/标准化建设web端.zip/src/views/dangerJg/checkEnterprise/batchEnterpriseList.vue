<template name="batch-enterprise">
    <div class="batch-enterprise">
        <el-dialog v-dialogDrag :title="title" width="600px" :visible.sync="visible" label-width="120px" show-close :close-on-click-modal="false">
            <eagle-page ref="EaglePage" :noPage="true">
                <template slot="slot-buttons">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="addEnterprise()">
                                新增被检查单位</el-button>
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">
                    <el-table-column label="*被检查单位名称" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.enterpriseName" />
                        </template>
                    </el-table-column>
                    <el-table-column label="*统一社会信用代码" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.organizationCode" />
                        </template>
                    </el-table-column>
                    <el-table-column label="*行业" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.applyProfessionName" />
                        </template>
                    </el-table-column>
                    <el-table-column label="*所在地区" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.area" />
                        </template>
                    </el-table-column>
                    <el-table-column label="公司简称" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.companySname" />
                        </template>
                    </el-table-column>
                    <el-table-column label="公司电话" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.phone" />
                        </template>
                    </el-table-column>
                    <el-table-column label="公司负责人" align="left" width="100">
                        <template slot-scope="scope">
                            <input v-model="scope.row.principal" />
                        </template>
                    </el-table-column>
                </template>
                <!-- <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="danger" v-if="!scope.row.taskCount" icon="el-icon-delete"
                        @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
                </template> -->
            </eagle-page>

        </el-dialog>
    </div>

</template>
<script>
export default {
    components: {},
    name: "batch-enterprise",
    props: {},
    data() {
        return {
            title: "录入被检查单位名称",
            controller: "system/company",
            visible: false,
            model: {},
            list: [],
        };
    },
    created() {},
    methods: {
        submitForm() {
            let _this = this;
            let url = `${this.controller}/batchEnterprise`;
            let array = this.model.enterpriseName
                .replaceAll(" ", "")
                .split(/[(\r\n)\r\n]+/);
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        array,
                        function (res) {
                            if (res.data.result) {
                            }
                        }
                    );
                }
            });
        },

        show() {
            this.visible = true;
        },
    },
};
</script>