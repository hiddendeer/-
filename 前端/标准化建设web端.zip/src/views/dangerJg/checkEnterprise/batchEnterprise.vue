<template name="batch-enterprise">
    <div class="batch-enterprise">
        <el-dialog v-dialogDrag :title="title" width="600px" :visible.sync="visible" label-width="120px" show-close :close-on-click-modal="false">
            <el-form ref="form" :model="model" label-width="120px" class="lg_form" size="small">
                <eagle-input type="textarea" required label="被检查单位名称" placeholder="请输入被检查单位名称,且每行一家被检查单位的名称" prop="enterpriseName" v-model="model.enterpriseName" :rows="10" />
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible=false">取 消</el-button>
                <el-button type="primary" @click="submitForm">确 认</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
export default {
    components: {},
    name: "batch-enterprise",
    props: {},
    data() {
        return {
            title: "录入被检查单位名称",
            controller: "system/company",
            visible: false,
            model: {},
        };
    },
    methods: {
        submitForm() {
            let _this = this;
            let url = `${this.controller}/batchEnterprise`;
            let array = this.model.enterpriseName
                .replaceAll(" ", "")
                .split(/[(\r\n)\r\n]+/);
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        array,
                        function (res) {
                            if (res.data.result) {
                            }
                        }
                    );
                }
            });
        },
        show() {
            this.visible = true;
        },
    },
};
</script>
<style lang="scss" scoped>
</style>