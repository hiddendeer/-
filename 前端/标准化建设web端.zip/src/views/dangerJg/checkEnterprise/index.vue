<template name="danger-check-enterprise-index">
    <div class="danger-check-enterprise-index">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="keyWords"
                v-model="conditions.keyWords.value" placeholder="请输入被检查单位名称进行模糊查询" clearable size="small" />
        </eagle-condition>
        <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams">
            <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary" icon="el-icon-plus" size="mini" @click="addEnterprise()">新增被检查单位
                        </el-button>
                        <!-- <el-button type="primary"  icon="el-icon-plus" size="mini" @click="batchEnterprise()">批量新增被检查单位</el-button> -->
                    </el-col>
                </el-row>
            </template>
            <template slot="slot-table">
                <!-- <el-table-column label="检查单位" align="left" prop="companyName" /> -->
                <el-table-column label="被检查单位名称" align="left" prop="enterpriseName" width="200" />
                <!-- <el-table-column label="联系人/联系电话" align="center" prop="attachs" width="200">
                    <template slot-scope="scope">
                        {{scope.row.contact}}({{scope.row.contactTel}})
                    </template>
                </el-table-column> -->
                <el-table-column label="行业" align="left" prop="applyProfessionName" />
                <!-- <el-table-column label="地址" align="left" prop="address" /> -->
                <el-table-column label="任务数" align="left" prop="taskCount" />
                <el-table-column label="发现隐患数" align="left" prop="dangerCount" />
                <el-table-column label="已复查隐患数" align="left" prop="passCount" />

                <el-table-column label="整改率" align="left" width="100">
                    <template slot-scope="scope">
                        {{scope.row.taskCount ?`${scope.row.passScale}%`:"-"}}
                    </template>
                </el-table-column>
                <el-table-column label="一般隐患数" align="left" prop="dangerTypeCount1" />
                <el-table-column label="重大隐患数" align="left" prop="dangerTypeCount2" />

            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="danger" v-if="!scope.row.taskCount"
                    @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
            </template>
        </eagle-page>
        <eagle-select-project-enterprise ref="projectEnterPriseDialog" :single="false"
            @callBack="handelEnterpriseChoose"></eagle-select-project-enterprise>
        <batchEnterprise ref="batchEnterprise" />
    </div>
</template>

<script>
import eagleSelectProjectEnterprise from "@/views/project/components/selectProjectEnterprise/eagleSelectProjectEnterprise";
import batchEnterprise from "@/views/dangerJg/checkEnterprise/batchEnterprise";

export default {
    name: "danger-check-enterprise-index",
    components: { eagleSelectProjectEnterprise, batchEnterprise },
    data() {
        return {
            controller: "danger/checkEnterprise",
            conditions: {
                keyWords: { value: "", operate: "like" },
            },
            queryParams: {
                dataType: "list",
                projectId: "",
            },
        };
    },

    created() {
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
    },
    mounted() {
        this.search();
    },
    methods: {
        batchEnterprise() {
            this.$refs.batchEnterprise.show();
        },
        addEnterprise() {
            this.$refs.projectEnterPriseDialog.show();
        },
        handelEnterpriseChoose(data) {
            let _this = this;
            if (data) {
                let enterpriseCodes = data.code.split(",");
                let enterpriseNames = data.name.split(",");
                let array = [];
                enterpriseCodes.forEach((item, index) => {
                    array.push({
                        enterpriseName: enterpriseNames[index],
                        enterpriseCode: item,
                        projectId: _this.queryParams.projectId,
                    });
                });

                let url = `${_this.controller}/pushEnterprise/${_this.queryParams.projectId}`;
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    array,
                    function (res) {
                        if (res.data.result) {
                            // if (res.data.anyList && res.data.anyList.length > 0)
                            //     _this.msgSuccess(
                            //         "操作成功:" +
                            //         res.data.anyList +
                            //         "已在项目中,无需重复新增"
                            //     );
                            // else
                            _this.msgSuccess("操作成功");
                            _this.search();
                        }
                    }
                );
            }
        },
        search() {
            this.$refs.EaglePage.search();
        },
        //查询条件重置
        resetQuery() {
            this.conditions.keyWords.value = "";

            this.search();
        },

        handleDelete(row) {
            this.$refs.EaglePage.handleDelete(row);
        },
    },
};
</script>
<style scoped lang="scss">
.danger-check-enterprise-index {
    padding: 10px;
    background: #fff;
}
</style>