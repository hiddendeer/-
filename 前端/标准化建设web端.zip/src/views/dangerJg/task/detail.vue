 <!-- 全局设置 -->
  <template name="danger-check-plan-detail">
    <div>
        <el-dialog v-dialogDrag :visible.sync="submitDialog" width="1000px" append-to-body show-close
            :close-on-click-modal="false" title="编辑检查任务">
            <eagle-block border>
                <div class="danger-check-plan-detail">
                    <el-form ref="elForm" :model="model">
                        <eagle-radio label-width="120px" label="检查类型" prop="checkType" v-model="model.checkType"
                            @change="hdCheckType" required :data-source="params.checkType" />
                        <eagle-input label-width="120px" label="所属项目" :isEdit="false" v-if="urlParams.projectId"
                            v-model="model.sourceName"></eagle-input>
                        <eagle-choose label-width="120px" v-else label="所属项目" prop="sourceName"
                            @change="onProjectChoose" @clearChoose="onClearProject" v-model="model.sourceName" />
                        <eagle-choose label-width="120px" label="被检查单位" prop="enterpriseName"
                            @change="openEnterpriseChoose" v-model="model.enterpriseName" required />
                        <eagle-input label-width="120px" label="任务名称" prop="checkTaskName" v-model="model.checkTaskName"
                            required />
                        <eagle-choose-user label-width="120px" label="检查人" prop="checkCodes" :single="false"
                            :names.sync="model.checkNames" v-model="model.checkCodes" required />
                        <eagle-picker-range picker-options-type="gt" label-width="120px" prop="datetimes"
                            type="daterange" format="yyyy-MM-dd" v-model="model.datetimes" label="开始/截止日期" required />
                        <el-form-item label-width="120px" label="">
                            <el-switch active-color="#13ce66" v-model="model.verifyDanger" />
                            <span>是否需要隐患整改复查</span>
                        </el-form-item>
                        <eagle-input label-width="120px" label="检查要求" v-model="model.checkRequirement" type="textarea"
                            :rows="2" />
                        <el-form-item label="检查表">
                            <el-button size="mini" type="primary" icon="el-icon-edit"
                                @click.prevent.stop="handleChooseLibTemplateShow()">选择检查表</el-button>
                            <div>
                                <ul class="temp">
                                    <li class="temp-item" v-for="(item,index) in formFileList" :key="index"
                                        tabindex="0">
                                        <span class="temp-item-name" @click="hdShowTemplateDetail(item.tCode)"><i
                                                class="el-icon-document"></i> {{item.title}}</span>
                                        <el-button size="mini" type="text" class="el-icon-delete"
                                            @click.prevent.stop="deleteTemp(index)" />
                                    </li>
                                </ul>
                            </div>
                        </el-form-item>
                    </el-form>
                </div>
            </eagle-block>
            <div slot="footer" class="dialog-footer">
                <el-button type="default" @click="submitDialog=false">取 消</el-button>
                <el-button type="primary" @click="submit">保 存</el-button>
            </div>
        </el-dialog>
        <eagle-select-project-enterprise projectApiUrl="danger/checkEnterprise/getPageData"
            ref="projectEnterPriseDialog" :single="true" @callBack="handelEnterpriseChoose">
        </eagle-select-project-enterprise>
        <choose-lib-template ref="chooseLibTemplate" @change="handleChooseLibTemplate" />
        <dangerTemplateDetail ref="dangerTemplateDetail" />
        <windowProjectConsultation ref="windowProjectConsultation" @callBack="chooseProject">
        </windowProjectConsultation>
    </div>
</template>

<script>
import eagleSelectProjectEnterprise from "@/views/project/components/selectProjectEnterprise/eagleSelectProjectEnterprise";
import windowProjectConsultation from "@/views/project/components/projectConsultation/windowProjectConsultation";
import chooseLibTemplate from "@/views/support/public/chooseLibTemplate.vue";
// import DangerTemplateDetail from "./window/dangerTemplateDetail.vue";
import dangerTemplateDetail from "@/views/support/TplOp/window/dangerTemplateDetail.vue";
// import { resetForm } from "@/utils/EageleRMC";
export default {
    components: {
        eagleSelectProjectEnterprise,
        chooseLibTemplate,
        dangerTemplateDetail,
        windowProjectConsultation,
    },
    name: "danger-check-plan-detail",
    data() {
        return {
            controller: "danger/jgDangerTask",
            model: {},
            submitDialog: false,
            datetimes: [],
            params: {
                checkType: [],
            },
            formFileList: [],
            form: {},
            tempModel: {},
            urlParams: {
                code: "",
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    created() { },
    mounted() { },
    methods: {
        show(config) {
            this.submitDialog = true;
            this.initParams();
            this.urlParams.code = config.code ?? "";
            this.urlParams.enterpriseCode = config.enterpriseCode ?? "";
            this.urlParams.projectId = config.projectId ?? "";
            this.formFileList = [];
            this.getModel();
        },

        hdCheckType() {
            let _this = this;
            this.model.checkTypeName = this.formateDict(
                this.params.checkType,
                this.model.checkType
            );
            if (this.model.checkTaskName && this.model.enterpriseName) {
                this.$confirm("是否被覆盖任务名称?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.model.checkTaskName = `${_this.model.enterpriseName
                        }_${_this.model.checkTypeName}${_this.getDateStr()}`;
                });
            } else if (this.model.enterpriseName) {
                _this.model.checkTaskName = `${_this.model.enterpriseName}_${_this.model.checkTypeName
                    }${_this.getDateStr()}`;
            }
        },
        hdShowTemplateDetail(code) {
            this.$refs.dangerTemplateDetail.show({ tCode: code });
        },
        handleChooseLibTemplate(array) {
            var _this = this;
            this.formFileList = [];
            if (array && array.length > 0) {
                array.forEach((x) => {
                    this.formFileList.push(x);
                });
            }
        },
        deleteTemp(index) {
            this.formFileList.splice(index, 1);
            this.form.tCodes = JSON.stringify(this.formFileList);
        },
        handleChooseLibTemplateShow() {
            this.$refs.chooseLibTemplate.show(this.formFileList);
        },
        openEnterpriseChoose() {
            this.$refs.projectEnterPriseDialog.show();
        },
        onProjectChoose() {
            this.$refs.windowProjectConsultation.show(
                this.model.code,
                this.model.sourceName
            );
        },
        onClearProject() {
            this.model.sourceCode = "";
            this.model.projectName = "";
            this.model.sourceName = "";
            this.model.sourceType = "";
        },
        chooseProject(data) {
            this.model.sourceCode = data.code;
            this.model.sourceName = data.name;
            this.model.sourceType = "1";
        },
        handelEnterpriseChoose(data) {
            let _this = this;
            this.model.enterpriseCode = data.code;
            this.model.enterpriseName = data.name;
            if (this.model.checkTaskName && this.model.checkTypeName) {
                this.$confirm("是否被覆盖任务名称?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.model.checkTaskName = `${_this.model.enterpriseName
                        }_${_this.model.checkTypeName}${_this.getDateStr()}`;
                });
            } else if (this.model.checkTypeName) {
                _this.model.checkTaskName = `${_this.model.enterpriseName}_${_this.model.checkTypeName
                    }${_this.getDateStr()}`;
            }
        },

        getDateStr() {
            var date = new Date();
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();
            return `${year}${month > 9 ? month : "0" + month}${day}`;
        },
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type"],
                function (res) {
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                }
            );
        },
        getModel() {
            let _this = this;
            this.formFileList = [];
            let url = `${_this.controller}/${_this.urlParams.code
                    ? "getDataByCode/" + _this.urlParams.code
                    : "initData/0"
                }`;
            _this.http
                .get(url, {
                    enterpriseCode: _this.urlParams.enterpriseCode,
                    projectId: _this.urlParams.projectId,
                })
                .then((res) => {
                    _this.model = res.data;

                    _this.model.tempRelations.forEach((item) => {
                        _this.formFileList.push({
                            tCode: item.tCode,
                            title: item.tName,
                        });
                    });
                    if (
                        (!_this.model.id || _this.model.id == 0) &&
                        _this.params.checkType &&
                        _this.params.checkType.length > 0
                    ) {
                        _this.model.checkType = _this.params.checkType[0].id;
                        _this.model.checkTypeName =
                            _this.params.checkType[0].name;
                    }
                    _this.model.datetimes = [];
                    _this.model.datetimes.push(_this.model.startDate);
                    _this.model.datetimes.push(_this.model.endDate);
                    if (_this.$refs["elForm"]) {
                        _this.$refs["elForm"].resetFields();
                    }
                });
        },

        submit() {
            let _this = this;
            let url = `${this.controller}/createTask`;

            _this.$refs["elForm"].validate(function (valid) {
                if (valid) {
                    _this.model.startDate = _this.model.datetimes[0];
                    _this.model.endDate = _this.model.datetimes[1];
                    _this.model.tempRelations = [];
                    _this.formFileList.forEach((item) => {
                        _this.model.tempRelations.push({
                            tCode: item.tCode,
                            tName: item.title,
                        });
                    });
                    const loading = _this.$loading({
                        lock: true,
                        text: "Loading",
                        spinner: "el-icon-loading",
                        background: "rgba(0, 0, 0, 0.7)",
                    });
                    _this.http.postLoading(
                        loading,
                        url,
                        _this.model,
                        function (res) {
                            _this.msgSuccess("保存成功");
                            _this.submitDialog = false;
                            _this.$emit("saved", res);
                        }
                    );
                }
            });
        },
    },
};
</script>
<style scoped lang="scss">
.danger-check-plan-detail {
    padding: 20px;

    .temp {
        .temp-item-name {
            color: #46a6ff;
            cursor: pointer;
        }

        .el-icon-delete {
            color: red;
        }
    }

    // ::v-deep.el-form-item {
    //     margin-bottom: 0px;
    // }
}
</style>
