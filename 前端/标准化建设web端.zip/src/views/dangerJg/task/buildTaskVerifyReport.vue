<template name="build-task-verify-report">
    <div class="build-task-verify-report">
        <el-dialog v-dialogDrag :title="title" width="600px" :visible.sync="visible" label-width="120px" show-close :close-on-click-modal="false">
            <el-form ref="form" :model="model" label-width="120px" class="lg_form" size="small">
                <eagle-block border>
                    <eagle-input required label="报告名称" prop="reportName" v-model="model.reportName" />
                    <eagle-select label="报告模板" key="reportTemplateCode" prop="reportTemplateCode" required :dataSource="reportTemp" @change="changeReportSource" v-model="model.reportTemplateCode" />
                    <el-col>
                        <eagle-picker-range label-width="120px" type="daterange" format="yyyy-MM-dd" prop="datetimes" v-model="model.datetimes" label="检查起始时间" required @change="changeDatetimes" />
                    </el-col>
                    <el-col>
                        <eagle-input type="textarea" label-width="120px" label="总结和建议" :rows="3" prop="remarks" v-model="model.remarks" />
                    </el-col>
                </eagle-block>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible=false">取 消</el-button>
                <el-button type="primary" @click="submitForm">生成报告</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
// import { resetForm } from "@/utils/EageleRMC";

export default {
    components: {},
    name: "build-task-verify-report",
    props: {},
    data() {
        return {
            title: "生成整改报告",
            controller: "danger/report",
            visible: false,
            model: {},
            reportTemp: [],
            optionModel: {
                relationName: "",
                relationCode: "",
                relationType: null,
                projectId: "",
                enterpriseCode: "",
            },
            reportTemplateCode: null,
        };
    },
    created() {
        this.getReportTemp();
        // this.getModel();
    },
    methods: {
        consoleLog(obj) {
            // console.log("obj", obj);
        },
        changeReportType() {
            let _this = this;
            _this.model.reportName = _this.taskNames;
            this.model.reportTemplateCode = "";
        },
        submitForm() {
            let _this = this;
            let url = `danger/jgDangerTask/buildTaskVerifyReport`;
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        _this.model,
                        function (res) {
                            _this.msgSuccess("报告生成成功");
                            _this.visible = false;
                            if (
                                res.data &&
                                res.data.report &&
                                res.data.report.reportAttach
                            ) {
                                let fileInfo = res.data.report.reportAttach;
                                let row = JSON.parse(fileInfo)[0];
                                let code = row.attCode || row.AttCode;
                                var params = { code: code };
                                params.fileName = row.name;
                                _this.$emit("afterSave", params);
                                // var modulesCode = _this.$route.meta.modulesId;
                                // var name = "DangerFileView";
                                // if (
                                //     modulesCode == "dangerJg" &&
                                //     _this.$route.query.projectId &&
                                //     _this.$route.query.enterpriseCode
                                // ) {
                                //     modulesCode = "dangerJg_child";
                                //     name = "DangerFileChildView";
                                // }
                                // setTimeout(function () {
                                //     _this.$router.push({
                                //         name: name,
                                //         query: {
                                //             attcode: params.code,
                                //             name: params.name,
                                //             projectId:
                                //                 _this.$route.query.projectId,
                                //             enterpriseCode:
                                //                 _this.$route.query
                                //                     .enterpriseCode,
                                //             modulesCode: modulesCode,
                                //         },
                                //     });
                                // }, 300);
                            }
                        }
                    );
                }
            });
        },
        changeReportSource() {
            this.model.reportTemplateName = this.formateDict(
                this.reportTemp,
                this.model.reportTemplateCode
            );
        },
        getModel() {
            let _this = this;
            let url = `${this.controller}/initData/0?projectId=${
                this.optionModel.projectId
            }&reportType=${this.optionModel.relationType == 1 ? 4 : 3}`;
            _this.http.get(url).then((res) => {
                _this.bindData(res.data);
            });
        },
        bindData(data) {
            this.model = data;
            this.model.reportName = this.optionModel.relationName; //this.common.dateFormatStr(new Date);
            this.model.sourceName = this.optionModel.relationName;
            this.model.sourceId = this.optionModel.relationCode;
            this.model.enterpriseCode = this.optionModel.enterpriseCode;
            this.model.enterpriseName = this.optionModel.enterpriseName;
            this.model.projectId = this.optionModel.projectId;
            // this.model.relationType = this.optionModel.relationType;
            if (this.reportTemplateCode) {
                this.model.reportTemplateCode = this.reportTemplateCode;
            }
            this.$set(this.model, "datetimes", []);
            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
            this.model.datetimes.push(this.model.startDate);
            this.model.datetimes.push(this.model.endDate);
        },

        getDateStr() {
            var date = new Date();
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();
            return `${year}${month > 9 ? month : "0" + month}${day}`;
        },

        changeDatetimes(data) {
            this.model.startDate = data[0];
            this.model.endDate = data[1];
        },
        getReportTemp() {
            let _this = this;
            let reportType =
                this.optionModel.relationType == 1
                    ? "DangerJgVerifyReporyByEnterprise"
                    : "DangerJgVerifyReportByTask";
            let url = `site/fileToolDataSource/getMap?reportType=${reportType}`;
            _this.http.get(url).then((res) => {
                _this.reportTemp = res.data;
                if (res.data) {
                    _this.reportTemplateCode = res.data[0].id;
                    _this.reportTemplateName = res.data[0].name;
                }
            });
        },
        show(config) {
            this.optionModel = config.optionModel;
            this.visible = true;
            this.getReportTemp();
            this.getModel();
        },
    },
};
</script>
<style lang="scss" scoped>
</style>
