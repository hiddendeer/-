 <!--  -->
  <template name="danger-jg-batch-build-task">
    <div class="danger-batch-build-task">
        <el-form ref="elForm" :model="model">
            <el-card class="box-card" style="width:780px">
                <div slot="header" class="clearfix">
                    <span style="font-size:16px;">检查任务基本信息 </span><span>({{model.checkTaskName}})</span>
                </div>
                <div>
                    <eagle-radio label-width="120px" label="检查类型" prop="checkType" v-model="model.checkType" @change="hdCheckType" required :data-source="params.checkType" />
                    <eagle-choose label-width="120px" label="被检查单位" prop="enterpriseName" @change="openEnterpriseChoose" v-model="model.enterpriseName" required />
                    <eagle-input label-width="120px" label="任务名称" prop="checkTaskName" v-model="model.checkTaskName" required />
                    <eagle-choose-user label-width="120px" label="检查人" prop="checkCodes" :single="false" :names.sync="model.checkNames" v-model="model.checkCodes" required />
                    <eagle-picker-range picker-options-type="gt" label-width="120px" prop="datetimes" type="daterange" format="yyyy-MM-dd" v-model="model.datetimes" label="开始/截止日期" required />
                    <el-form-item label-width="120px" label="">
                        <el-switch active-color="#13ce66" v-model="model.verifyDanger" />
                        <span>是否需要隐患整改复查</span>
                    </el-form-item>
                    <eagle-input label-width="120px" label="检查要求" v-model="model.checkRequirement" type="textarea" :rows="2" />
                    <el-form-item label="检查表">
                        <el-button size="mini" type="primary" icon="el-icon-edit" @click.prevent.stop="handleChooseLibTemplateShow()">选择检查表</el-button>
                        <div>
                            <ul class="temp">
                                <li class="temp-item" v-for="(item,index) in formFileList" :key="index" tabindex="0">
                                    <span class="temp-item-name" @click="hdShowTemplateDetail(item.tCode)"><i class="el-icon-document"></i> {{item.title}}</span>
                                    <el-button size="mini" type="text" class="el-icon-delete" @click.prevent.stop="deleteTemp(index)" />
                                </li>
                            </ul>
                        </div>
                    </el-form-item>
                    <div style="text-align: center;">
                        <el-button type="default" @click="back">返 回</el-button>
                        <el-button type="primary" @click="submit">保 存</el-button>
                    </div>
                </div>
            </el-card>
        </el-form>
        <eagle-select-project-enterprise ref="projectEnterPriseDialog" :single="true" @callBack="handelEnterpriseChoose"></eagle-select-project-enterprise>
        <choose-lib-template ref="chooseLibTemplate" @change="handleChooseLibTemplate" />
        <dangerTemplateDetail ref="dangerTemplateDetail" />
    </div>
</template>

<script>
import eagleSelectProjectEnterprise from "@/views/project/components/selectProjectEnterprise/eagleSelectProjectEnterprise";
import chooseLibTemplate from "@/views/support/public/chooseLibTemplate.vue";
// import DangerTemplateDetail from "./window/dangerTemplateDetail.vue";
import dangerTemplateDetail from "@/views/support/TplOp/window/dangerTemplateDetail.vue";
// import { resetForm } from "@/utils/EageleRMC";
export default {
    components: {
        eagleSelectProjectEnterprise,
        chooseLibTemplate,
        dangerTemplateDetail,
    },
    name: "danger-jg-batch-build-task",
    data() {
        return {
            controller: "danger/jgDangerTask",
            model: {},

            datetimes: [],
            params: {
                checkType: [],
            },
            formFileList: [],
            form: {},
            tempModel: {},
            urlParams: {
                code: "",
                enterpriseCode: "",
                projectId: "",
            },
        };
    },
    created() {
        this.initParams();

        this.urlParams.code = this.$route.query.code ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";

        this.getModel();
    },
    mounted() {},
    methods: {
        hdCheckType() {
            this.model.checkTypeName = this.formateDict(
                this.params.checkType,
                this.model.checkType
            );
        },
        hdShowTemplateDetail(code) {
            this.$refs.dangerTemplateDetail.show({ tCode: code });
        },
        handleChooseLibTemplate(array) {
            var _this = this;
            this.formFileList = [];
            if (array && array.length > 0) {
                array.forEach((x) => {
                    this.formFileList.push(x);
                });
            }
        },
        deleteTemp(index) {
            this.formFileList.splice(index, 1);
            this.form.tCodes = JSON.stringify(this.formFileList);
        },
        handleChooseLibTemplateShow() {
            this.$refs.chooseLibTemplate.show(this.formFileList);
        },
        openEnterpriseChoose() {
            this.$refs.projectEnterPriseDialog.show();
        },
        handelEnterpriseChoose(data) {
            this.model.enterpriseCode = data.code;
            this.model.enterpriseName = data.name;
        },
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type"],
                function (res) {
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                }
            );
        },
        getModel() {
            let _this = this;
            let url = `${_this.controller}/${
                _this.urlParams.code
                    ? "getDataByCode/" + _this.urlParams.code
                    : "initData/0"
            }`;
            _this.http
                .get(url, {
                    enterpriseCode: _this.urlParams.enterpriseCode,
                    projectId: _this.urlParams.projectId,
                })
                .then((res) => {
                    _this.model = res.data;
                    _this.model.formFileList = [];
                    _this.model.tempRelations.forEach((item) => {
                        _this.formFileList.push({
                            tCode: item.tCode,
                            title: item.tName,
                        });
                    });
                    if (_this.params.checkType) {
                        _this.model.checkType = _this.params.checkType[0].id;
                        _this.model.checkTypeName =
                            _this.params.checkType[0].name;
                    }
                    _this.model.datetimes = [];
                    _this.model.datetimes.push(_this.model.startDate);
                    _this.model.datetimes.push(_this.model.endDate);
                    if (_this.$refs["elForm"]) {
                        _this.$refs["elForm"].resetFields();
                    }
                });
        },
        back() {
            let _this = this;
            _this.$router.push({
                name: _this.urlParams.projectId
                    ? "DangerJgProjectTaskIndex"
                    : "DangerJgTask",
                query: {
                    projectId: _this.urlParams.projectId,
                    enterpriseCode: _this.urlParams.enterpriseCode,
                },
            });
        },
        submit() {
            let _this = this;
            let url = `${this.controller}/createTask`;

            _this.$refs["elForm"].validate(function (valid) {
                if (valid) {
                    _this.model.startDate = _this.model.datetimes[0];
                    _this.model.endDate = _this.model.datetimes[1];
                    _this.model.tempRelations = [];
                    _this.formFileList.forEach((item) => {
                        _this.model.tempRelations.push({
                            tCode: item.tCode,
                            tName: item.title,
                        });
                    });
                    const loading = _this.$loading({
                        lock: true,
                        text: "Loading",
                        spinner: "el-icon-loading",
                        background: "rgba(0, 0, 0, 0.7)",
                    });
                    _this.http.postLoading(
                        loading,
                        url,
                        _this.model,
                        function (res) {
                            _this.msgSuccess("保存成功");
                            setTimeout(() => {
                                if (!_this.urlParams.projectId)
                                    _this.$router.push({
                                        name: "DangerJgTask",
                                    });
                                else {
                                    _this.$router.push({
                                        name: "DangerJgProjectTaskIndex",
                                        query: {
                                            projectId:
                                                _this.urlParams.projectId,
                                            enterpriseCode:
                                                _this.urlParams.enterpriseCode,
                                        },
                                    });
                                }
                            }, 500);
                        }
                    );

                    // _this.http.post(url, _this.model).then(function (res) {
                    //     if (res.code == 200) {
                    //         _this.msgSuccess("保存成功");
                    //         setTimeout(() => {
                    //             loading.close();
                    //             if (!_this.urlParams.projectId)
                    //                 _this.$router.push({
                    //                     name: "DangerJgTask",
                    //                 });
                    //             else {
                    //                 _this.$router.push({
                    //                     name: "DangerJgProjectTaskIndex",
                    //                     query: {
                    //                         projectId:
                    //                             _this.urlParams.projectId,
                    //                         enterpriseCode:
                    //                             _this.urlParams.enterpriseCode,
                    //                     },
                    //                 });
                    //             }
                    //         }, 500);
                    //     }
                    //     else {
                    //         setTimeout(() => {
                    //             loading.close();
                    //         }, 3000);
                    //     }
                    // })
                }
            });
        },
    },
};
</script>
<style scoped lang="scss">
.danger-batch-build-task {
    padding: 20px;
    .temp {
        .temp-item-name {
            color: #46a6ff;
            cursor: pointer;
        }
        .el-icon-delete {
            color: red;
        }
    }
}
</style>
