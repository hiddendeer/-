<template name="danger-dj-task-index">
    <div class="danger-dj-task-index app-container">
        <eagle-page :controller="controller" searchWidth="460px;" ref="EaglePage" :conditions="conditions" :query-params="queryParams" btnWidth="250" :showCheckColumn="false" searchRight="400px">
            <template slot="slot-search">
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <eagle-radio @change="search()" label-width="80px" label="检查类型" prop="checkType" v-model="conditions.checkType.value" :dataSource="params.checkType" size="small" />
                    <eagle-radio @change="search()" label-width="80px" label="状态" prop="status" v-model="conditions.status.value" :dataSource="params.taskStatus" size="small" />
                    <eagle-input :inputStyle="{ 'width': '270px' }" label-width="80px" @changeEnter="search()" label="筛选条件" v-model="conditions.keyWords.value" placeholder="请输入任务名称或者被检查企业模糊查询" clearable size="small" />
                </eagle-condition>
            </template>
            <template slot="slot-buttons">
                <el-button type="primary" icon="el-icon-plus" size="mini" @click="hdShowDetail('')">新增检查任务</el-button>
                <el-button type="primary" icon="el-icon-plus" size="mini" @click="hdBatchDetail('')">批量新增检查任务
                </el-button>

                <el-button v-if="queryParams.projectId" type="primary" icon="el-icon-plus" size="mini" @click="hdChooseTask()">关联任务</el-button>

            </template>
            <template slot="slot-table">
                <el-table-column label="任务名称" align="left" prop="checkTaskName" width="250px" />
                <el-table-column label="被检查单位" align="left" prop="enterpriseName" width="250px" />
                <el-table-column label="检查报告" align="left" prop="plan">
                    <template slot-scope="scope">
                        <eagle-row-attach :isReport="true" v-model="scope.row.checkAttachs"></eagle-row-attach>
                    </template>
                </el-table-column>
                <!-- <el-table-column label="检查人" align="center" prop="checkPersonChName" /> --> -->
                <!-- <el-table-column label="是否复查" align="center" width="100px">
                        <template slot-scope="scope">
                            <span>{{scope.row.verifyDanger?"需要复查":"无需复查"}}</span>
                        </template>
                    </el-table-column> -->
                <el-table-column label="开始/截止日期" align="left" width="210px">
                    <template slot-scope="scope">
                        {{ parseTime(scope.row.startDate, "{y}/{m}/{d}") }}- {{ parseTime(scope.row.endDate,
                                "{y}/{m}/{d}")
                        }}
                    </template>
                </el-table-column>
                <el-table-column label="检查人" align="left" prop="checkNames" />
                <el-table-column label="状态" align="left" width="150px">
                    <template slot-scope="scope">
                        <span v-html="formateStatus(params.taskStatus, scope.row.status)"></span>
                        <span v-if="scope.row.unNextVerify" style="color:red">(无需复查)</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建人" align="left" prop="createChnName" width="120px" />
                <el-table-column label="创建日期" align="left" width="100px">
                    <template slot-scope="scope">
                        {{ parseTime(scope.row.createDate, "{y}/{m}/{d}") }}
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="primary" v-if="scope.row.status == 10" @click.prevent.stop="hdShowDetail(scope.row.code)">编辑</eagle-row-button>
                <eagle-row-button type="success" v-if="scope.row.status == 10" @click.prevent.stop="goView(scope.row.code)">实施</eagle-row-button>
                <eagle-row-button type="success" v-if="scope.row.status > 10" @click.prevent.stop="goView(scope.row.code)">详情</eagle-row-button>

                <eagle-row-button type="danger" v-if="queryParams.projectId" @click.prevent.stop="removeTaskWithProject(scope.row.code)">移出项目</eagle-row-button>
                <eagle-row-button type="danger" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
            </template>
        </eagle-page>
        <taskDetail ref="taskDetail" @saved="afterSave" />
        <batchTask ref="batchTask" @saved="search" />
        <windowTaskList ref="windowTaskList" @change="changeTask" />
    </div>
</template>

<script>
import taskDetail from "@/views/dangerJg/task/detail";
import batchTask from "@/views/dangerJg/task/batchTask";
import windowTaskList from "@/views/dangerJg/dangerJgVerify/windowTaskList";
export default {
    components: { taskDetail, batchTask, windowTaskList },
    name: "danger-check-plan-index",
    data() {
        return {
            controller: "danger/jgDangerTask",
            conditions: {
                keyWords: {
                    name: "checkTaskName,enterpriseName",
                    value: "",
                    operate: "like",
                },
                status: { value: null, operate: "=" },
                checkType: { value: "", operate: "=" },
            },
            queryParams: {
                dataType: "list",
                enterpriseCode: "",
                projectId: "",
            },
            checkType: [],
            params: {
                checkType: [],
                taskStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 10, name: "进行中", color: "#F56C6C" },
                    { id: 25, name: "任务终止", color: "#F56C6C" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    // { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
        };
    },

    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.initParams();
    },
    mounted() {
        this.search();
    },
    methods: {
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type"],
                function (res) {
                    _this.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                }
            );
        },
        search() {
            this.$refs.EaglePage.search();
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.search();
            });
        },
        //查询条件重置
        resetQuery() {
            // this.conditions.checkType.value = "";
            this.conditions.keyWords.value = "";
            this.conditions.status.value = null;

            this.search();
        },
        hdShowDetail(code) {
            this.$refs.taskDetail.show({
                code: code,
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
        },
        hdBatchDetail() {
            this.$refs.batchTask.show({
                enterpriseCode: this.$route.query.enterpriseCode ?? "",
                projectId: this.$route.query.projectId ?? "",
            });
        },
        afterSave(res) {
            let data = res.data;
            this.goView(data.code);
        },
        goView(code) {
            this.$router.push({
                name: this.$route.query.projectId
                    ? "DangerJgTaskView"
                    : "DangerJgTaskViewUs",
                query: {
                    code: code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                    st: this.$route.query.projectId ? 1 : 3,
                },
            });
        },
        hdChooseTask() {
            /**
             * windowTaskList
             */
            this.$refs.windowTaskList.show({
                type: "joinProject",
                projectId: this.queryParams.projectId,
            });
        },
        changeTask(selection) {
            let _this = this;
            let taskCodes = selection.map((x) => x.code);
            let url = `${this.controller}/joinProject/${this.queryParams.projectId}`;
            _this.http.postLoading(
                _this.loading(),
                url,
                taskCodes,
                function (res) {
                    _this.msgSuccess("操作成功");
                    _this.search();
                }
            );
        },
        removeTaskWithProject(taskCode) {
            let _this = this;
            let url = `${this.controller}/removeTaskWithProject/${taskCode}`;

            this.$confirm("是否确认将此任务移出项目?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.msgSuccess("操作成功");
                        _this.search();
                    }
                );
            });
        },
        afterSaved(data) {
            console.log(data);
        },
    },
};
</script>
<style scoped lang="scss">
.danger-dj-task-index {
    padding: 10px;
    background: #fff;
}
</style>