<template name="danger-lg-task-detail-view-new">
    <div class="danger-lg-task-detail-view-new">
        <eagle-form :controller="controller" title="隐患信息" @afterSave="afterSave" :form="form" width="1000px" ref="EagleForm" @bindData="bindDataDetail" :customButtons="true">

            <el-row :gutter="10">
                <el-col :span="18">

                    <eagle-block title="隐患信息">
                        <!-- <div slot="header" class="clearfix">
                            <span>隐患信息</span>
                        </div> -->
                        <div>
                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="隐患来源" label-width="100px">
                                        <span>{{ formateDict(params.checkSource, form.originType) }}</span>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="检查人" label-width="100px">
                                        <span>{{ form.createChnName }}</span>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="检查时间" label-width="100px">
                                        <span>{{ parseTime(form.createDate, "{y}-{m}-{d}") }}</span>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="检查结果" label-width="100px">
                                        {{ formateDict(params.checkResult, form.checkResult) }}
                                    </el-form-item>
                                </el-col>
                            </el-row>

                            <el-row>
                                <eagle-image label-width="100px" key="attachs" :is-edit="false" v-model="form.attachs" label="隐患图片" prop='attachs' :count="3" />
                            </el-row>

                            <el-row>
                                <eagle-label label-width="100px" v-model="form.hiddenDangerArea" label="隐患区域" />
                            </el-row>
                            <el-row>
                                <div style="text-align: right;">
                                    <el-button type="text" @click="hdTemplateCheckShowLg(form)"> 查看依据</el-button>
                                </div>
                            </el-row>
                            <el-row>
                                <eagle-label label-width="100px" v-model="form.hiddenDangerDesc" label="隐患描述" />
                            </el-row>
                            <el-row>
                                <eagle-label label-width="100px" v-model="form.correctiveAdvise" label="整改建议" />
                            </el-row>
                            <el-row>
                                <eagle-label label-width="100px" :span="8" v-model="form.lgdName" label="隐患分类" />
                            </el-row>
                            <el-row>

                                <el-col :span="12">
                                    <el-form-item label="隐患性质" label-width="100px">
                                        {{ formateDict(params.dangerType, form.hiddenDangerType) }}
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="整改期限" label-width="100px">
                                        {{ parseTime(form.correctiveDate, "{y}/{m}/{d}") }}
                                    </el-form-item>
                                </el-col>
                            </el-row>
                        </div>
                    </eagle-block>
                    <eagle-block class="box-card mt10" v-if="form.correctiveAttachs || form.correctiveDesc" title="整改详情">
                        <!-- <div slot="header" class="clearfix">
                            <span>整改详情</span>
                        </div> -->
                        <div>
                            <eagle-image :isEdit="false" label-width="100px" v-model="form.correctiveAttachs" label="整改图片" prop='correctiveAttachs' :count="3" />
                            <el-form-item label="整改说明" label-width="100px">
                                {{ form.correctiveDesc }}
                            </el-form-item>
                            <!-- <eagle-input type="textarea" :rows="2" key="correctiveDesc" label-width="100px" label="整改说明" prop="correctiveDesc" v-model="form.correctiveDesc" /> -->
                        </div>
                    </eagle-block>
                    <eagle-block class="box-card  mt10" v-if="form.verifyAttachs || form.remarks">
                        <div slot="header" class="clearfix">
                            <span>复查详情</span>
                        </div>
                        <div>
                            <el-row>
                                <eagle-image :isEdit="false" label-width="100px" v-model="form.verifyAttachs" label="复查图片" prop='verifyAttachs' :count="3" />
                            </el-row>
                            <el-row>
                                <el-form-item label="复查说明" label-width="100px">
                                    {{ form.remarks }}
                                </el-form-item>
                            </el-row>
                        </div>
                    </eagle-block>
                </el-col>
                <el-col :span="6">
                    <eagle-block class="box-card" title="操作记录">
                        <!-- <div slot="header" class="clearfix">
                            <span>操作记录</span>
                        </div> -->
                        <div>

                            <el-timeline style="margin-left: -45px;">
                                <el-timeline-item v-for="(activity, index) in logs" :key="index" :timestamp="activity.createDate" placement="top">
                                    {{ activity.operateType }}: {{ activity.opeateLog }}
                                </el-timeline-item>
                            </el-timeline>

                        </div>

                    </eagle-block>
                </el-col>
            </el-row>
            <div slot="buttons" class="dialog-footer">
                <el-button @click="cancel">关 闭</el-button>
            </div>
        </eagle-form>
        <templateItem ref="templateItem" />
    </div>
</template>

<script>
import templateItem from "@/views/site/components/danger/template/templateItem";
export default {
    components: {
        templateItem,
    },
    name: "danger-lg-task-detail-view-new",
    props: {},
    data() {
        return {
            controller: "danger/jgDangerTaskDetail",
            form: {},
            type: 0, //1 查看 2 制定措施,3整改,4 复查
            ctype: 1, //1制定措施,2重新指派
            verifyType: 1, // 1复查通过 ,2:不通过
            mainCode: "",
            params: {
                dangerType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkResult: [
                    { id: "Y", name: "符合", color: "#67C23A" },
                    { id: "N", name: "不符合", color: "#F56C6C" },
                    { id: "NA", name: "不适用", color: "#E6A23C" },
                ],
                correctiveMethod: [
                    { id: "1", name: "立即整改" },
                    { id: "2", name: "限时整改" },
                ],
            },
            logs: [],
        };
    },
    created() {
        this.initData();
    },
    computed: {
        correctiveAttach() {
            return this.form.correctiveAttachs || this.form.verifyAttachs;
        },
    },
    methods: {
        reVolid() {
            this.$refs.EagleForm.reVolid();
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        bindDataDetail(data) {
            let _this = this;
            _this.form = data;
        },

        show(params, config) {
            let _this = this;
            _this.type = config.type;
            _this.mainCode = params.code;
            switch (config.type) {
                case 1:
                    config.title = "隐患详情";
                    break;
                case 2:
                    _this.ctype = 1;
                    config.title = "隐患制定措施";
                    break;
                case 3:
                    config.title = "隐患整改";
                    break;
                case 5:
                    config.title = "隐患详情";
                    break;
            }
            _this.$refs.EagleForm.handleUpdate(params, config);
            _this.getLogs();
        },
        getLogs() {
            let _this = this;
            _this.http
                .get(`danger/jgDangerLog/getList/${_this.mainCode}`)
                .then((res) => {
                    _this.logs = res.data;
                });
        },
        cancel(data) {
            this.$refs.EagleForm.cancel();
        },
        submitForm() {
            let tmpType = 0;
            if (this.ctype == 1) {
                tmpType = 1;
            }
            if (this.ctype == 2) {
                tmpType = 2;
            }
            if (this.type == 3) {
                tmpType = 3;
            }
            if (this.type == 5) {
                if (this.verifyType == 1) tmpType = 4;
                if (this.verifyType == 2) tmpType = 5;
            }
            let url = `${this.controller}/modifyTaskDetail/${tmpType}`;
            this.$refs.EagleForm.submitForm({ url: url });
        },
        afterSave() {
            this.$emit("afterSave");
        },
        //检查表检查,查看依据
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({
                model: item,
                isEdit: false,
            });
        },
    },
};
</script>
 
<style scoped lang="scss">
.danger-lg-task-detail-view-new {
    .el-dialog__body {
        padding: 0px 20px;
        max-height: 600px;
        overflow: auto;
    }
}
</style>