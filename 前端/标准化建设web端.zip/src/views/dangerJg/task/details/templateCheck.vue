<template name="danger-jg-template-check">
    <div class="layer">
        <div class="div-danger-jg-fw-template-check">

            <div class="div-left" :style="{height:leftHeight+'px'}">
                <div class="p-location">
                    <div class="dh-title">导航</div>
                    <div :style="{height:(leftHeight-50)+'px',overflow:'auto'}">
                        <ul>
                            <li class="cl-lv1" v-for="(item,index) in templateModel.details" :key="'li'+index">
                                <div class="title" @click="hdNav('item_' + index)" :class="navSelector==('item_' + index)?'act':''">{{index+1}} {{item.detailTitle}}</div>
                                <div v-if="item.grandsons.length>0" class="cl-lv2">
                                    <ul>
                                        <li class="cl-lv2" v-for="(gitem,gindex) in item.grandsons" :key="'li_'+index+'_'+gindex">
                                            <div class="title" :title="gitem.itemName" @click="hdNav('item_' + index + '_' + gindex)" :class="navSelector==('item_' + index + '_' + gindex)?'act':''">
                                                {{index+1}}.{{gindex+1}} {{gitem.itemName}}</div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="div-right">
                <el-form>
                    <div class="tl-container">
                        <div class="block-content">
                            <div class="block-num waithCheck" :class="actBlockIndex==1?'activity':''" @click="hdBlockClick(1)">
                                <p>
                                    <span class="min-icon"></span>
                                    <span>待检查</span>
                                </p>
                                <div class="num-pl">
                                    <span class="num">{{waithCheck}}</span>
                                    <span class="num-unit">项</span>
                                </div>
                            </div>
                            <div class="block-num unUserCheck" :class="actBlockIndex==2?'activity':''" @click="hdBlockClick(2)">
                                <p> <span class="min-icon"></span>
                                    <span>不适用</span>
                                </p>
                                <div class="num-pl">
                                    <span class="num">{{unUserCheck}}</span>
                                    <span class="num-unit">项</span>
                                </div>
                            </div>

                            <div class="block-num failCheck" :class="actBlockIndex==3?'activity':''" @click="hdBlockClick(3)">
                                <p><span class="min-icon"></span>
                                    <span>发现隐患</span>
                                </p>
                                <div class="num-pl">
                                    <span class="num">{{failCheck}}</span>
                                    <span class="num-unit">项</span>
                                </div>
                            </div>

                            <div class="block-num waithInputCheck" :class="actBlockIndex==4?'activity':''" @click="hdBlockClick(4)">
                                <p> <span class="min-icon"></span>
                                    <span>待完善</span>
                                </p>
                                <div class="num-pl">
                                    <span class="num">{{waithInputCheck}}</span>
                                    <span class="num-unit">项</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="check-title-m">
                        检查内容
                    </div>
                    <el-scrollbar ref="scrollbarRef" style="height:calc(100vh - 388px)">
                        <table v-for="(item,index) in templateModel.details" class="tftable" :key="index">
                            <tbody>
                                <tr class="order-row" :key="'item_'+index">
                                    <td class="order-col">
                                        <div :id="'item_'+index">
                                            {{index+1}}
                                        </div>
                                    </td>
                                    <td>
                                        <span> {{item.detailTitle}}</span>
                                    </td>
                                </tr>

                                <tr v-for="(gitem,gindex) in item.grandsons" :key="'item_'+index+'_'+gindex">
                                    <td class="order-col">

                                        {{index+1}}.{{gindex+1}}

                                    </td>
                                    <td>
                                        <div class="btn-td">
                                            <span style="font-size:13px;">
                                                <div :id="'item_'+index+'_'+gindex"> {{gitem.itemName}} </div>
                                            </span>
                                            <div class="btn-group" v-if="isEdit">
                                                <span :class="gitem.checkResult=='Y'?'btn Y checked':'btn Y'" @click="setCheck(gitem,'Y')">符合</span>
                                                <span :class="gitem.checkResult=='N'?'btn N checked':'btn N'" @click="setCheck(gitem,'N')">不符合</span>
                                                <span :class="gitem.checkResult=='NA'?'btn NA checked':'btn NA'" @click="setCheck(gitem,'NA')">不适用</span>
                                            </div>
                                            <div v-else class="btn-group">
                                                <span class="un-btn" :class="gitem.checkResult=='Y'?'btn Y checked':'btn Y'">符合</span>
                                                <span class="un-btn" :class="gitem.checkResult=='N'?'btn N checked':'btn N'">不符合</span>
                                                <span class="un-btn" :class="gitem.checkResult=='NA'?'btn NA checked':'btn NA'">不适用</span>
                                            </div>
                                        </div>
                                        <div class="div-op" v-if="gitem.checkResult" :key="'item2_'+index+'_'+gindex">
                                            <div v-show="gitem.checkResult==='N'" class="content-N">

                                                <div v-for=" (ditem, dindex) in gitem.checkDetails" :key="'item_' + index + '_' + gindex + '_' + dindex" :id="'item_' + index + '_' + gindex + '_' + dindex" class="cn-item">
                                                    <div class="box-item">
                                                        <div style="display: flex;">

                                                            <div style="width: 170px;" v-if="ditem.attachs">
                                                                <eagle-image key="attachs" :showImgCount="1" show-default-img :isEdit="false" v-model="ditem.attachs" />
                                                            </div>
                                                            <div style="margin-top:10px;">
                                                                <div>
                                                                    <div class="double-line" style="text-indent: 2em; line-height: 22px;">
                                                                        隐患描述:
                                                                        {{ ditem.hiddenDangerDesc }}
                                                                    </div>
                                                                </div>
                                                                <div style="margin-top: 15px;">
                                                                    <div style="text-indent: 2em; line-height: 22px;">
                                                                        隐患位置:
                                                                        {{ ditem.hiddenDangerArea }}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div style="position: absolute;right: 20px;bottom: 20px;">
                                                            <el-button type="primary" size="small" icon="el-icon-edit-outline" @click="editCheck(ditem,gitem.greatGrandsons)" style="height: 30px;">编辑</el-button>
                                                            <el-button type="danger" size="small" icon="el-icon-delete" @click="removeDanger(gitem,dindex)" style="height: 30px;">删除</el-button>
                                                        </div>
                                                        <div class="isOverTag" v-if="fnValidIsOver(ditem)">
                                                            <span>待完善</span>
                                                        </div>
                                                    </div>
                                                    <hr style="border:1px dashed #DCDFE6;margin-top:10px" />

                                                </div>

                                                <div style="padding: 10px;" class="cn-item">
                                                    <el-button type="primary" icon="el-icon-circle-plus-outline" @click="pushDanger(gitem) ">新增隐患
                                                    </el-button>
                                                </div>
                                            </div>
                                        </div>

                                    </td>
                                </tr>

                            </tbody>
                        </table>
                        <div style="height:calc(100vh - 480px)"></div>
                    </el-scrollbar>
                </el-form>
                <div class="div-button-container">
                    <el-button @click="hdBack" type="default">返 回</el-button>
                    <el-button :disabled='waithCheck != 0' @click="post" v-if="isEdit" type="primary">保存并返回</el-button>
                </div>
            </div>
            <templateSingleCheck @confirm="singleConfirm" ref="templateSingleCheck" />
        </div>
    </div>
</template>
<script>
import chooseDangerType from "@/views/components/danger/chooseDangerType";
import templateSingleCheck from "@/views/dangerJg/task/details/templateSingleCheck";

export default {
    components: { chooseDangerType, templateSingleCheck },
    data() {
        return {
            taskCode: "",
            controller: "danger/jgDangerTaskDetail",
            templateCode: "",
            templateModel: {},
            chooseItem: {},
            tempCheckDetail: [],
            isEdit: false,
            params: {
                // dangerCheckTaskType: [],
                opType: [],
                dangerType: [],

                checkResult: [
                    { id: "Y", name: "符合", color: "#67C23A" },
                    { id: "N", name: "不符合", color: "#F56C6C" },
                    { id: "NA", name: "不适用", color: "#E6A23C" },
                ],
            },
            urlParams: {
                projectId: "",
                enterpriseCode: "",
            },
            defaultHiddenDangerArea: "",
            defaultCorrectiveDate: "",
            navSelector: "",
            swaperPreIndex: 0,
            actBlockIndex: 0,
            leftHeight: window.innerHeight - 180,
        };
    },
    created() {
        this.templateCode = this.$route.query.templateCode ?? "";
        this.taskCode = this.$route.query.taskCode ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
        this.isEdit = this.$route.query && this.$route.query.ed === "Y";
        console.log("create=>");
        this.initData();
        this.getTemplate();
    },
    computed: {
        waithCheck() {
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (!citem.checkResult) num++;
                    });
                });
            return num;
        },
        unUserCheck() {
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (citem.checkResult === "NA") num++;
                    });
                });
            return num;
        },

        failCheck() {
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (
                            citem.checkResult === "N" &&
                            citem.checkDetails &&
                            citem.checkDetails.length > 0
                        ) {
                            num = num + citem.checkDetails.length;
                        }
                    });
                });
            return num;
        },
        waithInputCheck() {
            let _this = this;
            let num = 0;
            if (
                this.templateModel &&
                this.templateModel.details &&
                this.templateModel.details.length > 0
            )
                this.templateModel.details.forEach((item, index) => {
                    item.grandsons.forEach((citem, cindex) => {
                        if (
                            citem.checkResult === "N" &&
                            citem.checkDetails &&
                            citem.checkDetails.length > 0
                        ) {
                            citem.checkDetails.forEach((x) => {
                                // if (
                                //     !x.hiddenDangerArea ||
                                //     !x.hiddenDangerDesc ||
                                //     !x.lgdName ||
                                //     !x.hiddenDangerType
                                // )
                                if (_this.fnValidIsOver(x)) {
                                    num++;
                                }
                            });
                        }
                    });
                });
            return num;
        },
    },

    methods: {
        fnValidIsOver(item) {
            return (
                !item.hiddenDangerDesc ||
                !item.lgdName ||
                !item.hiddenDangerType ||
                (item.lgdType == "2" && !item.hiddenDangerArea)
            );
        },
        hdNav(selector) {
            this.navSelector = selector;
            this.goAnchor("#" + selector);
        },

        hdBlockClick(index) {
            this.fnSwaper(index);
        },
        fnSwaper(type) {
            let _this = this;
            if (type == _this.actBlockIndex)
                _this.swaperPreIndex = _this.swaperPreIndex + 1;
            else {
                _this.actBlockIndex = type;
                _this.swaperPreIndex = 0;
            }
            //定义min 是为了减少循环,且避免死循环
            let index = -1;
            let minIndex = -1;

            let flag = false;
            let minFlag = false;

            let selector = "";
            let minSelector = "";

            if (
                _this.templateModel.details &&
                _this.templateModel.details.length > 0
            )
                _this.templateModel.details.forEach((item, i) => {
                    item.grandsons.forEach((citem, ci) => {
                        switch (type) {
                            //待检查项
                            case 1:
                                index++;
                                if (minFlag == false && !citem.checkResult) {
                                    minIndex = index;
                                    minFlag = true;
                                    minSelector = `#item_${i}_${ci}`;
                                }
                                if (flag == false && !citem.checkResult) {
                                    if (index >= _this.swaperPreIndex) {
                                        _this.swaperPreIndex = index;
                                        flag = true;
                                        selector = `#item_${i}_${ci}`;
                                    }
                                }
                                break;
                            //不适用项
                            case 2:
                                index++;
                                if (
                                    minFlag == false &&
                                    citem.checkResult === "NA"
                                ) {
                                    minIndex = index;
                                    minFlag = true;
                                    minSelector = `#item_${i}_${ci}`;
                                }
                                if (
                                    flag == false &&
                                    citem.checkResult === "NA"
                                ) {
                                    if (index >= _this.swaperPreIndex) {
                                        flag = true;
                                        _this.swaperPreIndex = index;
                                        selector = `#item_${i}_${ci}`;
                                    }
                                }
                                break;

                            //隐患数
                            case 3:
                                if (citem.checkResult === "N")
                                    if (
                                        citem.checkDetails &&
                                        citem.checkDetails.length > 0
                                    ) {
                                        citem.checkDetails.forEach(
                                            (gitem, gi) => {
                                                index++;
                                                if (
                                                    minFlag == false &&
                                                    gitem.checkResult === "N"
                                                ) {
                                                    minIndex = index;
                                                    minFlag = true;
                                                    minSelector = `#item_${i}_${ci}_${gi}`;
                                                }
                                                if (
                                                    flag == false &&
                                                    gitem.checkResult === "N"
                                                ) {
                                                    if (
                                                        index >=
                                                        _this.swaperPreIndex
                                                    ) {
                                                        flag = true;
                                                        _this.swaperPreIndex =
                                                            index;
                                                        selector = `#item_${i}_${ci}_${gi}`;
                                                    }
                                                }
                                            }
                                        );
                                    }
                                break;
                            //待完善
                            case 4:
                                if (citem.checkResult === "N") {
                                    if (
                                        citem.checkDetails &&
                                        citem.checkDetails.length > 0
                                    ) {
                                        citem.checkDetails.forEach(
                                            (gitem, gi) => {
                                                index++;
                                                if (
                                                    minFlag == false &&
                                                    _this.fnValidIsOver(gitem)
                                                ) {
                                                    minIndex = index;
                                                    minFlag = true;
                                                    minSelector = `#item_${i}_${ci}_${gi}`;
                                                }
                                                if (
                                                    flag == false &&
                                                    _this.fnValidIsOver(gitem)
                                                ) {
                                                    if (
                                                        index >=
                                                        _this.swaperPreIndex
                                                    ) {
                                                        flag = true;
                                                        _this.swaperPreIndex =
                                                            index;
                                                        selector = `#item_${i}_${ci}_${gi}`;
                                                    }
                                                }
                                            }
                                        );
                                    }
                                }

                                break;
                        }
                    });
                });
            if (selector) {
                _this.goAnchor(selector);
            } else if (minSelector) {
                _this.swaperPreIndex = minIndex;
                _this.goAnchor(minSelector);
            }
        },

        singleConfirm(item, opType) {
            if (opType == "add") {
                this.defaultCorrectiveDate = item.correctiveDate;
                this.defaultHiddenDangerArea = item.hiddenDangerArea;
            }
        },
        removeDanger(model, index) {
            model.checkDetails.splice(index, 1);
            if (!model.checkDetails || model.checkDetails.length <= 0)
                model.checkResult = "";
            //
        },

        editCheck(item, dangerSource, action) {
            let _this = this;
            _this.$refs.templateSingleCheck.show({
                model: item,
                dangerSource: dangerSource,
                isEdit: true,
                action: action,
            });
        },
        hdViewDanger(item, dangerSource) {
            let _this = this;
            _this.$refs.templateSingleCheck.show({
                model: item,
                dangerSource: dangerSource,
                isEdit: false,
            });
        },

        clearHidden(obj) {
            obj.lgdType = "";
            obj.lgdCode = "";
            obj.lgdName = "";
        },

        handleRandShowHidden(item) {
            this.chooseItem = item;
            this.$refs.chooseDangerType.show();
        },
        handleChooseDangerType(val, obj) {
            this.chooseItem.lgdType = obj.dType;
            this.chooseItem.lgdCode = val;
            this.chooseItem.lgdName = obj.dFullName.replace(">", "-");
        },
        initData() {
            console.log("initData=>");
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        //锚点跳转
        goAnchor(selector) {
            let sss = document.querySelector(selector);
            let top = this.getAbsCoordinates(document.querySelector(selector));
            let tempPx = 220;
            this.$refs.scrollbarRef.wrap.scrollTop = top - tempPx;
        },
        getAbsCoordinates(e) {
            var pos = { top: 0, left: 0 };
            while (e && e.tagName != "BODY") {
                pos.left += e.offsetLeft;
                pos.top += e.offsetTop;
                e = e.offsetParent;
            }
            return pos.top;
        },
        getCheckList() {
            let _this = this;
            let url = `${_this.controller}/getTempCheckItem/${_this.taskCode}/${_this.templateCode}`;

            _this.http.get(url).then((res) => {
                _this.tempCheckDetail = res.data;
                _this.reSetModel();
            });
        },
        setCheck(item, checkResult) {
            item.checkResult =
                item.checkResult === checkResult ? "" : checkResult;

            if (item.checkResult == "N") {
                if (
                    (item.checkDetails && item.checkDetails.length > 0) == false
                ) {
                    item.checkDetails.push(this.getPushModel(item, true));
                    this.editCheck(
                        item.checkDetails[0],
                        item.greatGrandsons,
                        "add"
                    );
                }
            }
        },
        pushDanger(item) {
            //checkDetails
            item.checkDetails.push(this.getPushModel(item, false));
            this.editCheck(
                item.checkDetails[item.checkDetails.length - 1],
                item.greatGrandsons,
                "add"
            );
        },
        getPushModel(item, isInit) {
            var data = {
                hiddenDangerDesc: "",
                hiddenDangerArea: this.defaultHiddenDangerArea,
                correctiveDate: this.defaultCorrectiveDate,
                hiddenDangerType: "",
                correctiveAdvise: item.correctiveAdvise,
                lgdName: "",
                lgdCode: "",
                lgdType: "",
                legalLiability: item.legalLiability,
                gistSource: item.gistSource,
                originalText: item.originalText,
                detailItemFullNo: "",
                tCode: this.templateCode,
                ctCode: this.taskCode,
                tName: this.templateModel.title,
                detailNo: "",
                checkResult: "N",
                originType: 3,
            };
            if (
                isInit &&
                item &&
                item.greatGrandsons &&
                item.greatGrandsons.length == 1
            ) {
                let itemDetial = item.greatGrandsons[0];
                data.hiddenDangerDesc = itemDetial.hiddenDangerDesc;
                data.hiddenDangerType = itemDetial.hiddenDangerType;
                data.legalLiability = itemDetial.legalLiability;
                data.hiddenCode = itemDetial.dCode;
                data.lgdType = itemDetial.dType;
                data.lgdCode = itemDetial.dCode;
                if (itemDetial.dName) {
                    data.hiddenTypeName =
                        itemDetial.dType == "1" ? "基础管理" : "现场管理";
                    data.lgdName =
                        data.hiddenTypeName +
                        "-" +
                        itemDetial.dName.replace(">", "-");
                }
            }
            return data;
        },
        reSetModel() {
            let _this = this;
            _this.templateModel.details.forEach((item) => {
                if (item.grandsons && item.grandsons.length > 0) {
                    item.grandsons.forEach((citem) => {
                        _this.$set(citem, "checkResult", "");
                        _this.$set(citem, "checkDetail", {
                            detailItemFullNo: citem.itemFullNo,
                            detailNo: citem.itemNo,
                            checkResult: "",
                            tCode: _this.templateCode,
                            ctCode: _this.taskCode,
                            tName: _this.templateModel.title,
                            originType: 3,
                        });
                        let array = _this.tempCheckDetail.filter(
                            (x) => x.detailItemFullNo == citem.itemFullNo
                        );
                        if (array && array.length > 0) {
                            _this.$set(citem, "checkDetails", array);
                            citem.checkResult = array[0].checkResult;
                        } else {
                            _this.$set(citem, "checkDetails", []);
                        }
                        // else {
                        //     _this.$set(citem, "checkDetails", [
                        //         this.getPushModel(citem),
                        //     ]);
                        // }
                    });
                }
            });
        },
        getTemplate() {
            let _this = this;
            let url = `support/DagerTpl/GetTemplateByCode?tCode=${this.templateCode}`;
            _this.http.get(url).then((res) => {
                _this.templateModel = res.data;
                _this.getCheckList();
            });
        },
        post() {
            let _this = this;

            let array = [];
            let message = "";
            let selector = "";
            // debugger;
            _this.templateModel.details.forEach((item, index) => {
                item.grandsons.forEach((citem, cindex) => {
                    if (citem.checkResult == "N") {
                        if (citem.checkDetails && citem.checkDetails.length > 0)
                            citem.checkDetails.forEach((gitem, dindex) => {
                                gitem.detailItemFullNo = citem.itemFullNo;
                                gitem.detailNo = citem.itemNo;
                                gitem.checkResult = "N";
                                array.push(gitem);
                            });
                    }
                    if (citem.checkResult == "Y" || citem.checkResult == "NA") {
                        citem.checkDetail.checkResult = citem.checkResult;
                        array.push(citem.checkDetail);
                    }
                });
            });
            let url = `${_this.controller}/tempCheck/${_this.taskCode}/${_this.templateCode}`;
            _this.http.postLoading(_this.loading(), url, array, function (res) {
                _this.hdBack();
            });
            // _this.http.post(url, array).then((res) => {
            //     _this.hdBack();
            //     // _this.$router.push({
            //     //     name: _this.urlParams.projectId ? "DangerJgTaskView" : "DangerJgTaskViewUs",
            //     //     query: {
            //     //         code: _this.taskCode,
            //     //         projectId: _this.urlParams.projectId,
            //     //         enterpriseCode: _this.urlParams.enterpriseCode,
            //     //     },
            //     // });
            // });
        },
        hdBack() {
            let _this = this;
            _this.$router.push({
                name: _this.urlParams.projectId
                    ? "DangerJgTaskView"
                    : "DangerJgTaskViewUs",
                query: {
                    code: _this.taskCode,
                    projectId: _this.urlParams.projectId,
                    enterpriseCode: _this.urlParams.enterpriseCode,
                },
            });
        },
    },
};
</script>
 
<style lang="scss" scoped>
.div-danger-jg-fw-template-check {
    .box-item {
        display: flex;
        justify-content: space-between;
    }

    .double-line {
        text-indent: 2em;
        line-height: 22px;
        display: -webkit-box;
        text-overflow: ellipsis;
        overflow: hidden;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    display: flex;
    margin-left: 10px;
    margin-right: 10px;
    display: flex;

    ::v-deep .el-form-item {
        margin: 10px;
    }

    .p-location {
        overflow: auto;
        // z-index: 9;
        // position: fixed;
        // padding: 5px 0px;
        text-align: center;
        width: 100%;
        min-height: 22px;

        .dh-title {
            height: 40px;
            background: #f5f7fa;
            font-size: 16px;
            line-height: 40px;
        }

        ul,
        li {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        li.cl-lv1 {
            padding: 2px 10px;
            .title {
                line-height: 35px;
                font-size: 12px;
                font-weight: 600;
                color: #303133;
            }
            .title.act {
                color: #409eff;
            }
        }
        li.cl-lv2 {
            height: 35px;
            .title {
                font-size: 12px;
                font-weight: 400;
                color: #606266;
                height: 35px;
                line-height: 35px;
                border-bottom: 1px solid #f5f7fa;
            }
            .title.act {
                color: #409eff;
            }
        }
        .title {
            text-align: left;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block;
            cursor: pointer;
            line-height: 25px;
            font-size: 12px;
            // margin: 0px auto 10px auto;
            color: #707070;
        }

        .cl-lv1 {
            padding-left: 10px;
        }

        // .cl-lv2 {
        //     // padding-left: 15px;
        // }
    }

    .div-left {
        width: 185px;
        // padding: 5px;
        border: 1px solid #e1e1e1;
        border-radius: 4px;
        margin-right: 10px;
        padding-bottom: 5px;
    }

    .div-right {
        flex: 1;
        margin-right: 10px;
        width: calc(100vw - 530px);
    }

    // .div-left,
    .div-right {
        padding: 15px;
        border: 1px solid #e1e1e1;
        border-radius: 4px;
        table.tftable {
            font-size: 12px;
            color: #333333;
            width: 100%;
            margin-bottom: 15px;
            // box-shadow: 1px #e4e4e4;
        }
        ::deep .el-scrollbar__wrap {
            overflow-x: hidden;
        }
        table.tftable td {
            border: 1px solid #e4e4e4;
            border-left: none;
            border-top: none;
            border-spacing: xpx;
            // padding: 5px;
            text-align: left;
        }

        table.tftable td span {
            line-height: 1.6;
        }

        table.tftable {
            border-radius: 5px;
            border-spacing: 0;
            .order-row {
                background-color: #ecf5ff;
                color: #409eff;
                td {
                    padding: 10px 5px;
                }
            }

            .order-col {
                text-align: center;
                width: 60px;
            }

            tr:first-child td {
                border-top: 1px solid #e4e4e4;
            }
            tr td:first-child {
                border-left: 1px solid #e4e4e4;
            }
            tr:first-child td:first-child {
                border-top-left-radius: 10px; /* 设置table左下圆角 */
            }
            tr:first-child td:last-child {
                border-top-right-radius: 10px; /* 设置table右下圆角 */
            }
            tr:last-child td:first-child {
                border-bottom-left-radius: 10px; /* 设置table左下圆角 */
            }
            tr:last-child td:last-child {
                border-bottom-right-radius: 10px; /* 设置table右下圆角 */
            }
            tr:first-child td {
                border-bottom: none;
            }
        }
        .isOverTag {
            padding: 0px 10px;
            color: #ff6600;
            background-color: #f6e4df;
            position: absolute;
            right: 0px;
            top: -1px;
            font-size: 12px;
            width: 56px;
            height: 28px;
            border-bottom-left-radius: 5px;
            line-height: 28px;
        }

        .cn-item {
            position: relative;
            text-align: left;

            .btn-rm {
                position: absolute;
                right: 10px;
                top: 10px;
                color: red;
                cursor: pointer;
                z-index: 100;
            }
        }

        .swp {
            display: flex;
            justify-content: space-between;
            border: 1px solid #e4e4e4;
            border-bottom: 0px;
            border-right: 0px;
            background: #ecf8ff;

            span {
                width: 25%;
                text-align: center;
                line-height: 35px;
                border-right: 1px solid #e4e4e4;
                font-size: 14px;
            }
        }

        .el-form-item {
            margin-bottom: 10px;
        }

        .item-title {
            text-align: left;
        }

        .item-title span {
            margin: 10px !important;
        }

        .btn-td {
            display: flex;
            justify-content: space-between;
            padding: 10px;

            .btn-group {
                display: flex;
                justify-content: space-between;

                .btn {
                    width: 80px;
                    display: block;
                    margin-left: 5px;
                    margin-right: 5px;
                    display: -webkit-box;
                    display: -webkit-flex;
                    display: flex;
                    -webkit-box-pack: center;
                    -webkit-justify-content: center;
                    justify-content: center;
                    height: 30px;
                    border-radius: 5px;
                    line-height: 30px;
                    cursor: pointer;
                    border: 1px solid #e4e4e4;
                }

                .btn.Y.checked {
                    background-color: #19be6b;
                    color: #ffffff;
                }

                .btn.N.checked {
                    background-color: red;
                    color: #ffffff;
                }

                .btn.NA.checked {
                    background-color: #ff976a;
                    color: #ffffff;
                }
            }
        }

        .div-op {
            background: #f5f7fa;
        }

        .div-op .content-N {
            .cn-item:first-child {
                border-top: 1px solid #e1e1e1;
            }

            .box-item {
                padding: 10px;
            }
        }

        .div-op .content-Y {
            padding: 10px;
            position: relative;
            .cn-item:first-child {
                border-top: 1px solid #e1e1e1;
            }
        }

        .using-content {
            font-size: 13px;
        }

        .btn-using {
            color: #409eff;
            cursor: pointer;
            font-size: 13px;
        }

        .div-button-container {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
            margin-top: 10px;
        }

        .tl-container {
            .block-content {
                display: flex;
                justify-content: flex-start;
                margin-bottom: 10px;
            }

            .block-num {
                width: 226px;
                height: 90px;
                border-radius: 4px;
                cursor: pointer;
                margin-right: 15px;
                p {
                    margin-top: 15px;
                    margin-left: 15px;
                }
                .min-icon {
                    width: 16px;
                    height: 16px;
                    margin-right: 5px;
                    float: left;
                }
                .num-pl {
                    margin-top: 5px;
                    text-align: center;
                    .num {
                        font-size: 36px;
                        font-weight: bold;
                        line-height: 42px;
                    }
                    .num-unit {
                        font-size: 12px;
                    }
                }
            }

            .block-num.waithCheck {
                background: url("../../../../assets/img/danger/bg-num1.png")
                    no-repeat;
                color: #409eff;
                .min-icon {
                    background: url("../../../../assets/img/danger/num1-ico.png")
                        no-repeat;
                }
            }

            .block-num.waithCheck:hover,
            .block-num.waithCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num1.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num1-ico.png")
                        no-repeat;
                }
            }

            .block-num.unUserCheck {
                background: url("../../../../assets/img/danger/bg-num2.png")
                    no-repeat;
                color: #e6a23c;
                .min-icon {
                    background: url("../../../../assets/img/danger/num2-ico.png")
                        no-repeat;
                }
            }

            .block-num.unUserCheck:hover,
            .block-num.unUserCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num2.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num2-ico.png")
                        no-repeat;
                }
            }

            .block-num.failCheck {
                background: url("../../../../assets/img/danger/bg-num3.png")
                    no-repeat;
                color: #f56c6c;
                .min-icon {
                    background: url("../../../../assets/img/danger/num3-ico.png")
                        no-repeat;
                }
            }
            .block-num.failCheck:hover,
            .block-num.failCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num3.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num3-ico.png")
                        no-repeat;
                }
            }

            .block-num.waithInputCheck {
                background: url("../../../../assets/img/danger/bg-num4.png")
                    no-repeat;
                color: #a254dd;
                .min-icon {
                    background: url("../../../../assets/img/danger/num4-ico.png")
                        no-repeat;
                }
            }
            .block-num.waithInputCheck:hover,
            .block-num.waithInputCheck.activity {
                background: url("../../../../assets/img/danger/act-bg-num4.png")
                    no-repeat;
                color: #ffffff;
                .min-icon {
                    background: url("../../../../assets/img/danger/act-num4-ico.png")
                        no-repeat;
                }
            }

            .check-title-m {
                height: 20px;
                font-size: 14px;
                font-weight: bold;
                color: #303133;
                line-height: 20px;
                margin-top: 10px;
                margin-bottom: 10px;
            }
        }
    }
}

// .box-item {
//     display: flex;
//     justify-content: space-between;
// }
// .double-line {
//     text-indent: 2em;
//     line-height: 22px;
//     display: -webkit-box;
//     text-overflow: ellipsis;
//     overflow: hidden;
//     -webkit-line-clamp: 2;
//     -webkit-box-orient: vertical;
// }
// .div-danger-jg-template-check {
//     display: flex;
//     margin-left: 10px;
//     margin-right: 10px;
//     display: flex;
//     ::v-deep .el-form-item {
//         margin: 10px;
//     }

//     .p-location {
//         overflow: auto;
//         z-index: 1;
//         position: fixed;
//         padding: 5px 0px;
//         text-align: center;
//         width: 172px;
//         min-height: 22px;
//         height: calc(100vh - 320px);
//         ul,
//         li {
//             padding: 0;
//             margin: 0;
//             list-style: none;
//         }
//         .title {
//             text-align: left;
//             white-space: nowrap;
//             overflow: hidden;
//             text-overflow: ellipsis;
//             display: block;
//             cursor: pointer;
//             line-height: 25px;
//             font-size: 14px;
//         }
//         .cl-lv1 {
//             padding-left: 10px;
//         }
//         .cl-lv2 {
//             padding-left: 15px;
//         }
//     }
//     .div-left {
//         width: 175px;
//     }
//     .div-right {
//         flex: 1;
//         margin-right: 10px;
//     }
//     .div-left,
//     .div-right {
//         table.tftable {
//             font-size: 12px;
//             color: #333333;
//             width: 100%;
//             border-width: 1px;
//             border-collapse: collapse;
//             margin-bottom: 10px;
//         }

//         table.tftable th {
//             font-weight: bold;
//             font-style: normal;
//             font-size: 14px;
//             padding: 10px;
//             border: 1px solid #e4e4e4;
//             text-align: center;
//         }
//         table.tftable td {
//             border: 1px solid #e4e4e4;
//             padding: 5px;
//             text-align: left;
//         }
//         table.tftable td span {
//             line-height: 28px;
//         }
//         table.tftable .order-col {
//             text-align: center;
//         }
//         .cn-item {
//             position: relative;

//             text-align: left;
//             .btn-rm {
//                 position: absolute;
//                 right: 10px;
//                 top: 10px;

//                 cursor: pointer;
//                 z-index: 100;
//             }
//             .btn-rm.del {
//                 position: absolute;
//                 right: 10px;
//                 top: 10px;
//                 color: red;
//                 cursor: pointer;
//                 z-index: 100;
//             }
//         }

//         .swp {
//             display: flex;
//             justify-content: space-between;
//             border: 1px solid #e4e4e4;
//             border-bottom: 0px;
//             border-right: 0px;
//             background: #ecf8ff;
//             span {
//                 width: 25%;
//                 text-align: center;
//                 line-height: 35px;
//                 border-right: 1px solid #e4e4e4;
//                 font-size: 14px;
//             }
//         }

//         .el-form-item {
//             margin-bottom: 10px;
//         }
//         .item-title {
//             text-align: left;
//         }

//         .item-title span {
//             margin: 10px !important;
//         }
//         .btn-td {
//             display: flex;
//             justify-content: space-between;
//             .btn-group {
//                 display: flex;
//                 justify-content: space-between;
//                 .btn {
//                     width: 80px;
//                     display: block;
//                     margin-left: 5px;
//                     margin-right: 5px;
//                     display: -webkit-box;
//                     display: -webkit-flex;
//                     display: flex;
//                     -webkit-box-pack: center;
//                     -webkit-justify-content: center;
//                     justify-content: center;
//                     height: 30px;
//                     border-radius: 5px;
//                     line-height: 30px;
//                     cursor: pointer;
//                     border: 1px solid #e4e4e4;
//                 }
//                 .un-btn.btn {
//                     cursor: text;
//                 }
//                 .btn.Y.checked {
//                     background-color: #19be6b;
//                     color: #ffffff;
//                 }
//                 .btn.N.checked {
//                     background-color: red;
//                     color: #ffffff;
//                 }
//                 .btn.NA.checked {
//                     background-color: #ff976a;
//                     color: #ffffff;
//                 }
//             }
//         }

//         .div-op {
//             background: #ecf8ff;
//         }
//         .div-op .content-N .el-col {
//             background: #ecf8ff;
//         }
//         .div-op .content-Y .el-col {
//             background: #ecf8ff;
//         }
//         .div-op .content-NA .el-col {
//             background: #ecf8ff;
//         }

//         .using-content {
//             font-size: 13px;
//         }
//         .btn-using {
//             color: #409eff;
//             cursor: pointer;
//             font-size: 13px;
//         }
//         .div-button-container {
//             width: 100%;
//             text-align: center;
//             margin-bottom: 10px;
//         }
//     }
// }
</style>