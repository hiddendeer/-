<template name="danger-lg-task-detail">
    <div>
        <el-dialog :title="title" v-dialogDrag :visible.sync="visible" width="1000px" append-to-body show-close :close-on-click-modal="false">
            <!-- <div slot="title">
                {{title}}
            </div> -->
            <el-form :form="form" label-width="120px" ref="EagleForm">
                <eagle-block border>
                    <div class="danger-lg-task-detail">
                        <eagle-image label-width="100px" key="attachs" :is-edit="isEdit" v-model="form.attachs" label="隐患图片" prop='attachs' :count="3" />
                        <eagle-input :required="form.lgdType=='2'" :is-edit="isEdit" :row="2" label-width="100px" label="隐患区域" v-model="form.hiddenDangerArea" />
                        <div v-if="isEdit" style="margin-left:100px;max-heigth:200px">
                            <span>快捷选择隐患描述</span>
                            <template v-for="(sitem,sindex) in dangerSource">
                                <div class="using-content" :key="sindex">
                                    <div class="using-content-item">{{sindex+1}}. {{sitem.hiddenDangerDesc}} <span class="btn-using" @click="setDangerDesc(sitem)">引用</span></div>
                                </div>
                            </template>
                        </div>
                        <div style="text-align: right;">
                            <el-button type="text" @click="hdTemplateCheckShowLg(form)"> {{isEdit?"编辑依据":"查看依据"}}</el-button>
                        </div>
                        <eagle-input required type="textarea" :is-edit="isEdit" :row="2" label-width="100px" label="隐患描述" v-model="form.hiddenDangerDesc" />
                        <eagle-input type="textarea" autosize :is-edit="isEdit" :row="2" label-width="100px" label="整改建议" prop='correctiveAdvise' v-model="form.correctiveAdvise" />
                        <el-row>
                            <el-col :span="12">
                                <eagle-choose @clearChoose="clearHidden(form)" required label-width="100px" :is-edit="isEdit" label="隐患分类" v-model="form.lgdName" @change="handleRandShowHidden()" />
                            </el-col>
                        </el-row>

                        <eagle-radio required label-width="100px" :is-edit="isEdit" label="隐患性质" v-model="form.hiddenDangerType" v-if="params.dangerType" :data-source="params.dangerType" />
                        <el-row>
                            <el-col :span="12">
                                <eagle-date label-width="100px" :is-edit="isEdit" quickChoose prop='correctiveDate' label="整改期限" v-model="form.correctiveDate" />
                            </el-col>
                        </el-row>

                    </div>
                </eagle-block>
            </el-form>

            <div slot="footer" class="dialog-footer">
                <el-button @click="cancel">{{isEdit?"取 消":"关 闭"}}</el-button>
                <el-button v-if="isEdit" type="primary" @click="submitForm">确 定</el-button>
            </div>

        </el-dialog>
        <choose-danger-type ref="chooseDangerType" v-model="form.hiddenCode" @change="handleChooseDangerType" />
        <templateItem ref="templateItem" />
    </div>
</template>

<script>
import templateItem from "@/views/site/components/danger/template/templateItem";
import chooseDangerType from "@/views/components/danger/chooseDangerType";
export default {
    components: {
        chooseDangerType,
        templateItem,
    },
    name: "danger-lg-task-detail",
    props: {},
    data() {
        return {
            title: "",
            action: "",
            visible: false,
            isEdit: false,
            form: {},
            oldForm: {},
            dangerSource: [],
            params: {
                dangerType: [],
            },
        };
    },
    created() {},
    methods: {
        setDangerDesc(sitem) {
            this.form.hiddenDangerDesc = sitem.hiddenDangerDesc;
            this.form.hiddenDangerType = sitem.hiddenDangerType;
            // ditem.correctiveAdvise = correctiveAdvise;
            this.form.lgdName = sitem.dName;
            this.form.lgdCode = sitem.dCode;
            this.form.lgdType = sitem.dType;
            this.form.legalLiability = sitem.legalLiability;
            if (sitem.dType)
                this.form.lgdName = `${
                    sitem.dType == "1" ? "基础管理" : "现场管理"
                }-${this.form.lgdName}`;
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        show(options) {
            this.title = options.isEdit ? "编辑隐患" : "隐患详情";
            this.action = options.action;
            this.visible = true;
            this.isEdit = options.isEdit;
            this.oldForm = options.model;
            this.form = this.deepMerge(this.oldForm, this.form);
            this.dangerSource = options.dangerSource;
            this.initData();
        },
        clearHidden(obj) {
            obj.lgdType = "";
            obj.lgdCode = "";
            obj.lgdName = "";
        },

        setHidderDangerDesc(obj) {
            let _this = this;
            _this.form.correctiveAdvise = obj.base.correctiveAdvise;
            _this.form.gistSource = obj.base.gistSource;
            _this.form.originalText = obj.base.originalText;
            _this.form.lgCode = obj.base.lGCode;
            if (obj.item === "base-danger") {
                if (obj.danger.dFullName) {
                    _this.form.lgHdCode = obj.danger.lGHDCode;
                    _this.form.lgdCode = obj.danger.dCode;
                    _this.form.lgdName = obj.danger.dFullName.replace(">", "-");
                    let hiddenTypeName = obj.danger.dFullName.split("-")[0];
                    if (hiddenTypeName === "现场管理") _this.form.lgdType = "2";
                    if (hiddenTypeName === "基础管理") _this.form.lgdType = "1";
                }
                _this.form.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.form.hiddenDangerType = obj.danger.hiddenDangerType;
                _this.form.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.form.legalLiability = obj.danger.legalLiability;
            }
            this.libTempDetailsVisible = false;
        },

        choosedDangerLg(chooseData) {
            this.model = chooseData;
        },
        randVolid() {
            return true;
        },
        handleChooseDangerType(val, obj) {
            this.form.lgdType = obj.dType;
            this.form.lgdCode = val;
            this.form.lgdName = obj.dFullName.replace(">", "-");
        },
        handleRandShowHidden() {
            this.$refs.chooseDangerType.show();
        },
        cancel() {
            this.visible = false;
        },
        submitForm() {
            for (var key in this.form) {
                this.oldForm[key] = this.form[key];
            }
            this.$emit("confirm", this.form, this.action);

            this.cancel();
        },
        //检查表检查,查看依据
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({
                model: item,
                isEdit: this.isEdit,
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.danger-lg-task-detail {
    .using-content {
        font-size: 13px;
        max-height: 55px;
        overflow: auto;
        padding: 5px 20px;
        .using-content-item {
            display: inline-block;
        }
        .btn-using {
            color: #409eff;
            cursor: pointer;
            font-size: 13px;
        }
    }
}
</style>
