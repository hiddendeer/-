<template name="danger-dj-task-details-index">
    <div class="danger-dj-task-details-index  app-container">
        <div class="layer">
            <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <!-- <eagle-radio @change="search()"   label-width="80px" label="隐患状态" prop="checkType" v-model="conditions.checkType.value" :dataSource="params.checkType" size="small" /> -->
                        <el-col>
                            <eagle-radio @change="search()" label-width="80px" label="计划状态" prop="status" v-model="conditions.status.value" :dataSource="params.correctiveStatus" size="small" />
                        </el-col>
                        <eagle-input label-width="80px" :inputStyle="{width:'400px'}" @changeEnter="search()" label="筛选条件" prop="keyWords" v-model="conditions.keyWords.value" placeholder="请输入检查任务名称,隐患描述,整改建议进行模糊查询" clearable size="small" />
                    </eagle-condition>
                </template>
                <!-- <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary"  icon="el-icon-plus" size="mini" @click="goDetail('0')">新增</el-button>
                    </el-col>
                </el-row>
            </template> -->
                <template slot="slot-table">
                    <!-- <el-table-column label="检查单位" align="left" prop="companyName" /> -->
                    <el-table-column label="任务名称" align="left" prop="ctName" />
                    <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" />
                    <el-table-column label="隐患图片" align="left" prop="attachs" width="100">
                        <template slot-scope="scope">
                            <eagle-row-image v-model="scope.row.attachs" />
                        </template>
                    </el-table-column>
                    <el-table-column label="隐患区域" align="left" prop="hiddenDangerArea" />
                    <el-table-column label="隐患分类" align="left" prop="lgdName" />
                    <el-table-column label="整改建议" align="left" prop="correctiveAdvise" />
                    <el-table-column label="隐患性质" align="left">
                        <template slot-scope="scope"><span>{{formateDict(params.dangerType,scope.row.hiddenDangerType)
                        }}</span></template>
                    </el-table-column>
                    <el-table-column label="隐患状态" align="left">
                        <template slot-scope="scope"><span>{{formateDict(params.correctiveStatus,scope.row.status)
                        }}</span></template>
                    </el-table-column>
                    <el-table-column label="整改人" align="left" prop="correctiveChnName" />
                    <el-table-column label="检查人" align="left" prop="createChnName" />
                    <el-table-column label="检查日期" align="left">
                        <template slot-scope="scope">
                            {{ parseTime(scope.row.createDate , "{y}/{m}/{d}")}}
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="primary" @click.prevent.stop="showDetail(scope.row)">详情</eagle-row-button>
                    <!-- v-if="scope.row.status==40" -->
                    <!-- <eagle-row-button type="primary" v-if="scope.row.jg==false && scope.row.status==40" icon="el-icon-view" @click.prevent.stop="hdMeasure(scope.row)">制定措施</eagle-row-button>
                <eagle-row-button type="primary" v-if="scope.row.jg==false && scope.row.status==50" icon="el-icon-view" @click.prevent.stop="hdCorrective(scope.row)">整改</eagle-row-button>
                <eagle-row-button type="primary" v-if="scope.row.jg && scope.row.status!==100" icon="el-icon-view" @click.prevent.stop="hdAccept(scope.row)">复查</eagle-row-button>
          -->

                    <eagle-row-button type="primary" v-if="scope.row.status==40" @click.prevent.stop="hdMeasure(scope.row)">制定措施</eagle-row-button>
                    <eagle-row-button type="primary" v-if="scope.row.status==50" @click.prevent.stop="hdCorrective(scope.row)">整改</eagle-row-button>
                    <!-- <eagle-row-button type="primary" v-if="scope.row.jg && scope.row.status!==100" icon="el-icon-view" @click.prevent.stop="hdAccept(scope.row)">复查</eagle-row-button> -->

                </template>
            </eagle-page>

            <taskDetailView ref="taskDetailView" @afterSave="search()" />
            <taskDetailViewNew ref="taskDetailViewNew" @afterSave="search()" />
        </div>
    </div>
</template>

<script>
import taskDetailView from "./taskDetailView";
import taskDetailViewNew from "./view";

export default {
    name: "danger-check-plan-index",
    components: { taskDetailView, taskDetailViewNew },
    data() {
        return {
            controller: "danger/jgDangerTaskDetail",
            conditions: {
                keyWords: { value: "", operate: "like" },
                status: { value: null, operate: "=" },
            },
            queryParams: {
                dataType: "list",
                projectId: "",
            },

            params: {
                correctiveStatus: [],
                checkType: [],
                dangerType: [],
            },
        };
    },

    created() {
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.initParams();
    },
    mounted() {
        this.search();
    },
    methods: {
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                [
                    "danger_check_plan_type",
                    "danger_simple_danger_type",
                    "dangerJg_corrective_status",
                ],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) => p.paramId === "danger_simple_danger_type"
                    );
                    _this.params.dangerType.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                    _this.params.correctiveStatus = [
                        {
                            id: null,
                            name: "不限",
                        },
                    ];
                    res.data
                        .filter(
                            (p) => p.paramId === "dangerJg_corrective_status"
                        )
                        .forEach((x) => {
                            _this.params.correctiveStatus.push({
                                id: parseInt(x.id),
                                name: x.name,
                            });
                        });
                }
            );
        },
        search() {
            // let url = `${this.controller}/getPageList`;
            // this.$refs.EaglePage.search({ url: url });
            this.$refs.EaglePage.search();
        },
        //查询条件重置
        resetQuery() {
            this.conditions.keyWords.value = "";
            this.conditions.status.value = null;
            this.search();
        },
        showDetail(row) {
            this.$refs.taskDetailViewNew.show(row, { type: 1 });
        },
        hdMeasure(row) {
            this.$refs.taskDetailView.show(row, { type: 2 });
        },
        hdCorrective(row) {
            this.$refs.taskDetailView.show(row, { type: 3 });
        },
        hdAccept(row) {
            this.$refs.taskDetailView.show(row, { type: 5 });
        },
    },
};
</script>
<style scoped lang="scss">
.danger-check-plan-index {
    padding: 20px;

    .img-content {
        width: 30px;
        height: 30px;
    }
}

.danger-dj-task-details-index {
    padding: 10px;
}
</style>