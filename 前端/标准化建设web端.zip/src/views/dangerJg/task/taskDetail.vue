<template name="danger-lg-task-detail">
    <div class="danger-lg-task-detail">
        <eagle-form :controller="controller" title="隐患信息" :is-edit="type!=0" :save-volid-fun="randVolid" @afterSave="afterSave" :form="form" width="1000px" label-width="120px" ref="EagleForm" @bindData="bindDataDetail" :customButtons="true">
            <eagle-block border>
                <div v-if="type!=4 && type!=3">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="隐患来源" label-width="100px">
                                <span>{{formateDict( params.checkSource,form.originType) }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="检查人" label-width="100px">
                                <span>{{form.createChnName}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="检查时间" label-width="100px">
                                <span>{{ parseTime(form.createDate, "{y}-{m}-{d}") }}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>
                <div v-if="form.checkResult=='N'">

                    <eagle-image label-width="100px" key="attachs" :is-edit="type==1 ||type==3 || type==4|| type==5" v-model="form.attachs" label="隐患图片" prop='attachs' :count="3" />

                    <eagle-input :required="form.lgdType=='2'" :is-edit="type==1 ||type==3|| type==4|| type==5" :row="2" label-width="100px" label="隐患区域" v-model="form.hiddenDangerArea" />
                    <div style="text-align: right;">
                        <el-button type="text" v-if="type==1 ||type==3|| type==4|| type==5" @click="hdTemplateCheckChooseLg()">选择依据</el-button>
                        <el-button type="text" @click="hdTemplateCheckShowLg(form)"> {{type==1 ||type==3|| type==4?"编辑依据":"查看依据"}}</el-button>
                    </div>
                    <eagle-input required type="textarea" autosize :is-edit="type==1 ||type==3|| type==4|| type==5" :row="2" label-width="100px" label="隐患描述" v-model="form.hiddenDangerDesc" />
                    <eagle-input type="textarea" autosize :is-edit="type==1 ||type==3|| type==4|| type==5" :row="2" label-width="100px" label="整改建议" prop='correctiveAdvise' v-model="form.correctiveAdvise" />
                    <el-row>
                        <el-col :span="12">
                            <eagle-choose @clearChoose="clearHidden(form)" required label-width="100px" :is-edit="type!=0" label="隐患分类" v-model="form.lgdName" @change="handleRandShowHidden()" />
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-radio required label-width="100px" :is-edit="type!=0" label="隐患性质" v-model="form.hiddenDangerType" :data-source="params.dangerType" />
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <eagle-date label-width="100px" :is-edit="type!=0" prop='correctiveDate' quickChoose label="整改期限" v-model="form.correctiveDate" />
                        </el-col>
                    </el-row>
                </div>
                <div v-if="form.checkResult=='NA'">
                    <eagle-input :is-edit="type!=0" type="textarea" :row="2" label-width="100px" key="remarks" label="备注" v-model="form.remarks" />
                </div>
                <div v-if="form.checkResult=='Y'">
                    <eagle-input :is-edit="type!=0" type="textarea" :row="2" label-width="100px" key="checkRemark" label="检查情况" v-model="form.checkRemark" />
                </div>
            </eagle-block>
            <div slot="buttons" class="dialog-footer">
                <el-button @click="cancel" v-if="type!=0">取 消</el-button>
                <el-button @click="cancel" v-if="type===0">关 闭</el-button>
                <el-button v-if="type!=0" type="primary" @click="submitForm"> {{form.self &&  type===2 ?"保存并复查通过":"保 存"}}</el-button>
            </div>
        </eagle-form>
        <choose-danger-type ref="chooseDangerType" v-model="form.hiddenCode" @change="handleChooseDangerType" />
        <dangerlgAddWindow ref="dangerLG" @choosed="choosedDangerLg"></dangerlgAddWindow>
        <templateItem ref="templateItem" />
        <libTempDetails :dataType="libDataType" @handleClose="libTempDetailsVisible=false" :libTempDetailsVisible="libTempDetailsVisible" @handlerSelectBase="handlerSelectBase" />
    </div>
</template>

<script>
import chooseDangerType from "@/views/components/danger/chooseDangerType";
import dangerlgAddWindow from "@/views/site/components/danger/dangerlg/dangerlgAddWindow";
import templateItem from "@/views/site/components/danger/template/templateItem";

import libTempDetails from "@/views/support/libTemp/components/libTempDetails/libTempDetails";
export default {
    components: {
        chooseDangerType,
        dangerlgAddWindow,
        templateItem,
        libTempDetails,
    },
    name: "danger-lg-task-detail",
    props: {},
    data() {
        return {
            libTempDetailsVisible: false,
            libDataType: "base",
            controller: "danger/jgDangerTaskDetail",
            form: {},
            type: 0, //0查看,1:编辑,2整改,3随手拍,4 依据查, 5 拷贝
            mainCode: "",
            params: {
                // dangerCheckTaskType: [],
                opType: [],
                dangerType: [],
                checkSource: [
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                checkResult: [
                    { id: "Y", name: "符合", color: "#67C23A" },
                    { id: "N", name: "不符合", color: "#F56C6C" },
                    { id: "NA", name: "不适用", color: "#E6A23C" },
                ],
            },

            tempModel: {}, //依据查model
        };
    },
    created() {
        this.initData();
    },
    methods: {
        clearHidden(obj) {
            obj.lgdType = "";
            obj.lgdCode = "";
            obj.lgdName = "";
        },
        handlerSelectBase(obj) {
            let _this = this;

            if (obj.item == "base" && _this.form.correctiveAdvise) {
                this.$confirm("是否确认覆盖整改建议?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.setHidderDangerDesc(obj);
                });
            } else if (
                obj.item === "base-danger" &&
                (_this.form.hiddenDangerDesc || _this.form.correctiveAdvise)
            ) {
                this.$confirm("是否确认覆盖隐患描述和整改建议?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }).then(function (res) {
                    _this.setHidderDangerDesc(obj);
                });
            } else _this.setHidderDangerDesc(obj);

            // if (_this.form.hiddenDangerDesc) {
            //     this.$confirm("是否确认覆盖隐患描述和整改建议?", "警告", {
            //         confirmButtonText: "确定",
            //         cancelButtonText: "取消",
            //         type: "warning",
            //     }).then(function (res) {
            //         _this.setHidderDangerDesc(obj);
            //     });
            // } else _this.setHidderDangerDesc(obj);
        },

        setHidderDangerDesc(obj) {
            let _this = this;
            _this.form.correctiveAdvise = obj.base.correctiveAdvise;
            _this.form.gistSource = obj.base.gistSource;
            _this.form.originalText = obj.base.originalText;
            _this.form.lgCode = obj.base.lGCode;
            // _this.form.lgHdCode = "";
            if (obj.item === "base-danger") {
                if (obj.danger.dFullName) {
                    _this.form.lgHdCode = obj.danger.lGHDCode;
                    _this.form.lgdCode = obj.danger.dCode;
                    _this.form.lgdName = obj.danger.dFullName.replace(">", "-");
                    let hiddenTypeName = _this.form.lgdName.split("-")[0];
                    if (hiddenTypeName === "现场管理") _this.form.lgdType = "2";
                    if (hiddenTypeName === "基础管理") _this.form.lgdType = "1";
                }
                _this.form.hiddenDangerDesc = obj.danger.hiddenDangerDesc;
                _this.form.hiddenDangerType = obj.danger.hiddenDangerType;
                _this.form.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                _this.form.legalLiability = obj.danger.legalLiability;
            }
            this.libTempDetailsVisible = false;
        },
        //检查表检查,查看依据
        hdTemplateCheckShowLg(item) {
            this.$refs.templateItem.show({
                model: item,
                isEdit: this.type !== 0 && this.type !== 2,
            });
        },
        //检查表检查选择依据
        hdTemplateCheckChooseLg(model) {
            this.libTempDetailsVisible = true;
            this.libDataType = "base";
        },
        /*
         *
         */
        choosedDangerLg(chooseData) {
            this.model = chooseData;
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );
        },
        bindDataDetail(data) {
            let _this = this;
            _this.form = data;
            _this.form.ctCode = _this.mainCode;
            if (_this.form.id == 0) {
                _this.form.originType = 1;
                _this.form.checkResult = "N";
                if (_this.type == 4) {
                    //依据查
                    _this.form.originType = 2;
                    _this.form.attachs = _this.tempModel.attachs;
                    for (let x in _this.tempModel) {
                        if (_this.tempModel[x] || _this.tempModel[x] == 0)
                            _this.form[x] = _this.tempModel[x];
                    }
                }
            }
            if (_this.type == 5) {
                _this.form.id = "0";
                _this.form.code = "";
            }
        },
        handleChangeResult(status) {
            console.log(this.type);
            if (this.type == 1) this.form.checkResult = status;
        },
        show(params, config) {
            let _this = this;
            _this.type = config.type;

            console.log("_this.type:", _this.type);
            _this.mainCode = params.mainCode;
            switch (config.type) {
                case 0:
                    config.title = "隐患详情";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
                case 1:
                    config.title = "隐患编辑";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
                case 2:
                    config.title = "隐患整改";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
                case 3:
                    config.title = "随手拍";
                    _this.$refs.EagleForm.handleAdd(config);
                    break;
                case 4:
                    config.title = "依据查";
                    //_this.tempModel = config.lg;
                    _this.tempModel = {};
                    _this.$refs.EagleForm.handleAdd(config);

                    //依据查
                    _this.tempModel.originType = 2;
                    _this.tempModel.attachs = config.lg.attachs;
                    _this.tempModel.correctiveAdvise =
                        config.lg.correctiveAdvise;
                    _this.tempModel.lgCode = config.lg.lGCode;
                    _this.tempModel.gistSource = config.lg.gistSource;
                    _this.tempModel.originalText = config.lg.originalText;
                    // _this.tempModel.gistSource = config.lg.gistSource
                    if (config.lg.item === "base-img-danger") {
                        if (config.lg.dFullName) {
                            _this.tempModel.lgdCode = config.lg.dCode;
                            _this.tempModel.lgdName =
                                config.lg.dFullName.replace(">", "-");
                            let hiddenTypeName =
                                _this.tempModel.lgdName.split("-")[0];
                            if (hiddenTypeName === "现场管理")
                                _this.tempModel.lgdType = "2";
                            if (hiddenTypeName === "基础管理")
                                _this.tempModel.lgdType = "1";
                        }
                        _this.tempModel.lgHdCode = config.lg.lGHDCode;
                        _this.tempModel.hiddenDangerDesc =
                            config.lg.hiddenDangerDesc;
                        _this.tempModel.hiddenDangerType =
                            config.lg.hiddenDangerType;
                        _this.tempModel.hiddenDangerTypeName =
                            config.lg.hiddenDangerTypeName;
                        _this.tempModel.legalLiability =
                            config.lg.legalLiability;
                    }
                    break;
                case 5:
                    config.title = "复制隐患";
                    _this.$refs.EagleForm.handleUpdate(params, config);
                    break;
            }
        },
        randVolid() {
            return true;
        },
        handleChooseDangerType(val, obj) {
            this.form.lgdType = obj.dType;
            this.form.lgdCode = val;
            this.form.lgdName = obj.dFullName.replace(">", "-");
        },
        handleRandShowHidden() {
            this.$refs.chooseDangerType.show();
        },
        cancel(data) {
            this.$refs.EagleForm.cancel();
        },
        submitForm() {
            let config = {
                url: `${this.controller}/createTaskDetail`,
            };

            this.$refs.EagleForm.submitForm(config);
        },
        afterSave() {
            this.$emit("afterSave");
        },
    },
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0px 20px;
}
</style>