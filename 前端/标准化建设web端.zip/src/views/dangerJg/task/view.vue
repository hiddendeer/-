 <!-- 任务详情 -->
  <template name="danger-check-plan-detail">
    <div class="danger-check-plan-detail">
        <el-form ref="elForm" :model="model">
            <eagle-fold-block class="box-card">
                <div slot="header" class="clearfix">
                    <span style="font-size:16px;">检查任务基本信息 </span><span>({{ model.checkTaskName }})</span>
                    <!-- <el-button type="default" size="mini" style="float: right; margin-left:10px" @click="hdBack">返 回</el-button>
                                  <el-button type="danger" size="mini" style="float: right; margin-left:10px" v-if="model.status!=25 && model.status<80 && (model.manager || model.endStatus>0) " @click="hdOverTask">终止任务</el-button>
                                  <el-button type="danger" size="mini" style="float: right; margin-left:10px" v-if="model.status===10 && model.endStatus==10" @click="hdEndTask">结束检查</el-button>
                                  <el-button type="danger" size="mini" style="float: right; margin-left:10px" v-if="(model.status===10 && model.endStatus==20)|| (model.canBack &&(model.status===30 ||model.status===80))" @click="hdResetEndTask">恢复检查</el-button>
                                  <el-button type="primary" size="mini" style="float: right; margin-left:10px" v-if="model.status>=30 " @click="buildReport">生成检查报告</el-button>
                                  <el-button type="primary" size="mini" style="float: right; margin-left:10px" v-if="model.status>=30" @click="buildVerifyReport">生成整改报告</el-button> -->
                    <el-button type="default" size="mini" style="float: right; margin-left:10px" @click="hdBack">返 回
                    </el-button>
                    <el-button type="danger" size="mini" style="float: right; margin-left:10px" v-if="model.status != 25" @click="hdOverTask">终止任务</el-button>
                    <el-button type="danger" size="mini" style="float: right; margin-left:10px" v-if="model.status === 10" @click="submitTask">结束检查</el-button>
                    <el-button type="danger" size="mini" style="float: right; margin-left:10px" v-if="model.canBack && (model.status >= 30) && !(model.status == 100 && !model.unNextVerify)" @click="hdResetEndTask">恢复检查</el-button>
                    <el-button type="primary" size="mini" style="float: right; margin-left:10px" v-if="model.status >= 30" @click="buildVerifyReport">生成整改报告</el-button>
                    <el-button type="primary" size="mini" style="float: right; margin-left:10px" v-if="model.status >= 30" @click="buildReport">生成检查报告</el-button>
                    <el-button type="primary" size="mini" style="float: right; margin-left:10px" v-if="model.status >= 30" @click="buildDangerListReport">生成隐患清单</el-button>
                </div>
                <div class="form-view">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="任务名称">
                                <span>{{ model.checkTaskName }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="检查类型" prop="checkType">
                                <span>{{ formateDict(params.checkType, model.checkType) }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="状态">
                                <span v-if="model.status == 10" style="color:red">进行中</span>
                                <span v-else v-html="formateStatus(params.taskStatus, model.status)"></span>
                                <span v-if="model.unNextVerify" style="color:red">(无需复查)</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="被检查单位">
                                <span>{{ model.enterpriseName }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="检查人">
                                <span>{{ model.checkNames }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="开始/截止日期">
                                {{ parseTime(model.startDate, "{y}/{m}/{d}") }} ~ {{ parseTime(model.endDate,
                                        "{y}/{m}/{d}")
                                }}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="创建人">
                                <span>{{ model.createChnName }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="创建时间">
                                {{ parseTime(model.createDate, "{y}/{m}/{d} {h}:{i}") }}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="隐患清单">
                                <eagle-row-attach v-model="model.dangerListReportAttach"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="检查报告">
                                <eagle-row-attach :isReport="true" v-model="model.checkAttachs"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="整改报告">
                                <eagle-row-attach v-model="model.verifyAttachs"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col>
                            <el-form-item label-width="120px" label="检查要求">
                                <span>{{ model.checkRequirement }}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>
                <!-- </div> -->
            </eagle-fold-block>
            <el-card class="box-card">
                <div slot="header" class="clearfix">
                    <span>进行检查</span>
                </div>
                <div v-if="model.status === 10">
                    <p class="eagle-title-left-split">检查工具</p>
                    <div>
                        <el-button type="primary" size="mini" @click.prevent.stop="handleChooseLibTemplateShow">+检查表
                        </el-button>
                        <el-button type="primary" size="mini" @click.prevent.stop="handleChooseYJ()">+依据检查</el-button>
                        <el-button type="primary" size="mini" @click.prevent.stop="handRand()">+随手拍</el-button>
                    </div>
                </div>
                <div>
                    <p class="eagle-title-left-split">任务检查表</p>
                    <div label="任务检查表">
                        <!-- <ul>
                                          <li v-for="(item,index) in model.tempRelations" :key="index" style="list-style:none;margin-top: -10px;float:left;margin-right:15px; ">
                                              <el-link style="margin-right:5px;" @click="goTemplateCheck(item.tCode)" type="primary">
                                                  {{item.tName}}
                                              </el-link>
                                              <i v-if="model.status===10" class="el-icon-delete" style="color:red;cursor:pointer;" title="移除检查表" @click="hdRemoverTemplate(index)"></i>
                                          </li>
                                      </ul> -->
                        <div class="temp-block" v-for="(item, index) in model.tempRelations" :key="index">
                            <div class="temp-title single-line">{{ index + 1 }}-{{ item.tName }}</div>
                            <div class="temp-button">
                                <eagle-row-button v-if="model.status === 10" type="danger" @click.prevent.stop="hdRemoverTemplate(index)">删除</eagle-row-button>
                                <eagle-row-button type="primary" @click.prevent.stop="goTemplateCheck(item.tCode)">
                                    {{ model.status === 10 ? '检查' : '详情' }}</eagle-row-button>
                            </div>
                        </div>
                    </div>
                </div>
            </el-card>
            <el-card class="box-card">
                <el-tabs v-model="activeName" @tab-click="hdTabsClick">
                    <el-tab-pane label="隐患记录" name="first">
                        <eagle-page :controller="detailController" ref="EaglePage" :rowClassName="getCompateClassName" :conditions="conditions1" :query-params="queryParams1" :btnWidth="model.status == 10 ? '250' : '150'" :showCheckColumn="false">
                            <template slot="slot-search">
                                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                                    <eagle-select @change="search()" label-width="80px" label="检查类型" prop="originType" v-model="conditions1.originType.value" :dataSource="params.originType" size="small" />
                                    <eagle-select @change="search()" label-width="80px" label="隐患性质" prop="hiddenDangerType" v-model="conditions1.hiddenDangerType.value" :dataSource="params.dangerType" size="small" />
                                    <eagle-select @change="search()" label-width="80px" label="隐患状态" prop="status" v-model="conditions1.status.value" :dataSource="params.correctiveStatus" size="small" />
                                    <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="keyWords" v-model="conditions1.keyWords.value" placeholder="请输入隐患描述,整改建议,操作人进行模糊查询" clearable size="small" />
                                </eagle-condition>
                            </template>
                            <template slot="slot-table">
                                <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" width="300" />
                                <el-table-column label="隐患图片" align="center" prop="attachs" width="90">
                                    <template slot-scope="scope">
                                        <eagle-row-image v-model="scope.row.attachs" />
                                    </template>
                                </el-table-column>
                                <el-table-column label="隐患区域" align="left" prop="hiddenDangerArea" />
                                <el-table-column label="隐患分类" align="left" prop="lgdName" width="200" />
                                <el-table-column label="检查类型" align="left" width="120">
                                    <template slot-scope="scope"><span>{{ formateDict(params.originType,
                                                scope.row.originType)
                                        }}</span></template>
                                </el-table-column>
                                <el-table-column label="隐患状态" align="left" width="150">
                                    <template slot-scope="scope">
                                        <span v-html="formateStatus(params.correctiveStatus, scope.row.status)"></span>

                                    </template>
                                </el-table-column>
                                <!-- <el-table-column label="整改建议" align="left" prop="correctiveAdvise" width="300" /> -->
                                <el-table-column label="检查表" align="left" prop="tName" />
                                <el-table-column label="操作人" align="left" prop="createChnName" />
                                <el-table-column label="操作时间" align="center" prop="createDate" width="140">
                                    <template slot-scope="scope"><span>{{ parseTime(scope.row.createDate,
                                                "{y}-{m}-{d} {h}:{i}") || "--"
                                        }}</span></template>
                                </el-table-column>
                            </template>
                            <template slot="slot-row-buttons" slot-scope="scope">
                                <eagle-row-button type="success" @click.prevent.stop="handView(scope.row)">详情
                                </eagle-row-button>
                                <eagle-row-button type="primary" v-if="scope.row.status <= 10" @click.prevent.stop="handEdit(scope.row)">编辑</eagle-row-button>
                                <eagle-row-button type="primary" v-if="scope.row.status <= 10" @click.prevent.stop="handCopy(scope.row)">复制</eagle-row-button>
                                <eagle-row-button type="danger" v-if="scope.row.status <= 10" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
                                <eagle-row-button type="primary" v-if="scope.row.status >= 30 && scope.row.status < 80" @click.prevent.stop="hdAccept(scope.row)">复查</eagle-row-button>
                            </template>
                        </eagle-page>
                    </el-tab-pane>
                    <el-tab-pane label="人员检查情况" name="second">
                        <eagle-page :controller="detailController" ref="EaglePage2" btnWidth="80" :showCheckColumn="false">
                            <template slot="slot-search">
                                <eagle-condition @search="search2()" @resetQuery="resetQueryCheckUser()">
                                    <eagle-input label-width="80px" @changeEnter="search2" :required="false" prop="chnName" label="检查人" v-model="checkChnName" placeholder="请输入检查人" clearable size="small" />
                                </eagle-condition>
                            </template>
                            <template slot="slot-buttons" v-if="model.status == 10">
                                <el-row :gutter="10">
                                    <el-col :span="1.5">
                                        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="pushChecker()">新增</el-button>
                                    </el-col>
                                </el-row>
                            </template>
                            <template slot="slot-table">
                                <el-table-column label="检查人" align="left" prop="chnName" />
                                <el-table-column label="隐患数/检查数">
                                    <template slot-scope="scope">
                                        <span style="color:red">{{ scope.row.fcount }}</span>/<span>{{
                                                scope.row.tcount
                                        }}</span>
                                    </template>
                                </el-table-column>
                            </template>

                            <template slot="slot-row-buttons" slot-scope="scope">
                                <eagle-row-button type="danger" v-if="model.status == 10 && scope.row.tcount <= 0 && model.manager" @click.prevent.stop="handRemoveChecker(scope.row)">移除</eagle-row-button>
                            </template>
                        </eagle-page>
                    </el-tab-pane>
                    <el-tab-pane label="报告记录" name="third">
                        <div>
                            <el-row>
                                <el-col :span="24">
                                    <eagle-page :controller="reportController" ref="EaglePage3" :conditions="conditions3" :query-params="queryParams3" btnWidth="120" :showCheckColumn="false">
                                        <template slot="slot-search">

                                            <eagle-condition @search="search3()" @resetQuery="resetQuery3()">

                                                <eagle-select @change="search3()" label-width="80px" label="报告类型" prop="reportTypeId" v-model="conditions3.reportTypeId.value" :dataSource="params.reportTypes" size="small" />

                                                <eagle-input label-width="80px" @changeEnter="search3()" label="筛选条件" prop="reportName" v-model="conditions3.reportName.value" placeholder="请输入报告名称进行查询" clearable size="small" />
                                            </eagle-condition>
                                        </template>

                                        <template slot="slot-table">
                                            <el-table-column label="报告名称" align="left" prop="reportName" width="200" />
                                            <el-table-column label="报告类型" align="left" width="200">
                                                <template slot-scope="scope"><span>{{ formateDict(params.reportTypes,
                                                        scope.row.reportTypeId)
                                                }}</span></template>
                                            </el-table-column>
                                            <el-table-column label="报告文件" align="left" prop="plan">
                                                <template slot-scope="scope">
                                                    <eagle-row-attach v-model="scope.row.reportAttach">
                                                    </eagle-row-attach>
                                                </template>
                                            </el-table-column>
                                            <!-- <el-table-column label="检查时间" align="center" prop="plan">
                                                              <template slot-scope="scope">
                                                                  {{ parseTime(scope.row.startDate, "{y}-{m}-{d}")}} ~ {{ parseTime(scope.row.endDate, "{y}-{m}-{d}")}}
                                                              </template>
                                                          </el-table-column> -->
                                            <el-table-column label="报表版本" align="center" prop="plan">
                                                <template slot-scope="scope">
                                                    {{ scope.row.status == 10 ? "最新报告" : "历史报告" }}
                                                </template>
                                            </el-table-column>
                                            <el-table-column label="报告人" align="center" prop="plan">
                                                <template slot-scope="scope">
                                                    {{ scope.row.createChnName }}
                                                </template>
                                            </el-table-column>
                                            <el-table-column label="报告生成日期" align="center" prop="plan">
                                                <template slot-scope="scope">
                                                    {{ scope.row.createDate }}
                                                </template>
                                            </el-table-column>
                                        </template>
                                        <template slot="slot-row-buttons" slot-scope="scope">
                                            <eagle-row-button type="danger" v-if="(model.manager)" @click.prevent.stop="handleDelete3(scope.row)">删除</eagle-row-button>
                                        </template>
                                    </eagle-page>
                                </el-col>
                            </el-row>
                        </div>
                    </el-tab-pane>
                </el-tabs>
            </el-card>
        </el-form>
        <dangerJgTaskDetail ref="dangerJgTaskDetail" @afterSave="getModel" />
        <eagle-dialog-user ref="eagleChooseUser" :single="false" @callBack="pushNewChecker" />
        <taskDetailView ref="taskDetailView" @afterSave="getModel" />
        <taskDetailViewNew ref="taskDetailViewNew" @afterSave="getModel" />
        <choose-lib-template :psotCompanyCode="companyCode" ref="chooseLibTemplate" @change="handleChooseLibTemplate" />
        <libTempDetails :companyCode="companyCode" :dataType="libDataType" @handleClose="libTempDetailsVisible = false" :libTempDetailsVisible="libTempDetailsVisible" @handlerSelectImg="handlerSelectImg" />
        <buildDangerReport ref="buildDangerReport" @afterSave="showReport" />
        <dangerListReport ref="dangerListReport" @afterSave="showReport" />
        <verifyTaskReport ref="verifyTaskReport" @afterSave="showReport" />
        <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>
    </div>
</template>

<script>
import verifyTaskReport from "@/views/dangerJg/task/buildTaskVerifyReport";
import chooseLibTemplate from "@/views/support/public/chooseLibTemplate.vue";
import dangerJgTaskDetail from "./taskDetail";
// import dangerJgSubmitTask from "./submitTask";
import eagleDialogUser from "@/components/Eagle/chooseUser/eagle-dialog-user";
import taskDetailView from "../task/details/taskDetailView";
import taskDetailViewNew from "../task/details/view";
import libTempDetails from "@/views/support/libTemp/components/libTempDetails/libTempDetails";
import buildDangerReport from "../task/buildDangerReport";
import dangerListReport from "../task/dangerListReport";
import EagleFoldBlock from "@/components/Eagle/eagle-fold-block.vue";
// import { resetForm } from "@/utils/EageleRMC";

export default {
    components: {
        dangerJgTaskDetail,
        "eagle-dialog-user": eagleDialogUser,
        // dangerJgSubmitTask,
        taskDetailView,
        taskDetailViewNew,
        chooseLibTemplate,
        libTempDetails,
        buildDangerReport,
        dangerListReport,
        verifyTaskReport,
        EagleFoldBlock,
    },
    name: "danger-check-plan-detail",
    data() {
        return {
            companyCode: "",
            libDataType: "img",
            libTempDetailsVisible: false,
            submitDialog: false,
            controller: "danger/jgDangerTask",
            detailController: "danger/jgDangerTaskDetail",
            reportController: "danger/report",
            model: {},
            submitModel: {
                type: 1,
            },
            id: "0",
            // datetimes: [],
            conditions1: {
                checkResult: { value: "N", operate: "=" },
                status: { value: null, operate: "=" },
                originType: { value: null, operate: "=" },
                hiddenDangerType: { value: null, operate: "=" },
                keyWords: { value: null, operate: "like" },
            },
            conditions2: {
                chnName: { value: "", operate: "like" },
            },
            conditions3: {
                reportTypeId: { value: null, operate: "=" },
                reportName: { value: "", operate: "like" },
            },
            queryParams1: { ctCode: "", dataType: "taskDetail" },
            queryParams3: { dataType: "taskDetail", taskCode: "" },
            activeName: "first",
            params: {
                // userStatus: [
                //     { id: 10, name: "未结束", color: "#F56C6C" },
                //     { id: 20, name: "已结束", color: "#67C23A" },
                // ],
                taskStatus: [
                    { id: 10, name: "进行中", color: "#F56C6C" },
                    { id: 25, name: "任务终止", color: "#F56C6C" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
                checkType: [],
                dangerType: [],
                correctiveStatus: [
                    { id: null, name: "不限", color: "#F56C6C" },
                    { id: 10, name: "检查中", color: "#F56C6C" },
                    { id: 25, name: "检查终止", color: "#F56C6C" },
                    { id: 30, name: "待整改", color: "#F56C6C" },
                    { id: 60, name: "待复查", color: "#F56C6C" },
                    { id: 80, name: "无需复查", color: "#F56C6C" },
                    { id: 100, name: "复查通过", color: "#67C23A" },
                ],
                originType: [
                    { id: null, name: "不限" },
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                reportTypes: [
                    { id: null, name: "不限" },
                    { id: 1, name: "隐患清单" },
                    { id: 2, name: "检查报告" },
                    { id: 3, name: "整改报告" },
                    { id: 4, name: "总结报告" },
                ],
            },
            urlParams: {
                code: "",
                enterpriseCode: "",
                projectId: "",
            },
            chooseYJModel: {},
            checkChnName: "",
        };
    },
    created() {
        this.initParams();
        this.urlParams.code = this.$route.query.code ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";
        this.queryParams3.taskCode = this.$route.query.code ?? "";
        this.queryParams1.ctCode = this.$route.query.code ?? "";
        this.getModel();
    },
    mounted() {
        this.search();
    },
    //随手拍

    methods: {
        /**
         * 移除检查
         */
        hdRemoverTemplate(index) {
            let _this = this;
            let item = _this.model.tempRelations[index];
            this.$confirm(`是否确认移除检查表[${item.tName}]?`, "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http
                    .post(
                        `danger/jgDangerTask/removeRelation/${_this.model.code}/${item.tCode}`
                    )
                    .then(function (res) {
                        _this.model.tempRelations.splice(index, 1);
                    });
            });
        },
        showReport(params) {
            this.$refs.PdfDialog.show(params);
            this.getModel();
        },
        getCompateClassName(row) {
            return row.row.complete ? "" : "complete";
        },

        // hdBuildReportBack() {
        //     this.activeName = "third";
        //     this.getModel();
        // },
        hdAccept(row) {
            this.$refs.taskDetailView.show(row, { type: 5 });
        },
        /**生成检查报告 */
        buildReport() {
            let _this = this;
            // debugger;
            _this.checkSubmit(1, function (res) {
                _this.$refs.buildDangerReport.show({
                    taskCodes: _this.model.code,
                    taskNames: _this.model.checkTaskName,
                    enterpriseCode: _this.model.enterpriseCode,
                    projectId: _this.model.sourceCode,
                });
            });
        },
        /**生成隐患清单*/
        buildDangerListReport() {
            let _this = this;
            _this.checkSubmit(2, function () {
                _this.$refs.dangerListReport.show({
                    taskCode: _this.model.code,
                });
            });
        },

        checkSubmit(type, callback) {
            let _this = this;
            let url = `${_this.controller}/checkSubmit/${this.model.code}/${type}`;
            _this.http.get(url).then((res) => {
                if (res.data.result) {
                    callback && callback(res);
                } else {
                    _this.msgError(res.data.errorMsg);
                    //callback
                }
            });
            // checkSubmit
        },
        handleChooseYJ() {
            this.chooseYJModel = {};
            this.libTempDetailsVisible = true;
            this.companyCode = this.model.enterpriseCode;
        },
        /**终止任务 */
        hdOverTask() {
            let _this = this;
            this.$confirm(
                "确定要终止任务及它的隐患吗?终止后将无法进行其他操作!",
                "警告",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            ).then(function (res) {
                let url = `${_this.controller}/overTask/${_this.model.code}`;
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.getModel();
                    }
                );
            });
        },
        handlerSelectImg(obj) {
            this.chooseYJModel.correctiveAdvise = obj.base.correctiveAdvise;
            this.chooseYJModel.gistSource = obj.base.gistSource;
            this.chooseYJModel.originalText = obj.base.originalText;
            this.chooseYJModel.attachs = obj.img.filePath;
            this.chooseYJModel.item = obj.item;
            this.chooseYJModel.lGCode = obj.base.lGCode;
            if (obj.item === "base-img") {
            }
            if (obj.item === "base-img-danger") {
                this.chooseYJModel.lGHDCode = obj.danger.lGHDCode;
                this.chooseYJModel.dFullName = obj.danger.dFullName;
                this.chooseYJModel.dCode = obj.danger.dCode;
                this.chooseYJModel.hiddenDangerDesc =
                    obj.danger.hiddenDangerDesc;
                this.chooseYJModel.hiddenDangerType =
                    obj.danger.hiddenDangerType;
                this.chooseYJModel.hiddenDangerTypeName =
                    obj.danger.hiddenDangerTypeName;
                this.chooseYJModel.legalLiability = obj.danger.legalLiability;
            }
            this.libTempDetailsVisible = false;
            this.$refs.dangerJgTaskDetail.show(
                { mainCode: this.model.code },
                { type: 4, lg: this.chooseYJModel }
            );
        },
        goTemplateCheck(tempCode) {
            //
            // model.status===10 && model.end==false
            let path = this.urlParams.projectId
                ? "DangerJgTemplateCheck"
                : "DangerJgTemplateCheckUs";
            this.$router.push({
                name: path,
                query: {
                    //是否可以编辑
                    ed: this.model.status === 10 ? "Y" : "N",
                    taskCode: this.model.code,
                    templateCode: tempCode,
                    projectId: this.urlParams.projectId,
                    enterpriseCode: this.urlParams.enterpriseCode,
                },
            });
            // this.$router.push({
            //     path: "dangerJgTemplateCheck",
            //     query: {
            //         taskCode: this.model.code,
            //         templateCode: tempCode,
            //     },
            // });
        },
        handleChooseLibTemplateShow() {
            this.$refs.chooseLibTemplate.show([]);
        },
        handleChooseLibTemplate(array) {
            var _this = this;
            if (array && array.length > 0) {
                let postArray = [];
                this.model.tempRelations.forEach((item) => {
                    postArray.push({
                        taskCode: item.taskCode,
                        tCode: item.tCode,
                        tName: item.tName,
                    });
                });
                let flag = false;

                array.forEach((item) => {
                    if (
                        postArray.findIndex((x) => x.tCode === item.tCode) < 0
                    ) {
                        flag = true;
                        postArray.push({
                            taskCode: _this.model.code,
                            tCode: item.tCode,
                            tName: item.title,
                        });
                    }
                });
                if (flag) {
                    _this.http
                        .post(
                            `${_this.controller}/pushRelation/${_this.model.code}`,
                            postArray
                        )
                        .then((res) => {
                            _this.model.tempRelations = res.data;
                        });
                }
            }
        },
        /**撤回任务 */
        backTask() {
            let _this = this;
            this.$confirm("确定要撤回任务及它的隐患吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                let url = `${_this.controller}/backTask/${_this.model.code}`;
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.getModel();
                    }
                );
            });
        },
        /**返回上页 */
        hdBack() {
            let _this = this;
            let routeName = "DangerJgTask";
            if (_this.$route.query.st) {
                switch (_this.$route.query.st.toString()) {
                    case "1":
                        routeName = "DangerJgProjectTaskIndex";
                        break;
                    case "2":
                        routeName = "";
                        break;
                    case "3":
                        routeName = "DangerJgTask";
                        break;
                }
            }
            _this.$router.push({
                name: routeName,
                query: {
                    projectId: _this.urlParams.projectId,
                    enterpriseCode: _this.urlParams.enterpriseCode,
                },
            });
        },

        /** 结束任务 */
        // hdEndTask() {
        //     let _this = this;
        //     let url = `${_this.controller}/endTask/${this.model.code}`;
        //     _this.http.postLoading(_this.loading(), url, {}, function (res) {
        //         _this.getModel();
        //     });
        // },
        //提交任务
        submitTask() {
            let _this = this;
            let url = `${_this.controller}/submitTask/${this.model.code}/1`;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                _this.getModel();
            });
        },
        /**恢复我的检查 */
        hdResetEndTask() {
            let _this = this;
            this.$confirm("确定要恢复我的检查吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                let url = `${_this.controller}/resetEndTask/${_this.model.code}`;
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.getModel();
                    }
                );
            });
        },

        /**恢复其他检查人的任务 */
        hdResetUserTask(row) {
            let _this = this;
            let url = `${_this.controller}/resetUserTask/${this.model.code}/${row.userName}`;

            this.$confirm(
                `是否确认为检查人${row.chnName}恢复检查任务?`,
                "警告",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            ).then(function () {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.getModel();
                    }
                );
            });
        },
        /**结束其他检查人的任务 */
        hdEndUserTask(row) {
            let _this = this;
            let url = `${_this.controller}/endUserTask/${this.model.code}/${row.userName}`;

            this.$confirm(
                `是否确认为检查人${row.chnName}结束检查任务?`,
                "警告",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            ).then(function () {
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.getModel();
                    }
                );
            });
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            var url = `${_this.detailController}/dangerDelete/${row.ctCode}/${row.id}`;
            this.$confirm("是否确认删除此行数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http.delLoading(_this.loading(), url, {}, function (res) {
                    _this.getModel();
                    _this.msgSuccess("删除成功");
                });
            });
        },
        handleDelete3(row) {
            var _this = this;
            this.$refs.EaglePage3.handleDelete(row, function (res) {
                _this.search3();
            });
        },

        search2() {
            let _this = this;
            let url = `${_this.controller}/getTaskUserList/${this.model.code}`;
            _this.http
                .get(url, { chnName: _this.checkChnName })
                .then(function (res) {
                    _this.$refs.EaglePage2.list = res.data;
                });
        },
        search3() {
            let _this = this;
            this.$refs.EaglePage3.search();

            //EaglePage3
            // _this.http.get(url).then(function (res) {
            //     _this.$refs.EaglePage2.list = res.data;
            // });
        },
        handEdit(row) {
            this.$refs.dangerJgTaskDetail.show(
                { mainCode: this.model.code, id: row.id },
                { type: 1 }
            );
        },
        handCopy(row) {
            this.$refs.dangerJgTaskDetail.show(
                { mainCode: this.model.code, id: row.id },
                { type: 5 }
            );
        },
        handView(row) {
            /**
             * 查看详情
             */
            this.$refs.taskDetailViewNew.show(row, { type: 1 });
        },
        handRand() {
            this.$refs.dangerJgTaskDetail.show(
                { mainCode: this.model.code },
                { type: 3 }
            );
        },
        resetQuery() {
            this.conditions1.checkResult.value = "N";
            this.conditions1.status.value = null;
            this.conditions1.originType.value = null;
            this.conditions1.hiddenDangerType.value = null;
            this.conditions1.keyWords.value = null;
            this.conditions1.status.value = null;
            this.search();
        },
        resetQueryCheckUser() {
            this.checkChnName = "";
            this.search2();
        },
        search() {
            this.$refs.EaglePage.search();
        },
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type", "danger_simple_danger_type"],
                function (res) {
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.dangerType = res.data.filter(
                        (p) => p.paramId === "danger_simple_danger_type"
                    );
                    _this.params.checkType.splice(0, 0, {
                        id: null,
                        name: "不限",
                    });
                    _this.params.dangerType.splice(0, 0, {
                        id: null,
                        name: "不限",
                    });
                }
            );
        },
        getModel() {
            let _this = this;
            let url = `${_this.controller}/${
                _this.urlParams.code
                    ? "getDataByCode/" + _this.urlParams.code
                    : "initData/0"
            }`;

            _this.http.get(url).then((res) => {
                _this.model = res.data;
                _this.queryParams1.ctCode = _this.model.code;
                _this.search();
                _this.search2();
                _this.search3();
            });
        },
        pushChecker() {
            this.$refs.eagleChooseUser.show("", "");
        },
        handRemoveChecker(row) {
            let _this = this;
            this.$confirm("是否确认移除此检查人员吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                let url = `${_this.controller}/removeChecker/${row.mainCode}/${row.userName}`;
                _this.http.postLoading(
                    _this.loading(),
                    url,
                    {},
                    function (res) {
                        _this.getModel();
                    }
                );
            });
        },
        pushNewChecker(data) {
            let _this = this;
            var tmpModel = {
                code: _this.model.code,
                checkNames: data.name,
                checkCodes: data.code,
            };
            let url = `${_this.controller}/pushChecker`;
            _this.http.postLoading(
                _this.loading(),
                url,
                tmpModel,
                function (res) {
                    _this.getModel();
                }
            );
        },
        /**生成整改报告 */
        buildVerifyReport() {
            let _this = this;
            this.$refs.verifyTaskReport.show({
                optionModel: {
                    relationName: _this.model.checkTaskName,
                    relationCode: _this.model.code,
                    relationType: 2,
                    projectId: _this.model.sourceCode,
                    enterpriseCode: _this.model.enterpriseCode,
                    enterpriseName: _this.model.enterpriseName,
                },
            });
        },
        resetQuery3() {
            this.conditions3.reportTypeId.value = null;
            this.conditions3.reportName.value = "";
            this.search3();
        },
        hdTabsClick(tab, event) {
            switch (tab.name) {
                case "first":
                    this.search();
                    break;
                case "second":
                    this.search2();
                    break;
                case "third":
                    this.search3();
                    break;
            }
        },
    },
};
</script>
<style scoped lang="scss">
.danger-check-plan-detail {
    padding: 10px;

    .el-card {
        margin-top: 10px;
    }

    .temp-block {
        background-color: #f4f9ff;
        width: 300px;
        padding: 5px 10px;
        display: inline-block;
        margin-right: 10px;
        border: 1px solid #e1f3d8;

        .temp-title {
            font-size: 15px;
            width: 245px;
            color: #303133;
            line-height: 28px;
        }

        .temp-button {
            text-align: right;
        }
    }
}
</style>
