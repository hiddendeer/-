<template name="danger-lg-task-submit">
    <el-dialog v-dialogDrag :visible.sync="submitDialog" width="600px" append-to-body show-close :close-on-click-modal="false" title="提交任务">
        <el-form :model="submitModel">
            <eagle-block border>
                <el-form-item label="提交选择" required prop="type">

                    <el-button :type="submitModel.type==1?'primary':'info'" @click="submitModel.type=1">需要复查</el-button>
                    <el-button :type="submitModel.type==2?'danger':'info'" @click="submitModel.type=2">无需复查</el-button>
                    <el-button :type="submitModel.type==3?'danger':'info'" @click="submitModel.type=3">终止任务</el-button>
                </el-form-item>
                <el-form-item>
                    <div>
                        <el-tag> 需要复查</el-tag> <span style="margin-left:10px">提交后,该任务隐患需要继续复查。</span>
                    </div>
                    <div>
                        <el-tag type="danger"> 无需复查</el-tag><span style="margin-left:10px">提交后,该任务隐患不需要复查,直接为复查通过。</span>
                    </div>
                    <div>
                        <el-tag type="danger"> 终止任务</el-tag><span style="margin-left:10px">提交后,该任务隐患不记录报表与大屏。</span>
                    </div>
                </el-form-item>
            </eagle-block>
        </el-form>

        <div slot="footer" class="dialog-footer">
            <el-button @click="submitDialog=false">取 消</el-button>
            <el-button type="primary" @click="submitTask">提 交</el-button>

        </div>
    </el-dialog>
</template>
<script>
import TreeNodeDialogVue from "../../system/company/template/TreeNodeDialog.vue";
export default {
    name: "danger-lg-task-submit",
    data() {
        return {
            submitDialog: false,
            controller: "danger/jgDangerTask",
            submitModel: {
                code: "",
                type: 1,
            },
        };
    },
    methods: {
        show(config) {
            this.submitDialog = true;
            this.submitModel.code = config.code;
        },
        submitTask() {
            let _this = this;
            let url = `${_this.controller}/submitTask/${this.submitModel.code}/${this.submitModel.type}`;
            // _this.http.post(url).then(function (res) {
            //     _this.submitDialog = false;
            //     _this.$emit("callback");
            // });
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                _this.submitDialog = false;
                _this.$emit("callback");
            });
        },
    },
};
</script>
<style scoped>
.el-dialog__body {
    padding: 0px 20px;
}
</style>