<template name="danger-dj-task-index">
    <div class="danger-dj-task-index">
        <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <el-col>
                <eagle-radio @change="search()" label-width="80px" label="检查类型" prop="checkType" v-model="conditions.checkType.value" :dataSource="params.checkType" size="small" />
            </el-col>
            <!-- <el-col>
                <eagle-radio @change="search()"   label-width="80px" label="状态" prop="status" v-model="conditions.status.value" :dataSource="params.taskStatus" size="small" />
            </el-col> -->
            <!-- <eagle-radio @change="search()"   label-width="80px" label="计划状态" prop="status" v-model="conditions.status.value" :dataSource="status" size="small" /> -->
            <eagle-input label-width="80px" @changeEnter="search()" label="任务名称" prop="checkTaskName" v-model="conditions.checkTaskName.value" placeholder="任务名称" clearable size="small" />
        </eagle-condition>
        <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams">
            <!-- <template slot="slot-buttons">
                <el-row :gutter="10" class="mb8">
                    <el-col :span="1.5">
                        <el-button type="primary"  icon="el-icon-plus" size="mini" @click="goDetail('')">新增检查任务</el-button>
                    </el-col>
                </el-row>
            </template> -->
            <template slot="slot-table">
                <el-table-column label="任务名称" align="left" prop="checkTaskName" />
                <el-table-column label="被检查单位" align="left" prop="enterpriseName" />

                <!-- <el-table-column label="检查人" align="center" prop="checkPersonChName" /> --> -->
                <!-- <el-table-column label="检查类型" align="center">
                    <template slot-scope="scope">
                        <span>{{formateDict(params.checkType,scope.row.checkType) }}</span>
                    </template>
                </el-table-column> -->
                <el-table-column label="开始/截止日期" align="left">
                    <template slot-scope="scope">
                        {{ parseTime(scope.row.startDate , "{y}/{m}/{d}")}}- {{ parseTime(scope.row.endDate,
                        "{y}/{m}/{d}")}}
                    </template>
                </el-table-column>
                <el-table-column label="检查人" align="left" prop="checkNames" />
                <el-table-column label="状态" align="left">
                    <template slot-scope="scope">
                        <span>{{formateDict(params.taskStatus,scope.row.status) }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="创建人" align="left" prop="createChnName" />
                <el-table-column label="创建日期" align="left">
                    <template slot-scope="scope">
                        {{ parseTime(scope.row.createDate , "{y}/{m}/{d}")}}
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="primary" @click.prevent.stop="goView(scope.row.code)">详情</eagle-row-button>
            </template>
        </eagle-page>

    </div>
</template>

<script>
export default {
    name: "danger-check-plan-index",
    data() {
        return {
            controller: "danger/jgDangerTask",
            conditions: {
                checkTaskName: { value: "", operate: "like" },
                status: { value: 30, operate: "=" },
                checkType: { value: "", operate: "=" },
            },
            queryParams: {
                dataType: "list",
                enterpriseCode: "",
                projectId: "",
            },
            checkType: [],
            params: {
                checkType: [],
                taskStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 10, name: "进行中", color: "#F56C6C" },
                    { id: 25, name: "任务终止", color: "#F56C6C" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    // { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
        };
    },

    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";

        console.log(this.queryParams);

        this.initParams();
    },
    mounted() {
        this.search();
    },
    methods: {
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type"],
                function (res) {
                    _this.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                }
            );
        },
        search() {
            this.$refs.EaglePage.search();
        },
        //查询条件重置
        resetQuery() {
            // this.conditions.checkType.value = "";
            this.conditions.checkTaskName.value = "";
            this.conditions.status.value = null;

            this.search();
        },
        goDetail(code) {
            this.$router.push({
                name: "DangerJgTaskDetail",
                query: {
                    code: code,
                    enterpriseCode: this.queryParams.enterpriseCode,
                    projectId: this.queryParams.projectId,
                },
            });
        },
        goView(code) {
            this.$router.push({
                name: "DangerJgTaskView",
                query: {
                    code: code,
                    enterpriseCode: this.queryParams.enterpriseCode,
                    projectId: this.queryParams.projectId,
                    st: 2,
                },
            });
        },
    },
};
</script>
<style scoped lang="scss">
.danger-check-plan-index {
    padding: 20px;
}
</style>