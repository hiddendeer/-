<template name="build-danger-report ">
    <div class="build-danger-report">
        <el-dialog v-dialogDrag :title="title" width="600px" :visible.sync="visible" label-width="120px" show-close :close-on-click-modal="false">
            <el-form ref="form" :model="model" label-width="120px" class="lg_form" size="small">
                <eagle-block border>
                    <eagle-input required label="报告名称" prop="reportName" v-model="model.reportName" />
                    <!-- 1 -->
                    <eagle-select label="报告模板" key="reportTemplateCode" prop="reportTemplateCode" v-if="reportTemp && reportTemp.length>0" required :dataSource="reportTemp" @change="changeReportSource" v-model="model.reportTemplateCode" />
                    <eagle-picker-range label-width="120px" type="daterange" format="yyyy-MM-dd" prop="datetimes" v-model="model.datetimes" label="检查起始时间" required @change="changeDatetimes" />
                    <eagle-input type="textarea" label-width="120px" label="总结和建议" :rows="3" prop="remarks" v-model="model.remarks" />
                </eagle-block>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible=false">关 闭</el-button>
                <el-button type="primary" @click="submitForm">生成报告</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
export default {
    components: {},
    name: "build-danger-report",
    props: {},
    data() {
        return {
            title: "生成检查报告",
            controller: "danger/report",
            visible: false,
            model: {},
            params: {
                reportSource: [],
            },

            taskCodes: "",
            taskNames: "",
            enterpriseCode: "",
            projectId: "",
            reportTemp: [],
            taskModel: {},
            reportTemplateCode: null,
        };
    },
    created() {
        this.getReportTemp();
        // this.getModel();
    },
    methods: {
        submitForm() {
            let _this = this;
            let url = `danger/jgDangerTask/buildDangerCheckReportNew`;
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        _this.model,
                        function (res) {
                            _this.msgSuccess("报告生成成功");
                            _this.visible = false;
                            if (
                                res.data &&
                                res.data.report &&
                                res.data.report.reportAttach
                            ) {
                                let fileInfo = res.data.report.reportAttach;
                                let row = JSON.parse(fileInfo)[0];
                                let code = row.attCode || row.AttCode;
                                var params = { code: code };
                                params.fileName = row.name;
                                _this.$emit("afterSave", params);
                            }
                        }
                    );
                }
            });
        },
        changeReportSource() {
            this.model.reportTemplateName = this.formateDict(
                this.params.reportSource,
                this.model.reportTemplateCode
            );
        },
        getModel() {
            let _this = this;
            let url = `${this.controller}/initData/0?projectId=${_this.projectId}&reportType=2&companyCode=${_this.enterpriseCode}&taskCode=${_this.taskCodes}`;
            _this.http.get(url).then((res) => {
                _this.bindData(res.data);
            });
        },
        bindData(data) {
            this.model = data;
            // this.model.reportName = this.taskNames;
            // this.model.sourceName = this.taskNames;
            // this.model.sourceId = this.taskCodes;
            // this.model.projectId = this.projectId;
            if (this.reportTemplateCode) {
                this.model.reportTemplateCode = this.reportTemplateCode;
            }
            this.$set(this.model, "datetimes", []);
            this.model.datetimes.push(this.model.startDate);
            this.model.datetimes.push(this.model.endDate);
        },

        // getDateStr() {
        //     var date = new Date();
        //     var year = date.getFullYear();
        //     var month = date.getMonth() + 1;
        //     var day = date.getDate();
        //     return `${year}${month > 9 ? month : "0" + month}${day}`;
        // },

        changeDatetimes(data) {
            this.model.startDate = data[0];
            this.model.endDate = data[1];
        },
        getReportTemp() {
            let url = `site/fileToolDataSource/getMap?reportType=DangerJgCheckReport`;
            let _this = this;
            _this.http.get(url).then((res) => {
                _this.reportTemp = res.data;
                if (res.data) {
                    _this.reportTemplateCode = res.data[0].id;
                    _this.reportTemplateName = res.data[0].name;
                }
            });
        },

        // getParams() {
        //     let _this = this;
        //     let url =
        //         "site/fileToolDataSource/getMap?reportType=DangerJgCheckReport";
        //     _this.http.get(url).then((res) => {
        //         _this.params.reportSource = res.data;
        //     });
        // },
        show(config) {
            this.taskCodes = config.taskCodes;
            this.taskNames = config.taskNames;
            this.enterpriseCode = config.enterpriseCode ?? "";
            this.projectId = config.projectId;
            this.visible = true;
            this.getModel();
        },
    },
};
</script>
<style lang="scss" scoped>
</style>