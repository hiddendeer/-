<template name="danger-jg-verify" >
    <div class="danger-jg-verify">
        <el-tabs v-model="activeName" @tab-click="hdTabsClick">
            <el-tab-pane label="按任务复查" name="first">
                <taskVerify />
            </el-tab-pane>
            <el-tab-pane label="按单位复查" name="second">
                <enterpriseVerify />
            </el-tab-pane>
            <!-- <el-tab-pane label="整改报告" name="third">
                <verifyReportList />
            </el-tab-pane> -->
        </el-tabs>
    </div>
</template>
<script>
import enterpriseVerify from "@/views/dangerJg/dangerJgVerify/enterpriseVerify";
import taskVerify from "@/views/dangerJg/dangerJgVerify/taskVerify";
// import verifyReportList from "@/views/dangerJg/dangerJgVerify/verifyReportList";
export default {
    components: { enterpriseVerify, taskVerify },
    name: "danger-jg-verify",
    props: {},
    data() {
        return {
            activeName: "first",
        };
    },
    created() {
        this.activeName = this.$route.query.active ?? "first";
    },
    methods: {
        hdTabsClick(tab, event) {},
    },
};
</script>
<style scoped lang="scss">
.danger-jg-verify {
    padding: 10px;
    background: #fff;
}
</style>