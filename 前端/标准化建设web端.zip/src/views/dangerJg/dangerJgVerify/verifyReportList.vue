<template name="danger-dj-verify-report-list">
    <div class="danger-dj-verify-report-list app-container">
        <div class="layer">
            <eagle-page :queryParams="queryParams" :controller="controller" ref="EaglePage" :showCheckColumn="false" btnWidth="250">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-radio v-if="pageName !== 'ProjectJgReportList'" @change="search()" label-width="80px" label="报告类型" prop="reportTypeId" v-model="conditions.reportTypeId.value" :dataSource="params.reportTypes" size="small" />
                        <eagle-input label-width="80px" @changeEnter="search()" label="报告名称" prop="reportName" v-model="conditions.reportName.value" placeholder="报告名称" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-buttons" v-if="pageName == 'ProjectJgReportList'">
                    <el-row :gutter="10" class="mb8">
                        <el-col :span="1.5">
                            <el-button type="primary" icon="el-icon-plus" size="mini" @click="showWindowTaskList()">
                                按任务生成总结报告</el-button>
                            <!-- <el-button type="primary"  icon="el-icon-plus" size="mini" @click="goDetail('')">按隐患生成总结报告</el-button> -->
                        </el-col>
                    </el-row>
                </template>
                <template slot="slot-table">
                    <el-table-column label="报告名称" align="left" prop="reportName" width="350" />
                    <el-table-column label="报告文件" align="left" prop="plan">
                        <template slot-scope="scope">
                            <eagle-row-attach :isReport="true" v-model="scope.row.reportAttach"></eagle-row-attach>
                        </template>
                    </el-table-column>
                    <el-table-column label="报告类型" align="left" width="100" v-if="pageName !== 'ProjectJgReportList'">
                        <template slot-scope="scope"><span>{{ formateDict(params.reportTypes, scope.row.reportTypeId)
                        }}</span></template>
                    </el-table-column>
                    <!-- <el-table-column label="检查时间" align="center" prop="plan" width="200">
                        <template slot-scope="scope">
                            {{ parseTime(scope.row.startDate, "{y}-{m}-{d}")}} ~ {{ parseTime(scope.row.endDate, "{y}-{m}-{d}")}}
                        </template>
                    </el-table-column> -->
                    <el-table-column label="报表版本" align="left" width="100" prop="plan">
                        <template slot-scope="scope">
                            {{ scope.row.status == 10 ? "最新报告" : "历史报告" }}
                        </template>
                    </el-table-column>
                    <el-table-column label="报告人" align="left" width="100" prop="plan">
                        <template slot-scope="scope">
                            {{ scope.row.createChnName }}
                        </template>
                    </el-table-column>
                    <el-table-column label="报告生成日期" align="left" width="150" prop="plan">
                        <template slot-scope="scope">
                            {{ scope.row.createDate }}
                        </template>
                    </el-table-column>
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="danger" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button>
                    <eagle-row-button type="primary" @click.prevent.stop="downLoad(scope.row, '.docx')">word报告
                    </eagle-row-button>
                    <eagle-row-button type="warning" @click.prevent.stop="downLoad(scope.row, '.pdf')">pdf报告
                    </eagle-row-button>
                </template>
            </eagle-page>
            <window-task-list ref="windowTaskList" @change="changeTask" />
            <project-report ref="projectReport" @afterSave="showReport" />
            <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>

        </div>

    </div>
</template>
<script>
import windowTaskList from "@/views/dangerJg/dangerJgVerify/windowTaskList";
import projectReport from "@/views/dangerJg/dangerJgVerify/projectReport";
export default {
    components: { windowTaskList, projectReport },
    name: "danger-dj-verify-report",
    data() {
        return {
            pageName: "",
            controller: "danger/report",
            queryParams: {
                dataType: "projectReport",
                enterpriseCode: "",
                projectId: "",
            },
            conditions: {
                reportName: {
                    value: "",
                },
                reportTypeId: {
                    value: null,
                    operate: "=",
                },
            },
            params: {
                reportTypes: [
                    { id: null, name: "不限" },
                    { id: 1, name: "隐患清单" },
                    { id: 2, name: "检查报告" },
                    { id: 3, name: "整改报告" },
                ],
            },
        };
    },
    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.pageName =
            typeof this.$route.name == "string"
                ? this.$route.name
                : this.$route.name[0];
        switch (this.pageName) {
            case "DangerJgReportList":
                this.queryParams.dataType = "taskReport";
                break;
            case "ProjectJgReportList":
                // this.conditions.reportTypeId.value = 4;
                this.queryParams.dataType = "projectReport";
                break;
            case "DangerJgReportListUs":
                this.queryParams.dataType = "myReport";
                break;
        }
        setTimeout(() => {
            this.search();
        });
    },
    mounted() {
        // setTimeout(() => {
        //     this.search();
        // });
    },
    methods: {
        showReport(params) {
            this.search();
            this.$refs.PdfDialog.show(params);
        },
        changeTask(selection) {
            this.$refs.projectReport.show({
                selection: selection,
                projectId: this.queryParams.projectId,
            });
        },
        showWindowTaskList() {
            //
            this.$refs.windowTaskList.show({
                type: "report",
                projectId: this.queryParams.projectId,
            });
        },
        resetQuery() {
            this.conditions.reportName.value = "";
            this.conditions.reportTypeId.value = null;
            this.search();
        },
        search() {
            this.$refs.EaglePage.search({
                conditions: this.getBaseCondtions(this.conditions),
            });
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.search();
            });
        },
        getBaseCondtions(obj) {
            let conditionsArry = [];
            for (let key in obj) {
                let ops = obj[key].operate;
                let vals = obj[key].value;
                if (vals) {
                    conditionsArry.push({
                        name: key,
                        operate: !ops ? "like" : ops,
                        value: vals,
                    });
                }
            }
            return conditionsArry && conditionsArry.length > 0
                ? JSON.stringify(conditionsArry)
                : conditionsArry;
        },
        downLoad(item, type) {
            let jsostr = [];
            if (item.reportAttach) {
                jsostr = JSON.parse(item.reportAttach);
            }
            var _this = this;
            this.http
                .get("/file/getDataByAttCode/" + jsostr[0].attCode)
                .then((res) => {
                    if (res.code == 200) {
                        const a = document.createElement("a");
                        var url =
                            type == ".pdf"
                                ? res.data.attMiddlePath
                                : res.data.attFilePath;
                        fetch(url)
                            .then((res) => res.blob())
                            .then((blob) => {
                                a.href = URL.createObjectURL(blob);
                                a.download = res.data.attName + type; // 下载文件的名字
                                document.body.appendChild(a);
                                a.click();
                            });
                    }
                });
        },
    },
};
</script>
<style scoped lang="scss">
</style>