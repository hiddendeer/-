<template name="danger-dj-task-verify ">
    <div class="danger-dj-task-verify  app-container">
        <div class="layer">
            <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams"
                btnWidth="250" :showCheckColumn="false">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-radio @change="search()" label-width="80px" label="复查状态" prop="status"
                            v-model="conditions.status.value" :dataSource="params.taskStatus" size="small" />
                        <eagle-radio @change="search()" label-width="80px" label="整改报告" prop="reportStatus"
                            v-model="conditions.reportStatus.value" :dataSource="params.reportStatus" size="small" />
                        <eagle-input label-width="80px" @changeEnter="search()" label="任务名称" prop="checkTaskName"
                            v-model="conditions.checkTaskName.value" placeholder="请输入任务名称" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-table">
                    <el-table-column label="任务名称" align="left" prop="checkTaskName" width="300px" />
                    <el-table-column label="被检查单位" align="left" prop="enterpriseName" width="300px" />

                    <el-table-column label="状态" align="left">
                        <template slot-scope="scope">
                            <span v-html="formateStatus(params.taskStatus, scope.row.status)"></span>
                            <span v-if="scope.row.unNextVerify" style="color:red"> (无需复查)</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="整改报告" align="left">
                        <template slot-scope="scope">
                            <eagle-row-attach :isReport="true" v-model="scope.row.verifyAttachs"></eagle-row-attach>
                        </template>
                    </el-table-column>
                    <el-table-column label="开始/截止日期" align="left" width="200px">
                        <template slot-scope="scope">
                            {{ parseTime(scope.row.startDate, "{y}/{m}/{d}") }}- {{ parseTime(scope.row.endDate,
                                    "{y}/{m}/{d}")
                            }}
                        </template>
                    </el-table-column>
                    <el-table-column label="检查人" align="left" prop="checkNames" />
                </template>
                <template slot="slot-row-buttons" slot-scope="scope">
                    <eagle-row-button type="primary" v-if="scope.row.status == 30"
                        @click.prevent.stop="goVerifyDetails(scope.row)">复查</eagle-row-button>
                    <eagle-row-button type="success" v-if="scope.row.status == 100"
                        @click.prevent.stop="goVerifyDetails(scope.row)">详情</eagle-row-button>
                    <eagle-row-button type="danger" v-if="scope.row.status == 30"
                        @click.prevent.stop="hdUnVerify(scope.row.code)">无需复查</eagle-row-button>
                    <eagle-row-button type="danger" v-if="scope.row.status == 100 && scope.row.unNextVerify"
                        @click.prevent.stop="backVerify(scope.row.code)">恢复复查</eagle-row-button>
                    <eagle-row-button type="primary" v-if="scope.row.status == 100"
                        @click.prevent.stop="buildVerifyReport(scope.row)">生成整改报告</eagle-row-button>
                </template>
            </eagle-page>
            <verifyTaskReport ref="verifyTaskReport" @afterSave="showReport" />
            <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>
        </div>
    </div>
</template><script>
import verifyTaskReport from "@/views/dangerJg/task/buildTaskVerifyReport";
export default {
    components: { verifyTaskReport },
    name: "danger-dj-task-verify",
    data() {
        return {
            controller: "danger/jgDangerTask",
            conditions: {
                checkTaskName: { value: "", operate: "like" },
                status: { value: null, operate: "=" },
                reportStatus: { value: null, operate: "=" },
            },
            queryParams: {
                dataType: "verifyList",
                enterpriseCode: "",
                projectId: "",
            },

            params: {
                taskStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
                reportStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 2, name: "未生成整改报告", color: "#67C23A" },
                    { id: 1, name: "已生成整改报告", color: "#F56C6C" },
                ],
            },
        };
    },

    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.initParams();
        // setTimeout(() => { this.search(); })
    },
    mounted() {
        setTimeout(() => {
            this.search();
        });
    },
    methods: {
        showReport(params) {
            this.$refs.PdfDialog.show(params);
            this.search();
        },
        hdUnVerify(code) {
            let _this = this;
            _this
                .$confirm("是否确定该检查任务无需复查?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                })
                .then(function (res) {
                    let url = `${_this.controller}/unVerify/${code}`;
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.msgSuccess("操作成功");
                            _this.search();
                        }
                    );
                });
        },

        backVerify(code) {
            let _this = this;
            _this
                .$confirm("是否确定该检查任务恢复复查?", "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                })
                .then(function (res) {
                    let url = `${_this.controller}/backVerify/${code}`;
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.msgSuccess("操作成功");
                            _this.search();
                        }
                    );
                });
        },

        buildVerifyReport(row) {
            this.$refs.verifyTaskReport.show({
                optionModel: {
                    relationName: row.checkTaskName,
                    relationCode: row.code,
                    relationType: 2,
                    projectId: row.sourceCode,
                    enterpriseCode: row.enterpriseCode,
                    enterpriseName: row.enterpriseName,
                },
            });
        },
        initParams() { },
        search() {
            this.$refs.EaglePage.search();
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.search();
            });
        },

        //查询条件重置
        resetQuery() {
            this.conditions.checkTaskName.value = "";
            this.conditions.status.value = null;
            this.conditions.reportStatus.value = null;
            this.search();
        },

        goVerifyDetails(row) {
            this.$router.push({
                name: this.$route.query.projectId
                    ? "DangerJgVerifyTaskView"
                    : "DangerJgVerifyTaskViewUs",
                query: {
                    code: row.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                },
            });
        },
    },
};
</script>
<style scoped lang="scss">
.taskVerify {
    background: #fff;
    padding: 10px;
}
</style>