<template name="danger-dj-enterprise-verify">
    <div class="danger-dj-enterprise-verify">

        <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams"
            btnWidth="200" :showCheckColumn="false">
            <template slot="slot-search">
                <eagle-condition @search="search()" @resetQuery="resetQuery()">
                    <el-col>
                        <eagle-radio @change="search()" label-width="80px" label="复查状态" prop="status"
                            v-model="conditions.checkStatus.value" :dataSource="params.checkStatus" size="small" />
                    </el-col>
                    <el-col>
                        <eagle-radio @change="search()" label-width="80px" label="整改报告" prop="reportStatus"
                            v-model="conditions.reportStatus.value" :dataSource="params.reportStatus" size="small" />
                    </el-col>
                    <eagle-input label-width="80px" @changeEnter="search()" label="单位名称" prop="enterpriseName"
                        v-model="conditions.enterpriseName.value" placeholder="被检查单位名称" clearable size="small" />
                </eagle-condition>
            </template>
            <template slot="slot-table">
                <el-table-column label="被检查单位名称" align="left" prop="enterpriseName" width="300" />
                <el-table-column label="任务数" align="left" prop="taskCount" />
                <el-table-column label="隐患数" align="left" prop="dangerCount" />
                <el-table-column label="待复查隐患数" align="left" prop="waiteVerifyCount" />
                <el-table-column label="状态" align="left">
                    <template slot-scope="scope">
                        <span v-if="scope.row.waiteVerifyCount > 0" style="color:#F56C6C"> 待复查 </span>
                        <span v-else style="color:#67C23A"> 已完成 </span>
                    </template>
                </el-table-column>

                <el-table-column label="整改报告" align="left">
                    <template slot-scope="scope">
                        <eagle-row-attach v-model="scope.row.verifyAttach"></eagle-row-attach>
                    </template>
                </el-table-column>
            </template>
            <template slot="slot-row-buttons" slot-scope="scope">
                <eagle-row-button type="primary" v-if="scope.row.waiteVerifyCount > 0"
                    @click.prevent.stop="goVerifyDetails(scope.row)">复查</eagle-row-button>
                <eagle-row-button type="success" v-else @click.prevent.stop="goVerifyDetails(scope.row)">详情
                </eagle-row-button>
                <eagle-row-button type="primary" @click.prevent.stop="buildVerifyReport(scope.row)">生成整改报告
                </eagle-row-button>
            </template>
        </eagle-page>
        <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>

        <verifyTaskReport ref="verifyTaskReport" @afterSave="showReport" />
    </div>
</template><script>
import verifyTaskReport from "@/views/dangerJg/task/buildTaskVerifyReport";
export default {
    components: { verifyTaskReport },
    name: "danger-dj-enterprise-verify",
    data() {
        return {
            controller: "danger/checkEnterprise",
            conditions: {
                enterpriseName: { value: "", operate: "like" },
                checkStatus: { value: null, operate: "=" },
                reportStatus: { value: null, operate: "=" },
            },
            queryParams: {
                dataType: "verifyList",
                enterpriseCode: "",
                projectId: "",
            },
            checkType: [],
            params: {
                checkType: [],
                checkStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 2, name: "待复查", color: "#F56C6C" },
                    { id: 1, name: "已完成", color: "#67C23A" },
                ],
                reportStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 1, name: "已生成整改报告", color: "#F56C6C" },
                    { id: 2, name: "未生成整改报告", color: "#67C23A" },
                ],
            },
        };
    },

    created() {
        this.queryParams.enterpriseCode =
            this.$route.query.enterpriseCode ?? "";
        this.queryParams.projectId = this.$route.query.projectId ?? "";
        this.initParams();
    },
    mounted() {
        this.search();
    },
    methods: {
        showReport(params) {
            this.$refs.PdfDialog.show(params);
            this.search();
        },
        buildVerifyReport(row) {
            this.$refs.verifyTaskReport.show({
                optionModel: {
                    relationName: row.enterpriseName,
                    relationCode: row.enterpriseCode,
                    relationType: 1,
                    code: row.code,
                    projectId: row.projectId,
                    enterpriseCode: row.enterpriseCode,
                    enterpriseName: row.enterpriseName,
                },
            });
        },
        initParams() { },
        search() {
            this.$refs.EaglePage.search();
        },
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.search();
            });
        },

        //查询条件重置
        resetQuery() {
            this.conditions.checkStatus.value = "";
            this.conditions.reportStatus.value = null;
            this.conditions.enterpriseName.value = "";
            this.search();
        },
        goVerifyDetails(row) {
            this.$router.push({
                name: "DangerJgVerifyEnterpriseView",
                query: {
                    code: row.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                },
            });
        },
    },
};
</script>
<style scoped lang="scss">
</style>