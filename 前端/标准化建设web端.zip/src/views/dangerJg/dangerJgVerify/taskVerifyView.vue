 <!-- 任务详情 -->
  <template name="danger-task-verify-view">
    <div class="danger-task-verify-view">
        <el-form ref="elForm" :model="model">
            <eagle-fold-block>
                <div slot="header" class="clearfix">
                    <span style="font-size:16px;"> </span><span>({{model.enterpriseName}})</span>
                    <el-button type="default" size="mini" style="float: right; margin-left:10px" @click="hdBack">返 回
                    </el-button>
                    <el-button type="primary" size="mini" style="float: right; margin-left:10px" @click="buildReport">
                        生成整改报告</el-button>
                </div>
                <div class="form-view">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="任务名称">
                                <span>{{model.checkTaskName}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="检查类型" prop="checkType">
                                <span>{{formateDict(params.checkType,model.checkType) }}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="状态">
                                <span v-html="formateStatus(params.taskStatus,model.status)"></span>
                                <span v-if="model.unNextVerify" style="color:red">(无需复查)</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="被检查单位">
                                <span>{{model.enterpriseName}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="检查人">
                                <span>{{model.checkNames}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="开始/截止日期">
                                {{ parseTime(model.startDate , "{y}/{m}/{d}")}} ~ {{ parseTime(model.endDate,
                                "{y}/{m}/{d}")}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="创建人">
                                <span>{{model.createChnName}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="创建时间">
                                {{ parseTime(model.createDate , "{y}/{m}/{d} {h}:{i}")}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="隐患清单">
                                <eagle-row-attach v-model="model.dangerListReportAttach"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="检查报告">
                                <eagle-row-attach v-model="model.checkAttachs"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label-width="120px" label="整改报告">
                                <eagle-row-attach v-model="model.verifyAttachs"></eagle-row-attach>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col>
                            <el-form-item label-width="120px" label="检查要求">
                                <span>{{model.checkRequirement}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>
            </eagle-fold-block>

            <el-card class="box-card mt10">
                <div slot="header" class="clearfix">
                    <span>检查记录</span>
                </div>
                <eagle-page :controller="detailController" :rowClassName="getCompateClassName" ref="EaglePage" :conditions="dangerCoditions" :query-params="dangerParams" btnWidth="200px" :showCheckColumn="false">
                    <template slot="slot-search">
                        <eagle-condition @search="search()" @resetQuery="resetQuery()">
                            <eagle-select @change="search()" label-width="80px" label="检查类型" prop="originType" v-model="dangerCoditions.originType.value" :dataSource="params.originType" size="small" />
                            <eagle-select @change="search()" label-width="80px" label="隐患性质" prop="hiddenDangerType" v-model="dangerCoditions.hiddenDangerType.value" :dataSource="params.dangerType" size="small" />
                            <eagle-select @change="search()" label-width="80px" label="隐患状态" prop="status" v-model="dangerCoditions.status.value" :dataSource="params.correctiveStatus" size="small" />
                            <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="keyWords" v-model="dangerCoditions.keyWords.value" placeholder="请输入隐患描述,整改建议,操作人进行模糊查询" clearable size="small" />
                        </eagle-condition>
                    </template>
                    <template slot="slot-table">
                        <el-table-column label="隐患描述" align="left" prop="hiddenDangerDesc" width="300" />
                        <el-table-column label="隐患图片" align="center" prop="attachs" width="100">
                            <template slot-scope="scope">
                                <eagle-row-image v-model="scope.row.attachs" />
                            </template>
                        </el-table-column>
                        <el-table-column label="隐患区域" align="left" prop="hiddenDangerArea" />
                        <el-table-column label="隐患分类" align="left" prop="lgdName" width="200" />
                        <!-- <el-table-column label="整改建议" align="left" prop="correctiveAdvise" width="300" /> -->
                        <el-table-column label="检查类型" align="left">
                            <template slot-scope="scope"><span>{{formateDict(params.originType,scope.row.originType)
                            }}</span></template>
                        </el-table-column>
                        <el-table-column label="隐患状态" align="left">
                            <template slot-scope="scope"><span v-html="formateStatus(params.correctiveStatus,scope.row.status)"></span></template>
                        </el-table-column>
                        <el-table-column label="检查表" align="left" prop="tName" />
                        <el-table-column label="操作人" align="left" prop="createChnName" />
                        <el-table-column label="操作时间" align="left" prop="createDate" width="140">
                            <template slot-scope="scope"><span>{{ parseTime(scope.row.createDate, "{y}-{m}-{d} {h}:{i}")
                            ||"--"}}</span></template>
                        </el-table-column>
                    </template>
                    <template slot="slot-row-buttons" slot-scope="scope">
                        <eagle-row-button type="primary" @click.prevent.stop="handView(scope.row)">详情</eagle-row-button>
                        <!-- <eagle-row-button type="primary" icon="el-icon-edit" @click.prevent.stop="handEdit(scope.row)">编辑</eagle-row-button>
                          <eagle-row-button type="danger" icon="el-icon-delete" @click.prevent.stop="handleDelete(scope.row)">删除</eagle-row-button> -->
                        <eagle-row-button type="primary" v-if="scope.row.status>=30 && scope.row.status<80" @click.prevent.stop="hdAccept(scope.row)">复查</eagle-row-button>
                    </template>
                </eagle-page>
            </el-card>
        </el-form>
        <verifyTaskReport ref="verifyTaskReport" @afterSave="showReport" />
        <taskDetailView ref="taskDetailView" @afterSave="getModel" />
        <taskDetailViewNew ref="taskDetailViewNew" @afterSave="getModel" />
        <dangerJgTaskDetail ref="dangerJgTaskDetail" @afterSave="getModel" />
        <eagle-pdf-dialog :isReport="true" ref="PdfDialog"></eagle-pdf-dialog>
    </div>
</template>

<script>
import taskDetailView from "../task/details/taskDetailView";
import taskDetailViewNew from "../task/details/view";
import dangerJgTaskDetail from "@/views/dangerJg/task/taskDetail";
import verifyTaskReport from "@/views/dangerJg/task/buildTaskVerifyReport";
import EagleFoldBlock from "@/components/Eagle/eagle-fold-block.vue";
// import { resetForm } from "@/utils/EageleRMC";
export default {
    components: {
        dangerJgTaskDetail,
        verifyTaskReport,
        taskDetailView,
        taskDetailViewNew,
        EagleFoldBlock,
    },
    name: "danger-task-verify-view",
    data() {
        return {
            libDataType: "img",
            libTempDetailsVisible: false,
            submitDialog: false,
            controller: "danger/jgDangerTask",
            detailController: "danger/jgDangerTaskDetail",
            reportController: "danger/dangerJgReport",
            model: {},
            submitModel: {
                type: 1,
            },
            id: "0",
            // datetimes: [],
            dangerCoditions: {
                checkResult: { value: "N", operate: "=" },
                status: { value: null, operate: "=" },
                originType: { value: null, operate: "=" },
                hiddenDangerType: { value: null, operate: "=" },
                keyWords: { value: null, operate: "like" },
            },
            dangerParams: { ctCode: "", dataType: "taskDetail" },

            activeName: "first",
            params: {
                taskStatus: [
                    { id: null, name: "不限" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
                checkType: [],
                dangerType: [
                    { id: null, name: "不限" },
                    { name: "一般隐患", id: "1" },
                    { name: "重大隐患", id: "2" },
                ],
                correctiveStatus: [
                    { id: null, name: "不限", color: "#F56C6C" },
                    { id: 30, name: "待整改", color: "#F56C6C" },
                    { id: 60, name: "待复查", color: "#F56C6C" },
                    { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "复查通过", color: "#67C23A" },
                ],
                originType: [
                    { id: null, name: "不限" },
                    { id: 1, name: "随手拍" },
                    { id: 2, name: "依据检查" },
                    { id: 3, name: "检查表检查" },
                ],
                reportTypes: [
                    { id: 1, name: "检查报告" },
                    { id: 2, name: "整改报告" },
                ],
            },
            urlParams: {
                code: "",
                enterpriseCode: "",
                projectId: "",
            },
            chooseYJModel: {},
        };
    },
    created() {
        this.initParams();
        this.urlParams.code = this.$route.query.code ?? "";
        this.urlParams.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.urlParams.projectId = this.$route.query.projectId ?? "";

        this.getModel();
    },
    mounted() {},
    //随手拍

    methods: {
        showReport(params) {
            this.$refs.PdfDialog.show(params);
            this.getModel();
        },
        getCompateClassName(row) {
            console.log("row.row.complete=>", row.row.complete);
            return row.row.complete ? "" : "complete";
        },

        /**返回上页 */
        hdBack() {
            let _this = this;
            let routeName = "";
            if (_this.$route.query.st) {
                routeName = "DangerJgIndex";
            } else {
                routeName = _this.urlParams.projectId
                    ? "DangerJgVerifyList"
                    : "DangerJgVerifyTask";
            }
            _this.$router.push({
                name: routeName,
                query: {
                    projectId: _this.urlParams.projectId,
                    enterpriseCode: _this.urlParams.enterpriseCode,
                    active: "first",
                },
            });
        },
        hdAccept(row) {
            this.$refs.taskDetailView.show(row, { type: 5 });
        },
        /** 删除按钮操作 */
        handleDelete(row) {
            var _this = this;
            this.$refs.EaglePage.handleDelete(row, function (res) {
                _this.search();
            });
        },
        handEdit(row) {
            this.$refs.dangerJgTaskDetail.show(
                { mainCode: this.model.code, id: row.id },
                { type: 1 }
            );
        },

        handView(row) {
            /**
             * 查看详情
             */

            this.$refs.taskDetailViewNew.show(row, { type: 1 });
        },
        handRand() {
            this.$refs.dangerJgTaskDetail.show(
                { mainCode: this.model.code },
                { type: 3 }
            );
        },
        resetQuery() {
            this.dangerCoditions.status.value = null;
            this.dangerCoditions.originType.value = null;
            this.dangerCoditions.hiddenDangerType.value = null;
            this.dangerCoditions.keyWords.value = null;
            this.dangerCoditions.status.value = null;
            this.search();
        },
        search() {
            this.$refs.EaglePage.search();
        },
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type"],
                function (res) {
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType.splice(0, 0, {
                        id: null,
                        name: "不限",
                    });
                }
            );
        },
        getModel() {
            let _this = this;
            let url = `${_this.controller}/getDataByCode/${_this.urlParams.code}`;

            _this.http.get(url).then((res) => {
                _this.model = res.data;
                if (_this.$refs["elForm"]) {
                    _this.$refs["elForm"].resetFields();
                }
                _this.dangerParams.ctCode = _this.model.code;
                _this.search();
            });
        },
        buildReport() {
            let _this = this;
            this.$refs.verifyTaskReport.show({
                optionModel: {
                    relationName: _this.model.checkTaskName,
                    relationCode: _this.model.code,
                    relationType: 2,
                    projectId: _this.model.sourceCode,
                    enterpriseCode: _this.model.enterpriseCode,
                    enterpriseName: _this.model.enterpriseName,
                },
            });
        },
    },
};
</script>
<style scoped lang="scss">
.danger-task-verify-view {
    // padding: 20px;

    .t-list {
        .el-tag {
            cursor: pointer;
            margin-right: 10px;
        }
    }
}
</style>
