<template name="danger-dj-window-task-list">
    <el-dialog v-dialogDrag :visible.sync="submitDialog" width="1000px" append-to-body show-close
        :close-on-click-modal="false" title="选择检查任务">
        <div>
            <!-- <eagle-block border> -->
            <div class="danger-dj-window-task-list app-container">
                <eagle-block border>
                    <eagle-window-choose :controller="controller" :conditions="conditions" ref="EaglePage"
                        table-height="270" :single="false" selectTextField="checkTaskName" selectField="code">
                        <!-- <eagle-page :controller="controller" ref="EaglePage" :conditions="conditions" :query-params="queryParams" :showBtn="false" @handleSelectionChange="handleSelectionChange"> -->
                        <template slot="slot-search">
                            <eagle-condition @search="search()" @resetQuery="resetQuery()">
                                <el-row>
                                    <el-col>
                                        <eagle-select @change="search()" label-width="80px" label="检查类型"
                                            prop="checkType" v-model="conditions.checkType.value"
                                            :dataSource="params.checkType" size="small" />
                                        <eagle-select @change="search()" label-width="80px" label="状态" prop="status"
                                            v-model="conditions.status.value" :dataSource="params.taskStatus"
                                            size="small" />
                                        <eagle-select @change="search()" label-width="80px" label="任务来源"
                                            prop="sourceType" v-model="conditions.sourceType.value"
                                            :dataSource="params.sourceType" size="small" />
                                    </el-col>
                                </el-row>
                                <eagle-input label-width="80px" @changeEnter="search()" label="任务名称"
                                    prop="checkTaskName" v-model="conditions.checkTaskName.value" placeholder="任务名称"
                                    clearable size="small" />
                            </eagle-condition>
                        </template>
                        <template slot="slot-table">
                            <el-table-column label="任务名称" align="left" prop="checkTaskName" width="150px" />
                            <el-table-column label="项目名称" align="left" prop="sourceName" width="150px" />
                            <el-table-column label="被检查单位" align="left" prop="enterpriseName" width="150px" />
                            <el-table-column label="是否复查" align="left" width="100px">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.verifyDanger ? "需要复查" : "无需复查" }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column label="开始/截止日期" align="left" width="200px">
                                <template slot-scope="scope">
                                    {{ parseTime(scope.row.startDate, "{y}/{m}/{d}") }} - {{
                                            parseTime(scope.row.endDate, "{y}/{m}/{d}")
                                    }}
                                </template>
                            </el-table-column>
                            <el-table-column label="检查人" align="left" prop="checkNames" />
                            <el-table-column label="状态" align="left">
                                <template slot-scope="scope">
                                    <span v-html="formateStatus(params.taskStatus, scope.row.status)"></span>
                                </template>
                            </el-table-column>
                            <el-table-column label="创建人" align="left" prop="createChnName" />
                            <el-table-column label="创建日期" align="left">
                                <template slot-scope="scope">
                                    {{ parseTime(scope.row.createDate, "{y}/{m}/{d}") }}
                                </template>
                            </el-table-column>
                        </template>
                    </eagle-window-choose>
                </eagle-block>
            </div>
            <!-- </eagle-block> -->
            <div slot="buttons" class="dialog-footer" style="text-align:right;margin-bottom:10px">
                <el-button @click="submitDialog = false">取 消</el-button>
                <el-button type="primary" @click="submitForm">确认选择</el-button>
            </div>
        </div>
    </el-dialog>
</template>
<script>
export default {
    components: {},
    name: "danger-dj-window-task-list",
    data() {
        return {
            selection: [],
            submitDialog: false,
            controller: "danger/jgDangerTask",
            conditions: {
                checkTaskName: { value: "", operate: "like" },
                status: { value: null, operate: "=" },
                checkType: { value: "", operate: "=" },
                sourceType: { value: "", operate: "=" },
                sourceCode: { value: "", operate: "!=" },
            },
            queryParams: {
                dataType: "",
                enterpriseCode: "",
                projectId: "",
            },
            checkType: [],
            params: {
                checkType: [],
                taskStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 10, name: "进行中", color: "#F56C6C" },
                    { id: 25, name: "任务终止", color: "#F56C6C" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    // { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
                sourceType: [
                    { id: "", name: "不限", color: "" },
                    { id: "0", name: "临时检查任务", color: "#F56C6C" },
                    { id: "1", name: "项目检查任务", color: "#F56C6C" },
                ],
            },
        };
    },
    created() {
        this.initParams();
    },
    mounted() {
        // this.search();
    },
    methods: {
        submitForm() {
            let selection = this.$refs.EaglePage.selection;
            if (!selection || selection.length <= 0) {
                this.msgError("请选择检查任务");
                return;
            }
            this.$emit("change", selection);
            this.submitDialog = false;
        },
        show(config) {
            this.submitDialog = true;
            if (config.type == "joinProject") {
                this.conditions.sourceCode.value = config.projectId;
                this.queryParams.dataType = "joinProject";
            } else {
                this.queryParams.dataType = "list";
                this.queryParams.enterpriseCode =
                    this.$route.query.enterpriseCode ?? "";
                this.queryParams.projectId = this.$route.query.projectId ?? "";
            }
            setTimeout(() => {
                this.search();
                this.$refs.EaglePage.selection = [];
            });
        },
        initParams() {
            let _this = this;
            _this.common.getBatechParam(
                ["danger_check_plan_type"],
                function (res) {
                    _this.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType = res.data.filter(
                        (p) => p.paramId === "danger_check_plan_type"
                    );
                    _this.params.checkType.splice(0, 0, {
                        id: "",
                        name: "不限",
                    });
                }
            );
        },
        search() {
            this.$refs.EaglePage.search({ params: this.queryParams });
        },
        //查询条件重置
        resetQuery() {
            this.conditions.checkType.value = "";
            this.conditions.sourceType.value = "";
            this.conditions.checkTaskName.value = "";
            this.conditions.status.value = null;
            this.search();
        },
        handleSelectionChange(selection) {
            console.log("selection", selection);
        },
    },
};
</script>
<style scoped lang="scss">
.danger-dj-window-task-list {
    padding: 10px;
}
</style>