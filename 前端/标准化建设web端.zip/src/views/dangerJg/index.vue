<template>
    <div class="div_danger_container div_webkit_scrollbar app-container">
        <div class="layer">
            <div>
                <eagle-condition style="margin-bottom:10px;" @search="search()" :showReset="false">
                    <eagle-year label-width="50px" label="年度" type="years" @change="search()"
                        v-model="conditions.year" />
                </eagle-condition>
            </div>
            <div class="div_danger_check_data">
                <div class="div_danger_check_left">
                    <el-card style="width:100%;height:480px;">
                        <div slot="header" class="clearfix">
                            排查项目数据 </div>
                        <div>
                            <div class="div_danger_check_static">
                                <template v-for="(item, index) in dataList">
                                    <div v-bind:key="index" class="div_danger_check_static_item">
                                        <!-- <div v-bind:key="index" @click.stop="item_click(item)" :class="item|getItemClass(selectItemCode)"> -->
                                        <el-image style="width: 40px; height: 40px"
                                            :src="item | getItemSrc(selectItemCode)"></el-image>
                                        <span>{{ item.name }}</span>
                                        <span class="span_value">{{ item.value }}</span>
                                    </div>
                                </template>
                            </div>
                            <eagle-page :imageSize="80" :tableHeight="250" :controller="controller" :showOrder="false"
                                :single="false" :showCheckColumn="false" ref="EaglePage" :showBtn="false">
                                <template slot="slot-table">
                                    <el-table-column label="项目单位" prop="enterpriseName" align="left" />
                                    <el-table-column label="项目名称" prop="projectName" align="left" />
                                    <el-table-column label="项目起止日期" width="180px" align="left">
                                        <template slot-scope="scope">
                                            <span>{{ parseTime(scope.row.startDate, '{y}-{m}-{d}') }}</span> ~ <span>{{
                                                    parseTime(scope.row.endDate, '{y}-{m}-{d}')
                                            }}</span>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="项目负责人" width="100px" align="left" prop="mainChnName" />
                                    <el-table-column label="项目参与人" width="180px" align="left" prop="partChnName" />
                                </template>
                            </eagle-page>
                        </div>
                    </el-card>
                </div>
                <div class="div_danger_check_right">
                    <el-card style="height:480px;">
                        <div slot="header" class="clearfix">
                            项目进展情况 </div>
                        <div v-show="chartShow.showProjectProgress">
                            <div id="div_project_progress" style="height:400px"></div>
                        </div>
                        <template v-show="!chartShow.showProjectProgress">
                            <div style="margin-top:25%;">
                                <el-empty :image-size="50"></el-empty>
                            </div>
                        </template>
                    </el-card>
                </div>

            </div>
            <el-card style="margin-bottom:10px">
                <div slot="header" class="clearfix">
                    <div style="float:left"><span>排查任务数据</span></div>
                    <div style="float:right">
                        <el-switch v-model="ownDanger" active-text="只看我的" @change="switchDanger()">
                        </el-switch>
                        <!-- <SPAN>更多</SPAN> -->
                    </div>
                </div>
                <div>
                    <div class="div_header_container">
                        <div class="div_header_card" @click="serchTask(1)">
                            <eagle-head-card title="进行中的排查任务" :value="taskInfo.progressNum"
                                bgColor="linear-gradient(135deg, #fe9494,#ff7676)">
                                <i class="el-icon-s-order"></i>
                            </eagle-head-card>
                        </div>
                        <div class="div_header_card" @click="serchTask(2)">
                            <eagle-head-card title="逾期的排查任务" :value="taskInfo.overNum"
                                bgColor="linear-gradient(135deg, #ffcd50, #f5bf39)">
                                <i class="el-icon-s-order"></i>
                            </eagle-head-card>
                        </div>
                        <div class="div_header_card" @click="serchTask(3)">
                            <eagle-head-card title="待开始的排查任务" :value="taskInfo.notStartNum"
                                bgColor="linear-gradient(135deg, #7ba7ff, #6696f7)">
                                <i class="el-icon-s-order"></i>
                            </eagle-head-card>
                        </div>
                    </div>
                    <div style="height:280px;">
                        <eagle-page :imageSize="40" :tableHeight="260" dataType="statisticsList" style="width: 100%;"
                            :controller="controller" ref="EaglePageDanger" :conditions="conditions"
                            :query-params="queryParams" :showOrder="false" :single="false" :showCheckColumn="false">
                            <template slot="slot-table">
                                <el-table-column label="任务名称" prop="checkTaskName" align="left" />
                                <!-- <el-table-column label="所属项目" width="
                                    100px" align="center" prop="mainChnName" /> -->
                                <el-table-column label="被检查单位" width="230px" align="left" prop="enterpriseName" />
                                <el-table-column label="检查人" width="100px" align="left" prop="checkNames" />

                                <el-table-column label="项目起止日期" width="190px" align="left">
                                    <template slot-scope="scope">
                                        {{ parseTime(scope.row.startDate, "{y}/{m}/{d}") }}- {{
                                                parseTime(scope.row.endDate, "{y}/{m}/{d}")
                                        }}
                                    </template>
                                </el-table-column>
                                <el-table-column label="状态" align="left" width="120px">
                                    <template slot-scope="scope">
                                        <span v-html="formateStatus(params.taskStatus, scope.row.status)"></span>
                                    </template>
                                </el-table-column>
                            </template>
                            <template slot="slot-row-buttons" slot-scope="scope">
                                <eagle-row-button icon="el-icon-view" @click.prevent.stop="goView(scope.row.code)">详情
                                </eagle-row-button>
                            </template>
                        </eagle-page>
                    </div>
                </div>
            </el-card>
            <el-card style="margin-bottom:10px">
                <div slot="header" class="clearfix">
                    复查任务数据<div style="float:right">
                        <el-switch v-model="ownDangerAcceptance" @change="switchAcceptance()" active-text="只看我的">
                        </el-switch>
                        <!-- <SPAN>更多</SPAN> -->
                    </div>
                </div>
                <div>
                    <div class="div_header_container">
                        <eagle-head-card title="待复查的任务" :value="taskInfo.waitCheck"
                            bgColor="linear-gradient(135deg, #7ba7ff, #6696f7)">
                            <i class="el-icon-s-claim"></i>
                        </eagle-head-card>
                    </div>
                    <div style="height:280px;">
                        <eagle-page :imageSize="80" :tableHeight="260" :controller="controllerDanger" :showOrder="false"
                            :single="false" ref="EaglePageDangerAcceptance" :showCheckColumn="false">
                            <template slot="slot-table">
                                <el-table-column label="任务名称" prop="checkTaskName" align="left" />
                                <!-- <el-table-column label="所属项目" width="
                                    100px" align="center" prop="mainChnName" /> -->
                                <el-table-column label="被检查单位" width="230px" align="left" prop="enterpriseName" />
                                <el-table-column label="检查人" width="100px" align="left" prop="checkNames" />

                                <el-table-column label="项目起止日期" width="200px" align="left">
                                    <template slot-scope="scope">
                                        {{ parseTime(scope.row.startDate, "{y}/{m}/{d}") }}- {{
                                                parseTime(scope.row.endDate, "{y}/{m}/{d}")
                                        }}
                                    </template>
                                </el-table-column>
                                <el-table-column label="状态" align="left" width="200px">
                                    <template slot-scope="scope">
                                        <span v-html="formateStatus(params.taskStatus, scope.row.status)"></span>
                                    </template>
                                </el-table-column>
                            </template>
                            <template slot="slot-row-buttons" slot-scope="scope">
                                <eagle-row-button type="primary" v-if="scope.row.status == 30" icon="el-icon-edit"
                                    @click.prevent.stop="goVerifyDetails(scope.row)">复查</eagle-row-button>
                            </template>
                        </eagle-page>
                    </div>
                </div>
            </el-card>
            <el-card style="margin-bottom:10px">
                <div slot="header" class="clearfix">
                    人员项目数量排行<div style="float:right">
                        <el-switch v-model="ownProjectCount" @change="switchProjectCount()" active-text="只看我的">
                        </el-switch>
                        <!-- <SPAN>更多</SPAN> -->
                    </div>
                </div>
                <div>
                    <div v-if="chartShow.showPersonProjectCount"
                        style="height:320px;overflow-y:auto;overflow-x:hidden;">
                        <div id="divChart_person_project_count" style="height:300px"></div>
                    </div>
                    <template v-else>
                        <el-empty :image-size="50"></el-empty>
                    </template>
                </div>
            </el-card>
            <el-card v-show="1 == 2" style="margin-bottom:10px;">
                <div slot="header" class="clearfix">
                    <div style="float:left"><span>人员任务数量排行</span>
                        <el-switch v-model="dataType" active-text="只看逾期项目">
                        </el-switch>
                    </div>
                    <div style="float:right">
                        <el-switch v-model="dataType" active-text="只看我的">
                        </el-switch>
                        <!-- <SPAN>更多</SPAN> -->
                    </div>
                </div>

                <div id="divChart_testScroll" style="height:320px;overflow-y:scroll;overflow-x:hidden;">
                    <div id="divChart_personTaskCount" style="min-height:300px;width:100%;"></div>
                </div>
                <!-- <template v-else>
                <div style="height:320px;">
                    <el-empty :image-size="100"></el-empty>
                </div>
            </template> -->
            </el-card>
            <el-card style="margin-bottom:10px;height:340px;">
                <div slot="header" class="clearfix">
                    <div style="float:left;">
                        <span style="margin-right:10px">人均单次任务隐患发现数量排行榜</span>
                        <el-radio-group v-model="person_danger" size="mini" @change="change_danger()">
                            <el-radio-button label="base">基础管理</el-radio-button>
                            <el-radio-button label="locale">现场管理</el-radio-button>
                        </el-radio-group>
                    </div>
                    <div style="float:right">
                        <!-- <SPAN>更多</SPAN> -->
                    </div>
                </div>
                <div>
                    <div v-if="chartShow.showdangerCount" style="height:320px;overflow-y:auto;overflow-x:hidden;">
                        <div id="divChart_person_danger_count" style="height:300px;width:100%;"></div>
                    </div>
                    <template v-else>
                        <el-empty :image-size="50"></el-empty>
                    </template>
                </div>
            </el-card>
            <el-card style="margin-bottom:10px">
                <div slot="header" class="clearfix">
                    <div style="float:left;"></div>
                    <span style="margin-right:10px">提报隐患类型统计</span>
                    <el-radio-group v-model="danger_type" size="mini" @change="change_dangerType()">
                        <el-radio-button label="base">基础管理</el-radio-button>
                        <el-radio-button label="locale">现场管理</el-radio-button>
                    </el-radio-group>
                    <div style="float:right">
                        <!-- <SPAN>更多</SPAN> -->
                    </div>
                </div>
                <div>
                    <div v-if="chartShow.showDangerType">
                        <div id="divChart_danger_type" style="height:400px"></div>
                    </div>
                    <template v-else>
                        <el-empty :image-size="50"></el-empty>
                    </template>
                </div>
            </el-card>
        </div>
    </div>
</template>

<script>
import * as echarts from "echarts";
import { getCurrentUser } from "@/utils/auth";
export default {
    name: "danger-home-container",
    data() {
        return {
            codeNo: "R00006",
            controller: "site/projectConsultation",
            controllerDanger: "danger/jgDangerTask/",
            dataType: false,
            chartObj: {
                chart_progress: null,
                chart_person_project_count: null,
                chart_personTaskCount: null,
                chart_personDangerCount: null,
                chart_personDangerType: null,
            },
            chartShow: {
                showProjectProgress: false,
                showPersonTask: false,
                showDangerType: false,
                showdangerCount: false,
                showPersonProjectCount: false,
            },
            dataList: [
                {
                    code: "monthAdd",
                    name: "本月新增",
                    value: 0,
                    imgSrc: require("@/assets/images/danger/monthAdd.png"),
                    imgSrc_white: require("@/assets/images/danger/monthAdd_white.png"),
                },
                {
                    code: "yearAdd",
                    name: "本年度新增",
                    value: 0,
                    imgSrc: require("@/assets/images/danger/yearAdd.png"),
                    imgSrc_white: require("@/assets/images/danger/yearAdd.png"),
                },
                {
                    code: "progress",
                    name: "进行中",
                    value: 0,
                    imgSrc: require("@/assets/images/danger/progress.png"),
                    imgSrc_white: require("@/assets/images/danger/progress_white.png"),
                },
                {
                    code: "over",
                    name: "逾期",
                    value: 0,
                    imgSrc: require("@/assets/images/danger/overDate.png"),
                    imgSrc_white: require("@/assets/images/danger/overDate_white.png"),
                },
                {
                    code: "monthOver",
                    name: "本月结案",
                    value: 0,
                    imgSrc: require("@/assets/images/danger/monthOver.png"),
                    imgSrc_white: require("@/assets/images/danger/monthOver_white.png"),
                },
                {
                    code: "yearOver",
                    name: "年度累计结案",
                    value: 0,
                    imgSrc: require("@/assets/images/danger/yearOver.png"),
                    imgSrc_white: require("@/assets/images/danger/yearOver_white.png"),
                },
                // ,
                // {
                //     code: "noStart",
                //     name: "未安排",
                //     value: 0,
                //     imgSrc: require("@/assets/images/danger/noStart.png"),
                //     imgSrc_white: require("@/assets/images/danger/noStart_white.png")
                // }
            ],
            pageForm: {},
            conditions: { year: new Date().getFullYear() },
            selectItemCode: "monthAdd",
            taskInfo: {},
            person_danger: "base", //人均单次任务隐患发现数量排行榜类型（）
            danger_type: "base",
            person_danger_list: {
                localList: [],
                baseList: [],
                yAxis: [],
            },
            danger_type_list: {
                localList: [],
                baseList: [],
                seriesList: [],
                legendLocal: [],
                legendBase: [],
            },
            queryParams: { dataType: "list" },
            params: {
                taskStatus: [
                    { id: null, name: "不限", color: "" },
                    { id: 10, name: "进行中", color: "#F56C6C" },
                    // { id: 25, name: "任务终止", color: "#F56C6C" },
                    { id: 30, name: "待复查", color: "#F56C6C" },
                    { id: 80, name: "无需复查", color: "#67C23A" },
                    { id: 100, name: "已结束", color: "#67C23A" },
                ],
            },
            ownDanger: false,
            ownDangerAcceptance: false,
            ownProjectCount: false,
            statisticsStatus: "1",
            maxValue: 0,
        };
    },
    filters: {
        getItemClass: function (item, selectItemCode) {
            if (item.code == selectItemCode) {
                return "div_danger_check_static_item div_is_selected";
            } else {
                return "div_danger_check_static_item";
            }
        },
        getItemSrc(item, selectItemCode) {
            return item.imgSrc;
            // if (item.code == selectItemCode) {
            //     return item.imgSrc_white;
            // } else {
            //     return item.imgSrc;
            // }
        },
    },
    created() { },
    mounted() {
        //this.initPersonProjectCount();
        // this.initPersonTaskCount();
        //this.initPersonDangerCount();
        //this.initPersonDangerType();
        this.search();
    },
    methods: {
        initProjectProgress() {
            var _this = this;
            var option = {
                tooltip: {
                    trigger: "item",
                },
                legend: {
                    orient: "horizontal",
                    bottom: "3px",
                    left: "10px",
                },
                color: ["#71D4D4", "#C3B6E6", "#A3D2F6", "#E1BF66"],
                series: [
                    {
                        name: "项目进展情况",
                        type: "pie",
                        radius: "50%",
                        data: [
                            // { value: _this.dataList[6].value, name: "未安排" },
                            {
                                value: _this.dataList[3].value,
                                name: "进行中(逾期)",
                            },
                            { value: _this.dataList[2].value, name: "进行中" },
                            { value: _this.dataList[5].value, name: "已结案" },
                        ],
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: "rgba(0, 0, 0, 0.5)",
                            },
                        },
                    },
                ],
            };
            setTimeout(() => {
                this.chartObj.chart_progress = echarts.init(
                    document.getElementById("div_project_progress")
                );
                this.chartObj.chart_progress.setOption(option);
            }, 50);
        },
        initPersonProjectCount(personList, overList, notOverList) {
            let option = {
                color: ["#6CBDF8", "#F2A333"],
                tooltip: {
                    trigger: "axis",
                    axisPointer: {
                        type: "shadow",
                    },
                },
                xAxis: {
                    type: "category",
                    data: personList,
                },
                yAxis: {
                    type: "value",
                    minInterval: 1,
                },
                grid: {
                    left: "50px",
                    right: "10px",
                },
                series: [
                    {
                        label: {
                            show: true,
                        },
                        name: "未逾期项目",
                        type: "bar",
                        stack: "total",

                        barWidth: "40px",
                        data: notOverList,
                    },
                    {
                        name: "逾期项目",
                        type: "bar",
                        stack: "total",
                        label: {
                            show: true,
                        },
                        data: overList,
                        barWidth: "40px",
                    },
                ],
            };
            setTimeout(() => {
                this.chartObj.chart_person_project_count = echarts.init(
                    document.getElementById("divChart_person_project_count")
                );
                this.chartObj.chart_person_project_count.setOption(option);
            }, 10);
        },
        //人均单次任务隐患发现数量排行
        initPersonTaskCount() {
            let option = {
                color: ["#6CBDF8", "#A7AAAE"],
                title: {
                    text: "项目人员分析图",
                    textStyle: {
                        fontSize: 14,
                        fontFamily: "Microsoft YaHei",
                    },
                },

                tooltip: {
                    trigger: "axis",
                    axisPointer: {
                        type: "shadow",
                    },
                },
                xAxis: { type: "value" },
                yAxis: {
                    data: [
                        "田磊",
                        "谢勤",
                        "魏中雨",
                        "张明泽",
                        "吴海林",
                        "贺聪",
                        "高坚毅",
                        "张明泽",
                        "徐昊",
                        "钱程",
                    ],
                },
                series: [
                    {
                        name: "未逾期项目",
                        type: "bar",
                        stack: "total",
                        label: {
                            show: true,
                        },
                        barWidth: "30px",
                        barGap: "0%",
                        data: [11, 33, 75, 96, 88, 111, 133, 175, 196, 188],
                    },
                    {
                        name: "逾期项目",
                        type: "bar",
                        stack: "total",
                        label: {
                            show: true,
                        },
                        barWidth: "30px",
                        barGap: "0%",
                        data: [16, 3, 7, 9, 8, 11, 13, 17, 19, 18],
                    },
                ],
            };

            var height = option.yAxis.data.length * 50 + 120;

            var divElement = document.getElementById(
                "divChart_personTaskCount"
            );
            if (divElement) {
                divElement.setAttribute("style", "height:" + height + "px;");
            }
            this.chartObj.chart_personTaskCount = echarts.init(
                document.getElementById("divChart_personTaskCount")
            );
            this.chartObj.chart_personTaskCount.setOption(option);
        },
        initPersonDangerCount() {
            var _this = this;
            let option = {
                color: ["#6CBDF8"],
                legend: {
                    orient: "horizontal",
                    bottom: "3px",
                    left: "10px",
                },
                tooltip: {
                    trigger: "axis",
                    axisPointer: {
                        type: "shadow",
                    },
                },
                xAxis: { type: "value" },
                yAxis: {
                    data: [],
                },
                series: [
                    {
                        name: "", //"现场管理类隐患",
                        type: "bar",
                        stack: "total",
                        label: {
                            show: true,
                        },
                        barWidth: "30px",
                        barGap: "0%",
                        data: [], //[11, 33, 75, 88, 96, 111, 133, 175, 178, 188],
                        markLine: {
                            data: [{ type: "average", name: "Avg" }],
                        },
                    },
                ],
            };

            var height = option.yAxis.data.length * 50 + 100;
            setTimeout(() => {
                var divElement = document.getElementById(
                    "divChart_person_danger_count"
                );
                height = height > 300 ? height : 300;
                divElement.setAttribute("style", "height:" + height + "px;");
                this.chartObj.chart_personDangerCount = echarts.init(
                    document.getElementById("divChart_person_danger_count")
                );

                option.yAxis.data = _this.person_danger_list.yAxis;
                if (_this.person_danger == "base") {
                    option.series[0].name = "基础管理类隐患";
                    option.series[0].data = _this.person_danger_list.baseList;
                } else {
                    option.series[0].name = "现场管理类隐患";
                    option.series[0].data = _this.person_danger_list.localList;
                }
                this.chartObj.chart_personDangerCount.setOption(option, true);
            }, 100);
        },
        initPersonDangerType() {
            var _this = this;

            var data = [];
            var legendList = [];
            if (_this.danger_type == "base") {
                data = _this.danger_type_list.baseList;
                legendList = _this.danger_type_list.legendBase;
            } else {
                data = _this.danger_type_list.localList;
                legendList = _this.danger_type_list.legendLocal;
            }

            var option = {
                legend: {
                    show: true,
                    left: 10,
                    top: 10,
                },
                xAxis: {
                    show: false,
                    minInterval: 1,
                    max: _this.maxValue + 10,
                },
                yAxis: {
                    show: false,
                    minInterval: 1,
                },
                tooltip: {
                    formatter: function (params) {
                        return params.seriesName + "：" + params.data[0];
                    },
                },
                series: [],
            };
            var series = [];

            var forList = _this.danger_type_list.seriesList.filter(
                (item) => item.type == _this.danger_type
            );

            for (var i = 0; i < forList.length; i++) {
                var model = forList[i];

                series.push({
                    name: model.type_name,
                    data: data[i],
                    type: "scatter",
                    symbolSize: function (data) {
                        //return data[0];
                        var size = data[0] < 30 ? 30 : data[0];
                        return size > 200 ? 200 : size < 20 ? size * 10 : size;
                    },
                    label: {
                        show: true,
                        color: "#FFF",
                        fontSize: 14,
                        formatter: function (param) {
                            var html = param.data[0];
                            return html;
                        },
                        align: "center",
                        rich: {},
                    },
                });
            }
            option.series = series;
            option.legend.data = legendList;
            setTimeout(() => {
                this.chartObj.chart_personDangerType = echarts.init(
                    document.getElementById("divChart_danger_type")
                );
                this.chartObj.chart_personDangerType.setOption(option, true);
            }, 100);
        },
        getChnName(code) {
            var html = "";
            switch (code) {
                case 1:
                    html = "消防安全";
                    break;
                case 2:
                    html = "设备设施";
                    break;
                case 3:
                    html = "涉爆粉尘";
                    break;
                case 4:
                    html = "有限空间";
                    break;
                default:
                    html = "其他";
                    break;
            }
            return html;
        },
        search() {
            var _this = this;

            var currentUser = getCurrentUser();
            var isAdmin = currentUser.manager ? 1 : 0;
            var conditionsList = [];
            var queryParams = {
                codeNo: _this.codeNo,
                year: _this.conditions.year,
                isAdmin: isAdmin,
            };
            if (_this.ownDanger) {
                queryParams.isonlyme1 = 1;
                queryParams.isAdmin = 0;
            }
            if (_this.ownDangerAcceptance) {
                queryParams.isonlyme2 = 1;
                queryParams.isAdmin = 0;
            }
            if (_this.ownProjectCount) {
                queryParams.isonlyme3 = 1;
                queryParams.isAdmin = 0;
            }
            conditionsList.push(queryParams);

            var url = "/site/commonReportForms/getMainPageInfo";
            _this.http
                .get(url, { conditions: JSON.stringify(conditionsList) })
                .then((result) => {
                    var res = result.data;
                    if (res) {
                        var M2 = res.M2;
                        if (M2.length > 0 && M2.length > 0 && M2[0] != null) {
                            _this.chartShow.showProjectProgress = true;
                            _this.dataList[0].value = M2[0].addMNum; //本月新增
                            _this.dataList[1].value = M2[0].addYNum; //本年度新增
                            _this.dataList[2].value = M2[0].progressNum; //进行中
                            _this.dataList[3].value = M2[0].overNum; //逾期
                            _this.dataList[4].value = M2[0].colseMNum; //本月结案
                            _this.dataList[5].value = M2[0].colseYNum; //年度累计结案
                            // _this.dataList[6].value = M2[0].notArrangeNum; //未开始
                            this.initProjectProgress();
                        } else {
                            _this.chartShow.showProjectProgress = false;
                            _this.dataList[0].value = 0; //本月新增
                            _this.dataList[1].value = 0; //本年度新增
                            _this.dataList[2].value = 0; //进行中
                            _this.dataList[3].value = 0; //逾期
                            _this.dataList[4].value = 0; //本月结案
                            _this.dataList[5].value = 0; //年度累计结案
                            //_this.dataList[6].value = 0; //未开始
                        }
                        _this.taskInfo = res.M3[0]; //排查任务数据、验收任务数据(统计汇总)

                        var M4List = res.M4; //人员项目数量排行
                        _this.initM4(M4List);

                        var personListTemp = res.M6; //人均单次任务隐患发现数量排行

                        _this.person_danger_list.yAxis = [];
                        _this.person_danger_list.localList = [];
                        _this.person_danger_list.baseList = [];
                        _this.chartShow.showdangerCount = false;

                        if (personListTemp && personListTemp.length > 0) {
                            _this.chartShow.showdangerCount = true;
                            for (var i = 0; i < personListTemp.length; i++) {
                                _this.person_danger_list.yAxis.push(
                                    personListTemp[i].user_name
                                );
                                if (personListTemp[i].localeaverage) {
                                    _this.person_danger_list.localList.push(
                                        personListTemp[i].localeaverage
                                    );
                                } else {
                                    _this.person_danger_list.localList.push(0);
                                }
                                if (personListTemp[i].baseaverage) {
                                    _this.person_danger_list.baseList.push(
                                        personListTemp[i].baseaverage
                                    );
                                } else {
                                    _this.person_danger_list.baseList.push(0);
                                }
                            }
                            this.initPersonDangerCount();
                        }
                        var templateList = res.M7;
                        var danger_typeList = [];
                        var dataList = [];

                        var dataList = [];
                        _this.danger_type_list.localList = [];
                        _this.danger_type_list.legendLocal = [];
                        _this.danger_type_list.baseList = [];
                        _this.danger_type_list.legendBase = [];
                        _this.chartShow.showDangerType = false;

                        if (templateList && templateList.length > 0) {
                            _this.chartShow.showDangerType = true;
                            for (var i = 0; i < templateList.length; i++) {
                                if (templateList[i].localeNum) {
                                    if (
                                        templateList[i].localeNum >
                                        _this.maxValue
                                    ) {
                                        _this.maxValue =
                                            templateList[i].localeNum;
                                    }
                                    _this.danger_type_list.localList.push([
                                        [templateList[i].localeNum, i + 1],
                                    ]);
                                    _this.danger_type_list.legendLocal.push(
                                        templateList[i].type_name
                                    );
                                    _this.$set(
                                        templateList[i],
                                        "type",
                                        "locale"
                                    );
                                    _this.danger_type_list.seriesList.push(
                                        templateList[i]
                                    );
                                }
                                if (templateList[i].baseNum) {
                                    if (
                                        templateList[i].baseNum > _this.maxValue
                                    ) {
                                        _this.maxValue =
                                            templateList[i].baseNum;
                                    }
                                    _this.danger_type_list.baseList.push([
                                        [templateList[i].baseNum, i + 1],
                                    ]);
                                    _this.danger_type_list.legendBase.push(
                                        templateList[i].type_name
                                    );
                                    _this.$set(templateList[i], "type", "base");
                                    _this.danger_type_list.seriesList.push(
                                        templateList[i]
                                    );
                                }
                            }
                            // this.danger_type_list.seriesList = templateList;
                            _this.initPersonDangerType();
                        }
                        _this.resizeCharts();
                    }
                });

            _this.$refs.EaglePage.search({
                params: { modulesId: "dangerJg", dataType: "list" },
                url: "site/projectConsultation/getPageData",
                conditions: JSON.stringify([
                    {
                        name: "arrangeDate",
                        operate: "like",
                        value: _this.conditions.year,
                    },
                    { name: "status", operate: "like", value: "0" },
                ]),
            });
            _this.serchTask(1);
            _this.searchAcceptancePage();
        },
        initM4(M4List) {
            var _this = this;
            var personList = [];
            var overList = []; //逾期项目
            var notOverList = []; //未逾期项目
            _this.chartShow.showPersonProjectCount = false;
            if (M4List != null && M4List.length > 0) {
                _this.chartShow.showPersonProjectCount = true;
                for (var i = 0; i < M4List.length; i++) {
                    personList.push(M4List[i].user_name);
                    overList.push(M4List[i].overdue);
                    notOverList.push(M4List[i].notoverdue);
                }
                _this.initPersonProjectCount(personList, overList, notOverList);
            }
        },
        serchTask(action) {
            var _this = this;
            if (action) {
                _this.statisticsStatus = action;
            }
            var own = 2;
            if (_this.ownDanger) {
                own = 1;
            }
            this.$refs.EaglePageDanger.search({
                params: { dataType: "statisticsList" },
                url: "danger/jgDangerTask/getPageData",
                conditions: JSON.stringify([
                    {
                        name: "statisticsStatus",
                        operate: "like",
                        value: action,
                    },
                    {
                        name: "year",
                        operate: "=",
                        value: _this.conditions.year,
                    },
                    { name: "own", operate: "=", value: own },
                ]),
            });
        },
        searchAcceptancePage() {
            var _this = this;
            var own = 2;
            if (_this.ownDangerAcceptance) {
                own = 1;
            }
            this.$refs.EaglePageDangerAcceptance.search({
                params: { dataType: "statisticsList" },
                url: "danger/jgDangerTask/getPageData",
                conditions: JSON.stringify([
                    {
                        name: "statisticsStatus",
                        operate: "like",
                        value: 4,
                    },
                    {
                        name: "year",
                        operate: "=",
                        value: _this.conditions.year,
                    },
                    { name: "own", operate: "=", value: own },
                ]),
            });
        },
        search_statistics(isonlyme, type, isAdmin) {
            var _this = this;
            var conditionsList = [];
            var queryParams = {
                codeNo: _this.codeNo,
                year: _this.conditions.year,
                isAdmin: isAdmin,
            };

            if (type == "danger") {
                queryParams.isonlyme1 = isonlyme;
            } else if (type == "dangerAcceptance") {
                queryParams.isonlyme2 = isonlyme;
            } else if (type == "projectCount") {
                queryParams.isonlyme3 = isonlyme;
            }
            conditionsList.push(queryParams);
            var url = "/site/commonReportForms/getMainPageInfo";

            _this.http
                .get(url, { conditions: JSON.stringify(conditionsList) })
                .then((result) => {
                    var res = result.data;
                    var M3 = res.M3[0];
                    if (M3) {
                        if (type == "danger") {
                            _this.taskInfo.progressNum = M3.progressNum;
                            _this.taskInfo.overNum = M3.overNum;
                            _this.taskInfo.notStartNum = M3.notStartNum;
                        } else if (type == "dangerAcceptance") {
                            _this.taskInfo.waitCheck = M3.waitCheck;
                        }
                    }
                    if (type == "projectCount") {
                        var M4List = res.M4;
                        _this.initM4(M4List);
                    }
                });
        },
        item_click(item) {
            //统计汇总点击按钮切换事件
            this.selectItemCode = item.code;
        },
        change_danger() {
            this.initPersonDangerCount();
        },
        change_dangerType() {
            if (
                this.danger_type_list.seriesList &&
                this.danger_type_list.seriesList.length > 0
            ) {
                this.initPersonDangerType();
            }
        },
        resizeCharts() {
            var _this = this;
            setTimeout(function () {
                window.onresize = function () {
                    if (_this.chartObj.chart_progress != null) {
                        _this.chartObj.chart_progress.resize();
                    }
                    if (_this.chartObj.chart_person_project_count != null) {
                        _this.chartObj.chart_person_project_count.resize();
                    }
                    if (_this.chartObj.chart_personTaskCount != null) {
                        _this.chartObj.chart_personTaskCount.resize();
                    }
                    if (_this.chartObj.chart_personDangerCount != null) {
                        _this.chartObj.chart_personDangerCount.resize();
                    }
                    if (_this.chartObj.chart_personDangerType != null) {
                        _this.chartObj.chart_personDangerType.resize();
                    }
                };
            }, 200);
        },
        switchDanger() {
            this.serchTask(this.statisticsStatus);

            var isonlyme1 = 2;
            var isAdmin = 0;

            if (this.ownDanger) {
                isonlyme1 = 1;
            } else {
                var currentUser = getCurrentUser();
                isAdmin = currentUser.manager ? 1 : 0;
            }
            this.search_statistics(isonlyme1, "danger", isAdmin);
        },
        switchAcceptance() {
            this.searchAcceptancePage();
            var isAdmin = 0;

            var isonlyme2 = 2;
            if (this.ownDangerAcceptance) {
                isonlyme2 = 1;
            } else {
                var currentUser = getCurrentUser();
                isAdmin = currentUser.manager ? 1 : 0;
            }
            this.search_statistics(isonlyme2, "dangerAcceptance", isAdmin);
        },
        switchProjectCount() {
            var isAdmin = 0;
            var isonlyme3 = 2;
            if (this.ownProjectCount) {
                isonlyme3 = 1;
            } else {
                var currentUser = getCurrentUser();
                isAdmin = currentUser.manager ? 1 : 0;
            }
            this.search_statistics(isonlyme3, "projectCount", isAdmin);
        },
        goView(code) {
            this.$router.push({
                name: "DangerJgTaskViewUs",
                query: {
                    code: code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                    st: 4,
                },
            });
        },
        goVerifyDetails(row) {
            this.$router.push({
                name: "DangerJgVerifyTaskViewUs",
                query: {
                    code: row.code,
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                    st: 4,
                },
            });
            const { href } = this.$router.resolve({ path: path });
            window.open(href, "_blank");
        },
    },
};
</script>
<style lang="scss"  scoped>
.div_danger_container {


    .div_header_container {
        display: flex;
        flex-direction: row;
        gap: 10px;

        .div_header_card {
            display: block;
            cursor: pointer;
        }
    }

    .div_danger_check_data {
        display: flex;
        flex-direction: row;
        margin-bottom: 10px;
        flex: 1;

        .div_danger_check_left {
            display: flex;
            flex: 1;
            margin-right: 10px;
            width: calc(100% - 410px);

            .div_danger_check_static {
                display: flex;
                flex-direction: row;

                flex-wrap: wrap;
                cursor: pointer;

                .div_danger_check_static_item {
                    margin-right: 10px;
                    margin-bottom: 5px;
                    display: flex;
                    flex-direction: column;
                    border: 1px solid #e6ebf5;
                    border-radius: 5px;
                    padding: 10px 10px;
                    width: 110px;
                    align-items: center;

                    span {
                        line-height: 32px;
                        color: #303133;
                    }

                    .span_value {
                        font-size: 24px;
                        font-weight: bold;
                        color: #8d97a7;
                    }
                }

                .div_is_selected {
                    span {
                        line-height: 32px;
                        color: white;
                    }

                    .span_value {
                        font-size: 24px;
                        font-weight: bold;
                        color: white;
                    }

                    background-color: #85cff4;
                }
            }
        }

        .div_danger_check_right {
            width: 400px;
        }
    }
}
</style>