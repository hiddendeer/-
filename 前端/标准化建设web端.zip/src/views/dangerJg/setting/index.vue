<template name="danger-jg-setting">
    <div class="danger-jg-setting">
        <el-form :form="model" ref="form">
            <eagle-block class="box-card">
                <div slot="header" class="clearfix">
                    <span>通用设置</span>
                </div>
                <div>
                    <el-form-item label-width="150px" label="项目检查表">
                        <el-button size="mini" @click="handleChooseLibTemplateShow">选择检查表</el-button>
                        <div>
                            <div class="temp-block" v-for="(item, index) in templates" :key="index">
                                <div class="temp-title single-line">{{ index + 1 }}-{{ item.name }}</div>
                                <div class="temp-button">
                                    <eagle-row-button type="primary" @click.prevent.stop="hdShowTemplate(item)">详情
                                    </eagle-row-button>
                                    <eagle-row-button type="danger" @click.prevent.stop="hdRemoveTemp(index)">删除
                                    </eagle-row-button>
                                </div>

                            </div>
                        </div>
                        <!-- <div class="template-list" v-for="(item,index) in templates" :key="index">
                            <el-link type="primary" :key="index" style="margin-right:10px" @click="hdShowTemplate(item)">{{item.name}}</el-link>
                            <i class="el-icon-delete" @click="hdRemoveTemp(index)"></i>
                        </div> -->
                    </el-form-item>
                    <el-form-item label-width="150px" label="">
                        <el-switch active-color="#13ce66" v-model="model.verifyDanger" />
                        <span>是否需要隐患整改复查</span>
                    </el-form-item>
                    <eagle-input label-width="150px" type="textarea" @changeEnter="search()" label="检查要求" prop="checkRequire" v-model="model.checkRequire" placeholder="请输入检查要求;设置好后新增任务时候带出来，可以修改" clearable size="small" />
                </div>
            </eagle-block>
            <eagle-block class="box-card mt10">
                <div slot="header" class="clearfix">
                    <span>隐患排查报告模板设置</span>
                </div>
                <div>
                    <eagle-select label="隐患排查报告模板" label-width="200px" :dataSource="reportTemp1" v-model="model.checkReportTemplateCode" prop="checkReportTemplateCode" @change="changeReportSource1"></eagle-select>
                    <eagle-select label="隐患整改报告模板-按任务" label-width="200px" :dataSource="reportTemp2" v-model="model.acceptReportTemplateCode" prop="acceptReportTemplateCode" @change="changeReportSource2"></eagle-select>
                    <eagle-select label="隐患整改报告模板-按单位" label-width="200px" :dataSource="reportTemp3" v-model="model.enterpriseAcceptReportTemplateCode" prop="enterpriseAcceptReportTemplateCode" @change="changeReportSource3"></eagle-select>
                </div>
                <div style="width: 780px;text-align: center;margin-top: 10px;">
                    <el-button type="primary" @click="submit">保存</el-button>
                </div>
            </eagle-block>
        </el-form>

        <dangerTemplateDetail ref="dangerTemplateDetail" />
        <choose-lib-template ref="chooseLibTemplate" @change="handleChooseLibTemplate" />
    </div>
</template>

<script>
import chooseLibTemplate from "@/views/support/public/chooseLibTemplate";
import dangerTemplateDetail from "@/views/support/TplOp/window/dangerTemplateDetail.vue";
import eagleChooseUser from "../../../components/Eagle/chooseUser/eagle-choose-user.vue";
import EagleInput from "../../../components/Eagle/eagle-input.vue";
import EagleSelect from "../../../components/Eagle/eagle-select.vue";
export default {
    components: {
        eagleChooseUser,
        dangerTemplateDetail,
        chooseLibTemplate,
        EagleInput,
        EagleSelect,
    },
    name: "danger-jg-setting",
    props: {},
    data() {
        return {
            controller: "danger/dangerSettingJg",
            model: {},
            mainCode: "",
            params: {},
            projectId: "",
            enterpriseCode: "",
            templates: [],
            reportTemp1: [],
            reportTemp2: [],
            reportTemp3: [],
            //             acceptReportTemplateCode: ""
            // acceptReportTemplateName: ""
            // checkReportTemplateCode: ""
            // checkReportTemplateName: ""
        };
    },
    created() {
        this.initData();
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";
        this.getSetting();
    },
    methods: {
        changeReportSource1() {
            this.model.checkReportTemplateName = this.formateDict(
                this.reportTemp1,
                this.model.checkReportTemplateCode
            );
        },
        changeReportSource2() {
            this.model.acceptReportTemplateName = this.formateDict(
                this.reportTemp2,
                this.model.acceptReportTemplateCode
            );
        },
        changeReportSource3() {
            this.model.enterpriseAcceptReportTemplateName = this.formateDict(
                this.reportTemp3,
                this.model.enterpriseAcceptReportTemplateCode
            );
        },

        hdRemoveTemp(index) {
            console.log(index);

            this.templates.splice(index, 1);
        },
        handleChooseLibTemplate(array) {
            let _this = this;
            _this.templates = [];
            if (array && array.length > 0) {
                array.forEach((x) => {
                    _this.templates.push({
                        code: x.tCode,
                        name: x.title,
                    });
                });
            }
        },
        handleChooseLibTemplateShow() {
            this.$refs.chooseLibTemplate.show();
        },
        hdShowTemplate(item) {
            this.$refs.dangerTemplateDetail.show({ tCode: item.code });
        },
        submit() {
            let _this = this;
            let url = `${_this.controller}/submitSet`;
            _this.model.dangerCheckTemplateCodes = "";
            _this.model.dangerCheckTemplateNames = "";
            if (_this.templates && _this.templates.length > 0) {
                _this.templates.forEach((item) => {
                    _this.model.dangerCheckTemplateCodes = !_this.model
                        .dangerCheckTemplateCodes
                        ? item.code
                        : `${_this.model.dangerCheckTemplateCodes},${item.code}`;
                    _this.model.dangerCheckTemplateNames = !_this.model
                        .dangerCheckTemplateNames
                        ? item.name
                        : `${_this.model.dangerCheckTemplateNames},${item.name}`;
                });
            }
            _this.http.postLoading(
                _this.loading(),
                url,
                _this.model,
                function (res) {
                    _this.msgSuccess("设置成功");
                    // _this.getSetting();
                }
            );

            // _this.http.post(url, _this.model).then(res => {
            //     if (res.code == 200) {
            //         _this.msgSuccess("设置成功");
            //         _this.getSetting();
            //     }
            //     else {
            //         _this.msgError("系统异常");
            //     }
            // })
        },
        getSetting() {
            let _this = this;
            let url = `${_this.controller}/getSetting/${_this.enterpriseCode}/${_this.projectId}`;
            _this.http.get(url).then((res) => {
                _this.model = res.data;
                _this.templates = [];
                if (_this.model.dangerCheckTemplateCodes) {
                    let codes = _this.model.dangerCheckTemplateCodes.split(",");
                    let names = _this.model.dangerCheckTemplateNames.split(",");
                    for (let i = 0; i < codes.length; i++) {
                        _this.templates.push({
                            code: codes[i],
                            name: names[i],
                        });
                    }
                }

                console.log("templates=>", _this.templates);
            });
        },
        initData() {
            let _this = this;
            _this.common.getBatechParam(
                [_this.constParams.hidden_danger_type],
                function (res) {
                    _this.params.dangerType = res.data.filter(
                        (p) =>
                            p.paramId === _this.constParams.hidden_danger_type
                    );
                }
            );

            let url = `site/fileToolDataSource/getMap?reportType=DangerJgCheckReport`;

            _this.http.get(url).then((res) => {
                _this.reportTemp1 = res.data;
            });
            let url2 = `site/fileToolDataSource/getMap?reportType=DangerJgVerifyReportByTask`;
            _this.http.get(url2).then((res) => {
                _this.reportTemp2 = res.data;
            });

            let url3 = `site/fileToolDataSource/getMap?reportType=DangerJgVerifyReporyByEnterprise`;
            _this.http.get(url3).then((res) => {
                _this.reportTemp3 = res.data;
            });
        },
    },
};
</script>
<style scoped lang="scss">
.danger-jg-setting {
    //padding: 10px;
}

.box-card {
    // margin-left: 10px;
    max-width: 1000px;
}

.tempList {
    display: flex;

    .el-tag {
        margin-right: 10px;
        cursor: pointer;
    }
}

.template-list {
    line-height: 28px;

    .el-icon-delete {
        color: red;
        cursor: pointer;
    }
}

.temp-block {
    background-color: #f4f9ff;
    width: 300px;
    padding: 5px 10px;
    display: inline-block;
    margin-right: 10px;
    margin-bottom: 10px;
    border: 1px solid #e1f3d8;

    .temp-title {
        font-size: 15px;
        width: 245px;
        color: #303133;
        line-height: 28px;
    }

    .temp-button {
        text-align: right;
    }
}
</style>