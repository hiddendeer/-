import Vue from "vue";

Vue.prototype.msgSuccess = function ( msg ) {
  this.$message({
    showClose: true,
    message: msg,
    type: "success"
  });
}

Vue.prototype.loading = function () {
  return this.$loading({
    lock: true,
    text: "Loading",
    spinner: "el-icon-loading",
    background: "rgba(0, 0, 0, 0.7)",
  });
}

Vue.prototype.msgError = function ( msg ) {
  this.$message({
    showClose: true,
    message: msg,
    type: "error"
  });
}

Vue.prototype.msgInfo = function ( msg ) {
  this.$message.info(msg);
}
