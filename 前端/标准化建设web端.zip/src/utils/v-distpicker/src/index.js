import VDistpicker from './Distpicker'

export default VDistpicker
