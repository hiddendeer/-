export const formatDate = function (value, args) {
  if (value) {
    value = value.replace(/-/g, "/");
    var dt = new Date(value);
    var y = dt.getFullYear();
    var m = dt.getMonth() + 1;
    var d = dt.getDate();
    return `${y}-${m}-${d}`;
  }
}

export const dataFormat = function (value, args) {
  if (value) {
    value = value.replace(/-/g, "/");
    var dt = new Date(value);
    var y = dt.getFullYear();
    var m = dt.getMonth() + 1;
    var d = dt.getDate();
    return `${y}-${m}-${d}`;
  }
}


export const formatDateTime = function (value, args) {
  if (value) {
    value = value.replace(/-/g, "/");
    var dt = new Date(value);
    const y = dt.getFullYear()
    const m = (dt.getMonth() + 1 + '').padStart(2, '0')
    const d = (dt.getDate() + '').padStart(2, '0')
    const hh = (dt.getHours() + '').padStart(2, '0')
    const mm = (dt.getMinutes() + '').padStart(2, '0')
    return `${y}-${m}-${d} ${hh}:${mm}`;
  }
}

export const formatMinute = function (value, args) {
  if (value) {
    value = value.replace(/-/g, "/");
    var dt = new Date(value);
    const hh = (dt.getHours() + '').padStart(2, '0')
    const mm = (dt.getMinutes() + '').padStart(2, '0')
    return `${hh}:${mm}`;
  }
}
export const boolFormat = function (value) {
  if (value == "1") {
    return "是";
  } else {
    return "否";
  }
}

export const nullFormat = function (value) {
  if (value) {
    return value;
  } else {
    return "--"
  }
}

export const getDateDiffs = function (days) {
  var tag = "";
  if (days > 0) {
    tag = "剩";
  }
  if (days < 0) {
    days = -days;
  }
  var yearLevelValue = 365;
  var monthLevelValue = 31;
  var year = parseInt((parseInt(days)) / yearLevelValue);
  var month = parseInt((days - year * yearLevelValue) / monthLevelValue);
  var day = parseInt(days - year * yearLevelValue - month * monthLevelValue);
  var result = "";
  if (year != 0) result = result + year + "年";
  if (month != 0) result = result + month + "月";
  if (day != 0)
    result = result + day + "天";
  return tag + result;
}


export function paramsFormat(val, list) {
  if (val || val === 0) {
    if (list != undefined && list.length > 0) {
      for (let i = 0; i < list.length; i++) {
        if (val == list[i].id) {
          val = list[i].name;
        }
      }
    }
    var type = typeof (val);
    if (type == "string") {
      val = val.replace("Custom-", "").replace("Custom", "");
    }
    return val;
  }
  return "";
}


//金额格式化
export function moneyFormat(number, decimals, dec_point, thousands_sep) {
  /*
   * 参数说明：
   * number：要格式化的数字
   * decimals：保留几位小数
   * dec_point：小数点符号
   * thousands_sep：千分位符号
   * */
  try {
    if (number) {
      number = (number + '').replace(/[^0-9+-Ee.]/g, '');
      var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 2 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
          var k = Math.pow(10, prec);
          return '' + Math.ceil(n * k) / k;
        };

      s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
      var re = /(-?\d+)(\d{3})/;
      while (re.test(s[0])) {
        s[0] = s[0].replace(re, "$1" + sep + "$2");
      }

      if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
      }
      return s.join(dec);
    } else {
      return "--";
    }
  } catch (e) {
    if (typeof console !== 'undefined')
      console.log(e, webOut);
    return number;
  }
}
