//仅可输入汉字、字母、数字
export function inputFiltration1(e) {
    let regex = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;
    if (!regex.test(e)) {
        return e.replace(
            /[^a-zA-Z0-9\u4e00-\u9fa5]/g,
            ""
        );
    } else {
        return e
    }
}
//仅可输入数字
export function inputFiltration2(e) {
    let regex = /^[0-9]+$/;
    if (!regex.test(e)) {
        return e.replace(
            /[^0-9]/g,
            ""
        );
    } else {
        return e
    }
}