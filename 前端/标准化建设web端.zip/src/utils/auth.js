import Cookies from 'js-cookie'
import {
  getLoginInfo
} from '@/api/login'


const TokenKey = 'Admin-Token'

const ExpiresInKey = 'Admin-Expires-In'

const CookieKey = '.AspNetCore.Session'

localStorage.setItem('myToken', Cookies.get(TokenKey))

export function getToken() {
  return Cookies.get(TokenKey)
}

export function refreshUser() {
  let user = {};
  getLoginInfo({}).then(function (res) {
    localStorage.removeItem('userInfo')
    user = res.data;
    sessionStorage.setItem("user", JSON.stringify(user));
    localStorage.setItem("userInfo", JSON.stringify(user));
  })
  return user;
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
}

export function removeToken() {
  return Cookies.remove(TokenKey)
}

export function getCookie() {
  return Cookies.get(CookieKey)
}

export function setCookie(cookie) {
  console.log("==========走到这里c");
  return Cookies.set(CookieKey, cookie)
}

export function removeCookie() {
  return Cookies.remove(CookieKey)
}

export function getExpiresIn() {
  return Cookies.get(ExpiresInKey) || -1
}

export function setExpiresIn(time) {
  return Cookies.set(ExpiresInKey, time)
}

export function removeExpiresIn() {
  return Cookies.remove(ExpiresInKey)
}

export function isAqx() {
  let user = getCurrentUser();
  return user.companyCode.length < 10;
}


export function getCurrentCompany() {
  let user = getCurrentUser();
  return user.companyCode;
}

export function getCurrentUserName() {
  let user = getCurrentUser();
  return user.userName;
}


export function getCurrentUser() {
  let userJsonStr = localStorage.getItem("user");
  if (!userJsonStr || userJsonStr == "undefined") {
    return refreshUser();
  }
  else {
    let user = JSON.parse(userJsonStr)
    return user ? user : refreshUser();
  }

}

//公司管理员
export function isCompanyManager() { 
  let userInfo = getCurrentUser();
  let userKind = userInfo ? userInfo.userKind : 0;
  return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 32768) > 0
}
//销售负责人
export function isSaleManager() {
  let userInfo = getCurrentUser();
  let userKind = userInfo ? userInfo.userKind : 0;
  return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 2048) > 0
}
//财务负责人
export function isFinanceManager() {
  let userInfo = getCurrentUser();
  let userKind = userInfo ? userInfo.userKind : 0;
  return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 16384) > 0
}
//咨询项目负责人
export function isConsultManager() {
  let userInfo = getCurrentUser();
  console.log(userInfo);
  let userKind = userInfo ? userInfo.userKind : 0;
  return (userKind & 4) > 0 || (userKind & 256) > 0 || (userKind & 8192) > 0
}
