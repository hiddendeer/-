const checkBase = {
  state: {
    tabsShow: ''
  },
  mutations: {
    SET_TABSSHOW(state, payload) {
      state.tabsShow = payload
    }
  }
}

export default checkBase
