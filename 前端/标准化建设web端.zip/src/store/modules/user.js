import {
  login,
  loginSafety,
  logout,
  getInfo,
  getSafetyInfo,
  refreshToken,
  loginSafetyByMobile
} from '@/api/login'
import {
  getToken,
  setToken,
  // setCookie,
  setExpiresIn,
  removeToken
} from '@/utils/auth'

const user = {
  state: {
    token: getToken(),
    name: '',
    avatar: '',
    roles: [],
    permissions: [],
    //后加自身业务（TL）
    userName: '',
    chnName: '',
    companyCode: '',
    companyName: '',
    cookie: ''
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_EXPIRES_IN: (state, time) => {
      state.expires_in = time
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_PERMISSIONS: (state, permissions) => {
      state.permissions = permissions
    },
    SET_LoginData: (state, data) => {
      state.userName = data.userName;
      state.name = data.userName;
      state.chnName = data.chnName;
      state.companyCode = data.companyCode;
      state.companyName = data.companyName;
      state.token = data.companyCode + ':' + data.token;
      if (data.roles) {
        state.roles = data.roles;
      }
      sessionStorage.setItem("user", JSON.stringify(data));
      localStorage.setItem("user", JSON.stringify(data));
    },

  },

  actions: {
    SetLoginData({
      commit
    }, data) {
      // setCookie(data.cookie);
      setToken(data.companyCode + ':' + data.token);
      setExpiresIn(data.expiresIn);
      commit('SET_LoginData', data)
    },
    // 登录
    Login({
      commit
    }, userInfo) {
      const username = userInfo.username.trim()
      const password = userInfo.password
      const code = userInfo.code
      const uuid = userInfo.uuid
      return new Promise((resolve, reject) => {
        login(username, password, code, uuid).then(res => {
          let data = res.data
          setToken(data.access_token)
          commit('SET_TOKEN', data.access_token)
          setExpiresIn(data.expires_in)
          commit('SET_EXPIRES_IN', data.expires_in)
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登录管管（手机号）
    LoginSafetyByMobile({
      commit
    }, userInfo) {
      const params = {
        username: userInfo.mobile.trim(),
        password: userInfo.password,
        code: userInfo.code,
        uuid: userInfo.uuid,
        clientId: 10006,
        cookie: userInfo.cookie
      }
      return new Promise((resolve, reject) => {
        loginSafetyByMobile(params).then(res => {
          if (res.success && res.data && res.data.userName) {
            let data = res.data
            setToken(data.companyCode + ':' + data.token);
            setExpiresIn(data.expiresIn);
            commit('SET_LoginData', data)
            resolve()
          }
          else {
            reject("登录失败")
          }
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登录管管
    LoginSafety({
      commit
    }, userInfo) {
      console.log(userInfo)
      const params = {
        token: userInfo.token.trim(),
        companyId: userInfo.companyId,
        code: userInfo.code,
        uuid: userInfo.uuid
      }
      return new Promise((resolve, reject) => {
        loginSafety(params).then(res => {
          let data = res.data
          setToken(data.companyCode + ':' + data.token)
          commit('SET_TOKEN', data.companyCode + ':' + data.token)
          setExpiresIn(data.expiresIn)
          commit('SET_EXPIRES_IN', data.expiresIn)
          console.log('login')
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取用户信息
    GetInfo({
      commit,
      state
    }) {
      return new Promise((resolve, reject) => {
        getInfo().then(res => {
          const user = res.user
          // const avatar = user.avatar == "" ? require("@/assets/images/profile.jpg") : user.avatar;
          if (res.roles && res.roles.length > 0) { // 验证返回的roles是否是一个非空数组
            commit('SET_ROLES', res.roles)
            commit('SET_PERMISSIONS', res.permissions)
          } else {
            commit('SET_ROLES', ['ROLE_DEFAULT'])
          }
          commit('SET_NAME', user.userName)
          // commit('SET_AVATAR', avatar)
          resolve(res)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取用户信息
    GetSafetyInfo({
      commit,
      state
    }) {
      return new Promise((resolve, reject) => {
        let companyCode = '';
        getSafetyInfo(companyCode).then(res => {
          const user = res.user;
          if (res.roles) { // 验证返回的roles是否是一个非空数组
            commit('SET_ROLES', res.roles)
            commit('SET_PERMISSIONS', res.permissions)
          } else {
            commit('SET_ROLES', ['ROLE_DEFAULT'])
          }
          commit('SET_NAME', user.userName)
          commit('SET_AVATAR', user.avatar)
          resolve(res)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 刷新token
    RefreshToken({
      commit,
      state
    }) {
      return new Promise((resolve, reject) => {
        refreshToken(state.token).then(res => {
          setExpiresIn(res.data)
          commit('SET_EXPIRES_IN', res.data)
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 退出系统
    LogOut({
      commit,
      state
    }) {
      return new Promise((resolve, reject) => {
        logout(state.token).then(() => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          commit('SET_PERMISSIONS', [])
          removeToken()
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 前端 登出
    FedLogOut({
      commit
    }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        removeToken()
        resolve()
      })
    }
  }
}

export default user
