export default {
    inserted(el, binding) {
      if (el) {
        let scale = 1;
        el.onwheel = (event) => {
          event.preventDefault();
          const wheelDelta = event.deltaY;
          const scaleFactor = 0.1;
          const zoomFactor = wheelDelta > 0 ? 1 - scaleFactor : 1 + scaleFactor;
          scale *= zoomFactor;
          el.style.transform = `scale(${scale})`;
        };
      }
    },
  };