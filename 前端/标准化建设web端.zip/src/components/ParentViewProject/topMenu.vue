<template >
    <div class="div_container_menmu_row">
        <!-- <el-radio-group v-model="activeName" @change="goto">
            <template v-for="(item, index) in projectAllRouters">
                <el-radio-button v-if="!item.hidden" :label="item.name" v-bind:key="index">{{ item.meta.title }}
                </el-radio-button>
            </template>
        </el-radio-group> -->
        <div class="div-menu-row">
            <template v-for="(item, index) in projectAllRouters">
                <div @click="goto(item)"
                    :class="activeName === item.name ? 'div-menu-button div-button-active' : 'div-menu-button div-button-normal'"
                    v-if="!item.hidden" :label="item.name">{{
                            item.meta.title
                    }}</div>
            </template>
        </div>
        <!-- <div class="div-button-row">
            <el-button type="primary" size="mini" @click.stop="toHostBookView">电子台账</el-button>
            <el-button type="primary" size="mini" @click.stop="toHostHomeView">报表中心</el-button>
        </div> -->
    </div>
</template>
<script>
import { mapGetters, mapState } from "vuex";
export default {
    name: "top-menu",
    computed: {
        ...mapGetters(["projectAllRouters"]),
    },
    created() {
        let linkArry = [];
        this.projectAllRouters.forEach((item) => {
            let nameUrl = item.name;
            if (
                item.component === "ParentViewProjectMenu" &&
                item.children &&
                item.children.length
            ) {
                nameUrl = item.children[0].name;
            }

            linkArry.push({
                name: nameUrl,
                title: item.meta.title,
                hidden: item.hidden,
            });
        });
        this.linkArry = linkArry;
    },
    mounted() {
        const route = this.$route;
        let name = route.name;
        if (route.matched.length == 4) {
            name = route.matched[2].name;
        }
        this.activeName = name;
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";
    },
    data() {
        return {
            activeName: "",
            enterpriseCode: "",
            projectId: "",
            linkArry: [],
        };
    },
    filters: {
        getIcon: function () {
            return "/src/assets/images/file_icon/main_law.png";
        },
    },
    methods: {
        goto(item) {
            let namePath = item.name;
            this.activeName = item.name;
            let nameUrl = namePath;
            this.projectAllRouters.forEach((menu) => {
                if (menu.name == namePath) {
                    if (
                        menu.component === "ParentViewProjectMenu" &&
                        menu.children &&
                        menu.children.length
                    ) {
                        nameUrl = menu.children[0].name;
                    }
                }
            });
            this.$router.push({
                name: nameUrl,
                query: {
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });
        },
        /**
         * 跳转电子台账
         */
        toHostBookView() {
            this.$router.push({
                name: "HostBook",
                query: {
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                },
            });
        }, //跳转报表中心
        toHostHomeView() {
            this.$router.push({
                name: "HostSiteHome",
                query: {
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                },
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.div_Container {
    display: flex;
    flex-direction: column;
    margin-top: 5px;

    .div_Container_Row {
        display: flex;
        justify-content: space-between;
        margin: 0px 10px;

        .div_Container_RowChild_Horizontal {
            display: flex;
            flex-direction: row;
        }

        .div_Container_RowChild {
            display: flex;
            flex-direction: row;
            column-gap: 10px;

            overflow: hidden;
        }
    }
}

.div_Container_rowChild_block {
    border: 1px solid #f3f3f3;
    color: #1d93fe;
    border-radius: 10px;
    position: relative;
    min-width: 180px;
    height: 58px;
    margin-top: 15px;

    span {
        margin: 0px 10px;
        line-height: 58px;
        margin-left: 50px;
        font-size: 14px;
    }
}

.div_service {
    font-size: 14px;
    margin-top: 30px;
    min-width: 270px;
    overflow: hidden;
}

.spanEdit {
    cursor: pointer;
    color: #1d93fe;
    font-size: 12px;
    margin-left: 5px;
}

.span_EntName {
    font-size: 20px;
    line-height: 73px;
    margin-left: 10px;
    min-width: 288px;
    overflow: hidden;
}

.icon-image {
    width: 73px;
    height: 73px;
}

.block_img {
    width: 32px;
    height: 32px;
    position: absolute;
    top: 10px;
    left: 10px;
}

.div_container_menmu_row {
    margin-top: 10px;
    margin-bottom: 10px;
    min-width: 1100px;
    overflow-x: hidden;
    background: #FFF;
    display: flex;
    flex-direction: row;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;

    .div-menu-row {
        display: flex;
        flex-direction: row;
        min-width: 1000px;
    }

    .div-menu-button {
        padding: 10px 20px;
    }

    .div-button-active {
        background: #409EFF;
        border: 1px solid #409EFF;
        color: #FFF;
        font-size: 14px;
    }

    .div-button-normal {
        color: #303133;
        font-size: 14px;
    }

    .div-button-row {
        margin-top: 5px;
        margin-right: 5px;
        margin-right: 20px;
    }
}
</style>
