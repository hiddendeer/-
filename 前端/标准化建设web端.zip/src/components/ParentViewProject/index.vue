<template >
    <div>
        <eagle-block class="div-host-main-container" style="margin-bottom:10px;
    min-width: 1100px;">
            <project-header></project-header>
        </eagle-block>
        <top-menu>
        </top-menu>
        <!-- <div v-if="name=='ProjectMainIndex'">
            <task-process></task-process>
        </div> -->
        <div :body-style="{ padding: '10px 0px' }">
            <div class="host-content">
                <router-view :key="key" />
            </div>
        </div>
    </div>
</template>
<script>
import ProjectHeader from "@/components/ParentViewProject/projectHeader";
// import taskProcess from "@/views/project/components/projectConsultation/taskProcess.vue";
import TopMenu from "@/components/ParentViewProject/topMenu.vue";
export default {
    components: { ProjectHeader, TopMenu },
    computed: {
        key() {
            return this.$route.path;
        },
    },
    data() {
        return {
            modulesId: "",
            name: "",
        };
    },
    mounted() {
        this.modulesId = this.$route.meta.modulesId;
        this.name = this.$route.name;
        if (this.$route.matched.length > 0) {
            this.name =
                this.$route.matched[this.$route.matched.length - 1].name;
        }
    },
};
</script>
<style lang="scss">
.host-content {
    .layer {
        border: none;
        margin-top: 0px;
    }

    .app-container {
        padding-bottom: 0px;
    }
}
</style>