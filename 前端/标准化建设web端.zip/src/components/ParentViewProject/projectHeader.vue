<template >
    <div class="div_Container">
        <div class="div-project-area">
            <img :src="require('@/assets/images/file_icon/ent_image.png')" style="width: 50px; height: 50px;" />
            <div class="div-font-area">
                <div class="div_entName single-line">{{ form.projectName }}
                </div>
                <div class="div-remark">
                    <div class="single-line">服务类型：{{ form.serviceName }}</div>
                    <div v-if="form.serviceType == 'C'">模板：{{ form.entrustedBigCatalogName }}</div>
                    <div>项目工期：{{ parseTime(form.startDate, "{y}-{m}-{d}") }}至{{
                            parseTime(form.endDate, "{y}-{m}-{d}")
                    }}
                    </div>
                </div>
            </div>
        </div>
        <div class="div-button-area">
            <div v-if="showArrange" @click.stop="projectArrangement()" class="div-button-info div-middle">
                <img :src="require('@/assets/images/file_icon/arrange.png')" class="icon-image" />项目安排
            </div>
            <div v-if="modulesId != 'dangerJg'" @click.stop="toHostHomeView" class="div-button-info div-middle"><img
                    :src="require('@/assets/images/file_icon/report.png')" class="icon-image" />报表中心</div>
            <div v-if="modulesId != 'dangerJg'" @click.stop="toHostBookView()" class="div-button-info div-middle">
                <img :src="require('@/assets/images/file_icon/site.png')" class="icon-image" />电子台账
            </div>
            <div class="div-button-info div-middle" @click.stop="backProjectList"> <img
                    :src="require('@/assets/images/file_icon/back.png')" class="icon-image" />返回列表
            </div>
        </div>
        <project-arrangement-edit ref="projectArrangementEdit" @afterSave="afterSave">
        </project-arrangement-edit>
    </div>
</template>
<script>
import projectArrangementEdit from "@/views/project/components/projectManage/ProjectArrangementEdit.vue";
import { getCurrentUser } from "@/utils/auth";
import { mapGetters, mapState } from "vuex";

export default {
    name: "ProjectHeader",
    computed: {
        ...mapGetters(["projectAllRouters"]),
    },
    components: {
        projectArrangementEdit,
    },
    created() {
        let linkArry = [];
        this.projectAllRouters.forEach((item) => {
            let nameUrl = item.name;
            if (
                item.component === "ParentViewProjectMenu" &&
                item.children &&
                item.children.length
            ) {
                nameUrl = item.children[0].name;
            }
            linkArry.push({ name: nameUrl, title: item.meta.title });
        });
        this.linkArry = linkArry;
    },
    mounted() {
        this.currentUser = getCurrentUser();

        const route = this.$route;
        let name = route.name;
        if (route.matched.length == 4) {
            name = route.matched[2].name;
        }
        this.activeName = name;
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";
        this.getProjectData();

    },
    data() {
        return {
            form: {
                attachs: "@/assets/images/file_icon/main_law.png",
                serviceName: "",
                entrustedBigCatalogName: "",
                enterpriseName: "",
                serviceType: ""
            },
            activeName: "",
            enterpriseCode: "",
            projectId: "",
            linkArry: [],
            modulesId: "",
            showArrange: false,
            currentUser: {}
        };
    },
    filters: {
        getIcon: function () {
            return "/src/assets/images/file_icon/main_law.png";
        },
    },
    created() {
        this.modulesId = this.$route.meta.modulesId;
    },
    methods: {
        goto(namePath) {
            let nameUrl = namePath;
            this.projectAllRouters.forEach((menu) => {
                if (menu.name == namePath) {
                    if (
                        menu.component === "ParentViewProjectMenu" &&
                        menu.children &&
                        menu.children.length
                    ) {
                        nameUrl = menu.children[0].name;
                    }
                }
            });
            this.$router.push({
                name: nameUrl,
                query: {
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });
        },
        backProjectList() {
            this.$router.push({
                name: "MyProjectList",
            });
        },
        getProjectData() {

            if (this.projectId) {
                let _this = this;
                let url =
                    "site/projectConsultation/getDataByCode/" + this.projectId;
                this.http.get(url, null).then((res) => {
                    if (res.code == 200) {
                        var data = res.data;
                        _this.form = {};
                        _this.form.serviceName = data.serviceName;
                        _this.form.serviceType = data.serviceType;
                        _this.form.enterpriseName = data.enterpriseName;
                        _this.form.projectName = data.projectName;
                        _this.form.entrustedBigCatalogName =
                            data.entrustedBigCatalogName;
                        _this.form.startDate = data.startDate;
                        _this.form.endDate = data.endDate;
                        _this.form.id = data.id;
                        _this.form.mainUserName = data.mainUserName;
                        if ((_this.form.mainUserName == _this.currentUser.userName || _this.currentUser.manager) && _this.form.status < 30) {
                            _this.showArrange = true;
                        }
                    }
                });
            } else {
            }
        },
        toHostBookView() {
            this.$router.push({
                name: "HostBook",
                query: {
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                },
            });
        }, //跳转报表中心
        toHostHomeView() {
            this.$router.push({
                name: "HostSiteHome",
                query: {
                    enterpriseCode: this.$route.query.enterpriseCode ?? "",
                    projectId: this.$route.query.projectId ?? "",
                },
            });
        },
        projectArrangement() {
            let row = this.form;
            //row.id = this.form.id;
            let config = { type: 2 };
            this.$refs.projectArrangementEdit.show(row, config);
        },
        afterSave(res, action) {
            this.getProjectData();
        },
    },
};
</script>
<style lang="scss" scoped>
.project_card ::v-deep .el-card__body {
    padding: 10px;
}

.div_Container {
    margin-top: 5px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    cursor: pointer;

    .div-project-area {
        display: flex;
        flex-direction: row;
        flex: 1;
    }
}

.div_Container_rowChild_block {
    border: 1px solid #f3f3f3;
    color: #1d93fe;
    border-radius: 10px;
    position: relative;
    min-width: 180px;
    height: 38px;
    margin-top: 15px;

    span {
        margin: 0px 10px;
        line-height: 38px;
        margin-left: 50px;
        font-size: 14px;
    }
}

.div_service {
    font-size: 14px;
    margin-top: 6px;
    min-width: 270px;
    overflow: hidden;
}

.spanEdit {
    cursor: pointer;
    color: #1d93fe;
    font-size: 12px;
    margin-left: 5px;
}

.div-font-area {
    padding-left: 15px;

    .div_entName {
        font-size: 16px;
        font-weight: 500;
        color: #303133;
        line-height: 25px;
    }

    .div-remark {
        display: flex;

        line-height: 25px;
        color: #606266;

        div {
            margin-right: 20px;
            min-width: 220px
        }
    }
}

.div-button-area {
    display: flex;
    flex-direction: row;
    font-size: 14px;
    font-weight: 500;
    color: #606266;
    line-height: 32px;
    justify-content: flex-end;

    .div-middle {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .icon-image {
        width: 17px;
        height: 17px;
        margin-right: 5px;
    }

    .div-button-info {
        width: 100px;
        height: 32px;
        background: #FFFFFF;
        border: 1px solid #DCDFE6;
        border-radius: 4px;
        margin-right: 10px;
    }

}

.icon-image {
    width: 73px;
    height: 73px;
}

.block_img {
    width: 32px;
    height: 32px;
    position: absolute;
    top: 10px;
    left: 10px;
}
</style>
