<template >
    <!-- #e6e6e6 :style="{height:height+'px'}"-->
    <div class="div-container" v-bind:style="{ height: menuHeight + 'px' }">
        <div class="div-left-menu-container mr10">
            <el-menu :default-active="activeName" class="el-menu-vertical-demo">
                <el-menu-item v-for="(item, index) in menuArry" :key="index" :index="item.name" @click="goto(item)">
                    <i class="el-icon-menu"></i>
                    <span slot="title" :title="item.meta.title">{{ item.meta.title }}</span>
                </el-menu-item>
            </el-menu>
        </div>
        <div class="div-router-container">
            <router-view :key="key" />
        </div>
    </div>
</template>

<script>
import { mapGetters, mapState } from "vuex";
export default {
    computed: {
        ...mapGetters(["projectAllRouters"]),
        key() {
            return this.$route.path;
        },
    },
    mounted() {
        const route = this.$route;
        debugger;
        this.activeName = route.name;
        var _this = this;
        if (route.matched && route.matched.length > 1) {
            let parentName = route.matched[route.matched.length - 2].name;
            this.projectAllRouters.forEach((menu) => {
                if (menu.name == parentName) {
                    menu.children.forEach(function (dItem) {
                        if (dItem.hidden == false) {
                            _this.menuArry.push(dItem);
                        }
                    });
                }
            });
        }
        this.enterpriseCode = this.$route.query.enterpriseCode ?? "";
        this.projectId = this.$route.query.projectId ?? "";

        this.getDivHeight();
        window.addEventListener("resize", this.getDivHeight);
    },
    data() {
        return {
            menuArry: [],
            activeName: "",
            enterpriseCode: "",
            projectId: "",
            menuHeight: 0,
        };
    },
    methods: {
        getDivHeight() {
            this.menuHeight = document.documentElement.clientHeight - 208;
        },
        goto(item) {
            // console.log("betall", item);

            this.$router.push({
                name: item.name,
                query: {
                    enterpriseCode: this.enterpriseCode,
                    projectId: this.projectId,
                },
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.div-container {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;

    // .layer {
    //     padding: 0px 3px;
    // }

    overflow-y: visible;

    .div-left-menu-container .el-menu:last-child {
        border-radius: 0 0 5px 5px;
        min-height: 400px;
    }

    .div-left-menu-container {
        width: 200px;
        min-width: 200px;
        overflow: hidden;
        border-radius: 5px;

        .el-menu-vertical-demo {
            width: 100%;
        }

        ::v-deep.el-radio-button--medium {
            cursor: pointer;
        }

        .el-menu {
            border-right: 0px;
        }

        .el-icon-menu {
            margin-right: 0px;
        }

        border-right: 0px;
    }

    .div-router-container {
        flex: 1;
        // border-left: 1px solid #e6e6e6;
        overflow-x: hidden;
        overflow-y: auto;
        // background: #fff;
        border-radius: 5px;
    }
}
</style>
