<template>
  <el-upload
    style="width: 100%"
    :disabled="uploadLoading || isFormDisabled"
    ref="upload"
    :action="uploadUrl"
    :headers="headers"
    :on-success="handleUploadSuccess"
    :accept="accept"
    :limit="1"
    :auto-upload="true"
    :file-list="uploadFileList"
    :before-upload="beforeUpload"
    :on-exceed="handleExceed"
    :on-remove="handleRemove"
    :on-change="fileChange"
    :on-preview="onPreview"
  >
    <el-input v-show="false" v-model="fileUrl"></el-input>
    <el-button
      type="primary"
      :disabled="uploadLoading || isFormDisabled"
      :loading="uploadLoading"
      >点击上传</el-button
    >
    <template #tip>
      <div class="cusUploadTip">
        可上传{{ accept.replace(/\,|\，/g, "") }}
      </div>
    </template>
  </el-upload>
</template>

<script>
import { getToken } from "@/utils/auth";
export default {
  name: "cus-upload",
  props: {
    fileList: {
      type: Array,
      default() {
        return [];
      },
    },
    accept: {
      type: String,
      default() {
        return ".doc,.docx,.pdf,.xlsx,.xls,.zip,.PDF,.DOC,.DOCX,.XLS,.XLSX";
      },
    },
    maxSize: {
      type: Number,
      default() {
        return 5000;
      },
    },
    isFormDisabled: {
      type: [Boolean],
      default() {
        return false;
      },
    },
  },
  data() {
    return {
      fileUrl: "",
      uploadFileList: [],
      uploadLoading: false,
      uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload",
      headers: {
        Authorization: "Bearer " + getToken(),
      },
    };
  },
  computed: {},
  watch: {
    fileList(val) {
      if (val) {
        this.uploadFileList = val;
      }
    },
  },

  methods: {
    fileChange(file, fileList) {
      this.uploadFileList = fileList;
    },

    async handleUploadSuccess(res) {
      if (res.code == 200) {
        this.$emit("uploadFile", res.data.attCode, this.uploadFileList);
        this.fileUrl = "file";
      } else {
        this.$message.error("附件上传失败");
      }
    },

    beforeUpload(file, fileList) {
      let fileType = "";
      let png = "image/png";
      let jpeg = "image/jpeg";
      let jpg = "image/jpg";

      let doc = "application/msword";
      let docx =
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      let pdf = "application/pdf";
      let xlsx =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      let xls = "application/vnd.ms-excel";
      let xcZip = "application/x-zip-compressed";
      let zip = "application/zip";
      let osZip = "application/octet-stream";
      let xZip = "multipart/x-zip";

      console.log("file.type", file.type);
      console.log("file", file);
      switch (file.type) {
        case xlsx:
          fileType = "xlsx";
          break;
        case xls:
          fileType = "xls";
          break;
        case pdf:
          fileType = "pdf";
          break;
        case doc:
          fileType = "doc";
          break;
        case docx:
          fileType = "docx";
          break;
        case png:
          fileType = "png";
          break;
        case jpeg:
          fileType = "jpeg";
          break;
        case jpg:
          fileType = "jpg";
          break;
        case xcZip:
          fileType = "zip";
          break;
        case zip:
          fileType = "zip";
          break;
        case osZip:
          fileType = "zip";
          break;
        case xZip:
          fileType = "zip";
          break;
        default:
          break;
      }
      let acceptIncludes = this.accept
        .replace(/\.|\s/g, "")
        .split(",")
        .includes(fileType);
      if (!acceptIncludes) {
        this.$message.error("上传文件类型有误，请重新上传");
        return false;
      }
      const isLtMaxSize = file.size / 1024 <= this.maxSize;
      if (!isLtMaxSize) {
        this.$message.error(`超出文件大小限制${this.maxSize}kb，无法导入`);
        return false;
      }
      return true;
    },

    handleRemove(file, uploadFiles) {
      this.uploadFileList = uploadFiles;
      this.$emit("uploadFile", "");
      this.fileUrl = "";
    },
    handleExceed(files, uploadFiles) {
      this.$message.warning("超出文件数量限制");
    },
    async onPreview(file) {
      let blob = null;
      if (file.url) {
        let response = await fetch(file.url);
        // 内容转变成blob地址
        blob = await response.blob();
      }
      // 创建隐藏的可下载链接
      let objectUrl = window.URL.createObjectURL(blob ?? file.raw);
      let a = document.createElement("a");
      //地址
      a.href = objectUrl;
      //修改文件名
      a.download = file.name;
      // 触发点击
      document.body.appendChild(a);
      a.click();
      //移除
      setTimeout(() => document.body.removeChild(a), 1000);
    },
  },
};
</script>

<style lang="scss" scoped>
.cusUploadTip {
  margin-top: 0;
  position: absolute;
  left: 110px;
  top: 0;
  color: red;
  overflow: hidden;
  white-space: normal;
  word-wrap: break-word;
  word-break: break-all;
  text-overflow: ellipsis;
}
</style>
