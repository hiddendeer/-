<template>
    <div>
        <el-dialog :title="title" v-dialogDrag :visible.sync="open" :width="width" append-to-body show-close :close-on-click-modal="false" :before-close="handleClose">
             <eagle-block border>
                <div style="display: flex; padding: 5px 10px">
                    <div>
                        <label class="el-form-item__label" style="80px;">上传文件</label>
                    </div>

                    <el-upload width="500px" ref="upload" :limit="1" accept=".xlsx, .xls" :headers="headers" :action="
                        uploadUrl + '/' + url + '/importData?updateSupport=' + updateSupport + companyCodeStr
                    " :data="ExportData" :disabled="isUploading" :on-progress="handleFileUploadProgress" :on-success="handleFileSuccess" :auto-upload="true" drag class="import-block">
                        <i class="el-icon-upload"></i>
                        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                        <div class="el-upload__text">仅允许xls、xlsx文件</div>
                        <div class="el-upload__tip" slot="tip"></div>
                        <!-- <span>仅允许导入xls、xlsx格式文件。</span> -->
                    </el-upload>
                </div>
                <el-form ref="form" :model="ExportData" label-width="80px">
                    <el-form-item label="导入模板">
                        <el-link type="primary" :underline="false" style="font-size: 14px; vertical-align: baseline" @click="importTemplate">下载模板</el-link>
                    </el-form-item>
                    <el-form-item label="导入设置" required>
                        <el-radio-group v-model="ExportData.ImportOption">
                            <el-radio label="1">遇错继续</el-radio>
                            <el-radio label="0">遇错停止</el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="导入结果">
                        <el-input v-model="result" type="textarea" :rows="4" readonly></el-input>
                    </el-form-item>
                </el-form>

                <div slot="footer" class="dialog-footer">
                    <el-button @click="cancel">关闭</el-button>
                </div>
            </eagle-block>
        </el-dialog>
    </div>
</template>


<script>
// 导出模板   导入数据操作工具类
import { getToken } from "@/utils/auth";
import { download } from "@/utils/request"
import { re } from "mathjs";
// import { postData, getInfo, putData } from "@/api/http";
export default {
    name: "EagleDialogExce",
    props: {
        width: {
            type: String,
            default() {
                return "600px";
            },
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        url: {
            type: String,
            default() {
                return "";
            },
        },
        updateSupport: {
            type: Number,
            default() {
                return 0;
            },
        },
        fileName: {
            type: String,
            default() {
                return "";
            },
        },
        isUploading: {
            type: Boolean,
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            ExportData: {
                ImportOption: "1",
            },
            form: {},
            uploadUrl: process.env.VUE_APP_BASE_API,
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            open: false,
            queryParams: {
                fileName: "",
            },
            result: "",
            companyCodeStr: "",
        };
    },
    created() {
        if (this.$route.query.enterpriseCode) {
            this.companyCodeStr =
                "&companyCode=" + this.$route.query.enterpriseCode;
        }
    },
    methods: {
        // 文件上传中处理
        handleFileUploadProgress(event, file, fileList) {
            this.isUploading = true;
        },
        /** 下载模板操作 */
        importTemplate() {
            this.queryParams.fileName = this.fileName;
            download(
                "/" + this.url + "/importDefineTemplate",
                {
                    ...this.queryParams,
                },
                this.title + `模板.xlsx`
            );
            //   ——${new Date().getTime()}
        },
        // 文件上传成功处理
        handleFileSuccess(response, file, fileList) {
            //   this.open = false;
            this.isUploading = false;
            this.$refs.upload.clearFiles();
            if ((response.code = 200)) {
                this.result = response.data;
            } else {
                this.$alert(response.errorText, response.errorText);
            }
            //   this.$alert(response.data, response.errorText, {
            //     dangerouslyUseHTMLString: true,
            //   });

            //   this.$emit("refresh");
        },
        // 关闭按钮
        cancel() {
            this.result = "";
            this.open = false;
            this.$emit("refresh");
        },
        show() {
            this.open = true;
            this.result = "";
        },
        handleClose(done) {
            done();
            this.$emit("refresh");
        },
        // 提交上传文件
        submitFileForm() {
            this.$refs.upload.submit();
            this.$refs.upload.clearFiles();
            this.result = "";
        },
    },
};
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.el-form-item {
    margin-bottom: auto;
}
</style>
