<template>
    <el-button class="eagle-row-btn" v-bind="$attrs" v-on="$listeners" :size="size" :plain="plain">
        <slot />
    </el-button>
</template>
<script>
export default {
    name: "eagle-row-button",
    props: {
        size: { type: String, default: "mini" },
        plain: { type: Boolean, default: true },
    },
    data() {
        return {
            // defaultType: "primary",
        };
    },
    watch: {},
    created() {},
    methods: {
        // click() {
        //     this.$emit("click");
        // },
    },
};
</script>
<style  scoped lang="scss">
.eagle-row-btn {
    cursor: pointer;
    margin-bottom: 5px;
    padding: 5px 8px !important;
}
</style>