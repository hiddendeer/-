<template>
  <div class="eagle-page">
    <div class="eagle-header">
      <div class="eagle-page-search" :style="{ 'margin-right': searchRight }">
        <slot name="slot-search"> </slot>
      </div>
      <div class="eagle-page-buttons eagle-btn">
        <slot name="slot-buttons"></slot>
      </div>
    </div>
    <div v-if="!customize" class="child">
      <div class="eagle-page-table">
        <el-table
          :show-header="showHeader"
          :rowClassName="rowClassName"
          :show-summary="showSummary"
          :height="maxHeight - 10"
          ref="multipleTable"
          v-loading="pageLoading"
          :data="list"
          @row-click="rowClick"
          @selection-change="handleSelectionChange"
          @select="handleCheckBoxChange"
          @select-all="handleCheckBoxAllChange"
          :summary-method="handleSummary"
        >
          <el-table-column
            width="45px"
            v-if="single && showCheckColumn"
            fixed="left"
            align="center"
          >
            <template v-slot="scope">
              <el-radio
                v-model="singleValue"
                :label="scope.row[selectField]"
                @change="handleRowChange(scope.row)"
                >{{ "" }}</el-radio
              >
            </template>
          </el-table-column>
          <el-table-column
            v-if="!single && showCheckColumn"
            fixed="left"
            type="selection"
            width="45px"
            align="center"
          />
          <el-table-column
            v-if="showOrder"
            :label="label"
            fixed
            align="left"
            width="50px"
          >
            <template slot-scope="scope">
              <span class="index">{{ scope.$index + 1 }}</span>
            </template>
          </el-table-column>
          <slot name="slot-table"></slot>
          <el-table-column
            label="操作"
            fixed="right"
            align="left"
            v-if="showBtn"
            class-name="small-padding fixed-width table-button"
            :width="btnWidth"
          >
            <template slot-scope="scope">
              <div class="btn-td">
                <slot
                  name="slot-row-buttons"
                  :row="scope.row"
                  :index="scope.$index"
                />
              </div>
            </template>
          </el-table-column>
          <template slot="empty">
            <el-empty :image-size="imageSize" description="暂无数据"></el-empty>
          </template>
        </el-table>
      </div>
    </div>
    <div v-else-if="customize" class="child">
      <div class="customize-block">
        <slot :data="list"> </slot>
        <div class="customize-page"></div>
      </div>
    </div>
    <el-pagination
      class="pagination"
      background
      small
      v-show="total > 0 && !noPage"
      :total="total"
      :current-page="query.params.pageNum"
      :page-size="query.params.pageSize"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :page-sizes="pageSizes"
      :layout="layout"
    >
    </el-pagination>
    <el-empty
      :image-size="imageSize"
      v-if="isShowEmpty && isShowEmpty1"
    ></el-empty>
  </div>
</template>
<script>
// import { get, del } from "@/api/http";
// import nodata from "../Eagle/eagle-nodata.vue";
export default {
  // components: { nodata },
  name: "eagle-page",
  props: {
    pageSizes: {
      type: Array,
      default() {
        return [10, 20, 30, 50, 100];
      },
    },
    showCheckColumn: { type: Boolean, default: true },
    tableHeight: {
      type: String | Number,
      default: 50,
    },
    countHeight: {
      type: String | Number,
      default: 0,
    },
    imageSize: {
      type: String | Number,
      default: 200,
    },
    label: { type: String, default: "序号" },
    single: { type: Boolean, default: false },
    showCheck: { type: Boolean, default: false },
    selectValue: { type: String | Array | Number, default: "" },
    selectField: { type: String, default: "code" },
    pageUrl: { type: String, default: "" },
    idField: { type: String, default: "id" },
    selectTextField: { type: String, default: "name" },
    btnWidth: { type: String, default: "120" },
    searchRight: { type: String, default: "120px" },
    showBtn: { type: Boolean, default: true },
    customize: { type: Boolean, default: false },
    noPage: { type: Boolean, default: false },
    showOrder: { type: Boolean, default: true },
    showHeader: { type: Boolean, default: true },
    controller: { type: String, default: "" },
    queryUrl: { type: String, default: "" },
    pageSize: { type: Number, default: 20 },
    hasTotal: { type: Boolean, default: false },
    isDialog: { type: Boolean, default: false },
    hasTab: { type: Boolean, default: false },
    hasSearchTitle: { type: Boolean, default: false },
    showSummary: { type: Boolean, default: false },
    size: { type: String, default: "small" },
    rowStyle: {
      type: Function,
      default() {
        return {};
      },
    },
    rowClassName: {
      type: Function,
      default() {
        return "";
      },
    },
    layout: {
      type: String,
      default: "total, sizes, prev, pager, next, jumper",
    },
    isShowEmpty: { type: Boolean, default: false },
    queryParams: {
      type: Object,
      default: function () {
        return {};
      },
    },
    conditions: {
      type: Object,
      default: function () {
        return {};
      },
    },
    uniId:{
      type:String,
      default:''
    },
    uniColumns:{
      type:Array,
      default:function(){
        return []
      }
    }
  },
  data() {
    return {
      // RefRowSelection: [],
      singleValue: this.selectValue,
      multipleValue: this.selectValue,
      selection: [],
      // 遮罩层
      pageLoading: false,
      total: 0,
      list: [],
      isShowEmpty1: false,
      pageParams: {
        pageNum: 1,
        pageSize: 20,
      },
      query: {
        url: "",
        params: {},
      },
      maxHeight: 0,
    };
  },
  created() {
    this.pageParams.pageSize = this.pageSize;
    this.maxHeight = this.tableHeight;
  },
  mounted: function () {
    var _this = this;
    if (this.maxHeight == 50) {
      var subtractVal = 150;
      if (!_this.noPage) {
        subtractVal = 110;
      }
      if (_this.isDialog) {
        subtractVal += 100;
      } else {
        if (_this.hasTotal) {
          subtractVal += 70;
        }
        if (_this.hasTab) {
          subtractVal += 80;
        }
        if (_this.hasSearchTitle) {
          subtractVal = 150;
        }
      }
      this.$nextTick(function () {
        if (_this.$refs.multipleTable) {
          let self = this;
          _this.maxHeight =
            window.innerHeight -
            _this.$refs.multipleTable.$el.offsetTop -
            subtractVal -
            self.countHeight;
          _this.maxHeight = _this.maxHeight < 500 ? 500 : _this.maxHeight;

          // 监听窗口大小变化
          window.onresize = function () {
            if (_this.$refs.multipleTable) {
              _this.maxHeight =
                window.innerHeight -
                _this.$refs.multipleTable.$el.offsetTop -
                subtractVal -
                self.countHeight;
              _this.maxHeight = _this.maxHeight < 500 ? 500 : _this.maxHeight;
            }
          };
        }
      });
    }
  },
  watch: {
    selectValue(nVal, oVal) {
      this.singleValue = nVal;
      this.multipleValue = nVal;
    },
  },
  methods: {
    setList(config) {
      this.list = config.list;
      this.pageParams.pageNum = config.pageNum;
      this.pageParams.pageSize = config.pageSize;
      this.query = config.queryParams;
      this.total = config.total;
      this.query.url = config.url;
    },
    refresh(config) {
      this.getListData();
    },
    search(config) {
      this.pageParams.pageNum = 1;
      this.dealParams(config);
      this.getListData();
    },
    dealParams(config) {
      if (config && config.url) {
        this.query.url = config.url;
      } else {
        this.query.url = this.pageUrl
          ? this.pageUrl
          : this.controller + "/getPageData";
      }
      if (config) {
        if (config.params) {
          this.query.params = this.deepMerge(config.params, this.pageParams);
        } else {
          this.query.params = this.deepMerge(this.queryParams, this.pageParams);
        }
        if (config.conditions) {
          this.query.params.conditions = config.conditions;
        } else {
          this.query.params.conditions = this.getCondtionsNew();
        }
      } else {
        this.query.params = this.deepMerge(this.queryParams, this.pageParams);
        this.query.params.conditions = this.getCondtionsNew();
      }
    },
    handleCurrentChange(pageNum) {
      this.query.params.pageNum = pageNum;
      this.pageParams.pageNum = pageNum;
      this.getListData();
    },
    handleSizeChange(size) {
      this.query.params.pageNum = 1;
      this.pageParams.pageNum = 1;
      this.pageParams.pageSize = size;
      this.query.params.pageSize = size;
      this.getListData();
    },
    getListData() {
      this.pageLoading = true;
      let _this = this;
      _this.isShowEmpty1 = false;
      let enterpriseCode = this.$route.query.enterpriseCode;
      if (enterpriseCode) {
        if (!this.query.params.companyCode) {
          this.$set(this.query.params, "companyCode", enterpriseCode);
        }
      }
      this.http
        .get(this.query.url, this.query.params)
        .then((res) => {
          this.pageLoading = false;
          _this.list = res.data;
          if (res.data.length == 0) {
            _this.isShowEmpty1 = true;
          }
          _this.total = res.total;
          _this.pageLoading = false;
          _this.selection = [];
          // if (
          //     _this.loading == false &&
          //     this.RefRowSelection.length > 0
          // ) {
          //     this.RefRowSelection.length;
          //     setTimeout(() => {
          //         this.ReftoggleRowSelection(this.RefRowSelection);
          //     });
          // }
          // if (
          //     !_this.showCheckColumn &&
          //     _this.single &&
          //     _this.list.length > 0
          // ) {
          //     _this.rowClick(_this.list[0]);
          // }
          this.$emit("afterSearch", _this.list);
        })
        .catch(() => {
          this.pageLoading = false;
        });
    },
    rowClick(row) {
      let _this = this;
      if (_this.single) {
        _this.singleValue = row[_this.selectField];
        _this.selection = [];
        _this.selection.push(row);
      } else {
        _this.$refs.multipleTable.toggleRowSelection(row);
        var checked =
          _this.selection.findIndex(
            (x) => x[_this.selectField] == row[_this.selectField]
          ) >= 0;
        _this.setChangeData(row, checked);
      }
      this.$emit("rowClick", row);
    },
    handleSelectionChange(selection) {
      this.selection = selection.filter((item) => item != undefined);
      this.$emit("handleSelectionChange", selection);
    },
    getSelection() {
      return this.selection;
    },
    getCurrentList() {
      return this.list;
    },
    //查找当前页面的选中id
    getSelectionIds() {
      var arryIds = [];
      this.selection.forEach((item) => {
        arryIds.push(item[this.idField]);
      });
      return arryIds.join(",");
    },
    // 风险分控
    selectionRemove(id) {
      let index = this.list.findIndex((item) => item.id === id);
      let selectionIndex = this.selection.findIndex((item) => item.id === id);

      if (index != -1)
        this.$refs.multipleTable.toggleRowSelection(this.list[index]);
      if (selectionIndex != -1) this.selection.splice(selectionIndex, 1);
    },
    // setSelection() {
    //     let _this = this;
    //     _this.selection = selection;
    //     _this.selection = _this.list.filter((x) =>
    //         _this.multipleValue.include(x[_this.selectField])
    //     );
    //     if (_this.selection) {
    //         _this.selection.forEach((row) => {
    //             _this.$refs.multipleTable.toggleRowSelection(row);
    //         });
    //     }
    // },
    // toggleRowSelection(ref) {
    //     this.selection = [];
    //     let _this = this;
    //     ref.forEach((row) => {
    //         this.selection.push(row);
    //         this.list.filter((x) => {
    //             if (row.tCode == x.tCode) {
    //                 _this.$refs.multipleTable.toggleRowSelection(x, false);
    //             }
    //         });
    //     });
    // },
    handleCheckBoxChange(selectAllRow, currRow) {
      let _this = this;
      this.setChangeData(
        currRow,
        selectAllRow.findIndex(
          (x) => x[_this.selectField] == currRow[_this.selectField]
        ) >= 0
      );
      // selectAllRow.forEach((element) => {
      // if (element.tCode !== currRow.tCode) {
      this.$emit("handleCheckBoxChange", currRow);
      // }
      // });
    },
    handleConfirm() {
      console.log(this.selection);
    },
    handleCheckBoxAllChange(selectRows) {
      let _this = this;
      //先从选中的列表中全都移除
      this.list.forEach((x) => {
        _this.setChangeData(x, false);
      });
      if (selectRows && selectRows.length > 0) {
        _this.selection = _this.selection.concat(selectRows);
      }
      this.$emit("handleCheckBoxAllChange", _this.selection);
    },
    handleSummary({columns,data}){
      let sum = [];  
      columns.forEach((column,index)=>{
        if(this.$props.uniColumns.includes(column?.property) && !!this.$props?.uniId){
          let innerSum=0;
          const uniquePlanIds = new Set();
          data.forEach((item)=>{
            if(!uniquePlanIds.has(item[this.$props?.uniId])){
              uniquePlanIds.add(item[this.$props?.uniId]);
              innerSum+=item[column.property];
            }
          })
          sum[index]=innerSum;
        }else{
          const values = data.map(item => Number(item[column.property]));
          if (!values.every(value => isNaN(value))) {
            sum[index] = values.reduce((prev, curr) => {
              const value = Number(curr); //Number转换为数值
              if (!isNaN(value)) {
                return prev + curr;
              } else {
                return prev;
              }
            }, 0);
          }
        }
        if(isNaN(Number(sum[index]))){
            sum[index]=""
        }
        if(index==0){
          sum[0]="合计"
        }
      })
      return sum;
    },
    handleCopy(row, success) {
      let _this = this;
      const id = row[this.idField];
      var url = "/" + this.controller + "/copy/" + id;
      _this.http.postLoading(_this.loading(), url, {}, function (res) {
        if (typeof success == "function") {
          success(res);
        } else {
          _this.refresh();
        }
        _this.msgSuccess("复制成功");
      });
    },

    /** 删除按钮操作 */
    handleDelete(row, success) {
      var url = "/" + this.controller + "/delete/" + row[this.idField];
      let _this = this;
      this.$confirm("是否确认删除此行数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function (res) {
          _this.http.delLoading(_this.loading(), url, {}, function (res) {
            if (typeof success == "function") {
              success(res);
            } else {
              _this.refresh();
            }
            _this.msgSuccess("删除成功");
          });
        })
        .catch(() => {});
    },
    //批量删除操作
    handleMultDelete(ids, success) {
      let _this = this;

      if (ids == "") {
        _this.msgError("请先选择数据项");
        return false;
      }
      var url = "/" + this.controller + "/delete/" + ids;
      this.$confirm("是否确认删除选中数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function (res) {
          const load = _this.loading();
          _this.http.delLoading(load, url, {}, function (res) {
            if (typeof success == "function") {
              success(res);
            } else {
              _this.refresh();
            }
            _this.msgSuccess("删除成功");
          });

          // _this.http.del(url).then(function () {
          //     if (typeof success == "function") {
          //         success(res);
          //     } else {
          //         _this.refresh();
          //     }
          //     _this.msgSuccess("删除成功");
          // });
        })
        .catch(() => {
          debugger;
        });
    },
    //批量废止操作
    handleMultDisable(ids, success) {
      if (ids == "") {
        _this.msgError("请先选择数据项");
        return false;
      }
      var url = "/" + this.controller + "/disable/" + ids;
      let _this = this;
      this.$confirm("是否确认作废选中数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function () {
          _this.http.postLoading(_this.loading(), url, {}, function (res) {
            if (typeof success == "function") {
              success(res);
            }
            _this.msgSuccess("作废成功");
          });
          // return _this.http.post(url).then((res) => {
          //     if (res.code == 200) {
          //         if (typeof success == "function") {
          //             success(res);
          //         }
          //         _this.msgSuccess("作废成功");
          //     } else {
          //         _this.msgError("作废失败");
          //     }
          // });
        })
        .catch(() => {});
    },

    //批量现行操作
    handleMultRestore(ids, success) {
      if (ids == "") {
        _this.msgError("请先选择数据项");
        return false;
      }
      var url = "/" + this.controller + "/restore/" + ids;
      let _this = this;
      this.$confirm("是否确认启用选中数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function () {
          _this.http.postLoading(_this.loading(), url, {}, function (res) {
            if (typeof success == "function") {
              success(res);
            }
            _this.msgSuccess("现行成功");
          });
          // return _this.http.post(url).then((res) => {
          //     if (res.code == 200) {
          //         if (typeof success == "function") {
          //             success(res);
          //         }
          //         _this.msgSuccess("现行成功");
          //     } else {
          //         _this.msgError("现行失败");
          //     }
          // });
        })
        .catch(() => {});
    },
    // handleMultDelete(ids, success) {
    //      var url = "/" + this.controller + "/delete/" +ids;
    //     let _this = this;
    //     this.$confirm("是否确认删除此行数据项吗?", "警告", {
    //         confirmButtonText: "确定",
    //         cancelButtonText: "取消",
    //         type: "warning",
    //     }).then(function (res) {
    //         _this.http.del(url).then(function () {
    //             if (typeof success == "function") {
    //                 success(res);
    //             } else {
    //                 _this.refresh();
    //             }
    //             _this.msgSuccess("删除成功");
    //         });
    //     });
    // },
    handleRowChange(row) {
      this.selection = [];
      this.selection.push(row);
    },
    setChangeData(row, isChecked) {
      let _this = this;
      if (isChecked) {
        let index = _this.selection.findIndex(
          (x) => x[_this.selectField] == row[this.selectField]
        );
        if (index < 0) {
          _this.selection.push(row);
        }
      } else {
        let index = _this.selection.findIndex(
          (x) => x[_this.selectField] == row[this.selectField]
        );
        if (index >= 0) {
          _this.selection.splice(index, 1);
        }
      }
    },

    //拼装查询条件
    getCondtions(vals, keys) {
      let conditionsArry = [];
      for (let key in vals) {
        let op = keys[key];
        let val = vals[key];
        if (val) {
          conditionsArry.push({
            name: key,
            operate: !op ? "like" : op,
            value: val,
          });
        }
      }
      return conditionsArry && conditionsArry.length > 0
        ? JSON.stringify(conditionsArry)
        : conditionsArry;
    },
    getCondtionsNew() {
      let conditionsArry = [];
      for (let key in this.conditions) {
        let op = this.conditions[key];
        let val = op.value;

        let operate = op.operate;
        let name = op.name;
        if (val) {
          conditionsArry.push({
            name: name || key,
            operate: !operate ? "like" : operate,
            value: val,
          });
        }
      }
      return conditionsArry && conditionsArry.length > 0
        ? JSON.stringify(conditionsArry)
        : conditionsArry;
    },
    // 设置背景颜色
    defaultRowStyle({ row, rowIndex }) {
      let obj = {};
      obj = this.deepMerge(this.rowStyle({ row, rowIndex }), {});

      if (row[this.selectField] == this.singleValue) {
        obj.background = "#E4E9F1";
      }
      return obj;
    },
    clearListData() {
      this.list = [];
      this.isShowEmpty1 = true;
      this.total = 0;
      this.selection = [];
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .pagination {
  margin-top: 10px;
  .el-input__inner {
    height: 22px !important;
    line-height: 22px;
  }
}

.customize-block {
  // border: 1px solid #dfe6ec;
  padding: 3px;
}

.eagle-header {
  position: relative;
}

.el-date-editor.el-input {
  width: 100%;
}

.tag-content {
  overflow-x: auto;
  border: 1px solid #dfe6ec;
  padding: 3px;
  margin-bottom: 10px;
}

.eagle-page-search {
  margin-bottom: 10px;
  // width: calc(100% - 10px);
}

.eagle-page-buttons {
  position: absolute;
  right: 0px;
  bottom: 0px;

  // .el-button {
  //     height: 32px;
  //     padding: 0px 15px;
  // }

  // .el-dropdown {
  //     margin-left: 10px;

  //     .el-icon-arrow-down {
  //         margin-left: 2px;
  //     }
  // }
}

::v-deep .el-table__fixed,
::v-deep .el-table__fixed-right {
  height: calc(100% - 10px) !important;
}

.eagle-page-table {
  button[type="primary"] {
    color: #409eff;
  }

  button[type="success"] {
    color: #67c23a;
  }

  button[type="info"] {
    color: #909399;
  }

  button[type="warning"] {
    color: #e6a23c;
  }

  button[type="danger"] {
    color: #f56c6c;
  }

  .el-button [class*="el-icon-"] + span {
    margin-left: 2px;
    //letter-spacing: 2px;
  }

  .el-table {
    border-top: 1px solid #dfe6ec;
    border-left: 1px solid #dfe6ec;
    border-right: 1px solid #dfe6ec;
  }

  .el-table .cell {
    font-size: 12px;
  }

  .btn-td {
    padding-left: 10px;
  }

  // .el-table__body-wrapper::-webkit-scrollbar {
  //     height: 10px;
  // }
  //   .el-table__body-wrapper::-webkit-scrollbar-thumb {
  //     background-color: #3a90e0;
  //     background-clip: padding-box;
  //     border-radius: 10px;
  //   }
}
</style>
