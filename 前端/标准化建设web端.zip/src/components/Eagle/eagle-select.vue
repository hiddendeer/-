<template>
    <span class="eagle-select">
        <el-form-item :label="label" :label-width="labelWidth" :prop="prop" :required="required" :rules="rulesArray">
            <template v-if="!isEdit">{{ formateDict(dataSource, value, id, name, ',') }}</template>
            <template v-else>
                <el-select :style="inputStyle" v-model="selectValue" :placeholder="placeholderVal" :disabled="disabled" @change="handleChange" :filterable="filterable" :clearable="clearable" :multiple="multiple">
                    <el-option v-for="item in dataSource" :key="item[id]" :label="item[name]" :value="item[id]"></el-option>
                </el-select>
            </template>
        </el-form-item>
    </span>
</template>
<script>
export default {
    name: "eagle-select",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },
        id: {
            type: String,
            default() {
                return "id";
            },
        },
        name: {
            type: String,
            default() {
                return "name";
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        filterable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        multiple: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },

        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        width: {
            type: Number,
            default() {
                return 0;
            },
        },
    },
    data() {
        return {
            selectValue: "",
            placeholderVal: this.placeholder
                ? this.placeholder
                : "请选择" + this.label,
            // rulesArray: [],
            inputStyle: {
                width: "",
            },
        };
    },
    computed: {
        rulesArray: function () {
            let array = [];
            if (this.required && !this.onlyShowRequired) {
                array.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    array.push(x);
                });
            }
            console.log(array);
            return array;
        },
    },
    created() {
        if (this.width) {
            this.inputStyle.width = this.width;
        }
        this.selectValue = this.value;
        // this.setRules();
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
          console.log("newvalue", newvalue)
          console.log("oldvalue", oldvalue)
            this.selectValue = this.value;
        },
    },
    methods: {
        // setRules() {
        //     if (this.required && !this.onlyShowRequired) {
        //         this.rulesArray.push({
        //             required: true,
        //             message: "请选择" + (this.label ? this.label : ""),
        //         });
        //     }
        //     if (this.rules && this.rules.length > 0) {
        //         this.rules.forEach((x) => {
        //             this.rulesArray.push(x);
        //         });
        //     }
        // },
        handleChange(newvalue) {
            let _this = this;
          console.log(newvalue)
            _this.$emit("input", newvalue);
            _this.$emit("change", newvalue);
        },
    },
};
</script>

<style  lang="scss" scoped>
.eagle-select {
    .el-select {
        width: 100%;
    }
}
</style>
