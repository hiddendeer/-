<template>
    <el-form-item :label="label" :prop="prop" :label-width="labelWidth">
        <span class="span_value" :title="value">
            {{ value }}
        </span>
    </el-form-item>

</template>
<script>
export default {
    name: "eagle-label",
    props: {
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },

        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        size: {
            type: String,
            default() {
                return "";
            },
        },

        autosize: {
            type: Boolean,
            default() {
                return false;
            },
        },

        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {};
    },
    created() { },
    watch: {},
    methods: {},
};
</script>
<style scoped lang="scss">
.span_value {
    line-height: 36px;
    cursor: pointer;
}
</style>