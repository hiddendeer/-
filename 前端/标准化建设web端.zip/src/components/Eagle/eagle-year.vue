<template>

    <el-form-item :label="label" :label-width="labelWidth" :prop="prop" :required="required" :rules="rulesArray">
        <template v-if="!isEdit">{{value}}</template>
        <template v-else>
            <el-select v-model="selectValue" :placeholder="placeholderVal" :disabled="disabled" @change="handleChange" :filterable="filterable" :clearable="clearable" :multiple="multiple">
                <el-option v-for="item in dataArray" :key="item" :label="item" :value="item">
                    <span v-if="curryYear==item" style="color:#1890ff">{{item}}</span>
                    <span v-else>{{item}}</span>
                </el-option>
            </el-select>
        </template>
    </el-form-item>
</template>
<script>
import { getCurrentYear } from "@/utils/EageleRMC";
export default {
    name: "eagle-year",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },

        label: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        filterable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        multiple: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },

        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },

        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
    },
    data() {
        return {
            selectValue: "",
            placeholderVal: this.placeholder
                ? this.placeholder
                : "请选择" + this.label,
            rulesArray: [],
            dataArray: [],
            curryYear: getCurrentYear(),
        };
    },
    created() {
        this.selectValue = this.value;
        this.setRules();
        let year = this.curryYear;
        for (var i = year - 5; i < year + 5; i++) {
            this.dataArray.push(i);
        }
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
            this.selectValue = this.value;
        },
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange(newvalue) {
            let _this = this;
            _this.$emit("input", newvalue);
            _this.$emit("change", newvalue);
        },
    },
};
</script>
