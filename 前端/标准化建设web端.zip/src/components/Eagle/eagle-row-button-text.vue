<template>
    <div class="div_button" @click="click">
        <span class="span_text">
            <slot />
        </span>
    </div>
</template>
<script>
export default {
    name: "eagle-row-button-text",
    props: {
        size: { type: String, default: "mini" },
        type: { type: String, default: "primary" },
        imageValue: { type: String, default: "choose" }, //或者upload
    },
    data() {
        return {
            buttonType: "primary",
        };
    },
    watch: {},
    created() {
        let _this = this;

        // if (_this.imageValue == 'choose') {
        //     _this.imageSrc = require("@/assets/images/choose.png");
        // } else {
        //     _this.imageSrc = require("@/assets/images/upload.png");
        // }
        _this.buttonType = _this.type;
    },
    methods: {
        click() {
            this.$emit("click");
        },
    },
};
</script>
<style  scoped lang="scss">
.eagle-row-btn {
    cursor: pointer;
}

.div_button {
    width: 42px;
    height: 24px;
    background: #ffffff;
    border-radius: 2px;
    border: 1px solid #b3d8ff;
    text-align: center;
    cursor: pointer;
    margin-bottom: 5px;
    margin-right: 5px;
    background: #ecf5ff;

    .span_text {
        width: 25px;
        font-size: 12px;
        font-weight: 500;
        color: #409eff;
    }
}
</style>