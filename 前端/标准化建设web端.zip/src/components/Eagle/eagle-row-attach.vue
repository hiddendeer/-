<template>
    <div>
        <div v-if="fileList && fileList.length > 0">
            <div class="upload-list_item-preview single-line" :class="{ 'upload-list_item-preview1': noWidth }"
                v-for="(item, index) in fileList" :key="index" v-if="item" :title="item.name || item.AttName">
                <span class="upload-list_item " @click.stop="handlePreview(item)">
                    <div style="display:inherit;position: relative;">
                        <img class="img_class" style="width:16px;height:16px;position:absolute;top:0px"
                            :src="item | getIcon" alt="">
                        <span style="display:inherit;margin-left:20px;">{{ item.name || item.AttName }}</span>
                    </div>
                </span>
            </div>
        </div>
        <div v-else>--</div>
        <eagle-pdf-dialog :isReport="isReport" ref="PdfDialog"></eagle-pdf-dialog>
    </div>
</template>
<script>
export default {
    name: "eagle-row-attach",
    props: {
        value: {
            type: Array | String,
            default() {
                return "";
            },
        },
        noWidth: {
            type: Boolean,
            default: false,
        },
        isReport: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            fileList: [],
        };
    },
    filters: {
        getIcon: function (item) {
            if (!item) return "";
            let attExt = item.attExt || item.AttExt;
            if (attExt) {
                if (attExt.indexOf(".") != -1) {
                    attExt = attExt.replace(".", "");
                }
            }
            switch (attExt) {
                case "docx":
                case "doc":
                    return require("@/assets/images/file_icon/doc.png");
                case "pptx":
                case "ppt":
                    return require("@/assets/images/file_icon/doc.png");
                case "xls":
                case "excel":
                case "xlsx":
                    return require("@/assets/images/file_icon/xls.png");
                case "pdf":
                    return require("@/assets/images/file_icon/pdf.png");
                case "mp4":
                    return require("@/assets/images/file_icon/mp4.png");
                case "zip":
                    return require("@/assets/images/file_icon/zip.png");
                case "png":
                case "jpeg":
                case "jpg":
                    return require("@/assets/images/file_icon/png.png");
                default:
                    return require("@/assets/images/file_icon/cou.png");
            }
        },
    },
    watch: {
        value(newvalue, oldvalue) {
            if (newvalue) {
                if (typeof newvalue == "string") {
                    var arryFile = JSON.parse(newvalue);
                    this.fileList = arryFile;
                } else {
                    this.fileList = newvalue;
                }
            } else {
                this.fileList = [];
            }
        },
    },
    created() {
        if (this.value) {
            if (typeof this.value == "string") {
                var arryFile = JSON.parse(this.value);
                this.fileList = arryFile;
            } else {
                this.fileList = this.value;
            }

            if (this.fileList) {
                for (var i = 0; i < this.fileList.length; i++) {
                    var attach = this.fileList[i];
                    if (!attach) {
                        attach = {};
                    }
                    var attExt = attach.attExt || attach.AttExt;
                    if (attExt) {
                        if (attExt.indexOf(".") != -1) {
                            attExt = attExt.replace(".", "");
                        }

                        this.fileList[
                            i
                        ].attSrc = require("@/assets/images/file_icon/cou.png");
                        switch (attExt) {
                            case ("docx", "doc"):
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/doc.png");
                                break;
                            case ("pptx", "ppt"):
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/doc.png");
                                break;
                            case ("xls", "excel", "xlsx"):
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/xls.png");
                                break;
                            case "pdf":
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/pdf.png");
                                break;
                            case "mp4":
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/mp4.png");
                                break;
                            case "zip":
                                attthis.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/zip.png");
                                break;
                            case ("png", "jpeg", "jpg"):
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/png.png");
                                break;
                            default:
                                this.fileList[
                                    i
                                ].attSrc = require("@/assets/images/file_icon/cou.png");
                                break;
                        }
                    }
                }
            }
        }
    },
    methods: {
        handlePreview(row) {
            let code = row.attCode || row.AttCode;
            var params = { code: code };
            params.fileName = row.name;
            this.$refs.PdfDialog.show(params);
        },
    },
};
</script>
<style  scoped lang="scss">
.upload-list_item-preview {
    text-align: left;
    cursor: pointer;
    width: 100%;
}

.upload-list_item-preview1 {
    text-align: left;
    cursor: pointer;
    width: auto;
    margin: 0 15px 10px 0;
}

.upload-list_item {
    // display: inline-block;
    white-space: nowrap;
    color: #1b76d1;
}
</style>