<template>
    <!-- <el-col v-if="isFullCol || span < 24" :span="span">
        <el-form-item :label="label" :prop="prop" :label-width="labelWidth" :required="required" :rules="rulesArray">
            <div class="div-choose-container">
                <el-input v-if="isEdit" @blur="onblur" @focus="onFoucs" v-model.trim="inputValue" :placeholder="placeholderValue" :type="type" :disabled="disabled" readonly :size="size" :autosize="autosize" :prefix-icon="prefixicon" :suffix-icon="suffixicon" :rows="rows" clearable :autofocus="autofocus">
                    <i slot="append" @click="onClear" class="el-icon-circle-close delete-icon" v-if="isClear" v-show="showClear"></i>
                    <el-button slot="append" icon="el-icon-s-fold" @click="handleChoose"></el-button>
                </el-input>
                <span v-else>
                    {{ inputValue }}
                </span>

            </div>
        </el-form-item>
    </el-col> -->
    <el-form-item :label="label" :prop="prop" :label-width="labelWidth" :class="required ||onlyShowRequired? 'is-required':''" :required="required" :rules="rulesArray">
        <div class="div-choose-container">
            <el-input v-if="isEdit" @blur="onblur" @focus="onFoucs" v-model.trim="inputValue" :placeholder="placeholderValue" :type="type" :disabled="disabled" readonly :size="size" :autosize="autosize" :prefix-icon="prefixicon" :suffix-icon="suffixicon" :rows="rows" clearable :autofocus="autofocus">
                <i slot="append" @click="onClear" class="el-icon-circle-close delete-icon" v-if="isClear" v-show="showClear"></i>
                <el-button slot="append" icon="el-icon-s-fold" @click="handleChoose"></el-button>
            </el-input>
            <!-- <span v-else>
                {{ inputValue }}
            </span> -->
        </div>
    </el-form-item>
</template>
<script>
export default {
    name: "eagle-choose",
    props: {
        isClear: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: Number | String,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        type: {
            type: String,
            default() {
                return "text";
            },
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        size: {
            type: String,
            default() {
                return "";
            },
        },
        prefixicon: {
            type: String,
            default() {
                return null;
            },
        },
        suffixicon: {
            type: String,
            default() {
                return null;
            },
        },
        rows: {
            type: Number,
            default() {
                return 2;
            },
        },
        autosize: {
            type: Boolean,
            default() {
                return false;
            },
        },
        readonly: {
            type: Boolean,
            default() {
                return false;
            },
        },
        autofocus: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            placeholderValue: "",
            inputValue: "",
            rulesArray: [],
            showClear: false,
        };
    },
    created() {
        this.placeholderValue = this.placeholder
            ? this.placeholder
            : "请选择" + this.label;
        this.inputValue = this.value;
        this.showClear = false;
        this.setRules();
    },
    watch: {
        value(newvalue, oldvalue) {
            this.inputValue = this.value;
        },
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChoose(newvalue) {
            this.$emit("change", newvalue);
        },
        onFoucs() {
            if (this.inputValue) {
                this.showClear = true;
            }
        },
        onblur() {
            setTimeout(() => {
                this.showClear = false;
            }, 500);
        },
        onClear() {
            this.inputValue = "";
            this.showClear = false;
            this.$emit("clearChoose");
        },
    },
};
</script>
<style type="text/css">
/* .div-choose-container {
    position: relative;
} */
.delete-icon {
    position: absolute;
    right: 60px;
    top: 10px;
    cursor: pointer;
}

::v-deep .el-input--small .el-input__inner {
    height: 36px;
    line-height: 36px;
}
</style>