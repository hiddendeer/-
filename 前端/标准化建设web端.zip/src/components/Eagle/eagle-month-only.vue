
<template >
    <el-select v-model="selectValue" :placeholder="placeholderVal" :disabled="disabled" @change="handleChange" :filterable="filterable" :clearable="clearable" :multiple="multiple">
        <el-option v-for="item in dataArray" :key="item" :label="item+'月'" :value="item">
            <span v-if="curryMonth==item" style="color:#1890ff">{{item}}月</span>
            <span v-else>{{item}}月</span>
        </el-option>
    </el-select>
</template>
<script>
import { getCurrentMonth } from "@/utils/EageleRMC";

export default {
    name: "eagle-month-only",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },

        label: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        filterable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        multiple: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },

        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },

        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
    },
    data() {
        return {
            selectValue: "",
            placeholderVal: this.placeholder
                ? this.placeholder
                : "请选择" + this.label,
            rulesArray: [],
            dataArray: [],
            curryMonth: getCurrentMonth(),
        };
    },
    created() {
        this.selectValue = this.value;
        this.setRules();

        for (var i = 1; i < 13; i++) {
            this.dataArray.push(i);
        }
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
            this.selectValue = this.value;
        },
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange(newvalue) {
            let _this = this;
            _this.$emit("input", newvalue);
            _this.$emit("change", newvalue);
        },
    },
};
</script>
