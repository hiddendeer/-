<template>
    <div class="eagle-fold-block">
        <div class="header-block" v-if="$slots.header">
            <slot name="header"></slot>
        </div>
        <el-collapse-transition>
            <div class="from-block" v-if="show">
                <slot />
            </div>
        </el-collapse-transition>
        <div class="block-control">
            <div v-if="!show" @click="show = !show"><i class="el-icon-caret-bottom"></i><span> {{ showTitle }}</span>
            </div>
            <div @click="show = !show" v-else><i class="el-icon-caret-top"></i><span> {{ hideTitle }}</span></div>
        </div>
    </div>

</template>
<script>
export default {
    name: "eagle-fold-block",
    props: {
        title: {
            type: String,
            default() {
                return "";
            },
        },
        showTitle: {
            type: String,
            default() {
                return "显示详情";
            },
        },
        hideTitle: {
            type: String,
            default() {
                return "隐藏详情";
            },
        },
    },
    data() {
        return {
            show: false,
        };
    },
    created() { },
    watch: {},
    methods: {},
};
</script>
<style scoped lang="scss">
.eagle-fold-block {
    border: 1px solid #ebebeb;
    border-radius: 3px;
    transition: 0.2s;

    // box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
    .header-block {
        padding: 7px 15px 7px;
        min-height: 40px;
        line-height: 28px;
        border-bottom: 1px solid #e6ebf5;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        background: #fff;
    }

    .from-block {
        background-color: #fff;
    }

    .block-control {
        border-top: 1px solid #eaeefb;
        height: 44px;
        box-sizing: border-box;
        background-color: #fff;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        text-align: center;
        margin-top: -1px;
        color: #d3dce6;
        cursor: pointer;
        position: relative;
        line-height: 44px;
        transition: 0.3s;
    }

    .block-control:hover {
        color: #409eff;
        background-color: #f9fafc;
    }
}
</style>