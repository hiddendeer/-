<template>
    <div class="eagle-image-hidden">
        <el-upload class="avatar-uploader" :action="uploadUrl" :show-file-list="false" :on-success="handleAvatarSuccess" :headers="headers" :before-upload="beforeAvatarUpload">
            <div>添加图片</div>
        </el-upload>
    </div>
</template>
<script>
import { getToken } from "@/utils/auth";
export default {
    name: "eagle-image-hidden",
    props: {
        index: {
            type: Number,
            default() {
                return 0;
            },
        },
        subIndex: {
            type: Number,
            default() {
                return 0;
            },
        },
        imgData: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String,
            default() {
                return "";
                //return "http://139.196.228.32:9000/eagle/477e8e0439168c728a60fbb1e436443f/20211020/916ca76a-26c3-47b7-bedf-5a61a4282187.jpg;http://139.196.228.32:9000/eagle/477e8e0439168c728a60fbb1e436443f/20211020/876d9969-e485-443f-b5c7-49f7b2f21fcf.jpg;http://139.196.228.32:9000/eagle/477e8e0439168c728a60fbb1e436443f/20211020/f20ca645-46ab-4ee3-977d-2496ca823f91.jpg";
            },
        },
    },
    data() {
        return {
            uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload", // 上传的图片服务器地址
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            imageUrl: "",
        };
    },

    watch: {
        value(nval, oval) {
            if (nval != oval) {
                this.imageUrl = !nval ? "" : this.value;
            }
        },
    },
    created() {},
    methods: {
        handleAvatarSuccess(res, file) {
            if (res.code == 200) {
                this.imageUrl = res.data.filePath;
                let imgData = {
                    Url: res.data.filePath,
                    Name: res.data.attName,
                    Width: 200,
                    Height: 0,
                };
                let retData = {
                    index: this.index,
                    subIndex: this.subIndex,
                    data: JSON.stringify(imgData),
                };
                this.$emit("imgChanged", retData);
            } else {
                this.$message.error("图片上传失败!");
            }
        },
        beforeAvatarUpload(file) {
            const isJPG = file.type === "image/jpeg";
            const isPNG = file.type === "image/png";
            const isHEIC = file.type === "image/heic";
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isPNG && !isJPG && !isHEIC) {
                this.$message.error("上传头像图片只能是 JPG或PNG 格式!");
                return false;
            }
            // if (!isJPG) {
            //     this.$message.error("上传图片只能是 JPG 格式!");
            // }
            // if (!isLt2M) {
            //     this.$message.error("上传图片大小不能超过 2MB!");
            // }
            //
            //return isJPG && isPNG && isLt2M && isHEIC;
            return true;
        },
    },
};
</script>

<style>
.eagle-image-hidden .el-upload {
    width: 100%;
    text-align: left;
}
</style>
