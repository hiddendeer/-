<template>
    <div class="head-class" :style="{background:bgColor}">
        <div class="head-icon">
            <slot />
        </div>
        <div class="head-content">
            <div class="head-num"> {{value}}</div>
            <div class="head-title"> {{title}}</div>
        </div>
    </div>
</template>
<script>
export default {
    name: "eagle-head-cart",
    props: {
        value: {
            type: String | Number,
            default() {
                return "";
            }
        },
        bgColor: {
            type: String,
            default() {
                return "red";
            }
        },
        title: {
            type: String,
            default() {
                return "";
            }
        }
    },
    data() {
        return {};
    },
    created() {},
    watch: {}
};
</script>
<style scoped>
.head-class {
    width: 200px;
    height: 60px;
    display: flex;
    border-radius: 5px;
    margin: 5px;
    color: #fff;
    justify-content: space-between;
    cursor: pointer;
}
.head-icon {
    font-size: 40px;
    color: #fff;
    line-height: 60px;
    width: 40px;
    text-align: center;
    margin-left: 5px;
}
.head-content {
    margin-right: 10px;
}
.head-num {
    line-height: 40px;
    height: 30px;
    font-size: 30px;
    text-align: center;
}
.head-title {
    line-height: 30px;
    font-size: 14px;
}
</style>