<template>
    <el-form-item :label="label" :prop="prop" :label-width="labelWidth" :required="required" :rules="rulesArray">
        <div class="eagle-image-name">
            <div v-if="isEdit || (imageUrls && imageUrls.length>0)" class="img-pannel">
                <div v-for="(item,index) in imageUrls" :key="index" class="img-content">
                    <template v-if="showImgCount<=0 || index<showImgCount">
                        <img :src="item.path" class="avatar" />
                        <span class="el-upload-list__item-actions">
                            <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(item.path)">
                                <i class="el-icon-zoom-in"></i>
                            </span>
                            <span v-if="!disabled && isEdit" class="el-upload-list__item-delete" @click="imageUrls.splice(index,1)">
                                <i class="el-icon-delete"></i>
                            </span>
                        </span>
                        <el-input style="width: 120px;" v-model="item.name" placeholder="请输入图片名称"></el-input>
                    </template>
                </div>
                <div v-if="imageUrls.length<count  && isEdit && !disabled " class="img-content">
                    <el-upload class="avatar-uploader" ref="elUpload" :limit="count" :multiple="true" :action="uploadUrl" :show-file-list="false" :on-remove="handleRemove" :on-change="handleChange" :on-error="handleError" :on-success="handleAvatarSuccess" :headers="headers" :before-upload="beforeAvatarUpload">
                        <i class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </div>
            </div>
            <div v-else-if="showDefaultImg && isEdit==false" class="img-pannel">
                <div class="img-content">
                    <img :src="defaultUrl" class="avatar" />
                </div>
            </div>
        </div>
        <el-dialog title="图片预览" v-dialogDrag :visible.sync="dialogVisible" width="500px" append-to-body show-close custom-class="imag-dialog">
            <div style="background: rgba(0, 0, 0, 0.7)">
                <img width="100%" :src="dialogImageUrl" alt />
            </div>
        </el-dialog>
    </el-form-item>
</template>
<script>
import { getToken } from "@/utils/auth";
import { log } from "mathjs";
export default {
    name: "eagle-image-name",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },

        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        required: {
            type: Boolean,
            default() {
                return false;
            },
        },
        count: {
            type: Number,
            default() {
                return 3;
            },
        },
        value: {
            type: Array | String,
            default() {
                return [];
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        showDefaultImg: {
            type: Boolean,
            default() {
                return false;
            },
        },
        showImgCount: {
            type: Number,
            default() {
                return 0;
            },
        },
    },
    data() {
        return {
            uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload", // 上传的图片服务器地址
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            imageUrls: [],
            imageNames: [],
            dialogImageUrl: "",
            dialogVisible: false,
            rulesArray: [],
            defaultUrl: require("@/assets/images/no-img.png"),
            //imageUrl: this.value,
        };
    },

    watch: {
        value(newvalue, oldvalue) {
            if (newvalue.length == oldvalue.length) return;
            console.log("http======3>", newvalue);
            if (newvalue) {
                this.isInit = false;
                if (typeof newvalue == "string") {
                    var arryFile = JSON.parse(newvalue);
                    this.imageUrls = arryFile;
                } else {
                    this.imageUrls = newvalue;
                }
                console.log("http=======1>", this.imageUrls);
            } else {
                this.isInit = true;
                this.imageUrls = [];
                console.log("http=======2>", this.imageUrls);
            }
        },
        imageUrls(newvalue, oldvalue) {
            this.$emit("input", newvalue);
        },
    },
    created() {
        if (this.value) {
            if (typeof this.value == "string") {
                var arryFile = JSON.parse(this.value);
                this.imageUrls = arryFile;
            } else {
                this.imageUrls = JSON.parse(JSON.stringify(this.value));
            }
        }
        this.setRules();
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请上传" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleRemove(file, fileList) {
            console.log(file, fileList);
        },
        handleError(err, file, fileList) {},
        handleChange(event, file, fileList) {},
        handlePictureCardPreview(url) {
            this.dialogImageUrl = url;
            this.dialogVisible = true;
        },
        handleAvatarSuccess(res, file) {
            if (res.code == 200) {
                console.log(res.data);
                let newvalue2 = { name: "", url: "" };
                newvalue2.name = res.data.attName.substring(
                    0,
                    res.data.attName.lastIndexOf(".")
                );
                newvalue2.path =res.data.filePath;
                this.imageUrls.push(newvalue2);
            } else {
                this.$message.error("图片上传失败!");
            }
        },
        beforeAvatarUpload(file) {
            const isJPG = file.type === "image/jpeg";
            const isPNG = file.type === "image/png";
            const isHEIC = file.type === "image/heic";
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isPNG && !isJPG && !isHEIC) {
                this.$message.error("上传头像图片只能是 JPG或PNG 格式!");
                return false;
            }
            return true;
        },
    },
};
</script>
<style lang="scss" scoped>
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
.avatar-uploader .el-upload:hover {
    border-color: #409eff;
}
.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    background-color: #fbfdff;
    border: 1px dashed #c0ccda;
    border-radius: 6px;
    width: 110px;
    height: 110px;
    line-height: 110px;
    text-align: center;
}
.avatar {
    width: 110px;
    height: 110px;
    display: block;
    border-radius: 6px;
    padding: 2px;
    background: #fff;
}
.img-pannel {
    display: flex;

    .img-content {
        margin: 5px;
        display: flex;
        position: relative;
        display: block;
        text-align: center;
        .icon {
            opacity: 0.5;
            width: 101px;
            background-color: #d9d9d9;
            position: absolute;
            bottom: 0px;
            color: red;
            cursor: pointer;
        }
    }
}
.img-content .el-upload-list__item-actions {
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    cursor: default;
    text-align: center;
    color: #fff;
    opacity: 0;
    font-size: 20px;
    background-color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    line-height: 110px;
    border-radius: 6px;
}

.img-content .el-upload-list__item-actions:hover {
    opacity: 1;
}
.img-content .el-upload-list__item-actions:hover span {
    display: inline-block;
}
.img-content .el-upload-list__item-actions .el-upload-list__item-delete {
    position: static;
    font-size: inherit;
    color: inherit;
    margin-left: 3px;
}
.imag-dialog .el-dialog__body {
    padding: 0;
}
</style>