<template>
  <div>
    <el-dialog
      :title="title"
      v-dialogDrag
      :visible.sync="open"
      :width="width"
      append-to-body
      show-close
      :close-on-click-modal="false"
      :before-close="cancel"
    >
       <eagle-block border>
        <el-form
          ref="forms"
          :model="formData"
          :rules="rules"
          label-width="80px"
        >
          <el-form-item
            v-if="radioList.length > 0"
            label="上传类型"
            class="radio-box"
          >
            <el-radio-group :value="formData.fileType">
              <el-radio
                :label="item.dictCode"
                :key="item.dictCode"
                v-for="item in radioList"
                @click.native.prevent="changeHandle(item.dictCode)"
                >{{ item.label }}</el-radio
              >
            </el-radio-group>
          </el-form-item>
          <el-form-item label="上传" class="upload-container" prop="fileUrl">
            <el-upload
              ref="upload"
              :limit="count"
              :accept="accept"
              :headers="headers"
              multiple
              :action="uploadUrl"
              auto-upload
              :disabled="isUploading"
              :on-progress="handleFileUploadProgress"
              :on-success="handleFileSuccess"
              :on-exceed="onExceed"
              :before-upload="handleBeforeUpload"
              :on-error="handleUploadError"
              :on-remove="handleRemove"
              drag
            >
              <el-input v-show="false" v-model="formData.fileUrl"></el-input>
              <i class="el-icon-upload"></i>
              <div class="el-upload__text">
                将文件拖到此处，或<em>点击上传</em>
              </div>
              <div class="el-upload__text">支持文件类型： {{ accept }}</div>
              <div class="el-upload__text">
                单个文件最大不超过5MB且最多可同时上传10个文件
              </div>
              <div class="el-upload__tip" slot="tip"></div>
            </el-upload>
          </el-form-item>
        </el-form>
      </eagle-block>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="saveLoading" @click="submitFileForm"
          >保存</el-button
        >
        <el-button @click="cancel">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 导出模板   导入数据操作工具类
import { getToken } from "@/utils/auth";
import { dangerSave } from "@/api/libTemp/libTemp.js";
// import { download } from "@/utils/request";
// import { postData, getInfo, putData } from "@/api/http";
export default {
  name: "EagleDialogRadioExce",
  props: {
    // 上传文件大小限制(MB)
    fileSize: {
      type: Number,
      default: 500,
    },
    width: {
      type: String,
      default() {
        return "600px";
      },
    },
    title: {
      type: String,
      default() {
        return "";
      },
    },
    count: {
      type: Number,
      default: 10,
    },
    accept: {
      type: String,
      default: ".doc,.docx,.pdf,.xlsx,.xls,.zip,.PDF,.DOC,.DOCX,.XLS,.XLSX",
    },
    radioList: {
      type: Array,
      default() {
        return [];
      },
    },
    fileType: {
      type: String,
      default: "",
    },
    saveUrl: { type: String, default: "" },
  },
  data() {
    return {
      rules: {
        fileUrl: [{ required: true, message: "请上传文件", trigger: "change" }],
      },
      isUploading: false,
      formData: {
        fileUrl: "",
        fileType: "",
      },
      fileList: [],
      uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload", // 上传的服务器地址
      headers: {
        Authorization: "Bearer " + getToken(),
      },
      saveLoading: false,
      open: false,
    };
  },
  watch: {
    fileList: {
      handler(val, oldVal) {
        this.formData.fileUrl = val
          ? JSON.parse(JSON.stringify(val)).toString()
          : "";
      },
      deep: true,
    },
    fileType: {
      handler(val) {
        this.formData.fileType = val;
      },
      immediate: true,
    },
  },
  methods: {
    changeHandle(v) {
      if (this.fileList.length > 0) {
        this.$confirm("切换类型将清空以上传内容", "请注意！", {
          confirmButtonText: "继续",
          cancelButtonText: "返回",
          type: "warning",
        })
          .then(() => {
            this.$refs.upload.clearFiles();
            this.fileList = [];
            this.formData.fileType = v;
          })
          .catch(() => {});
      } else {
        this.formData.fileType = v;
      }
    },
    // 上传前校检格式和大小
    handleBeforeUpload(file) {
      //校验文件名称长度
      if (file.name.length > 100) {
        this.$message.error("文件名称最大100个字符");
        return false;
      }
      //校验文件格式
      const type = file.type.split("/")[1];
      let fileType = "";
      let png = "png";
      let jpeg = "jpeg";
      let doc = "msword";
      let docx = "vnd.openxmlformats-officedocument.wordprocessingml.document";
      let pdf = "pdf";
      let xlsx = "vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      let xls = "vnd.ms-excel";
      let zip = "x-zip-compressed";
      switch (type) {
        case xlsx:
          fileType = "xlsx";
          break;
        case xls:
          fileType = "xls";
          break;
        case pdf:
          fileType = "pdf";
          break;
        case doc:
          fileType = "doc";
          break;
        case docx:
          fileType = "docx";
          break;
        case png:
          fileType = "png";
          break;
        case jpeg:
          fileType = "jpeg";
          break;
        case zip:
          fileType = "zip";
          break;
        default:
          break;
      }
      let acceptIncludes = this.accept
        .replace(/\.|\s/g, "")
        .replace(/jpg/g, "jpeg")
        .split(",")
        .includes(fileType);
      if (!acceptIncludes) {
        this.$message.warning("上传文件类型有误，请重新上传");
        return false;
      }

      // 校检文件大小
      if (this.fileSize) {
        const isLt = file.size / 1024 / 1024 < this.fileSize;
        if (!isLt) {
          this.$message.error(`上传文件大小不能超过 ${this.fileSize} MB!`);
          return false;
        }
      }
      return true;
    },
    onExceed(files, fileList) {
      this.$message.warning("单次上传文件数量已超过最大限制");
    },
    // 文件上传中处理
    handleFileUploadProgress(event, file, fileList) {
      this.isUploading = true;
    },
    handleRemove(file) {
      this.fileList = this.fileList.filter(item => item.fileName !== file.name)
    },
    // 文件上传成功处理
    handleFileSuccess(response, file, fileList) {
      if (response.code === 200) {
        this.isUploading = false;
        let data = response.data || {};
        let doc = {
          fileName: data.attName,
          fileCode: data.attCode,
          fileType: this.formData.fileType,
          state: 0,
          status: 0,
        };
        this.fileList = [...this.fileList, doc];
      } else {
        this.$refs.upload.handleRemove(file);
        this.isUploading = false;
        this.$message.error("附件上传失败");
      }
    },
    handleUploadError() {
      this.$message.error("附件上传失败");
      this.isUploading = false;
    },
    // 关闭按钮
    cancel() {
      this.$refs.upload.clearFiles();
      this.$refs.upload.$parent.resetField();
      this.fileList = [];
      this.open = false;
    },
    show() {
      this.open = true;
    },
    onSave() {
      this.saveLoading = true;
      const timer = setTimeout(() => {
        this.saveLoading = false;
        Message.error("请求超时");
      }, 100000);
      this.http
        .post(this.saveUrl, this.fileList)
        .then((res) => {
          if (res.code === 200) {
            this.saveLoading = false;
            clearTimeout(timer);
            this.$emit("refresh");
            this.cancel();
          } else {
            this.saveLoading = false;
            clearTimeout(timer);
          }
        })
        .catch(() => {
          this.saveLoading = false;
          clearTimeout(timer);
        });
    },
    // 提交上传文件
    submitFileForm() {
      this.$refs.forms.validate((valid) => {
        if (valid) this.onSave();
      });
    },
  },
};
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.radio-box {
  margin-bottom: 20px;
  .el-radio-group {
    margin-bottom: -10px;
    .el-radio {
      margin-bottom: 10px;
    }
  }
}
::v-deep .upload-container {
  .el-upload {
    width: 400px;
  }
  .el-upload-dragger {
    height: auto;
  }
}
</style>
