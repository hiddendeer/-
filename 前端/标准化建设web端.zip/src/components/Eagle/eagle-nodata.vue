<template>
    <div class="zwsj" style="width:100%">
        <img :src="require('@/assets/images/zwsj.png')" :width="imgW" :height="imgH" style="color: #999;font-size: 12px;margin-top: 20px" />
        <!-- <div style="color: #999;font-size: 12px;margin-top: 5px">{{text}}</div> -->
    </div>
</template>

<script>
export default {
    name: "ecs-nodata",
    props: {
        icon: {
            require: true,
        },
        imgW: {
            default: "180px",
        },
        imgH: {
            default: "240px",
        },
    },
};
</script>

<style scoped>
.zwsj {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
}
</style>