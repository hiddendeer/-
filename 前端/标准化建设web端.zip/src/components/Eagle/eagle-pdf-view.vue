<template>
    <div class="pdf-dialog">
        <!-- <div v-if="!checkIsVideo(url)">

            <pdf v-for="i in pageTotalNum" v-if="i<=pageSize*pageIndex" :id="'pdf_'+i" :key="i" :src="url" :page="i">
            </pdf>
            <div v-if="pageIndex<pageCount" style="text-align: center;margin-top: 10px;margin-bottom: 10px;">
                <el-button type="primary" @click.stop="pageIndex=pageIndex+1" class="mr10"> 加载更多</el-button>
            </div>

        </div> -->
        <!-- <eagle-video v-if="checkIsVideo(url)" :videoSrc="url" ref="eagleVideo"></eagle-video> -->
        <!-- <template v-if="!checkIsVideo(url)">
            <iframe height="100%" width="100%" id="pdfId" name="pdfId" :src="htmlUrl" frameboder="0"></iframe>

        </template>
        <template v-else>
            <iframe height="100%" width="100%" id="videoId" name="videoId" :src="htmlUrl" frameboder="0"></iframe>

        </template> -->
        <iframe height="100%" style="min-height:550px;" width="100%" id="videoId" name="videoId" :src="htmlUrl" frameboder="0"></iframe>
    </div>
</template>

<script>
export default {
    name: "eagle-pdf-view",
    props: {
        url: {
            type: String,
            default: "",
        },
    },
    data() {
        return {
            pageNum: 1,
            pageTotalNum: 1,
            pageRotate: 0,
            loadedRatio: 0,
            curPageNum: 0,
            pageIndex: 1,
            pageSize: 10,
            pageCount: 1,
        };
    },
    watch: {
        // url(newvalue, oldvalue) {
        //     this.src = newvalue;
        //     let isVideo = this.checkIsVideo(newvalue);
        //     if (!isVideo) {
        //         this.loadPdf();
        //     }
        // },
    },
    computed: {
        htmlUrl() {
            let isVideo = this.checkIsVideo(this.url);
            if (isVideo) {
                return "/pagehelp/ckplayer/viewer.html?file=" + this.url;
            } else {
                return "/pagehelp/pdfjs/web/viewer.html?file=" + this.url;
            }
        },
    },
    beforeMount() {
        this.pageTotalNum = 1;
    },
    mounted() {
        if (this.url) {
            // let isVideo = this.checkIsVideo(this.url);
            // if (!isVideo) {
            //     this.loadPdf();
            // }
        }
    },
    methods: {
        // loadPdf() {
        //     var _this = this;
        //     if (this.url) {
        //         var loadingTask = pdf.createLoadingTask(this.url);
        //         loadingTask.promise
        //             .then((pdf) => {
        //                 _this.pageTotalNum = pdf._pdfInfo.numPages;
        //                 _this.pageCount =
        //                     _this.pageTotalNum % _this.pageSize > 0
        //                         ? parseInt(
        //                               _this.pageTotalNum / _this.pageSize
        //                           ) + 1
        //                         : _this.pageTotalNum / _this.pageSize;
        //             })
        //             .catch((error) => {});
        //     }
        // },

        checkIsVideo(url) {
            if (url) {
                if (url.indexOf("avi") > -1 || url.indexOf("mp4") > -1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
        // 上一页函数，
        prePage() {
            var page = this.pageNum;
            page = page > 1 ? page - 1 : this.pageTotalNum;
            this.pageNum = page;
        },
        // 下一页函数
        nextPage() {
            var page = this.pageNum;
            page = page < this.pageTotalNum ? page + 1 : 1;
            this.pageNum = page;
        },
        // 页面顺时针翻转90度。
        clock() {
            this.pageRotate += 90;
        },
        // 页面逆时针翻转90度。
        counterClock() {
            this.pageRotate -= 90;
        },
        // 页面加载回调函数，其中e为当前页数
        pageLoaded(e) {
            this.curPageNum = e;
        },
        // 其他的一些回调函数。
        pdfError(error) {
            console.error(error);
        },
        handleClose() {
            // this.$refs.eagleVideo.handleClose();
            window.frames["videoId"].location.href = "";
        },
    },
};
</script>

<style lang="scss">
.pdf-btn {
    position: fixed;
    bottom: 20rpx;
    width: 100%;
}
.tools {
    display: flex;
    justify-content: center;
    margin-top: 10px;
    margin-bottom: 10px;
}
.tools .page {
    margin-top: 10px;
    margin-right: 10px;
    font-size: 18px;
}
.pdf-dialog {
    min-height: 550px;
}
</style>
