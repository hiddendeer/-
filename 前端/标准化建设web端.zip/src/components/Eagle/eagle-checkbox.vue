<template>
    <!-- <el-col :span="span" v-if=" isFullCol || span<24">
        <el-form-item :label="label" :label-width="labelWidth" :required="required" :prop="prop" :rules="rulesArray">
            <el-checkbox v-model="checked" @change="handleChange" :disabled="disabled"></el-checkbox>
        </el-form-item>
    </el-col> -->
    <el-form-item :label="label" :label-width="labelWidth" :required="required" :prop="prop" :rules="rulesArray">
        <el-checkbox v-model="checked" @change="handleChange" :disabled="disabled"></el-checkbox>
    </el-form-item>
</template>
<script>
export default {
    name: "eagle-checkbox",
    props: {
        isFullCol: {
            type: Boolean,
            default() {
                return true;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            checked: this.value,
            rulesArray: [],
        };
    },
    created() {
        if (this.value) {
            this.checked = this.value;
        }
        this.setRules();
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
            this.checked = newvalue;
        },
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange() {
            this.$emit("input", this.checked);
            this.$emit("change", this.checked);
        },
    },
};
</script>
