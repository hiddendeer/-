<template>
    <el-cascader v-model="currentValue" :options="options" @change="handleChange">
        <template slot-scope="{ node, data }">
            <span>{{ data.label }}</span>
            <span v-if="!node.isLeaf"> ({{ data.children.length }}) </span>
        </template>
    </el-cascader>
</template>

<script>
import { area } from "@/utils/area.js";
export default {
    name: "eagle-distpicker",
    props: {
        value: {
            type: Array,
            default: () => [],
        },
    },
    data() {
        return {
            options: area,
            currentValue: this.value,
        };
    },
    computed: {},
    watch: {
        value(n, o) {
            this.currentValue = n;
        },
    },
    mounted() {},
    beforeDestroy() {},
    methods: {
        setRules() {
            if (this.required) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange(value) {
            this.currentValue = value;
            this.$emit("input", value);
        },
    },
};
</script>

