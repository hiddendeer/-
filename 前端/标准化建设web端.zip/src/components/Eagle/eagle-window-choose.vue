<template>
  <div class="eagle-window-choose">
    <div v-if="!customize" class="child">
      <div class="tag-group" v-if="!single && choosedBlock">
        <span class="success">当前选择的是:</span>
        <div class="tag-content" :style="{ height: single ? '36px' : '72px' }">
          <el-tag
            size="medium"
            style="margin-right: 4px"
            v-for="(tag, index) in selection"
            :key="tag[selectField]"
            closable
            @close="selectionRemove(tag, index)"
            :type="tag.type"
            >{{ tag[selectTextField] }}</el-tag
          >
        </div>
      </div>
      <div border class="mt10">
        <div class="eagle-page-search" :style="{ 'margin-right': searchRight }">
          <slot name="slot-search"> </slot>
        </div>
        <div class="eagle-page-buttons">
          <slot name="slot-buttons"></slot>
        </div>
        <div class="eagle-page-table">
          <el-table
            :show-header="showHeader"
            :max-height="tableHeight"
            ref="multipleTable"
            v-loading="loading"
            :data="list"
            @row-click="rowClick"
            @selection-change="handleSelectionChange"
            @select="handleCheckBoxChange"
            @select-all="handleCheckBoxAllChange"
          >
            <el-table-column
              fixed="left"
              type="selection"
              width="45px"
              align="center"
            />
            <el-table-column
              v-if="showOrder"
              label="序号"
              fixed
              align="center"
              width="50px"
            >
              <template slot-scope="scope">
                <span>{{ scope.$index + 1 }}</span>
              </template>
            </el-table-column>
            <slot name="slot-table"></slot>
            <el-table-column
              label="操作"
              fixed="right"
              align="center"
              v-if="showBtn"
              class-name="small-padding fixed-width table-button"
              :width="btnWidth"
            >
              <template slot-scope="scope">
                <slot name="slot-row-buttons" :row="scope.row" />
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div v-else-if="customize" class="child">
      <slot :data="list"> </slot>
      <div class="customize-page"></div>
    </div>
    <el-pagination
      v-show="total > 0 && !noPage"
      :total="total"
      :current-page="query.params.pageNum"
      :page-size="query.params.pageSize"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :page-sizes="[10, 20, 30, 50, 100]"
      :layout="layout"
    >
    </el-pagination>
  </div>
</template>
<script>
// import { get, del } from "@/api/http";
export default {
  name: "eagle-window-choose",
  props: {
    tableHeight: { type: String | Number, default: "11000px" },
    single: { type: Boolean, default: false },
    choosedBlock: { type: Boolean, default: true },
    selectField: { type: String, default: "code" },
    idField: { type: String, default: "id" },
    selectTextField: { type: String, default: "name" },
    btnWidth: { type: String, default: "120px" },
    showBtn: { type: Boolean, default: false },
    customize: { type: Boolean, default: false },
    noPage: { type: Boolean, default: false },
    showOrder: { type: Boolean, default: true },
    showHeader: { type: Boolean, default: true },
    autoCompany: { type: Boolean, default: true },
    controller: { type: String, default: "" },
    pageUrl: { type: String, default: "" },
    pageSize: { type: Number, default: 20 },
    searchRight: { type: String, default: "10px" },
    layout: {
      type: String,
      default: "total, sizes, prev, pager, next, jumper",
    },
    queryParams: {
      type: Object,
      default: function () {
        return {};
      },
    },
    conditions: {
      type: Object,
      default: function () {
        return {};
      },
    },
  },
  data() {
    return {
      selection: [],
      // 遮罩层
      loading: false,
      total: 0,
      list: [],
      pageParams: {
        pageNum: 1,
        pageSize: 20,
      },
      query: {
        url: "",
        params: {},
      },
    };
  },
  created() {
    this.pageParams.pageSize = this.pageSize;
  },
  watch: {},
  methods: {
    setInitCodes(value, names) {
      var _this = this;
      this.selection = [];
      if (value) {
        let arry = value.split(",");
        let arryName = [];
        if (names) {
          arryName = names.split(",");
        }
        for (let i = 0; i < arry.length; i++) {
          var data = {};
          _this.$set(data, this.selectField, arry[i]);
          _this.$set(data, this.selectTextField, arryName[i]);
          this.selection.push(data);
        }
      }
    },
    dealParams(config) {
      if (config && config.url) {
        this.query.url = config.url;
      } else {
        this.query.url = this.pageUrl
          ? this.pageUrl
          : this.controller + "/getPageData";
      }
      if (config) {
        if (config.params) {
          this.query.params = this.deepMerge(config.params, this.pageParams);
        } else {
          this.query.params = this.deepMerge(this.queryParams, this.pageParams);
        }
        if (config.conditions) {
          this.query.params.conditions = config.conditions;
        } else {
          this.query.params.conditions = this.getCondtionsNew();
        }
      } else {
        this.query.params = this.deepMerge(this.queryParams, this.pageParams);
        this.query.params.conditions = this.getCondtionsNew();
      }
    },
    getCondtionsNew() {
      let conditionsArry = [];
      for (let key in this.conditions) {
        let op = this.conditions[key];
        let val = op.value;
        let operate = op.operate;
        if (val) {
          conditionsArry.push({
            name: key,
            operate: !operate ? "like" : operate,
            value: val,
          });
        }
      }
      return conditionsArry && conditionsArry.length > 0
        ? JSON.stringify(conditionsArry)
        : conditionsArry;
    },
    handleCurrentChange(pageNum) {
      this.query.params.pageNum = pageNum;
      this.pageParams.pageNum = pageNum;
      this.getListData();
    },
    handleSizeChange(size) {
      this.query.params.pageNum = 1;
      this.pageParams.pageNum = 1;
      this.pageParams.pageSize = size;
      this.query.params.pageSize = size;
      this.getListData();
    },

    rowClick(row) {
      let _this = this;
      if (_this.single) {
        this.$refs.multipleTable.clearSelection();
        this.$refs.multipleTable.toggleRowSelection(row);
        _this.selection = [];
        _this.selection.push(row);
      } else {
        var checked =
          _this.selection.findIndex(
            (x) => x[_this.selectField] == row[_this.selectField]
          ) < 0;
        this.$refs.multipleTable.toggleRowSelection(row, checked);
        _this.setChangeData(row, checked);
      }
    },
    handleSelectionChange(selection) {
      this.$emit("getSelectionVal", selection);
    },
    getSelection() {
      return this.selection;
    },
    selectionRemove(item, index) {
      this.selection.splice(index, 1);
      this.initCheckList();
    },
    handleCheckBoxChange(selectAllRow, currRow) {
      this.$refs.multipleTable.toggleRowSelection(currRow);
      this.rowClick(currRow);
    },
    handleCheckBoxAllChange(selectRows) {
      if (this.single) {
        this.$refs.multipleTable.clearSelection();
      } else {
        this.selection = selectRows;

        //  this.selection.forEach
      }
    },
    setChangeData(row, isChecked) {
      let _this = this;
      if (isChecked) {
        let index = _this.selection.findIndex(
          (x) => x[_this.selectField] == row[this.selectField]
        );
        if (index < 0) {
          _this.selection.push(row);
        }
      } else {
        let index = _this.selection.findIndex(
          (x) => x[_this.selectField] == row[this.selectField]
        );
        if (index >= 0) {
          _this.selection.splice(index, 1);
        }
      }
    },
    search(config) {
      this.pageParams.pageNum = 1;
      this.dealParams(config);
      this.getListData();
    },
    refresh(config) {
      this.pageParams.pageNum = 1;
      this.getListData();
    },
    //拼装查询条件
    getCondtions(vals, keys) {
      let conditions = [];
      for (let key in vals) {
        let op = keys[key];
        let val = vals[key];
        if (val) {
          conditions.push({
            name: key,
            operate: !op ? "like" : op,
            value: val,
          });
        }
      }
      return conditions && conditions.length > 0
        ? JSON.stringify(conditions)
        : conditions;
    },
    getListData() {
      let enterpriseCode = this.$route.query.enterpriseCode;
      if (enterpriseCode && this.autoCompany) {
        if (!this.query.params.companyCode) {
          this.$set(this.query.params, "companyCode", enterpriseCode);
        }
      }
      this.loading = true;
      let _this = this;
      this.http
        .get(this.query.url, this.query.params)
        .then((res) => {
          this.loading = false;
          if (res.code == 200) {
            _this.list = res.data;
            this.initCheckList();
            _this.total = res.total;
            _this.loading = false;
          }
        })
        .catch(() => {
          this.loading = false;
        });
    },
    initCheckList() {
      var _this = this;
      if (this.list && this.list.length > 0) {
        this.$nextTick(function () {
          this.list.forEach((row) => {
            let index = _this.selection.findIndex(
              (x) => x[_this.selectField] == row[this.selectField]
            );
            if (index >= 0) {
              this.$refs.multipleTable.toggleRowSelection(row, true);
            } else {
              this.$refs.multipleTable.toggleRowSelection(row, false);
            }
          });
        });
      }
      this.isInit = false;
    },
    //批量删除操作
    handleMultDelete(ids, success) {
      if (ids == "") {
        _this.msgError("请先选择数据项");
        return false;
      }
      var url = "/" + this.controller + "/delete/" + ids;
      let _this = this;
      this.$confirm("是否确认删除选中数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(function (res) {
        _this.http.delLoading(_this.loading(), url, {}, function (res) {
          if (typeof success == "function") {
            success(res);
          } else {
            _this.refresh();
          }
          _this.msgSuccess("删除成功");
        });
        // _this.http.del(url).then(function () {
        //     if (typeof success == "function") {
        //         success(res);
        //     } else {
        //         _this.refresh();
        //     }
        //     _this.msgSuccess("删除成功");
        // });
      });
    },
    //批量废止操作
    handleMultDisable(ids, success) {
      if (ids == "") {
        _this.msgError("请先选择数据项");
        return false;
      }
      var url = "/" + this.controller + "/disable/" + ids;
      let _this = this;
      this.$confirm("是否确认作废选中数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function () {
          _this.http.postLoading(_this.loading(), url, {}, function (res) {
            if (typeof success == "function") {
              success(res);
            }
            _this.msgSuccess("作废成功");
          });
          //  return _this.http.post(url).then((res) => {
          // if (res.code == 200) {
          //     if (typeof success == "function") {
          //         success(res);
          //     }
          //     _this.msgSuccess("作废成功");
          // } else {
          //     _this.msgError("作废失败");
          // }
          // });
        })
        .catch(() => {});
    },
    //批量启用操作
    handleMultRestore(ids, success) {
      if (ids == "") {
        _this.msgError("请先选择数据项");
        return false;
      }
      var url = "/" + this.controller + "/restore/" + ids;
      let _this = this;
      this.$confirm("是否确认启用选中数据项吗?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function () {
          _this.http.postLoading(_this.loading(), url, {}, function (res) {
            if (typeof success == "function") {
              success(res);
            }
            _this.msgSuccess("现行成功");
          });

          // return _this.http.post(url).then((res) => {
          //     if (res.code == 200) {
          //         if (typeof success == "function") {
          //             success(res);
          //         }
          //         _this.msgSuccess("现行成功");
          //     } else {
          //         _this.msgError("现行失败");
          //     }
          // });
        })
        .catch(() => {});
    },
  },
};
</script>
<style rel="stylesheet/scss" lang="scss">
.el-date-editor.el-input {
  width: 100%;
}

.tag-content {
  overflow-x: auto;
  border: 1px solid #dfe6ec;
  padding: 3px;
  margin-bottom: 10px;
}

.eagle-page-table {
  button[type="primary"] {
    color: #409eff;
  }

  button[type="success"] {
    color: #67c23a;
  }

  button[type="info"] {
    color: #909399;
  }

  button[type="warning"] {
    color: #e6a23c;
  }

  button[type="danger"] {
    color: #f56c6c;
  }

  .el-button [class*="el-icon-"] + span {
    margin-left: 2px;
    //letter-spacing: 2px;
  }
}

.eagle-page-search {
  margin-bottom: 10px;
  // width: calc(100% - 10px);
}

.eagle-page-buttons {
  // margin-bottom: 10px;

  // float: right;
  position: absolute;
  right: 0px;
  bottom: 0px;

  .el-button {
    height: 32px;
    padding: 0px 15px;
  }

  .el-dropdown {
    margin-left: 10px;

    .el-icon-arrow-down {
      margin-left: 2px;
    }
  }
}

// .el-table td.table-button {
//     text-align: left;
// }
// .el-table td.table-button .el-button {
//     margin-right: 10px;
// }
// .el-button + .el-button {
//     margin-right: 0px;
//     margin-left: 0px;
// }
</style>
