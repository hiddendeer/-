<template name="eagle-form" >
    <el-dialog class="eagle-form-dialog" :visible.sync="open" @open="reVolid" :title="customTitle" v-dialogDrag :width="width" append-to-body show-close :close-on-click-modal="false" v-loading="loadingbut" :before-close="beforeClose">
        <div class="eagle-form">
            <el-form ref="form" :model="form" :rules="rules" :label-width="labelWidth" size="small">
                <slot></slot>
            </el-form>
        </div>
        <div v-if="!customButtons" slot="footer" class="dialog-footer">
            <el-button @click="cancel" v-if="isEdit">取 消</el-button>
            <el-button @click="cancel" v-if="!isEdit">关 闭</el-button>
            <el-button v-if="isEdit" type="primary" @click="submitForm" :loading="loadingbut">{{ loadingbuttext }}
            </el-button>
        </div>
        <div v-else slot="footer" class="dialog-footer">
            <slot name="buttons"></slot>
        </div>
    </el-dialog>
</template>
<script>
import eagleBlock from "./eagle-block.vue";
// import { resetForm } from "@/utils/EageleRMC";
// import "@/utils/dialogDrag.js";
export default {
    components: { eagleBlock },
    name: "eagle-form",
    props: {
        customButtons: {
            type: Boolean,
            default() {
                return false;
            },
        },
        showBtn: {
            type: Boolean,
            default: false,
        },
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        controller: {
            type: String,
            default() {
                return "";
            },
        },
        rules: {
            type: Object,
            default() {
                return {};
            },
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        form: {
            type: Object,
            default() {
                return {};
            },
        },
        width: {
            type: String,
            default() {
                return "600px";
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "80px";
            },
        },
        saveFun: {
            type: String,
            default() {
                return "save";
            },
        },
        saveVolidFun: {
            type: Function,
            default() {
                return true;
            },
        },
    },
    data() {
        return {
            customTitle: "编辑",
            open: false,
            // title: null,
            loading: false,
            loadingbut: false,
            loadingbuttext: "确 定",
            disabled: false,
            action: "add",
        };
    },
    created() {
        if (this.title) {
            this.customTitle = this.title;
        }
    },
    watch: {
        isEdit(nval, oval) {
            if (nval) {
                this.customTitle = "编辑" + this.title;
            } else {
                this.customTitle = this.title + "详情";
            }
        },
        title(nval, oval) {
            if (this.isEdit) {
                this.customTitle = "编辑" + nval;
            } else {
                this.customTitle = nval + "详情";
            }
        },
    },

    methods: {
        exportUp(value) {
            this.$emit("exportUp", value);
        },
        reVolid() {
            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
        },
        beforeClose(done) {
            done();
            this.$emit("beforeClose");
        },
        realSubmit(config) {
            let _this = this;
            var url = "/" + _this.controller + "/" + _this.saveFun;
            if (config && config.url) url = config.url;

            _this.http
                .post(url, this.form)
                .then((response) => {
                    if (response.code == 200) {
                        _this.msgSuccess("保存成功");
                        _this.open = false;
                        _this.$emit("afterSave", response, _this.action);
                        if (config && typeof config.success === "function") {
                            config.afterSave();
                        }
                        _this.loadingbut = false;
                        _this.loadingbuttext = "确 定";
                    } else {
                        _this.loadingbut = false;
                        _this.loadingbuttext = "确 定";
                    }
                })
                .catch((e) => {
                    _this.loadingbut = false;
                    _this.loadingbuttext = "确 定";
                });
        },
        /** 提交按钮 */
        submitForm(config) {
            let _this = this;
            _this.$refs["form"].validate((valid) => {
                if (valid) {
                    _this.loadingbut = true;
                    _this.loadingbuttext = "提交中...";
                    if (config && typeof config.saveVolidFun === "function") {
                        if (config.saveVolidFun()) _this.realSubmit(config);
                    } else if (typeof _this.saveVolidFun === "function") {
                        if (_this.saveVolidFun()) _this.realSubmit(config);
                    } else _this.realSubmit(config);
                }
            });
        },
        /** 提交按钮 */
        validateField(validateName) {
            let _this = this;
            _this.$refs["form"].validateField(validateName,(valid) => {
                
            });
        },
        // 取消按钮
        cancel() {
            this.open = false;

            if (this.$refs["form"]) {
                this.$refs["form"].resetFields();
            }
            Object.assign(this.$data, this.$options.data());
        },
        show(config) {
            if (config && config.title) {
                this.customTitle = "";
                this.customTitle = config.title;
            }
            this.open = true;
        },
        handleAdd(config) {
            this.action = "add";
            var _this = this;
            _this.customTitle = "新增" + _this.title;
            var url = "/" + this.controller + "/initData/0";
            var params = {};
            if (config) {
                if (config.url) {
                    url = config.url;
                }
                if (config.params) {
                    params = config.params;
                }
                if (config.title) _this.customTitle = config.title;
            }
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                if (!params.companyCode) {
                    this.$set(params, "companyCode", enterpriseCode);
                }
            }
            _this.http.get(url, params).then((response) => {
                var data = response.data;
                data.id = data.id || 0;
                _this.$emit("bindData", response.data, _this.action);
                _this.open = true;
                if (_this.$refs["form"]) {
                    _this.$refs["form"].resetFields();
                }
            });
        },

        /** 修改按钮操作 */
        handleUpdate(row, config) {
            this.action = "edit";
            // debugger;
            let _this = this;
            var url = "";
            if (_this.isEdit) {
                this.customTitle = "编辑" + this.title;
            } else {
                this.customTitle = this.title + "详情";
            }

            if (config && config.title) {
                _this.customTitle = config.title;
            }
            if (config && config.url) url = config.url;
            else {
                const id = row.id;
                url = "/" + _this.controller + "/getData/" + id;
            }
            _this.http.get(url).then((response) => {
                _this.$emit("bindData", response.data, _this.action);
                _this.open = true;
                if (config && typeof config.callback === "function") {
                    config.callback(response.data);
                    if (_this.$refs["form"]) {
                        _this.$refs["form"].resetFields();
                    }
                }
            });
        },
        toggle(config) {
            this.open = true;
             if (config && config.title) {
                this.customTitle = config.title;
            }
        },

        /** 安全生产会议记录复制按钮操作 */
        copyUpdate(row, config) {
            let _this = this;
            this.action = "add";
            this.customTitle = "";
            this.customTitle = "复制" + this.title;
            var url = "/" + this.controller + "/getData/" + row.id;
            if (config && config.title) {
                this.customTitle = config.title;
            }
            if (config && config.url) url = config.url;
            this.http.get(url).then((response) => {
                var data = response.data;
                data.accidentDate = "";
                data.id = "0";
                data.code = "";
                this.$emit("bindData", data, _this.action);
                this.open = true;
            });
        },
    },
};
</script>
<style scoped lang="scss">
// .eagle-form {
//     min-height: 500px;
// }
// ::v-deep .el-dialog__body {
//     background: #f0f0f0;
// }
</style>
