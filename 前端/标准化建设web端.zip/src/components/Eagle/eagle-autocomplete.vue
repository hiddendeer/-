<template>

    <el-form-item :label="label" :label-width="labelWidth" :prop="prop" :required="required" :rules="rulesArray">
        <el-autocomplete v-model="selectValue" style="width: 100%;" :fetch-suggestions="querySearchAsync" @input="handle" :placeholder="placeholderVal" @select="selectCallBack">
            <template slot-scope="{ item }">
                <div class="name">{{ item[labelName] }}</div>
            </template>
        </el-autocomplete>
    </el-form-item>
</template>
<script>
export default {
    name: "eagle-autocomplete",
    props: {
        label: {
            type: String,
            default() {
                return "所在区域";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        labelName: {
            type: String,
            default() {
                return "name";
            },
        },
        labelCode: {
            type: String,
            default() {
                return "code";
            },
        },
        autoCode: {
            type: [Boolean],
            default() {
                return true;
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },

        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        url: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            selectValue: "",
            placeholderVal: this.placeholder
                ? this.placeholder
                : "请选择" + this.label,
            // rulesArray: [],
        };
    },
    computed: {
        rulesArray: function () {
            let array = [];
            if (this.required && !this.onlyShowRequired) {
                array.push({
                    required: true,
                    message: "请输入" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    array.push(x);
                });
            }
            return array;
        },
    },
    created() {
        this.selectValue = this.value;
        // this.setRules();
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
            this.selectValue = this.value;
        },
    },

    methods: {
        // setRules() {
        //     if (this.required && !this.onlyShowRequired) {
        //         this.rulesArray.push({
        //             required: true,
        //             message: "请输入" + (this.label ? this.label : ""),
        //         });
        //     }
        //     if (this.rules && this.rules.length > 0) {
        //         this.rules.forEach((x) => {
        //             this.rulesArray.push(x);
        //         });
        //     }
        // },
        querySearchAsync(queryString, cb) {
            if (queryString) {
                // queryString = decodeURI(queryString);
                this.http
                    .get(this.url, {
                        name: queryString,
                        companyCode: this.$route.query.enterpriseCode,
                    })
                    .then(function (res) {
                        cb(res.data);
                    });
            } else {
                cb([]);
            }
        },
        selectCallBack(obj) {
            if (this.autoCode) {
                this.$emit("update:code", obj[this.labelCode]);
            }
            this.$emit("input", obj[this.labelName]);
            this.selectValue = obj[this.labelName];
            this.$emit("select", obj);
        },
        handle(e, item) {
            this.$emit("input", e);
            this.$emit("update:code", "");
        },
    },
};
</script>
