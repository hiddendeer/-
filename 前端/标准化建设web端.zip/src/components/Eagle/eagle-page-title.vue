<template>
    <div class="page-bg">
        <div class="page-title">{{value}}
            <slot />
        </div>
    </div>
</template>
<script>
export default {
    name: "eagle-page-title",
    props: {
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
    },
    data() {
        return {};
    },
    created() {},
    watch: {},
    methods: {},
};
</script>
<style lang="scss" scoped>
.page-bg {
    border-bottom: 1px solid #ddd;
    margin-bottom: 15px;
    .page-title {
        // background: #ff6a00;
        // display: inline-block;
        // line-height: 40px;
        // color: #fff;
        // padding: 0 10px;
        // border-radius: 10px 10px 0 0;
        background: #189cff;
        display: inline-block;
        line-height: 32px;
        color: #fff;
        padding: 0 10px;
        border-radius: 10px 10px 0 0;
        font-size: 14px;
    }
}
</style>

