<template>
    <div class="eagle-page">
        <div v-if="!customize" class="child">
            <slot name="slot-search">
            </slot>
            <slot name="slot-buttons"></slot>
            <div class="eagle-page-table">
                <el-table :show-header="showHeader" border :row-style="rowStyle" :max-height="maxHeight" ref="multipleTable" v-loading="loading" :data="list" @row-click="rowClick" @selection-change="handleSelectionChange" @select="handleCheckBoxChange" @select-all="handleCheckBoxAllChange" :span-method="cellMerge">
                    <el-table-column width="45px" v-if="single && showCheckColumn" fixed="left" align="center">
                        <template v-slot="scope">
                            <el-radio v-model="singleValue" :label="scope.row[selectField]" @change="handleRowChange(scope.row)">{{""}}</el-radio>
                        </template>
                    </el-table-column>
                    <el-table-column v-if="!single && showCheckColumn" fixed="left" type="selection" width="45px" align="center" />
                    <el-table-column v-if="showOrder" :label="label" fixed align="center" width="50px">
                        <template slot-scope="scope">
                            <span>{{ scope.$index+1 }}</span>
                        </template>
                    </el-table-column>
                    <slot name="slot-table"></slot>
                    <el-table-column label="操作" fixed="right" align="center" v-if="showBtn" class-name="small-padding fixed-width table-button" :width="btnWidth">
                        <template slot-scope="scope">
                            <slot name="slot-row-buttons" :row="scope.row" />
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <div v-else-if="customize" class="child">
            <slot :data="list"> </slot>
            <div class="customize-page">
            </div>
        </div>
        <el-pagination v-show="total > 0&&!noPage" :total="total" :current-page="query.params.pageNum" :page-size="query.params.pageSize" @size-change="handleSizeChange" @current-change="handleCurrentChange" :page-sizes="[10, 20, 30, 50,100]" :layout="layout">
        </el-pagination>
        <nodata v-if=" isShowEmpty && isShowEmpty1"></nodata>
    </div>
</template>
<script>
// import { get, del } from "@/api/http";
import nodata from "../Eagle/eagle-nodata.vue";
export default {
    components: { nodata },
    name: "eagle-page",
    props: {
        showCheckColumn: { type: Boolean, default: true },
        tableHeight: {
            type: String | Number,
            default: 50,
        },
        label: { type: String, default: "序号" },
        single: { type: Boolean, default: false },
        showCheck: { type: Boolean, default: false },
        selectValue: { type: String | Array | Number, default: "" },
        selectField: { type: String, default: "code" },
        idField: { type: String, default: "id" },
        selectTextField: { type: String, default: "name" },
        btnWidth: { type: String, default: "120px" },
        showBtn: { type: Boolean, default: true },
        customize: { type: Boolean, default: false },
        noPage: { type: Boolean, default: false },
        showOrder: { type: Boolean, default: true },
        showHeader: { type: Boolean, default: true },
        controller: { type: String, default: "" },
        pageSize: { type: Number, default: 20 },
        hasTotal: { type: Boolean, default: false },
        isDialog: { type: Boolean, default: false },
        hasTab: { type: Boolean, default: false },
        layout: {
            type: String,
            default: "total, sizes, prev, pager, next, jumper",
        },
        isShowEmpty: { type: Boolean, default: false },
        queryParams: {
            type: Object,
            default: function () {
                return {};
            },
        },
        conditions: {
            type: Object,
            default: function () {
                return {};
            },
        },
    },
    data() {
        return {
            // RefRowSelection: [],
            singleValue: this.selectValue,
            multipleValue: this.selectValue,
            selection: [],
            // 遮罩层
            loading: false,
            total: 0,
            list: [],
            isShowEmpty1: false,
            pageParams: {
                pageNum: 1,
                pageSize: 20,
            },
            query: {
                url: "",
                params: {},
            },
            maxHeight: 0,
            spanArr: [],
            pos: 0,
        };
    },
    created() {
        this.pageParams.pageSize = this.pageSize;
        this.maxHeight = this.tableHeight;
    },
    mounted: function () {
        var _this = this;
        if (this.maxHeight == 50) {
            var subtractVal = 70;
            if (!_this.noPage) {
                subtractVal = 100;
            }
            if (_this.isDialog) {
                subtractVal += 100;
            } else {
                if (_this.hasTotal) {
                    subtractVal += 70;
                }
                if (_this.hasTab) {
                    subtractVal += 70;
                }
            }

            this.$nextTick(function () {
                if (_this.$refs.multipleTable) {
                    _this.maxHeight =
                        window.innerHeight -
                        _this.$refs.multipleTable.$el.offsetTop -
                        subtractVal;

                    // 监听窗口大小变化
                    let self = this;
                    window.onresize = function () {
                        if (_this.$refs.multipleTable) {
                            _this.maxHeight =
                                window.innerHeight -
                                _this.$refs.multipleTable.$el.offsetTop -
                                subtractVal;
                        }
                    };
                }
            });
        }
    },
    watch: {
        selectValue(nVal, oVal) {
            this.singleValue = nVal;
            this.multipleValue = nVal;
        },
    },
    methods: {
        setList(config) {
            this.list = config.list;
            this.pageParams.pageNum = config.pageNum;
            this.pageParams.pageSize = config.pageSize;
            this.query = config.queryParams;
            this.total = config.total;
            this.query.url = config.url;
        },
        refresh(config) {
            this.pageParams.pageNum = 1;
            this.getListData();
        },
        search(config) {
            this.pageParams.pageNum = 1;
            this.dealParams(config);
            this.getListData();
        },
        dealParams(config) {
            this.query.url =
                config && config.url
                    ? config.url
                    : this.controller + "/getPageData";
            if (config) {
                if (config.params) {
                    this.query.params = this.deepMerge(
                        config.params,
                        this.pageParams
                    );
                } else {
                    this.query.params = this.deepMerge(
                        this.queryParams,
                        this.pageParams
                    );
                }
                if (config.conditions) {
                    this.query.params.conditions = config.conditions;
                } else {
                    this.query.params.conditions = this.getCondtionsNew();
                }
            } else {
                this.query.params = this.deepMerge(
                    this.queryParams,
                    this.pageParams
                );
                this.query.params.conditions = this.getCondtionsNew();
            }
        },
        handleCurrentChange(pageNum) {
            this.query.params.pageNum = pageNum;
            this.pageParams.pageNum = pageNum;
            this.getListData();
        },
        handleSizeChange(size) {
            this.query.params.pageNum = 1;
            this.pageParams.pageNum = 1;
            this.pageParams.pageSize = size;
            this.query.params.pageSize = size;
            this.getListData();
        },
        getListData() {
            this.loading = true;
            let _this = this;
            _this.isShowEmpty1 = false;
            let enterpriseCode = this.$route.query.enterpriseCode;
            if (enterpriseCode) {
                if (!this.query.params.companyCode) {
                    this.$set(this.query.params, "companyCode", enterpriseCode);
                }
            }
            this.http
                .get(this.query.url, this.query.params)
                .then((res) => {
                    this.loading = false;
                    _this.list = res.data;
                    if (res.data.length == 0) {
                        _this.isShowEmpty1 = true;
                    }
                    _this.total = res.total;
                    _this.loading = false;
                    _this.selection = [];

                    _this.getSpanArr(res.data);
                    // if (
                    //     _this.loading == false &&
                    //     this.RefRowSelection.length > 0
                    // ) {
                    //     this.RefRowSelection.length;
                    //     setTimeout(() => {
                    //         this.ReftoggleRowSelection(this.RefRowSelection);
                    //     });
                    // }
                    // if (
                    //     !_this.showCheckColumn &&
                    //     _this.single &&
                    //     _this.list.length > 0
                    // ) {
                    //     _this.rowClick(_this.list[0]);
                    // }
                    this.$emit("afterSearch", _this.list);
                })
                .catch(() => {
                    this.loading = false;
                });
        },
        // ReftoggleRowSelection(ref) {
        //     let _this = this;
        //     ref.forEach((row) => {
        //         this.list.filter((x) => {
        //             if (row.tCode == x.tCode) {
        //                 _this.$refs.multipleTable.toggleRowSelection(x, true);
        //             }
        //         });
        //     });
        // },
        rowClick(row) {
            let _this = this;
            if (_this.single) {
                _this.singleValue = row[_this.selectField];
                _this.selection = [];
                _this.selection.push(row);
            } else {
                _this.$refs.multipleTable.toggleRowSelection(row);
                var checked =
                    _this.selection.findIndex(
                        (x) => x[_this.selectField] == row[_this.selectField]
                    ) < 0;
                _this.setChangeData(row, checked);
            }
            this.$emit("rowClick", row);
        },
        handleSelectionChange(selection) {
            this.$emit("handleSelectionChange", selection);
        },
        getSelection() {
            return this.selection;
        },
        getCurrentList() {
            return this.list;
        },
        //查找当前页面的选中id
        getSelectionIds() {
            var arryIds = [];
            this.selection.forEach((item) => {
                arryIds.push(item[this.idField]);
            });
            return arryIds.join(",");
        },

        handleCheckBoxChange(selectAllRow, currRow) {
            let _this = this;
            this.setChangeData(
                currRow,
                selectAllRow.findIndex(
                    (x) => x[_this.selectField] == currRow[_this.selectField]
                ) >= 0
            );
            selectAllRow.forEach((element) => {
                if (element[_this.selectField] !== currRow[_this.selectField]) {
                    this.$emit("handleCheckBoxChange", currRow);
                }
            });
        },
        handleConfirm() {
            console.log(this.selection);
        },
        handleCheckBoxAllChange(selectRows) {
            let _this = this;
            //先从选中的列表中全都移除
            this.list.forEach((x) => {
                _this.setChangeData(x, false);
            });
            if (selectRows && selectRows.length > 0) {
                _this.selection = _this.selection.concat(selectRows);
            }
            this.$emit("handleCheckBoxAllChange", selectAllRow, currRow);
        },

        handleCopy(row, success) {
            let _this = this;
            const id = row[this.idField];
            var url = "/" + this.controller + "/copy/" + id;
            _this.http.postLoading(_this.loading(), url, {}, function (res) {
                if (typeof success == "function") {
                    success(res);
                } else {
                    _this.refresh();
                }
                _this.msgSuccess("复制成功");
            });
            // this.http.post(url).then(response => {
            // if (typeof success == "function") {
            //     success(res);
            // } else {
            //     _this.refresh();
            // }
            // _this.msgSuccess("复制成功");
            // });
        },

        /** 删除按钮操作 */
        handleDelete(row, success) {
            var url = "/" + this.controller + "/delete/" + row[this.idField];
            let _this = this;
            this.$confirm("是否确认删除此行数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http.delLoading(_this.loading(), url, {}, function (res) {
                    if (typeof success == "function") {
                        success(res);
                    } else {
                        _this.refresh();
                    }
                    _this.msgSuccess("删除成功");
                });

                // _this.http.del(url).then(function () {
                //     if (typeof success == "function") {
                //         success(res);
                //     } else {
                //         _this.refresh();
                //     }
                //     _this.msgSuccess("删除成功");
                // });
            });
        },
        //批量删除操作
        handleMultDelete(ids, success) {
            if (ids == "") {
                _this.msgError("请先选择数据项");
                return false;
            }
            var url = "/" + this.controller + "/delete/" + ids;
            let _this = this;
            this.$confirm("是否确认删除选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(function (res) {
                _this.http.delLoading(_this.loading(), url, {}, function (res) {
                    if (typeof success == "function") {
                        success(res);
                    } else {
                        _this.refresh();
                    }
                    _this.msgSuccess("删除成功");
                });
                // _this.http.del(url).then(function () {
                //     if (typeof success == "function") {
                //         success(res);
                //     } else {
                //         _this.refresh();
                //     }
                //     _this.msgSuccess("删除成功");
                // });
            });
        },
        //批量废止操作
        handleMultDisable(ids, success) {
            if (ids == "") {
                _this.msgError("请先选择数据项");
                return false;
            }
            var url = "/" + this.controller + "/disable/" + ids;
            let _this = this;
            this.$confirm("是否确认作废选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            if (typeof success == "function") {
                                success(res);
                            }
                            _this.msgSuccess("作废成功");
                        }
                    );

                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         if (typeof success == "function") {
                    //             success(res);
                    //         }
                    //         _this.msgSuccess("作废成功");
                    //     } else {
                    //         _this.msgError("作废失败");
                    //     }
                    // });
                })
                .catch(() => {});
        },

        //批量现行操作
        handleMultRestore(ids, success) {
            if (ids == "") {
                _this.msgError("请先选择数据项");
                return false;
            }
            var url = "/" + this.controller + "/restore/" + ids;
            let _this = this;
            this.$confirm("是否确认启用选中数据项吗?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    _this.http.postLoading(
                        _this.loading(),
                        url,
                        {},
                        function (res) {
                            _this.msgSuccess("现行成功");
                        }
                    );

                    // return _this.http.post(url).then(res => {
                    //     if (res.code == 200) {
                    //         if (typeof success == "function") {
                    //             success(res);
                    //         }
                    //         _this.msgSuccess("现行成功");
                    //     } else {
                    //         _this.msgError("现行失败");
                    //     }
                    // });
                })
                .catch(() => {});
        },
        // handleMultDelete(ids, success) {
        //      var url = "/" + this.controller + "/delete/" +ids;
        //     let _this = this;
        //     this.$confirm("是否确认删除此行数据项吗?", "警告", {
        //         confirmButtonText: "确定",
        //         cancelButtonText: "取消",
        //         type: "warning",
        //     }).then(function (res) {
        //         _this.http.del(url).then(function () {
        //             if (typeof success == "function") {
        //                 success(res);
        //             } else {
        //                 _this.refresh();
        //             }
        //             _this.msgSuccess("删除成功");
        //         });
        //     });
        // },
        handleRowChange(row) {
            this.selection = [];
            this.selection.push(row);
        },
        setChangeData(row, isChecked) {
            let _this = this;
            if (isChecked) {
                let index = _this.selection.findIndex(
                    (x) => x[_this.selectField] == row[this.selectField]
                );
                if (index < 0) {
                    _this.selection.push(row);
                }
            } else {
                let index = _this.selection.findIndex(
                    (x) => x[_this.selectField] == row[this.selectField]
                );
                if (index >= 0) {
                    _this.selection.splice(index, 1);
                }
            }
        },

        //拼装查询条件
        getCondtions(vals, keys) {
            let conditionsArry = [];
            for (let key in vals) {
                let op = keys[key];
                let val = vals[key];
                if (val) {
                    conditionsArry.push({
                        name: key,
                        operate: !op ? "like" : op,
                        value: val,
                    });
                }
            }
            return conditionsArry && conditionsArry.length > 0
                ? JSON.stringify(conditionsArry)
                : conditionsArry;
        },
        getCondtionsNew() {
            let conditionsArry = [];
            for (let key in this.conditions) {
                let op = this.conditions[key];
                let val = op.value;
                let operate = op.operate;
                if (val) {
                    conditionsArry.push({
                        name: key,
                        operate: !operate ? "like" : operate,
                        value: val,
                    });
                }
            }
            return conditionsArry && conditionsArry.length > 0
                ? JSON.stringify(conditionsArry)
                : conditionsArry;
        },
        // 设置背景颜色
        rowStyle({ row, rowIndex }) {
            if (row[this.selectField] == this.singleValue) {
                console.log(row[this.selectField], this.singleValue);
                return { background: "#E4E9F1" };
            }
        },
        clearListData() {
            this.list = [];
            this.isShowEmpty1 = true;
            this.total = 0;
            this.selection = [];
        },
        cellMerge({ row, column, rowIndex, columnIndex }) {
            if (
                columnIndex === 0 ||
                columnIndex === 1 ||
                columnIndex === 2 ||
                columnIndex === 3
            ) {
                const _row = this.spanArr[rowIndex];
                const _col = _row > 0 ? 1 : 0;
                return {
                    rowspan: _row,
                    colspan: _col,
                };
            }
        },
        getSpanArr(data) {
            for (var i = 0; i < data.length; i++) {
                if (i === 0) {
                    this.spanArr.push(1);
                    this.pos = 0;
                } else {
                    // 判断当前元素与上一个元素是否相同
                    if (data[i].buildingCode === data[i - 1].buildingCode) {
                        this.spanArr[this.pos] += 1;
                        this.spanArr.push(0);
                    } else {
                        this.spanArr.push(1);
                        this.pos = i;
                    }
                }
            }
        },
        objectSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                //用于设置要合并的列
                if (rowIndex % 2 === 0) {
                    //用于设置合并开始的行号
                    return {
                        rowspan: 2, //合并的行数
                        colspan: 1, //合并的列数，设为０则直接不显示
                    };
                } else {
                    return {
                        rowspan: 0,
                        colspan: 0,
                    };
                }
            }
        },
    },
};
</script>
<style rel="stylesheet/scss" lang="scss">
.el-date-editor.el-input {
    width: 100%;
}
.tag-content {
    overflow-x: auto;
    border: 1px solid #dfe6ec;
    padding: 3px;
    margin-bottom: 10px;
}
.eagle-page-table {
    button[type="primary"] {
        color: #409eff;
    }
    button[type="success"] {
        color: #67c23a;
    }
    button[type="info"] {
        color: #909399;
    }
    button[type="warning"] {
        color: #e6a23c;
    }

    button[type="danger"] {
        color: #f56c6c;
    }

    .el-button [class*="el-icon-"] + span {
        margin-left: 2px;
        //letter-spacing: 2px;
    }
}
</style>
