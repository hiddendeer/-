<template name="eagle-dialog-dept">
    <el-dialog v-dialogDrag :title="title" :visible.sync="showDialog" width="800px" append-to-body show-close
        :close-on-click-modal="false">
        <eagle-block border>
            <eagle-window-choose :queryParams="queryParams" :controller="controller" ref="EaglePage" table-height="500" :single="single"
                selectTextField="organName" selectField="organId">
                <template slot="slot-search">
                    <eagle-condition @search="search()" @resetQuery="resetQuery()">
                        <eagle-input label-width="120px" @changeEnter="search()" label="筛选条件" prop="key"
                            v-model="conditionsVals.key" placeholder="部门名称" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-table">
                    <el-table-column label="部门名称" align="left" prop="organName" />
                    <el-table-column label="部门全名称" align="left" prop="organFullName" />
                </template>
            </eagle-window-choose>
        </eagle-block>
        <span slot="footer" class="dialog-footer">
            <el-button @click="showDialog = false">取 消</el-button>
            <el-button type="primary" @click="handleChoose">确 定</el-button>
        </span>
    </el-dialog>
</template>

<script>
export default {
    name: "eagle-dialog-dept",
    components: {},
    props: {
        single: { type: Boolean, default: true },
    },
    data() {
        return {
            queryParams: { dataType: "list" },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditionsTypes: {
                name: "like",
            },
            // 查询条件
            conditionsVals: {
                key: "",
            },
            controller: "system/eagleOrgan", //对应后端控制器
            title: "选择部门",
            showDialog: false,
        };
    },
    created() { },
    methods: {
        handleChoose(obj) {
            let chooseObj = this.$refs.EaglePage.selection;
            if (!chooseObj || chooseObj.length <= 0) {
                this.msgError("请选择部门");
                return;
            }
            let data = {};
            if (this.single) {
                data.code = chooseObj[0].organId;
                data.name = chooseObj[0].organName;
            } else {
                let arryCode = [];
                let arryName = [];
                chooseObj.forEach((element) => {
                    arryCode.push(element.organId);
                    arryName.push(element.organName);
                });
                data.code = arryCode.join(",");
                data.name = arryName.join(",");
            }
            this.$emit("callBack", data);
            this.showDialog = false;
        },
        //查询
        search() {
            setTimeout(() => {
                this.$refs.EaglePage.search({
                  
                    conditions: this.$refs.EaglePage.getCondtions(
                        this.conditionsVals,
                        this.conditionsTypes
                    ),
                });
            });
        },

        //查询条件重置
        resetQuery() {
            this.search();
        },

        /** 新增按钮操作 */

        resetQuery() {
            this.conditionsVals.key = "";
            this.search();
        },
        show(code, name) {
            this.showDialog = true;
            setTimeout(() => {
                this.$refs.EaglePage.setInitCodes(code, name);
                this.search();
            });
        },
    },
};
</script>