<template>
    <span>
        <eagle-choose :label="label" @change="openChoose" :required="required" v-model="names" />
        <eagle-dialog-dept ref="detpDialog" :single="single" @callBack="handelChoose"></eagle-dialog-dept>
    </span>
</template>
<script>
import { number } from "mathjs";
import eagleDialogDept from "./eagle-dialog-dept.vue";
export default {
    components: { eagleDialogDept },
    name: "eagle-choose-dept",
    props: {
        required: false,
        value: {
            type: String,
            default: "",
        },
        names: {
            type: String,
            default: "",
        },

        label: {
            type: String,
            default: "部门",
        },
        single: {
            type: Boolean,
            default: true,
        },

    },
    data() {
        return {};
    },
    created() { },
    watch: {},
    methods: {
        handelChoose(data) {
            // debugger;
            this.$emit("input", data.code);
            this.$emit("update:names", data.name);
            this.$emit("callBack", data);
        },
        openChoose(data) {
            this.$refs.detpDialog.show(this.value, this.names);
        },
    },
};
</script>