<template name="eagle-picker-range">
    <!-- <el-col :span="span" v-if="isFullCol || span < 24">
        <el-form-item :label="label" :prop="prop" :label-width="labelWidth" :required="required" :rules="rulesArray">
            <el-date-picker :picker-options="curPickerOptions" :clearable="clearable" :size="size" v-model="inputValue" :type="type" :placeholder="placeholderValue" @change="handleChange" :readonly="readonly" :disabled="disabled" :default-time="defaultTime">
            </el-date-picker>
        </el-form-item>
    </el-col> -->
    <el-form-item :label="label" :prop="prop" :label-width="labelWidth" :required="required" :rules="rulesArray">
        <el-date-picker :start-placeholder='startPlaceholder' :end-placeholder='endPlaceholder' :picker-options="curPickerOptions" :clearable="clearable" :size="size" v-model="inputValue" :type="type" :value-format="format" :placeholder="placeholderValue" @change="handleChange" :readonly="readonly" :disabled="disabled" :default-time="defaultTime">
        </el-date-picker>
    </el-form-item>
</template>
<script>
import { max, min } from "mathjs";
export default {
    name: "eagle-picker-range",
    props: {
        clearable: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        startPlaceholder: {
            type: String,
            default() {
                return "";
            },
        },
        endPlaceholder: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        type: {
            type: String,
            default() {
                return "date";
            },
        },
        format: {
            type: String,
            default() {
                return "yyyy-MM-dd";
            },
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        size: {
            type: String,
            default() {
                return "";
            },
        },

        rows: {
            type: Number,
            default() {
                return 2;
            },
        },
        readonly: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: Boolean,
            default() {
                return false;
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        onlyShowRequired: {
            type: Boolean,
            default() {
                return false;
            },
        },
        defaultTime: {
            type: Array,
            default() {
                return [];
            },
        },
        pickerOptionsType: {
            type: String, //  gt:大于 lt:小于
            default() {
                return "";
            },
        },
        pickerOptions: {
            type: Object,
            default() {
                return {
                    disabledDate: !this.pickerOptionsType
                        ? function (time) {
                            return false;
                        }
                        : this.pickerOptionsType == "gt"
                            ? function (time) {
                                return (
                                    time.getTime() > Date.now() - 8.64e7 === false
                                );
                            }
                            : function (time) {
                                return (
                                    time.getTime() < Date.now() - 8.64e7 === false
                                );
                            },
                    shortcuts: [],
                };
            },
        },
    },
    data() {
        return {
            curPickerOptions: this.pickerOptions,
            placeholderValue: "",
            inputValue: "",
            rulesArray: [],
        };
    },
    created() {
        this.placeholderValue = this.placeholder
            ? this.placeholder
            : "请选择" + this.label;
        this.inputValue = this.value;
        this.setRules();
        if (
            !this.curPickerOptions.shortcuts ||
            this.curPickerOptions.shortcuts.length === 0
        ) {
            if (!this.pickerOptionsType || this.pickerOptionsType == "lt") {
                this.curPickerOptions.shortcuts.push({
                    text: "前一周",
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                        picker.$emit("pick", [start, end]);
                    },
                });
                this.curPickerOptions.shortcuts.push({
                    text: "前一个月",
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                        picker.$emit("pick", [start, end]);
                    },
                });
                this.curPickerOptions.shortcuts.push({
                    text: "前三个月",
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(
                            start.getTime() - 3600 * 1000 * 24 * 30 * 3
                        );
                        picker.$emit("pick", [start, end]);
                    },
                });
            }
            if (
                !this.curPickerOptions.pickerOptionsType ||
                this.pickerOptionsType == "gt"
            ) {
                this.curPickerOptions.shortcuts.push({
                    text: "后一周",
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(end.getTime() + 3600 * 1000 * 24 * 7);
                        picker.$emit("pick", [start, end]);
                    },
                });
                this.curPickerOptions.shortcuts.push({
                    text: "后一个月",
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(end.getTime() + 3600 * 1000 * 24 * 30);
                        picker.$emit("pick", [start, end]);
                    },
                });
                this.curPickerOptions.shortcuts.push({
                    text: "后三个月",
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(end.getTime() + 3600 * 1000 * 24 * 30 * 3);
                        picker.$emit("pick", [start, end]);
                    },
                });
            }
        }
    },
    watch: {
        value(newvalue, oldvalue) {
            this.inputValue = this.value;
        },
    },
    methods: {
        setRules() {

            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: this.placeholderValue,
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange(newvalue) {
            this.$emit("input", newvalue);
            this.$emit("change", newvalue);
        },
    },
};
</script>