<template>

    <el-form-item class="eagle-radio-form-item" :label="label" :labelWidth="labelWidth" :required="required" :prop="prop" :rules="rulesArray">
        <template v-if="!isEdit">{{formateDict(dataSource, value,id,name,',')}}</template>
        <template v-else>
            <el-radio-group v-model="checkValue" @change="handleChange">
                <el-radio v-for="item in items" :disabled="item.disabled" :key="item[id]" :label="item[id]">
                    {{ item[name] }}
                </el-radio>
            </el-radio-group>
        </template>
        <slot></slot>
    </el-form-item>
    <!-- </el-row> -->
</template>
<script>
export default {
    name: "eagle-radio",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        isFullCol: {
            type: Boolean,
            default() {
                return false;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        id: {
            type: String,
            default() {
                return "id";
            },
        },
        name: {
            type: String,
            default() {
                return "name";
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabledValues: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "100px";
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },

        rules: {
            type: Array,
            default() {
                return [];
            },
        },
    },
    data() {
        return {
            checkValue: "",
            items: [],
            rulesArray: [],
            // dataSourceArray: [],
        };
    },
    mounted() {
        this.bind();
    },
    created() {
        // console.log(this.isFullCol);
        this.checkValue = this.value;
        this.setRules();
    },
    updated() {},
    watch: {
        dataSource(nval, oval) {
            if (nval !== oval) this.items = this.deepClone(this.dataSource);
        },
        value(newvalue, oldvalue) {
            if (newvalue !== oldvalue) {
                this.checkValue = this.value;
            }
        },
        checkValue(newvalue, oldvalue) {
            this.$emit("input", newvalue);
        },
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                    trigger: "change",
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },

        handleChange(newvalue) {
            // this.checkValue;
            this.$emit("input", newvalue);
            this.$emit("change", newvalue);
        },

        bind: function () {
            this.items = this.deepClone(this.dataSource);
            var disabledArray = this.disabledValues
                ? this.disabledValues.split(",")
                : [];
            this.items.forEach((item, index) => {
                if (this.disabled || disabledArray.includes(item.id))
                    this.$set(item, "disabled", true);
                else this.$set(item, "disabled", false);
            });
        },
    },
};
</script>
<style lang="scss" scoped>
.eagle-radio-form-item {
    //display: flex;
    // ::v-deep .el-form-item__content {
    //     flex: 1;
    // }
}
</style>