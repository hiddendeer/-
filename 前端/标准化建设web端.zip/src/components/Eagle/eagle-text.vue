<template>
    <div class="eagle-text">
        <el-form-item :label="label" :class="{ 'no-title-item': !label }" :style="{ width: width }" :labelWidth="labelWidth">
            <span class="eagle-text-input">

                {{ value || emptyText }}
                <slot>
                </slot>
            </span>
        </el-form-item>
    </div>
</template>
<script>
import * as math from "mathjs";
export default {
    name: "eagle-text",
    props: {
        value: {
            type: [String, Object],
            default: "",
        },
        labelWidth: {
            type: String,
            default() {
                return "80px";
            },
        },
        label: {
            type: [String],
            default: "",
        },
        width: {
            type: [Number, String],
            default: "100%",
        },
        emptyText: {
            type: [String],
            default: "",
        },
    },
    data() {
        return {};
    },
    computed: {},
    created() {},
    watch: {},
    methods: {},
};
</script>
<style lang="scss" scoped>
.eagle-text {
    ::v-deep .el-form-item {
        margin-bottom: 0px;
    }
    .eagle-text-input {
        color: #666;
        margin-bottom: 15px;
        display: inline-block;
        font-size: 14px;
        line-height: 36px;
        min-height: 24px;
    }
}
</style>