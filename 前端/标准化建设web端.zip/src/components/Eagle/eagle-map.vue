<template>
  <div>
    <el-input v-model="address" suffix-icon="el-icon-position" @click.native="clickFnc" style="width: 50%">
    </el-input>
    <el-dialog v-dialogDrag @close="changFunc" :visible.sync="mapVisible" :close-on-click-modal="false" width="50%">
      <div class="myIndexWrap">
        <div class="amap-page-container">
          <!-- 搜索框 -->
          <!-- <el-amap-search-box class="search-box"
        :search-option="searchOption"
        :on-search-result="onSearchResult">
      </el-amap-search-box> -->
          <div class="pickerBox">
            <el-input v-model="searchValue" id="pickerInput" placeholder="输入关键字选取地点" />
            <div id="poiInfo"></div>
          </div>
          <el-amap ref="map" vid="eagleMap" :center="center" :map-manager="amapManager" :zoom="zoom" :plugin="plugin" :events="events" class="amap-map">
            <!-- 坐标点 -->
            <el-amap-marker vid="eagleMap" :position="center"></el-amap-marker>
            <el-amap-info-window :position="currentWindow.position" :content="currentWindow.content" :visible="currentWindow.visible" :offset="[0,-37]" :events="currentWindow.events">
            </el-amap-info-window>
          </el-amap>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="changFunc">取 消</el-button>
        <el-button type="primary" @click="changFunc">确 定</el-button>
      </span>
    </el-dialog>
    <div>
      <el-input type="hidden" v-model="lng" />
      <el-input type="hidden" v-model="lat" />
    </div>
  </div>
</template>
<script>
import Vue from 'vue'
import VueAMap from 'vue-amap'
Vue.use(VueAMap)

let amapManager = new VueAMap.AMapManager();
let geocoder = new AMap.Geocoder({
  radius: 1000,
  extensions: "all"
});
export default {
  name: 'eagle-map',
  data() {
    let vm = this
    vm.city = vm.city || '全国'
    return {
      mapVisible: false,
      zoom: 16,
      center: [121.59996, 31.197646], // 中心位置
      resetCenter: [],
      amapManager,
      geocoder,
      map: null,
      searchValue: '',
      lng: '',
      lat: '',
      events: {
        init: (o) => {
          vm.map = o;
          AMapUI.loadUI(['misc/PoiPicker'], (PoiPicker) => {
            var poiPicker = new PoiPicker({
              input: 'pickerInput'
            });
            window.poiPicker = poiPicker;
            //选取了某个POI
            poiPicker.on('poiPicked', (poiResult) => {
              var poi = poiResult.item;
              vm.currentPoi = poi;
              vm.map.setCenter(poi.location);
              vm.center = [poi.location.lng, poi.location.lat];
            });
            console.log("init")
          });
          o.getCity(result => {
            console.log(result)
          })
        },
        'moveend': () => {
          console.log("moveend")
          vm.getAddress();
        },
        'zoomchange': () => {
          console.log("zoomchange")
          vm.getAddress();
        },
        'click': (e) => {
          console.log(e)
          vm.center = [e.lnglat.lng, e.lnglat.lat]// 点击选择新地址为中心点
          vm.map.setCenter([e.lnglat.lng, e.lnglat.lat]);
          // console.log("click")
          // vm.getAddress();
        }
      },
      // ToolBar工具条插件、MapType插件、Scale比例尺插件、OverView鹰眼插件
      plugin: ['ToolBar', {
        pName: 'MapType',
        defaultType: 0,
        events: {
          init(o) {
            console.log(o)
          }
        }
      }, {
          pName: 'Scale',
          events: {
            init(instance) {
              console.log(instance)
            }
          }
        }, {
          pName: 'OverView',
          events: {
            init(instance) {
              console.log(instance)
            }
          }
        }],
      windows:  // 窗口信息框
      {
        position: [121.69996, 31.237646],
        content: "",
        visible: true,
        events: {
          close() {
            console.log('关闭窗口一！')
          }
        }
      },
      // 当前窗口
      currentWindow: {
        position: [0, 0],
        content: '',
        events: {},
        visible: false
      },
    }
  },
  created() {
    this.resetCenter = [...this.center];
  },
  mounted() {
    this.currentWindow = this.windows// 初始化窗口信息
  },
  destroyed() {
  },
  methods: {
    clickFnc() {
      this.mapVisible = true;
    },
    changFunc() {
      this.center = this.resetCenter;
      this.searchValue = '';
      this.mapVisible = false;
      this.address = this.currentPoi.address;
      this.$emit('input', this.currentPoi)
      this.lng = this.currentPoi.lng;
      this.lat = this.currentPoi.lat;
    },
    // 切换信息窗口
    showWindow() {
      this.currentWindow.visible = false;
      this.$nextTick(() => {
        this.windows.position = this.center;
        this.windows.content = `<div>
          <div style="text-align: center;margin: 0 20px 5px 0;"><span>`+ this.currentPoi.name + `</span></div>
            <div style="margin: 0;padding:0;height:1px;width: 100%;background-color:#c0c4cc;overflow:hidden;"></div>
          <div style="margin-top: 5px;"><span>`+ this.currentPoi.address + `</span></div>
        </div>`;
        this.currentWindow = this.windows;
        this.currentWindow.visible = true;
      })
    },
    getAddress() {
      if (geocoder) {
        geocoder.getAddress(this.center, (status, result) => {
          if (status === 'complete' && result.info === 'OK') {
            var pois = result.regeocode.pois;
            if (pois.length > 0) {
              var poi = null;
              var max = pois.length > 5 ? 5 : pois.length;
              for (var i = 0; i < max; i++) {
                if (this.currentPoi != null && pois[i].id == this.currentPoi.id) {
                  poi = pois[i];
                }
              }
              if (poi == null) {
                poi = pois[0];
              }
              this.currentPoi = poi;
              this.showWindow();
            }
          }
        });
      }
    }
  }
}
</script>

<style scoped>
.myIndexWrap {
  height: 500px;
}
.pickerBox {
  position: absolute;
  z-index: 9999;
  top: 18px;
  left: 100px;
  width: 300px;
}
.amap-map {
  height: 500px;
}
.search-box {
  position: absolute;
  top: 25px;
  left: 70px;
}
.amap-page-container {
  position: relative;
}
.toolbar button {
  background: #42b983;
  border: 0;
  color: white;
  padding: 8px;
  margin: 0 5px;
  border-radius: 3px;
  cursor: pointer;
  margin-top: 10px;
}
</style>