<template>
    <el-form-item :label="label" :prop="onlyShowRequired ? '' : prop" :required="required" :label-width="labelWidth" :rules="rulesArray">
        <template v-if="isEdit">
            <el-input v-if="type == 'number'" :style="inputStyle" v-model.number="inputValue" @clear="clear" @keyup.native='keyupEvent2($event)' :placeholder="placeholderValue" :type="type" :clearable="clearable" :disabled="disabled" :size="size" :autosize="autosize" :prefix-icon="prefixicon" :min="min" :max="max" :suffix-icon="suffixicon" :rows="rows" :readonly="readonly" :autofocus="autofocus" @change="handleChange" @input="handleInput">
                <template #prepend v-if="leftMessage">
                    {{ leftMessage }}
                </template>
                <template #append v-if="rightMessage">
                    {{ rightMessage }}
                </template>
            </el-input>
            <el-input v-else v-model.trim="inputValue" :maxlength="maxlength" :style="inputStyle" @clear="clear" @keyup.native='keyupEvent2($event)' :placeholder="placeholderValue" :type="type" :clearable="clearable" :disabled="disabled" :size="size" :autosize="autosize" :prefix-icon="prefixicon" :suffix-icon="suffixicon" :rows="rows" :readonly="readonly" :autofocus="autofocus" :show-word-limit="showWordLimit" @change="handleChange" @input="handleInput">
                <template #prepend v-if="leftMessage">
                    {{ leftMessage }}
                </template>
                <template #append v-if="rightMessage">
                    <template v-if="rightMessage != 'icon'">
                        {{ rightMessage }}
                    </template>
                    <template v-else>
                        <i :class="iconClass"></i>
                    </template>
                </template>
            </el-input>
        </template>
        <template v-else>
            {{ inputValue }}
        </template>
    </el-form-item>
</template>
<script>
/**
 * type='money'
 */
import * as math from "mathjs";
export default {
    name: "eagle-input",
    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        maxlength: {
            type: Number | String,
            default() {
                return null;
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: Number | String,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        placeholder: {
            type: String,
            default() {
                return "";
            },
        },
        type: {
            type: String,
            default() {
                return "text";
            },
        },
        clearable: {
            type: Boolean,
            default() {
                return false;
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        size: {
            type: String,
            default() {
                return "";
            },
        },
        prefixicon: {
            type: String,
            default() {
                return null;
            },
        },
        suffixicon: {
            type: String,
            default() {
                return null;
            },
        },
        rows: {
            type: Number,
            default() {
                return 2;
            },
        },
        autosize: {
            type: Boolean,
            default() {
                return false;
            },
        },
        readonly: {
            type: Boolean,
            default() {
                return false;
            },
        },
        autofocus: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        width: {
            type: String,
            default() {
                return "";
            },
        },
        leftMessage: {
            type: String,
            default() {
                return "";
            },
        },
        rightMessage: {
            type: String,
            default() {
                return "";
            },
        },
        iconClass: {
            type: String,
            default() {
                return "";
            },
        },
        min: {
            type: Number,
            default() {
                return 24;
            },
        },
        max: {
            type: Number,
            default() {
                return 24;
            },
        },
        MaxLength:{
            type:Number,
            default(){
                return 999999
            }
        },
        showWordLimit:{
            type:Boolean,
            default:false
        }
    },
    data() {
        return {
            placeholderValue: "",
            inputValue: "",
            inputStyle: {
                width: "",
            },
        };
    },
    computed: {
        rulesArray: function () {
            let array = [];
            if (this.required && !this.onlyShowRequired) {
                array.push({
                    required: true,
                    message: "请输入" + (this.label ? this.label : ""),
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    array.push(x);
                });
            }
            return array;
        },
    },
    created() {
        this.placeholderValue = this.placeholder
            ? this.placeholder
            : "请输入" + this.label;
        this.inputValue = this.value;
        if (this.width) {
            this.inputStyle.width = this.width;
        }
    },
    watch: {
        value(newvalue, oldvalue) {
            this.inputValue = this.value;
        },
    },
    methods: {
        printFn(value) {
            const precision = 14;
            return Number(math.format(value * 10000, precision));
        },
        keyupEvent2(e) {
            if (e.key === "Enter") {
                this.$emit("changeEnter", e);
            }
        },
        keyupEvent(e) {
            e.target.value = e.target.value.replace(/[^\d.]/g, "");
            e.target.value = e.target.value.replace(/\.{2,}/g, ".");
            e.target.value = e.target.value.replace(/^\./g, "0.");
            e.target.value = e.target.value.replace(/^0[^\.]+/g, "0");
            this.input = e.target.value;
            this.$emit("keyupEvent", e);
            if (e.key === "Enter") {
                this.$emit("changeEnter");
            }
        },
        clear() {
            this.$emit("changeEnter");
        },
        handleChange(newvalue) {
            this.$emit("change", newvalue);
        },
        handleInput(newvalue) {
            this.$emit("input", newvalue);
        },
    },
};
</script>
<style scoped>
.digit {
    line-height: 32px;
    /* vertical-align: bottom; */
    margin-left: 10px;
    font-weight: bold;
}
</style>