<template name="eagle-date">
  <div class="eagle-date">
    <el-form-item
      :label="label"
      :prop="prop"
      :label-width="labelWidth"
      :required="required"
      :rules="rulesArray"
    >
      <el-date-picker
        v-if="isEdit && type == 'year'"
        :clearable="clearable"
        :size="size"
        v-model="inputValue"
        :type="type"
        :value-format="format"
        :placeholder="placeholderValue"
        @change="handleChange"
        :readonly="readonly"
        :disabled="disabled"
      >
      </el-date-picker>
      <el-date-picker
        :picker-options="pickerOptions"
        :clearable="clearable"
        :size="size"
        v-else-if="isPickerOptions"
        v-model="inputValue"
        :type="type"
        :value-format="format"
        :placeholder="placeholderValue"
        @change="handleChange"
        :readonly="readonly"
        :disabled="disabled"
      >
      </el-date-picker>
      <el-date-picker
        v-else-if="isDaterange"
        :clearable="clearable"
        :size="size"
        v-model="inputValue"
        :type="type"
        :value-format="format"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        @change="handleChange"
        :readonly="readonly"
        :disabled="disabled"
      ></el-date-picker>
      <el-date-picker
        v-else-if="isEdit"
        :clearable="clearable"
        :size="size"
        v-model="inputValue"
        :type="type"
        :value-format="format"
        :placeholder="placeholderValue"
        @change="handleChange"
        :readonly="readonly"
        :disabled="disabled"
      >
      </el-date-picker>
      <span v-else>
        {{ formatDate(inputValue, format) }}
      </span>
      <template v-if="isEdit && !disabled && quickChoose">
        <div class="date-quick-choose">
          <div style="display: flex">
            <div style="width: 75px">快捷选择：</div>
            <div v-if="fastKey" style="line-height: 32px; display: flex">
              <div v-for="(item, key) in getFastKeyData()" :key="key">
                <el-button
                  class="eagle-date-quick-btn"
                  size="small"
                  type="primary"
                  plain
                  @click.stop="chooseDate(item.value)"
                  >{{ item.text }}</el-button
                >
              </div>
            </div>
          </div>
        </div>
      </template>
    </el-form-item>
  </div>
</template>
<script>
export default {
  name: "eagle-date",
  props: {
    clearable: {
      type: Boolean,
      default() {
        return true;
      },
    },
    isEdit: {
      type: Boolean,
      default() {
        return true;
      },
    },
    isDaterange: {
      type: Boolean,
      default() {
        return false;
      },
    },
    isFullCol: {
      type: Boolean,
      default() {
        return false;
      },
    },
    label: {
      type: String,
      default() {
        return "";
      },
    },
    prop: {
      type: String,
      default() {
        return "";
      },
    },
    value: {
      type: String | Number,
      default() {
        return null;
      },
    },
    span: {
      type: Number,
      default() {
        return 24;
      },
    },
    placeholder: {
      type: String,
      default() {
        return "";
      },
    },
    type: {
      type: String,
      default() {
        return "date";
      },
    },
    format: {
      type: String,
      default() {
        return "yyyy-MM-dd";
      },
    },
    clearable: {
      type: Boolean,
      default() {
        return false;
      },
    },
    disabled: {
      type: Boolean,
      default() {
        return false;
      },
    },
    size: {
      type: String,
      default() {
        return "";
      },
    },

    rows: {
      type: Number,
      default() {
        return 2;
      },
    },

    readonly: {
      type: Boolean,
      default() {
        return false;
      },
    },

    labelWidth: {
      type: String,
      default() {
        return "";
      },
    },
    required: {
      type: [Boolean],
      default() {
        return false;
      },
    },
    rules: {
      type: Array,
      default() {
        return [];
      },
    },
    onlyShowRequired: {
      type: [Boolean],
      default() {
        return false;
      },
    },
    isPickerOptions: {
      type: Boolean,
      default() {
        return false;
      },
    },
    fast: {
      type: Boolean,
      default() {
        return false;
      },
    },
    fastKey: {
      type: String,
      default() {
        return "F1";
      },
    },
    quickChoose: {
      type: Boolean,
      default() {
        return false;
      },
    },
    // mustInput: {
    //   type: Boolean,
    //   default() {
    //     return false;
    //   },
    // },
  },
  data() {
    return {
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      placeholderValue: "",
      inputValue: "",
      rulesArray: [],
      shortcuts: [
        { text: "今天", key: "T", value: new Date() },
        { text: "昨天", key: "Y", value: this.setDate(-1) },
        { text: "一周前", key: "M-R7", value: this.setDate(-7) },
        { text: "一周", key: "W-2", value: this.setDate(7) },
        { text: "两周", key: "W-2", value: this.setDate(7 * 2) },
        { text: "一个月", key: "M-1", value: this.setDate(30) },
        { text: "两个月", key: "M-2", value: this.setDate(30 * 2) },
        // { text: "昨天", key: "Y", value: () => { return add(new Date(), -1, "day"); } },
        // { text: "一周前", key: "M-R7", value: () => { return add(new Date(), -7, "day") } },
        // { text: "一周", key: "W-2", value: () => { return add(new Date(), 7, "day"); } },
        // { text: "两周", key: "W-2", value: () => { return add(new Date(), 14, "day"); } },
        // { text: "一个月", key: "M-1", value: () => { return add(new Date(), 1, "month"); } },
        // { text: "两个月", key: "M-2", value: () => { return add(new Date(), 2, "month"); } }
      ],
    };
  },
  created() {
    this.placeholderValue = this.placeholder
      ? this.placeholder
      : "请选择" + this.label;
    this.inputValue = this.value;
    this.setRules();
  },
  watch: {
    value(newvalue, oldvalue) {
      this.inputValue = this.value;
    },
  },
  methods: {
    setDate(val) {
      let start = new Date();
      return start.setDate(start.getDate() + val);
    },
    setMonth(val) {
      let start = new Date();
      return start.setMonth(start.getMonth() + val);
    },

    chooseDate(value) {
      let val = this.formatDate(value);
      this.inputValue = value;
      this.$emit("input", val);
      // emit("update:modelValue", val);
    },
    getFastKeyData() {
      let array = [];
      if (this.fastKey == "F1") {
        array = ["W-1", "W-2", "M-1", "M-2"];
      }
      return this.shortcuts.filter((item) => {
        if (array.indexOf(item.key) >= 0) {
          return item;
        }
      });
    },

    setRules() {
      if (this.required && !this.onlyShowRequired) {
        this.rulesArray.push({
          required: true,
          message: this.placeholderValue,
        });
      }
      if (this.rules && this.rules.length > 0) {
        this.rules.forEach((x) => {
          this.rulesArray.push(x);
        });
      }
    },
    handleChange(newvalue) {
      this.$emit("input", newvalue);
      this.$emit("change", newvalue);
    },
  },
};
</script>
<style lang="scss" scoped>
.eagle-date {
  display: inline;
  .date-quick-choose {
    margin-top: 5px;
  }
  .eagle-date-quick-btn {
    margin-left: 10px;
  }
  ::v-deep .el-date-editor {
    height: 36px;
    line-height: 36px;
  }

  .el-range-editor--small.el-input__inner {
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-divider--vertical {
    height: 2em;
  }
  ::v-deep .el-date-editor .el-range-separator{
    display:flex;
    align-items: center;
  }
}
</style>
