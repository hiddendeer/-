<template name="eagle-condition">
    <div class="eagle-condition">
        <el-form ref="queryForm" :inline="true" :label-width="labelWidth" @submit.native.prevent="search">
            <slot />
            <el-form-item v-if="showRight">
                <el-button type="primary" icon="el-icon-search" size="mini" @click="search()">搜索</el-button>
                <el-button class="button_reset" icon="el-icon-refresh" v-if="showReset" size="mini" @click="resetQuery">
                    重置</el-button>
                <slot name="slot-buttons"></slot>
            </el-form-item>
        </el-form>
    </div>
</template>
<script>
export default {
    name: "eagle-condition",
    props: {
        showRight: { type: Boolean, default: true },
        showReset: { type: Boolean, default: true },
        labelWidth: {
            type: String,
            default() {
                return "90px";
            }
        }
    },
    methods: {
        search() {
            this.$emit("search");
        },
        resetQuery() {
            this.$emit("resetQuery");
        }
    }
};
</script>
<style scoped lang="scss">
.eagle-condition {
    ::v-deep .el-form-item {
        margin-bottom: 0px;
    }

    .button_reset {
        border: 1px solid #dfe6ec;
    }
}
</style>
<style  type="text/css">
/* .eagle-condition .el-form-item.el-form-item--medium {
    display: flex;
} */

.eagle-condition .el-button {
    line-height: 32px;
    padding: 0px 15px;
    border: 0px;
}

.eagle-condition .el-radio {
    margin-right: 10px;
}

.eagle-condition .el-radio__input {
    display: none;
}

.eagle-condition .el-radio__label {
    /* background: #1890ff;
    color: #fff; */
    padding: 5px;
    line-height: 30px;
    margin-right: 10px;
}

.eagle-condition .el-radio.is-checked .el-radio__label {
    background-color: #1890ff;
    color: #fff !important;
}
</style>