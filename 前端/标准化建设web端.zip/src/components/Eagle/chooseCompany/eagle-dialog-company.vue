<template name="eagle-dialog-dept">
  <el-dialog
    v-dialogDrag
    :title="title"
    :visible.sync="showDialog"
    width="800px"
    append-to-body
    show-close
    :close-on-click-modal="false"
  >
    <eagle-block border>
      <eagle-window-choose
        :autoCompany="false"
        :showOrder="false"
        :pageUrl="pageUrl"
        ref="EaglePage"
        table-height="500"
        :single="single"
        selectTextField="entName"
        selectField="companyId"
      >
        <template slot="slot-search">
          <eagle-condition @search="search()" @resetQuery="resetQuery()">
            <eagle-input
              label-width="80px"
              @changeEnter="search()"
              label="筛选条件"
              prop="entName"
              v-model="conditionsVals.entName"
              placeholder="请输入企业名进行模糊查询"
              clearable
              size="small"
              @input="(e) => inputFiltration(e)"
            />
          </eagle-condition>
        </template>
        <template slot="slot-table">
          <el-table-column label="企业名称" align="left" prop="entName" />
          <el-table-column label="企业联系人" align="left" prop="entContact" />
          <el-table-column
            label="企业联系人联系方式"
            align="left"
            prop="entContactMobile"
          />
        </template>
      </eagle-window-choose>
    </eagle-block>
    <span slot="footer" class="dialog-footer">
      <el-button @click="closeDialog()">取 消</el-button>
      <el-button type="primary" @click="handleChoose">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  name: "eagle-dialog-company",
  components: {},
  props: {
    single: { type: Boolean, default: true },
    pageUrl: {
      type: String,
      default: "rent/tenantRelationship/queryEnterpriseInfo",
    }, //对应后端控制器
    title: {
      type: String,
      default: "选择企业",
    }, //对应后端控制器
  },
  data() {
    return {
      // 查询条件判断方式 : like,<,>,<=,>=,= ,
      conditionsTypes: {
        name: "like",
      },
      // 查询条件
      conditionsVals: {
        entName: "",
      },

      showDialog: false,
    };
  },
  filters: {},
  created() {},
  methods: {
    splitLine(str) {
      if (str && str.includes(",")) {
        return str.replace(/,/g, "<br/>");
      } else return str;
    },
    resetQuery() {
      this.conditionsVals.entName = "";
      this.search();
    },
    handleChoose(obj) {
      let chooseObj = this.$refs.EaglePage.selection;
      if (!chooseObj || chooseObj.length <= 0) {
        this.closeDialog();
        return;
      }
      let data = {};
      if (this.single) {
        data.code = chooseObj[0].companyId;
        data.name = chooseObj[0].entName;
      } else {
        let arryCode = [];
        let arryName = [];
        let objData = [];
        chooseObj.forEach((element) => {
          arryCode.push(element.companyId);
          arryName.push(element.entName);
          objData.push(element);
        });
        data.code = arryCode.join(",");
        data.name = arryName.join(",");
        data.objData = objData;
      }
      this.$emit("callBack", data);
      this.closeDialog();
    },
    closeDialog() {
      this.conditionsVals.entName = "";
      this.showDialog = false;
    },
    //查询
    search() {
      setTimeout(() => {
        this.$refs.EaglePage.search({
          conditions: this.$refs.EaglePage.getCondtions(
            this.conditionsVals,
            this.conditionsTypes
          ),
        });
      });
    },

    show(code, name) {
      this.showDialog = true;
      setTimeout(() => {
        this.$refs.EaglePage.setInitCodes(code, name);
        this.search();
      });
    },
    inputFiltration(e) {
      this.$nextTick(() => {
        this.conditionsVals.entName = e.replace(/\s+/g, "");
      });
    },
  },
};
</script>
