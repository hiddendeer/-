<template>
  <span>
    <eagle-choose
      :label="label"
      :prop="prop"
      :label-width="labelWidth"
      @change="openChoose"
      :required="required"
      :onlyShowRequired="onlyShowRequired"
      v-model="names"
      @clearChoose="clearChoose"
    />
    <eagle-dialog-company
      ref="userDialog"
      :single="single"
      :pageUrl="pageUrl"
      :title="title"
      @callBack="handelChoose"
    ></eagle-dialog-company>
  </span>
</template>
<script>
import EagleDialogCompany from "./eagle-dialog-company.vue";

export default {
  components: { EagleDialogCompany },
  name: "eagle-choose-company",
  props: {
    prop: {
      type: String,
      default: "",
    },
    required: false,
    value: {
      type: String,
      default: "",
    },
    names: {
      type: String,
      default: "",
    },
    title: {
      type: String,
      default: "",
    },
    pageUrl: {
      type: String,
      default: "rent/tenantRelationship/queryEnterpriseInfo",
    },
    label: {
      type: String,
      default: "企业",
    },
    single: {
      type: Boolean,
      default: true,
    },

    labelWidth: {
      type: String,
      default() {
        return "";
      },
    },
    onlyShowRequired: {
      type: [Boolean],
      default() {
        return false;
      },
    },
  },
  data() {
    return {};
  },
  created() {},
  watch: {},
  methods: {
    handelChoose(data) {
      this.$emit("input", data.code);
      this.$emit("update:names", data.name);
      this.$emit("update:objData", data.objData);
      this.$emit("callBack", data);
    },
    openChoose(data) {
      this.$refs.userDialog.show(this.value, this.names);
    },
    clearChoose() {
      this.$emit("input", "");
      this.$emit("update:names", "");
      this.$emit("update:objData", []);
      this.$emit("callBack");
    },
  },
};
</script>
