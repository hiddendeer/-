<template>
  <div style="width: 100%" class="gjy-tree">
    <div v-if="!noTitle" class="tree-title">{{ this.Title }}</div>
    <div style="overflow-x: auto">
      <el-tree
        ref="newTopRightsTree"
        :data="menuList"
        :node-key="mainNo"
        :show-checkbox="showCheckbox"
        :expand-on-click-node="false"
        :default-expanded-keys="key"
        :check-on-click-node="true"
        :default-checked-keys="defaultChecked"
        @node-click="handleTreeClick"
        @check="handleCheckChange"
      >
        <span
          class="custom-tree-node"
          slot-scope="{ data }"
          @mouseenter="mouseenter(data)"
          @mouseleave="mouseleave(data)"
        >
          <i
            class="el-icon-office-building"
            style="color: #5757bc; margin-right: 5px"
            v-if="data.opNo == '00'"
          ></i>
          <i
            class="el-icon-collection"
            style="color: #409eff; margin-right: 5px"
            v-else-if="
              data.opCode !== '-1' && data.children && data.children.length > 0
            "
          ></i>
          <i class="el-icon-my-export2" style="margin-right: 5px" v-else></i>
          <el-button
            v-if="!name"
            type="text"
            :style="{ color: data.show ? '#1890ff' : '#333333' }"
          >
            <!-- <i class="el-icon-office-building" style="margin-right:5px" v-if="data.OPCode !== '-1'&& data.children == 0"></i>
            <i class="el-icon-unlock" style="margin-right:5px" v-if="data.OPCode !== '-1' && data.children.length > 0"></i> -->
            <!-- <i class="el-icon-my-export2" style="margin-right:5px"></i> -->
            {{ data.opName }}
          </el-button>
          <el-button
            v-else
            type="text"
            icon="el-icon-my-export3"
            style="margin: 0"
            :style="{ color: data.show ? '#1890ff' : '#333333' }"
            >{{ data.cName }}</el-button
          >
          <!--   v-show="data.show||(data.opName==this.opName)"-->
          <span
            slot="dropdown"
            v-show="data.show && isShow"
            v-if="data.operation"
            style="overflow: auto"
          >
            <span class="buttonGroup" style="display: flex">
              <el-tooltip effect="dark" content="新增" placement="top">
                <eagle-row-button
                  size="mini"
                  icon="el-icon-circle-plus-outline"
                  type="text"
                  @click.stop="addOp(data, 'add')"
                  :plain="false"
                ></eagle-row-button>
              </el-tooltip>
              <el-tooltip effect="dark" content="编辑" placement="top">
                <eagle-row-button
                  type="text"
                  :plain="false"
                  v-if="
                    data.opNo != '0001' &&
                    data.opNo != '0002' &&
                    data.opNo != '0003' &&
                    data.opNo != '0004' &&
                    data.opNo != '0005'
                  "
                  size="mini"
                  icon="el-icon-edit-outline"
                  @click.stop="addOp(data, 'edit')"
                ></eagle-row-button>
              </el-tooltip>
              <el-tooltip effect="dark" content="删除" placement="top">
                <eagle-row-button
                  type="text"
                  :plain="false"
                  v-if="
                    data.opNo != '0001' &&
                    data.opNo != '0002' &&
                    data.opNo != '0003' &&
                    data.opNo != '0004' &&
                    data.opNo != '0005'
                  "
                  size="mini"
                  icon="el-icon-delete"
                  @click.stop="handleDelete(data)"
                ></eagle-row-button>
              </el-tooltip>
            </span>
          </span>
        </span>
      </el-tree>
    </div>

    <window-tpldata
      ref="windowTpldata"
      @handleSubmitClose="handleSubmitClose"
    ></window-tpldata>
  </div>
</template>
<script>
import { Message, MessageBox } from "element-ui";
import windowTpldata from "../../views/support/TplOp/windowTpldata.vue";
import { handleTree } from "@/utils/EageleRMC";
export default {
  components: { windowTpldata },
  name: "eagle-tree",
  props: {
    Title: {
      type: String,
      default() {
        return "目录";
      },
    },
    isShow: {
      type: Boolean,
      default() {
        return true;
      },
    },
    controller: {
      type: String,
      default() {
        return "";
      },
    },
    companyCode: {
      type: String,
      default() {
        return "";
      },
    },
    mainNo: {
      type: String,
      default() {
        return "opNo";
      },
    },
    superiorNo: {
      type: String,
      default() {
        return "opPno";
      },
    },
    name: {
      type: Boolean,
      default() {
        return false;
      },
    },
    showCheckbox: {
      type: Boolean,
      default() {
        return false;
      },
    },
    noTitle: {
      type: Boolean,
      default() {
        return false;
      },
    },
    noCCodeArr: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      dataList: [],
      cCodes: "",
      opName: "",
      isMouseenter: true,
      menuList: [],
      opForm: {},
      windowTpDataTitle: "",
      originForm: {},
      origindata: { show: false }, //记录上一次点击的实体    用于清除显示操作状态
      key: [],
      defaultChecked: [],
    };
  },
  created() {
    this.geMenuList();
    console.log("ishow:", this.isShow);
  },
  watch: {
    noCCodeArr: {
      handler(val) {
        console.log(val);
        this.defaultChecked = val;
      },
      immediate: true,
    },
  },
  methods: {
    setCheckedKeys() {
      this.geMenuList();
    },
    mouseenter(data) {
      //鼠标移入监听
      if (this.opName !== data.opName && data.operation) {
        this.$set(data, "show", true);
      }
    },
    mouseleave(data) {
      //鼠标移出监听
      if (this.opName !== data.opName && data.operation) {
        this.$set(data, "show", false);
      }
    },
    geMenuList() {
      this.http.get(this.controller).then((res) => {
        this.key = [];
        if (res.code === 200) {
          if (this.noTitle) {
            this.dataList = res.data.list;
            let result = handleTree(
              res.data.list,
              this.mainNo,
              this.superiorNo,
              "children"
            );
            this.menuList = result;
            this.key.push(this.menuList[0].cNo);
          } else {
            let result = handleTree(
              res.data,
              this.mainNo,
              this.superiorNo,
              "children"
            );
            this.menuList = result;
            this.key.push(this.menuList[0].opNo);
          }
          console.log("http========>", this.menuList);
        }
      });
    },
    handleTreeClick(val) {
      if (this.origindata !== null) {
        this.$set(this.origindata, "show", false);
      }
      this.origindata = val;
      this.opName = val.opName;
      this.$set(val, "show", true);
      this.$emit("handleTreeClick", val);
    },
    handleCheckChange(val1, val) {
      this.cCodes = "";
      this.dataList.forEach((item) => {
        val.checkedKeys.forEach((v) => {
          if (item.cNo === v) {
            this.cCodes += item.cCode + ",";
          }
        });
      });
      this.$emit("handleCheckChange", this.cCodes);
    },
    addOp(res, val1) {
      if (val1 === "add") {
        this.$refs.windowTpldata.show(
          "目录操作-【新增】",
          res,
          1,
          val1,
          this.companyCode
        );
      } else {
        this.$refs.windowTpldata.show("目录操作-【编辑】", res, 2, val1);
      }
    },
    handleDelete(val) {
      // console.log(val);
      MessageBox.confirm("确定删除该目录吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          this.http
            .del(
              "/support/TplOp/delete/" +
                val.id +
                "?opCode=" +
                val.opCode +
                "&ids=" +
                val.id
            )
            .then((res) => {
              if (res.code === 200) {
                Message.success("删除成功");
                this.geMenuList();
                this.$emit("deleteTree");
              }
            });
        })
        .catch(() => {
          return;
        });
    },
    // handleWindowTpDataClose(val) {
    //     this.dialogVisible = val;
    // },
    handleSubmitClose(val) {
      // this.dialogVisible = val;
      this.geMenuList();
    },
  },
};
</script>

<style scoped lang="scss">
/* .el-tree-node.is-current > .el-tree-node__content {
    background-color: rgb(216, 216, 218) !important;
} */
::v-deep .el-tree-node__content {
  height: auto !important;
  .el-button--medium {
    flex: 1 1 0%;
    padding: 0 !important;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: normal;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    text-align: left !important;
  }
}
.buttonGroup {
  ::v-deep .eagle-row-btn {
    padding: 0 !important;
    margin-left: 5px !important;
  }
}
.gjy-tree {
  .custom-tree-node {
    flex: 1;
    display: flex !important;
    align-items: center !important;
  }
  .tree-title {
    width: 100%;
    height: 50px;
    line-height: 50px;
    text-align: center;
    border-bottom: 1px solid #e6e6e6;

    margin: 5px 0 0 0;
  }
  .el-tree {
    padding: 10px 0;
  }
  .el-tree .el-tree-node__content {
    display: block;
  }
  .el-tree .el-tree-node__children {
    overflow: visible;
  }
  .el-icon-my-export2 {
    background: url("../../assets/images/line_tag.png") center no-repeat;
    background-size: cover;
  }
  .el-icon-my-export3 {
    width: 20px;
    height: 10px;
    background: url("../../assets/images/设计目录.png") center no-repeat;
    background-size: contain;
  }
  .el-icon-my-export2:before {
    content: "替";
    font-size: 14px;
    visibility: hidden;
  }
  .el-icon-my-export2 {
    font-size: 14px;
  }
  .el-icon-my-export2:before {
    content: "\e611";
  }
}
</style>
