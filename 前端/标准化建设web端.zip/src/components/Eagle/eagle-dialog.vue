<template>
    <div>
        <el-dialog v-dialogDrag v-bind="$attrs" v-on="$listeners" :title="title" :visible.sync="open" :width="width" append-to-body show-close :close-on-click-modal="false" :before-close="handleClose">
            <slot></slot>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancel">关闭</el-button>
            </div>
        </el-dialog>
    </div>
</template>


<script>
// import { postData, getInfo, putData } from "@/api/http";
export default {
    name: "eagle-dialog",
    props: {
        width: {
            type: String,
            default() {
                return "600px";
            },
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
    },
    data() {
        return {
            open: false,
        };
    },
    created() {},
    methods: {
        // 关闭按钮
        cancel() {
            this.open = false;
            this.$emit("handleClose");
        },
        show() {
            this.open = true;
        },
        handleClose(done) {
            done();
            this.$emit("handleClose");
        },
    },
};
</script>