<template>
    <el-dropdown class="eagle-more-btn" type="primary" :size="size" v-bind="$attrs" v-on="$listeners">
        <eagle-row-button :size="size" :type="type" :plain="plain">
            {{btnName}} <i class="el-icon-arrow-down"></i>
        </eagle-row-button>
        <el-dropdown-menu slot="dropdown">
            <slot></slot>
        </el-dropdown-menu>
    </el-dropdown>
</template>
<script>
export default {
    name: "eagle-more-button",
    props: {
        isRow: { type: Boolean, default: true },
        size: { type: String, default: "mini" },
        btnName: { type: String, default: "更多操作" },
        type: { type: String, default: "defalut" },
        plain: { type: Boolean, default: false },
    },
    data() {
        return {};
    },
    watch: {},
    created() {},
    methods: {},
};
</script>
<style  scoped lang="scss">
.eagle-more-btn {
    margin-left: 10px;
}
</style>