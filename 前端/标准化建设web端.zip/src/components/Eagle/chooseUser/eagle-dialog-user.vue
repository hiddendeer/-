<template name="eagle-dialog-dept">
    <el-dialog v-dialogDrag :title="title" :visible.sync="showDialog" width="800px" append-to-body show-close :close-on-click-modal="false">
        <eagle-block border>
            <eagle-window-choose :queryParams="queryParams" :autoCompany="false" :pageUrl="pageUrl" :conditions="conditions" ref="EaglePage" table-height="500" :single="single" selectTextField="chnName" selectField="userName">
                <template slot="slot-search">
                    <eagle-condition @search="search()" :showReset="true" @resetQuery="resetQuery()">
                        <eagle-input label-width="80px" @changeEnter="search()" label="筛选条件" prop="chnName" v-model="conditions.chnName.value" placeholder="请输入员工进行模糊查询" clearable size="small" />
                    </eagle-condition>
                </template>
                <template slot="slot-table">
                    <el-table-column label="员工" align="left" prop="chnName" :width="100" />
                    <el-table-column label="部门名称" align="left">
                        <template slot-scope="scope">
                            <span v-html="splitLine(scope.row.orgName)"></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="部门全名称" align="left">
                        <template slot-scope="scope">
                            <span v-html="splitLine(scope.row.orgFullName)"></span>
                        </template>
                    </el-table-column>
                </template>
            </eagle-window-choose>
        </eagle-block>
        <span slot="footer" class="dialog-footer">
            <el-button @click="showDialog = false">取 消</el-button>
            <el-button type="primary" @click="handleChoose">确 定</el-button>
        </span>
    </el-dialog>
</template>

<script>
export default {
    name: "eagle-dialog-user",
    components: {},
    props: {
        single: { type: Boolean, default: true },
        msgErrorText: { type: String, default: "请选择员工" },
        title: { type: String, default: "选择员工" },
    },
    data() {
        return {
            queryParams: { dataType: "list" },
            // 查询条件判断方式 : like,<,>,<=,>=,= ,
            conditions: {
                chnName: {
                    value: "",
                },
            },
            pageUrl: "support/CommonAQXApi/getUserUser", //对应后端控制器
            showDialog: false,
        };
    },
    filters: {},
    created() {},
    methods: {
        splitLine(str) {
            if (str && str.includes(",")) {
                return str.replace(/,/g, "<br/>");
            } else return str;
        },
        handleChoose(obj) {
            let chooseObj = this.$refs.EaglePage.selection;
            if (!chooseObj || chooseObj.length <= 0) {
                this.msgError(this.msgErrorText);
                return;
            }
            let data = {};
            if (this.single) {
                data.code = chooseObj[0].userName;
                data.name = chooseObj[0].chnName;
            } else {
                let arryCode = [];
                let arryName = [];
                let arrayList = [];
                chooseObj.forEach((element) => {
                    arryCode.push(element.userName);
                    arryName.push(element.chnName);
                    arrayList.push({reportUserAccount: element.userName, reportUserName: element.chnName})
                });
                data.code = arryCode.join(",");
                data.name = arryName.join(",");
                data.arrayList = arrayList;
            }
            this.$emit("callBack", data);
            this.showDialog = false;
        },
        //查询
        search() {
            setTimeout(() => {
                this.$refs.EaglePage.search();
            });
        },

        //查询条件重置
        resetQuery() {
            this.conditions.chnName.value = "";
            this.search();
        },

        show(code, name) {
            this.showDialog = true;
            setTimeout(() => {
                this.$refs.EaglePage.setInitCodes(code, name);
                this.search();
            });
        },
    },
};
</script>