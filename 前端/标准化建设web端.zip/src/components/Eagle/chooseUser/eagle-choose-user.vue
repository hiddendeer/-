<template>
    <span>
        <eagle-choose :label="label" :prop="prop" :label-width="labelWidth" @change="openChoose" :required="required" :onlyShowRequired="onlyShowRequired" v-model="names" @clearChoose="clearChoose" />
        <eagle-dialog-user ref="userDialog" :msgErrorText='msgErrorText' :single="single" :title="title" @callBack="handelChoose"></eagle-dialog-user>
    </span>
</template>
<script>
import EagleDialogUser from "./eagle-dialog-user.vue";

export default {
    components: { EagleDialogUser },
    name: "eagle-choose-user",
    props: {
        prop: {
            type: String,
            default: "",
        },
        title: {
            type: String,
            default: "",
        },
        required: false,
        value: {
            type: String,
            default: "",
        },
        names: {
            type: String,
            default: "",
        },
        label: {
            type: String,
            default: "员工",
        },
        single: {
            type: Boolean,
            default: true,
        },

        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        msgErrorText: {
            type: String,
            default() {
                return "";
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
    },
    data() {
        return {};
    },
    created() {},
    watch: {},
    methods: {
        handelChoose(data) {
            this.$emit("input", data.code);
            this.$emit("update:names", data.name);
            this.$emit("callBack", data);
        },
        openChoose(data) {
            this.$refs.userDialog.show(this.value, this.names);
        },
        clearChoose() {
            this.$emit("input", "");
            this.$emit("update:names", "");
            this.$emit("callBack");
        },
    },
};
</script>