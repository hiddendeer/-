<template>
    <div>
        <el-dialog :title="title" :visible.sync="open" :width="width" append-to-body show-close :close-on-click-modal="false" :before-close="handleClose">
            <eagle-block border>

                <div style="display: flex; padding: 5px 10px">

                    <div>
                        <label class="el-form-item__label" style="80px;">上传文件</label>
                    </div>

                    <el-upload width="500px" ref="upload" :limit="1" accept=".xlsx, .xls" :headers="headers" :action="
            uploadUrl + '/' + url + '/importFromData'+'?templateType=' + templateType+(showOpCode ? '&opCode='+opCode+'&opFullName='+ opFullName: '') + (companyCode!==null||companyCode!==''?'&companyCode='+companyCode:'')
          " :data="ExportData" :on-progress="handleFileUploadProgress" :on-success="handleFileSuccess" :auto-upload="true" drag class="import-block">
                        <i class="el-icon-upload"></i>
                        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                        <div class="el-upload__text">仅允许xls、xlsx文件</div>
                        <div class="el-upload__tip" slot="tip"></div>
                    </el-upload>
                </div>
                <el-form ref="form" :model="ExportData" label-width="80px">
                    <eagle-choose v-if="showOpCode" label-width="80px" label="所属类目" v-model="opFullName" @change="companyTreeShow()" />
                    <el-form-item label="导入模板">
                        <el-link type="primary" :underline="false" style="font-size: 14px; vertical-align: baseline" @click="importTemplate('checkTableTemplate.xlsx')">下载合规检查表模板</el-link>
                        <div class="el-upload__text" style="color: red;"></div>
                        <el-link type="primary" :underline="false" style="font-size: 14px; vertical-align: baseline" @click="importTemplate('checkTableTemplateNos.xlsx')">下载非合规检查表模板</el-link>
                        <div class="el-upload__text" style="color: red;">每次做数据导入前，请先下载最新的数据模板核对格式。</div>
                    </el-form-item>
                    <!-- <el-form-item label="导入设置" required>
                    <el-radio-group v-model="ExportData.ImportOption">
                        <el-radio label="0">遇错停止</el-radio>
                        <el-radio label="1">遇错继续</el-radio>
                    </el-radio-group>
                </el-form-item> -->
                    <el-form-item label="导入结果">
                        <el-input v-model="result" type="textarea" :rows="4"></el-input>
                    </el-form-item>
                </el-form>
            </eagle-block>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancel">关闭</el-button>
            </div>
        </el-dialog>
        <company-tree ref="companyTree" @handleCloseDirectory="handleCloseDirectory"></company-tree>
    </div>
</template>


<script>
//检查表专用（特殊处理）
// 导出模板   导入数据操作工具类
import { getToken } from "@/utils/auth";
import { download } from "@/utils/request"
import companyTree from "@/views/support/TplOp/rightForm/companyTree.vue";

export default {
    components: { companyTree },
    name: "EagleDialogTableExce",
    props: {
        companyCode: {
            type: String,
            default: "",
        },
        width: {
            type: String,
            default() {
                return "600px";
            },
        },
        title: {
            type: String,
            default() {
                return "";
            },
        },
        url: {
            type: String,
            default() {
                return "";
            },
        },

        templateType: {
            type: String,
            default() {
                // C 代表公司   M代表我的    大写
                return "M";
            },
        },
        fileName: {
            type: String,
            default() {
                return "";
            },
        },
        showOpCode: {
            type: Boolean,
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            ExportData: {
                // ImportOption: "0",
            },
            form: {},
            uploadUrl: process.env.VUE_APP_BASE_API,
            headers: {
                Authorization: "Bearer " + getToken(),
            },
            open: false,
            queryParams: {
                fileName: "",
            },
            result: "",
            opCode: "",
            opFullName: "",
        };
    },
    created() {},
    methods: {
        //目录组件传回来的值
        handleCloseDirectory(res) {
            this.opCode = res.opCode;
            this.opFullName = res.opName;
            // this.saveList(params);
        },
        //目录选择（公司检查表用到）
        companyTreeShow() {
            this.$refs.companyTree.show(
                this.companyCode !== null || this.companyCode !== ""
                    ? true
                    : false,
                this.companyCode !== null || this.companyCode !== ""
                    ? this.companyCode
                    : ""
            );
        },
        // 文件上传中处理
        handleFileUploadProgress(event, file, fileList) {
            // this.isUploading = true;
        },
        /** 下载模板操作 */
        importTemplate(value) {
            this.queryParams.fileName = value;
            var titleName = "合规检查表导入模板.xlsx";
            if (value == "checkTableTemplateNos.xlsx") {
                titleName = "非合规检查表导入模板.xlsx";
            }
            download(
                "/" + this.url + "/importDefineTemplate",
                {
                    ...this.queryParams,
                },
                titleName
            );
            //   ——${new Date().getTime()}
        },
        // 文件上传成功处理
        handleFileSuccess(response, file, fileList) {
            //   this.open = false;
            // this.isUploading = false;
            this.$refs.upload.clearFiles();
            if (response.code == 200) {
                this.result = response.data;
            } else {
                this.result = response.errorText;
                this.$alert(
                    response.errorText
                        ? response.errorText
                        : "请核对导入文件是否与模板格式对应",
                    "错误提示"
                );
            }
            //   this.$alert(response.data, response.errorText, {
            //     dangerouslyUseHTMLString: true,
            //   });

            this.$emit("refresh");
        },
        // 关闭按钮
        cancel() {
            this.result = "";
            this.open = false;
            this.$emit("refresh");
        },
        show(opCode, opName) {
            this.opCode = opCode;
            this.opFullName = opName;
            this.open = true;
        },
        handleClose(done) {
            done();
            this.$emit("refresh");
        },
        // 提交上传文件
        submitFileForm() {
            this.$refs.upload.submit();
            this.$refs.upload.clearFiles();
            this.result = "";
        },
    },
};
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.el-form-item {
    margin-bottom: auto;
}
</style>
