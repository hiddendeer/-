<template>
  <div class="choose-date-container">
    <el-popover
      placement="bottom-start"
      width="320"
      trigger="click"
      popper-class="date-popper"
      v-model="show"
    >
      <div class="wrapper">
        <div class="head">
          <div
            class="head-item"
            :class="{ active: index === headDataIndex }"
            v-for="(item, index) in headData"
            :key="item.name"
            @click="headDataClick(index, item)"
          >
            {{ item.name }}
          </div>
        </div>
        <template v-if="contentShow">
          <div class="content">
            <div
              :class="{ active: index === yearDataIndex }"
              class="content-item-head"
              v-for="(item, index) in yearData"
              :key="item.name"
              @click="yearDataClick(index, item)"
            >
              {{ item.name }}
            </div>
            <div class="content-item-content">
              <div
                :class="{ active: index === contentHeadDataIndex }"
                v-for="(item, index) in contentHeadData"
                :key="item.name"
                @click="contentHeadDataClick(index, item)"
              >
                {{ item.name }}
              </div>
            </div>
            <div class="content-item-footer">
              <div
                :class="{ active: index === contentDataIndex }"
                v-for="(item, index) in contentData"
                :key="item.name"
                @click="contentDataClick(index, item)"
              >
                {{ item.name }}
              </div>
            </div>
          </div>
          <div class="footer" v-if="year === new Date().getFullYear()">
            <div
              :class="{ active: index === footerDataIndex }"
              v-for="(item, index) in footerData"
              :key="item.name"
              @click="footerDataClick(index, item)"
            >
              {{ item.name }}
            </div>
          </div>
        </template>
        <template v-if="datePickerShow">
          <el-date-picker
            style="width: 295px"
            v-model="value"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd"
            @change="datePickerChange"
          >
          </el-date-picker>
        </template>
      </div>
      <el-button v-if="showType==='button'" slot="reference">{{ text }}</el-button>
      <el-input v-if="showType==='input'" v-model="text" style="width:320px" readonly slot="reference"></el-input>
    </el-popover>
  </div>
</template>

<script>
export default {
  props: {
    showType:{
      type:String,
      default:'button'
    }
  },
  data() {
    return {
      text: "激活",
      show: false,
      value: "",
      dateValue: "",
      datePickerShow: false,
      contentShow: false,
      year: "",
      headData: [
        { name: "全部", value: "All-All" },
        { name: new Date().getFullYear() - 1 },
        { name: new Date().getFullYear() },
        { name: "自定义" },
      ],
      headDataIndex: 0,
      yearData: [{ name: "全年", value: "AllYear" }],
      yearDataIndex: -1,
      contentHeadData: [
        { name: "一季度", value: "FirstQuarter" },
        { name: "二季度", value: "SecondQuarter" },
        { name: "三季度", value: "ThirdQuarter" },
        { name: "四季度", value: "FourthQuarter" },
      ],
      contentHeadDataIndex: -1,
      contentData: [
        { name: "一月", value: "January" },
        { name: "二月", value: "February" },
        { name: "三月", value: "March" },
        { name: "四月", value: "April" },
        { name: "五月", value: "May" },
        { name: "六月", value: "June" },
        { name: "七月", value: "July" },
        { name: "八月", value: "August" },
        { name: "九月", value: "September" },
        { name: "十月", value: "October" },
        { name: "十一月", value: "November" },
        { name: "十二月", value: "December" },
      ],
      contentDataIndex: -1,
      footerData: [
        { name: "今天", value: "ToDay" },
        { name: "昨天", value: "YesterDay" },
        { name: "前天", value: "BeforeYesterDay" },
      ],
      footerDataIndex: -1,
    };
  },
  methods: {
    //全部行
    headDataClick(index, val) {
      this.headDataIndex = index;
      this.datePickerShow = false;
      this.yearDataIndex = -1;
      this.contentHeadDataIndex = -1;
      this.contentDataIndex = -1;
      this.footerDataIndex = -1;
      if (index === 0) {
        this.dateValue = val.value;
        this.text = "全部";
        this.datePickerShow = false;
        this.contentShow = false;
        this.show = false;
        this.$emit("chooseDate", this.dateValue);
      }
      if (index === 1) {
        this.datePickerShow = false;
        this.contentShow = true;
        this.year = val.name;
      }
      if (index === 2) {
        this.datePickerShow = false;
        this.contentShow = true;
        this.year = val.name;
      }
      if (index === 3) {
        this.datePickerShow = true;
        this.contentShow = false;
        this.show = true;
      }
    },
    //全年行
    yearDataClick(index, val) {
      this.yearDataIndex = index;
      this.contentHeadDataIndex = -1;
      this.contentDataIndex = -1;
      this.footerDataIndex = -1;
      if (this.headDataIndex === 1) {
        this.dateValue = `${new Date().getFullYear() - 1}-${val.value}`;
        this.text = `${new Date().getFullYear() - 1}年全年`;
      }
      if (this.headDataIndex === 2) {
        this.dateValue = `${new Date().getFullYear()}-${val.value}`;
        this.text = `${new Date().getFullYear()}年全年`;
      }
      this.show = false;
      this.$emit("chooseDate", this.dateValue);
    },
    //季度行
    contentHeadDataClick(index, val) {
      this.contentHeadDataIndex = index;
      this.yearDataIndex = -1;
      this.contentDataIndex = -1;
      this.footerDataIndex = -1;
      if (this.headDataIndex === 1) {
        this.dateValue = `${new Date().getFullYear() - 1}-${val.value}`;
        this.text = `${new Date().getFullYear() - 1}年${val.name}`;
      }
      if (this.headDataIndex === 2) {
        this.dateValue = `${new Date().getFullYear()}-${val.value}`;
        this.text = `${new Date().getFullYear()}年${val.name}`;
      }
      this.show = false;
      this.$emit("chooseDate", this.dateValue);
    },
    //月份行
    contentDataClick(index, val) {
      this.contentDataIndex = index;
      this.yearDataIndex = -1;
      this.contentHeadDataIndex = -1;
      this.footerDataIndex = -1;
      if (this.headDataIndex === 1) {
        this.dateValue = `${new Date().getFullYear() - 1}-${val.value}`;
        this.text = `${new Date().getFullYear() - 1}年${val.name}`;
      }
      if (this.headDataIndex === 2) {
        this.dateValue = `${new Date().getFullYear()}-${val.value}`;
        this.text = `${new Date().getFullYear()}年${val.name}`;
      }
      this.show = false;
      this.$emit("chooseDate", this.dateValue);
    },
    //今昨前天行
    footerDataClick(index, val) {
      this.footerDataIndex = index;
      this.yearDataIndex = -1;
      this.contentHeadDataIndex = -1;
      this.contentDataIndex = -1;
      if (this.headDataIndex === 1) {
        this.dateValue = `${new Date().getFullYear() - 1}-${val.value}`;
        this.text = val.name;
      }
      if (this.headDataIndex === 2) {
        this.dateValue = `${new Date().getFullYear()}-${val.value}`;
        this.text = val.name;
      }
      this.show = false;
      this.$emit("chooseDate", this.dateValue);
    },
    //日期选择器
    datePickerChange(val) {
      this.headDataIndex = -1;
      this.yearDataIndex = -1;
      this.contentHeadDataIndex = -1;
      this.contentDataIndex = -1;
      this.footerDataIndex = -1;
      if (!val) return;
      this.dateValue = val[0] + "至" + val[1];
      this.text = val[0] + " 至 " + val[1];
      this.show = false;
      this.$emit("chooseDate", this.dateValue);
    },
  },
};
</script>

<style lang="scss" scoped>
.date-popper {
  .active {
    background: #409eff;
    color: #fff !important;
    border-color: #409eff;
  }
  .head {
    display: flex;
    align-items: center;
    padding-bottom: 15px;
    margin-bottom: 15px;
    border-bottom: 1px solid #dcdfe6;

    .head-item {
      padding: 5px 12px;
      border: 1px solid #dcdfe6;
      border-radius: 8px;
      margin-right: 5px;
      cursor: pointer;
      color: #606266;
      font-size: 12px;

      &:hover {
        background: #606266;
        color: #fff;
        border-color: #606266;
      }
    }
  }

  .content {
    display: flex;
    flex-direction: column;

    .content-item-head {
      padding: 5px 12px;
      border: 1px solid #dcdfe6;
      border-radius: 8px;
      margin-right: 5px;
      width: 54px;
      margin-bottom: 15px;
      cursor: pointer;
      color: #606266;
      font-size: 12px;
      &:hover {
        background: #606266;
        color: #fff;
        border-color: #606266;
      }
    }
    .content-item-content {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
      div {
        padding: 5px 12px;
        border: 1px solid #dcdfe6;
        border-radius: 8px;
        margin-right: 5px;
        cursor: pointer;
        color: #606266;
        font-size: 12px;
        &:hover {
          background: #606266;
          color: #fff;
          border-color: #606266;
        }
      }
    }
    .content-item-footer {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      div {
        padding: 5px 12px;
        border: 1px solid #dcdfe6;
        border-radius: 8px;
        margin-right: 5px;
        margin-bottom: 10px;
        color: #606266;
        font-size: 12px;
        cursor: pointer;
        &:hover {
          background: #606266;
          color: #fff;
          border-color: #606266;
        }
      }
    }
  }
  .footer {
    display: flex;
    align-items: center;
    margin-top: 5px;
    div {
      padding: 5px 12px;
      border: 1px solid #dcdfe6;
      border-radius: 8px;
      margin-right: 5px;
      cursor: pointer;
      color: #606266;
      font-size: 12px;
      &:hover {
        background: #606266;
        color: #fff;
        border-color: #606266;
      }
    }
  }
}
</style>