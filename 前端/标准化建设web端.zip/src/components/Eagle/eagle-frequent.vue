<template name="eagle-frequent">
    <div class="eagle-frequent">
        <el-input v-model="inputVal" type='number' class="input" v-model.number="inputVal" @clear="false" :disabled="disabled" @input="handleInput" />
        <el-select v-model="selectVal" @change="handleChange">
            <el-option v-for="item in DataArray" class="select" :key="item.id" :label="item.name" :disabled="disabled" :value="item.id"></el-option>
        </el-select>
    </div>
</template>


<script>
export default {
    name: "eagle-frequent",
    props: {
        value: {
            type: Number | String,
            default: "",
        },
        // dataSource: {
        //     type: Array,
        //     default: [],
        // },
        disabled: {
            type: Boolean,
            default: false,
        },
        optionVals: { type: String, default: "HDWMQY" },
    },
    data() {
        return {
            inputVal: "",
            selectVal: "",
            DataArray: [],
            // DataArray: this.dataSource,
        };
    },
    created() {
        this.DataArray = [];
        if (this.optionVals) {
            for (let i = 0; i < this.optionVals.length; i++) {
                switch (this.optionVals.charAt(i)) {
                    case "H":
                        this.DataArray.push({ id: "H", name: "小时" });
                        break;
                    case "D":
                        this.DataArray.push({ id: "D", name: "天" });
                        break;
                    case "W":
                        this.DataArray.push({ id: "W", name: "周" });
                        break;
                    case "M":
                        this.DataArray.push({ id: "M", name: "月" });
                        break;
                    case "Q":
                        this.DataArray.push({ id: "Q", name: "季度" });
                        break;
                    case "Y":
                        this.DataArray.push({ id: "Y", name: "年" });
                        break;
                }
            }
        }
        this.setVal(this.value);
    },
    watch: {
        value(nval, oval) {
            if (nval || nval === 0) {
                this.setVal(nval);
            }
        },
    },
    methods: {
        setVal(val) {
            let i = val.indexOf("-");
            if (i >= 0) {
                if (i > 0) this.selectVal = val.substring(0, i);
                else this.selectVal = "";
                if (val.length > i) this.inputVal = val.substring(i + 1);
                else this.inputVal = "";
            }
        },
        handleInput() {
            let val = "";
            if (this.selectVal && (this.inputVal || this.inputVal == 0)) {
                val = this.selectVal + "-" + this.inputVal;
            }
            this.$emit("input", val);
        },

        handleChange() {
            let val = "";
            if (this.selectVal && (this.inputVal || this.inputVal == 0)) {
                val = this.selectVal + "-" + this.inputVal;
            }
            this.$emit("input", val);
        },
    },
};
</script>
<style scoped lang="scss">
.eagle-frequent {
    .input {
        width: 80px;
    }
    .el-select {
        width: 80px;
    }
}
</style>
 