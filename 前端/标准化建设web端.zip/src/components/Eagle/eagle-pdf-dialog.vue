<template>
    <el-dialog v-dialogDrag :visible.sync="open" :width="width" append-to-body show-close :close-on-click-modal="false" custom-class="pdf-dialog" :before-close="handleClose">
        <div slot="title" class="dialog-title">
            <div>{{ title || "文件浏览" }}</div>
            <div class="btnMargin dialog-btn" v-if="!isLib">
                <!-- <a :href="sourceUrl" :download="fileName" target="_blank"> <i class="el-icon-download"></i> </a> -->
                <div style="display:inline-block;margin-top:-7px;">
                    <template v-if="isReport">
                        <el-button size="mini" type="primary" v-if="sourceUrl" @click="downSource">导出Word报告</el-button>
                        <el-button size="mini" type="danger" v-if="pdfUrl" @click="downPdf">导出Pdf报告</el-button>
                    </template>
                    <template v-else>
                        <el-button size="mini" type="primary" v-if="sourceUrl" @click="downSource">导出</el-button>
                        <!-- <a style="color: #1890ff;" v-if="sourceUrl&&showDownLoad" @click="downSource">下载</a> -->
                    </template>
                </div>
            </div>
        </div>
        <div slot="title">
            <slot name="second-title"></slot>
        </div>
        <div style="height:600px;background: rgba(0, 0, 0, 0.7);">
            <slot>
                <template style="min-height: 400px" v-if="!isImage">
                    <eagle-pdf-view class="pdf-view" v-if="url" :url="url" ref="eaglePdfView"></eagle-pdf-view>
                </template>
                <div style="" v-if="isImage">
                    <!-- <img v-scale v-if="url" :src="url" class="imageClass"> -->
                    <el-image class="imageClass" v-if="url" :src="url" :zoom-rate="1.2" :preview-src-list="[url]" :fit="fit" />
                </div>
            </slot>
        </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="cancel">关 闭</el-button>
        </div>
    </el-dialog>
</template>

<script>
import eagleImage from "./eagle-image.vue";
export default {
    components: { eagleImage },
    name: "eagle-pdf-dialog",
    props: {
        code: {
            type: String,
            default() {
                return "";
            },
        },
        showDownLoad: {
            type: Boolean,
            default: true,
        },
        isReport: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            url: "",
            pdfUrl: "",
            sourceUrl: "",
            open: false,
            width: "1000px",
            title: "文件浏览",
            attExt: "",
            isImage: false,
            fit: "contain",
            fileName: "",
        };
    },
    computed: {
        isLib() {
            return this.url && this.url.indexOf("lib") >= 0;
        },
    },
    filters: {},
    created() {},
    methods: {
        down() {
            var _this = this;
            const a = document.createElement("a");
            fetch(_this.sourceUrl)
                .then((res) => res.blob())
                .then((blob) => {
                    a.href = URL.createObjectURL(blob);
                    a.download = _this.fileName; // 下载文件的名字
                    document.body.appendChild(a);
                    a.click();
                });
        },
        show(config) {
            this.url = "";
            this.sourceUrl = "";
            this.pdfUrl = "";
            this.fileName = "";
            var _this = this;
            if (config.url) {
                this.url = config.url;
                this.isImage = config.isImage ?? this.isImage;
                this.open = true;
            } else if (config.code) {
                this.http
                    .get("/file/getDataByAttCode/" + config.code)
                    .then((res) => {
                        if (res.code == 200) {
                            var data = res.data;
                            _this.sourceUrl = data.attFilePath;
                            _this.pdfUrl = data.attMiddlePath;
                            _this.fileName = data.attName + "." + data.attExt;

                            var isImageExt = _this.checkIsImage(data.attExt);
                            if (!isImageExt) {
                                if (data.status == 1) {
                                    _this.$alert(`文件在转换中,请稍后再试!`);
                                } else if (data.status == 10) {
                                    if (_this.checkIsVideo(data.attExt)) {
                                        _this.url = data.attFilePath;
                                    } else {
                                        _this.url = data.attMiddlePath;
                                    }

                                    _this.title =
                                        data.attName || config.fileName;
                                    _this.attExt = data.attExt;
                                    _this.open = true;
                                } else if (data.status == -1) {
                                    this.$confirm(
                                        "文件无法预览,是否下载后查看?",
                                        "提醒",
                                        {
                                            confirmButtonText: "确定",
                                            cancelButtonText: "取消",
                                            type: "warning",
                                        }
                                    )
                                        .then(function () {
                                            _this.down();
                                        })
                                        .then((res) => {})
                                        .catch(() => {});
                                }
                                if (
                                    data.attName != null &&
                                    data.attName != ""
                                ) {
                                    _this.title = data.attName;
                                }

                                _this.isImage = false;
                                // if (config.fileName) {
                                //     _this.title =
                                //         config.fileName + "." + _this.attExt;
                                // }
                            } else {
                                _this.open = true;
                                _this.title = data.attName;
                                _this.attExt = data.attExt;
                                _this.url = data.attFilePath;
                                _this.isImage = isImageExt;
                            }
                            if (config.titleName != '') {
                                _this.title = config.titleName || '文件浏览'
                            }
                        } else {
                            _this.$alert(`文件无法查到,请联系管理员处理!`);
                        }
                    });
            }
        },
        downPdf() {
            var _this = this;
            const a = document.createElement("a");
            fetch(_this.pdfUrl)
                .then((res) => res.blob())
                .then((blob) => {
                    a.href = URL.createObjectURL(blob);
                    a.download = _this.title + ".pdf"; // 下载文件的名字
                    document.body.appendChild(a);
                    a.click();
                });
        },

        downSource() {
            var _this = this;
            const a = document.createElement("a");
            fetch(_this.sourceUrl)
                .then((res) => res.blob())
                .then((blob) => {
                    a.href = URL.createObjectURL(blob);
                    a.download = _this.fileName; // 下载文件的名字
                    document.body.appendChild(a);
                    a.click();
                });
        },
        checkIsVideo(attExt) {
            if (attExt) {
                if (attExt.indexOf("avi") > -1 || attExt.indexOf("mp4") > -1) {
                    return true;
                }
            }
            return false;
        },
        checkIsImage(attExt) {
            if (attExt) {
                attExt = attExt.toLowerCase();
                if (
                    attExt.indexOf("png") > -1 ||
                    attExt.indexOf("jpg") > -1 ||
                    attExt.indexOf("jpeg") > -1 ||
                    attExt.indexOf("jpg") > -1 ||
                    attExt.indexOf("gif") > -1 ||
                    attExt.indexOf("bmp") > -1
                ) {
                    return true;
                } else {
                    return false;
                }
            }
        },
        handleClose(done) {
            if (!this.isImage && this.attExt.indexOf("mp4") > -1) {
                this.$refs.eaglePdfView.handleClose();
            }
            done();
        },
        cancel() {
            this.open = false;
        },
    },
};
</script>

<style lang="scss"  scoped>
.dialog-botton {
    color: #409eff;
}

.dialog-title {
    display: flex;
    justify-content: space-between;
    width: 930px;
    margin-right: 30px;
}

// .btnMargin {
//     margin-top: -15px;
// }
.pdf-dialog .el-dialog__header {
    background: #000;
    color: #fff;
    height: 48px;
    overflow: hidden;
}

::v-deep .pdf-dialog .el-dialog__body {
    padding: 0px;
}

// .dialog-btn {
//     float: right;
//     margin-right: 30px;
// }

.pdf-view {
    // height: 600px;
    // overflow: auto;
    height: 100%;
}

.avatar {
    margin: 0 auto;
    display: inherit;
    max-height: 600px;
}

.imageClass {
    max-width: 100%;
    max-height: 490px;
    position: absolute;
    top: 50px;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    display: block;
}
</style>