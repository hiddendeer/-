<template>
    <div class="img-pannel">

        <div v-if="fileList && fileList.length > 0" class="flex image-block">
            <template v-for="(item, index) in fileList">
                <span v-if="index<maxCount" :key="index" class="img-content" @click.stop="handlePictureCardPreview(item)">
                    <img :src="item" class="avatar" :style="{ height: height, width: width, borderRadius: borderRadius }" />
                </span>
            </template>
        </div>
        <div v-else-if="defaultPic">
            <div class="img-content">
                <img :src="defaultPic" class="avatar" />
            </div>
        </div>
        <el-dialog v-dialogDrag :visible.sync="dialogVisible" width="500px" title="图片预览" append-to-body show-close custom-class="imag-dialog">
            <img width="100%" :src="dialogImageUrl" alt="">
        </el-dialog>
    </div>
</template>
<script>
export default {
    name: "eagle-row-image",
    props: {
        value: {
            type: Array | String,
            default() {
                return "";
            },
        },
        defaultPic: {
            type: String,
            default() {
                return "";
            },
        },
        maxCount: {
            type: Number,
            default() {
                return 1;
            },
        },
        width: {
            type: String,
            default() {
                return "30px";
            },
        },
        height: {
            type: String,
            default() {
                return "30px";
            },
        },
        borderRadius: {
            type: String,
            default() {
                return "2px";
            },
        },
    },
    data() {
        return {
            fileList: [],
            dialogImageUrl: "",
            dialogVisible: false,
        };
    },
    watch: {
        value(newvalue, oldvalue) {
            if (newvalue != oldvalue) {
                this.initArry(newvalue);
            }
        },
    },
    created() {
        if (this.value) {
            this.initArry(this.value);
        }
    },
    methods: {
        handlePictureCardPreview(url) {
            this.dialogImageUrl = url;
            this.dialogVisible = true;
        },
        initArry(value) {
            this.fileList = !value ? [] : this.value.split(";");
        },
    },
};
</script>
<style  scoped lang="scss" scoped>
.avatar {
    display: block;
    border-radius: 2px;
    cursor: pointer;
}

.img-pannel {
    display: flex;
    width: 100%;
    .img-content {
        display: flex;
        position: relative;
        display: block;
        text-align: center;
        margin: 0 auto;
    }

    .eagle-img-css {
        border-radius: 2px;
    }
    .image-block {
        width: 100%;
        text-align: center;
        .img-content {
            display: inline-block;
        }
    }
}

.img-content .el-upload-list__item-actions {
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    cursor: default;
    text-align: center;
    color: #fff;
    opacity: 0;
    font-size: 20px;
    background-color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    // line-height: 82px;
    border-radius: 2px;
    top: 45%;
}

.img-content .el-upload-list__item-actions:hover {
    opacity: 1;
}

.img-content .el-upload-list__item-actions:hover span {
    display: inline-block;
}

.img-content .el-upload-list__item-actions .el-upload-list__item-delete {
    position: static;
    font-size: inherit;
    color: inherit;
    margin-left: 3px;
}

.imag-dialog .el-dialog__body {
    padding: 0;
}
</style>