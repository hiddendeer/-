<template>
    <div class="ealge-view-title">
        <i class="el-icon-s-grid"></i>
        <span> {{title}} </span>
    </div>
</template>

<script>
export default {
    name: "eagle-view-title",
    props: {
        title: {
            type: String,
        },
    },
};
</script>
<style scoped>
.ealge-view-title {
    padding-left: 8px;
    padding-right: 8px;
    border-bottom: 2px solid #999;
    display: inline-block;
    padding-bottom: 10px;
    margin-bottom: 10px;
    span {
        font-weight: 700;
        font-size: 14px;
        color: #333;
        white-space: nowrap;
    }
}
</style>