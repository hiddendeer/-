<template>
    <el-form-item :label="label" :label-width="labelWidth" :required="required" :prop="prop" :rules="rulesArray">
        <template v-if="!isEdit">
            {{formateDict(dataSource, value,id,name,',')}}</template>
        <template v-else>
            <el-checkbox-group v-model="checkList">
                <el-checkbox :style="{'width':checkWidth}" v-for="item in dataSource" :key="item[id]" :label="item[id]" @change="handleChange">{{item[name]}}</el-checkbox>
            </el-checkbox-group>
        </template>
    </el-form-item>
</template>
<script>
export default {
    name: "eagle-checkgroup",

    props: {
        isEdit: {
            type: Boolean,
            default() {
                return true;
            },
        },
        id: {
            type: String,
            default() {
                return "id";
            },
        },
        name: {
            type: String,
            default() {
                return "name";
            },
        },
        label: {
            type: String,
            default() {
                return "";
            },
        },
        value: {
            type: String | Number,
            default() {
                return null;
            },
        },
        inputName: {
            type: String | Number,
            default() {
                return null;
            },
        },
        span: {
            type: Number,
            default() {
                return 24;
            },
        },
        prop: {
            type: String,
            default() {
                return "";
            },
        },
        disabled: {
            type: Boolean,
            default() {
                return false;
            },
        },
        labelWidth: {
            type: String,
            default() {
                return "";
            },
        },
        dataSource: {
            type: Array,
            default() {
                return [];
            },
        },
        required: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        rules: {
            type: Array,
            default() {
                return [];
            },
        },
        onlyShowRequired: {
            type: [Boolean],
            default() {
                return false;
            },
        },
        isAverage: {
            type: [Boolean],
            default() {
                return true;
            },
        },
        checkWidth: {
            type: String,
            default() {
                return "80px";
            },
        },
    },
    data() {
        return {
            checkList: [],
            rulesArray: [],
        };
    },
    created() {
        if (this.value) {
            var arry = this.value.split(",");
            this.checkList = arry;
        }
        this.setRules();
        console.log("name", this.name);
    },
    updated() {},
    watch: {
        value(newvalue, oldvalue) {
            if (this.value) {
                var arry = this.value.split(",");
                this.checkList = arry;
            } else {
                this.checkList = [];
            }
        },
    },
    methods: {
        setRules() {
            if (this.required && !this.onlyShowRequired) {
                this.rulesArray.push({
                    required: true,
                    message: "请选择" + (this.label ? this.label : ""),
                    trigger: "change",
                });
            }
            if (this.rules && this.rules.length > 0) {
                this.rules.forEach((x) => {
                    this.rulesArray.push(x);
                });
            }
        },
        handleChange() {
            if (this.checkList.length > 0) {
                var stringValue = this.checkList.join(",");
                this.$emit("input", stringValue);
                this.$emit("change", stringValue, this.checkList);
            } else {
                this.$emit("input", "");
                this.$emit("change", "", this.checkList);
            }
        },
    },
};
</script>
<style scoped>
.avageWidth {
    min-width: 80px;
}
</style>