<template>
    <div>
        <div v-if="fileList && fileList.length > 0">
            <div class="upload-list_item-preview single-line" :class="{ 'upload-list_item-preview1': noWidth }"
                v-for="(item, index) in fileList" :key="index" v-if="item" :title="item.name || item.AttName">
                <span class="upload-list_item " @click.stop="handlePreview(item)">
                    <div style="display:inherit;position: relative;">
                        <img class="img_class" style="width:16px;height:16px;position:absolute;top:0px"
                            :src="item | getIcon" alt="">
                        <span style="display:inherit;margin-left:20px;  font-size: 12px;color: #1890FF;">预览</span>
                    </div>
                </span>
            </div>
        </div>
        <div v-else>--</div>
        <eagle-pdf-dialog :isReport="isReport" ref="PdfDialog"></eagle-pdf-dialog>
    </div>
</template>
<script>
export default {
    name: "eagle-row-attach-preview",
    props: {
        value: {
            type: Array | String,
            default() {
                return "";
            },
        },
        noWidth: {
            type: Boolean,
            default: false,
        },
        isReport: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            fileList: [],
        };
    },
    filters: {
        getIcon: function (item) {
            return require("@/assets/images/view/host/preview.png");
        },
    },
    watch: {
        value(newvalue, oldvalue) {
            if (newvalue) {
                if (typeof newvalue == "string") {
                    var arryFile = JSON.parse(newvalue);
                    this.fileList = arryFile;
                } else {
                    this.fileList = newvalue;
                }
            } else {
                this.fileList = [];
            }
        },
    },
    created() {
        if (this.value) {
            if (typeof this.value == "string") {
                var arryFile = JSON.parse(this.value);
                this.fileList = arryFile;
            } else {
                this.fileList = this.value;
            }
        }
    },
    methods: {
        handlePreview(row) {
            let code = row.attCode || row.AttCode;
            var params = { code: code };
            params.fileName = row.name;
            this.$refs.PdfDialog.show(params);
        },
    },
};
</script>
<style  scoped lang="scss">
.upload-list_item-preview {
    text-align: left;
    cursor: pointer;
    width: 100%;
}

.upload-list_item-preview1 {
    text-align: left;
    cursor: pointer;
    width: auto;
    margin: 0 15px 10px 0;
}

.upload-list_item {
    // display: inline-block;
    white-space: nowrap;
    color: #1b76d1;
}
</style>