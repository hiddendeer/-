<template>
  <el-form-item
    :label="label"
    :prop="prop"
    :label-width="labelWidth"
    :required="required"
    style="width: 500px"
    :rules="rulesArray"
    ref="elUpload"
  >
    <div style="display: flex" v-if="isEdit">
      <div v-if="fileList.length < count" class="img-content">
        <el-upload
          class="upload-block"
          :limit="count"
          :action="uploadUrl"
          :show-file-list="false"
          :before-upload="handleBeforeUpload"
          :on-success="handleUploadSuccess"
          :on-error="handleUploadError"
          name="file"
          :headers="headers"
          ref="upload"
          :accept="accept"
          :multiple="multiple"
          :on-progress="handleOnProgress"
          :on-exceed="onExceed"
        >
          <span
            class="el-div-btn"
            v-if="btnLoading"
            @click.stop
            :loading="btnLoading"
            :disabled="btnLoading"
            ><i class="el-icon-loading"></i>正在上传中...</span
          >
          <el-button v-else size="small" type="primary">{{
            btnTitle
          }}</el-button>
        </el-upload>
      </div>
      <div style="margin-left: 10px">
        <slot />
      </div>
    </div>
    <div v-if="fileList.length > 0">
      <ul class="el-upload-list" v-for="(item, index) in fileList" :key="index">
        <li tabindex="0" class="is-success">
          <a
            @click="handlePreView(item.attCode || item.AttCode || item.code)"
            style="color: #1890ff"
          >
            <i class="el-icon-document"></i>
            {{ item["name"] || item["AttName"] }}
          </a>
          <label
            v-if="isEdit"
            class="el-upload-list__item-status-label"
            @click="fileList.splice(index, 1)"
          >
            <i class="el-icon-upload-success el-icon-circle-check"></i>
          </label>
          <i
            style="color: #666"
            class="el-icon-delete upload-delete"
            v-if="isEdit"
            @click="fileList.splice(index, 1)"
          ></i>
          <!-- <i class="el-icon-bottom" @click="download(item)"></i> -->
        </li>
      </ul>
    </div>
    <el-progress
      :percentage="progressPercent"
      v-show="showProgress"
    ></el-progress>
    <eagle-pdf-dialog ref="PdfDialog"></eagle-pdf-dialog>
  </el-form-item>
</template>

<script>
import { getToken } from "@/utils/auth";

export default {
  name: "eagle-attach",
  props: {
    value: {
      type: Array | String,
      default() {
        return [];
      },
    },
    label: {
      type: String,
      default() {
        return "";
      },
    },
    prop: {
      type: String,
      default() {
        return "";
      },
    },
    labelWidth: {
      type: String,
      default() {
        return "";
      },
    },
    required: {
      type: [Boolean],
      default() {
        return false;
      },
    },
    span: {
      type: Number,
      default() {
        return 24;
      },
    },
    // 上传文件大小限制(MB)
    fileSize: {
      type: Number,
      default: 500,
    },
    /* 类型（base64格式、url格式） */
    onlyShowRequired: {
      type: [Boolean],
      default() {
        return false;
      },
    },
    isReplaceFile: {
      type: [Boolean],
      default() {
        return false;
      },
    },
    count: {
      type: Number,
      default: 9,
    },
    isEdit: {
      type: Boolean,
      default() {
        return true;
      },
    },

    accept: {
      //上传附件的格式用","分割
      type: String,
      default() {
        return "";
      },
    },
    btnTitle: {
      type: String,
      default: "点击上传",
    },
    fileFormat: {
      type: String,
      default: "",
    },
    multiple: {
      type: Boolean,
      default() {
        return true;
      },
    },
  },
  data() {
    return {
      uploadUrl: process.env.VUE_APP_BASE_API + "/file/upload", // 上传的图片服务器地址
      headers: {
        Authorization: "Bearer " + getToken(),
      },
      fileList: [],
      rulesArray: [],
      isInit: false,
      showProgress: false,
      progressPercent: 0,
      imageFormat: ["png", "jpg", "jpeg", "webp"],
      videoFormat: ["mp4"],
      fileListValue: [],
      btnLoading: false,
    };
  },
  computed: {},
  watch: {
    value(newvalue, oldvalue) {
      // 超出限制数量则删除 
      // if (newvalue.length > this.count) {
      //   this.fileList.splice(this.count, Number(newvalue.length-this.count));
      // }
      this.btnLoading = false;
      this.showProgress = false;
      if (newvalue.length == oldvalue.length) return;
      if (newvalue && newvalue?.length > 0) {
        this.isInit = false;
        if (typeof newvalue == "string") {
          var arryFile = JSON.parse(newvalue);
          this.fileList = arryFile;
        } else {
          this.fileList = newvalue;
        }
      } else {
        this.isInit = true;
        this.fileList = [];
        this.$refs.upload?.clearFiles();
      }
    },
    fileList(nval, oval) {
      // this.fileListValue = [];
      if (nval) {
        nval.forEach((item, index) => {
          // this.fileListValue.push({ url: item });
        });
      }

      this.$emit("input", nval);
      this.$emit("handleChange", nval);

      if (!this.isInit && this.prop) this.$refs.elUpload.validate("change");
    },
  },
  created() {
    if (this.value) {
      if (typeof this.value == "string") {
        var arryFile = JSON.parse(this.value);
        this.fileList = arryFile;
      } else {
        this.fileList = JSON.parse(JSON.stringify(this.value));
      }
    }
    this.setRules();
  },
  mounted() {},
  beforeDestroy() {
    this.isInit = true;
  },
  methods: {
    setRules() {
      if (this.required && !this.onlyShowRequired) {
        this.rulesArray.push({
          required: true,
          message: "请选择" + (this.label ? this.label : ""),
          trigger: "change",
        });
      }
      if (this.rules && this.rules.length > 0) {
        this.rules.forEach((x) => {
          this.rulesArray.push(x);
        });
      }
    },
    // 上传前校检格式和大小
    handleBeforeUpload(file) {
      // 校检文件大小
      if (this.fileSize) {
        const isLt = file.size / 1024 / 1024 < this.fileSize;
        if (!isLt) {
          this.$message.error(`上传文件大小不能超过 ${this.fileSize} MB!`);
          return false;
        }
      }
      // // 校验文件后缀
      // if (this.accept != "") {
      //   const type = file.type.split("/")[1];
      //   let acceptIncludes = this.accept
      //     .replace(/\.|\s/g, "")
      //     .replace(/jpg/g, "jpeg")
      //     .split(",")
      //     .includes(type);
      //   if (!acceptIncludes) {
      //     this.$message.warning("上传文件类型有误，请重新上传");
      //     return false;
      //   }
      // }

      //校验文件格式
      if (this.fileFormat) {
        const type = file.type.split("/")[1];
        if (this.fileFormat === "image") {
          if (!this.imageFormat.includes(type)) {
            this.$message.error(
              `上传文件仅支持 ${this.imageFormat.join()} 格式!`
            );
            return false;
          }
        }
        if (this.fileFormat === "video") {
          if (!this.videoFormat.includes(type)) {
            this.$message.error(
              `上传文件仅支持 ${this.videoFormat.join()} 格式!`
            );
            return false;
          }
        }
      }
      return true;
    },
    handleUploadSuccess(res, rawFile) {
      if (res.code == 200) {
        var data = res.data;
        var doc = {
          name: data.attName,
          attCode: data.attCode,
          attExt: data.fileExt,
          attFilePath: data?.filePath || '',
          filePath: data?.filePath || '',
        };
        if (this.isReplaceFile) {
          var arry = [];
          arry.push(doc);
          this.fileList = arry;
        } else {
          this.fileList = [...this.fileList, doc];
        }
        this.showProgress = false;
        this.btnLoading = false;
      } else {
        this.$message.error("附件上传失败");
        this.showProgress = false;
        this.btnLoading = false;
      }
    },
    handleUploadError() {
      this.$message.error("附件上传失败");
      this.showProgress = false;
      this.btnLoading = false;
    },
    handlePreView(attCode) {
      var params = { code: attCode };
      this.$refs.PdfDialog.show(params);
    },
    handleOnProgress(event, file, fileList) {
      this.btnLoading = true;
      this.showProgress = true;
      var number = Number(((event.loaded / event.total) * 100).toFixed(1));
      this.progressPercent = number;
    },
    download(item) {
      var _this = this;
      this.http.get("/file/getDataByAttCode/" + item.attCode).then((res) => {
        if (res.code == 200) {
          var data = res.data;
          var sourceUrl = data.attFilePath;
          var fileName = data.attName;
          console.log(data);
          _this.downloadFile(sourceUrl, fileName);
        } else {
          _this.$alert(`文件无法查到,请联系管理员处理!`);
        }
      });
    },
    downloadFile(downloadUrl, fileName) {
      var _this = this;
      const a = document.createElement("a");
      fetch(downloadUrl)
        .then((res) => res.blob())
        .then((blob) => {
          a.href = URL.createObjectURL(blob);
          a.download = fileName; // 下载文件的名字
          document.body.appendChild(a);
          a.click();
        });
    },
    onExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 ${this.count} 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
  },
};
</script>

<style scoped lang='scss'>
.el-upload-list__item:first-child {
  margin-top: 2px;
}

.el-upload-list__item .el-icon-close {
  right: 25px;
}

.el-upload-list__item-status-label {
  right: 25px;
}

.el-icon-bottom {
  position: absolute;
  right: 5px;
  top: 5px;
  color: #40d783;
}

.el-div-btn {
  padding: 9px 15px;
  font-size: 12px;
  border-radius: 3px;
  color: #ffffff;
  background-color: #1890ff;
  border-color: #1890ff;
}

.el-upload-list {
  .upload-delete {
    text-indent: 20px;
  }
}
</style>
