<template>
    <div class="eagle-block" :class="{'eagle-block-border':border}">
        <div class="header-block" v-if="$slots.header||title">
            <span v-if="title">{{title}}</span>
            <div v-else>
                <slot name="header"></slot>
            </div>
        </div>
        <div class="eagle-block-content">
            <slot></slot>
        </div>
    </div>

</template>
<script>
export default {
    name: "eagle-block",
    props: {
        title: {
            type: String,
            default() {
                return "";
            },
        },
        border: {
            type: [Boolean],
            default() {
                return false;
            },
        },
    },
    data() {
        return {
            show: false,
        };
    },
    created() {},
    watch: {},
    methods: {},
};
</script>
<style scoped lang="scss">
.eagle-block {
    background: #fff;
    border-radius: 5px;
    overflow: hidden;
    .header-block {
        padding: 7px 15px 7px;
        min-height: 40px;
        line-height: 28px;
        border-bottom: 1px solid #e6ebf5;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        background: #fff;
        border-radius: 5px 5px 0 0;
        color: #303133;
    }
    .eagle-block-content {
        padding: 10px;
    }
}
.eagle-block-border {
    border: 1px solid #e1e1e1;
    border-radius: 5px;
}
</style>