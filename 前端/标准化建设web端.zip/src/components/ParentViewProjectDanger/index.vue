<template >
    <div class="danger-index-container">
        <eagle-block>
            <project-header>
            </project-header>
        </eagle-block>
        <!-- <task-process></task-process> -->
        <div class="content-block mt10">
            <div class="content-left mr10" v-if="name != 'ProjectMainIndex'">
                <left-menu></left-menu>
            </div>
            <div class="content-right" style="width: auto;overflow-y:visible;">
                <router-view :key="key" />
            </div>
        </div>
    </div>
</template>
<script>
import ProjectHeader from "@/components/ParentViewProject/projectHeader";
import leftMenu from "@/components/ParentViewProjectDanger/leftMenu.vue";
// import taskProcess from "@/views/project/components/projectConsultation/taskProcess.vue";
export default {
    components: { ProjectHeader, leftMenu },
    computed: {
        key() {
            return this.$route.path;
        },
    },
    data() {
        return {
            modulesId: "",
            name: "",
        };
    },
    mounted() {
        this.modulesId = this.$route.meta.modulesId;
        this.name = this.$route.name;

        if (this.$route.matched.length > 0) {
            this.name =
                this.$route.matched[this.$route.matched.length - 1].name;
        }
    },
};
</script>
<style lang="scss" scoped >
.danger-index-container {
    // .layer {
    //     border: none;
    //     padding: 0px;
    // }
    // .app-container {
    //     padding: 0px;
    // }
}

.content-block {
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -ms-flex-wrap: nowrap;
    flex-wrap: nowrap;
    overflow-y: visible;
    height: calc(100vh - 140px);
}

.content-left {
    border-radius: 5px;
    width: 200px;
    height: calc(100vh - 140px);
    // background: #fff;
}

.content-right {
    flex: 1;
    // border-left: 1px solid #e6e6e6;
    overflow-x: hidden;

    overflow-y: hidden;
    border-radius: 5px;
    height: calc(100vh - 140px);
}
</style>