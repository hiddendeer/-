import request from '@/utils/request'
import XLSX from "xlsx";
import FileSaver from "file-saver";
import http from "@/api/http.js";


var common = {
  
  getparams: function (paramid) {
    var params = {
      paramid: paramid
    }
    return request({
      url: "/danger/params/getParamslist",
      method: 'get',
      params
    })
  },

  getModuleSettins: function (moduleCode) {
    return request({
      url: "/danger/settingItem/settingKV/" + moduleCode,
      method: 'get'
    })
  },

  getCustomDict: function (keys) {
    let params = {
      paramsIds: keys
    }
    return request({
      url: "/danger/settingItem/getCustomDicts",
      method: 'get',
      params
    })
  },


  getDangerCustomParam(paramArray, callback) {
    let keys = paramArray.join(',');
    return request({
      url: "/danger/dangerCompanyDict/getCustomParams",
      method: 'get',
      params: {
        paramIds: keys
      }
    }).then((res) => {
      if (typeof callback === "function") {
        callback(res);
      }

    })
  },

  getParam(paramId, callback) {
    return request({
      url: "/system/dict/data/paramsList",
      method: 'get',
      params: {
        paramId: paramId
      }
    }).then((res) => {
      if (typeof callback === "function") {
        callback(res);
      }

    })
  },
  getBatechParam(paramArray, callback) {
    let keys = paramArray.join(',');
    return request({
      url: "/system/dict/data/paramsLists",
      method: 'get',
      params: {
        paramIds: keys
      }
    }).then((res) => {
      if (typeof callback === "function") {
        callback(res);
      }

    })
  },
  writeXLSXFile(FileName, plan) {
    let FileNames = FileName
    if (plan == '') {
      plan = "el-table__fixed";
    }
    if (FileName == '') {
      FileNames = `导出表格—${new Date().getTime()}.xlsx`;
    } else {
      FileNames = FileName + `—${new Date().getTime()}.xlsx`;
    }
    let table = document.getElementsByClassName(plan)[0].cloneNode(true);
    let tableHeader = table.querySelector('.el-table__fixed-header-wrapper')
    let tableBody = table.querySelector('.el-table__body');
    tableHeader.childNodes[0].append(tableBody.childNodes[1]);
    let headerDom = tableHeader.childNodes[0].querySelectorAll('th');
    // 移除checkbox的节点
    if (headerDom[0].querySelectorAll('.el-checkbox').length > 0) {
      headerDom[0].remove();
    }
    for (let key in headerDom) {
      if (headerDom[key].innerText == '序号' || headerDom[key].innerText == '操作') {
        headerDom[key].remove();
      }
    }
    // 清理掉checkbox 序号 操作按钮
    let tableList = tableHeader.childNodes[0].childNodes[2].querySelectorAll('td');
    for (let key = 0; key < tableList.length; key++) {
      if (tableList[key].querySelectorAll('.el-checkbox').length > 0 || tableList[key].querySelectorAll('.el-button').length > 0 || tableList[key].querySelectorAll('.index').length > 0) {
        tableList[key].remove();
      }
    }
    // 获取web的节点
    let workbooks = XLSX.utils.table_to_book(tableHeader);
    let webOut = XLSX.write(workbooks, { bookType: 'xlsx', bookSST: true, type: 'array' });
    try {
      FileSaver.saveAs(new Blob([webOut], { type: 'application/octet-stream' }), FileNames);
    } catch (e) {
      if (typeof console !== 'undefined') console.log(e, webOut)
    }
  },
  number_format(num, withcents) {
    var originnum = num;
    num = num.toString().replace(/\$|\,/g, "");
    if (isNaN(num)) {
      num = "0";
    }
    var sign = num == (num = Math.abs(num));
    num = Math.floor(num * 100 + 0.50000000001);
    var cents = num % 100;
    num = Math.floor(num / 100).toString();
    if (cents < 10) {
      cents = "0" + cents;
    }
    for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
      num =
        num.substring(0, num.length - (4 * i + 3)) +
        "," +
        num.substring(num.length - (4 * i + 3));
    }
    var rs = (sign ? "" : "-") + num + "." + cents;
    if (!withcents && parseInt(originnum) == parseFloat(originnum)) {
      return rs.split(".")[0];
    } else {
      return rs;
    }
  },
  handleExport(loading, codeNo, year, companyCode, code) {
    let url = "site/fileToolDataSource/uploadDoc?companyCode=" + companyCode;
    code = code ?? "";
    let _this = this;
    let params = {
      codeNo: codeNo,
      args: {
        year: year,
        code: code
      },
      advice: {
        Year: year
      },
    };
    http.postLoading(loading,
      url,
      params,
      function (res) {
        if (res.code == 200) {
          let path = res.data.attFilePath;
          let fileName = res.data.name + "." + res.data.attExt;
          _this.downLoadByPath(path, fileName);
        }
      }
    );
  },

  downLoadByPath(path, fileName) {
    const a = document.createElement("a");
    var url = path;
    fetch(url)
      .then((res) => res.blob())
      .then((blob) => {
        a.href = URL.createObjectURL(blob);
        a.download = fileName; // 下载文件的名字
        document.body.appendChild(a);
        a.click();
      });
  }
}
export default common
