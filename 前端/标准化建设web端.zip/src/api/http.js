import request from '@/utils/request'

var http = {
  // 查询【请填写功能名称】详细
  get: function (url, params) {
    return request({
      url: url,
      method: 'get',
      params: params
    })
  },


  post: function (url, data) {
    return request({
      url: url,
      method: 'post',
      data: data
    })
  },


  postLoading: function (loading, url, data, success, error) {
    return request({
      url: url,
      method: 'post',
      data: data
    }).then(res => {
      if (res.code == 200)
        success && success(res)
      else {
        error && error(res)
      }
      setTimeout(() => {
        loading && loading.close();
      });
    }).then(() => {
      setTimeout(() => {
        loading && loading.close();
      });
    })
      .catch(() => {
        loading.close();
      })
  },

  postParams: function (url, params) {
    return request({
      url: url,
      method: 'post',
      params: params
    })
  },

  put: function (url, data) {
    console.log(url)
    return request({
      url: url,
      method: 'put',
      data: data
    })
  },


  // 删除【请填写功能名称】
  del: function (url, params) {
    return request({
      url: url,
      method: 'delete',
      params: params
    })
  },

  delLoading: function (loading, url, params, success, error) {
    return request({
      url: url,
      method: 'delete',
      params: params
    }).then(res => {
      if (res.code == 200)
        success && success(res)
      else {
        error && error(res)
      }
      setTimeout(() => {
        loading && loading.close();
      }, 1000);
    }).then(() => {
      setTimeout(() => {
        loading && loading.close();
      }, 1000);
    }).catch(() => {
      loading.close();
    })
    // return request({
    //   url: url,
    //   method: 'delete',
    //   params: params
    // })
  }
}
export default http
