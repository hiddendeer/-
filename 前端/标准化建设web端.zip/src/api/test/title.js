import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function listTitle(query) {
  return request({
    url: '/test/title/getPageData',
    method: 'get',
    params: query
  })
}

// 查询【请填写功能名称】详细
export function getTitle(code) {
  return request({
    url: '/test/title/getInfo/' + code,
    method: 'get'
  })
}

// 新增【请填写功能名称】
export function addTitle(data) {
  return request({
    url: '/test/title',
    method: 'post',
    data: data
  })
}

// 修改【请填写功能名称】
export function updateTitle(data) {
  return request({
    url: '/test/title/edit',
    method: 'post',
    data: data
  })
}

// 删除【请填写功能名称】
export function delTitle(code) {
  return request({
    url: '/test/title/delete/' + code,
    method: 'delete'
  })
}
