import request from "@/utils/request";

// 获取全部演练数据
export function getEntGetPageData(query = {}) {
    return request({
        url: "/site/planDrillPlan/entGetPageData",
        method: "get",
        params: query,
    });
}
