var constParams = {
  sys_user_sex: "sys_user_sex", //	用户性别
  sys_show_hide: "sys_show_hide", //	菜单状态
  sys_normal_disable: "sys_normal_disable", //	系统开关
  sys_job_status: "sys_job_status", //	任务状态
  sys_job_group: "sys_job_group", //	任务分组
  sys_yes_no: "sys_yes_no", //	系统是否
  sys_notice_type: "sys_notice_type", //	通知类型
  sys_notice_status: "sys_notice_status", //	通知状态
  sys_oper_type: "sys_oper_type", //	操作类型
  sys_common_status: "sys_common_status", //	系统状态
  danger_lgd: "danger_lgd", //	隐患分类
  hidden_danger_type: "hidden_danger_type", //	隐患性质
  equ_status: "equ_status", //	设备状态
  equipment_type: "equipment_type", //	设备类型
  equipment_type_simple: "equipment_type_simple", //	设备类型(简单)
  site_plan_type: "site_plan_type", //	应急预案-预案类型
  site_danger_check_template_type: "site_danger_check_template_type", //	隐患检查任务_检查类型(台账)
  site_plan_goods_cycle: "site_plan_goods_cycle", //	应急物资（点检周期）
  accident_type: "accident_type", //	事故类型
  accident_level: "accident_level", //	事故等级
  accident_content_type: "accident_content_type", //	内容类型
  site_dangerous_operation_type: "site_dangerous_operation_type", //	危险作业类型
  site_dangerous_operation_user_type: "site_dangerous_operation_user_type", //	危险作业审批记录作业人员类型
  cert_kind: "cert_kind", //	证书类别
  site_chemistry_prop: "site_chemistry_prop", //	危险化学品其他属性
  site_accident_type: "site_accident_type", //	事故类型
  site_accident_happen_side: "site_accident_happen_side", //	事故发生方
  fire_frequency: "fire_frequency", //	消防点检频率
  cert_state: "cert_state", //	证书状态
  support_content_type: "support_content_type", //	内容类型
  site_danger_template_op: "site_danger_template_op", //	模板所属类目
  site_projectFiles_aqpjjg: "site_projectFiles_aqpjjg", //	建设项目档案-安全评价结果
  site_projectFiles_jgysjg: "site_projectFiles_jgysjg", //	建设项目档案—竣工验收结果
  site_projectFiles_ysjg: "site_projectFiles_ysjg", //	建设项目档案——验收结果
  public_isok: "public_isok", //	公共是否字典
  train_records_kind: "train_records_kind", //	培训类型
  site_train_plan_type: "site_train_plan_type", //	培训计划类型
  site_construction_type: "site_construction_type", //	施工安全——施工类型（多选）
  safe_cost_plan_type: "safe_cost_plan_type", //	安全生产费用计划类别
  site_plan_target_type: "site_plan_target_type", //	安全生产计划目标计量单位
  site_plan_target_cycle_type: "site_plan_target_cycle_type", //	安全生产计划目标~周期
  supplier_category: "supplier_category", //	培训机构类别
  site_projectFiles_nature: "site_projectFiles_nature", //	建设项目档案—项目性质
  is_need_review: "is_need_review", //	证书需要复审
  state_plan: "state_plan", //	计划状态
  danger_plan_check_type: "danger_plan_check_type", //	检查计划-检查类型
  site_project_service_type: "site_project_service_type", //	服务类别
  site_project_node_approve: "site_project_node_approve", //	项目节点-审批
  site_project_node_files: "site_project_node_files", //	项目节点-文件上传
  danger_isTrue: "danger_isTrue", //	隐患排查治理服务-是否
  danger_PersonWithDeptShowType: "danger_PersonWithDeptShowType", //	隐患排查治理服务-选择人员/部门界面的显示方式
  danger_DangerCheckUnPassSetting: "danger_DangerCheckUnPassSetting", //	隐患排查治理服务-使用检查表选择符合/不适用时，录入信息设定
  danger_JoinCheckEndType: "danger_JoinCheckEndType", //	隐患排查治理服务-应用检查表联合检查时结束检查表的方式
  testaaaa: "testaaaa", //	测试数据
  danger_check_plan_type: "danger_check_plan_type", //	隐患排查-检查计划分类
  site_project_contract_status: "site_project_contract_status", //合同状态
  site_project_renewal_status: "site_project_renewal_status", //续签状态
  site_project_track_status: "site_project_track_status", //跟踪状态
  site_project_generate_project: "site_project_generate_project", //生成项目类型
  site_project_contract_invoice_state: "site_project_contract_invoice_state", //开票历史-状态
  site_project_contract_back_state: "site_project_contract_back_state", //回款历史-状态
  site_project_enterprise_scale: "site_project_enterprise_scale", // 企业规模
  site_project_source_type: "site_project_source_type", // 客户来源
  site_project_customer_track_mode: "site_project_customer_track_mode", // 跟踪方式
  site_project_contract_dts_receive_status: "site_project_contract_dts_receive_status", // 回款状态
  site_project_tax_included: "site_project_tax_included", //含税类型
  site_project_collection_mode: "site_project_collection_mode", //回款方式
  site_project_manager_list_state: "site_project_manager_list_state", //项目列表-状态
  site_project_invoice_apply_status: "site_project_invoice_apply_status", //开票申请-状态
  support_noticeType: "support_noticeType", //消息提示-消息方式
  site_project_invoice_search_status: "site_project_invoice_search_status", //开票查询状态
  end_building_fire_grade: "end_building_fire_grade", //耐火等级
  end_building_danger_type: "end_building_danger_type", //危险性分类
  end_building_purpose: "end_building_purpose", //建筑用途
  end_building_Regulatoryfocus: "end_building_Regulatoryfocus", //监管重点
  end_building_material: "end_building_material", //建筑材质
  end_building_structure: "end_building_structure", //建筑结构
  file_online_temp_doc_type: "file_online_temp_doc_type", //在线模板类型
  ledger_temp_catalog_category: "ledger_temp_catalog_category", // 台账在线模板中目录类型
  site_project_contract_back_status: "site_project_contract_back_status", //合同回款状态
  host_webSite_declareStatus: "host_webSite_declareStatus", //申报记录状态
  doc_type: "doc_type", //八大要素
  site_relation_type: "site_relation_type", //相关方类型
  site_space_danger: "site_space_danger", //主要风险
  site_space_type: "site_space_type", //有限空间类型
  site_material_storage: "site_material_storage", //存储方式
  site_material_purpose: "site_material_purpose", //原辅料主要用途
  site_material_danger_attribute: "site_material_danger_attribute", //主要危险属性
  site_material_physical_form: "site_material_physical_form", //物质形态
  site_equipment_secure_attach: "site_equipment_secure_attach", //安全附件
  site_enterprise_danger: "site_enterprise_danger", //企业关键风险点
  site_enterprise_factory_ownership: "site_enterprise_factory_ownership", //企业厂房权属
  site_enterprise_standardization_level: "site_enterprise_standardization_level", //企业标准化等级
  site_risk_rpType: "site-risk-rpType", //风险点类型
  support_health_hazard_factors: "support_health_hazard_factors", //职业病危害因素
  site_risk_frequency: "site-risk-frequency", //管控周期
  system_staff_role: "system_staff_role", //员工角色
  system_bi_report_type: "sys_bi_report_type", //报表类型
  service_frequency: "service_frequency", //频次
  service_frequency_type: "service_frequency_type", //频次类型
  system_warning_module: "warning_module", //预警-所属模块
  system_warning_type: "warning_type", //预警-预警类型
  site_risk_check_type: "risk_check_type",//风险管控检查类型
  site_check_frequency: "check_frequency",//风险管控检查频次
  site_risk_control_person: "risk_control_person",//风险管控检查类型
  site_risk_control_level: "risk_control_level",//风险管控管控层级
  site_risk_merge_check_type: "risk_merge_check_type",//风险管控类型设定
  site_check_type: "check_type",//风险管控措施类型
  site_risk_level : "risk_level",//风险管控措施类型
  risk_influence_scope : "risk_influence_scope", //风险影响范围
  risk_disposal_doc_type :"disposal_doc_type",//应急预案文件类型
  risk_site_accident_type :"site_accident_type",//应急预案文件类型
};

export default constParams;
