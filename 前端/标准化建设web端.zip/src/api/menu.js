import request from '@/utils/request'

// 获取路由
export const getRouters = (modulesId) => {
  return request({
    url: `/system/menu/getRouters/${modulesId}`,
    method: 'get'
  })
}