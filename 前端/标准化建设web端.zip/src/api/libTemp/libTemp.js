import request from "@/utils/request";

// 获取默认当前行业
export function getListWithTypeOne(query = {}) {
  return request({
    url: "/support/dangerlgclassify/GetListWithTypeOne",
    method: "get",
    params: query,
  });
}

// 获取默认当前行业-新
export function getListWithTypeOne1(query = {}) {
  return request({
    url: "/site/entInfo/getEnterpriseInfo",
    method: "post",
    params: query,
  });
}

// 查询依据库三级目录数据
export function dangerlgclassify(query = {}) {
  return request({
    url: "/support/dangerlgclassify/getClassifyList",
    method: "get",
    params: query,
  });
}

// 查询依据库列表数据
export function getPageData(query = {}) {
  return request({
    url: "/support/dangerlg/getPageData",
    method: "get",
    params: query,
  });
}

// 查询依据库详情数据
export function getGetDetail(query = {}) {
  return request({
    url: "/support/dangerlg/getGetDetail",
    method: "get",
    params: query,
  });
}

// 依据收藏
export function collect(query = {}) {
  return request({
    url: "/support/dangerlg/collect",
    method: "get",
    params: query,
  });
}

//依据取消收藏
export function unCollected(query = {}) {
  return request({
    url: "/support/dangerlg/unCollected",
    method: "get",
    params: query,
  });
}

// 依据忽略
export function ignore(query = {}) {
  return request({
    url: "/support/dangerlg/Ignore",
    method: "get",
    params: query,
  });
}

//依据恢复
export function unIgnore(query = {}) {
  return request({
    url: "/support/dangerlg/UnIgnore",
    method: "get",
    params: query,
  });
}

//手动添加依据初始化
export function newCompany(query = {}) {
  return request({
    url: "/support/dangerlg/NewCompany",
    method: "get",
    params: query,
  });
}

//手动添加依据
export function addBasis(query = {}) {
  return request({
    url: "/support/dangerlg/add",
    method: "post",
    params: query,
  });
}

//删除手动添加依据
export function deleteCompany(query = {}) {
  return request({
    url: "/support/dangerlg/DeleteCompany",
    method: "get",
    params: query,
  });
}

//修改手动添加依据初始化
export function getCompanyDetail(query = {}) {
  return request({
    url: "/support/dangerlg/GetCompanyDetail",
    method: "get",
    params: query,
  });
}

//修改手动添加依据
// export function editCompany(query = {}) {
//   return request({
//     url: '/support/dangerlg/EditCompany',
//     method: 'post',
//     params: query
//   })
// }

//隐患忽略
export function ignoreHiddenDanger(query = {}) {
  return request({
    url: "/support/dangerlg/IgnoreHiddenDanger",
    method: "get",
    params: query,
  });
}

//隐患恢复
export function unIgnoreHiddenDanger(query = {}) {
  return request({
    url: "/support/dangerlg/UnIgnoreHiddenDanger",
    method: "get",
    params: query,
  });
}

// 基础依据移除隐患
export function removeHiddenDanger(query = {}) {
  return request({
    url: "/support/dangerlg/RemoveHiddenDanger",
    method: "post",
    params: query,
  });
}

// 基础依据添加隐患
// export function addHiddenDanger(query = {}) {
//   return request({
//     url: '/support/dangerlg/AddHiddenDanger',
//     method: 'post',
//     params: query
//   })
// }

//获取所有隐患分类
export function getDangerType(query = {}) {
  return request({
    url: "/support/dangerlg/getDangerType",
    method: "get",
    params: query,
  });
}

//获取所有行业
export function getListWithType(query = {}) {
  return request({
    url: "/support/dangerlgclassify/GetListWithType",
    method: "get",
    params: query,
  });
}

//初始化data
export function initData(query = {}) {
  return request({
    url: "/support/DagerTpl/initData",
    method: "get",
    params: query,
  });
}

//获取公共检查表表格数据
export function getPageListData(query = {}) {
  return request({
    url: "/support/DagerTpl/getPageListData",
    method: "get",
    params: query,
  });
}

//自建检查对象库
//获取检查对象
export function getMyselfClassifyList(query = {}) {
  return request({
    url: "/support/dangerLGClassifyCompany/getClassifyList",
    method: "get",
    params: query,
  });
}

//获取检查要素
export function getMyselfPageData(query = {}) {
  return request({
    url: "/support/dangerLGClassifyCompany/getPageData",
    method: "get",
    params: query,
  });
}
//获取许可证菜单
export function getDict(url, query = {}) {
  return request({
    url: `/site/${url}/getDict`,
    method: "get",
    params: query,
  });
}