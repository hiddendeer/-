<template>
  <div class="page-container">
    <div class="searchInput !px-[8px]">
      <div
        class="flex items-center flex-1"
        @click="openSelect('typeList', pages?.warnType)"
      >
        <span>类型</span>
        <fui-input
          class="ml-[4px] !py-[4px] !w-[75%]"
          size="24"
          v-model="tools.warnTypeName"
          backgroundColor="#eee"
          placeholder="请选择预警类型"
          readonly
          clearable
        ></fui-input>
      </div>
      <div
        class="flex items-center justify-end flex-1"
        @click="openSelect('levelList', pages?.warnLevel)"
      >
        <span>级别</span>
        <fui-input
          class="ml-[4px] !py-[4px] !w-[75%]"
          size="24"
          v-model="tools.warnLevelName"
          backgroundColor="#eee"
          placeholder="请选择预警级别"
          readonly
          clearable
        ></fui-input>
      </div>
      <fui-select
        :show="tools.showType"
        :options="tools.typeList"
        title="请选择预警级别"
        isReverse
        closeColor="#6D758A"
        @confirm="(e) => onConfirmRadio(e, 'warnType', 'warnTypeName')"
        @close="tools.showType = false"
      />
      <fui-select
        :show="tools.showLevel"
        :options="tools.levelList"
        title="请选择预警类型"
        isReverse
        closeColor="#6D758A"
        @confirm="(e) => onConfirmRadio(e, 'warnLevel', 'warnLevelName')"
        @close="tools.showLevel = false"
      />
    </div>
    <scroll-view
      class="w-full h-[88vh] box-border"
      scroll-y="true"
      @scroll="scroll"
      @scrolltolower="lower"
    >
      <div class="list-wrap">
        <fui-loading
          v-if="loading"
          isMask
          text="加载中"
          type="col"
        ></fui-loading>
        <fui-empty
          v-else-if="listData.length < 1 && !loading"
          color="#999"
          marginTop="180"
          src="/static/empty.png"
          title="暂无数据"
        />
        <div
          v-for="item in listData"
          v-else
          :key="item.inspectionRecordId"
          class="box"
          @click="toDetail(item)"
        >
          <div style="flex: 1; overflow: hidden">
            <div class="box-row flex">
              <p class="label-text">店招名：</p>
              <p class="fui-text__explain">{{ item?.companyName }}</p>
            </div>
            <div class="box-row flex">
              <p class="label-text">安全事件：</p>
              <p class="fui-text__explain">{{ item?.safeEventName }}</p>
            </div>
            <div class="box-row flex">
              <p class="label-text">预警级别：</p>
              <p class="fui-text__explain">{{ item?.warnLevelName }}</p>
            </div>
            <div class="box-row flex">
              <p class="label-text">预警类型：</p>
              <p class="fui-text__explain">{{ item?.warnTypeName }}</p>
            </div>
          </div>
          <img
            src="/static/image/right_arrow.png"
            style="height: 24rpx; width: 24rpx"
          />
        </div>
      </div>
    </scroll-view>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref, watch } from "vue";
import { onPullDownRefresh } from "@dcloudio/uni-app";
import api from "./server/api.js";
import commonApi from "@/api/commonApi";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();
const listData = ref([]);
const loading = ref(false);
const tools = reactive({
  scrollYTop: 0,
  oldScrollYTop: 0,
  isLastPage: false,
  typeList: [],
  levelList: [],
  warnLevelName: "",
  warnTypeName: "",
  showType: false,
  showLevel: false,
});
const pages = reactive({
  pageSize: 10,
  pageNo: 1,
  // warnType: "",
  // warnLevel: "",
});
// 监听配置参数
watch(
  () => tools.warnTypeName,
  (newVal) => {
    if (newVal == "") {
      pages.warnType = "";
      tools.isLastPage=false;
      listData.value=[];
      pages.pageNo=1;
      getList();
    }
  },
  {
    deep: true,
  }
);
watch(
  () => tools.warnLevelName,
  (newVal) => {
    if (newVal == "") {
      pages.warnLevel = "";
      tools.isLastPage=false;
      listData.value=[];
      pages.pageNo=1;
      getList();
    }
  },
  {
    deep: true,
  }
);
onMounted(async () => {
  getDicList("yjlx", "typeList");
  getDicList("yjjb", "levelList");
  getList();
});
//下拉刷新
onPullDownRefresh(() => {
  getDicList("yjlx", "typeList");
  getDicList("yjjb", "levelList");
  clear();
  setTimeout(() => {
    uni.stopPullDownRefresh();
  }, 1000);
});
const getDicList = async (code, list) => {
  let res = await commonApi.getDicList({ dictTypeCode: code });
  if (res?.code && res?.code == "00000") {
    if (code == "industry") tools.industryList = [];
    res?.data?.map((it) => {
      it.id = it.dictId;
      it.text = it.dictName;
      it.checked = false;
    });
    tools[list] = res?.data ?? [];
  }
};
const openSelect = (list, id) => {
  tools[list]?.forEach((item) => {
    if (item.dictId == id) {
      item.checked = true;
    }
  });
  if (list == "typeList") {
    tools.showType = true;
  } else {
    tools.showLevel = true;
  }
};
const onConfirmRadio = (e, type, name) => {
  pages[type] = e?.options?.dictId;
  tools[name] = e?.options?.dictName;
  tools.isLastPage=false;
  listData.value=[];
  pages.pageNo=1;
  if (type == "warnType") {
    tools.showType = false;
  } else {
    tools.showLevel = false;
  }
  getList();
};
const getList = async () => {
  if (tools.isLastPage) {
    uni.showToast({
      title: "到底啦!",
      icon: "none",
    });
    return;
  }
  let obj = JSON.parse(JSON.stringify(pages));
  let res = await api.getList(obj);
  if (res?.code == "00000") {
    if (res?.data?.pages == res?.data?.current) {
      tools.isLastPage = true;
    }
    res?.data?.records?.map((item) => {
      listData.value.push(item);
    });
  }
};
const lower = (e) => {
  pages.pageNo++;
  getList();
};
const search = (e) => {
  pages.merchantName = e?.detail?.value;
  pages.pageNo = 1;
  tools.isLastPage = false;
  listData.value = [];
  getList();
};
const clear = () => {
  pages.merchantName = "";
  pages.pageNo = 1;
  tools.isLastPage = false;
  listData.value = [];
  getList();
};

const toDetail = (e) => {
  uni.navigateTo({
    url: `/pages/warning/detail?id=${e?.id}`,
  });
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: calc(100vh - 88rpx);
  .searchInput {
    background: #fff;
    height: 100rpx;
    padding: 0;
    display: flex;
    align-items: center;
  }

  .list-wrap {
    width: 100%;
    padding: 30rpx;
    box-sizing: border-box;

    .box {
      width: 100%;
      height: auto;
      display: flex;
      background-color: #fff;
      border-radius: 10rpx;
      margin-bottom: 20rpx;
      color: #333;
      align-items: center;
      justify-content: space-between;
      font-size: 32rpx;
      padding: 20rpx;
      box-sizing: border-box;

      .box-row {
        padding-bottom: 10rpx;

        p {
          min-width: 160rpx;
          color: #666;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .fui-text__explain {
          color: #333;
        }
      }
    }
  }
  :deep(.fui-input__wrap) {
    padding: 4px 8px !important;
  }
  :deep(.uni-input-placeholder) {
    font-size: 12px !important;
  }
  :deep(.fui-input__clear-wrap) {
    height: 16px !important;
    width: 16px !important;
  }
}
</style>
