import http from '@/utils/network.js'

export default class Api {
  static getList = (data) => {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/web/earlyWarning/page',
      method: 'GET',
      data
    })
  }
  static getDetail = (data) => {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/getEarlyWarnDetail',
      method: 'GET',
      data
    })
  }
}