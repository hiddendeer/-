<template>
  <div
      class="page-container bg-[#F4F5F7] text-16px flex flex-col overflow-auto"
  >
    <div class="px-[15px]">
      <p class="font-bold py-[5px]">隐患图片</p>
      <fui-upload
          v-if="quesFileList?.length > 0"
          :fileList="quesFileList"
          :isDel="false"
          :isAdd="false"
          class="my-[15px]"
      ></fui-upload>
      <div class="text-28rpx" v-else>暂无数据</div>
      <p class="font-bold py-[5px]">视频</p>
      <fui-upload-video
          v-if="quesFileListVideo?.length > 0"
          ref="upload"
          :fileList="quesFileListVideo"
          isView
      ></fui-upload-video>
      <div class="text-28rpx" v-else>暂无数据</div>
      <template v-if="detail?.riskInfo?.question">
        <p class="font-bold py-[5px]">描述</p>
        <fui-textarea disabled v-model="detail.riskInfo.question" />
      </template>
      <template v-if="detail?.riskInfo?.opinion">
        <p class="font-bold py-[5px]">整改意见</p>
        <fui-textarea disabled v-model="detail.riskInfo.opinion" />
      </template>
      <div class="flex py-[5px]" v-if="detail?.warnLevelName">
        <div class="text-32rpx font-bold">预警级别:</div>
        <div class="text-32rpx pl-[10rpx] flex" :class="[detail?.warnLevelName == '红色预警' ? 'text-[red]' : ( detail?.warnLevelName == '黄色预警' ? 'text-[yellow]' : 'text-[orange]' )]">
          {{ detail?.warnLevelName }}
        </div>
      </div>
      <div class="flex py-[5px]" v-if="detail?.warnTypeName">
        <div class="text-32rpx font-bold">隐患类型:</div>
        <div class="text-32rpx pl-[10rpx] flex">
          {{ detail?.warnTypeName }}
        </div>
      </div>
      <div class="flex py-[5px]" v-if="detail?.riskInfo?.overdueDays">
        <div class="text-32rpx font-bold">逾期未整改天数:</div>
        <div class="text-32rpx pl-[10rpx] flex text-[red]">
          {{ detail?.riskInfo?.overdueDays }} 天
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import {ref, reactive, onMounted, onBeforeUnmount} from "vue";
import api from "./server/api";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();
const listData = ref([
  {
    merchantAliasName: "11111",
    merchantName: "11111",
    createTime: "11111",
    createUser: "11111",
  },
]);
const loading = ref(false);
const tools = reactive({
  scrollYTop: 0,
  oldScrollYTop: 0,
});
const detail = ref({
  riskInfo: {
    // question: '',
    // opinion: ''
  },
});
const quesFileList = ref([]);
const quesFileListVideo = ref([]);
onMounted(() => {
  getDetail();
});
onBeforeUnmount(()=>{
  uni.closePreviewImage()
})
const getDetail = async (val) => {
  let res = await api.getDetail({ cewId: route.query?.id });
  if (res?.code && res?.code == "00000") {
    detail.value = res?.data ?? [];
    if (res?.data?.riskInfo?.fileList?.length > 0) {
      let quesFileListTemp = [];
      let quesFileListVideoTemp = [];
      res?.data?.riskInfo?.fileList?.forEach((item) => {
        if (item.fileType == `0`) {
          quesFileListTemp.push(item?.fileUrl);
        }
        if (item.fileType == `1`) {
          quesFileListVideoTemp.push(item?.fileUrl);
        }
      });
      quesFileList.value = quesFileListTemp;
      quesFileListVideo.value = quesFileListVideoTemp;
    }
  }
};
const scroll = (e) => {
  tools.oldScrollYTop = e.target.scrollTop;
};
</script>

<style lang="scss" scoped>
.page-container {
  height: calc(100vh - 88rpx);
}
:deep(.fui-upload__wrap) {
  width: calc(100vw - 60rpx) !important;
  flex-wrap: nowrap !important;
  overflow-x: auto !important;
}
:deep(.fui-tabs__text) {
  transform: scale(1) !important;
}
</style>
