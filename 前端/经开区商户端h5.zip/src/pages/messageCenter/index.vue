<template>
    <div class="body">
        <!-- <fui-sticky>
            <div class="bg-white">
              <fui-segmented-control :current="data.current" :values="['未读消息', '已读消息']"
                                     color="#999" bold activeColor="#333" type="text"
                                     @click="(e) => changeTab(e, 'current')"></fui-segmented-control>
              <fui-search-bar v-model="data.title" placeholder="请输入标题名称" @search="search"
                              @cancel="cancel"></fui-search-bar>
            </div>
          </fui-sticky>-->
        <scroll-view class="w-full h-[100vh]  pt-0 pb-[100rpx] box-border" scroll-y="true" @scrolltolower="lower"
                     @scroll="scroll">
            <div class="p-[20rpx] pt-0">
                <fui-list v-if="data.list.length > 0">
                    <fui-list-cell class="relative" marginTop="20" arrow v-for="item in data.list" :key="item.id"
                                   @click="handlerDetials(item)">
                        <div>
                            <p class="text-32rpx mb-[20rpx]">
                                <text>{{ item.title ? item.title:'-' }}</text>
                            </p>
                            <p class="text-[#999999]" v-if="item.content">
                                <text>{{ item.content ? item.content:'-' }}</text>
                            </p>
                            <p class="text-[#999999]">
                                <text>{{ item.createTime ? item.createTime:'-' }}</text>
                            </p>
                        </div>
                        <div class="box_state text-[#fff]" :class="{  blue: item.isRead == '1'}">
                            {{ item.isRead==0 ? '未读':'已读' }}
                        </div>

                    </fui-list-cell>
                </fui-list>
                <fui-empty v-else src="/static/empty.png" title="暂无消息"></fui-empty>
            </div>
        </scroll-view>
        <fui-dialog :show="showDialog" title="" :content="message" maskClosable :buttons="buttons"
                    @click="onTap"></fui-dialog>


    </div>
</template>

<script setup>
import {computed, onMounted, ref, watch} from "vue";
import {onPullDownRefresh, onReachBottom, onShow} from '@dcloudio/uni-app';
import {checkMessageUrl} from '@/utils/messageUrl';
import api from "./service/api";
import {useStore} from "vuex";

const store = useStore();
const showDialog = ref(false);
const message = ref('');
const buttons = ref([
    {
        text: '确定',
        color: '#3187FF'
    }
])
const data = ref({
    current: 0,
    taskCurrent: 0,
    list: [],
    pageNo: 1,
    isLastPage: false
})

// onMounted(() => {
//   getList()
// })
onShow(() => {
    reset()
    api.getUnreadCount().then(res => {
        if (res.data >= 0) {
            store.commit("tabbar/setMessageNum", res.data)
        }
    })
})
const onTap = (e) => {
    console.log(e)
    showDialog.value = false;
    message.value = '';

}


const lower = (e) => {
    if (!data.value.isLastPage) {
        data.value.pageNo++;
    }
    getList();
}
//下拉刷新
onPullDownRefresh(() => {
    data.value.current = 0;
    reset()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 1000);
})
//上拉加载
onReachBottom(() => {
    getList()
})
const changeTab = (e, type) => {
    reset()
    data.value[type] = e.index;
}
//重置
const reset = () => {
    data.value.list = [];
    data.value.pageNo = 1;
    data.value.isLastPage = false;
    getList()
}

const handlerDetials = async (val) => {
    if (val.isRead=='0') {
        await api.haveRead({
            receiverId: val.receiverId
        });
        val.isRead = '1';
        api.getUnreadCount().then(res => {
            if (res.data >= 0) {
                store.commit("tabbar/setMessageNum", res.data)
            }
        })
    }


    let isPass = await hasNavagateTo(val);
    if (!isPass) return;
    let obj = checkMessageUrl(val);
    if ((obj.url=='/'|| obj.url =='/?type=2') && obj.url) {
        uni.reLaunch({
            url: obj.url,
        })
    } else if (obj.message) {
        message.value = obj.message;
        showDialog.value = true
    } else if (obj.url) {
        uni.navigateTo({
            url: obj.url
        })
    }
}
const getList = async () => {
    if (data.value.isLastPage) {
        uni.showToast({
            title: '到底啦!',
            icon: 'none',
        });
        return
    }
    let obj = {
        pageNo: data.value.pageNo,
    }
    const res = await api.getMessage(obj);
    if (res.success) {
        data.value.isLastPage = res.data.totalPage==res.data.pageNo ? true:false;
        res.data.rows.map(item => {
            data.value.list.push(item)
        })
    }
}
const getShowTask = computed(() => {
    //返回的是ref对象
    return store.state.tabbar.messageNum
})
watch(getShowTask, (v) => {
    console.log(v, 'v')
    if (v > 99) {
        uni.setTabBarBadge({
            index: 2,
            text: '99+'
        })
    } else if (v > 0 && v <= 99) {
        uni.setTabBarBadge({
            index: 2,
            text: v
        })
    } else {
        uni.removeTabBarBadge({
            index: 2,
            text: 0
        })
    }
}, {immediate: true, deep: true})
//判断当前任务状态是否存在
const hasNavagateTo = async (val) => {
    let status;
    if (val.templateCode=='checkTaskMsg' || val.templateCode=='checkTaskToCompanyMsg') {
        status = await getCheckTaskStatus(val);

    } else if (val.templateCode=='reviewTaskMsg' || val.templateCode=='rectificationMsg') {
        status = await isNullRecordById(val);

    } else if (val.templateCode=='earlyWarningMsg' || val.templateCode=='earlyWarningToCompanyMsg') {
        status = await getEarlyWarnStatus(val);

    } else {
        return true;
    }


    if (status && status.data=="OK") {
        return true;
    } else {
        uni.showToast({
            title: status.data,
            icon: 'none',
        });
        return false;


    }
    // return true;
}

const getEarlyWarnStatus = async (v) => {
    const res = await api.getEarlyWarnStatus({
        cewId: v.recordId
    });
    return res
}
const isNullRecordById = async (v) => {
    const res = await api.isNullRecordById({
        recordId: v.recordId
    });
    return res;
}
const getCheckTaskStatus = async (v) => {
    const res = await api.getCheckTaskStatus({
        taskId: v.recordId
    });
    return res;
}
</script>

<style scoped lang="scss">
page {
    background-color: #F4F5F7;
}

:deep(.fui-segmented__item-line) {
    width: 40rpx;
    background-color: #1D4AD4 !important;
    left: calc(50% - 20rpx);
}

.body {
    width: 100%;
    height: auto;
    display: inline-block;
}


.box_state {
    position: absolute;
    right: 0;
    top: 0;
    border-radius: 0rpx 10rpx 0rpx 10rpx;
    color: #fff;
    text-align: center;
    width: 100rpx;
    height: 50rpx;
    line-height: 50rpx;
    font-size: 24rpx;
    background-color: #13BA79;
}

.blue {
    background-color: #3187FF;
}

</style>