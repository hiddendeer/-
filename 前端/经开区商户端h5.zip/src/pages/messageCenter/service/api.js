import http from '@/utils/network.js'

export default class api {


    static getMessage(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/siteMsg/getMessageList',
            method: 'GET',
            data
        })
    }
    static haveRead(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/siteMsg/haveRead',
            method: 'GET',
            data
        })
    }

    static getUnreadCount() {
        return http.request({
            url: '/tvrjet-edz-company-app/siteMsg/getUnreadCount',
            method: 'GET',
        })
    }

    // 获取预警状态，是否删除
    static getEarlyWarnStatus(data) {
        return http.request({
            url: '/tvrjet-edz-supervision-app/gov/web/siteMsg/getEarlyWarnStatus',
            method: 'GET',
            data,
            cancelToken:true,
        })
    }
    // 整改 审核 验收
    static isNullRecordById(data) {
        return http.request({
            url: '/tvrjet-edz-supervision-app/gov/h5/checkRecord/isNullRecordById',
            method: 'GET',
            data,
            cancelToken:true,
        })
    }
    // 获取检查任务状态
    static getCheckTaskStatus(data) {
        return http.request({
            url: '/tvrjet-edz-supervision-app/gov/web/siteMsg/getCheckTaskStatus',
            method: 'GET',
            data,
            cancelToken:true,
        })
    }
}
