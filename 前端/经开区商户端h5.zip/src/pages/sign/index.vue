<template>
  <view class="login-page">
    <image class="login-bg" src="/static/sign/login_bg.png" mode="widthFix" />
    <view class="login-title">经开区智慧安监</view>
    <view class="login-box" v-show="showLoginBox">
      <fui-input
        required
        label="账号"
        placeholder="请输入账号"
        v-model="formData.userPhone"
        maxlength="20"
      ></fui-input>
      <fui-input
        required
        password
        label="密码"
        placeholder="请输入密码"
        v-model="formData.pwd"
        maxlength="20"
        @input="passwordIpt"
      ></fui-input>
      <view class="submit-btn">
        <fui-button
          text="登 录"
          height="80rpx"
          radius="48rpx"
          @click="submit()"
          :loading="signInLoading"
          :disabled="signInLoading"
        ></fui-button>
      </view>
      <view class="submit-btn text-center text-16px text-[#2563eb]">
        <span @click="addMerchant">新商户注册</span>
      </view>
    </view>
    <view class="mobile-btn" v-show="!showLoginBox">
      <fui-button
        text="手机号一键登录"
        radius="48rpx"
        openType="getPhoneNumber"
        @getphonenumber="submitP"
        :loading="signInLoading"
        :disabled="signInLoading"
      ></fui-button>
    </view>
    <view class="login-way">
      <view class="btn" @click="showLoginBox = !showLoginBox">{{
        showLoginBox ? "手机号登录" : "密码登录"
      }}</view>
    </view>
    <fui-toast ref="toast"></fui-toast>
    <fui-safe-area></fui-safe-area>
  </view>
  <fui-select
    :show="showSelect"
    :options="companyItems"
    title="请选择企业登录"
    @confirm="onConfirm"
    @close="showSelect = false"
  ></fui-select>
</template>

<script>
import api from "./server/api.js";
import { mapActions, mapState } from "vuex";
import _ from "lodash";
import form from "@/components/firstui/fui-validator/fui-validator";
export default {
  data() {
    return {
      signInLoading: false,
      showSelect: false,
      companyItems: [],
      showLoginBox: false,
      //校验规则
      rules: [
        {
          name: "userPhone",
          rule: ["required"],
          msg: ["请输入账号"],
        },
        {
          name: "pwd",
          rule: ["required"],
          msg: ["请输入密码"],
        },
      ],
      //表单data数据
      formData: {
        userPhone: "",
        pwd: "",
      },
    };
  },
  // computed: {
  //   ...mapState("auth", {
  //     signInLoading: (state) => state.signInLoading,
  //     userData: (state) => state.userData,
  //   }),
  // },
  watch: {
    userData: {
      handler(val) {
        if (!_.isEmpty(val)) {
          this.toHomePages();
        }
      },
      deep: true,
    },
  },
  // 灵锡获取授权
  // async mounted() {
  //   const res = await api.getInitCode();
  //   console.log(window.ls);
  //   if (res?.code == "00000") {
  //     window.ls.ready(function () {});
  //     window.ls.error(function (e) {
  //       console.log(e, "错误信息");
  //     });
  //     // 确保ready方法初始化以后调用config方法
  //     console.log(res.data.lxAppId, 1);
  //     console.log(res.data.initCode, 2);
  //     window.ls.config({
  //       debug: true,
  //       appId: res.data.lxAppId,
  //       initCode: res.data.initCode,
  //     });
  //   }
  // },
  methods: {
    passwordIpt(v) {
      this.$nextTick(() => {
        this.formData.password = v.replace(/[^\@\d\a-\z\A-\Z]/g, "");
      });
    },
    toHomePages() {
      uni.reLaunch({
        url: "/pages/home/index",
      });
    },
    addMerchant() {
      uni.navigateTo({
        url: "/pages/homePage/newCheck/businessDetail?type=add",
      });
    },
    async submit() {
      let res = form.validator(this.formData, this.rules);
      if (res.isPassed) {
        let companyRes = await api.getCompanyList(this.formData);
        if (
          companyRes?.code &&
          companyRes.code == "00000" &&
          companyRes?.data?.length > 0
        ) {
          if (companyRes?.data?.length > 1) { 
            companyRes?.data.forEach((item, index) => {
              if (index == "0") {
                item.checked = true;
              }
              item.text = item?.companyAliasName+"("+item?.companyName+")";
            });
            this.companyItems = companyRes?.data;
            this.showSelect = true;
          } else if (companyRes?.data?.length == 1) {
            // 只有1条直接登录
            const { id: userId } = companyRes?.data?.[0];
            this.login(userId);
          }
        }
      } else {
        this.$refs.toast.show({ text: res.errorMsg });
      }
    },
    async login(userId) {
      const loginRes = await api.login({
        userId,
        clientId: "1187303628294764583",
      });

      if (loginRes?.code && loginRes.code == "00000") {
        uni.setStorageSync("token", loginRes?.data?.otherProperties?.token);
        uni.setStorageSync(
          "merchantId",
          loginRes?.data?.otherProperties?.merchantId
        );
        uni.setStorageSync("account", loginRes?.data?.account);
        uni.setStorageSync("userId", loginRes?.data?.userId);
        this.toHomePages();
      }
    },

    async submitP(v) {
      this.$store.commit("auth/setSignInLoading", true);
      if (v.errMsg !== "getPhoneNumber:ok") {
        this.$store.commit("auth/setSignInLoading", false);
        return;
      }
      this.$store.dispatch("auth/onSignIn", {
        appId: "wxa110c4259b7e0a05",
        secret: "680d64843c09d43dd1fe331a45fa0461",
        code: v.code,
      });
    },
    onConfirm(e) {
      this.login(e.options.id);
    },
  },
};
</script>

<style lang="scss" scoped>
.login-page {
  padding: 0 32rpx;
  display: flex;
  flex-direction: column;

  .login-bg {
    width: 380rpx;
    margin: 162rpx auto 20rpx;
  }

  .login-title {
    color: #555;
    font-size: 32rpx;
    text-align: center;
  }

  .mobile-btn {
    margin-top: 130rpx;
    /* #ifdef H5*/
    display: none;
    /* #endif */
  }

  .login-box {
    margin-top: 30rpx;
    /* #ifdef H5*/
    display: block !important;

    /* #endif */
    .submit-btn {
      margin-top: 50rpx !important;
    }
  }

  .login-way {
    display: flex;
    justify-content: center;
    margin-top: 74rpx;
    /* #ifdef H5*/
    display: none;

    /* #endif */
    .btn {
      font-size: 32rpx;
      font-weight: 500;
      text-decoration: underline;
      color: #465cff;
      line-height: 45rpx;
      cursor: pointer;
    }
  }
}
</style>
