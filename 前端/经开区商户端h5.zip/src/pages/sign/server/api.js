import http from '@/utils/network.js'

export default class Api {
    // 登录获取企业列表
    static getCompanyList(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getCompanyList',
            method: 'POST',
            data: data
        })
    }
    // 登录获取sso企业列表
    static getCompanyListByUmaToken(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getCompanyListByUmaToken',
            method: 'GET',
            data: data
        })
    }
    // 登录获取企业列表
    static login(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/login',
            method: 'POST',
            data: data
        })
    }
    // 登录获取企业列表
    static getInitCode(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sys/lingxi/getInitCode',
            method: 'GET',
            data: data
        })
    }
}