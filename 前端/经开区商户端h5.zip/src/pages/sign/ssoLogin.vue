<template>
  <div v-if="!loading" class="h-[100vh] ">
    <div class="h-[50vh] w-full flex flex-col justify-center items-center">
      <fui-avatar width="200" style="margin-bottom: 15px;" src="/static/merchantSelfTest.png"></fui-avatar>
      <fui-button @click="handleCheckPort('2')" size="40" width="200px" bold background="#069b87">商户自查</fui-button>
    </div>
    <div class="h-[50vh] w-full flex flex-col  justify-center items-center">
      <fui-avatar width="200" style="margin-bottom: 15px;" src="/static/supervisedCheck.png"></fui-avatar>
      <fui-button @click="handleCheckPort('1')" size="40" width="200px" bold background="#0070c0">监督检查</fui-button>
    </div>
  </div>
  <div v-else class="h-[100vh] mt-[300rpx]">
    <fui-load-ani type="5"></fui-load-ani>
    <div class="text-25rpx text-[#606266] text-center mt-[30rpx]">
      单点登录中...
    </div>
  </div>
  <fui-select :show="showSelect" :options="companyItems" title="请选择登录" @confirm="onConfirm"
    @close="showSelect = false"></fui-select>
</template>

<script setup>
import api from "./server/api.js";
import { onLoad } from "@dcloudio/uni-app";
import { useRoute } from "vue-router";
import { ref } from "vue";

const companyItems = ref([]); // 企业列表
// 显隐
const showSelect = ref(false); // 企业列表
const loading = ref(false);

const route = useRoute();
onLoad((e) => {
  loading.value = false;
  // getCompanyListByUmaToken(e.uam_token);
});
const handleCheckPort = (type) => {
  if (type == '1') {
    loading.value = false;
    window.location.href = `${window.location.origin}/h5/#/pages/sign/ssoLogin?uam_token=${route.query.uam_token}`;
    console.log(`${window.location.origin}`);
    console.log(`${window.location.origin}/h5/#/pages/sign/ssoLogin?uam_token=${route.query.uam_token}`);
  } else if (type == '2') {
    loading.value = true;
    getCompanyListByUmaToken(route.query.uam_token);
  }
}
// 获取sso单点 企业列表
const getCompanyListByUmaToken = async (umaToken) => {
  const companyRes = await api.getCompanyListByUmaToken({ umaToken });
  if (
    companyRes?.code &&
    companyRes.code == "00000" &&
    companyRes?.data?.length > 0
  ) {
    if (companyRes?.data?.length > 1) {
      companyRes?.data.forEach((item, index) => {
        if (index == "0") {
          item.checked = true;
        }
        item.text = item?.companyAliasName + "(" + item?.companyName + ")";
      });
      companyItems.value = companyRes?.data;
      showSelect.value = true;
    } else if (companyRes?.data?.length == 1) {
      // 只有1条直接登录
      const { id: userId } = companyRes?.data?.[0];
      login(userId);
    }
  } else if (companyRes?.code == `A10003`) {
    // A10003 表示去创建商户
    uni.showToast({
      title: companyRes?.message || "系统错误",
      icon: "none",
    });
    uni.navigateTo({
      url: "/pages/sign/index",
    });
  } else {
    // 其他问题不跳，只有错误提示
    uni.showToast({
      title: companyRes?.message || "网络错误",
      icon: "none",
    });
  }
};

// 登录
const login = async (userId) => {
  const loginRes = await api.login({
    userId,
    clientId: "1187303628294764583",
  });

  if (loginRes?.code && loginRes.code == "00000") {
    uni.setStorageSync("token", loginRes?.data?.otherProperties?.token);
    uni.setStorageSync(
      "merchantId",
      loginRes?.data?.otherProperties?.merchantId
    );
    uni.setStorageSync("account", loginRes?.data?.account);
    uni.setStorageSync("userId", loginRes?.data?.userId);
    toHomePages();
  }
};

// 前往首页
const toHomePages = () => {
  uni.reLaunch({
    url: "/pages/home/index",
  });
};

// 弹框触发
const onConfirm = (e) => {
  login(e.options.id);
};
</script>

<style lang="scss" scoped></style>