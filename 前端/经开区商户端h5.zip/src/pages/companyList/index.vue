<template>
  <div class="page-container">
    <div class="bg-[#fff] mt-[40rpx] w-[90%] m-auto rounded-[10rpx] ">
      <div class="p-[25rpx] min-h-[80vh]">
        <div
          class="flex justify-between items-center h-[80rpx]"
          style="border-bottom: 1px solid #eeeeee"
        >
          <div class="text-[#333333] text-32rpx font-bold mb-[10rpx] flex">
            <img class="w-[40rpx] h-[50rpx] pr-[12rpx]" :src="[switchDefaultValue==`1`? redLogo : blackLogo]" alt="">
            <div>
            安全度{{selectTitle}}(前10位)
            </div>
          </div>
          <vr-switch
            style="width: 100px; height: 30px; margin-bottom: 10rpx"
            @switchFunction="switchChangeFun"
            :switchType="'text'"
            :defaultColor="'#EEEEEE'"
            :highColor="'#fff'"
            :defaultValue="switchDefaultValue"
            :switchList="switchListText"
            :itemIndex="0"
          ></vr-switch>
        </div>
        <div class="mt-[20rpx] text-32rpx">
          <div v-for="(item, index) in list" class="py-[20rpx]">
            <div v-if="index == 0" class="flex justify-between">
              <div class="text-[#333333]  flex items-center  flex-[5] truncate">
                <div class="relative flex">
                <img
                  class="w-[50rpx] h-[50rpx] pr-[12rpx]"
                  :src="rangk1"
                />
                <span class="absolute left-[17rpx] top-[10rpx] text-20rpx text-[#fff]">{{index+1}}</span>
                </div>
                <span class="font-bold flex-[1] truncate">{{item.merchantName}}</span>
              </div>
              <div class="text-[#666666]">{{item.merchantScore}}分</div>
            </div>
            <div v-if="index == 1" class="flex justify-between">
              <div class="text-[#333333] font-bold flex items-center flex-[5] truncate">
              <div class="relative flex">
                <img
                  class="w-[50rpx] h-[50rpx] pr-[12rpx]"
                  :src="rangk2"
                  alt=""
                />
                <span class="absolute left-[17rpx] top-[10rpx] text-20rpx text-[#fff]">{{index+1}}</span>
                </div>
                <span class="font-bold flex-[1] truncate">{{item.merchantName}}</span>
              </div>
              <div class="text-[#666666]">{{item.merchantScore}}分</div>
            </div>
            <div v-if="index == 2" class="flex justify-between">
              <div class="text-[#333333] font-bold flex items-center flex-[5] truncate">
                <div class="relative flex">
                <img
                  class="w-[50rpx] h-[50rpx] pr-[12rpx]"
                  :src="rangk3"
                />
                <span class="absolute left-[17rpx] top-[10rpx] text-20rpx text-[#fff]">{{index+1}}</span>
                </div>
                <span class="font-bold flex-[1] truncate">{{item.merchantName}}</span>
              </div>
              <div class="text-[#666666]">{{item.merchantScore}}分</div>
            </div>
            <div v-if="index > 2" class="flex justify-between">
              <div class="text-[#333333] font-bold flex items-center flex-[5] truncate">
                <div class="relative">
                  <div :style="{backgroundColor: (switchDefaultValue == `1`? 'rgba(249,89,67,0.1)': 'rgba(164,185,201,0.3)')}" class="w-[35rpx] h-[45rpx] pl-[10rpx] rounded-[50%]"></div>
                 <span :style="{left: (index >= 9 ? `6rpx`:`15rpx`),color: (switchDefaultValue == `1`? '#F95943': '#7E92A1')}" class="absolute left-[15rpx] top-[10rpx] text-20rpx ">{{index+1}}</span>
                </div>
                <span class="pl-[15rpx] font-bold flex-[1] truncate">{{item.merchantName}}</span>
              </div>
              <div class="text-[#666666]">{{item.merchantScore}}分</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import api from "./service/api.js";
import rangk1 from "@/static/image/companyList/1.png";
import rangk2 from "@/static/image/companyList/2.png";
import rangk3 from "@/static/image/companyList/3.png";
import redLogo from "@/static/image/companyList/redLogo.png";
import blackLogo from "@/static/image/companyList/blackLogo.png";
import vrSwitch from "@/components/vr-work/vr-switch.vue";
import { onMounted, ref } from "vue";

const switchDefaultValue = ref(1);
const selectTitle = ref('红榜')
const list = ref([]);// 列表
const switchListText = ref([
  {
    title: "红榜",
    value: 1,
  },
  {
    title: "黑榜",
    value: 0,
  },
]);

onMounted(() => {
  getMerchantBillboard();
})

const switchChangeFun = (e) => {
  switchDefaultValue.value = e.swithcSelectItem.value;
  selectTitle.value = e.swithcSelectItem.title;
  getMerchantBillboard();
};

const getMerchantBillboard = async () => {
  const res = await api.getMerchantBillboard({billboardType: switchDefaultValue.value})
  if (res.code && res.code == '00000') {
    list.value = res.data;
  }
}
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: 100vh;
  display: flex;
  flex-direction: column;
}
</style>