import http from '@/utils/network.js'

export default class Api {
    /**
     * 红黑榜列表
     * @param {*} data 
     * @returns 
     */
    static getMerchantBillboard = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getMerchantBillboard',
            method: 'get',
            data
        })
    }

}