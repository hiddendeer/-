<template>
  <div class="w-full h-[100vh] p-3 box-border overflow-scroll pb-[60px]">
    <div class="top">
      <view class="fui-section__title font-bold">任务详情</view>
    </div>
    <div class="p-2">
      <fui-form ref="form" labelWidth="200">
        <fui-form-item label="任务名称:">
          <text class="text-gray-400" v-text="previewData.title"></text>
        </fui-form-item>
        <fui-form-item label="任务副标题:">
          <text class="text-gray-400" v-text="previewData.subtitle"></text>
        </fui-form-item>
        <fui-form-item label="开始日期:">
          <text class="text-gray-400" v-text="previewData.startTime"></text>
        </fui-form-item>
        <fui-form-item label="截止日期:">
          <text class="text-gray-400" v-text="previewData.endTime"></text>
        </fui-form-item>
        <fui-form-item
          label="本期截止日期:"
          v-if="previewData.publishFrequency != '2602497602702610434'"
        >
          <text
            class="text-gray-400"
            v-text="previewData.noticeChildResult?.endTime"
          ></text>
        </fui-form-item>
        <fui-form-item v-if="route.query.type == '1'" label="任务内容:">
          <fui-textarea
            class="text-gray-400"
            v-html="previewData.content"
          ></fui-textarea>
        </fui-form-item>
        <fui-form-item label="附件:">
          <view
            v-for="item in previewData.noticeFileDataResults"
            :key="item.id"
            class="text-28px font-bold flex justify-start overflow-hidden"
            :class="!isPic(item) ? 'text-gray-400' : ''"
            @click="uploadDown(item)"
          >
            <text class="break-normal mb-2" v-text="item.fileName"></text>
          </view>
        </fui-form-item>
        <fui-form-item label="发布时间:">
          <text class="text-gray-400" v-text="previewData.publishTime"></text>
        </fui-form-item>
        <fui-form-item v-if="route.query.type == '1'" label="签收状态:">
          <text class="text-gray-400">{{
            previewData.isSignature ? "已签收" : "未签收"
          }}</text>
        </fui-form-item>

        <template v-else>
          <fui-form-item label="提报状态:">
            <text
              class="text-gray-400"
              v-text="
                previewData.reportDataResult?.submitStatusName
                  ? previewData.reportDataResult?.submitStatusName
                  : '未提报'
              "
            ></text>
          </fui-form-item>
          <fui-form-item
            label="审核状态:"
            v-if="previewData.reportDataResult?.auditStatusName"
          >
            <text
              class="text-gray-400"
              v-text="previewData.reportDataResult?.auditStatusName"
            ></text>
          </fui-form-item>
          <fui-form-item
            v-if="previewData.reportDataResult?.auditStatus == '3'"
            label="驳回原因:"
          >
            <text
              class="text-gray-400"
              v-text="previewData.reportDataResult?.rejectionCause"
            ></text>
<!--            <p style="color: red; font-size: 14px">(请前往WEB端进行上报)</p>-->
          </fui-form-item>
        </template>
      </fui-form>
      <div
        v-if="!previewData.isSignature && route.query.type == '1'"
        class="flex justify-center mt-5"
      >
        <fui-button
          bold
          text="签收"
          width="200px"
          @click="handleSign"
        ></fui-button>
      </div>
    </div>
    <hr />
    <div v-if="previewData.isReport" class="p-2">
      <view class="fui-section__title font-bold">上报内容</view>
      <fui-list>
        <fui-list-cell :highlight="false">
          <view class="text-14px font-bold">附件:</view>
          <view class="text-14px font-bold w-[80%]" style="color: 'red'">
            <p
              v-for="item in previewData.noticeReportDataFileDataResults"
              :key="item.id"
              class="flex justify-start overflow-hidden"
              :class="!isPic(item) ? 'text-gray-400' : ''"
              @click="uploadDown(item)"
            >
              <fui-icon name="order"></fui-icon>
              <text v-text="item.fileName"></text>
            </p>
          </view>
        </fui-list-cell>
      </fui-list>
      <template v-for="item in previewData.content" :key="item.model">
        <fui-list>
          <fui-list-cell>
            <view class="text-14px font-bold">{{ item.cateLabel }}</view>
          </fui-list-cell>
        </fui-list>
        <VrForm :fieldConfig="{ fieldParams: item.fieldParams }" />
      </template>
    </div>
    <div
      v-if="
        !previewData.isReport && previewData.noticeType == '2646430377938915330'
      "
      class="p-2"
    >
      <view class="fui-section__title font-bold">上报内容</view>
      <div class="w-full mt-3">
        <!-- <p class="text-center">暂无数据</p>
        <p class="red text-center">(请前往WEB端进行上报)</p> -->
        <div class="mt-[20rpx]" v-for="item in fieldConfig" :key="item">
          <fui-section :marginTop="40" :lineRight="20" :padding="['0','2rpx']" :title="item.cateLabel" isLine :fontWeight="700" lineWidth="8rpx" :size="28"></fui-section>
          <settingForm
            ref="settingFormRef"
            :fieldParams="item.fieldParams"
          ></settingForm>
        </div>
        <div class="flex justify-center">
          <div class="mt-[60rpx] w-[70%]">
            <fui-button
              text="提 交"
              height="80rpx"
              radius="48rpx"
              @click="submit"
            ></fui-button>
          </div>
        </div>
      </div>
    </div>
    <fui-gallery
      :show="showPicture"
      :urls="showPictureList"
      @hide="hideGallery"
    ></fui-gallery>
  </div>
</template>

<script setup>
import _ from "lodash";
import { ref, onMounted } from "vue";
import api from "./service/api";
// import { useUserStore } from "@/store/user.js";
import { useRoute } from "vue-router";
import VrForm from "@/components/vr-form/index";
import settingForm from "@/components/vr-form/settingForm.vue";

const route = useRoute();
// const store = useUserStore();
const previewData = ref({});
const showPicture = ref(false);
const showPictureList = ref([]);
const fileListID = ref([]);

// 动态表单对象信息
const fieldConfig = ref([]);
const settingFormRef = ref(null);

// 提交表单对象
const jsonObj = ref({
  companyId: uni.getStorageSync('merchantId'),
  contentStr: "", // 表单信息
  fileIdList: [],
  noticeObjId: "",
  noticeChildId: "",
  userId: uni.getStorageSync('userId'),
  userName: uni.getStorageSync('account'),
})

onMounted(() => {
  getTaskDeials();
});
const hideGallery = () => {
  showPicture.value = false;
};
const getTaskDeials = async () => {
  console.log(route.query);
  showPictureList.value = [];
  let type = route.query.type;
  let obj = {
    noticeChildId: route.query.noticeChildId,
    noticeObjId: route.query.noticeObjId,
  };
  const res =
    route.query.type == "1"
      ? await api.notifyDetail(obj)
      : await api.taskDetail(obj);
  previewData.value = res.data || {};
  if (type == "1") {
    previewData.value.content = res.data.content
      ? decodeURI(atob(res.data.content))
      : "";
  } else if (res.data.isReport && type == "2") {
    previewData.value.content = res.data.content
      ? res.data.reportDataResult.contentStrJson
      : "";
  } else if (res.data.noticeTypeName == `数据上报`) {
    // 数据上报准备数据
    jsonObj.value.noticeObjId = obj.noticeObjId;
    jsonObj.value.noticeChildId = obj.noticeChildId;
    fieldConfig.value = res.data.contentStrJson;
  }
  console.log( previewData.value.content )
};
const isPic = (v) => {
  let newType = ["png", "jpg"];
  let name = v?.fileUrl?.substring(
    v?.fileUrl?.toLowerCase().lastIndexOf(".") + 1
  );
  return newType.indexOf(name) !== -1;
};
const uploadDown = (v) => {
  // console.log(v);
  // let newType = ["png", "jpg"];
  // let name = v?.fileUrl?.substring(
  //     v?.fileUrl?.toLowerCase().lastIndexOf(".") + 1
  // );
  // let isPic = newType.indexOf(name) !== -1;
  // console.log(isPic);
  if (!isPic(v)) {
    uni.showToast({
      title: "当前文件不支持预览",
      icon: "none",
    });
  } else {
    console.log(showPictureList);
    showPictureList.value = [];
    showPictureList.value.push(v.fileUrl);
    showPicture.value = true;
  }
  // uni.downloadFile({
  //     url: v.url,//下载地址接口返回
  //     success: (data) => {
  //         if (data.statusCode === 200) {
  //             //文件保存到本地
  //             uni.saveFile({
  //                 tempFilePath: data.tempFilePath, //临时路径
  //                 success: function (res) {
  //                     uni.showToast({
  //                         icon: 'none',
  //                         mask: true,
  //                         title: '文件已保存：' + res.savedFilePath, //保存路径
  //                         duration: 3000,
  //                     });
  //                     setTimeout(() => {
  //                         //打开文档查看
  //                         uni.openDocument({
  //                             filePath: res.savedFilePath,
  //                             success: function (res) {
  //                                 // console.log('打开文档成功');
  //                             }
  //                         });
  //                     }, 3000)
  //                 }
  //             });
  //         }
  //     },
  //     fail: (err) => {
  //         console.log(err);
  //         uni.showToast({
  //             icon: 'none',
  //             mask: true,
  //             title: '失败请重新下载',
  //         });
  //     },
  // });
};
const handleSign = async () => {
  const res = await api.notifySigning({
    noticeChildIdList: [route.query.noticeChildId],
    userId: uni.getStorageSync("userId"),
    userName: uni.getStorageSync("account"),
    companyId: uni.getStorageSync("merchantId"),
  });
  if (res.success) {
    uni.showToast({
      title: "签收成功!",
      duration: 2000,
    });
    setTimeout(() => {
      uni.navigateBack();
    }, 1500);
  } else {
    uni.showToast({
      title: "签收失败!",
      icon: "error",
      duration: 2000,
    });
  }
};

const submit = async () => {
  let fieldConfigObj = _.cloneDeep(fieldConfig.value);
  // 一、遍历多个动态表单组件
  settingFormRef.value.forEach(async (item, index) => {
    const res = await item.handleSumbitData();
    if (res) {
      if (Array.isArray(fieldConfigObj) && fieldConfigObj.length > 0) {
        // 二、遍历多个内容信息
        fieldConfigObj.forEach((it,inx) => {
          // 三、遍历内容信息内的表单项-赋值处理数据。
          it.fieldParams.forEach((i) => {
            if (res[i.model]) {
              i[i.model] = res[i.model];
            }
          });
        });
      }
    }
    if ((fieldConfigObj.length-1) === index) {
      triggerSubmit(fieldConfigObj);
    }
  });

};

const triggerSubmit = async(obj) => {
  jsonObj.value.contentStr = JSON.stringify(obj);

  const res = await api.taskReport(jsonObj.value);
  if (res?.code == '00000') {
    getTaskDeials();
  }

}
</script>

<style lang="scss" scoped>
:deep(.uni-section .uni-section-header) {
  padding: 0;
}

.fui-section__title {
  font-weight: 500;
  font-size: 20px;
  padding-left: 20px;
  position: relative;
  box-sizing: border-box;
}

.fui-section__title::after {
  content: "";
  position: absolute;
  width: 10px;
  height: 100%;
  background: #465cff;
  border-radius: 2px;
  left: 0;
  top: 0;
}
</style>
