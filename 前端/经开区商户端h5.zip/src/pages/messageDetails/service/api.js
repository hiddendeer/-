import http from '@/utils/network.js'

export default class api {
	static notifyDetail(data) {
		return http.request({
			url: '/tvrjet-edz-company-app/message/h5/notifyDetail',
			method: 'POST',
			data
		})
	}
	static notifySigning(data) {
		return http.request({
			url: '/tvrjet-edz-company-app/message/h5/notifySigning',
			method: 'POST',
			data
		})
	}
	static taskDetail(data) {
		return http.request({
			url: '/tvrjet-edz-company-app/message/h5/taskDetail',
			method: 'POST',
			data
		})
	}
	static taskReport(data) {
		return http.request({
			url: '/tvrjet-edz-company-app/message/h5/taskReport',
			method: 'POST',
			data
		})
	}
}

