import http from '@/utils/network.js'

export default class Api {
    // 检查表-详情
    // POST /tvrjet-edz-supervision-app/gov/h5/checkData/getCheckData
    // 接口ID：54762706
    // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-54762706
    static getCheckData = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getCheckData',
            method: 'POST',
            data
        })
    }
    //     适用/不适用  保存检查表
    static saveCheckData = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/saveCheckData',
            method: 'POST',
            data
        })
    }
    //     现场提交
    static submitCheckData = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/submitCompanyCheckData',
            method: 'POST',
            data
        })
    }

    // 根据记录id获取所有检查项及以下信息
    static getCheckDataByRecordId(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getCheckDataByRecordId',
            method: 'GET',
            data: data
        })
    }

    // 检查表-批量不适用
    static notApplyCheckData(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/notApplyCheckData',
            method: 'POST',
            data: data
        })
    }
    // 适用+现场取证
    // POST /tvrjet-edz-company-app/sso/user/saveCheckDataContentEvidence
    // 接口ID：67479269
    // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-67479269
    static saveCheckDataContentEvidence(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/saveCheckDataContentEvidence',
            method: 'POST',
            data: data
        })
    }
}