<template>
    <div class="body">
      <div class="flex flex-wrap mb-3 bg-white p-4" v-if="list?.contentTypeList.length>0 &&route.query.checkType == 1">
        <view class="w-[33%] mb-2">
          <view class="text-center text-[#1D4AD4] font-semibold " style="font-size: 64rpx">{{ checkNum.nonExaminedCount }}</view>
          <view class="text-center text-[#666] " style="font-size: 32rpx">待检查</view>
        </view>
        <view class="w-[33%] mb-2">
          <view class="text-center text-[#1D4AD4] font-semibold" style="font-size: 64rpx">{{ checkNum.nonUsabilityCount }}</view>
          <view class="text-center text-[#666] " style="font-size: 32rpx">不适用</view>
        </view>
        <view class="w-[33%] mb-2">
          <view class="text-center text-[#1D4AD4] font-semibold" style="font-size: 64rpx">{{ checkNum.evidenceCount }}</view>
          <view class="text-center text-[#666] " style="font-size: 32rpx">已取证</view>
        </view>
        <view class="w-[33%]">
          <view class="text-center text-[#1D4AD4] font-semibold" style="font-size: 64rpx">{{ checkNum.standardCount }}</view>
          <view class="text-center text-[#666] " style="font-size: 32rpx">合格</view>
        </view>
        <view class="w-[33%]">
          <view class="text-center text-[#1D4AD4] font-semibold " style="font-size: 64rpx">{{ checkNum.nonStandardCount }}</view>
          <view class="text-center text-[#666] " style="font-size: 32rpx">不合格</view>
        </view>
        <view class="w-[33%]">
          <view class="text-center text-[#1D4AD4] font-semibold " style="font-size: 64rpx">{{ checkNum.nonJudgmentCount }}</view>
          <view class="text-center text-[#666] " style="font-size: 32rpx">未判断</view>
        </view>

      </div>
        <fui-collapse accordion @change="change">
            <fui-collapse-item :index="index" :arrow="false" :open="item.open" :isBorder="false"
                v-for="(item, index) in list?.contentTypeList" :key="index">
                    <fui-list-cell :highlight="false" :bottomBorder="false" >
                        <view class="w-full h-full flex justify-between algin-center">
                            <p>检查分类:{{ item.classificationName }}</p>
<!--                            <fui-button v-if="route.query.checkType == 1 && !isDetials" width="160rpx" height="80rpx"
                                        background="#F4F5F7" color="#1D4AD4" @click="notApplicableAll(index)">不适用
                            </fui-button>-->
                        </view>
                    </fui-list-cell>
                <template v-slot:content>
                    <view v-for="(it, idx) in item.contentList" :key="it.id"
                        :class="{ detials: it.usability == '0' && isDetials }"
                        class="flex flex-col justify-start content-around">
                        <fui-list-cell :bottomBorder="false" style="margin: 20rpx 0rpx;" :highlight="false"
                            @click="handleButtonApply(it, 1, index, idx, isDetials)">
                            <span class="cell-label">检查点:</span>
                            <span class="cell-text">{{ it.checkPointName }}</span>
                        </fui-list-cell>
                      <fui-list-cell  @click="handleButtonApply(it, 1, index, idx, isDetials)" :highlight="false" :bottomBorder="false" v-if="route.query.checkType == '1'" style="align-items: flex-start">
                        <p class="cell-label ">检查内容:</p>
                        <div class="w-[80%]  relative">
                          <p class="w-full  cell-text  text_desc !text-justify inline-block">{{ it.content }}
                          </p>
                          <p  @click.prevent="showDesc(it.content)"
                              class="more_name absolute bottom-0 right-0"> ...更多</p>
                        </div>
                      </fui-list-cell>
                        <fui-list-cell :highlight="false" padding="0" :bottomBorder="false">
                            <p class="more_name mt-4">
<!--                              <fui-tag @click="handleButtonApply(it, 1, index, idx, true)"
                                       v-if="it.usability == '1' && !isDetials" theme="light" text="已取证" type="success">
                              </fui-tag>
                                <fui-tag @click="handleButtonApply(it, 1, index, idx, true)" theme="light"
                                    v-if="!it.questionList?.length" :text="it.evidence?.auditorStatus == '1' ? '合格' : (it.evidence?.auditorStatus == '3'
                                        ? '未判断' : '')"
                                    :type="it.evidence?.auditorStatus == '1' ? 'success' : (it.evidence?.auditorStatus == '3' ? 'warning' : '')">
                                </fui-tag>
                                <fui-tag  v-if="it.questionList?.length" theme="light" @click="handleButtonApply(it, 1, index, idx, true)"
                                    :text="it.questionList?.length > '0' ? '不合格：' + it.questionList?.length + '个问题' : ''"
                                    type="danger">
                                </fui-tag>-->
                              <view @click="handleButtonApply(it, 1, index, idx, true)" v-if="it.usability == '1' && !isDetials"  >
                                已取证 <fui-icon name="arrowright"  color="#1D4AD4" :size="32"></fui-icon>
                              </view>
                              <view @click="handleButtonApply(it, 1, index, idx, true)"
                                    v-if="it.evidence?.auditorStatus == '1' || it.evidence?.auditorStatus == '3'" >
                                {{it.evidence?.auditorStatus == '1' ? '合格' : (it.evidence?.auditorStatus == '3' ? '未判断' : '')}}
                                <fui-icon name="arrowright"  color="#1D4AD4" :size="32"></fui-icon>
                              </view>
                              <view  v-if="it.questionList?.length"  @click="handleButtonApply(it, 1, index, idx, true)">
                                {{it.questionList?.length > '0' ? '不合格：' + it.questionList?.length + '个问题' : ''}}
                                <fui-icon name="arrowright"  color="#1D4AD4" :size="32"></fui-icon>
                              </view>
                            </p>
                            <p v-if="!isDetials" class="flex justify-between algin-center" style="width: 50%;">
                              <fui-button width="140rpx" height="60rpx"

                                          :disabled="it.usability == '0' && !isDetials" disabledColor="#fff" disabledBackground="#1D4AD4"
                                          :color="it.usability === null? '#1D4AD4':(it.usability =='0'? '#fff':'#1D4AD4')" radius="32rpx"
                                          :background="it.usability === null? '#fff':(it.usability =='0'? '#1D4AD4':'#fff')" borderColor="#1D4AD4"
                                          @click="handleButtonApply(it, 0, index, idx, true)">不适用
                              </fui-button>
                              <!--                              :style="{opacity:(it.usability == '1' && !isDetials?'0.5':'1')}"-->
                              <fui-button width="140rpx" height="60rpx"

                                          :disabled="it.usability == '1' && !isDetials" disabledColor="#fff" disabledBackground="#1D4AD4"
                                          :color="it.usability === null? '#1D4AD4':(it.usability =='1'? '#fff':'#1D4AD4')" radius="32rpx"
                                          :background="it.usability === null? '#fff':(it.usability =='1'? '#1D4AD4':'#fff')" borderColor="#1D4AD4"
                                          @click="handleButtonApply(it, 1, index, idx, true)"
                              >适用
                              </fui-button>
                            </p>
                        </fui-list-cell>
                      <p class="line" v-if="idx+1 != item.contentList.length"></p>
                    </view>
                </template>
            </fui-collapse-item>
        </fui-collapse>
        <fui-empty v-if="!list?.contentTypeList?.length > 0" color="#999" src="/static/empty.png" title="暂无数据" />

        <fui-bottom-popup :show="showDescBottom" @close="closePopup">
            <view class="fui-custom__wrap">
                {{ showDescBottomContent }}
            </view>
        </fui-bottom-popup>
        <div class="footer" v-if="!isDetials && list?.contentTypeList?.length > 0">
            <fui-button @click="submit">提交</fui-button>
        </div>
        <fui-dialog :show="showDialog" title="" content="点击不适用将会清空您的检查内容,是否继续不适用?" maskClosable
            @click="onClickDialog"></fui-dialog>

        <fui-modal :buttons="[]" width="600" :show="showModal">
            <text class="fui-title" style="font-size: 34rpx;">您有未检查的检查项,请确认后再提交!</text>
            <fui-button text="我知道了" width="240rpx" height="72rpx" :size="28" radius="12rpx" borderWidth="0"
                :margin="['60rpx', '0', '24rpx']" @click="showModal = false">
            </fui-button>
        </fui-modal>
    </div>
</template>

<script setup>
import { ref, reactive, nextTick } from "vue";
import { useRoute } from "vue-router";
import Api from "./service/api";
import { useStore } from "vuex";
import { onShow, onLoad } from "@dcloudio/uni-app";
import FuiDialog from '../../components/firstui/fui-dialog/fui-dialog.vue'

const route = useRoute();
const store = useStore();
const list = ref();

const showDescBottom = ref(false);
const showDescBottomContent = ref('');
const showDialog = ref(false);
const showModal = ref(false);
const isDetials = ref(false);

let clickType = ref('');
let clickData = ref({})

const checkNum=reactive({
  nonExaminedCount:0, //待检查数量
  nonUsabilityCount:0, //不适用数量
  evidenceCount:0, //已取证
  standardCount:0, //合格数量
  nonStandardCount:0, //不合格数量
  nonJudgmentCount:0, //未判断数量
})

onLoad(() => {
    store.commit("checkList/setOpenIndex", 0)
    store.commit("checkList/setOpenIndex", 0)
    store.commit("checkList/setInfo", null)
    store.commit("checkList/setEditId", null)
    store.commit("checkList/setIndex", 0);
})
onShow(() => {
    if (route.query.recordId) {
        getListDitials(route.query.recordId);
        isDetials.value = route.query.isDetials;
    } else {
        getList();
    }
})
//获取检查表详情
const getListDitials = async (id) => {
    let res = await Api.getCheckDataByRecordId({ recordId: id })
    if (res?.code == '00000') {
        list.value = res?.data;
        let openIndex = store.state.checkList.openIndex;
        list.value.contentTypeList.forEach((it, index) => {
          if (index == openIndex) {
            it.open = true;
          }else {
            it.open = false;
          }
        });
        checkNum.evidenceCount= list.value.evidenceCount;
        checkNum.nonExaminedCount= list.value.nonExaminedCount;
        checkNum.nonJudgmentCount= list.value.nonJudgmentCount;
        checkNum.nonStandardCount= list.value.nonStandardCount;
        checkNum.nonUsabilityCount= list.value.nonUsabilityCount;
        checkNum.standardCount= list.value.standardCount;
      // getCheckNumber(list.value.contentTypeList);
    } else {
        list.value = [];

    }
}
const submit = async () => {
    let isShow = [];
    //如果是拍照检查 则不需要判断是否有未检查的检查项
    if (route.query.checkType == 1) {
        list.value.contentTypeList.map(item => {
            let arr = item.contentList.every(it => it.usability != null);
            console.log(arr)
            isShow.push(arr);
        });
        if (!isShow.every(it => it == true)) {
            showModal.value = true;
            return
        }
    }
    const res = await Api.submitCheckData({
        crId: list.value.crId,
        companyId: route.query.companyId,
        ctId: route.query.taskId,
    })
    if (res && res.code == '00000') {
        uni.switchTab({
            url: '/pages/home/index'
        })
    } else {
        uni.showToast({
            title: res.message,
            icon: 'none',
            duration: 2000
        });
    }
}
const getList = async () => {
    const res = await Api.getCheckData({
        ctId: route.query.taskId,
        companyId: route.query.companyId,
    })
    if (res.code == '00000') {
        nextTick(() => {
            list.value = res.data;
            let openIndex = store.state.checkList.openIndex;
            list.value.contentTypeList.forEach((it, index) => {
              if (index == openIndex) {
                it.open = true;
              }else {
                it.open = false;
              }
            });
          checkNum.evidenceCount= list.value.evidenceCount;
          checkNum.nonExaminedCount= list.value.nonExaminedCount;
          checkNum.nonJudgmentCount= list.value.nonJudgmentCount;
          checkNum.nonStandardCount= list.value.nonStandardCount;
          checkNum.nonUsabilityCount= list.value.nonUsabilityCount;
          checkNum.standardCount= list.value.standardCount;
        })
    }
}
const notApplicableAll = (index) => {
    if (isDetials.value) return;
    store.commit("checkList/setIndex", index);
    clickType.value = 'all'
    showDialog.value = true;
    // let arr = list.value.contentTypeList;
    // let isShow = arr[index].contentList.every(it => it.usability == null);
    // console.log(isShow);
    // if (!isShow) {
    //     store.commit("checkList/setIndex", index);
    //     showDialog.value = true;
    // } else {
    //     store.commit("checkList/setInfo", arr)
    //     saveCheckData();
    // }
}

const getCheckNumber=(list)=>{
  let newArr = [];
  list.map(item => {
    item.contentList.map(it => {
      newArr.push(it)
    })
  });
  newArr.map(item=>{
    // 不合格数量
    if(item.questionList?.length>0){
      checkNum.nonStandardCount+=1;
    }
    // 未判断数量
    if(item.evidence?.auditorStatus =='3' ){
      checkNum.nonJudgmentCount+=1;
    }
    // 合格
    if(item.evidence?.auditorStatus == '1' ){
      checkNum.standardCount+=1;
    }
    //已取证
    if(item.usability == '1'){
      checkNum.evidenceCount+=1;
    }
    // 不适用
    if(item.usability == '0'){
      checkNum.nonUsabilityCount+=1;
    }
    // 待检查数量
    if(!item.usability && item.usability != '0' ){
      checkNum.nonExaminedCount+=1;
    }
  })
  console.log(checkNum.nonStandardCount,'不合格')
  console.log(checkNum.nonJudgmentCount,'未判断数量')
  console.log(checkNum.standardCount,'和格')
  console.log(checkNum.evidenceCount,'已取证')
  console.log(checkNum.nonUsabilityCount,'不适用')
  console.log(checkNum.nonExaminedCount,'待检查数量')
}

const change = (e) => {
    list.value.contentTypeList[e.index].open = e.isOpen;
    if(e.isOpen){
        store.commit("checkList/setOpenIndex", e.index)
    }else{
        store.commit("checkList/setOpenIndex", null)
    }
}

// 点击不适用按钮 检查点和检查内容设置成不适用状态
const handleButtonApply = async (e, type, index, idx, isPass) => {
    if (!isPass) return
    let newArr = JSON.parse(JSON.stringify(list.value.contentTypeList));
    newArr[index].contentList[idx].usability = type;
    store.commit("checkList/setOpenIndex", index)
    if (type == 0) {
        if (!isDetials.value) {
            if (list.value.id) {
                let arr = [];
                arr.push(e.id)
                await updateCheckData(arr)
            } else {
                store.commit("checkList/setInfo", newArr)
                await saveCheckData();
            }
        }
    } else {
        store.commit("checkList/setInfo", newArr)
        store.commit("checkList/setEditId", list.value.id || null)
        uni.navigateTo({
            url: `/pages/checkListDetails/index?companyId=${route.query.companyId}&id=${e.id}&taskId=${route.query.taskId}&checkType=${route.query.checkType}&name=${list.value.name}&index=${index}&idx=${idx}&isDetials=${isDetials.value}`
        })
    }
}

const onClickDialog = async (e,type) => {
    showDialog.value = false;
    if (e.index == 1) {
        if (clickType.value == 'all') {
            allUnapplicable()
        }else if (clickType.value == 'once') {
           let {e, type, index, idx, isPass} = clickData.value 
           handleButtonApply(e, type, index, idx, isPass)
           clickData.value = {}
        }
    }
     clickType.value = ''
}

const clickOnceUnapplicable = (e, type, index, idx, isPass) =>{
    clickType.value = 'once'
    clickData.value = {e, type, index, idx, isPass}
    showDialog.value = true;
}

const allUnapplicable = async() =>{
    if (list.value.id) {
        // let arr = JSON.parse(JSON.stringify(list.value.contentTypeList));
        let arr = list.value.contentTypeList[store.state.checkList.index].contentList.map(it => it.id)
        await updateCheckData(arr)
    } else {
        let arr = JSON.parse(JSON.stringify(list.value.contentTypeList));
        arr[store.state.checkList.index].contentList.map(it => it.usability = 0);
        store.commit("checkList/setInfo", arr)
        await saveCheckData();
    }
}

const saveCheckData = async () => {
    // showDialog.value = true;
    let arr = JSON.parse(JSON.stringify(store.state.checkList.info));
    let newArr = [];
    arr.map(item => {
        item.contentList.map(it => {
            newArr.push(it)
        })
    });
    const res = await Api.saveCheckData({
        ctId: route.query.taskId,
        companyId: route.query.companyId,
        checkType: route.query.checkType,
        name: list.value.name,
        checkDataContentResults: newArr,
    });
    if (res.code == '00000') {
        await getList();
    }
    showDialog.value = false;
}

const showDesc = (e) => {
    showDescBottomContent.value = e;
    showDescBottom.value = true;
}
const closePopup = () => {
    showDescBottom.value = false;
    showDescBottomContent.value = '';
}

// 当前检查表第二次保存时 单独去修改需要保存的检查项
const updateCheckData = async (arr) => {

    const res = await Api.notApplyCheckData({
        checkDataContentIds: arr,
    });
    getList();

}

</script>

<style scoped lang="scss">
.body {
  width: 100%;
  height: 100vh;
  background-color: #F4F5F7;
  padding: 20rpx;
  padding-bottom: 240rpx;
  box-sizing: border-box;
  overflow: scroll;

  //:deep(.isDetials.fui-list__cell) {
  //    //padding: 0rpx !important;
  //    //align-items: flex-start !important;
  //    // margin-bottom: 20rpx;
  //}
  :deep(.arrow){
    align-items: center !important;
  }
  :deep(.fui-list__cell){
    padding: 0rpx !important;
  }
  .cell-label {
    width: 200rpx;
    font-size: 36rpx;
  }

  .cell-text {
    // width: calc(100% - 200rpx);
    height: auto;
    font-size: 32rpx;
    text-align: right;
    color: #666;
  }

  .text_desc {
    word-break: break-all;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .footer {
    z-index: 9999;
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
    padding: 20rpx 80rpx;
    box-sizing: border-box;
    background-color: #fff;
    box-shadow: 0rpx -10rpx 20rpx 1rpx rgba(0, 0, 0, 0.15) !important;

  }

  :deep(.fui-bottom__popup-wrap) {
    z-index: 99999 !important;
  }

  .fui-custom__wrap {
    width: 100%;
    max-height: 60vh;
    padding: 40rpx;
    overflow-y: scroll;
    box-sizing: border-box;
    font-size: 32rpx;
    color: #333;
  }

  .line {
    width: 640rpx;
    height: 0rpx;
    opacity: 1;
    border: 1rpx solid #EEEEEE;
    margin: 10rpx 0rpx;
  }

  :deep(.fui-collapse__wrap) {
    background-color: #FFF;
    align-items: center;
  }

  :deep(.fui-collapse__item) {
    padding: 20rpx;
    width: 100%;
    margin: 10rpx;
    background-color: #fff;
    box-sizing: border-box;
    border-radius: 8rpx;
  }
  :deep(.fui-collapse__content-wrap){

  }
  .red {
    color: #F95943;
    font-size: 32rpx;
  }

  .green {
    color: #13BA79;
    font-size: 32rpx;
  }

  .fui-descr-group {
    width: 100%;
    margin-top: 20rpx;
  }

  .more_name {
    font-size: 32rpx;
    font-weight: 400;
    color: #1D4AD4;
    text-align: right;
    background-color: #fff;
    //line-height: 38px;
  }

  :deep(.fui-collapse-item__title) {
    width: 100%;
    height: 80rpx;
    color: #333333;
    font-size: 36rpx;
    font-weight: 600;
  }
}
</style>

