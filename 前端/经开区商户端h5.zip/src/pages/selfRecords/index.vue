<template>
  <div class="body">
    <div style="height: 100rpx; display: flex; align-items: center">
      <fui-tabs
          :short="false"
          :tabs="titleList"
          background="#fff "
          bottom="10"
          color="#999"
          fontWeight="600"
          selectedColor="#333"
          selectedFontWeight="600"
          selectedSize="36"
          size="36"
          sliderBackground="#1D4AD4"
          sliderHeight="6"
          @change="changeTabs"
      />
    </div>

    <scroll-view
        class="w-full h-[95vh] pt-0 pb-[100rpx] box-border"
        scroll-y="true"
        @scroll="scroll"
        @scrolltolower="lower"
    >
      <div class="p-3 box-border">
        <!--                <fui-segmented-control :current="currentIndex" @click="changeTabs"  :values="titleList"></fui-segmented-control>-->
        <div class="content">
          <fui-list-cell
              v-for="item in list"
              :key="item.id"
              :highlight="false"
              @click="handleClickCell(item)"
          >
            <text class="text-32rpx font-bold flex-1">{{ item.taskName }}</text>
            <text v-if="currentIndex == '0'" class="fui-text__explain">
              {{ item.crId == null ? "" : "继续检查" }}
            </text>
            <text v-else class="fui-text__explain">
              {{item.checkTime?('检查时间:'+item.checkTime):'' }}
            </text
            >
          </fui-list-cell>
        </div>
      </div>
    </scroll-view>
  </div>
</template>

<script setup>
import {ref, onMounted} from "vue";
import api from "./service/api";
import {
  onPullDownRefresh,
  onReachBottom,
  onPageScroll
} from "@dcloudio/uni-app";

const currentIndex = ref(0);
const titleList = ref(["未完成", "已完成"]);
const pageNo = ref(1);
const isLastPage = ref(false);
const list = ref([]);

onMounted(() => {
  handleSearch();
});

const handleClickCell = (v) => {
  console.log(v);
  let companyId = uni.getStorageSync("merchantId");
  if (currentIndex.value != "0") {
    uni.navigateTo({
      url: `/pages/checkList/index?recordId=${v.crId}&isDetials=${
          currentIndex.value != "0"
      }&checkType=1`
    });
  } else {
    // url: `/pages/${val}/index?recordId=${item.id}&isDetials=${isDetials}&checkType=${item.checkType}`
    uni.navigateTo({
      url: `/pages/checkList/index?taskId=${v.id}&checkType=1&companyId=${companyId}`
    });
  }
};

const changeTabs = (e) => {
  console.log(e);
  currentIndex.value = e.index;
  reset();
};

const lower = (e) => {
  pageNo.value++;
  handleSearch();
  console.log(e);
};
//下拉刷新
onPullDownRefresh(() => {
  reset();
  setTimeout(() => {
    uni.stopPullDownRefresh();
  }, 1000);
});
//重置
const reset = () => {
  list.value = [];
  pageNo.value = 1;
  isLastPage.value = false;
  handleSearch();
};
//搜索
const handleSearch = async () => {
  if (isLastPage.value) {
    uni.showToast({
      title: "到底啦!",
      icon: "none"
    });
    return;
  }

  const res = await api.getMerchantTaskList({
    isFinish: currentIndex.value,
    pageNo: pageNo.value,
    pageSize: 20
  });
  if (res.code == "00000") {
    if (res.data.pages == res.data.current) {
      isLastPage.value = true;
    }
    res.data.records.map((item) => {
      list.value.push(item);
    });
  }
};
</script>

<style lang="scss" scoped>
.body {
  width: 100%;
  min-height: 100vh;
  // padding: 20rpx;
  box-sizing: border-box;

  // background-color: red;
  .fui-text__explain {
    color: red;
  }
}
</style>
