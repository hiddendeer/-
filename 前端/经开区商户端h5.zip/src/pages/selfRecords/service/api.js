import http from '@/utils/network.js'

export default class Api {
    // 自查-获取任务列表
    static getMerchantTaskList(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getMerchantTaskList',
            method: 'GET',
            data: data
        })
    }
}