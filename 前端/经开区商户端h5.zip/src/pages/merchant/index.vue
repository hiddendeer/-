<!-- 商户端我的 -->
<template>
  <div class="page-container">
    <div class="bg-white py-[30px]">
      <p class="text-center font-bold text-15px">{{ formData?.merchantAliasName }}</p>
      <fui-preview :previewData="preViewData" />

      <div class="text-center">
        <p class="p-[8px] pt-[20px] text-14px">安全评价</p>
        <fui-rate
          :score="formData.rate"
          color="#888"
          activeColor="#465CFF"
          :size="48"
          allowHalf
          disabled
        ></fui-rate>
        <!-- 安全得分：60分以上用绿色数字 #09BE4F、60~40分用黄色数字 #FFB703、40~20用橙色数字 #FF9632、20分以下用红色文字 -->
        <p
          class="p-[8px] pt-[20px] font-bold text-18px"
          :class="{
            'color-[#09BE4F]': formData.merchantScore > 60,
            'color-[#FFB703]': formData.merchantScore > 40 && formData.merchantScore <= 60,
            'color-[#FF9632]': formData.merchantScore > 20 && formData.merchantScore <= 40,
            'color-[#FF2B2B]': formData.merchantScore <= 20,
          }"
        >
          {{ formData.merchantScore }}
        </p>
        <p class="text-14px">安全得分</p>
      </div>
    </div>
  </div>
  <fui-toast ref="toastRef"></fui-toast>
</template>

<script setup>
import api from "./server/api.js";
import { ref, reactive, onMounted } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const loading = ref(false);
const toastRef = ref(null);
const formData = ref({
  rate: 0,
  merchantScore: 0,
});
const preViewData = ref({});
const qrcodeUrl = ref("");
const statusList = ref([]);

onMounted(() => {
  queryDetail();
});
const queryDetail = async () => {
  const res = await api.getMerchantInfo({merchantId: route.query?.merchantId});
  if (res?.code && res.code == "00000") {
    formData.value = res?.data;
    preViewData.value.list = [
      { label: "企业名:", value: formData.value.merchantName },
      { label: "法人/负责人:", value: formData.value.merchantLegalPerson },
      { label: "网格:", value: formData.value.gridInfo.gridFullName },
    ];
    let score = formData.value.merchantScore
    switch (true) {
      case ( score >= 1 && score < 51 ): 
        formData.value.rate = 0.5;
        break;
      case ( score >= 51 && score < 101 ):
        formData.value.rate = 1;
        break;
      case ( score >= 101 && score < 151 ): 
        formData.value.rate = 1.5;
        break;
      case ( score >= 151 && score < 201 ):
        formData.value.rate = 2;
        break;
      case ( score >= 201 && score < 251 ): 
        formData.value.rate = 2.5;
        break;
      case ( score >= 251 && score < 301 ):
        formData.value.rate = 3;
        break;
      case ( score >= 301 && score < 351 ): 
        formData.value.rate = 3.5;
        break;
      case ( score >= 351 && score < 401 ):
        formData.value.rate = 4;
        break;
      case ( score >= 401 && score < 451 ): 
        formData.value.rate = 4.5;
        break;
      case score >= 451:
        formData.value.rate = 5;
        break;
      default:
        formData.value.rate = 0;
        break;
    }
  }
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: 100vh;
  overflow: auto !important;
  padding: 15px;
}

:deep(.fui-preview__wrap:after) {
  margin: 0 15px !important;
  border-bottom: 1px solid #ccc !important;
}
</style>
