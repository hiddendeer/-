import http from '@/utils/network.js'

export default class api {
  // 获取商户信息
  static getMerchantInfo(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/getMerchantInfo',
      method: 'GET',
      data: data
    })
  }
}