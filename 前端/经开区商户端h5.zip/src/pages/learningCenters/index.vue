<template>
  <div class="page-container flex flex-col bg-[#f4f5f7]">
    <div class="searchInput">
      <fui-search-bar
        height="72"
        radius="10"
        background="#fff"
        inputBackground="#F4F5F7"
        paddingLr="30"
        :isLeft="true"
        ref="searchRef"
        :cancel="false"
        placeholder="请输入关键词进行模糊搜索"
        @search="search"
        @clear="clear"
      />
    </div>
    <div class="hidescroll flex my-[10px]">
      <p class="w-[60px] text-[14px] mr-[15px] mt-[8px] text-right">来源</p>
      <fui-data-tag
        style="flex: 1; overflow: auto; flex-wrap: nowrap"
        :options="tools.sourceList"
        v-model="searchForm.source"
        @change="(e) => changeDataTag(e,'source')"
      ></fui-data-tag>
    </div>
    <div class="hidescroll flex my-[10px]" v-if="searchForm.source != '1622829342025388033'">
      <p class="w-[60px] text-[14px] mr-[15px] mt-[8px] text-right">事故类型</p>
      <fui-data-tag
        style="flex: 1; overflow: auto; flex-wrap: nowrap"
        :options="tools.typeList"
        v-model="searchForm.accidentType"
        @change="(e) => changeDataTag(e,'accidentType')"
      ></fui-data-tag>
    </div>
    <div class="hidescroll flex my-[10px]" v-if="searchForm.source != '1622829342025388033'">
      <p class="w-[60px] text-[14px] mr-[15px] mt-[8px] text-right">事故等级</p>
      <fui-data-tag
        style="flex: 1; overflow: auto; flex-wrap: nowrap"
        :options="tools.levelList"
        v-model="searchForm.accidentLevel"
        @change="(e) => changeDataTag(e,'accidentLevel')"
      ></fui-data-tag>
    </div>
    <div class="hidescroll flex my-[10px]" v-if="searchForm.source != '1622829342025388033'">
      <p class="w-[60px] text-[14px] mr-[15px] mt-[8px] text-right">格式</p>
      <fui-data-tag
        style="flex: 1; overflow: auto; flex-wrap: nowrap"
        :options="tools.formatList"
        v-model="searchForm.fileType"
        @change="(e) => changeDataTag(e,'fileType')"
      ></fui-data-tag>
    </div>
    <!-- 公共库查询条件  -->
    <div v-if="searchForm.source == '1622829342025388033'">
      <div class="hidescroll flex my-[10px]"
        v-for="(item,index) in publicObj.searchList" :key="item.Key">
        <p class="w-[60px] text-[14px] mr-[15px] mt-[8px] text-right">{{ item.KeyName }}:</p>
        <fui-data-tag
          style="flex: 1; overflow: auto; flex-wrap: nowrap"
          :options="item.List"
          v-model="publicObj[item?.Key]"
          @change="(e) => changePublicRadio(e,item?.Key)"
        ></fui-data-tag>
      </div>
    </div>
    <scroll-view
      class="w-full box-border bg-white"
      style="flex-1;overflow:auto"
      scroll-y="true"
      @scrolltolower="lower"
    >
      <div class="p-[15px]">
        <fui-loading
          type="col"
          text="加载中"
          isMask
          v-if="loading"
        ></fui-loading>
        <fui-empty
          v-else-if="listData.length < 1 && !loading"
          src="/static/empty.png"
          title="暂无数据"
          color="#999"
          marginTop="180"
          style="hright:100%"
        />
        <div
          v-else
          v-for="(item,index) in listData"
          :key="item.inspectionRecordId"
          @click="toDetail(item)"
        >
          <div class="flex">
            <img
              :src="item.coverFileUrl"
              alt="加载失败"
              class="h-[63px] w-[109px] mr-[12px] rounded-[5px]"
            />
            <div class="flex-1 flex flex-col justify-between">
              <div style="font-size: 16px;font-weight: bold">{{ item.title }}</div>
              <div>
                <fui-tag
                  :text="item?.accidentLevelName"
                  color="#fff"
                  style="margin-right: 12px;padding: 6px"
                  :background="handleLevel.paramHandle(item?.accidentLevelName,'value')"
                />
                <fui-tag
                  :text="item?.accidentTypeName"
                  theme="light"
                  style="padding: 6px"
                  :color="handleLevel.paramHandle(item?.accidentLevelName, 'value')"
                  :type="handleLevel.paramHandle(item?.accidentLevelName, 'type')"
                />
              </div>
            </div>
          </div>
          <fui-divider v-if="index != listData.length - 1" color="#eee" width="100%" height="60"></fui-divider>
        </div>
      </div>
    </scroll-view>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, render } from "vue";
import { onPullDownRefresh } from "@dcloudio/uni-app";
import handleLevel from "@/utils/handleLevel.js"
import api from "./server/api.js";
import commonApi from "@/api/commonApi";

const listData = ref([]);
const loading = ref(false);
const searchRef = ref(null);
const tools = reactive({
  scrollYTop: 0,
  oldScrollYTop: 0,
  isLastPage: false,
  sourceList: [],
  typeList: [],
  levelList: [],
  formatList: []
});
const publicObj = reactive({
  searchList: []
})
const searchForm = reactive({
  accidentType: "-1",
  accidentLevel: "-1",
  title: "",
  status: "1",
  source: "1622828439629271041",
  fileType: '-1', // 文件类型，0=图片，1=视频，2=音频，3=文档
});
const pages = reactive({
  pageSize: 10,
  pageNo: 1,
});

onMounted(() => {
  getDictList("dataSource","sourceList",1);
  getDictList("faultType", "typeList");
  getDictList("faultLevel", "levelList");
  getDictList('format','formatList');
  getList(1);
});
//下拉刷新
onPullDownRefresh(() => {
  clear();
  setTimeout(() => {
    uni.stopPullDownRefresh();
  }, 1000);
});
const getDictList = async (code, list, type) => {
  if (type != 1) {
    tools[`${list}`] = [{
      text: "全部",
      value: "-1",
      dictId: "-1",
    }];
  } else {
    tools[`${list}`] = []
  }
  let res = await commonApi.getDicList({ dictTypeCode: code });
  if (res?.code && res?.code == "00000") {
    res?.data?.map((item) => {
      item.text = item.dictName;
      item.value = code == 'format' ? item.dictCode : item.dictId;
    });
    tools[`${list}`] = tools[`${list}`].concat(res?.data);
  }
};
const getList = async (page) => {
  if (page == 1) {
    listData.value = [];
    tools.isLastPage = false;
  }
  if (tools.isLastPage) {
    uni.showToast({
      title: "到底啦!",
      icon: "none",
    });
    return;
  }
  if (page) pages.pageNo = page;
  let params = {
    ...pages,
    ...searchForm,
  };
  for (const item in params) {
    if (params[item] == "-1" || params[item] == "") {
      delete params[item];
    }
  }
  let apiName = 'getList';
  if ( searchForm.source == '1622829342025388033' ) {
    apiName = 'getListCommon';
    params.keyWord = searchForm.title;
  }
  let res = await api[apiName](params);
  if (res?.code == "00000" && res.data) {
    if (res.data.pages == res.data.current) {
      tools.isLastPage = true;
    }
    res.data?.records?.map((item) => {
      listData.value.push(item);
    });
  }
};
const lower = (e) => {
  pages.pageNo++;
  getList();
  console.log("e", e);
};
const search = (e) => {
  searchForm.title = e?.detail?.value;
  tools.isLastPage = false;
  listData.value = [];
  getList(1);
};
const clear = () => {
  searchRef.value.val = ''
  searchForm.title = "";
  pages.pageNo = 1;
  tools.isLastPage = false;
  listData.value = [];
  getList(1);
};
const changeDataTag = (e,type) => {
  searchForm[type] = e.detail.value;
  tools.isLastPage = false;
  listData.value = [];
  if (type == 'source') {
    for (const item in searchForm) {
      if (item != "source"){
        if (item == "keyWord" || item == "title") {
          searchForm[item] = ''
        } else {
          searchForm[item] = '-1'
        }
      }
    }
  }
  if (searchForm.source == '1622829342025388033' ) {
    // 公共库查询条件参数
    pagePublicDataParam()
  } else {
    let paramsType = ["status", "accidentType", "accidentLevel", "fileType", "title", "source"];
    for (const item in searchForm) {
      if ( !paramsType.includes(item) ) {
        delete searchForm[item]
      }
    }
  }
  getList(1);
};
const changePublicRadio = (val,type) => {
  let list = [];
  list.push(val?.detail?.value);
  searchForm[`${type}List`] = list;
  getList(1);
};
// 公共库获取查询参数
const pagePublicDataParam = (async () => {
  tools.loading = true;
  let res = await api.pagePublicDataParam();
  if (res?.code && res?.code == "00000") {
    res?.data?.forEach((item) => {
      item.Key = item?.Key?.replace(item.Key[0],item.Key[0].toLowerCase());
      item?.List?.forEach((it) => {
        it.text = it.Name;
        it.value = it.ID;
        it.dictId = it.ID;
      })
      item?.List.unshift({
        text: "全部",
        value: "-1",
        dictId: "-1",
      })
      publicObj[item.Key] = '-1'
    })
    const newList = res.data?.filter(item => { return item?.Key != 'relatedRole' && item?.Key != 'charge' })
    publicObj.searchList = newList;
  }
  tools.loading = false;
})
const toDetail = (e) => {
  localStorage.learningInfo = JSON.stringify(e);
  uni.navigateTo({
    url: `/pages/learningCenters/details`,
  });
};
</script>

<style lang="scss">
.page-container {
  height: calc(100vh);
}
.hidescroll ::-webkit-scrollbar {
    height: 1px;
    background: transparent !important;
  }
.searchInput {
  background: #fff;
  height: 100rpx;
  padding: 0;
}
</style>