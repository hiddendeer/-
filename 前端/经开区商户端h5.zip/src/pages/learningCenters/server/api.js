import http from '@/utils/network.js'

export default class api {
  // 学习资料分页
  static getList(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/LearningMaterialsPage',
      method: 'GET',
      data: data
    })
  }
  // 分页 公共库
  static getListCommon(data) {
    return http.request({
      url: `/tvrjet-edz-company-app/sso/user/LearningMaterialsPage/yg/data`,
      method: 'POST',
      data: data
    })
  }
  // 公共库 获取参数
  static pagePublicDataParam(data) {
    return http.request({
      url: `/tvrjet-edz-company-app/sso/user/LearningMaterialsPage/yg/param`,
      method: 'GET',
      data: data
    })
  }
  // 公共库 获取详情
  static pagePublicDataDetail(data) {
    return http.request({
      url: `/tvrjet-edz-company-app/sso/user/LearningMaterialsPage/yg/detail`,
      method: 'GET',
      data: data
    })
  }
}