<template>
  <div class="page-container flex">
    <div class="p-[15px] bg-white">
      <p style="font-size: 16px; font-weight: bold">{{ infos?.title }}</p>
      <div class="mt-[8px]">
        <fui-tag
          v-if="infos.accidentLevelName"
          :text="infos?.accidentLevelName"
          color="#fff"
          style="margin-right: 12px; padding: 6px"
          :background="handleLevel.paramHandle(infos?.accidentLevelName, 'value')"
        />
        <fui-tag
          v-if="infos.accidentTypeName"
          :text="infos?.accidentTypeName"
          theme="light"
          style="padding: 6px"
          :color="handleLevel.paramHandle(infos?.accidentLevelName, 'value')"
          :type="handleLevel.paramHandle(infos?.accidentLevelName, 'type')"
        />
      </div>
    </div>
    <div class="mt-10px p-[15px] bg-white flex-1">
      <fui-upload-video
        v-if="infos?.fileType == '视频'"
        ref="upload"
        :fileList="infos?.fileList"
        isView
      />
      <fui-empty v-else-if="!infos?.fileUrl" title="暂无数据" />
      <div v-else>
        <fui-button
          type="gray"
          height="72rpx"
          text="请点击文本复制附件链接，到浏览器中下载查看"
          bold
          class="pb-[10px]"
          @click="copyText($event, infos?.fileUrl)"
        ></fui-button>
        <fui-button
          type="primary"
          height="72rpx"
          text="一键复制"
          bold
          @click="copyText($event, infos?.fileUrl)"
        ></fui-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { onShow } from "@dcloudio/uni-app";
import handleLevel from "@/utils/handleLevel.js"
import $fui from '@/components/firstui/fui-clipboard';

const route = useRoute();
const router = useRouter();
const loading = ref(false);
const infos = ref({});

onShow(() => {
  if (localStorage.learningInfo) {
    infos.value = JSON.parse(localStorage.learningInfo);
    let type= infos.value?.fileUrl.substring(infos.value?.fileUrl?.lastIndexOf(".") + 1);
    if (type == 'mp4' || type == 'MP4') {
      infos.value.fileType = "视频"
    }
    infos.value.fileList = infos.value?.fileUrl?.split() ?? [];
  }
});

const copyText = (e, text) => {
	$fui.getClipboardData(text, res => {
		if (res) {
      uni.showToast({
        title: '文档地址复制成功',
        icon: 'none',
      });
		}
	}, e);
}
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: calc(100vh - 88rpx);
  display: flex;
  flex-direction: column;
  overflow: auto;
}
:deep(.fui-uploadv__item) {
  width: 100% !important;
}
</style>