import http from '@/utils/network.js'

export default class api {
    static login(data) {
        return http.request({
            url: '/api/tvrjet-gov-system-app/loginApi',
            method: 'POST',
            data: data
        })
    }
    static notifyListPage(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/message/h5/notifyListPage',
            method: 'GET',
            data
        })
    }
    static taskListPage(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/message/h5/taskListPage',
            method: 'GET',
            data
        })
    }
}
