<template>
  <div class="h-[100vh]">
    <fui-sticky>
      <div class="bg-white">
        <fui-search-bar v-model="data.title" placeholder="搜索" @search="search" @cancel="cancel"></fui-search-bar>


        <fui-segmented-control :current="data.current" :values="['通知列表', '任务列表']"
                               @click="(e) => changeTab(e, 'current')"></fui-segmented-control>

        <fui-segmented-control style="margin-top: 10px;" v-if="data.current == '1'" activeColor="#2e8ff4"
                               type="text" color="#797979" :values="['全部', '未提报', '已提报', '未通过']"
                               @click="(e) => changeTab(e, 'taskCurrent')"></fui-segmented-control>
      </div>
    </fui-sticky>

    <div class="body">
      <fui-list v-if="data.list.length > 0">
        <fui-list-cell v-for="item in data.list" :key="item.noticeObjId" @click="handlerDetials(item)">
          <template v-if="data.current != '1'">
            <text class="inline-block color-[#2e8ff4] mr-[10px]">[{{ item.noticeTypeName }}]</text>
            <fui-overflow-hidden :text="item.title"></fui-overflow-hidden>
          </template>
          <template v-else>
            <div>
              <p>任务名称：
                <text class="text-gray-600">{{ item.title ? item.title : '-' }}</text>
              </p>
              <p>提报状态：
                <text class="text-gray-600">{{
                    item.submitStatusName ? item.submitStatusName : '-'
                  }}
                </text>
              </p>
              <p>提报人：
                <text class="text-gray-600">{{
                    item.reportUserName ? item.reportUserName : '-'
                  }}
                </text>
              </p>
              <p>填报时间：
                <text class="text-gray-600">{{
                    item.submitTime ? item.submitTime : '-'
                  }}
                </text>
              </p>
              <p>审核状态：
                <text class="text-gray-600">{{
                    item.auditStatusName ? item.auditStatusName : '-'
                  }}
                </text>
              </p>
            </div>
          </template>
        </fui-list-cell>
      </fui-list>
      <fui-empty v-else src="/static/empty.png" title="暂无数据"></fui-empty>
    </div>


    <fui-backtop :scrollTop="scrollTop" custom>
      <fui-icon :size="52" name="up"></fui-icon>
    </fui-backtop>
  </div>
</template>
<script setup>
import {ref, onMounted} from "vue";
import {onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app';
import api from "./service/api";
// import { useUserStore } from "../../store/user";

const scrollTop = ref(0);
// const store = useUserStore();

const data = ref({
  current: 0,
  taskCurrent: 0,
  list: [],
  companyId: uni.getStorageSync("merchantId"),
  title: '',
  pageNo: 1,
  pageSize: 20,
  isLastPage: false
})


onMounted(() => {
  getList()
})

//下拉刷新
onPullDownRefresh(() => {
  data.value.current = 0;
  reset()
  getList()
  setTimeout(() => {
    uni.stopPullDownRefresh()
  }, 1000);
})
//上拉加载
onReachBottom(() => {
  getList()
})
//重置
const reset = () => {
  data.value.list = [];
  data.value.title = '';
  data.value.pageNo = 1;
  data.value.isLastPage = false;
}

const handlerDetials = (val) => {
  let type = val.noticeType == '2646430377938915330' ? '2' : '1';
  uni.navigateTo({
    url: `/pages/messageDetails/index?noticeChildId=${val.noticeChildId}&noticeObjId=${val.noticeObjId}&type=${type}`
  })
}
// 获取
const getList = async () => {
  if (data.value.isLastPage) {
    uni.showToast({
      title: '到底啦!',
      icon: 'none',
    });
    return
  }
  let obj = {
    companyId: uni.getStorageSync("merchantId"),
    pageNo: data.value.pageNo,
    title: data.value.title,
  }
  if (data.value.taskCurrent == 1 || data.value.taskCurrent == 2) {
    obj.submitStatus = data.value.taskCurrent
  } else if (data.value.taskCurrent == 3) {
    obj.auditStatus = data.value.taskCurrent
  }
  const res = data.value.current == 1 ? await api.taskListPage(obj) : await api.notifyListPage(obj);
  if (res.success) {
    data.value.isLastPage = res.data.pages == res.data.current ? true : false;
    res.data.records.map(item => {
      data.value.list.push(item)
    })
  }
}
const changeTab = (e, type) => {
  reset()
  data.value[type] = e.index;
  getList()
}
const search = (e) => {
  reset()
  data.value.title = e.detail.value;
  getList()
}
const cancel = (e) => {
  reset()
  getList()
}
</script>

<style lang="scss" scoped>
:deep(.fui-list__cell) {
  justify-content: flex-start;
}
</style>
