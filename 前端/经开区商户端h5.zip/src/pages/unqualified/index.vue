<template>
    <div class="body">
      <fui-form ref="form">
        <div class="box" v-for="(item, index) in data.list" :key="index">
          <fui-list-cell :highlight="false">
            <span class="cell-label">问题{{ index + 1 }}</span>
            <span @click="handleDelete(index)" v-if="!isDetails && data.list.length > 1" class="cell-text red">删除</span>
          </fui-list-cell>
          <div  v-if="!isDetails"  @click="showRisks = true" class="cell-text hidden-list">从常用隐患选择</div>
          <div class="textarea">
            <fui-form-item labelSize="32" label="问题描述" asterisk>
              <fui-textarea :disabled="isDetails" isCounter :borderBottom="false" placeholder="请输入问题描述" placeholder-style="color:#ccc;"
                            v-model="item.question" maxlength=200 />
              <div v-if="!isDetails" class="flex flex-end algin-center" @click="item.question = ''">
                <img class="icons" src="/static/image/del_icon.png" />
              </div>
            </fui-form-item>
            <fui-form-item labelSize="32" label="整改意见" asterisk>
              <fui-textarea :disabled="isDetails" isCounter :textareaBorder="true" maxlength="200" placeholder="请输入整改意见"
                            placeholder-style="color:#ccc;" v-model="item.opinion" />
              <div v-if="!isDetails" class="flex flex-end algin-center" @click="item.opinion = ''">
                <img class="icons" src="/static/image/del_icon.png" />
              </div>
            </fui-form-item>
          </div>
          <fui-form-item labelSize="32" label="隐患性质" asterisk>
            <fui-radio-group  name="radio" v-model="item.dangerNature" class="flex algin-center justify-between">
              <fui-label v-for="its in dangerList" :key="its.dictId">
                <view class="flex algin-center">
                  <fui-radio :disabled="isDetails" :value="its.dictId"></fui-radio>
                  <span class="cell-text">{{ its.dictName }}</span>
                </view>
              </fui-label>
            </fui-radio-group>
          </fui-form-item>
          <fui-form-item labelSize="32" label="整改期限" asterisk>
            <fui-input :disabled="isDetails" v-model="item.rectifyDay" textRight type="number" min="1" max="180"
                       placeholder="请输入整改期限(1-180)">
              <span class="cell-text">天</span>
            </fui-input>
          </fui-form-item>
        </div>
        <div class="flex justifu-center" v-if="!isDetails">
          <fui-button width="400rpx" height="80rpx" @click="handleAddQusetions">添加问题</fui-button>
        </div>
      </fui-form>
        <div class="footer">
            <fui-button width="400rpx" height="80rpx" text="保存" bold @click="submit"></fui-button>
        </div>
        <!-- <selectRisks v-model:showPop="showHiddenDanger" @appoint="appoint"></selectRisks> -->

        <SelectRisks v-model:showPop="showRisks" @appoint="appoint" :riskList="hiddenList"></SelectRisks>
    </div>
</template>

<script setup>
import { reactive, ref, onMounted } from "vue";
import SelectRisks from '@/components/selectRisks.vue';
import checkListDetailsApi from "../checkListDetails/service/api";
import checkApi from "../checkListDetails/service/api";
import Api from "./service/api"
import { useRoute } from "vue-router";

const route = useRoute();

const showHiddenDanger = ref(false);
const isDetails = ref(false);
const form = ref(null);
const showRisks = ref(false);
const hiddenList = ref([]);
const fileList=ref([]);
const data = reactive({
    list: [{
        question: '',
        opinion: '',
        dangerNature: '',
        rectifyDay: '',
    },],

})
const dangerList = ref([]);
const rules = reactive([
    [{
        name: "question",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的问题描述`]
    },
    {
        name: "opinion",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的整改意见`]
    },
    {
        name: "dangerNature",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的隐患性质`]
    },
    {
        name: "rectifyDay",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的整改期限`],
    },]
]);


onMounted(async () => {
  if(route.query.isDetails == 'true'){
    isDetails.value=true;
  }
    const res = await Api.getHiddenDangerLevel();
    dangerList.value = res?.data;
    const ras = await checkApi.findContentById({ id: route.query.cdId });
    let info = ras.data || {};
  fileList.value=[]
  info.evidence.fileList.map(it=>{
    fileList.value.push({
      fileId:it.id
    })
  })

  //常见隐患 hiddenDangerList
    info?.hiddenDangerList.map((it, index) => {
        it?.successImgFileList?.forEach(i => { i.type = 1 });
        it?.errorImgFileList?.forEach(i => { i.type = 2 });
        it.imgList = it.errorImgFileList.concat(it.successImgFileList);
        it?.successVideoFileList?.forEach(i => { i.type = 1 })
        it?.errorVideoFileList?.forEach(i => { i.type = 2 })
        let videoList = it.successVideoFileList.concat(it.errorVideoFileList)
        it.videoList = []
        videoList?.map(item => {
            it.videoList.push(item?.fileUrl)
        });
    });
    hiddenList.value = info?.hiddenDangerList;
  if(info.questionList.length > 0){
    if(data.list.length==1){
      data.list=[];
      rules.splice(rules.length);
    }
    let arr = [{
      name: "question",
      rule: ["required"],
      msg: [`请输入问题${data.list.length}的问题描述`]
    },
      {
        name: "opinion",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的整改意见`]
      },
      {
        name: "dangerNature",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的隐患性质`]
      },
      {
        name: "rectifyDay",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的整改期限`],

      }]
    for (const infoElement of info.questionList) {
      data.list.push({
        question: infoElement.question,
        opinion: infoElement.opinion,
        dangerNature: infoElement.dangerNature,
        rectifyDay:infoElement.rectifyDay,
      })
      rules.push(arr)
    }
  }
})
// 删除问题
const handleDelete = (indexs) => {
    data.list.splice(indexs, 1)
    rules.splice(rules.length);
    console.log(rules);
    let arr = [{
        name: "question",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的问题描述`]
    },
    {
        name: "opinion",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的整改意见`]
    },
    {
        name: "dangerNature",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的隐患性质`]
    },
    {
        name: "rectifyDay",
        rule: ["required"],
        msg: [`请输入问题${data.list.length}的整改期限`],

    }]
    data.list.forEach(it => {
        rules.push(arr);
    })
}

//添加问题
const handleAddQusetions = () => {
    let index = data.list.length - 1;
    form.value.validator(data.list[index], rules[index], true).then(res => {
        if (res.isPassed) {
            data.list.push({
                question: '',
                opinion: '',
                dangerNature: '',
                rectifyDay: '',
            });
            let arr = [
                {
                    name: "question",
                    rule: ["required"],
                    msg: [`请输入问题${data.list.length}的问题描述`]
                },
                {
                    name: "opinion",
                    rule: ["required", "isSpecial"],
                    msg: [`请输入问题${data.list.length}的问题描述`]
                },
                {
                    name: "dangerNature",
                    rule: ["required"],
                    msg: [`请输入问题${data.list.length}的隐患性质`]
                },
                {
                    name: "rectifyDay",
                    rule: ["required"],
                    msg: [`请输入问题${data.list.length}的整改期限`],

                }];
            rules.push(arr);
        }
    })


}
// 引用
const appoint = (v) => {
    let obj = {};
    obj.question = v.describes;
    obj.dangerNature = v.level;
    if (data.list[data.list.length - 1].question == '') {
        data.list[data.list.length - 1] = obj;
    } else {
        data.list.push(obj);
    }
    showRisks.value = false;
}
const submit = async () => {
    let arr = [];
    data.list.map((item, index) => {
        arr.push(new Promise(async (resolve, reject) => {
            const res = await form.value.validator(item, rules[index], true)
            if (res.isPassed) {
                resolve(true);
            } else {
                reject(false);
            }
        }))
    })
    Promise.all(arr).then(async (res) => {
      data.list.map(it=>{
        it.fileList =fileList.value
      })
        const ras = await checkListDetailsApi.inspectCheckDataContent({
            cdcId: route.query.cdId,
            auditorStatus: 2,
            questionParamList: data.list
        })
        if (ras.code == '00000') {
            setTimeout(() => {
                uni.navigateBack({
                    delta: 2
                })
            }, 500);
        }
    }).catch(err => {
        console.log(err);
    })
}
</script>

<style scoped lang="scss">
.body {
    width: 100%;
    height: 100vh;
    overflow-y: scroll;
    background-color: #F4F5F7;
    padding: 20rpx;
    padding-bottom: 240rpx;
    box-sizing: border-box;



    .justifu-center {
        margin-bottom: 120rpx;
    }

    .footer {
        z-index: 999;
        width: 100%;
        position: absolute;
        bottom: 0;
        left: 0;
        padding: 20rpx 80rpx;
        box-sizing: border-box;
        background-color: #fff;
        box-shadow: 0rpx -10rpx 20rpx 1rpx rgba(0, 0, 0, 0.15) !important;
        display: flex;
        justify-content: center;
    }

    .red {
        color: #F95943 !important;
        font-size: 32rpx;
    }

    .box {
        width: 100%;
        margin-bottom: 30rpx;
        border-radius: 16rpx;
        overflow: hidden;
    }

    .cell-label {
        padding-right: 20rpx;
        font-size: 36rpx;
        font-weight: 600;
    }

    .cell-text {
        font-size: 32rpx;
        color: #666;
    }

    .textarea {

        :deep(.fui-form__item-wrap) {
            display: block;
        }

        :deep(.fui-form__asterisk) {
            top: 50rpx;
        }

        :deep(.fui-textarea__border) {
            padding-bottom: 0 !important;
        }

        :deep(.fui-form__item-content) {
            margin-top: 20rpx;
        }
    }

    .fui-align__center {
        margin-left: 20rpx;
    }

    .flex {
        height: 80rpx;
    }

    .icons {
        width: 46rpx;
        height: 46rpx;
        border: 1px solid #1D4AD4;
        border-radius: 50rpx;
        padding: 7rpx 32rpx;
    }

    .hidden-list {
        width: 100%;
        height: 60rpx;
        line-height: 60rpx;
        text-align: right;
        background-color: #fff;
        padding: 10rpx 40rpx;
        box-sizing: border-box;
        color: #1D4AD4;
    }
}
</style>
