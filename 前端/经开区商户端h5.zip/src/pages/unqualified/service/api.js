import http from '@/utils/network.js'

export default class Api {
    //     获取隐患性质
    //     GET /tvrjet-edz-supervision-app/gov/h5/checkData/getHiddenDangerLevel
    // 接口ID：57198454
    // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-57198454
    static getHiddenDangerLevel = (params) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getHiddenDangerLevel',
            method: 'get',
            params
        })
    }

}