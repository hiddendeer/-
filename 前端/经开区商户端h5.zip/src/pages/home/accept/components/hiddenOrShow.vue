<template>
  <div class="content-wrap">
    <div class="question-des" ref="questionDes" v-if="!showMore">
      <span>{{ props.title }}</span>
      {{ props.des }}
    </div>
    <div class="switchBtn" v-if="hasMore" @click="switchFn(1)">更多</div>
    <div class="question-des_more" v-if="showMore">
      <span>{{ props.title }}</span>
      {{ props.des }}
    </div>
    <div class="switchBtn" v-if="!hasMore && showMore" @click="switchFn(0)">
      收起
    </div>
  </div>
</template>
<script setup>
import { ref, reactive, onMounted, nextTick } from "vue";

const props = defineProps({
  title: {
    type: String,
    default: ''
  },
  des: {
    type: String,
    default: ''
  }
});

const questionDes = ref(null);
const hasMore = ref(false);
const showMore = ref(false);

onMounted(() => {
  nextTick(() => {
    hasMore.value = questionDes.value.clientHeight < questionDes.value.scrollHeight
  })
})

const switchFn = (type) => {
  if (type) {
    showMore.value = true
    hasMore.value = false
  } else {
    showMore.value = false
    hasMore.value = true
  }
}
</script>
<style lang="scss" scoped>
.content-wrap {
  font-size: 32rpx !important;
  span {
    color: #333;
    margin-right: 10px;
  }
  .question-des {
    padding: 4px 0px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    white-space: wrap;
    color: #666;
  }
  
  .question-des_more {
    padding: 4px 0px;
    color: #666;
  }
  
  .switchBtn {
    color: #1D4AD4;
    text-align: right;
    margin: 2px 0 0;
    cursor: pointer;
  }
}

</style>