<template>
	<div>
    <p class="header">{{ props.title }}</p>
    <!-- 3 整改情况 -->
    <template v-if="props.type == 3 && props.acceptType != '1'">
      <fui-radio-group name="radio" v-model="infos.result" @change="change">
        <div style="display:flex">
          <fui-label v-for="it in resultList" :key="it.id" style="padding: 5rpx 60rpx 40rpx 0;color: #333;font-size: 32rpx">
            <fui-radio :value="it.id" ></fui-radio>
            <span style="padding-left: 20rpx">{{ it.name }}</span>
          </fui-label>
        </div>
      </fui-radio-group>
      <div class="title">
        <span>图片记录</span>
        <span>({{ infos.fileList?.length ?? 0}}/6)</span>
      </div>
      <fui-upload ref="refUpload" :fileList="infos.fileList" immediate :url="infos.uploadUrl" :max="20"
        @success="(e) => successUpload(e, item)" @complete="(e) => completeUpload(e, item)"
      />
    </template>
    <template v-else-if="props.acceptType == '1'">
      <fui-form-item  label="整改结果:" :labelWidth="180" style="background:#F4F5F7">
        <p>整改通过</p>
      </fui-form-item>
      <div class="title">
        <span>图片记录</span>
        <span>({{props?.infos?.imgList?.length}}/6)</span>
      </div>
      <fui-upload :fileList="props?.infos?.imgList" :isDel="false" :isAdd="false"></fui-upload>
    </template>
    <template v-else-if="props?.infos?.imgList?.length > 0 ">
      <div class="title">
        <span>图片记录</span>
        <span>({{props?.infos?.imgList?.length}}/6)</span>
      </div>
      <fui-upload :fileList="props?.infos?.imgList" :isDel="false" :isAdd="false"></fui-upload>
    </template>
    <p class="title">文字记录</p>
    <div class="record-div" v-if="props.type == '3'" >
      <fui-textarea v-model="infos.records" :disabled="props.acceptType == '1'" :borderBottom="false" maxlength=200 />
      <img v-if="props.acceptType != '1'" src="/static/image/del_icon.png" @click="infos.records=''" alt="" />
    </div>
    <fui-textarea style="padding-bottom: 40rpx" v-else disabled=true v-model="props.infos.records" />
    <!-- 1 现场取证 -->
    <div v-if="props.type == '1'" class="title" style="padding-bottom: 0">
      <span class="cell-label red-text">不合格:</span>
      <span class="text">{{ props?.infos?.unqualified ?? 0 }}个问题></span>
    </div>
    <!-- 2 商户整改情况 -->
    <div v-if="props.type == '2'" class="title" style="padding-bottom: 0">
      <span class="cell-label">商户整改时间:</span>
      <span style="font-weight: 400">{{ props?.infos?.changeTime ?? 0 }}</span>
      <span style="color: #F95943;font-weight: 400">(逾期3天)</span>
    </div>
    <fui-button v-if="props.type == '3'" radius="96rpx" :margin="['20rpx','0']" @click="submit">提交</fui-button>
	</div>
</template>

<script setup>
import { ref, reactive, onMounted, watch } from "vue";

const props = defineProps({
	infos: {
		type: Object,
	},
  type: {
    type: String
  },
  title: {
    type: String
  },
  acceptType: {
    type: String,
    default: '0', // 0 待整改  1 已整改 
  }
});
const refUpload = ref(null);
const resultList = ref([
  { id: 1, name: '整改通过' },
  { id: 2, name: '整改不通过' }
]);
const infos = reactive({
  fileList: [],
  uploadUrl: '',
  records: '',
  result: 1
})
const emit = defineEmits(["updateList","update:show"]);
onMounted(()=>{

});
//上传成功触发
const successUpload = (e) => {
  console.log(e, "图片上传");
  if (res.data) {
    //处理结果返回给组件
    refUpload.value[0].result(res.data, e.index);
  }
};
//图片选择、上传完成、删除时触发
const completeUpload = (e, rowData) => {
//   infos.fileListObj = e.urls;
};
defineExpose({ })
</script>
<style lang="scss" scoped>
.header {
  font-size: 36rpx;
  font-weight: 600;
  text-align: center;
  padding: 40rpx 0 20rpx;
}
.title {
  font-size: 36rpx;
  padding-bottom: 20rpx;
  font-weight: 600;
}
.cell-label {
  padding-right: 20rpx;
  font-size: 36rpx;

}
.text {
  color: #1D4AD4;
  font-size: 32rpx;
  font-weight: 400;
}
.red-text {
  color: #F95943;
}
:deep(.fui-upload__wrap) {
  width: calc(100vw - 60rpx) !important;
  margin-bottom: 30rpx;
  flex-wrap: nowrap !important;
  overflow-x: auto !important;
}
.record-div {
  margin-bottom: 40rpx;
  background: #fff;
  min-height: 200rpx;
  img {
    width: 46rpx;
    margin: 0 0 30rpx 30rpx;
    height: 46rpx;
    border: 1px solid #1D4AD4;
    border-radius: 50rpx;
    padding: 7rpx 32rpx;
  }
}
:deep(.fui-form__item-wrap) {
  padding: 0 0 30rpx 0 !important;
  span {
    font-size: 36rpx;
    color: #000;
    font-weight: 600;
  }
  p {
    font-size: 32rpx;
  }
}
</style>