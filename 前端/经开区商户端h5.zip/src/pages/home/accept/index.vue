<template>
  <div class="page-container">
    <div style="height:100rpx;display: flex;align-items:center">
      <fui-tabs :tabs="tools.tabs" :short="false" sliderHeight=6 bottom=10 fontWeight="600" 
        background="#F4F5F7 " color="#999" selectedColor="#333" size=36 selectedSize=36
        selectedFontWeight="600" sliderBackground="#1D4AD4" @change="changeTabs"/>
      <img style="height: 88rpx;width: 88rpx" src="/static/image/filter_icon.png" @click="(tools.showSide = true)" />
    </div>
    <div class="list-wrap">
      <fui-loading type="col" text="加载中" isMask v-if="loading"></fui-loading>
      <fui-empty v-else-if="listData.length < 1 && !loading" title="暂无数据"></fui-empty>
      <div v-else v-for="(item,index) in listData" :key="item.id" 
          class="box flex" @click="toProject(item.id)">
        <div style="flex: 1;overflow: hidden">
          <div class="box-row flex">
            <p class="label-text">任务名称：</p>
            <p class="fui-text__explain">{{ item?.merchantName }}</p>
          </div>
          <div class="box-row flex">
            <p class="label-text">店招名：</p>
            <p class="fui-text__explain">{{ item?.merchantAliasName }}</p>
          </div>
          <div class="box-row flex">
            <p class="label-text">检查人：</p>
            <p class="fui-text__explain">{{ item?.createUser }}</p>
          </div>
          <div class="box-row flex">
            <p class="label-text">检查时间：</p>
            <p class="fui-text__explain">{{ item?.createTime }}</p>
          </div>
        </div>
        <img src="/static/image/right_arrow.png" style="height: 24rpx;width: 24rpx" /> 
      </div>
    </div>
    <!-- 筛选 -->
    <fui-drawer :show="tools.showSide" @close="(tools.showSide = false)">
      <div scroll-y class="fui-scroll__view" style="width: 75vw">
        <view class="sideBar">
          <fui-input placeholder="搜索店招名或任务名称" backgroundColor="#F4F5F7" isFillet inputBorder
            v-model="tools.searchInput"></fui-input>
          <div class="sideBar_time">
            <p>按检查时间搜索</p>
            <fui-list-cell @click="(tools.showTimer = true)">
              <view class="fui-align__center">
                <fui-icon name="calendar" @click="(showSide = true)"></fui-icon>
              </view>
              <text class="fui-text__explain">{{ tools.startTime ? tools.startTime : '请选择时间区间'
              }}</text>
            </fui-list-cell>
            <fui-list-cell @click="(tools.showTimer = true)">
              <view class="fui-align__center">
                <fui-icon name="calendar" @click="(toolsshowSide = true)"></fui-icon>
              </view>
              <text class="fui-text__explain">{{ tools.endTime ? tools.endTime : '请选择时间区间'
              }}</text>
            </fui-list-cell>
          </div>
        </view>
        <div class="sideBar_footer">
          <fui-button text="重置" radius="0" color="#333" plain @click="reset"></fui-button>
          <fui-button text="搜索" radius="0" @click="handleSearch"></fui-button>
        </div>
      </div>
    </fui-drawer>
    <fui-date-picker range :value="tools.timer" :show="tools.showTimer" type="3"
      @change="changeTimer" @cancel="cancelTimer">
    </fui-date-picker>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";

const listData = ref([
  {id: 1,merchantAliasName: '雪浪中心哈哈哈家居安好啊哈哈哦静安静',merchantName: '2022年冬季防火检查',createTime: '2022-11-02',createUser: '11111',},
  {id: 2,merchantAliasName: '雪浪中心麦当劳',merchantName: '2022年冬季防火检查',createTime: '11111',createUser: '11111',},
  {id: 3,merchantAliasName: '雪浪中心麦当劳',merchantName: '11111',createTime: '11111',createUser: '11111',},
  {id: 4,merchantAliasName: '11111',merchantName: '11111',createTime: '11111',createUser: '11111',},
  {id: 5,merchantAliasName: '11111',merchantName: '2022年冬季防火检查',createTime: '11111',createUser: '11111',},
  {id: 6,merchantAliasName: '雪浪中心麦当劳',merchantName: '11111',createTime: '11111',createUser: '11111',},
  {id: 7,merchantAliasName: '11111',merchantName: '11111',createTime: '11111',createUser: '11111',},
  {id: 8,merchantAliasName: '11111',merchantName: '11111',createTime: '11111',createUser: '11111',},
  {id: 9,merchantAliasName: '11111',merchantName: '11111',createTime: '11111',createUser: '11111',},
  {id: 10,merchantAliasName: '11111',merchantName: '11111',createTime: '11111',createUser: '11111',},
]);
const loading = ref(false);
const tools = reactive({
  tabs: [{name: '待整改'},{name: '已整改'}],
  currentTabs: 0, // 待整改
  scrollYTop: 0,
  oldScrollYTop: 0,
  showSide: false,
  searchInput: '',
  timer: '2022-12-8',
  startTime: '',
  endTime: '',
  showTimer: false,
});
const changeTabs = (e) => {
  tools.currentTabs = e?.index;
  // getRecordList()
};
//重置
const reset = () => {
  tools.searchInput = '';
  tools.startTime = '';
  tools.endTime = '';
  tools.stateIndex = '';
};
//搜索
const handleSearch = () => {
  let obj = {};
  obj.searchInput = tools.searchInput;
  obj.startTime = tools.startTime;
  obj.endTime = tools.endTime;
  obj.stateIndex = tools.stateIndex;
  console.log(obj);
};
const changeTimer = (e) => {
  tools.showTimer = false
  console.log(444,e.startDate.result);
  tools.startTime = e.startDate.result;
  tools.endTime = e.endDate.result;
};
const cancelTimer = () => {
  tools.showTimer = false
};
const scroll = (e) => {
  tools.oldScrollYTop = e.target.scrollTop;
};
const toProject = (id) => {
  uni.navigateTo({
    url: `/pages/homePage/accept/acceptProject?type=${tools.currentTabs}&id=${id}`
  })
}
</script>

<style lang="scss" scoped>
.page-container {
  background: #F4F5F7;
  height: calc(100vh - 178rpx);
  display: flex;
  flex-direction: column;
}
.list-wrap {
  padding: 0 30rpx;
  flex: 1;
  overflow: auto;
}
.box {
  background-color: #fff;
  border-radius: 10rpx;
  margin-bottom: 20rpx;
  padding: 40rpx 24rpx 30rpx;
  color: #333;
  overflow: hidden;
  align-items: center;
  justify-content: space-between;
  font-size: 32rpx;
  .box-row {
    padding-bottom: 10rpx;
    p {
      min-width: 160rpx;
      color: #666;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
.fui-scroll__view {
  height: 100%;
  padding: 88rpx 0;
  display: flex;
  flex-direction: column;
}
.sideBar {
  flex: 1;
  overflow: auto;
  background-color: #fff;
  padding: 36rpx 26rpx 40rpx;
  :deep(.fui-input__wrap) {
    padding: 16rpx 36rpx !important;
  }
}
.sideBar_time {
  background-color: #fff;
  margin: 40rpx 0rpx;
  :deep(.fui-list__cell) {
    padding: 30rpx 0 !important;
  }
  :deep(.fui-tabs__scrollbox) {
    background-color: #fff !important;
  }
  p {
    color: #333;
    font-size: 28rpx;
  }
}
.sideBar_footer {
  height: 100rpx;
  display: flex;
  align-items: center;
  margin-bottom: 40rpx;
  :deep(.fui-button) {
    width: 100% !important;
  }
}
:deep(.fui-tabs__text) {
  transform: scale(1) !important;
}
</style>