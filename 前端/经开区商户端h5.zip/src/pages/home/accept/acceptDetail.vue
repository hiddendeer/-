<template>
  <div class="page-container">
    <div style="height:100rpx">
      <fui-tabs :tabs="tools.tabs" scroll alignLeft :short="false" sliderHeight=6 bottom=10
        background="#FFF" color="#999" selectedColor="#333" size=36 selectedSize=36
        fontWeight="600" selectedFontWeight="600" sliderBackground="#1D4AD4" @change="changeTabs" />
    </div>
    <div class="list-wrap">
      <!-- <fui-loading type="col" text="加载中" isMask v-if="loading"></fui-loading>
      <fui-empty v-else-if="listData.length < 1 && !loading" title="暂无数据"></fui-empty> -->
      <div v-for="(item,index) in details" :key="index">
        <template v-if="index == tools.currentTab ">
          <fui-upload :fileList="item?.imgList" :isDel="false" :isAdd="false" style="margin: 30rpx 0"></fui-upload>
          <p class="left-title">规范说明</p>
          <fui-textarea disabled=true v-model="item.requireDesc" style="padding-bottom:40rpx" />
          
        </template>
      </div>
      <!-- 隐患 -->
      <div v-if="hiddenList?.length > 0">
        <p class="left-title">常见隐患</p>
        <div v-if="hiddenList.length > 0">
          <fui-list-cell :bottomBorder="false">
            <span class="cell-label">隐患内容:</span>
            <span class="cell-text">{{ hiddenList?.[0]?.hiddenInfo }}</span>
          </fui-list-cell>
          <fui-list-cell :bottomBorder="false">
            <span class="cell-label">整改意见:</span>
            <span class="cell-text">{{ hiddenList?.[0]?.advice }}</span>
          </fui-list-cell>
          <fui-list-cell>
            <span class="cell-label">隐患性质:</span>
            <span class="cell-text">{{ hiddenList?.[0]?.quality }}</span>
          </fui-list-cell>
          <fui-list-cell @click="showAllRisks">
            <p style="color: #1D4AD4;font-size: 32rpx;margin: auto">查看更多 >></p>
          </fui-list-cell>
        </div>
      </div>
      <!-- 现场取证 -->
      <acceptItem :infos="evidence" :type="1" title="现场取证"></acceptItem>
      <!-- 商户整改情况 -->
      <acceptItem :infos="evidence" :type="2" title="商户整改情况"></acceptItem>
      <!-- 整改情况 -->
      <acceptItem :infos="evidence" :acceptType="route.query.type" :type="3" title="整改情况"></acceptItem>
    </div>
    <selectRisks v-model:showPop="tools.showRisks" :type='1'></selectRisks>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import acceptItem from './components/acceptItem.vue';
import selectRisks from '@/components/selectRisks.vue';
import { useRoute } from "vue-router";

const route = useRoute();
const listData = ref([
  {merchantAliasName: '11111',merchantName: '11111',createTime: '11111',createUser: '11111',},
]);
const loading = ref(false);
const tools = reactive({
  currentTab: 0,
  tabs: [{name: '规范1'},{name: '规范2'},{name: '规范3'},{name: '规范4'},{name: '规范5'},{name: '规范6'}],
  current: 0,
  scrollYTop: 0,
  oldScrollYTop: 0,
  showEvidence: false, // 展示现场取证
});
const details = ref([
  { 
    name: '规范一',
    requireDesc: '配电箱周围应留有足够的安全通道和工作空间,且不应堆放易燃、腐蚀性物品。',
    imgList: [
      'http://192.168.1.240:50001/wx.hidden.dangers.report/6ced39bdabb34422809258b6e3338054.jpg',
      'http://192.168.1.240:50001/wx.hidden.dangers.report/447896efd10646709368ecc5bc58d16a.jpg',
      'http://192.168.1.240:50001/wx.hidden.dangers.report/6ced39bdabb34422809258b6e3338054.jpg',
      'http://192.168.1.240:50001/wx.hidden.dangers.report/447896efd10646709368ecc5bc58d16a.jpg',
    ]
  },
  { 
    name: '规范二',
    requireDesc: '隐患隐患。',
    imgList: [
      'http://192.168.1.240:50001/wx.hidden.dangers.report/6ced39bdabb34422809258b6e3338054.jpg',
      'http://192.168.1.240:50001/wx.hidden.dangers.report/447896efd10646709368ecc5bc58d16a.jpg',
    ]
  },
]);
const hiddenList = ref(
  [{
    hiddenInfo: '测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试',
    advice: '测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试',
    quality: '一般隐患',
  }]
);
const evidence = ref({
  imgList: [
    'http://192.168.1.240:50001/wx.hidden.dangers.report/6ced39bdabb34422809258b6e3338054.jpg',
    'http://192.168.1.240:50001/wx.hidden.dangers.report/447896efd10646709368ecc5bc58d16a.jpg',
    'http://192.168.1.240:50001/wx.hidden.dangers.report/6ced39bdabb34422809258b6e3338054.jpg',
    'http://192.168.1.240:50001/wx.hidden.dangers.report/447896efd10646709368ecc5bc58d16a.jpg'
  ],
  records: '因为空气开关有破损，需要更换一个新的空气开关此隐患时因为空气开关有破损，需要更换一个新的整改',
  unqualified: 3,
  changeTime: '2022-11-11 11:11'
});
onMounted(() => {
  queryDetails();
});
const queryDetails = () => {
  tools.tabs = details.value.map(item => {
    return Object.assign({}, { 'name': item.name })
  });
};
const changeTabs = (e) => {
  tools.currentTab = e.index;
  // getRecordList() 
};
const changeSwiper = (e) => {
  tools.current = e.detail.current;
};
const clear = () => {
  // getRecordList()
};
const scroll = (e) => {
  tools.oldScrollYTop = e.target.scrollTop;
};
const toProject = (id) => {
  uni.navigateTo({
    url: `/pages/homePage/accept/acceptProject?id=${id}`
  })
};
const showAllRisks = () => {
  tools.showRisks = true;
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #F4F5F7;
  height: calc(100vh - 88rpx);
  display: flex;
  flex-direction: column;
}
.list-wrap {
  padding: 0 30rpx;
  flex: 1;
  overflow: auto;
}
:deep(.fui-tabs__scrollbox) {
  ::-webkit-scrollbar {
    width: 0px !important;
    height: 0px !important;
  }
}
.fui-banner__wrap {
  text-align: center;
	height: 360rpx;
  border-radius: 8rpx;
}
.cell-label {
  width: 160rpx;
  font-size: 32rpx;
  color: #333;
}
.cell-text {
  flex: 1;
  font-size: 32rpx;
  color: #666;
}
.left-title {
  font-size: 36rpx;
  padding-bottom: 20rpx;
  font-weight: 600;
}
:deep(.fui-upload__wrap) {
  width: calc(100vw - 60rpx) !important;
  flex-wrap: nowrap !important;
  overflow-x: auto !important;
}
:deep(.fui-tabs__text) {
  transform: scale(1) !important;
}
</style>