<template>
  <div class="page-container">
    <div class="page-body">
      <div v-for="(item,index) in list" :key="item.id">
        <p class="title" style="padding: 20rpx">{{ item?.fName}} > {{ item?.sName }}</p>
        <fui-card full v-for="(it,inx) in item?.children" :key="inx" style="margin-bottom:20rpx;">
          <p class="title" style="padding-bottom: 20rpx">{{ it?.title }}</p>
          <div class="img-div">
            <img v-for="(e,i) in it?.imgList" :key="i" :src="e.url" alt='' />
          </div>
          <hiddenOrShow title="文字记录:" :des="it.text" :index="inx">{{inx}}</hiddenOrShow>
          <fui-form-item :label="formatName.timeName+':'" :labelWidth="200">
            <span>{{ it?.time }}</span>
          </fui-form-item>
          <div style="padding-top: 32rpx" @click="toDetail">
            <div class="bottom-btn">
              <img :src="detailImg" alt="加载失败" />
              <span>{{ formatName.detailName }}</span>
              <img class="small" :src="doubleRight" alt="加载失败" />
            </div>
          </div>
        </fui-card>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from "vue";
import detailImg from "@/static/image/detail_icon.png";
import doubleRight from "@/static/image/double_right.png";
import hiddenOrShow from './components/hiddenOrShow'
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();
const list = [
  {id: 1,fName: "消防",sName: '灭火器',
    children: [{
      title: '空气开关',
      text: '巴拉纳巴拉哈哈哈哈哈好烦好烦和哈哈哈哈好很好的哈烦好烦和哈哈哈哈好很好的哈烦好烦和哈哈哈哈好很好的哈嘿嘿我还得呵呵呵的黑乎乎的很好的和',
      time: '2022-12-07 12:11',
      imgList: [{
        url: 'https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAOEcdM.img',
      },{
        url: 'https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAOE58C.img',
      }]
    },{
      title: '灭火器',
      text: '啊哈哈哈哈对灭火器好的哈嘿嘿我还得呵呵呵的黑乎乎的很好的和',
      time: '2022-12-07 12:11',
      imgList: [{
        url: 'https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAOEcdM.img',
      },{
        url: 'https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAOE58C.img',
      }]
    }]
  },
  {id: 1,fName: "消防",sName: '手扶梯',
    children: [{
      title: '灭火器',
      text: '对灭火器巴拉纳巴拉哈哈哈哈哈好烦好烦和哈哈哈哈好很好的哈嘿嘿我还得呵呵呵的黑乎乎的很好的和',
      time: '2022-12-07 12:11',
      imgList: [{
        url: 'https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAOEcdM.img',
      },{
        url: 'https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAOE58C.img',
      }]
    }]
  },
];
const tools = reactive({
  visible: false,
  btnText: '查看',
});

onMounted(()=>{
  queryDetail();
});
const formatName = computed(() => {
  let params = {
    timeName: '',
    detailName: ''
  }
  if ( route.query.type == '1') {
    params.timeName = '隐患整改时间';
    params.detailName = '整改详情';
  } else {
    params.timeName = '隐患确定时间';
    params.detailName = '隐患整改';
  }
  return params;
});
const queryDetail = () => {
 
};
const readMore = () => {
  if (tools.visible) {
    tools.visible = false;
    tools.btnText = '查看';
  } else {
    tools.visible = true;
    tools.btnText = '隐藏';
  }
};
const toDetail = (id) => {
  uni.navigateTo({
    url: `/pages/homePage/accept/acceptDetail?type=${route.query.type}&id=${route.query.id}`
  })
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #F4F5F7;
  height: calc(100vh - 88rpx);
  overflow: auto !important;
}
.page-body {
  // height: calc(100vh - 88rpx);
  padding: 20rpx 30rpx;
  overflow: auto;
  :deep(.fui-card__body) {
    padding: 30rpx 20rpx;
    border-radius: 8rpx;
  }
}
.title {
  font-size: 36rpx;
  color: #333;
  font-weight: 600;
}
:deep(.fui-form__item-wrap) {
  font-size: 32rpx;
  color: #333;
  padding: 30rpx 0 !important;
}
.img-div {
  height: 180rpx;
  display: flex;
  justify-content: space-between;
  margin-bottom: 20rpx;
  img {
    width: 48%;
    height: 100%;
    object-fit: cover;
    border-radius: 4px;
    border: 1px solid #eee;
  }
}
.bottom-btn {
  width: 35vw;
  margin: auto;
  justify-content: space-evenly;
  display: flex;
  align-items: center;
  img {
    margin-top: 6rpx;
    width: 36rpx;
    height: 36rpx;
  }
  .small {
    width: 26rpx;
    height: 22rpx;
  }
  span {
    font-size: 32rpx;
    line-height: 38rpx;
    color: #1D4AD4;
  }
}
</style>