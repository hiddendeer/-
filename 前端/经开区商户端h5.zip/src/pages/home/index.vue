<template>
  <!-- <fui-nav-bar title="" splitLine>
    <img @click="jumpList" class="w-[90rpx] h-[90rpx]" :src="listIcon" />
  </fui-nav-bar> -->
  <div class="page-container">
    <div class="min-h-[200rpx]">
      <div class="relative my-[10rpx]">
        <div class="fui-section__title font-bold text-32rpx">安全可视</div>
      </div>
      <div
        class="bg-[#fff] p-[20rpx] rounded-[10rpx] min-h-[150rpx] flex items-center justify-around"
      >
        <div
          v-for="item in statisticsList"
          class="flex flex-col justify-center items-center w-[25%] h-[80rpx] borderClass"
          style="border-right: 2rpx solid #ebeef5"
        >
          <div class="text-54rpx font-bold" :style="{ color: item.color }">
            {{ item.num }}
          </div>
          <div class="text-[#555555] text-26rpx">{{ item.name }}</div>
        </div>
      </div>
      <div
        class="bg-[#fff] p-[20rpx] rounded-[10rpx] min-h-[150rpx] flex items-center justify-around mt-[20rpx]"
      >
        <div
          v-for="item in reactifyStatistics"
          class="flex flex-col justify-center items-center w-[33%] h-[80rpx] borderClass"
          style="border-right: 2rpx solid #ebeef5"
        >
          <div class="text-54rpx font-bold" :style="{ color: item.color }">
            {{ item.num }}
          </div>
          <div class="text-[#555555] text-26rpx">{{ item.name }}</div>
        </div>
      </div>
    </div>
    <div class="h-[160rpx] p-[20rpx]">
      <div
        class="h-full bg-[#fff] rounded-[10rpx] flex items-center justify-between px-[30rpx]"
        @click="jumpChange"
      >
        <div class="flex items-center">
          <img src="@/static/icon/rectify.png" class="w-[55rpx]" />
          <div class="font-bold text-32rpx text-[#333333] pl-[20rpx]">整改</div>
        </div>
        <div><fui-icon name="arrowright"></fui-icon></div>
      </div>
      <div
        class="mt-5 h-full bg-[#fff] rounded-[5px] flex items-center justify-between px-[30rpx]"
        @click="jumpChangesSelf"
      >
        <div class="flex items-center">
         <img src="@/static/icon/selfCheck.png" class="w-[55rpx]" />
          <div class="font-bold text-32rpx text-[#333333] pl-[20rpx]">自查</div>
        </div>
        <div><fui-icon name="arrowright"></fui-icon></div>
      </div>
      <div
        class="mt-5 h-full bg-[#fff] rounded-[5px] flex items-center justify-between px-[30rpx]"
        @click="jumpChangesLearning"
      >
        <div class="flex items-center">   <img src="@/static/icon/learnCenter.png" class="w-[55rpx]" />
        <div class="font-bold text-32rpx text-[#333333] pl-[20rpx]">学习角</div>
        </div>
        <div><fui-icon name="arrowright"></fui-icon></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import listIcon from "@/static/image/companyList/listLogo.png";
import apiMessage from '@/pages/messageCenter/service/api.js'
import api from "./server/api.js";
import { onMounted, ref ,watch,computed} from "vue";
import { onLoad } from "@dcloudio/uni-app";
import {useStore} from "vuex";
import {onShow} from "@dcloudio/uni-app";

onLoad(async (e) => {
  if (e.code) {
    uni.navigateTo({
      url: `/pages/pay/index?code=` + e.code,
    });
  }
});


const store= useStore();


onShow(()=>{
  getMessage();
})

const getShowTask = computed(() => {
  //返回的是ref对象
  return store.state.tabbar.messageNum
})

watch(getShowTask, (v) => {
  console.log(v,'v')
  if (v > 99) {
    uni.setTabBarBadge({
      index:2,
      text:'99+'
    })
  } else if (v > 0 && v <= 99) {
    uni.setTabBarBadge({
      index:2,
      text:v
    })
  }else{
    uni.removeTabBarBadge({
      index:2,
      text:0
    })
  }
}, {immediate: true, deep: true})
const getMessage=()=> {
  apiMessage.getUnreadCount().then(res => {
    if (res.data > 0) {
      store.commit("tabbar/setMessageNum", res.data)
    }else{
        store.commit("tabbar/setMessageNum", 0)
    }
  })
};

// 隐患数信息
const statisticsList = ref({
  hiddenDangerCount: { name: "隐患总数", num: "0", color: "#1D4AD4" },
  generalHiddenDangerCount: { name: "一般隐患数", num: "0", color: "#13BA79" },
  majorHiddenDangerCount: { name: "重大隐患数", num: "0", color: "#F95943" },
  overdueHiddenDangerCount: { name: "逾期隐患数", num: "0", color: "#EF7F0F" },
});

// 整改信息
const reactifyStatistics = ref({
  rectifyCount: { name: "待整改数", num: "0", color: "#F95943" },
  unRectifyCount: { name: "已整改数", num: "0", color: "#1D4AD4" },
  acceptancePassCount: { name: "验收通过数", num: "0", color: "#13BA79" },
});

onMounted(() => {
  getData();
});

// 获取统计数据
const getData = async () => {
  const res = await api.dataStatistics();
  if (res?.code == "00000") {
    for (const key in res?.data) {
      if (statisticsList.value[key]) {
        statisticsList.value[key].num = res?.data?.[key];
      }
      if (reactifyStatistics.value[key]) {
        reactifyStatistics.value[key].num = res?.data?.[key];
      }
    }
  }
};

const jumpChange = () => {
  uni.navigateTo({
    url: `/pages/homePage/accept/index`,
  });
};

// 跳转-红黑榜
const jumpList = () => {
  uni.navigateTo({
    url: `/pages/companyList/index`,
  });
};

const jumpChangesSelf = () => {
  uni.navigateTo({
    url: `/pages/selfRecords/index`,
  });
};
// 跳转-学习角
const jumpChangesLearning = () => {
  uni.navigateTo({
    url: `/pages/learningCenters/index`,
  });
};
</script>

<style lang="scss"  scoped>
.page-container {
  background: #f4f5f7;
  height: calc(100vh - 88rpx);
  overflow: auto !important;
  padding: 20rpx;
}
.fui-section__title {
  font-size: 28rpx;
  margin-left: 15rpx;
}
.fui-section__title::after {
  content: "";
  position: absolute;
  width: 6rpx;
  height: 70%;
  background: #465cff;
  border-radius: 4rpx;
  left: 0;
  top: 6rpx;
}

.borderClass:nth-last-child(1) {
  border: none !important;
}
</style>