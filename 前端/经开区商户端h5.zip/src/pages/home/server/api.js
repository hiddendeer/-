import http from '@/utils/network.js'

export default class Api {
    // 登录获取企业列表
    static getReceiptPage(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getReceiptPage',
            method: 'GET',
            data: data
        })
    }
    // 获取统计数据
    static dataStatistics(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/dataStatistics',
            method: 'GET',
            data: data
        })
    }
}