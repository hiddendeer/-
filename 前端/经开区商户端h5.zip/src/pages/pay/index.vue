<template>
  <div>
        11
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import wx from "weixin-js-sdk";
console.log(encodeURIComponent('http://172.168.10.46:3000/pages/pay/index'));
console.log(decodeURIComponent('https%3A%2F%2Fapi.qztele.com%2Fwap%2Fpages%2Fauthor%3Ftype%3DWxofficial'));

onMounted(() => {
//   wx.config({
//     debug: true, // 开启调试模式,
//     appId: "wxa31140786a732a24", // 必填，企业号的唯一标识，此处填写企业号corpid
//     timestamp: "123", // 必填，生成签名的时间戳
//     nonceStr: "234jj", // 必填，生成签名的随机串
//     signature: "272s", // 必填，签名，见附录1
//     jsApiList: ["scanQRCode", "chooseImage"], // 必填，需要使用的JS接口列表，所有JS接口列
//   });
//   wx.checkJsApi({
//     jsApiList: ["chooseImage"], // 需要检测的 JS 接口列表，所有 JS 接口列表见附录2,
//     success: function (res) {
//       console.log(res, 111);
//       // 以键值对的形式返回，可用的 api 值true，不可用为false
//       // 如：{"checkResult":{"chooseImage":true},"errMsg":"checkJsApi:ok"}
//     },
//   });
});
</script>

<style lang="scss" scoped>
</style>