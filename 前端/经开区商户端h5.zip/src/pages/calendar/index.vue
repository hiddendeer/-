<template>
    <div class="body">
        <scroll-view class="w-full h-[98vh]  pt-0 pb-[100rpx] box-border" scroll-y="true" @scrolltolower="lower"
            @scroll="scroll">
            <div class="p-3 box-border">
                <div class="mb-3 flex justify-between font-medium">
                    <div class="w-1/3 h-[100rpx] flex flex-col rounded justify-around items-center bg-white">
                        <p>{{ data.monthCheckCompanyNum }}</p>
                        <p>本月巡检次数</p>
                    </div>
                    <div class="w-1/3 h-[100rpx] flex flex-col rounded justify-around items-center bg-white">
                        <p>{{ data.monthCheckRiskNum }}</p>
                        <p>本月检查问题数</p>
                    </div>
                </div>

                <uni-calendar :insert="true" :date="Today" :selected="selectedDate" @change="change"
                    @monthSwitch="monthSwitch" />
                <div class="w-full bg-white h-[40px] flex flex-col justify-between p-3 box-border">
                    <!-- <p>本日已检 : {{ data.dayCheckCompanyNum }}家</p>
                    <p>问题商铺 : {{ data.dayCheckRiskCompanyNum }}个</p> -->
                    <p>巡检问题 : {{ data.dayCheckRiskNum }}个</p>
                </div>
                
                <fui-tabs :tabs="tabsList" :short="false" sliderHeight=6 bottom=10 fontWeight="600" background="#F4F5F7"
                    color="#999" selectedColor="#333" size=36 selectedSize=36 selectedFontWeight="600" sliderBackground="#1D4AD4"
                    @change="changeTabs" />
                <div v-if="list.length > 0">
                    <div class="content" v-for="item in list" :key="item.id">
                        <div class="box">
                            <div v-if="currentTab != 1">
                                <div class="box_row flex">
                                    <p>检查内容:</p>
                                    <p>{{ (item.taskName ?? item.taskName) }}</p>
                                </div>
                            </div>
                            <div v-else @click="toDetail(item)">
                                <div class="box_row flex">
                                    <p>任务名称:</p>
                                    <p>{{ item?.taskInfo?.taskName ?? '' }}</p>
                                </div>
                                <div class="box_row flex">
                                    <p>店招名:</p>
                                    <p>{{ item?.merchantInfo?.merchantAliasName ?? '' }}</p>
                                </div>
                                <div class="box_row flex">
                                    <p>检查人:</p>
                                    <p>{{ item?.checkRecordResult?.checkUserName ?? '' }}</p>
                                </div>
                                <div class="box_row flex">
                                    <p>检查时间:</p>
                                    <p>{{ item?.checkRecordResult?.checkTime ?? '' }}</p>
                                </div>
                            </div>

                            <p class="line" v-if="currentTab != 1"></p>
                            <div class="box_footer" v-if="currentTab != 1">
                                <div class="box_footer_right">
                                    <fui-button class="border_right" v-if="currentIndex == 0" plain color="#666666"
                                        text="删除" @click="selectIdDelete(item)"></fui-button>
                                    <fui-button @click="handleOrder('checkList', item, false)" v-if="currentIndex == 0"
                                        plain color="#1D4AD4" text="编辑"></fui-button>
                                    <fui-button class="border_right"
                                        v-if="currentIndex != 0 && item.status == 5 && isTestPersion" plain color="#1D4AD4"
                                        @click="handleOrder('signReport', item, false)" text="上传签字报告"></fui-button>
                                    <fui-button class="border_right" v-if="currentIndex != 0 && item.status == 6" plain
                                        color="#1D4AD4" @click="handleOrder('signReport', item, true)"
                                        text="查看签字报告"></fui-button>
                                    <fui-button class=" w-[80rpx]" v-if="currentIndex != 0" plain color="#1D4AD4"
                                        @click="handleOrder('checkList', item, true)" text="查看"></fui-button>
                                </div>
                            </div>
                            <div class="box_state"
                                :class="{ red: item.status == 4, blue: item.status == 5, green: item.status == 6, }"
                                v-if="currentIndex != '0'">
                                {{ item.status == 4 ? '审核中' : '' }}
                                {{ item.status == 5 ? '已审核' : '' }}
                                {{ item.status == 6 ? '已完成' : '' }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </scroll-view>
    </div>
</template>

<script setup>
import { ref, onMounted, reactive, nextTick } from "vue";
import serviceApi from './service/api';
import { onPullDownRefresh, onReachBottom, onPageScroll, onLoad, onShow } from '@dcloudio/uni-app';


const selectedDate = ref([]);
const changeDate = ref('');
const nowDate = ref({});
const Today = ref();
const tabsList = ref([
    { name: '检查记录', inx: 0 }
]);

const data = reactive({
    monthCheckCompanyNum: 0,
    monthCheckRiskNum: 0,
    dayCheckCompanyNum: 0, // 本日已检
    dayCheckRiskNum: 0, //巡查问题
    dayCheckRiskCompanyNum: 0, // 问题商铺
})


const list = ref([]);
const pageNo = ref(1);
const currentTab = ref(0);
const isLastPage = ref(false);
const isTestPersion = ref(false);

onMounted(() => {
    // let obj = JSON.parse(uni.getStorageSync('personRoles'));
    // isTestPersion.value = obj.isTestPersion || false;
})

onShow(() => {
    let [newFirstDay, newLastDay] = getMonthDay(new Date());
    nowDate.value.newFirstDay = newFirstDay;
    nowDate.value.newLastDay = newLastDay;
    let today = new Date();
    Today.value = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
    changeDate.value = Today.value;
    reset();
    getMonthStatistics();
    // handleSearch();
})

// 获取当前日期 月份的第一天与最后一天
const getMonthDay = (v) => {

    let date = new Date(v);
    let firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    let lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    let newFirstDay = firstDay.getFullYear() + "-" + (firstDay.getMonth() + 1) + "-" + firstDay.getDate();
    let newLastDay = lastDay.getFullYear() + "-" + (lastDay.getMonth() + 1) + "-" + lastDay.getDate();
    // // 当月第一天与最后一天
    // nowDate.value.firstDay = newFirstDay;
    // nowDate.value.lastDay = newLastDay;
    return [
        newFirstDay,
        newLastDay
    ]
}
// 获取本月检查商户数量
const changeDaysList = async () => {
    const rbs = await serviceApi.getMonthQueryStatisticsDetail({
        startDateTime: changeDate.value + ' 00:00:00',
        endDateTime: changeDate.value + ' 23:59:59'
    });
    data.dayCheckCompanyNum = rbs?.data.monthCheckCompanyNum || 0;
    data.dayCheckRiskNum = rbs?.data.monthCheckRiskNum || 0;
    data.dayCheckRiskCompanyNum = rbs?.data.monthCheckRiskCompanyNum || 0;
}
// 获取 本日巡检商户 与巡检记录
const getMonthStatistics = async () => {
    const res = await serviceApi.getMonthStatistics();
    data.monthCheckCompanyNum = res?.data.monthCheckCompanyNum || 0;
    data.monthCheckRiskNum = res?.data.monthCheckRiskNum || 0;
    const ras = await serviceApi.getMonthQueryStatistics({
        startDateTime: nowDate.value.newFirstDay + ' 00:00:00',
        endDateTime: nowDate.value.newLastDay + ' 23:59:59'
    });
    let arr = [];
    if (ras.data.checkDays.length > 0) {
        ras.data.checkDays.forEach(it => {
            let ojb = {
                date: it,
            }
            arr.push(ojb);
        })
    }
    nextTick(() => {
        selectedDate.value = arr;
    })
}
const changeTabs = (e) => {
    currentTab.value = e?.inx;
    reset()
    // handleSearch()
}
const toDetail = (e) => { 
    uni.navigateTo({
        url: `/pages/homePage/accept/acceptProject?type=2&id=${e?.crId}`
    })
}
//切换日期
const change = (e) => {
    changeDate.value = e.fulldate;
    reset();
    changeDaysList();
    // handleSearch()
}
// 切换月份 
const monthSwitch = (e) => {
    nowDate.value.nowMonths = e.year + '-' + e.month;
    let [newFirstDay, newLastDay] = getMonthDay(nowDate.value.nowMonths);
    nowDate.value.newFirstDay = newFirstDay;
    nowDate.value.newLastDay = newLastDay;
    reset();
    getMonthStatistics();

}
//下拉刷新
onPullDownRefresh(() => {
    reset()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 1000);
})

//上拉加载
onReachBottom(() => {
    // handleSearch()
})
const lower = (e) => {
    pageNo.value++;
    handleSearch();
}
//搜索
const handleSearch = async () => {
    if (isLastPage.value) {
        uni.showToast({
            title: '到底啦!',
            icon: 'none',
        });
        return
    }
    let obj = {};
    obj.pageNo = pageNo.value;
    obj.pageSize = 10;
    let apiName = ''
    obj.checkUser= uni.getStorageSync("userId");
    if (currentTab.value == 1) {
        obj.acceptanceStatus = 2
        obj.acceptanceTime = changeDate.value
        obj.companyId = uni.getStorageSync('merchantId');
        apiName = 'getWaitReceiptPage'
    } else {
        obj.checkClassify = 2;
        obj.statusList = [2, 3, 4, 5, 6];
        obj.checkTimeStart = changeDate.value + ' 00:00:00';
        obj.checkTimeEnd = changeDate.value + ' 23:59:59';
        obj.checkUser=uni.getStorageSync('userId');
        apiName = 'checkRecordPage'
    }
    const res = await serviceApi[`${apiName}`](obj);
    if (res.code == '00000') {
        if (res.data.pages == res.data.current) {
            isLastPage.value = true;
        }
        res.data.records.map(item => {
            list.value.push(item)
        })
    }
}
//重置
const reset = () => {
    list.value = [];
    pageNo.value = 1;
    isLastPage.value = false;
    handleSearch()
}
// 查看检查表
const handleOrder = (val, item, isDetials) => {
    uni.navigateTo({
        url: `/pages/${val}/index?recordId=${item.id}&isDetials=${isDetials}&checkType=${item.checkType}`
    })
}
</script>

<style scoped lang="scss">
.body {
    width: 100%;
    min-height: 100vh;
    background-color: #f4f5f7;
    // padding: 20rpx;
    box-sizing: border-box;
    font-size: 30rpx;
}

.content {
    width: 100%;
    padding-top: 20rpx;

    .box {
        width: 100%;
        background-color: #fff;
        border-radius: 10rpx;
        margin-bottom: 20rpx;
        padding: 20rpx;
        padding-top: 40rpx;
        box-sizing: border-box;
        font-size: 30rpx;
        color: #333333;
        overflow: hidden;
        position: relative;

        .box_state {
            position: absolute;
            right: 0;
            top: 0;
            border-radius: 0rpx 10rpx 0rpx 10rpx;
            // background-color: red;
            color: #fff;
            text-align: center;
            width: 100rpx;
            height: 50rpx;
            line-height: 50rpx;
            font-size: 24rpx;
        }

        .border_right {
            border-radius: 0rpx !important;
            border-right: 1rpx solid #eee;
        }

        .border_left {
            border-radius: 0rpx !important;
            border-left: 1rpx solid #eee;
        }

        .box_row {
            margin: 20rpx 0;

            p {
                min-width: 160rpx;
                color: #666;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        }

        .box_row :nth-last-child(1) {
            margin-left: 10rpx;
            color: #000;
        }

        .line {
            width: 100%;
            background-color: #eee;
            height: 2rpx;

            margin: 10rpx 0rpx;
        }

        .box_footer {
            width: 100%;
            height: 100rpx;

            .box_footer_right {
                width: 100%;
                height: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;

                :deep(.fui-button__wrap) {
                    height: 60rpx !important;
                }

                :deep(.fui-button) {
                    height: 60rpx !important;
                }
            }
        }
    }

    .cneter-button {
        padding: 10px 0;

        :deep(.fui-button) {
            box-shadow: 0rpx 6rpx 16rpx 0rpx rgba(70, 92, 255, 0.5);
        }
    }
}
</style>
