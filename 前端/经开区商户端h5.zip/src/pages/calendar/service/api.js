import http from '@/utils/network.js'

export default class Api {
    // 获取 本月统计
    // GET /tvrjet-edz-supervision-app/gov/h5/checkCalendar/getMonthStatistics
    // 接口ID：60976865
    // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-60976865
    static getMonthStatistics = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/h5/checkCalendar/getMonthStatistics',
            method: 'GET',
            data
        })
    }
    //     获取 月度检查日历
    //   POST /tvrjet-edz-supervision-app/gov/h5/checkCalendar/getMonthQueryStatistics
    //   接口ID：61005459
    //   接口地址：https://www.apifox.cn/link/project/2026198/apis/api-61005459
    static getMonthQueryStatistics = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/h5/checkCalendar/getMonthQueryStatistics',
            method: 'post',
            data
        })
    }
    //     获取 日检查统计
    //   POST /tvrjet-edz-supervision-app/gov/h5/checkCalendar/getMonthQueryStatisticsDetail
    //   接口ID：61063673
    //   接口地址：https://www.apifox.cn/link/project/2026198/apis/api-61063673
    static getMonthQueryStatisticsDetail = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/h5/checkCalendar/getMonthQueryStatisticsDetail',
            method: 'post',
            data
        })
    }

    //     检查记录 分页
    // POST /tvrjet-edz-supervision-app/gov/h5/checkRecord/page
    // 接口ID：54855658
    // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-54855658
    static checkRecordPage = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/h5/checkCalendar/getRecordByCheckUserPage',
            method: 'POST',
            data
        })
    }
    //     分页 待验收/已验收
    //   GET / tvrjet - edz - supervision - app / gov / h5 / home / getWaitReceiptPage
    //   接口ID：55181821
    //   接口地址：https://app.apifox.com/project/2026198/apis/api-55181821
    static getWaitReceiptPage(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/h5/checkCalendar/getWaitReceiptPage',
            method: 'POST',
            data: data
        })
    }
}