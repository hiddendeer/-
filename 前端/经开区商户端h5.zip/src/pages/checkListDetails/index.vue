<template>
    <div class="page-container">
        <div v-if="infoDetials.criterionList">
            <fui-tabs :short="false" :tabs="infoDetials.criterionList" alignLeft background="#FFF" bottom=10 color="#999"
                fontWeight="600" scroll selectedColor="#333" selectedFontWeight="600" selectedSize=36 size=36
                sliderBackground="#1D4AD4" sliderHeight=6 @change="changeTabs" />
        </div>
        <div class="list-wrap">
            <div v-for="(item, index) in infoDetials.criterionList" :key="index">
                <div v-if="index == tools.currentTab">
                    <fui-upload :fileList="item?.imageList" :isAdd="false" :isDel="false"
                        style="margin: 30rpx 0"></fui-upload>

                    <fui-upload-video ref="upload" :fileList="item?.videoList" isView></fui-upload-video>

                    <p class="left-title">规范说明</p>
                    <fui-textarea v-model="item.explains" disabled="true" style="padding-bottom:40rpx" />
                </div>
            </div>
            <!-- 隐患 -->
            <div v-if="route.query.checkType != '2' && infoDetials.hiddenDangerList?.length > 0">
                <p class="left-title">常见隐患</p>
                <div v-if="infoDetials.hiddenDangerList.length > 0">
                    <fui-list-cell :bottomBorder="false" :highlight="false">
                        <p class="cell-label">隐患内容:</p>
                        <p class="cell-text">{{ infoDetials.hiddenDangerList?.[0]?.describes }}</p>
                    </fui-list-cell>
                    <!-- <fui-list-cell :bottomBorder="false">
                        <span class="cell-label">整改意见:</span>
                        <span class="cell-text">{{ infoDetials.hiddenDangerList?.[0]?.suggest }}</span>
                    </fui-list-cell> -->
                    <fui-list-cell :highlight="false">
                        <span class="cell-label">隐患性质:</span>
                        <span class="cell-text" style="color: green;">{{
                            infoDetials.hiddenDangerList?.[0]?.levelName
                        }}</span>
                    </fui-list-cell>
                    <fui-list-cell :highlight="false">
                        <div class="cell-label w-[300rpx]">示例图片:
                            <p v-if="infoDetials.hiddenDangerList[0]?.errorImgFileList.length > 0" style="color: #1D4AD4;"
                                @click="checkPic('img', infoDetials.hiddenDangerList[0]?.errorImgFileList)">图片查看</p>
                            <!-- <p @click="checkPic('video', infoDetials.hiddenDangerList[0]?.successVideoFileList)"
                                v-if="infoDetials.hiddenDangerList[0]?.successVideoFileList.length > 0"
                                style="color: #1D4AD4;">视频查看</p> -->
                        </div>
                        <div class="cell-label">示例视频:
                            <!-- <p @click="checkPic('img', infoDetials.hiddenDangerList[0]?.errorImgFileList)"
                                v-if="infoDetials.hiddenDangerList[0]?.errorImgFileList.length > 0" style="color: #1D4AD4;"></p>
                                图片查看</p> -->
                            <p v-if="infoDetials.hiddenDangerList[0]?.errorVideoFileList.length > 0" style="color: #1D4AD4;"
                                @click="checkPic('video', infoDetials.hiddenDangerList[0]?.errorVideoFileList)">视频查看</p>
                        </div>
                    </fui-list-cell>
                    <fui-list-cell @click="tools.showRisks = true">
                        <p style=" color: #1D4AD4;font-size: 32rpx;margin: auto">查看更多》</p>
                    </fui-list-cell>
                </div>
            </div>
            <!-- 现场取证 -->
            <div>
                <p class="header">现场取证</p>
                <div class="title">
                    <span>图片记录</span>
                    <span style="color: red;">*</span>
                    <span>( {{ evidence.imgFileList?.length ?? 0 }}/ 6)</span>
                </div>
                <fui-upload :suffix="['jpg','png','jpeg']" ref="refUpload" :fileList="evidence.imgFileList" :isAdd="!isDetials" :isDel="!isDetials"
                    :max="6" :url="imageUrl" immediate @complete="complete" @success="successUpload" />

                <div class="title">
                    <span>视频上传</span>
                </div>
                <fui-upload-video  :isView="isDetials" immediate :max="1" background="#333" addColor="#d1d1d1"
                    :fileList="evidence.videoList" :url="fileUrl" ref="refUploadVideo" @success="successUploadVideo"
                    @complete="completeVideo"></fui-upload-video>
                <p class="title">文字记录</p>
                <div class="record-div">
                    <fui-textarea v-model="evidence.describes" :borderBottom="false" :disabled="isDetials" maxlength=200 />
                    <div v-if="!isDetials" class="flex flex-end">
                        <img src="/static/image/del_icon.png" @click="evidence.describes = ''" />
                    </div>
                </div>
                <div class="title" style="padding-bottom: 0">
                 <!--   <fui-tag v-if="!infoDetials.questionList?.length" :text="infoDetials.evidence?.auditorStatus == '1' ? '合格' : (infoDetials.evidence?.auditorStatus == '3'
                        ? '未判断' : '')"
                        :type="infoDetials.evidence?.auditorStatus == '1' ? 'success' : (infoDetials.evidence?.auditorStatus == '3' ? 'warning' : '')"
                        theme="light">
                    </fui-tag>
                    <fui-tag v-else @click="handleNagateTo"
                        :text="infoDetials.questionList?.length > '0' ? '不合格：' + infoDetials.questionList?.length + '个问题' : ''"
                        theme="light" type="danger">
                    </fui-tag>-->

                  <view v-if="!infoDetials.questionList?.length">
                    {{infoDetials.evidence?.auditorStatus == '1' ? '合格' : (infoDetials.evidence?.auditorStatus == '3' ? '未判断' : '')}}
                  </view>
                  <view v-else @click="handleNagateTo">
                    {{infoDetials.questionList?.length > '0' ? '不合格：' + infoDetials.questionList?.length + '个问题' : ''}}
                  </view>
                </div>
            </div>
        </div>
        <div v-if="!isDetials" class="footer flex justify-around items-center">
            <!-- <fui-button width="160rpx" height="80rpx" @click="handleButtonApply">完成</fui-button> -->

            <fui-button height="80rpx" width="160rpx" @click="submit" radius="36rpx">合格</fui-button>
            <fui-button height="80rpx" width="160rpx" @click="unqualified" radius="36rpx">不合格</fui-button>
            <!-- 后台可以配置让检查员是否可以现场核查，如果可以核查显示【现场核查】，如果不能核查只显示【完成】，点击完成去审核员审核，点击现场核查，显示合格，不合格，不清楚
合格，就是合格，不合格需要创建问题到检查员端审核，不清楚需要审核员审核 -->
            <fui-button v-if="isChecked"  height="80rpx" width="160rpx" radius="36rpx" @click="showActionsheet = true">.
            </fui-button>
        </div>
        <fui-gallery :show="showGallery" :urls="galleryUrls" @hide="showGallery = false"></fui-gallery>
        <fui-toast ref="toast"></fui-toast>
        <fui-modal :show="showModal" color="#000" descr="确定要将检查点状态变更吗?" maskClosable @click="handleUnqualified"></fui-modal>
        <fui-actionsheet :itemList="actionsheetList" :show="showActionsheet" @cancel="showActionsheet = false"
            @click="selectType" />

        <fui-backdrop :show="showVideo" closable @click="showVideo = false">
            <template #default>
                <div class="w-full h-[100vh] flex items-center">
                    <fui-swiper-dot :items="galleryUrls">
                        <swiper :duration="150" circular class="w-full h-[25vh]">
                            <swiper-item v-for="(item, index) in galleryUrls" :key="index">
                                <fui-upload-video ref="uploadVidoe" :fileList="[item.url]" class=" w-full flex items-center"
                                    isView></fui-upload-video>
                            </swiper-item>
                        </swiper>
                    </fui-swiper-dot>
                </div>
            </template>
        </fui-backdrop>
        <selectRisks v-model:showPop="tools.showRisks" :riskList="hiddenList" type=1></selectRisks>
        <!-- <fui-modal :buttons="[]" maskClosable width="750" :show="showVideo" @cancel="showVideo = false">

        </fui-modal> -->
    </div>
</template>

<script setup>
import { ref, reactive, onMounted ,onBeforeUnmount} from "vue";
import { useRoute } from "vue-router";
import { useStore } from "vuex";
import Api from "./service/api";
import commonApi from '@/api/commonApi';
import checkApi from "../checkList/service/api";
import selectRisks from '@/components/selectRisks.vue';
import { onShow } from "@dcloudio/uni-app";

const route = useRoute();
const store = useStore();

const refUpload = ref(null);
const refUploadVideo = ref(null);

const showActionsheet = ref(false);
const actionsheetList = ref(['合规', '不合格', '不清楚'])
const galleryUrls = ref([]);
const showGallery = ref(false);
const showVideo = ref(false);
const current = ref(0);

const actionsheetListSelectIndex = ref(0);
const toast = ref(null);
const showModal = ref(false);
const hiddenList = ref([]);
const tools = reactive({
    currentTab: 0,
    showRisks: false,
});


const infoDetials = ref({});
// 后台可以配置让检查员是否可以现场核查，如果可以核查显示【现场核查】，如果不能核查只显示【完成】，点击完成去审核员审核，点击现场核查，显示合格，不合格，不清楚
// 合格，就是合格，不合格需要创建问题到检查员端审核，不清楚需要审核员审核
const isChecked = ref(false);

const imageUrl = ref(window.location.origin + '/tvrjet-edz-supervision-system-custom-app/minio/upload');
const fileUrl = ref(window.location.origin + '/tvrjet-edz-supervision-system-custom-app/minio/upload');

const evidence = ref({
    id: '',
    fileList: [],
    imgFileList: [],
    describes: '',
    videoList: [],
});
const isDetials = ref(false);


onMounted(async () => {
    if (window.ls) {
        window.ls.location({
            type: 'GPS'
        }, function (res) {
            if (res.code === 200) {
                //成功
                let str = res.data.province + res.data.street + res.data.number;
                // let watermarkStr = `&lat=${res.data.latitude}&lon=${res.data.longitude}`
                imageUrl.value = imageUrl.value + 'ByWatermark?watermarkStr=' + str;
            }
        })
    }
    let info = JSON.parse(JSON.stringify(store.state.checkList.info))[route.query.index].contentList[route.query.idx];

    // 检查规范 criterionList
    info.criterionList?.map((it, index) => {
        it.name = '规范' + (index + 1);
        it.imageList = it.imgFileList.map(it => {
            return it.fileUrl
        })
        it.videoList = it.videoFileList.map(it => {
            return it.fileUrl
        })
    });
    //常见隐患 hiddenDangerList
    info?.hiddenDangerList?.map((it, index) => {
        it?.successImgFileList?.forEach(i => {
            i.type = 1
        });
        it?.errorImgFileList?.forEach(i => {
            i.type = 2
        });
        it.imgList = it.errorImgFileList.concat(it.successImgFileList);
        it?.successVideoFileList?.forEach(i => {
            i.type = 1
        })
        it?.errorVideoFileList?.forEach(i => {
            i.type = 2
        })
        let videoList = it.successVideoFileList.concat(it.errorVideoFileList)
        it.videoList = []
        videoList?.map(item => {
            it.videoList.push(item?.fileUrl)
        });
    });
    hiddenList.value = info?.hiddenDangerList;
    infoDetials.value = info;
    evidence.value.id = info.evidence?.id;
    evidence.value.describes = info.evidence?.describes;
    let newFileList = [];
    let newFileListVideo = [];
    console.log(info.evidence?.fileList);
    info.evidence?.fileList?.map((it, index) => {
        let testMsg = it.fileUrl.substring(it.fileUrl.lastIndexOf(".") + 1);
        let type = ["mp4", "webm"];
        let isVideo = type.includes(testMsg);
        if (isVideo) {
            console.log(it.fileUrl);
            newFileListVideo.push(it.fileUrl)
        } else {
            newFileList.push(it.fileUrl);
        }
        evidence.value.fileList.push({
            fileId: it.id,
            fileUrl: it.fileUrl,
        });
    })
    evidence.value.imgFileList = newFileList;
    evidence.value.videoList = newFileListVideo;
    console.log("newFileListVideo", newFileListVideo);
});

onShow(() => {
    isDetials.value = route.query.isDetials == 'true' ? true : false;
    console.log(isDetials.value);
})
onBeforeUnmount(()=>{
  uni.closePreviewImage()
})
const handleNagateTo=()=>{
  uni.navigateTo({
    url: `/pages/unqualified/index?cdId=${infoDetials.value.id}&index=${route.query.index}&idx=${route.query.idx}&auditorStatus=2&isDetails=${isDetials.value}`
  })
}
const changeTabs = (e) => {
    tools.currentTab = e.index;
    // getRecordList() 
};
const checkPic = (type, list) => {
    if (type == 'img') {
        showGallery.value = true;
        galleryUrls.value = list.map((it, index) => {
            return it.fileUrl
        })
    } else {
        showVideo.value = true;
        let arr = [];
        list.map((it, index) => {
            arr.push({
                url: it.fileUrl
            })
        })
        galleryUrls.value = arr;
    }
}
//上传成功触发
const successUpload = (e) => {
    let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
    if (res.data) {
        evidence.value.fileList.push({
            fileId: res.data?.id,
            fileUrl: res.data?.fileUrl,
        });
        evidence.value.imgFileList.push(res.data?.fileUrl);
        //处理结果返回给组件
        refUpload.value.result(res.data.fileUrl, e.index);
    }
};
//图片选择、上传完成、删除时触发
const complete = (e) => {
    if (e?.action == 'delete') {
        evidence.value.imgFileList = e?.urls;
    }
};
const successUploadVideo = (e) => {
    let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
    if (res.data) {
        evidence.value.fileList.push({
            fileId: res.data?.id,
            fileUrl: res.data?.fileUrl,
        });
        evidence.value.videoList.push(res.data?.fileUrl);
        //处理结果返回给组件
        refUploadVideo.value.result(res.data.fileUrl, e.index);
    }
}
const completeVideo = (e) => {
    if (e?.action == 'delete') {
        evidence.value.videoList = e?.urls;
    }
};

// 提示
const showToast = (text) => {
    let options = {}
    //提示信息
    options.text = text;
    toast.value.show(options)
}
// 完成
const handleButtonApply = async () => {
    if (evidence.value.imgFileList.length < 1) {
        return showToast('请选择图片!')
    }
    await newArr();
    back()
}
//获取新的图片与文字记录 save
const newArr = async () => {
    let newFileList = [...evidence.value.imgFileList, ...evidence.value.videoList];

    let arrFileID = [];
    evidence.value.fileList.forEach(item => {
        newFileList.forEach(it => {
            if (it == item.fileUrl) {
                arrFileID.push({
                    id: item.fileId
                })
            }
        })
    })
    if (store.state.checkList.editId) {
        let id = JSON.parse(JSON.stringify(store.state.checkList.info))[route.query.index].contentList[route.query.idx].id;
        const res = await checkApi.saveCheckDataContentEvidence({
            cdcId: id,
            describes: evidence.value.describes,
            fileList: arrFileID
        })
        if (res.success) return

    }
    let arr = JSON.parse(JSON.stringify(store.state.checkList.info));
    arr[route.query.index].contentList[route.query.idx].evidence = evidence.value;
    arr[route.query.index].contentList[route.query.idx].evidence.fileList = arrFileID;
    store.commit("checkList/setInfo", arr)
    let newArr = [];
    arr.map(item => {
        item.contentList.map(it => {
            newArr.push(it)
        })
    });
    await checkApi.saveCheckData({
        ctId: route.query.taskId,
        companyId: route.query.companyId,
        checkType: route.query.checkType,
        name: route.query.name,
        checkDataContentResults: newArr,
    })
}

//返回上一页
const back = (res) => {
    setTimeout(() => {
        // const pages = getCurrentPages();
        // console.log(pages);
        // //关于获取页面的官方文档https://uniapp.dcloud.io/api/window/window
        // const beforePage = pages[pages.length - 2];
        // beforePage.getList();
        uni.navigateBack({
            delta: 1
        });
    }, 200);

}
// 现场核查
const selectType = (e) => {
    if (evidence.value.imgFileList.length < 1) {
        return showToast('请选择图片!')
    }
    actionsheetListSelectIndex.value = e.index + 1;
    showActionsheet.value = false;
    showModal.value = true;
}
//合格
const submit = async (type) => {
    if (evidence.value.imgFileList.length < 1) {
        return showToast('请选择图片!')
    }
    await newArr();
    await Api.inspectCheckDataContent({
        cdcId: infoDetials.value.id,
        auditorStatus: 1
    })
    back()
}
// 不合格
const unqualified = async () => {
    if (evidence.value.imgFileList.length < 1) {
        return showToast('请选择图片!')
    }
    await newArr();
    uni.navigateTo({
      url: `/pages/unqualified/index?cdId=${infoDetials.value.id}&index=${route.query.index}&idx=${route.query.idx}&auditorStatus=${actionsheetListSelectIndex.value}&isDetails=${isDetials.value}`
    })
}
const handleUnqualified = async (e) => {
    showModal.value = false;
    if (e.index == 0) {
        return
    }
    if (actionsheetListSelectIndex.value != 2) {
        submit(actionsheetListSelectIndex.value)
    } else {
        await newArr();
      uni.navigateTo({
        url: `/pages/unqualified/index?cdId=${infoDetials.value.id}&index=${route.query.index}&idx=${route.query.idx}&auditorStatus=${actionsheetListSelectIndex.value}&isDetails=${isDetials.value}`
      })
    }
}
</script>

<style lang="scss" scoped>
.footer {
  z-index: 999;
  width: 100%;
  position: absolute;
  bottom: 0;
  left: 0;
  padding: 20rpx 80rpx;
  box-sizing: border-box;
  background-color: #fff;
  box-shadow: 0rpx -10rpx 20rpx 1rpx rgba(0, 0, 0, 0.15) !important;
}

// :deep(.uni-actionsheet) {
//     width: 100%;
//     z-index: 99999;
//     left: 0;
//     right: 0;
// }

// :deep(.uni-actionsheet__action) {
//     margin-top: 0rpx;
//     border-radius: 0rpx;
//     border-top: 2rpx solid #f3f3f4;
// }

.header {
  font-size: 36rpx;
  font-weight: 600;
  text-align: center;
  padding: 40rpx 0 20rpx;
}

.page-container {
  position: relative;
  background: #F4F5F7;
  // height: calc(100vh - 88rpx);
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.record-div {
  margin-bottom: 40rpx;
  background: #fff;
  min-height: 200rpx;

  img {
    width: 46rpx;
    margin: 0rpx 20rpx 20rpx 0rpx;
    height: 46rpx;
    border: 1px solid #1D4AD4;
    border-radius: 50rpx;
    padding: 7rpx 32rpx;
  }
}

.title {
  font-size: 36rpx;
  padding-bottom: 20rpx;
  font-weight: 600;
}

.cell-label {
  padding-right: 20rpx;
  font-size: 36rpx;
}

:deep(.fui-list__cell) {
  align-items: flex-start;
}

.list-wrap {
  padding: 0 30rpx;
  flex: 1;
  overflow: auto;
  margin-bottom: 220rpx;
}

:deep(.fui-tabs__scrollbox) {
  ::-webkit-scrollbar {
    width: 0px !important;
    height: 0px !important;
  }
}

.fui-banner__wrap {
  text-align: center;
  height: 360rpx;
  border-radius: 8rpx;
}

.cell-label {
  width: 160rpx;
  font-size: 32rpx;
  color: #333;
}

.cell-text {
  width: 60%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
  font-size: 32rpx;
  color: #666;
}

.left-title {
  font-size: 36rpx;
  padding-bottom: 20rpx;
  font-weight: 600;
}

:deep(.fui-upload__wrap) {
  width: calc(100vw - 60rpx) !important;
  flex-wrap: nowrap !important;
  overflow-x: auto !important;
}

:deep(.fui-uploadv__item) {
  width: 100% !important;
}
</style>