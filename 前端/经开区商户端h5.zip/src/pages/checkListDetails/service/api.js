import http from '@/utils/network.js'

export default class Api {
    //     现场核查
    //   POST /tvrjet-edz-supervision-app/gov/h5/checkData/inspectCheckDataContent
    //   接口ID：54794336
    //   接口地址：https://www.apifox.cn/link/project/2026198/apis/api-54794336
    static inspectCheckDataContent = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/inspectCheckDataContent',
            method: 'POST',
            data
        })
    }
    //     查询配置详情
    //   POST /tvrjet-edz-supervision-app/base/checkConfig/getDetailByCode
    //   接口ID：56933155
    //   接口地址：https://www.apifox.cn/link/project/2026198/apis/api-56933155
    static queryDetail = (data) => {
        return http.request({
            url: '/tvrjet-edz-supervision-app/base/checkConfig/getDetailByCode',
            method: 'POST',
            data
        })
    }

    //     检查内容-详情
    //   POST /tvrjet-edz-supervision-app/gov/h5/checkData/findContentById
    //   接口ID：57644553
    //   接口地址：https://www.apifox.cn/link/project/2026198/apis/api-57644553
    static findContentById = (data) => {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/findContentById',
            method: 'POST',
            data
        })
    }
}