<template>
  <view class="page check-log-page">
    <view class="select-container">
      <SelectMenu
        class="select-container_item"
        placeholder="按时间筛选"
        :isActive="selectActive"
        :val="formData.dateVal"
        @selectChange="selectChange($event, 'time')"
      ></SelectMenu>
      <SelectMenu
        class="select-container_item"
        placeholder="按行政区域筛选"
        :isActive="areaActive"
        :val="formData.resultRegion"
        @selectChange="selectChange($event, 'area')"
      ></SelectMenu>
    </view>
    <view class="pageDetail">
      <view class="topSearch">
        <view class="searchInput">
          <fui-search-bar
            ref="merchantName"
            height="88"
            radius="50"
            background="#f1f1f1"
            :isLeft="true"
            :cancel="false"
            placeholder="请输入店招名进行模糊搜索"
            @search="search"
            @clear="clear"
          ></fui-search-bar>
        </view>
        <fui-button
          size="30"
          height="80rpx"
          :plain="true"
          width="120rpx"
          radius="50rpx"
          borderWidth="2px"
          borderColor="#465CFF"
          color="#465CFF"
          background="#FFFFFF"
          @click="reset"
          >重置</fui-button
        >
      </view>
      <view
        class="card-list"
        v-for="(item, index) in checkLogList"
        :key="index"
        @click="goFinishCheckDetail(item)"
      >
        <view class="card-list__left">
          <text class="label">店招名：</text>
          <text class="val">{{ item.merchantAliasName || '-' }}</text>
          <text class="label">企业名：</text>
          <text class="val">{{ item.merchantName || '-' }} </text>
          <text class="label">检查时间：</text>
          <text class="val">{{ item.createTime.split(' ')[0] || '-' }}</text>
        </view>
        <fui-icon size="48" name="arrowright" color="#b2b2b2"></fui-icon>
        <view
          class="card-list__topRight"
          :class="{ draft: item.examineStatus == 'DRAFT' }"
        >
          {{ item.examineStatus == 'DRAFT' ? '暂存' : '完成' }}
        </view>
      </view>
      <fui-empty v-if="checkLogList.length == 0"></fui-empty>
    </view>
    <fui-bottom-popup
      class="calendar-container"
      :show="showCalendar"
      @close="calendarClose"
    >
      <view class="calendar__wrap">
        <view class="calendar__wrap-title">请选择日期</view>
        <fui-icon
          class="calendar__wrap-icon"
          name="close"
          :size="50"
          @click="calendarClose"
          color="#333"
        ></fui-icon>
        <fui-calendar
          type="3"
          showBtn
          showLunar
          @change="datePickerChange"
        ></fui-calendar>
      </view>
    </fui-bottom-popup>
    <fui-picker
      linkage
      :fields="['orgName', 'orgId', 'children']"
      :layer="2"
      :options="areaOptions"
      :show="showPicker"
      @change="pickerChange"
      @cancel="pickerCancel"
    ></fui-picker>
    <fui-safe-area background="#f1f1f1"></fui-safe-area>
  </view>
</template>

<script>
import { queryRecordList } from '@/api/authApi.js'
import { getExpHrOrgan } from '@/api/awaitCheck.js'
import SelectMenu from '@/components/select-menu/index.vue'
import { mapState } from 'vuex'
import _ from 'lodash'
export default {
  components: {
    SelectMenu
  },
  computed: {
    ...mapState({
      userId: state => state.auth.userData.userId
    })
  },
  data() {
    return {
      showCalendar: false,
      showPicker: false,
      selectActive: false,
      areaActive: false,

      formData: {
        dateVal: '',
        resultRegion: '',
        searchBeginTime: '',
        searchEndTime: '',
        merchantRegion: ''
      },
      areaOptions: [],
      checkLogList: [] //检查记录列表
    }
  },
  onLoad(options) {
    this.getAreaData()
  },
  onShow() {
    this.getQueryRecordList()
  },
  methods: {
    reset() {
      this.formData = this.$options.data().formData
      this.$refs.merchantName.clearInput()
      this.getQueryRecordList()
    },
    //获取地区数据
    async getAreaData() {
      let { data } = await getExpHrOrgan({ startOrgLevel: 4, orgLevel: 5 })
      data.forEach(item => {
        if (!_.isEmpty(item.children)) {
          item.children.unshift({
            orgId: item.orgId,
            orgName: '全部'
          })
        } else {
          item.children = [
            {
              orgId: item.orgId,
              orgName: '全部'
            }
          ]
        }
      })
      this.areaOptions = data
    },
    //拉取列表数据
    async getQueryRecordList() {
      let { dateVal, resultRegion, ...options } = this.formData
      let params = {
        merchantName: this.$refs.merchantName?.val || '',
        createUser: this.userId,
        ...options
      }
      let { data } = await queryRecordList(params)
      this.checkLogList = data
    },
    selectChange(val, t) {
      if (t === 'time') {
        this.showCalendar = val
        this.selectActive = val
      } else {
        this.showPicker = val
        this.areaActive = val
      }
    },
    datePickerChange({ value }) {
      this.formData.dateVal = value.join('至')
      this.formData.searchBeginTime = value[0] || ''
      this.formData.searchEndTime = value[1] || ''
      this.calendarClose()
      this.getQueryRecordList()
    },
    calendarClose() {
      this.showCalendar = false
      this.selectActive = false
    },
    pickerChange(val) {
      this.formData.resultRegion = val.text[1] || ''
      this.formData.merchantRegion = val.value[1]
      this.pickerCancel()
      this.getQueryRecordList()
    },
    pickerCancel() {
      this.showPicker = false
      this.areaActive = false
    },
    search() {
      this.getQueryRecordList()
    },
    clear() {
      this.getQueryRecordList()
    },
    goFinishCheckDetail(item) {
      if (item.examineStatus == 'DRAFT') {
        uni.navigateTo({
          url: `/pages/homePage/beginCheck/startCheck?inspectionRecordId=${item.inspectionRecordId}`
        })
      } else {
        uni.navigateTo({
          url: `/pages/homePage/logCheck/checkLogDetail?inspectionRecordId=${item.inspectionRecordId}`
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.check-log-page {
  display: flex;
  flex-direction: column;
  overflow: hidden !important;
  .calendar__wrap {
    padding-top: 10rpx;
    position: relative;
    &-title {
      font-size: 30rpx;
      font-weight: 700;
      text-align: center;
      padding: 10rpx;
      color: #333;
    }
    &-icon {
      position: absolute;
      top: 10rpx;
      right: 20rpx;
    }
  }
  .select-container {
    display: flex;
    justify-content: space-between;
    padding: 20rpx 30rpx;
    background: #fff;
    position: relative;
    &:first-child::after {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      content: '';
      width: 1rpx;
      height: 40rpx;
      background: #999999;
    }
    &_item {
      max-width: 48%;
      flex-shrink: 0;
      overflow: hidden;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }

  .pageDetail {
    overflow: auto;
    padding: 0 30rpx;
    .topSearch {
      margin: 20rpx 0;
      display: flex;
      align-items: center;
      background: #fff;
      border-radius: 50rpx;
      .searchInput {
        flex: 1;
        :deep(.fui-search__bar-wrap) {
          border-radius: 50rpx !important;
          background: #fff !important;
          padding: 0 !important;
          .fui-search__bar-btn {
            font-size: 30rpx !important;
            border: 0.5rpx solid #465cff;
            border-radius: 50rpx;
            height: 79rpx;
            width: 120rpx;
            box-sizing: initial;
            text-align: center;
            line-height: 76rpx;
          }
        }
      }
      :deep(.fui-button__wrap) {
        margin: 10rpx !important;
      }
    }
    .card-list {
      position: relative;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #fff;
      border-radius: 20rpx;
      padding: 30rpx;
      margin-bottom: 30rpx;
      box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
      &__left {
        display: grid;
        grid-template-columns: 160rpx 1fr;
        grid-row-gap: 10rpx;
        line-height: 1.5;
        margin: 8rpx 0;
        .label {
          color: #555555;
          font-size: 30rpx;
        }
        .val {
          color: #333333;
          font-size: 30rpx;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
      &:last-child {
        margin-bottom: 200rpx;
      }
      &__topRight {
        position: absolute;
        right: 0rpx;
        top: 20rpx;
        color: #fff;
        background: rgba(70, 92, 255, 0.6);
        padding: 6rpx 14rpx 6rpx 36rpx;
        border-radius: 30rpx 0 0 30rpx;
      }
      .draft {
        background: rgba(255, 128, 33, 0.6);
      }
    }
  }
}
</style>
