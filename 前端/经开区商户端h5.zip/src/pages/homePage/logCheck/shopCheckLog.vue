<template>
  <view class="page shop-check-log-page">
    <view
      class="card-list"
      v-for="(item, index) in checkLogList"
      :key="index"
      @click="goCheckLogDetail(item)"
    >
      <view class="card-list__left">
        <view class="line shopName">{{ item.createTime.split(' ')[0] }}</view>
        <view class="line">检查人：{{ item.createUser }}</view>
        <view class="line">
          审核状态：
          <text
            :class="
              item.examineStatus == 'SUBMITTED'
                ? 'orange'
                : item.examineStatus == 'REVIEWED'
                ? 'blue'
                : ''
            "
            >{{ examineText(item.examineStatus) }}</text
          >
        </view>
        <view v-if="item.examineStatus == 'REVIEWED'" class="line">
          隐患数：
          <text class="orange">{{ item.hiddenCount }}</text
          >个
        </view>
      </view>
      <fui-icon size="48" name="arrowright" color="#b2b2b2"></fui-icon>
      <view
        class="card-list__topRight"
        :class="{ draft: item.examineStatus == 'DRAFT' }"
      >
        {{ item.examineStatus == 'DRAFT' ? '暂存' : '完成' }}
      </view>
    </view>
    <fui-empty v-if="checkLogList.length == 0"></fui-empty>
  </view>
</template>

<script>
import { queryRecordList } from '@/api/authApi.js'
export default {
  data() {
    return {
      merchantId: '', //店铺的id
      checkLogList: [] //检查记录列表
    }
  },
  onLoad(options) {
    if (options.merchantId) {
      this.merchantId = options.merchantId
      this.getQueryRecordList()
    } else {
      uni.showToast({
        title: '未获取到店铺ID',
        icon: 'none'
      })
      uni.navigateBack()
    }
  },
  methods: {
    async getQueryRecordList() {
      let { data } = await queryRecordList({
        merchantId: this.merchantId
      })
      this.checkLogList = data
    },
    goCheckLogDetail(item) {
      if (item.examineStatus == 'DRAFT') {
        uni.navigateTo({
          url: `/pages/homePage/beginCheck/startCheck?inspectionRecordId=${item.inspectionRecordId}`
        })
      } else {
        uni.navigateTo({
          url: `/pages/homePage/logCheck/checkLogDetail?inspectionRecordId=${item.inspectionRecordId}`
        })
      }
    },
    examineText(val) {
      //  DRAFT("DRAFT", "草稿/暂存"),
      //  SUBMITTED("SUBMITTED", "已提交/待审核"),
      //  REVIEWED("REVIEWED", "已审核");
      if (val == 'REVIEWED') {
        return '已审核'
      } else if (val == 'SUBMITTED') {
        return '未审核'
      } else {
        return '-'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.shop-check-log-page {
  padding: 0 20rpx;
  overflow: auto;
  display: flex;
  flex-direction: column;
  align-content: center;
  .card-list {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fff;
    border-radius: 20rpx;
    padding: 30rpx;
    margin-bottom: 30rpx;
    position: relative;
    box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
    &__left {
      flex: 1;
      margin-left: 20rpx;
      .line {
        line-height: 1.5;
        color: #555555;
        font-size: 30rpx;
        margin: 10rpx 0;
        overflow: hidden;
        white-space: normal;
        word-wrap: break-word;
        word-break: break-all;
        text-overflow: ellipsis;
        .orange {
          color: #ff8021;
        }
        .blue {
          color: #465cff;
        }
      }
      .shopName {
        font-weight: bold;
        color: #333333;
        font-size: 36rpx;
      }
    }
    &__topRight {
      position: absolute;
      right: 0rpx;
      top: 20rpx;
      color: #fff;
      background: rgba(70, 92, 255, 0.6);
      padding: 6rpx 14rpx 6rpx 36rpx;
      border-radius: 30rpx 0 0 30rpx;
    }
    .draft {
      background: rgba(255, 128, 33, 0.6);
    }
    &:first-child {
      margin-top: 30rpx;
    }
    &:last-child {
      margin-bottom: 200rpx;
    }
  }
}
</style>
