<template>
  <view class="page check-log-detail-page">
    <view class="checkDate">
      <view
        class="onceDate"
        v-for="(item, index) in checkItemList"
        :key="index"
      >
        <view class="onceDate_title">
          <view class="onceDate_title_name">
            {{ item.checkSpotName }}
          </view>
        </view>
        <view class="onceDate_imgGroup">
          <view class="setDisplay">
            <fui-upload
              :isAdd="false"
              :isDel="false"
              :fileList="item.imageUrls"
            ></fui-upload>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { queryRecordDetail } from '@/api/logCheckApi'
export default {
  data() {
    return {
      inspectionRecordId: '',
      checkItemList: []
    }
  },
  computed: {},

  onLoad(options) {
    if (options.inspectionRecordId) {
      this.inspectionRecordId = options.inspectionRecordId
      this.getQueryRecordDetail()
    } else {
      uni.showToast({
        title: '未获取到当前记录ID',
        icon: 'none'
      })
      uni.navigateBack()
    }
  },
  onShow() {},
  onLaunch() {},
  methods: {
    async getQueryRecordDetail() {
      let { data } = await queryRecordDetail({
        supervisionInspectionRecordId: this.inspectionRecordId
      })
      this.checkItemList = data.dataList
    }
  }
}
</script>
<style lang="scss" scoped>
.check-log-detail-page {
  width: 100vw;
  display: flex;
  flex-direction: column;
  .checkDate {
    overflow: auto;
    height: 100%;
    padding: 30rpx 30rpx 0 30rpx;
    .onceDate {
      border-radius: 20rpx;
      margin-bottom: 30rpx;
      background: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
      &_title {
        display: flex;
        justify-content: space-between;
        background: #fff;
        margin: 20rpx 0;
        font-size: 48rpx;
        font-weight: bold;
        &_name {
          margin-left: 30rpx;
          font-weight: bold;
          font-size: 36rpx;
        }
      }
      &_imgGroup {
        display: flex;
        justify-content: center;
        .setDisplay {
          margin-left: 20rpx;
          width: 660rpx;
          :deep(.fui-upload__item) {
            border-radius: 20rpx;
            overflow: auto;
          }
        }
      }
      &:last-child {
        margin-bottom: 300rpx;
      }
    }
  }
}
</style>
