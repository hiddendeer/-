<template>
  <div class="page-container">
    <div class="searchInput">
      <fui-search-bar height="72" radius="10" background="#fff" inputBackground="#F4F5F7"
        paddingLr="30" :isLeft="true" :cancel="false" placeholder="请输入企业名/店招名进行模糊搜索"
        @search="search" @clear="clear" />
    </div>
    <div class="list-wrap">
      <fui-empty></fui-empty>
      <fui-loading type="col" text="加载中" isMask v-if="loading"></fui-loading>
      <fui-empty v-else-if="listData.length < 1 && !loading" title="暂无数据"></fui-empty>
      <div class="box flex" v-else v-for="item in listData"
        :key="item.inspectionRecordId" @click="toDetail(item)"> 
        <div style="flex: 1;overflow: hidden">
          <div class="box-row flex">
            <p class="label-text">店招名：</p>
            <p class="fui-text__explain">{{ item?.merchantAliasName }}</p>
          </div>
          <div class="box-row flex">
            <p class="label-text">企业名：</p>
            <p class="fui-text__explain">{{ item?.merchantName }}</p>
          </div>
          <div class="box-row flex">
            <p class="label-text">行政区域：</p>
            <p class="fui-text__explain">{{ item?.area }}</p>
          </div>
          <div class="box-row flex">
            <p class="label-text">地址：</p>
            <p class="fui-text__explain">{{ item?.address }}</p>
          </div>
        </div>
        <img src="/static/image/right_arrow.png" style="height: 24rpx;width: 24rpx" /> 
      
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, render } from "vue";

const listData = ref([
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
  {merchantAliasName: '11111',merchantName: '11111',area: '11111',address: '11111',},
]);
const loading = ref(false);
const tools = reactive({
  scrollYTop: 0,
  oldScrollYTop: 0,
});
const search = () => {
  // getRecordList()
};
const clear = () => {
  // getRecordList()
};
const scroll = (e) => {
  tools.oldScrollYTop = e.target.scrollTop;
};
const toDetail = (id) => {
  uni.navigateTo({
    url: `/pages/homePage/newCheck/businessDetail?inspectionRecordId=${id}`
  })
}
</script>

<style lang="scss">
.page-container {
  background: #F4F5F7;
  height: calc(100vh - 88rpx);
  display: flex;
  flex-direction: column;
}
.searchInput {
  background: #fff;
  height: 100rpx;
  padding: 0;
}
.list-wrap {
  padding: 40rpx 30rpx 0;
  flex: 1;
  overflow: auto;
}
.box {
  background-color: #fff;
  border-radius: 10rpx;
  margin-bottom: 20rpx;
  padding: 40rpx 24rpx 30rpx;
  color: #333;
  overflow: hidden;
  align-items: center;
  justify-content: space-between;
  font-size: 32rpx;
  .box-row {
    padding-bottom: 10rpx;
    p {
      min-width: 160rpx;
      color: #666;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .fui-text__explain {
      color: #333;
    }
  }
}
</style>