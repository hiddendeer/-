import http from '@/utils/network.js'

export default class checkApi {
  // 分页 开始检查-商户列表
  static getMerchantList(data) {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/h5/home/getMerchantList',
      method: 'GET',
      data: data
    })
  }
  // 开始检查 获取 商户-任务列表
  static getMerchantTaskList(data) {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/h5/home/getMerchantTaskList',
      method: 'GET',
      data: data
    })
  }
  // 修改商户
  static updateMerchant(data) {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/web/merchantInfo/update',
      method: 'POST',
      data: data
    })
  }
  // 添加商户
  static addMerchant(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/merchantInfoAdd',
      method: 'POST',
      data: data
    })
  }
  // 获取商户详情
  static getDetail(data) {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/web/merchantInfo/getDetail',
      method: 'GET',
      data: data
    })
  }
}