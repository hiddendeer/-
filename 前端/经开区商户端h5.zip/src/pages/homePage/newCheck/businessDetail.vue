<template>
  <div class="page-container flex flex-col">
    <div class="page-btn-body flex-1">
      <div class="w-full flex items-center justify-center text-[#1D4AD4] text-14px" v-if="tools.add || tools.edit">
        <fui-icon color="#1D4AD4" name="camera"></fui-icon>
        <span class="ml-[10px]" @click="openOCR">拍营业执照识别商户信息</span>
        <fui-bottom-popup :show="tools.showUpload">
          <div class="popup-title">
            <span>上传营业执照</span>
            <fui-icon name="close" :size="48" @click="tools.showUpload = false"></fui-icon>
          </div>
          <scroll-view class="popup-body px-[15px]">
            <fui-radio-group name="radio" v-model="tools.OCRType">
              <div style="display:flex">
                <fui-label v-for="it in tools.OCRList" :key="it.id"
                  style="padding: 5rpx 60rpx 40rpx 0;color: #333;font-size: 32rpx">
                  <fui-radio :value="it.id + ''"></fui-radio>
                  <span style="padding-left: 20rpx">{{ it.text }}</span>
                </fui-label>
              </div>
            </fui-radio-group>
            <fui-upload ref="refUpload" :fileList="formData.fileList" :url="tools.uploadUrl" :max="1" background="#F4F5F7"
              immediate @success="(e) => successUpload(e)" :formData="{ type: tools.OCRType }"
              @complete="(e) => completeUpload(e)" />
          </scroll-view>
        </fui-bottom-popup>
      </div>
      <div v-if="!tools.edit && !tools.add" class="btn-text" @click="editClick">编辑</div>
      <fui-form ref="formRef" v-model="formData" class="mt-[5px] bg-white rounded-[5px]">
        <!-- <fui-form-item borderColor="#ddd" labelWidth=260 :asterisk="tools.edit && !tools.add" label="营业执照:">
          <fui-upload ref="refUpload" :fileList="formData.fileList" immediate :url="tools.uploadUrl" :max="1"
            @success="(e) => successUpload(e)" @complete="(e) => completeUpload(e)"
          />
        </fui-form-item> -->
        <fui-form-item borderColor="#ddd" labelWidth=280 :asterisk="tools.edit || tools.add" label="统一社会信用代码:">
          <fui-input :borderBottom="false" v-model="formData.unifiedCreditCode"
            maxlength="18"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=135 :asterisk="tools.edit || tools.add" label="店招名:">
          <fui-input :borderBottom="false" maxlength="100"
            v-model="formData.merchantAliasName"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=135 :asterisk="tools.edit || tools.add" label="企业名:">
          <fui-input :borderBottom="false" maxlength="100"
            v-model="formData.merchantName"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="注册地址:">
          <fui-input :borderBottom="false" maxlength="100"
            v-model="formData.registerAddress"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="经营地址:">
          <fui-input :borderBottom="false" maxlength="100"
            v-model="formData.businessAddress"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=100 label="坐标:">
          <div class="flex">
            <fui-input :bottomLeft="0" placeholder="经度" disabled v-model="formData.longitude"></fui-input>
            <span class="mx-[10px] font-bold">:</span>
            <fui-input :bottomLeft="0" placeholder="纬度" disabled v-model="formData.latitude"></fui-input>
            <fui-button width="90%" height="48rpx" :size="28" v-if="tools.add" @click="handleMap">拾取坐标</fui-button>
          </div>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=260 :asterisk="tools.edit || tools.add" label="企业法人/负责人:">
          <fui-input :borderBottom="false" maxlength="100"
            v-model="formData.merchantLegalPerson"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="联系方式:">
          <fui-input :borderBottom="false" maxlength="11"
            v-model="formData.legalPhone"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=200 label="企业联系人:">
          <fui-input :borderBottom="false" maxlength="100"
            v-model="formData.merchantContactPerson"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 label="联系方式:">
          <fui-input :borderBottom="false" maxlength="11"
            v-model="formData.contactPhone"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 label="固定电话:">
          <div class="flex">
            <fui-input :bottomLeft="0" placeholder="请输入区号" v-model="formData.fixPhoneArea" minLength="3"
              maxlength="4"></fui-input>
            <span class="mx-[10px] font-bold">-</span>
            <fui-input :bottomLeft="0" placeholder="请输入座机号码" v-model="formData.fixPhoneNum" minLength="7"
              maxlength="8"></fui-input>
          </div>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=100 :asterisk="tools.edit || tools.add" label="行业:"
          @click="openSelect(2)">
          <span style="font-size: 16px;">{{ handleList(formData.industryList, 'dictName') }}</span>
          <fui-select :show="tools.showSelect" :options="tools.industryList" title="请选择行业" multiple isReverse
            closeColor="#6D758A" @confirm="onConfirm" @close="onClose" />
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="经营范围:">
          <fui-input :borderBottom="false" maxlength="200"
            v-model="formData.businessRange"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 label="主营业务:">
          <fui-input :borderBottom="false" maxlength="200"
            v-model="formData.mainBusiness"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=220 :asterisk="tools.edit || tools.add" label="重点监管领域:"
          @click="openCascaser">
          <span style="font-size: 16px">{{ handleList(tools.adminSupervisionList, 'supervisionAreasName') }}</span>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="所属网格:" @click="openGrid">
          <span style="font-size: 16px">{{ formData?.gridName }}</span>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160  v-if="tools.edit" :asterisk="tools.edit" label="商户状态:"
          @click="openSelect(1, 'statusList', formData?.merchantStatus)">
          <span style="font-size: 16px;">{{ handleText(formData?.merchantStatus, 'statusList') }}</span>
          <fui-select :show="tools.showSelectStatus" :options="tools.statusList" title="请选择商户状态" isReverse
            closeColor="#6D758A" @confirm="(e) => onConfirmRadio(e, 'merchantStatus')"
            @close="tools.showSelectStatus = false" />
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="商户类型:"
          @click="openSelect(1, 'typeList', formData?.merchantType)">
          <span style="font-size: 16px;">{{ handleText(formData?.merchantType, 'typeList') }}</span>
          <fui-select :show="tools.showSelectType" :options="tools.typeList" title="请选择商户类型" isReverse
            closeColor="#6D758A" @confirm="(e) => onConfirmRadio(e, 'merchantType')"
            @close="tools.showSelectType = false" />
        </fui-form-item>
        <fui-form-item borderColor="#fff" labelWidth=100 label="备注:">
          <fui-input :borderBottom="false" maxlength="200"
            v-model="formData.remark"></fui-input>
        </fui-form-item>
      </fui-form>
      <div class="btn-cell" v-if="!tools.edit && !tools.add">
        <fui-form-item label="检查记录" arrow @click="toDetail(1)" />
        <fui-form-item label="验收情况" arrow @click="toDetail(2)" />
        <fui-form-item label="自检记录" arrow @click="toDetail(3)" />
      </div>
    </div>
    <div class="bottom-btns">
      <fui-button radius="96rpx" v-if="!tools.edit && !tools.add" @click="startCheck">开始检查</fui-button>
      <fui-button radius="96rpx" v-else-if="tools.add" @click="saveEdit('add')">保存</fui-button>
      <fui-button radius="96rpx" v-else-if="tools.edit" @click="saveEdit('edit')">保存</fui-button>
    </div>
    <!-- <fui-safe-area></fui-safe-area> -->
    <fui-actionsheet :show="tools.show" :tips="tools.tips" :itemList="tools.list" @cancel="(tools.show = false)"
      @click="selectType" />
    <!-- 选择任务 -->
    <fui-bottom-popup :show="tools.showTask">
      <div class="popup-title">
        <span>选择任务</span>
        <fui-icon name="close" :size="48" @click="closePopup"></fui-icon>
      </div>
      <scroll-view scroll-y class="popup-body">
        <fui-empty v-if="tools.itemList.length == 0" title="暂无任务" style="padding-bottom: 20px"></fui-empty>
        <fui-list-cell v-else v-for="(item, index) in tools.itemList" :key="index" arrow style="position:relative"
          @click="selectTask(item)">
          <div class="popup-text">{{ item.taskName }}</div>
          <fui-tag text="继续检查" type="primary" v-if="item.crId" />
        </fui-list-cell>
      </scroll-view>
    </fui-bottom-popup>
    <fui-bottom-popup :show="tools.showGrid" @close="closeGrid">
      <view class="fui-scroll__wrap">
        <view class="text-center font-bold m-[12px] color-[#181818]" style="font-size: 16px">选择所属网格</view>
        <scroll-view scroll-y class="fui-scroll__view">
          <cascader :options="tools.gridOptions" @change="changeGrid" @complete="completeGrid"></cascader>
        </scroll-view>
        <view class="fui-icon__close" @tap="closeGrid">
          <fui-icon name="close" :size="48"></fui-icon>
        </view>
        <view class="p-[15px]">
          <fui-button radius="96rpx" @click="saveGrid">保存</fui-button>
        </view>
      </view>
    </fui-bottom-popup>
    <!-- 重点监管领域 级联 -->
    <fui-bottom-popup :show="tools.showCascader" @close="closeCascader">
      <view class="fui-scroll__wrap">
        <view class="text-center font-bold m-[12px] color-[#181818]" style="font-size: 16px">选择重点监管领域</view>
        <scroll-view scroll-y class="fui-scroll__view">
          <div class="cas-list px-[15px]">
            <fui-tag v-for="(item, index) in adminSupervisionListCopy" :key="item.supervisionAreasId"
              :text="item.supervisionAreasName" theme="light" @click="delCascader(item, index)">
              <fui-icon name="close" :size="32" color="#1D4AD4" class="ml-[8px]"></fui-icon>
            </fui-tag>
          </div>
          <cascader :options="tools.casCaderOptions" @complete="complete"></cascader>
        </scroll-view>
        <view class="fui-icon__close" @tap="closeCascader">
          <fui-icon name="close" :size="48"></fui-icon>
        </view>
        <view class="p-[15px]">
          <fui-button radius="96rpx" @click="saveCascader">保存</fui-button>
        </view>
      </view>
    </fui-bottom-popup>
  </div>
</template>

<script setup>
import { ref, toRef, reactive, onMounted, nextTick } from "vue";
import cascader from './components/cascader';
import { useRoute } from "vue-router";
import api from "./server/api.js";
import commonApi from '@/api/commonApi';
import { onLoad } from "@dcloudio/uni-app";

const route = useRoute();
const loading = ref(false);
const formData = ref({
  unifiedCreditCode: '',
  merchantAliasName: '',
  merchantName: '',
  registerAddress: '',
  businessAddress: '',
  merchantLegalPerson: '',
  legalPhone: '',
  merchantContactPerson: '',
  contactPhone: '',
  fileList: [],
  longitude: '', //120.31205187390617
  latitude: '', //31.4907894002759
  fixPhoneArea: '',
  fixPhoneNum: '',
  businessRange: '',
  mainBusiness: '',
  gridName: '',
  merchantStatus: '1602934097288695809',
  merchantType: '',
  industryList: '',
  remark: ''
});
const validateName = (value) => {
  let flag = true;
  let regexStr = /^[0-9a-zA-Z一-龟-(：，。；：、-（）,.【】;:-@#￥%！~*&？)]*$/
  if (!regexStr.test(value)) {
    flag = false;
  }
  return flag;
}
const validateAddress = (value) => {
  let flag = true;
  const text = /^[\u4e00-\u9fa5\-\（）(.)0-9a-zA-Z]+$/;
  if (!text.test(value)) {
    flag = false;
  }
  return flag;
}
const validateAddressAddS = (value) => {
  let flag = true;
  const text = /^[\u4e00-\u9fa5\-\（）(.)0-9a-zA-Z\s]+$/;
  if (!text.test(value)) {
    flag = false;
  }
  return flag;
}
const validateCode = (value) => {
  let flag = true;
  const text = /^[A-Z0-9]+$/;
  if (!text.test(value)) {
    flag = false;
  } else {
    let arr = ['I', 'O', 'Z', 'S', 'V'];
    arr.forEach(it => {
      if (value.search(it) != -1) {
        flag = false;
      }
    })
  }
  return flag;
}
const rules = reactive([
  {
    name: "unifiedCreditCode", rule: ["required", "isEnOrNo", "maxLength: 18"], msg: ["请输入统一社会信用代码", "统一社会信用代码仅允许输入大写字母与数字组合", "统一社会信用代码输入最大长度为18"],
    validator: [{ msg: '请输入大写英文与数字组合且不包含（I,O,Z,S,V）', method: validateCode }]
  },
  {
    name: "merchantAliasName", rule: ["required", "maxLength: 100"], msg: ["请输入店招名", "店招名最大输入长度为100"],
    validator: [{ msg: '店招名不可输入特殊符号', method: validateName }]
  },
  {
    name: "merchantName", rule: ["required", "maxLength: 100"], msg: ["请输入企业名", "企业名最大输入长度为100"],
    validator: [{ msg: '企业名不可输入特殊符号', method: validateName }]
  },

  {
    name: "registerAddress", rule: ["required", "maxLength: 100"], msg: ["请输入注册地址", "注册地址最大输入长度为100"],
    validator: [{ msg: '注册地址不可输入特殊符号', method: validateAddressAddS }]
  },
  {
    name: "businessAddress", rule: ["required", "maxLength: 100"], msg: ["请输入经营地址", "经营地址最大输入长度为100"],
    validator: [{ msg: '经营地址不可输入特殊符号', method: validateAddressAddS }]
  },
  // {
  //   name: "longitude", rule: ["required"], msg: ["请拾取坐标"],
  // },
  {
    name: "merchantLegalPerson", rule: ["required", "maxLength: 100"], msg: ["请输入企业法人/负责人", "企业法人/负责人最大输入长度为100"],
    validator: [{ msg: '企业法人/负责人不可输入特殊符号', method: validateAddress }]
  },
  { name: "legalPhone", rule: ["required", "isMobile"], msg: ["请输入企业法人/负责人联系方式", "请输入正确格式的联系方式"] },
  {
    name: "merchantContactPerson", rule: ["maxLength: 100"], msg: ["企业联系人最大输入长度为100"],
    validator: [{ msg: '企业联系人不可输入特殊符号', method: validateName }]
  },
  { name: "contactPhone", rule: ["isMobile"], msg: ["请输入正确格式的联系方式"], },
  { name: "fixPhoneArea", rule: ["isNumber", "minLength: 3"], msg: ["请输入正确格式的区号", "请输入正确格式的区号"], },
  { name: "fixPhoneNum", rule: ["isNumber", "minLength: 7"], msg: ["请输入正确格式的座机号码", "请输入正确格式的区号"], },
  { name: "industryList", rule: ["required"], msg: ["请选择行业"], },
  {
    name: "businessRange", rule: ["required", "maxLength: 200"], msg: ["请输入经营范围", "经营范围最大输入长度为200"],
    validator: [{ msg: '经营范围不可输入特殊符号', method: validateName }]
  },
  { name: "gridName", rule: ["required"], msg: ["请选择所属网格"] },
  {
    name: "mainBusiness", rule: ["maxLength: 200"], msg: ["主营业务最大输入长度为200"],
    validator: [{ msg: '主营业务不可输入特殊符号', method: validateName }]
  },
  { name: "merchantStatus", rule: ["required"], msg: ["请选择商户状态"], },
  { name: "merchantType", rule: ["required"], msg: ["请选择商户类型"], },
])
const gridInfos = ref({});
const tools = reactive({
  edit: false,
  add: false,
  show: false,
  isCancel: false,
  showTask: false,
  showCascader: false,
  editId: '',
  checkType: 1, // 1 检查表检查 2 拍照检查
  OCRType: '1',
  showUpload: false,
  list: [
    { text: '检查表检查' },
    { text: '拍照检查' }
  ],
  tips: '选择任务',
  itemList: [],
  showSelect: false,
  showSelectStatus: false,
  showSelectType: false,
  casCaderOptions: [],
  gridOptions: [],
  adminSupervisionList: [],
  industryList: [],
  statusList: [],
  typeList: [],
  OCRList: [
    { id: 1, text: '上传横版营业执照', checked: true },
    { id: 2, text: '上传竖版营业执照' }
  ],
  uploadUrl: window.location.origin + "/tvrjet-edz-supervision-system-custom-app/ocr/businessLicense",
});
const adminSupervisionListCopy = ref([]);
const personRoles = ref({});
const formRef = ref(null);
const refUpload = ref(null);

onLoad(() => {
  uni.$on('mapObj', (data) => {
    if (data?.latitude && data?.longitude) {
      formData.value.latitude = data?.latitude;
      formData.value.longitude = data?.longitude;
    }
  })
})

onMounted(() => {
  if (window.ls) {
    window.ls.location({
      type: 'GPS'
    }, function (res) {
      if (res.code === 200) {
        //成功
        let str = res.data.province + res.data.street + res.data.number;
        // let watermarkStr = `&lat=${res.data.latitude}&lon=${res.data.longitude}`
        tools.uploadUrl = tools.uploadUrl + 'ByWatermark?watermarkStr=' + str;
      }
    })
  }
  if (route.query?.type == 'add') {
    tools.add = true;
    tools.edit = false;
  }
  if (route.query?.inspectionRecordId) {
    tools.editId = route.query?.inspectionRecordId;
  }
  getDicList("Merchant", "statusList"); // 商户状态
  getDicList("shlx", "typeList"); // 商户类型
  getDicList("industry", "industryList"); // 行业
  // getTaskList();
  getSupervise();
  getAllTree();
  // personRoles.value = JSON.parse(uni.getStorageSync('personRoles')) || {};
  if (route.query?.type == 'add' && !route.query?.inspectionRecordId) {
    // if (uni.getStorageSync('gridInfos')) {
    //   gridInfos.value = JSON.parse(uni.getStorageSync('gridInfos'));
    // } else {
    //   gridInfos.value = {}
    // }
    formData.value.adminSupervisionList = []
    tools.adminSupervisionListCopy = []
    adminSupervisionListCopy.value = []
    // if (personRoles.value.isCheckPersion && !personRoles.value.isSuperAdmin) {
    //   formData.value.regionGridId = gridInfos.value?.id;
    //   formData.value.gridName = gridInfos.value?.gridFullName;
    // }
  } else {
    queryDetail()
  }
});
const queryDetail = async () => {
  let res = await api.getDetail({ merchantId: tools.editId })
  if (res?.code && res?.code == "00000") {
    formData.value = res?.data || {};
    formData.value.regionGridId = formData.value?.gridInfo?.id;
    tools.adminSupervisionList = res?.data?.adminSupervisionList
    adminSupervisionListCopy.value = formData.value.adminSupervisionList;
    formData.value.gridName = formData.value?.gridInfo?.gridFullName;
    if (formData.value?.industryList) {
      formData.value.industryIdList = [];
      formData.value?.industryList?.forEach(item => {
        formData.value.industryIdList.push(item.dictId);
      })
    }
  }
}
// 获取重点监管领域
const getSupervise = async () => {
  let res = await commonApi.getAdminSupervisionList();
  if (res?.code && res?.code == "00000") {
    tools.casCaderOptions = replaceParam(res?.data);
  }
};
// 获取所属网格
const getAllTree = async () => {
  let res = await commonApi.getAllTree();
  if (res?.code && res?.code == "00000") {
    tools.gridOptions = disabledOrg(res?.data);
  }
};
// 区域下不可绑定
const disabledOrg = (list) => {
  for (const item of list) {
    // type == `1` ? '区域':'网格'
    item.text = item?.name;
    item.value = item?.id;
    if (item.type == 1) {
      item.disabled = true;
    }
    if (item.children && item.children.length > 0) {
      disabledOrg(item.children);
    }
  }
  return list
}
const replaceParam = (arr) => {
  arr?.forEach(it => {
    it.text = it?.tagName;
    it.value = it?.id;
    if (it.children) {
      replaceParam(it.children)
    }
  })
  return arr
}
// 获取字典
const getDicList = async (code, list) => {
  let res = await commonApi.getDicList({ dictTypeCode: code });
  if (res?.code && res?.code == '00000') {
    if (code == "industry") tools.industryList = [];
    res?.data?.map(it => {
      it.id = it.dictId;
      it.text = it.dictName;
      it.checked = false;
    })
    tools[list] = res?.data ?? [];
  }
}
const toDetail = (type) => {
  if (type == 1) { // 检查记录
    uni.navigateTo({
      url: `/pages/checkRecord/index?miId=${formData.value?.id}`
    })
  } else if (type == 2) { // 验收记录
    getApp().globalData.companyId = formData.value?.id;
    uni.switchTab({
      url: `/pages/homePage/accept/index`
    })
  } else if (type == 3) { // 验收记录
    uni.navigateTo({
      url: `/pages/selfRecords/index?companyId=${formData.value?.id}`
    })
  }
};
const handleList = (val, type) => {
  if (val && val?.length > 0) {
    let list = val?.map((it) => {
      return it?.[type]
    });
    return list.join(",");
  } else {
    return '';
  }
}
const handleText = (val, list) => {
  if (val) {
    let obj = tools[list]?.find(it => it.dictId == val)
    return obj?.dictName;
  } else {
    return "";
  }
}
const openSelect = (type, list, id) => {
  // type: 1单选 2多选
  if (!tools.edit && !tools.add) return;
  if (type == 2) {
    tools.industryList?.forEach(item => {
      formData.value.industryIdList?.forEach(it => {
        if (item.dictId == it) {
          item.checked = true;
        }
      })
    })
    tools.showSelect = true
  } else {
    tools[list]?.forEach(item => {
      if (item.dictId == id) {
        item.checked = true;
      }
    })
    if (list == 'statusList') {
      tools.showSelectStatus = true
    } else {
      tools.showSelectType = true
    }
  }
}
const onConfirm = (e) => {
  formData.value.industryIdList = [];
  e?.options?.forEach(item => {
    formData.value.industryIdList.push(item?.dictId);
  })
  formData.value.industryList = e?.options;
  onClose()
}
const onConfirmRadio = (e, type) => {
  formData.value[type] = e?.options?.dictId;
  if (type == 'merchantStatus') {
    tools.showSelectStatus = false
  } else {
    tools.showSelectType = false
  }
}
//关闭组件
const onClose = () => {
  tools.showSelect = false
}
// 获取检查任务列表
const getTaskList = async () => {
  let params = {
    pageSize: 999,
    pageNo: 1,
    companyId: tools.editId
  }
  let res = await api.getMerchantTaskList(params);
  if (res?.code == '00000') {
    tools.itemList = res?.data ?? []
  }
};
// 显示检查方式
const startCheck = () => {
  // getTaskList();
  tools.show = true;
};
// 选择检查方式
const selectType = (e) => {
  tools.checkType = e.index + 1;
  tools.show = false;
  tools.showTask = true;
}
// 选择检查任务
const selectTask = (e) => {
  console.log(e);
  tools.showTask = false;
  uni.navigateTo({
    url: `/pages/checkList/index?taskId=${e.id}&checkType=${tools.checkType}&companyId=${route.query.inspectionRecordId}`
  })
};
const closePopup = () => {
  tools.showTask = false;
};
const openCascaser = () => {
  if (!tools.edit && !tools.add) return;
  tools.showCascader = true;
};
const closeCascader = () => {
  tools.showCascader = false;
};
const delCascader = (e, i) => {
  adminSupervisionListCopy.value.splice(i, 1)
};
// 级联选择完成
const complete = (e) => {
  let id = e?.value[e.value?.length - 1];
  let name = e?.text?.join(' / ');
  let flag = adminSupervisionListCopy.value?.find(it => it.supervisionAreasId == id) ?? false
  if (flag) {
    // adminSupervisionListCopy.value = adminSupervisionListCopy.value.filter(it => it.supervisionAreasId != flag.supervisionAreasId)  // 把这个数组变成去除掉id相同的这一项
  } else {
    adminSupervisionListCopy.value?.push({
      supervisionAreasId: id,
      supervisionAreasName: name,
    })
  }
}
const completeGrid = (e) => {
  tools.gridName = e?.text?.join(' / ');
}
const changeGrid = (e) => {
  tools.gridId = e?.value;
  tools.gridName = e?.text;
  tools.gridType = e?.type;
}
const saveCascader = () => {
  tools.adminSupervisionList = adminSupervisionListCopy.value;
  tools.showCascader = false;
}
const saveGrid = () => {
  if (tools.gridType == 1) {
    return uni.showToast({
      title: '当前选择项为区域，请选择网格后保存！',
      icon: 'none'
    })
  }
  formData.value.regionGridId = tools.gridId;
  formData.value.gridName = tools.gridName;
  tools.showGrid = false;
}
const openGrid = () => {
  if (!tools.add) return;
  tools.showGrid = true;
}
const closeGrid = () => {
  tools.showGrid = false;
}
const openOCR = () => {
  formData.value.fileList = [];
  tools.showUpload = true;
}
const closeOCR = () => {
  tools.showOCR = false
}
const onConfirmOCR = (e) => {
  tools.OCRType = e?.options?.id;
  refUpload.value.start();
  tools.showOCR = false;
}
//上传成功触发
const successUpload = (e) => {
  if (!tools.add && !tools.edit) return;
  let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
  formData.value.fileList = [];
  tools.showUpload = false;
  if (res?.code == '00000' && res?.data) {
    formData.value = res?.data || {}
  } else {
    return uni.showToast({
      title: res?.message,
      icon: 'none',
    })
  }
};
//图片选择、上传完成、删除时触发
const completeUpload = (e) => {
  if (!tools.add && !tools.edit) return;
  // if (e?.action == 'delete') {
  //   formData.value.fileList = e?.urls;
  //   let arr = formData.value.newFileList.filter((item) => formData.value.fileList.includes(item.fileUrl))
  //   formData.value.newFileList = arr;
  // }
};
// 点击编辑按钮
const editClick = () => {
  tools.edit = true;
};
const handleMap = () => {
  if (formData.value?.longitude && formData.value?.latitude) {
    uni.navigateTo({
      url: "/pages/map/index?longitude=" + formData.value.longitude + '&latitude=' + formData.value.latitude,
    });
  } else {
    uni.navigateTo({
      url: "/pages/map/index",
    });
  }
}
// 保存编辑/新增
const saveEdit = (type) => {
  formRef.value.validator(formData.value, rules).then(res => {
    if (res.isPassed) {
      if (tools?.adminSupervisionList?.length < 1) {
        return uni.showToast({
          title: '请选择重点监管领域！',
          icon: 'none',
        })
      }
      formData.value.adminSupervisionList = tools.adminSupervisionList
      for (const item in formData.value) {
        if (!formData.value[item]) {
          delete formData.value[item]
        }
      }
      let params = formData.value;
      let apiName = 'updateMerchant'
      if (type == 'add') {
        delete params.id;
        apiName = 'addMerchant'
      }
      api[apiName](params).then(res => {
        if (res?.code && res?.code == '00000') {
          tools.edit = false;
          if (type == 'add') {
            tools.editId = res?.data;
            tools.add = false;
            tools.edit = false;
            uni.navigateBack();
          }
        } else {
          return uni.showToast({
            title: res?.message || '操作失败',
            icon: 'none',
          })
        }
      }).catch(error => {
        console.log(error)
      })
    }
  }).catch(err => {
    console.log(err)
  })
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #F4F5F7;
  height: 100vh;
  overflow: auto !important;
}

.page-btn-body {
  padding: 15px 15px 0;

  :deep(.fui-input__wrap) {
    padding: 0 !important;
  }

  :deep(.fui-textarea__wrap) {
    .fui-textarea__border-top {
      display: none;
    }
  }
}

.btn-cell {
  :deep(.fui-form__item-wrap) {
    border-radius: 4px !important;
    margin: 10px 0 !important;
  }
}

.popup-title {
  padding: 36rpx 26rpx;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: wrap;

  span {
    flex: 1;
    text-align: center;
    font-size: 36rpx;
    font-weight: 500;
    color: #333;
    width: calc((100% - 52rpx) / 3); // 这里的10px = (分布个数3-1)*间
  }
}

.bottom-btns{
  padding: 10px 15px 30px;
}

.popup-body {
  max-height: 30vh;
  overflow: auto !important;

  .popup-text {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-size: 32rpx;
  }

  :deep(.fui-tag__wrap) {
    padding: 4rpx !important;
    position: absolute !important;
    right: 15px;
    top: 0px;
  }
}

.btn-text {
  background: #fff;
  color: #1D4AD4;
  text-align: right;
  padding: 15px 15px 0 0;
  font-size: 14px;
}

.cas-list :deep(.fui-tag__wrap) {
  padding: 8px !important;
  margin: 4px 8px 4px 0 !important;
}

.fui-scroll__wrap {
  position: relative;
}

.fui-icon__close {
  position: absolute;
  top: 0px;
  right: 12px;
}

.fui-scroll__view {
  width: 100%;
  height: 30vh;
}
:deep(uni-text) {
  white-space: nowrap !important;
}
</style>