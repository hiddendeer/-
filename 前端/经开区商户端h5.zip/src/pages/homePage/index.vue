<template>
  <view class="main">
    <view class="body">
      <view class="grid">
        <view class="grid_cell" v-for="(item, index) in gridList" :key="index">
          <view class="grid_cell_top">
            <span :style="'color:' + item.color">
              {{ item.lable }}
            </span>
            家
          </view>
          <view class="grid_cell_bottom" @click="goUrl(item.url)">
            {{ item.value }}
            <fui-icon size="26" name="roundright"></fui-icon>
          </view>
        </view>
      </view>
      <view class="cneter-button">
        <fui-button radius="50rpx" @click="goBeginCheck">开始检查</fui-button>
      </view>
      <view class="myBacklog">
        <view class="myBacklog_title"> 我的待办 </view>
        <view class="myBacklog_table">
          <fui-table
            :full="true"
            :border="false"
            :horBorder="false"
            :gap="30"
            headerBgColor="#E7EAFF"
            :itemList="tableData"
            :header="headerData"
            @click="goFinishCheckDetail"
          ></fui-table>
        </view>
      </view>
    </view>
    <fui-toast ref="toast"></fui-toast>
  </view>
</template>

<script>
import { mapState } from 'vuex'
import { queryRecordList, queryHomeRecord } from '@/api/authApi.js'
export default {
  computed: {
    ...mapState({
      userId: state => state.auth.userData.userId
    })
  },
  data() {
    return {
      gridList: [
        {
          lable: '0',
          value: '检查记录',
          color: '#465CFF',
          url: '/pages/homePage/logCheck/index'
        },
        {
          lable: '0',
          value: '待整改',
          color: '#FF8021',
          url: '/pages/homePage/awaitCheck/index'
        },
        {
          lable: '0',
          value: '已整改',
          color: '#2BAD7E',
          url: '/pages/homePage/finishCheck/index'
        }
      ],
      tableData: [],
      //基础使用 表头
      headerData: [
        {
          prop: 'merchantAliasName',
          width: 160,
          label: '店招名'
        },
        {
          prop: 'merchantName',
          width: 160,
          label: '企业名'
        },
        {
          prop: 'createTime',
          width: 110,
          label: '暂存时间'
        },
        {
          label: '操作',
          type: 3,
          width: 100,
          buttons: [
            {
              text: '继续检查',
              color: '#465CFF',
              // size: 30,
              fontWeight: 600
            }
          ]
        }
      ]
    }
  },

  onLoad(options) {},
  onShow() {
    // this.getQueryRecordList()
    // this.getQueryHomeRecord()
  },
  onLaunch() {},
  methods: {
    async getQueryRecordList() {
      let { data } = await queryRecordList({
        examineStatus: 'DRAFT',
        createUser: this.userId
      })
      const res = await queryRecordList({
        examineStatus: 'DRAFT',
        createUser: this.userId
      })
      console.log(res);
      this.tableData = data
      this.tableData.forEach(item => {
        if (item.createTime != '') {
          item.createTime = item.createTime.split(' ')[0]
        } else {
          item.createTime = '-'
        }
      })
    },
    async getQueryHomeRecord() {
      let { data } = await queryHomeRecord({
        createUser: this.userId
      })
      this.gridList[0].lable = data.inspectionRecord || '0'
      this.gridList[1].lable = data.unaccepted || '0'
      this.gridList[2].lable = data.accepted || '0'
    },
    goFinishCheckDetail(e) {
      uni.navigateTo({
        url: `/pages/homePage/beginCheck/startCheck?inspectionRecordId=${e.item.inspectionRecordId}`
      })
    },
    goBeginCheck() {
      uni.navigateTo({
        url: '/pages/homePage/newCheck/index'
      })
    },
    goUrl(url) {
      uni.navigateTo({
        url: url
      })
    }
  },
  created() {},
  mounted() {}
}
</script>
<style lang="scss" scoped>
.main {
  height: 100vh;
  /* #ifdef H5*/
  height: calc(100vh - 88rpx - 50px) !important;
  /* #endif */
  width: 100vw;
  position: relative;
  display: flex;
  background: #fff;
  .body {
    width: 100%;
    height: 100%;
    padding: 0 30rpx;
    overflow: auto;
    .grid {
      background: #fff;
      margin: 40rpx 0;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-column-gap: 40rpx;
      &_cell {
        border-radius: 30rpx;
        padding: 30rpx 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
        &_top {
          color: #999999;
          font-size: 24rpx;
          padding-bottom: 20rpx;
          span {
            font-weight: bold;
            font-size: 64rpx;
            overflow: hidden;
            white-space: normal;
            word-wrap: break-word;
            word-break: break-all;
            text-overflow: ellipsis;
          }
        }
        &_bottom {
          color: #333333;
          font-size: 26rpx;
        }
      }
    }
    .cneter-button {
      padding: 60rpx 50rpx 80rpx 50rpx;
      :deep(.fui-button) {
        box-shadow: 0rpx 6rpx 16rpx 0rpx rgba(70, 92, 255, 0.5);
      }
    }
    .myBacklog {
      padding-bottom: 200rpx;
      &_title {
        font-weight: 500;
        font-size: 38rpx;
      }
      &_table {
        overflow: auto;
        margin-top: 30rpx;
        border-radius: 20rpx;
        box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
      }
    }
  }
}
</style>
