<template>
  <view class="page finish-detail-page">
    <view class="firstTabDate">
      <view
        class="firstTabDate_onceTab"
        v-for="(item, index) in checkItemList"
        :key="index"
        @click="checkCurrent(index, 'firstCurrent')"
      >
        <text :class="{ active: firstCurrent == index }">
          {{ item.checkSpotName }}
        </text>
      </view>
    </view>

    <view
      v-if="
        checkItemList[firstCurrent] &&
        checkItemList[firstCurrent].hidden &&
        checkItemList[firstCurrent].hidden.length > 0
      "
    >
      <view class="secondTabDate">
        <view
          class="secondTabDate_onceTab"
          :class="{ active: secondCurrent == index }"
          v-for="(item, index) in checkItemList[firstCurrent].hidden"
          :key="index"
          @click="checkCurrent(index, 'secondCurrent')"
        >
          <text> 隐患{{ toChinesNum(index + 1) }} </text>
        </view>
      </view>

      <view class="bottomDate">
        <view class="onceDate">
          <view class="onceDate_title">隐患图片: </view>
          <PreviewImage
            :imgList="
              checkItemList[firstCurrent].hidden[secondCurrent].hiddenImageUrls
            "
          />
        </view>
        <view class="onceDate">
          <view class="onceDate_title">隐患描述: </view>
          <view class="onceDate_detail">
            {{
              checkItemList[firstCurrent].hidden[secondCurrent].hiddenDesc ||
              '-'
            }}
          </view>
        </view>
        <view class="onceDate">
          <view class="onceDate_title">整改建议: </view>
          <view class="onceDate_detail">
            {{
              checkItemList[firstCurrent].hidden[secondCurrent]
                .rectificationSuggestions || '-'
            }}
          </view>
        </view>
        <view class="onceDate">
          <view class="onceDate_title">法律法规: </view>
          <view class="onceDate_detail">
            {{
              checkItemList[firstCurrent].hidden[secondCurrent]
                .lawsRegulations || '-'
            }}
          </view>
        </view>
        <view class="onceDate">
          <view class="onceDate_title">整改图片: </view>
          <PreviewImage
            :imgList="
              checkItemList[firstCurrent].hidden[secondCurrent]
                .rectificationImageUrls
            "
          />
        </view>
      </view>
    </view>
    <fui-empty v-else></fui-empty>
  </view>
</template>

<script>
import { queryListByRecord } from '@/api/awaitCheck.js'
import PreviewImage from '@/components/preview-image/index.vue'
export default {
  components: {
    PreviewImage
  },
  data() {
    return {
      show: false,
      firstCurrent: 0,
      secondCurrent: 0,
      recordId: '',
      checkItemList: []
    }
  },
  computed: {},

  onLoad(options) {
    if (options.inspectionRecordId) {
      this.recordId = options.inspectionRecordId
      this.getQueryListByRecord()
    } else {
      uni.showToast({
        title: '未获取到店铺ID',
        icon: 'none'
      })
      uni.navigateBack()
    }
  },
  onShow() {},
  onLaunch() {},
  methods: {
    //获取暂存数据
    async getQueryListByRecord() {
      let { data } = await queryListByRecord({
        supervisionInspectionRecordId: this.recordId,
        acceptanceStatus: true
      })
      this.checkItemList = data
    },
    checkCurrent(index, val) {
      this[val] = index
      if (val == 'firstCurrent') {
        this.secondCurrent = 0
      }
    },
    // 数字转汉字
    toChinesNum(num) {
      let changeNum = [
        '零',
        '一',
        '二',
        '三',
        '四',
        '五',
        '六',
        '七',
        '八',
        '九'
      ]
      let unit = ['', '十', '百', '千', '万']
      num = parseInt(num)
      let getWan = temp => {
        let strArr = temp.toString().split('').reverse()
        let newNum = ''
        let newArr = []
        strArr.forEach((item, index) => {
          newArr.unshift(
            item === '0' ? changeNum[item] : changeNum[item] + unit[index]
          )
        })
        let numArr = []
        newArr.forEach((m, n) => {
          if (m !== '零') numArr.push(n)
        })
        if (newArr.length > 1) {
          newArr.forEach((m, n) => {
            if (newArr[newArr.length - 1] === '零') {
              if (n <= numArr[numArr.length - 1]) {
                newNum += m
              }
            } else {
              newNum += m
            }
          })
        } else {
          newNum = newArr[0]
        }
        if (newNum == '一十') return '十'
        if (newNum.length == 3) {
          return newNum.replace('一十', '十')
        } else {
          return newNum
        }
      }
      let overWan = Math.floor(num / 10000)
      let noWan = num % 10000
      if (noWan.toString().length < 4) {
        noWan = '0' + noWan
      }
      return overWan ? getWan(overWan) + '万' + getWan(noWan) : getWan(num)
    }
  }
}
</script>
<style lang="scss" scoped>
.finish-detail-page {
  width: 100vw;
  position: relative;
  background: #fff;
  .firstTabDate {
    width: 100%;
    height: 100rpx;
    display: flex;
    overflow-x: auto;
    font-size: 34rpx;
    font-weight: bold;
    &_onceTab {
      flex: 0 0 auto;
      line-height: 60rpx;
      background: #fff;
      padding: 20rpx 50rpx;
    }
    .active {
      display: flex;
      flex-direction: column;
      color: #465cff;
    }
    .active::after {
      content: '';
      width: 100%;
      height: 4rpx;
      background: #465cff;
    }
  }
  .secondTabDate {
    width: 100%;
    height: 100rpx;
    display: flex;
    overflow-x: auto;
    font-size: 28rpx;
    font-weight: bold;
    background: #f1f1f1;
    &_onceTab {
      flex: 0 0 auto;
      line-height: 36rpx;
      background: #fff;
      margin: 20rpx 25rpx;
      padding: 10rpx 30rpx;
      border-radius: 8rpx;
      border: 1px solid #dddddd;
    }
    .active {
      color: #465cff;
      border: 1px solid #465cff;
    }
  }
  .bottomDate {
    overflow: auto;
    height: calc(100% - 200rpx);
    padding: 0 30rpx;
    .onceDate {
      margin-bottom: 60rpx;
      &_title {
        color: #333333;
        margin: 20rpx 0;
        font-size: 32rpx;
        font-weight: bold;
        margin-bottom: 20rpx;
      }
      &_detail {
        color: #555555;
        font-size: 30rpx;
        overflow: hidden;
        white-space: normal;
        word-wrap: break-word;
        word-break: break-all;
        text-overflow: ellipsis;
      }
      &:last-child {
        margin-bottom: 300rpx;
      }
    }
  }
}
</style>
