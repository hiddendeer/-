<template>
  <view class="page select-merchant-page">
    <view class="topSearch">
      <view class="searchInput">
        <fui-search-bar
          height="88"
          radius="50"
          background="#f1f1f1"
          :isLeft="true"
          :cancel="false"
          placeholder="请输入企业名/店招名进行模糊搜索"
          @search="search"
          @clear="getAllMerchantLists()"
        ></fui-search-bar>
      </view>
    </view>
    <view class="shopList">
      <view class="topButton">
        <fui-button radius="50rpx" @click="goCheckInformation"
          >检查须知</fui-button
        >
      </view>
      <view class="shopCard" v-for="(item, index) in shopList" :key="index">
        <view class="shopCard_top">
          <view class="line shopName">{{ item.merchantAliasName || '-' }}</view>
          <view class="line">商户名:{{ item.merchantName || '-' }}</view>
          <view class="line">行政区域:{{ item.merchantRegion || '-' }}</view>
          <view class="line">地址:{{ item.merchantAddress || '-' }}</view>
        </view>
        <view class="shopCard_bottom">
          <view v-for="(bItem, btnIndex) in buttonLsit" :key="btnIndex">
            <fui-button
              size="26"
              height="60rpx"
              radius="50rpx"
              borderColor="#465CFF"
              color="#465CFF"
              background="#FFFFFF"
              @click="goItemUrl(bItem.url, item.merchantId)"
            >
              {{ bItem.buttonName }}
            </fui-button>
          </view>
        </view>
      </view>
      <fui-empty v-if="shopList.length == 0"></fui-empty>
    </view>
  </view>
</template>

<script>
import { getMerchantList } from '@/api/beginCheckApi'
export default {
  data() {
    return {
      shopList: [],
      buttonLsit: [
        {
          buttonName: '开始检查',
          url: '/pages/homePage/beginCheck/startCheck'
        },
        {
          buttonName: '检查记录',
          url: '/pages/homePage/logCheck/shopCheckLog'
        },
        {
          buttonName: '待整改项',
          url: '/pages/homePage/awaitCheck/awaitCheckDetail/index'
        }
      ]
    }
  },

  onLoad(options) {
    this.getAllMerchantLists()
  },
  onLaunch() {},
  methods: {
    //搜索框点击搜索触发
    search(e) {
      this.getAllMerchantLists(e.detail.value)
    },
    //获取全量列表
    async getAllMerchantLists(val) {
      let param = {
        merchantName: val || ''
      }
      let { data } = await getMerchantList(param)
      this.shopList = data
    },
    //跳转到检查须知
    goCheckInformation() {
      uni.navigateTo({
        url: '/pages/homePage/beginCheck/checkInformation'
      })
    },
    //跳转页面
    goItemUrl(url, merchantId) {
      uni.navigateTo({
        url: `${url}?merchantId=${merchantId}`
      })
    }
  },
  created() {},
  mounted() {}
}
</script>
<style lang="scss" scoped>
.select-merchant-page {
  width: 100vw;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  .topSearch {
    margin: 20rpx 30rpx;
    display: flex;
    align-items: center;
    background: #fff;
    border-radius: 50rpx;
    .searchInput {
      flex: 1;
      :deep(.fui-search__bar-wrap) {
        border-radius: 50rpx !important;
        background: #fff !important;
        padding: 0 !important;
        .fui-search__bar-btn {
          font-size: 30rpx !important;
          border: 0.5rpx solid #465cff;
          border-radius: 50rpx;
          height: 79rpx;
          width: 120rpx;
          box-sizing: initial;
          text-align: center;
          line-height: 76rpx;
        }
      }
    }
  }
  .topButton {
    margin: 30rpx 40rpx;
    :deep(.fui-button) {
      box-shadow: 0rpx 6rpx 16rpx 0rpx rgba(70, 92, 255, 0.5);
    }
  }
  .shopList {
    overflow: auto;
    flex: 1;
    display: flex;
    flex-direction: column;
    align-content: center;
    .shopCard {
      border-radius: 20rpx;
      margin: 15rpx 30rpx;
      padding: 20rpx;
      background: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
      &_top {
        flex: 1;
        margin-left: 20rpx;
        .line {
          line-height: 1.5;
          color: #555555;
          font-size: 30rpx;
          margin: 10rpx 0;
          overflow: hidden;
          white-space: normal;
          word-wrap: break-word;
          word-break: break-all;
          text-overflow: ellipsis;
        }
        .shopName {
          font-weight: bold;
          color: #333333;
          font-size: 36rpx;
        }
      }
      &_bottom {
        display: flex;
        justify-content: center;
        :deep(.fui-button__wrap) {
          width: 180rpx !important;
          margin: 15rpx !important;
        }
      }
      &:last-child {
        margin-bottom: 200rpx;
      }
    }
  }
}
</style>
