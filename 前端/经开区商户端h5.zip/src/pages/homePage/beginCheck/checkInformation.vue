<template>
  <view class="page check-information-page">
    <view class="date">
      <view class="date_title"> 基本要求： </view>
      <view> 1、尺寸 </view>
      <view>2、时间 </view>
      <view>3、焦距（拍照时要保持镜头稳定） </view>
      <view>
        4、布局（尽量将隐患重点信息置于画面中央，布局应尽量反应出“隐患在整体的位置”等信息，以便审核者更好解读）
      </view>
      <view>5、拍摄顺序（由远及近；先外后内；先整体后局部；先局部后细节）</view>
      <view>6、数量（以精简、准确的照片反映充分的隐患信息）</view>
    </view>
    <view class="bottom-btn">
      <fui-button @click="back" radius="50rpx">我已阅读了解清楚</fui-button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {}
  },
  computed: {},

  onLoad(options) {},
  onShow() {},
  onLaunch() {},
  methods: {
    back() {
      uni.navigateBack()
    }
  },
  created() {},
  mounted() {}
}
</script>
<style lang="scss" scoped>
.check-information-page {
  width: 100vw;
  position: relative;
  font-size: 32rpx;
  background: #fff;
  .date {
    padding: 30rpx;
    line-height: 2;
    color: #555555;
    &_title {
      font-weight: bold;
      line-height: 2.5;
      color: #333333;
    }
  }
  .bottom-btn {
    height: 140rpx;
    width: 100%;
    bottom: 0rpx;
    left: 0;
    position: absolute;
    :deep(.fui-button) {
      width: 80% !important;
      box-shadow: 0rpx 6rpx 16rpx 0rpx rgba(70, 92, 255, 0.5);
    }
  }
}
</style>
