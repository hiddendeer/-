<template>
  <view class="page start-check-page">
    <view class="top-btn">
      <fui-button height="88rpx" radius="50rpx" @click="showNewCheck = true"
        >新增检查点</fui-button
      >
    </view>
    <view class="checkDate">
      <view
        class="onceDate"
        v-for="(item, index) in checkItemList"
        :key="index"
      >
        <view class="onceDate_title">
          <view class="onceDate_title_name">
            {{ item.checkSpotName }}
          </view>
          <view v-if="item.change" class="onceDate_title_right">
            <fui-icon
              size="46"
              name="delete"
              @click="deleteCheck(index)"
            ></fui-icon>
            <fui-icon
              size="46"
              name="edit-fill"
              @click="editCheck(item, index)"
            ></fui-icon>
          </view>
        </view>
        <view class="onceDate_imgGroup">
          <view class="setDisplay">
            <fui-upload
              ref="upload"
              chooseMax="1"
              :fileList="item.imageUrls"
              confirmDel
              @complete="complete($event, index)"
            ></fui-upload>
          </view>
        </view>
      </view>
      <fui-empty v-if="checkItemList.length == 0"></fui-empty>
    </view>
    <view class="bottom-btn">
      <fui-button height="92rpx" radius="50rpx" @click="stagingIn"
        >暂存并返回</fui-button
      >
      <fui-button height="92rpx" radius="50rpx" @click="showSubmit = true"
        >提交检查</fui-button
      >
    </view>
    <fui-modal :buttons="[]" width="600" :show="showNewCheck">
      <view class="fui-title"> 新增检查点 </view>
      <view class="fui-input">
        <fui-input
          maxlength="10"
          placeholder="请输入检查项名称"
          v-model="checkItemName"
        ></fui-input>
      </view>
      <view class="fui-button">
        <fui-button
          text="取消"
          width="220rpx"
          height="84rpx"
          :size="28"
          radius="50rpx"
          borderColor="#465CFF"
          color="#465CFF"
          background="#FFFFFF"
          @click="onCancel"
        >
        </fui-button>
        <fui-button
          text="确定"
          width="220rpx"
          height="84rpx"
          :size="28"
          radius="50rpx"
          @click="onConfirm"
        >
        </fui-button>
      </view>
    </fui-modal>
    <fui-modal
      :show="showDelete"
      title="删除检查点"
      descr="确定要删除此检查点么？"
      @click="onClickDelete"
    ></fui-modal>
    <fui-modal
      :show="showSubmit"
      title="确认是否提交"
      @click="submit"
    ></fui-modal>
    <fui-toast ref="toast"></fui-toast>
    <fui-safe-area></fui-safe-area>
  </view>
</template>

<script>
import _ from 'lodash'
import { uploadFile } from '@/api/authApi'
import { queryRecordDetail } from '@/api/logCheckApi'
import {
  stagingInspection,
  submitInspection,
  startInspection,
  queryTemplateByMerchant
} from '@/api/beginCheckApi'
export default {
  data() {
    return {
      merchantId: '', //店铺的id
      recordId: '', //当前检查的id
      showNewCheck: false, //显示新增弹窗
      showDelete: false, //显示删除弹窗
      showSubmit: false, //显示提交弹窗
      deleteID: '', //删除的节点index
      changeID: '', //改变的节点index
      checkItemName: '', //改变的节点名字
      checkItemList: [], //节点列表
      deleteImgList: [] //删除的图片url
    }
  },
  computed: {},

  onLoad(options) {
    if (options.merchantId) {
      this.merchantId = options.merchantId
      this.getQueryTemplateByMerchant()
      this.getStartInspection()
    } else if (options.inspectionRecordId) {
      this.recordId = options.inspectionRecordId
      this.getQueryRecordDetail()
    } else {
      uni.showToast({
        title: '未获取到店铺ID',
        icon: 'none'
      })
      uni.navigateBack()
    }
  },
  onShow() {},
  onLaunch() {},
  methods: {
    //--------------新增/编辑检查点--------------//
    //编辑检查点
    editCheck(item, index) {
      this.checkItemName = item.checkSpotName
      this.changeID = String(index)
      this.showNewCheck = true
    },
    //关闭模态框
    onCancel() {
      this.checkItemName = ''
      this.changeID = ''
      this.showNewCheck = false
    },
    //点击确定
    onConfirm() {
      if (this.checkItemName !== '') {
        if (this.changeID != '') {
          this.checkItemList[this.changeID].checkSpotName = this.checkItemName
        } else {
          this.checkItemList.push({
            checkSpotName: this.checkItemName,
            imageUrls: [],
            change: true,
            checkSpotId: -1
          })
        }
        this.checkItemName = ''
        this.changeID = ''
        this.showNewCheck = false
      } else {
        let options = {}
        //提示信息
        options.text = '请输入检查项名称'
        this.$refs.toast.show(options)
      }
    },
    //--------------新增/编辑检查点--------------//

    //--------------删除节点--------------//
    //删除节点
    deleteCheck(index) {
      this.showDelete = true
      this.deleteID = String(index)
    },
    onClickDelete(e) {
      if (!e.plain) {
        this.deleteImgList = this.deleteImgList.concat(
          this.checkItemList[this.deleteID].imageUrls
        )
        this.checkItemList.splice(this.deleteID, 1)
        this.deleteID = ''
      }
      this.showDelete = false
    },
    //--------------删除节点--------------//

    //--------------图片处理--------------//
    complete(e, index) {
      if (e.action == 'choose') {
        this.upLoadImg(e, index)
      } else if (e.action == 'delete') {
        this.deleteImg(e, index)
      }
    },

    async upLoadImg(e, index) {
      let { data } = await uploadFile(e.urls[e.urls.length - 1].toString())
      this.checkItemList[index].imageUrls.push(data[0])
    },
    async deleteImg(e, index) {
      this.deleteImgList = this.deleteImgList.concat(
        _.differenceBy(this.checkItemList[index].imageUrls, e.urls)
      )
      this.checkItemList[index].imageUrls = e.urls
    },

    //--------------图片处理--------------//

    //获取模板
    async getQueryTemplateByMerchant() {
      let { data } = await queryTemplateByMerchant({
        merchantId: this.merchantId
      })
      this.checkItemList = data
    },
    //获取记录ID
    async getStartInspection() {
      let { data } = await startInspection({
        merchantId: this.merchantId
      })
      console.log('data', data)
      this.recordId = data
    },
    //获取暂存数据
    async getQueryRecordDetail() {
      let { data } = await queryRecordDetail({
        supervisionInspectionRecordId: this.recordId
      })
      if (data.dataList.length == 0) {
        this.merchantId = data.merchantId
        this.getQueryTemplateByMerchant()
      } else {
        this.checkItemList = data.dataList
      }
    },
    //提交
    async submit(e) {
      if (!e.plain) {
        let param = {
          supervisionInspectionRecordId: this.recordId,
          paramArray: this.checkItemList
        }
        console.log('param', param)
        await submitInspection(param)
          .then(res => {
            uni.navigateBack()
          })
          .catch(err => {
            uni.navigateBack()
          })
      }
      this.showSubmit = false
    },
    //暂存
    async stagingIn() {
      let param = {
        supervisionInspectionRecordId: this.recordId,
        paramArray: this.checkItemList
      }
      console.log('param', param)
      await stagingInspection(param)
        .then(res => {
          uni.navigateBack()
        })
        .catch(err => {
          uni.navigateBack()
        })
    }
  }
}
</script>
<style lang="scss" scoped>
.start-check-page {
  width: 100vw;
  position: relative;
  display: flex;
  flex-direction: column;
  .top-btn {
    background: #fff;
    padding: 30rpx 40rpx;
    box-shadow: 0rpx 6rpx 10rpx 0rpx rgba(0, 0, 0, 0.1);
    :deep(.fui-button) {
      box-shadow: 0rpx 6rpx 16rpx 0rpx rgba(70, 92, 255, 0.5);
    }
  }
  .checkDate {
    overflow: auto;
    height: 100%;
    padding: 30rpx 30rpx 0 30rpx;
    .onceDate {
      border-radius: 20rpx;
      margin-bottom: 30rpx;
      background: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
      &_title {
        display: flex;
        justify-content: space-between;
        background: #fff;
        margin: 20rpx 0;
        font-size: 48rpx;
        font-weight: bold;
        &_name {
          margin-left: 30rpx;
          font-weight: bold;
          font-size: 36rpx;
        }
        &_right {
          display: flex;
          :nth-child(n) {
            margin-right: 15rpx;
          }
        }
      }
      &_imgGroup {
        display: flex;
        justify-content: center;
        .setDisplay {
          margin-left: 20rpx;
          width: 660rpx;
          :deep(.fui-upload__item) {
            border-radius: 20rpx;
            overflow: auto;
          }
        }
      }
      &:last-child {
        margin-bottom: 300rpx;
      }
    }
  }
  .bottom-btn {
    z-index: 11;
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.5), #ffffff);
    height: 140rpx;
    width: 100%;
    display: flex;
    justify-content: space-around;
    bottom: 0rpx;
    left: 0;
    position: absolute;
    :deep(.fui-button) {
      width: 290rpx !important;
      margin-top: 20rpx;
      box-shadow: 0rpx 6rpx 16rpx 0rpx rgba(70, 92, 255, 0.5);
    }
  }

  .fui-title {
    color: #555555;
    font-size: 30rpx;
    font-weight: bold;
  }
  .fui-input {
    width: 90%;
    border: 1rpx solid #dddddd;
    border-radius: 16rpx;
    margin-top: 36rpx;
    margin-bottom: 52rpx;
    overflow: auto;
    :deep(.fui-input__wrap) {
      padding: 22rpx 32rpx !important;
    }
  }

  .fui-button {
    width: 90%;
    display: flex;
    justify-content: space-around;
  }
}
</style>
