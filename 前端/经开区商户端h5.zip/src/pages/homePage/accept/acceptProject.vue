<template>
  <div class="page-container">
    <div class="page-body">
      <div v-for="(item, index) in list" :key="index">
        <p class="title" style="padding: 20rpx" v-if="item.isHidden">
          {{ item?.classificationName }}
        </p>
        <template v-for="(it, inx) in item?.contentList" :key="inx">
          <fui-card full v-if="it?.questionList?.length > 0" :key="inx" class="mb-[10px]">
            <template v-for="(it1, inx1) in it.questionList" :key="inx1">
              <p class="title" style="padding-bottom: 20rpx">
                {{ it?.checkPointName }}
              </p>
              <div class="img-div" v-if="it?.evidence?.fileList?.length > 0">
                <img v-for="(e, i) in handleList(it.evidence.fileList)" :key="i.id" :src="e?.fileUrl" alt="错误信息" />
              </div>
              <hiddenOrShow title="检查内容:" :des="it?.content" :index="inx">{{
                inx
              }}</hiddenOrShow>
              <fui-form-item label="整改期限:" v-if="it.rectifyEndDate && item.rectifyEndDate != ``">
                <span>{{ it?.rectifyEndDate }}</span>
              </fui-form-item>
              <div class="flex py-[16px] items-center" :class="route.query?.type == 1 ? 'justify-between' : 'justify-around'" @click="toDetail(it,it1)">
                <!-- 1.验收通过 - 不论是否整改都不可以再整改
                2.验收未通过-可整改
                3.未验收-可整改（ 如果整改了但是未验收，需要等验收结果，验收如果通过了就不用整改了，验收没通过就要整改 ） -->

                <!-- <div v-if="route.query.type == 1 && it1.rectifyStatus == 2">
                  <fui-text text="商户已整改" color="#09BE4F" :size="26" block></fui-text>
                </div> -->
                <div v-if="route.query.type == 1">
                  <div v-if="it1?.hasAcceptance">
                    <fui-text text="验收通过" color="#09BE4F" :size="26" block></fui-text>
                  </div>
                  <div v-if="it1?.hasAcceptance == false">
                    <fui-text text="验收不通过" color="#FF2B2B" :size="26" block></fui-text>
                  </div>
                  <div v-if="(!it1?.hasAcceptance && it1?.hasAcceptance != false) && it1?.questionRectifyStatus">
                    <fui-text text="商户已整改" color="#09BE4F" :size="26" block></fui-text>
                  </div>
                </div>
                <div class="bottom-btn" :class="route.query?.type == 2 ? 'nomal' : ''">
                  <img :src="detailImg" alt="加载失败" />
                  <span>
                    {{ route.query.type == 1 && ( it1.hasAcceptance || (!it1?.hasAcceptance && it1?.hasAcceptance != false && it1?.questionRectifyStatus) ) ? formatName.Name : formatName.detailName }}
                  </span>
                  <img class="small" :src="doubleRight" alt="加载失败" />
                </div>
              </div>
            </template>
          </fui-card>
        </template>
      </div>
    </div>
  </div>
  <fui-select :show="showSelect" :options="quesOptions" title="请选择隐患问题" @confirm="onConfirm"
    @close="showSelect = false"></fui-select>
</template>

<script setup>
import { ref, reactive, onMounted, computed,onBeforeUnmount } from "vue";
import { onLoad, onShow } from "@dcloudio/uni-app";
import api from "./server/api";
import detailImg from "@/static/image/detail_icon.png";
import doubleRight from "@/static/image/double_right.png";
import hiddenOrShow from "./components/hiddenOrShow";
import { useRoute, useRouter } from "vue-router";
import { useStore } from "vuex";

const route = useRoute();
const router = useRouter();
const store = useStore();
const list = ref([]);
const tools = reactive({
  visible: false,
  btnText: "查看",
  id: "",
  type: "",
});

const showSelect = ref(false);
const quesOptions = ref([]);
const checkId = ref("");

onLoad((params) => {
  tools.id = params?.id;
  tools.type = params?.type;
  if (tools.type == "1") {
    uni.setNavigationBarTitle({
      title: "待整改项",
    });
  } else {
    uni.setNavigationBarTitle({
      title: "已整改项",
    });
  }
  // queryDetail();
});

onShow(() => {
  queryDetail();
});
onBeforeUnmount(()=>{
  uni.closePreviewImage()
})
const formatName = computed(() => {
  let params = {
    timeName: "",
    detailName: "",
    Name: ""
  };
  if (route.query.type == "2") {
    params.timeName = "隐患整改时间";
    params.detailName = "整改详情";
  } else {
    params.Name = "查看整改详情";
    params.timeName = "隐患确定时间";
    params.detailName = "隐患整改";
  }
  return params;
});
const queryDetail = async () => {
  let res = await api.getCheckDataByRecordId({ recordId: tools.id });
  if (res?.code == "00000") {
    list.value = res?.data?.contentTypeList;
    for (const item of list.value) {
      item.isHidden = false;
      for (const it of item.contentList) {
        if (it.questionList.length > `0`) {
          item.isHidden = true;
          break;
        }
      }
    }
  } else {
    list.value = [];
  }
};
const handleList = (list) => {
  let newList = []
  let newList1 = []
  if (list && list.length > 0) {
    list?.forEach((item) => {
      if (item.fileType == `0`) {
        newList.push(item);
      }
    });
    newList1 = newList?.filter((item, index) => {
      return index <= 2;
    });
  }
  return newList1 || [];
};
const readMore = () => {
  if (tools.visible) {
    tools.visible = false;
    tools.btnText = "查看";
  } else {
    tools.visible = true;
    tools.btnText = "隐藏";
  }
};
const toDetail = (it,it1) => {
  checkId.value = it?.id;
  store.commit("acceptInfos/setInfo", it);
  if ( it1 && Object.keys(it1)?.length > 0) {
    store.commit("acceptInfos/setQuesInfo", it1);
  } else {
    store.commit("acceptInfos/clearQuesInfo");
  }
  // if (it.questionList && it.questionList.length > 0) {
  //   quesOptions.value = it.questionList;
  //   quesOptions.value.forEach((item) => {
  //     item.text = item.question;
  //   });
  //   quesOptions.value[0].checked = true;
  //   showSelect.value = true;
  // } else {
    // store.commit("acceptInfos/clearQuesInfo");
    uni.navigateTo({
      url: `/pages/homePage/accept/acceptDetail?type=${route.query.type}&id=${it?.id}&hiddenId=${it1?.id}`,
    });
  // }
};
const onConfirm = (e) => {
  store.commit("acceptInfos/setQuesInfo", e.options);
  uni.navigateTo({
    url: `/pages/homePage/accept/acceptDetail?type=${route.query.type}&id=${checkId.value}`,
  });
  showSelect.value = false;
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: calc(100vh);
  overflow: auto !important;
}

.page-body {
  // height: calc(100vh - 88rpx);
  padding: 20rpx 30rpx 0 !important;
  overflow: auto;

  :deep(.fui-card__body) {
    padding: 30rpx 20rpx 0 !important;
    border-radius: 8rpx;
  }
}

.title {
  font-size: 36rpx;
  color: #333;
  font-weight: 600;
}

:deep(.fui-form__item-wrap) {
  font-size: 32rpx;
  color: #333;
  padding: 30rpx 0 !important;
}

.img-div {
  height: 180rpx;
  display: flex;
  justify-content: space-between;
  margin-bottom: 20rpx;

  img {
    width: 48%;
    height: 100%;
    object-fit: cover;
    border-radius: 4px;
    border: 1px solid #eee;
  }
}

.bottom-btn {
  width: 35vw;
  // margin: auto;
  justify-content: space-evenly;
  display: flex;
  align-items: center;

  .nomal {
    margin: auto !important;
  }

  img {
    margin-top: 6rpx;
    width: 36rpx;
    height: 36rpx;
  }

  .small {
    width: 26rpx;
    height: 22rpx;
  }

  span {
    font-size: 32rpx;
    line-height: 38rpx;
    color: #1d4ad4;
  }
}
</style>