<template>
  <div class="page-container">
    <div style="height: 100rpx">
      <fui-tabs :tabs="details" scroll alignLeft :short="false" sliderHeight="6" bottom="10" background="#FFF"
        color="#999" selectedColor="#333" size="36" selectedSize="36" fontWeight="600" selectedFontWeight="600"
        sliderBackground="#1D4AD4" @change="changeTabs" />
    </div>
    <div class="list-wrap">
      <!-- <fui-loading type="col" text="加载中" isMask v-if="loading"></fui-loading>
      <fui-empty v-else-if="listData.length < 1 && !loading" title="暂无数据"></fui-empty> -->
      <div v-for="(item, index) in details" :key="index">
        <template v-if="index == tools.currentTab">
          <fui-upload :fileList="item?.imageList" :isDel="false" :isAdd="false" style="margin: 30rpx 0"></fui-upload>
          <fui-upload-video ref="upload" :fileList="item?.videoList" isView></fui-upload-video>
          <p class="left-title">规范说明</p>
          <fui-textarea :disabled="true" v-model="item.explains" style="padding-bottom: 40rpx" />
        </template>
      </div>
      <!-- 隐患 -->
      <div v-if="hiddenList?.length > 0">
        <p class="left-title">常见隐患</p>
        <div v-if="hiddenList.length > 0">
          <fui-list-cell :bottomBorder="false" :highlight="false">
            <span class="cell-label">隐患内容:</span>
            <span class="cell-text">{{ hiddenList?.[0]?.describes }}</span>
          </fui-list-cell>
          <!-- <fui-list-cell :bottomBorder="false">
            <span class="cell-label">整改意见:</span>
            <span class="cell-text">{{ hiddenList?.[0]?.suggest }}</span>
          </fui-list-cell> -->
          <fui-list-cell>
            <span class="cell-label">隐患性质:</span>
            <span class="cell-text" :style="{ color: formatState(hiddenList?.[0]?.levelName).color }">{{
              hiddenList?.[0]?.levelName }}</span>
          </fui-list-cell>
          <fui-list-cell @click="showAllRisks">
            <p style="color: #1d4ad4; font-size: 32rpx; margin: auto">
              查看更多 >>
            </p>
          </fui-list-cell>
        </div>
      </div>
      <!-- 现场取证 -->
      <acceptItem :infos="evidence" type="1" :questionList="questionList" title="现场取证"></acceptItem>
      
      <!-- 隐患问题 -->
      <div v-if="Object.keys(quesInfo)?.length > 0">
        <fui-divider text="隐患信息" size="36" color="#000000" fontWeight="800" dividerColor="#6831FF"></fui-divider>
        <div>
          <div class="text-36rpx font-bold">隐患图片</div>
          <div class="py-[10rpx]">
            <fui-upload :fileList="quesFileList" :isDel="false" :isAdd="false" />
          </div>
          <template v-if="quesFileListVideo?.length> 0">
            <div class="text-36rpx font-bold">视频</div>
            <div class="py-[10rpx]">
              <fui-upload-video ref="upload" :fileList="quesFileListVideo" isView></fui-upload-video>
            </div>
          </template>

        </div>
        <div class="mt-[10rpx]">
          <div class="text-36rpx font-bold">描述</div>
          <div class="py-[10rpx] text-30rpx indent-[16rpx]">
            {{ quesInfo.question }}
          </div>
        </div>
        <div class="mt-[10rpx]">
          <div class="text-36rpx font-bold">整改意见</div>
          <div class="py-[10rpx] text-30rpx indent-[16rpx]">
            {{ quesInfo.opinion }}
          </div>
        </div>
        <div class="flex">
          <div class="text-36rpx font-bold">隐患性质:</div>
          <div class="text-36rpx pl-[10rpx] flex">
            {{ quesInfo.dangerNatureName }}
          </div>
        </div>
        <div class="flex mt-[10rpx]">
          <div class="text-36rpx font-bold">整改期限:</div>
          <div class="text-36rpx pl-[10rpx] flex">
            {{ quesInfo.rectifyDay }}天
          </div>
        </div>
      </div>

      <!-- 商户整改情况 -->
      <div v-if="rectify.length > 0">
        <!-- <div v-for="(item,index) in acceptance" :key="index">
          <acceptItem :infos="item" type="2" title="整改记录"></acceptItem>
        </div> -->
        <fui-divider text="整改信息" size="36" color="#000000" fontWeight="800" dividerColor="#6831FF"></fui-divider>
        <div v-for="item in rectify">
          <div class="text-36rpx font-bold">整改日期</div>
          <div class="text-30rpx py-[20rpx] indent-[20rpx]">
            {{ item.createTime }}
          </div>
          <div class="text-36rpx font-bold mb-[20rpx]">图片记录</div>
          <fui-upload ref="refUpload" :fileList="handleList(item.imgList)" :isDel="false" :isAdd="false" />
          <div class="text-36rpx font-bold mb-[20rpx]">视频</div>
          <fui-upload-video ref="upload" :fileList="handleVideoList(item.imgList)" isView></fui-upload-video>
          <div class="text-36rpx font-bold">文字记录</div>
          <div class="text-30rpx indent-[20rpx] py-[20rpx] break-all">
            {{ item.describes }}
          </div>
          <fui-divider width="100vw" height="40"></fui-divider>
        </div>
      </div>
      
      <!-- 整改情况 1 待整改 2 已整改 -->
      <template v-if="evidence.auditorStatus != `1`">
        <div v-if="route.query.type == 1 && !quesInfo?.hasAcceptance">
          <acceptItem :acceptType="route.query.type" :questionList="questionList" :id="route.query?.hiddenId" @submit="submit" type="3"
            title="整改信息" />
        </div>
        <div v-else-if="route.query.type == 2 && acceptance.length > 0">
          <div v-for="(item, index) in acceptance" :key="index">
            <acceptItem :infos="item" :acceptType="route.query.type" type="3" title="整改信息3" />
          </div>
        </div>
      </template>
    </div>
    <selectRisks v-model:showPop="tools.showRisks" :riskList="hiddenList" :type="1"></selectRisks>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted,onBeforeUnmount } from "vue";
import acceptItem from "./components/acceptItem.vue";
import selectRisks from "@/components/selectRisks.vue";
import api from "./server/api";
import { useRoute, useRouter } from "vue-router";
import { useStore } from "vuex";
import { onLoad, onPullDownRefresh, onUnload } from "@dcloudio/uni-app";
import vrFunc from "@/common/vrFunc.js";

const route = useRoute();
const router = useRouter();
const store = useStore();
const listData = ref([
  {
    merchantAliasName: "11111",
    merchantName: "11111",
    createTime: "11111",
    createUser: "11111",
  },
]);
const loading = ref(false);
const tools = reactive({
  currentTab: 0,
  current: 0,
  scrollYTop: 0,
  oldScrollYTop: 0,
  showEvidence: false, // 展示现场取证
});
const details = ref([]);
const hiddenList = ref([]);
const quesFileList = ref([]);
const quesFileListVideo = ref([]);
const quesInfo = ref({}); // 隐患问题
const evidence = ref({}); // 现场取证
const rectify = ref({});
const acceptance = ref({});

const questionList = ref([]);
onMounted(async () => {
  let info = JSON.parse(JSON.stringify(store.state.acceptInfos.info));
  quesInfo.value = JSON.parse(JSON.stringify(store.state.acceptInfos.quesInfo));
  if (Object.keys(quesInfo.value)?.length > 0) {
    let quesFileListTemp = [];
    let quesFileListVideoTemp = [];
    quesInfo.value.fileList.forEach((item) => {
      if (item.fileType==`0`) {
        quesFileListTemp.push(item.fileUrl);
      }
      if (item.fileType==`1`) {
        quesFileListVideoTemp.push(item.fileUrl);
      }
    });
    quesFileList.value = quesFileListTemp;
    quesFileListVideo.value = quesFileListVideoTemp;
  }

  // 检查规范 criterionList
  info.criterionList.map((it, index) => {
    it.name = "规范" + (index + 1);
    it.imageList = it.imgFileList.map((i) => {
      return i.fileUrl;
    });
    it.videoList = it.videoFileList.map((i) => {
      return i.fileUrl;
    });
  });
  details.value = info.criterionList;
  // 问题列表
  questionList.value = info?.questionList ?? [];
  console.log(questionList.value, 333);
  //常见隐患 hiddenDangerList
  info?.hiddenDangerList?.map((it, index) => {
    it?.successImgFileList?.forEach((i) => {
      i.type = 1;
    });
    it?.errorImgFileList?.forEach((i) => {
      i.type = 2;
    });
    it.imgList = it.errorImgFileList.concat(it.successImgFileList);
    it?.successVideoFileList?.forEach((i) => {
      i.type = 1;
    });
    it?.errorVideoFileList?.forEach((i) => {
      i.type = 2;
    });
    let videoList = it.successVideoFileList.concat(it.errorVideoFileList);
    it.videoList = [];
    videoList?.map((item) => {
      it.videoList.push(item?.fileUrl);
    });
  });
  hiddenList.value = info?.hiddenDangerList;
  // 现场取证
  if (info?.evidence && info?.evidence?.fileList) {
    info.evidence.imgList = [];
    info?.evidence?.fileList?.map((item) => {
      info.evidence.imgList.push(item.fileUrl);
    });
    // 现场核查没有上传图片功能, 隐患图片取现场核查的图片
    if (quesFileList.value.length == `0`) {
      if (info?.evidence?.imgList?.length > 0) {
        let newList = []
        info?.evidence?.imgList?.map(item => {
          let testMsg = item.substring(item.lastIndexOf(".") + 1);
          let type = ["mp4", "MP4", "webm", "webm", "mov", "MOV"];
          let isVideo = type.includes(testMsg);
          if (!isVideo) {
            newList.push(item)
          }
        });
        quesFileList.value = newList || [];
      }
    }
  } else {
    info.evidence.imgList = [];
  }
  evidence.value = info?.evidence;
  // 整改
  rectify.value = info?.rectify;
  rectify.value.forEach((item) => {
    item.imgList = [];
    item.fileList.forEach((i) => {
      item.imgList.push(i.fileUrl);
    });
  });
  console.log(rectify.value, "rectify.value");
  // 整改
  acceptance.value = info?.acceptance;
  if (route.query?.hiddenId) {
    let hiddenRes = await api.getHiddenDetail({id: route.query?.hiddenId})
    if (hiddenRes?.code == "00000") {
      quesInfo.value = hiddenRes.data
      rectify.value = quesInfo.value?.rectify;
      rectify.value?.forEach((item) => {
        item.imgList = [];
        item.fileList.forEach((i) => {
          item.imgList.push(i.fileUrl);
        });
      });
      if (hiddenRes?.data?.fileList?.length > 0) {
        let quesFileList = [];
        let quesFileListVideo = [];
        hiddenRes?.data?.fileList.forEach((item) => {
          if (item.fileType == `0`) {
            quesFileList.push(item?.fileUrl);
          }
          if (item.fileType == `1`) {
            quesFileListVideo.push(item?.fileUrl);
          }
        });
        quesFileList.value = quesFileList;
        quesFileListVideo.value = quesFileListVideo;
      } else {
        quesFileList.value = [];
        quesFileListVideo.value = [];
      }
    }
  }
});

onBeforeUnmount(()=>{
  uni.closePreviewImage()
})
const formatState = (val) => {
  let res = { name: "", color: "#13BA79" };
  switch (val) {
    case "一般隐患":
      res = { name: "一般隐患", color: "#13BA79" };
      break;
    case "重大隐患":
      res = { name: "重大隐患", color: "#F95943 " };
      break;
  }
  return res;
};
const queryDetails = () => {
  tools.tabs = details.value.map((item) => {
    return Object.assign({}, { name: item.name });
  });
};
const changeTabs = (e) => {
  tools.currentTab = e.index;
  // getRecordList()
};
const scroll = (e) => {
  tools.oldScrollYTop = e.target.scrollTop;
};
const toProject = (id) => {
  uni.navigateTo({
    url: `/pages/homePage/accept/acceptProject?id=${id}`,
  });
};
const showAllRisks = () => {
  tools.showRisks = true;
};
const handleList = (val) => {
  let list = [];
  if (val && val.length > 0) {
    val.map(item => {
      console.log(item);
      let testMsg = item.substring(item.lastIndexOf(".") + 1);
      let type = ["mp4", "webm"];
      let isVideo = type.includes(testMsg);
      if (!isVideo) {
        list.push(item)
      }
      // list.push(item.fileUrl)
    });
  }
  return list
}
const handleVideoList = (val) => {
  let list = [];
  if (val && val.length > 0) {
    val.map(item => {
      let testMsg = item.substring(item.lastIndexOf(".") + 1);
      let type = ["mp4", "webm"];
      let isVideo = type.includes(testMsg);
      if (isVideo) {
        list.push(item)
      }
    });
  }

  return list
}
const submit = async (params) => {
  params.cdcId = route.query.id;
  let res = await api.doReceipt(params);
  if (res?.code == "00000") {
    vrFunc.toast("提交成功");
    if (res.data) {
      setTimeout(() => {
        // uni.navigateTo({
        //   url: "/pages/homePage/accept/index",
        // });
        uni.navigateBack({
          delta: 2,
        });
      }, 800);
    } else {
      uni.navigateBack({
        delta: 1,
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: calc(100vh);
  display: flex;
  flex-direction: column;
}

.list-wrap {
  padding: 0 30rpx;
  flex: 1;
  overflow: auto;
}

:deep(.fui-tabs__scrollbox) {
  ::-webkit-scrollbar {
    width: 0px !important;
    height: 0px !important;
  }
}

.fui-banner__wrap {
  text-align: center;
  height: 360rpx;
  border-radius: 8rpx;
}

.cell-label {
  width: 160rpx;
  font-size: 32rpx;
  color: #333;
}

.cell-text {
  flex: 1;
  font-size: 32rpx;
  color: #666;
}

.left-title {
  font-size: 36rpx;
  padding-bottom: 20rpx;
  font-weight: 600;
}

:deep(.fui-upload__wrap) {
  width: calc(100vw - 60rpx) !important;
  flex-wrap: nowrap !important;
  overflow-x: auto !important;
}

:deep(.fui-tabs__text) {
  transform: scale(1) !important;
}
</style>