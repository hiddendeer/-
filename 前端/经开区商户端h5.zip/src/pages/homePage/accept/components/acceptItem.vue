<template>
  <div>
    <p class="header" v-if="props?.title">{{ props.title }}</p>
    <!-- 3 验收情况-待验收 -->
    <template v-if="props.type == 3 && props.acceptType != '2'">
      <!-- <fui-radio-group name="radio" v-model="accept.acceptanceStatus">
        <div style="display:flex">
          <fui-label v-for="it in resultList" :key="it.id"
            style="padding: 5rpx 60rpx 40rpx 0;color: #333;font-size: 32rpx">
            <fui-radio :value="it.id + ''"></fui-radio>
            <span style="padding-left: 20rpx">{{ it.name }}</span>
          </fui-label>
        </div>
      </fui-radio-group> -->
      <div class="title">
        <span>图片记录</span>
        <span>( {{ handleListImageNum(props?.infos?.fileList) }}/6)</span>
        <span style="color: red;">*</span>
      </div>
      <fui-upload ref="refUpload" :fileList="accept.fileList" immediate :url="accept.uploadUrl" :max="6"
        @success="(e) => successUpload(e)" @complete="(e) => completeUpload(e)" />
      <div class="title">
        <span>视频</span>
      </div>
      <!-- <fui-upload-video ref="upload" :fileList="handleVideoList(props?.infos?.fileList)" immediate
        isView></fui-upload-video> -->
      <fui-upload-video   immediate :max="1" background="#333" addColor="#d1d1d1" :fileList="accept.videoList"
        :url="fileUrl" ref="refUploadVideo" @success="successUploadVideo" @complete="completeVideo"></fui-upload-video>
    </template>
    <!-- 已验收 -->
    <template v-else-if="props.acceptType == '2'">
      <fui-form-item label="验收结果:" :labelWidth="180" style="background:#F4F5F7">
        <p>{{ props?.infos?.acceptanceStatus == '1' ? '验收通过' : '验收不通过' }}</p>
      </fui-form-item>
      <div class="title">
        <span>图片记录</span>
        <span>( {{ handleListImageNum(props?.infos?.fileList) }}/6)</span>
      </div>
      <fui-upload :fileList="handleList(props?.infos?.fileList)" :isDel="false" :isAdd="false"></fui-upload>
      <div class="title">
        <span>视频</span>
      </div>
      <fui-upload-video ref="upload" :fileList="handleVideoList(props?.infos?.fileList)" isView></fui-upload-video>
    </template>
    <!-- 现场取证、整改情况 -->
    <template v-else-if="props?.infos?.fileList?.length > 0">
      <div class="title">
        <span>图片记录</span>
        <span>( {{ handleListImageNum(props?.infos?.fileList) }}/6)</span>
      </div>
      <fui-upload :fileList="handleList(props?.infos?.fileList)" :isDel="false" :isAdd="false"></fui-upload>
      <div class="title">
        <span>视频</span>
      </div>
      <fui-upload-video ref="upload" :fileList="handleVideoList(props?.infos?.fileList)" isView></fui-upload-video>
    </template>
    <p class="title">文字记录</p>
    <!-- 验收情况 -->
    <div v-if="props.type == '3'">
      <div class="record-div">
        <fui-textarea v-if="props?.acceptType == '1'" v-model="accept.records" :disabled="props.acceptType == '2'"
          :borderBottom="false" maxlength=200 :isCounter="props?.acceptType == '1'" />
        <fui-textarea v-else-if="props?.acceptType == '2'" :disabled="props.acceptType == '2'" :borderBottom="false"
          maxlength=200 v-model="props.infos.describes"></fui-textarea>
          <div v-if="props?.acceptType == '1'" class="flex flex-end">
            <img src="/static/image/del_icon.png" @click="accept.records=''" alt="" />
          </div>
      </div>
    </div>
    <!-- 其他 -->
    <fui-textarea style="padding-bottom: 40rpx" v-else disabled v-model="props.infos.describes" />
    <fui-button v-if="props.acceptType == 1 && props.type == 3 && props.questionList.length > 0" radius="96rpx"
      :margin="['20rpx', '0']" @click="save">提交</fui-button>
    <!-- 1 现场取证 -->
    <div v-if="props.type == '1'" class="title" style="padding-bottom: 0">
      <span class="cell-label red-text">
        {{ props.infos?.auditorStatus == 1 ? '合格' : (props.infos?.auditorStatus == 3 ? '未判断' : '') }}
      </span>
      <span class="text">
        <fui-tag v-if="props.infos?.auditorStatus == `1`" :type="props.infos?.auditorStatus == `1` ? 'success' : 'danger'"
          theme="light">
          <span v-if="props.infos?.auditorStatus == `1`">
            合格
          </span>
        </fui-tag>
      </span>
    </div>
    <!-- 2 商户整改情况 -->
    <div v-if="props.type == '2'" class="title" style="padding-bottom: 0">
      <span class="cell-label">商户整改时间:</span>
      <span style="font-weight: 400">{{ props?.infos?.createTime ?? '' }}</span>
      <span v-if="props?.infos?.overdueDay" style="color: #F95943;font-weight: 400">(逾期{{ props?.infos?.overdueDay
      }}天)</span>
    </div>
    <fui-toast ref="toast"></fui-toast>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, watchEffect ,onBeforeUnmount} from "vue";
import { useStore } from "vuex";
const $store = useStore();

const props = defineProps({
  infos: {
    type: Object,
    default: {},
  },
  type: {
    type: String
  },
  title: {
    type: String
  },
  acceptType: {
    type: String,
    default: '1', // 1 待验收  2 已验收 
  },
  questionList: {
    type: Array,
    default: [],
  },
  id: {
    type: String,
    default: '', 
  },
});
const toast = ref(null);
const refUpload = ref(null);
const refUploadVideo = ref(null);
const resultList = ref([
  { id: 1, name: '验收通过' },
  { id: 2, name: '验收不通过' }
]);

const accept = reactive({
  fileList: [],
  newFileList: [],
  uploadUrl: window.location.origin + "/tvrjet-edz-supervision-system-custom-app/minio/upload",
  records: '',
  acceptanceStatus: '1',
  videoList: [],
})
const fileUrl = ref(window.location.origin + '/tvrjet-edz-supervision-system-custom-app/minio/upload')
const emit = defineEmits(["submit"]);
onMounted(() => {
  if (window.ls) {
    window.ls.location({
      type: 'GPS'
    }, function (res) {
      if (res.code === 200) {
        //成功
        let str = res.data.province + res.data.street + res.data.number;
        // let watermarkStr = `&lat=${res.data.latitude}&lon=${res.data.longitude}`
        accept.uploadUrl = accept.uploadUrl + 'ByWatermark?watermarkStr=' + str;
      } else {
        //失败
        //show error
        uni.showToast({
          title: '扫码失败',
          duration: 2000
        });
      }
    })
  }
  props?.infos?.fileList
})
onBeforeUnmount(()=>{
  uni.closePreviewImage()
})
// 判断当前图片数量
const handleListImageNum = (val) => {
  let list = [];
  if (val && val.length > 0) {
    val.map(item => {
      if (item.fileType == `0`) {
        list.push(item);
      }
    });
  }
  return list?.length || 0
}
const handleList = (val) => {
  let list = [];
  if (val && val?.length > 0) {
    val?.forEach((item) => {
      if (item?.fileType == `0`) {
        list.push(item?.fileUrl);
      }
    });
  }
  return list || []
}
const handleVideoList = (val) => {
  console.log(val);
  let list = [];
  if (val && val.length > 0) {
    val.map(item => {
      let testMsg = item.fileUrl.substring(item.fileUrl.lastIndexOf(".") + 1);
      let type = ["mp4", "webm"];
      let isVideo = type.includes(testMsg);
      if (isVideo) {
        list.push(item.fileUrl)
      }
    });
  }
  console.log(list);
  return list
}
const successUploadVideo = (e) => {
  let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
  if (res.data) {
    accept.newFileList.push({
      fileId: res.data?.id,
      fileUrl: res.data?.fileUrl,
      sort: e.index
    });
    accept.videoList.push(res.data?.fileUrl);
    //处理结果返回给组件
    refUploadVideo.value.result(res.data.fileUrl, e.index);
  }
}

//上传成功触发
const successUpload = (e) => {
  let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
  if (res?.code == '00000' && res.data) {
    accept.fileList.push(res.data?.fileUrl);
    accept.newFileList.push({
      fileId: res.data?.id,
      fileUrl: res.data?.fileUrl,
      sort: e.index
    });
    //处理结果返回给组件
    refUpload.value.result(res.data.fileUrl, e.index);
  }
};
//图片选择、上传完成、删除时触发
const completeUpload = (e) => {
  if (e?.action == 'delete') {
    accept.fileList = e?.urls;
    // let arr = accept.newFileList.filter((item) => accept.fileList.includes(item.fileUrl))
    // accept.newFileList = arr;
  }
};
// 删除视频 
const completeVideo = (e) => {
  if (e?.action == 'delete') {
    accept.videoList = e?.urls;
  }
};
const showToast = (text) => {
  let options = {}
  //提示信息
  options.text = text;
  toast.value.show(options)
}
// 提交数据
const save = () => {
  const cdcqId = $store.state.acceptInfos.quesInfo?.id || props.id;
  if (!cdcqId) {
    return showToast('请选择隐患!');
  }
  let params = {
    describes: accept.records, //文字记录
    cdcqId,
    acceptanceStatus: accept.acceptanceStatus, //验收状态（1通过、2不通过）
  }
  if (accept.fileList.length > 0) {

    // params.fileList = accept.newFileList.map(item => {
    //   return Object.assign({}, { 'fileId': item.fileId, 'sort': item.sort })
    // });

    let newFileList = [...accept.fileList, ...accept.videoList];
    let arrFileID = [];
    accept.newFileList.map(item => {
      newFileList.forEach(it => {
        if (it == item.fileUrl) {
          arrFileID.push({
            fileId: item.fileId,
            sort: item.sort
          })
        }
      })
    })
    params.fileList = arrFileID
  } else {
    return showToast('请选择图片!')
  }
  console.log(params);
  emit('submit', params);
}
defineExpose({})
</script>
<style lang="scss" scoped>
.header {
  font-size: 36rpx;
  font-weight: 600;
  text-align: center;
  padding: 40rpx 0 20rpx;
}

.title {
  font-size: 36rpx;
  padding-bottom: 20rpx;
  font-weight: 600;
}

.cell-label {
  padding-right: 20rpx;
  font-size: 36rpx;

}

.text {
  color: #1D4AD4;
  font-size: 32rpx;
  font-weight: 400;
}

.red-text {
  color: #F95943;
}

.record-div {
    margin-bottom: 40rpx;
    background: #fff;
    min-height: 200rpx;

    img {
        width: 46rpx;
        margin: 0rpx 20rpx 20rpx 0rpx;
        height: 46rpx;
        border: 1px solid #1D4AD4;
        border-radius: 50rpx;
        padding: 7rpx 32rpx;
    }
}

:deep(.fui-upload__wrap) {
  width: calc(100vw - 60rpx) !important;
  margin-bottom: 30rpx;
  flex-wrap: nowrap !important;
  overflow-x: auto !important;

  ::-webkit-scrollbar {
    display: none !important;
    border: 1px solid red;
  }
}

:deep(.fui-form__item-wrap) {
  padding: 0 0 30rpx 0 !important;

  span {
    font-size: 36rpx;
    color: #000;
    font-weight: 600;
  }

  p {
    font-size: 32rpx;
  }
}
</style>