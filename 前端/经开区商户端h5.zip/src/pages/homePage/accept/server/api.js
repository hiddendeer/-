import http from '@/utils/network.js'

export default class Api {
    // 登录获取企业列表
    static getReceiptPage(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getReceiptPage',
            method: 'GET',
            data: data
        })
    }
    static getWaitReceiptPage(data) {
        return http.request({
          url: '/tvrjet-edz-supervision-app/gov/h5/home/getWaitReceiptPage',
          method: 'GET',
          data: data
        })
      }
      // 根据记录id获取所有检查项及以下信息
      static getCheckDataByRecordId(data) {
        return http.request({
          url: '/tvrjet-edz-company-app/sso/user/getReceiptDetail',
          method: 'GET',
          data: data
        })
      }
      // 执行整改
      static doReceipt(data) {
        return http.request({
          url: '/tvrjet-edz-company-app/sso/user/doRectify',
          method: 'POST',
          data: data
        })
      }
    // 隐患列表-详情查询
    static getHiddenDetail(data) {
      return http.request({
        url: '/tvrjet-edz-company-app/sso/user/questionDetail',
        method: 'GET',
        data: data
      })
    }
}