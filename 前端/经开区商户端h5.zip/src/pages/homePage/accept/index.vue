<template>
  <div class="page-container">
    <div style="height: 100rpx; display: flex; align-items: center">
      <fui-tabs
        :tabs="tools.tabs"
        :short="false"
        sliderHeight="6"
        bottom="10"
        fontWeight="600"
        background="#F4F5F7 "
        color="#999"
        selectedColor="#333"
        size="36"
        selectedSize="36"
        selectedFontWeight="600"
        sliderBackground="#1D4AD4"
        @change="changeTabs"
      />
      <!-- <img
        style="height: 88rpx; width: 88rpx"
        src="/static/image/filter_icon.png"
        @click="tools.showSide = true"
      /> -->
    </div>
    <!-- style="height: calc(100vh - 300rpx)" -->
    <scroll-view
      scroll-y="true"
      style="height: calc(100vh - 100rpx)"
      @scrolltolower="scrolltolower"
    >
      <div class="list-wrap">
        <fui-loading
          type="col"
          text="加载中"
          isMask
          v-if="loading"
        ></fui-loading>
        <fui-empty
          v-else-if="listData.length < 1 && !loading"
          title="暂无数据"
        ></fui-empty>
        <div
          v-else
          v-for="(item, index) in listData"
          :key="item.id"
          class="box"
          @click="toProject(item.id)"
        >
          <div style="flex: 1; overflow: hidden">
            <div class="box-row flex">
              <p class="label-text">任务名称：</p>
              <p class="fui-text__explain">{{ item?.taskName }}</p>
            </div>
            <div class="box-row flex">
              <p class="label-text">店招名：</p>
              <p class="fui-text__explain">
                {{ item?.merchantInfo?.merchantAliasName }}
              </p>
            </div>
            <div class="box-row flex">
              <p class="label-text">检查人：</p>
              <p class="fui-text__explain">
                {{ item?.checkUserInfo?.realName }}
              </p>
            </div>
            <div class="box-row flex">
              <p class="label-text">检查时间：</p>
              <p class="fui-text__explain">{{ item?.checkTime }}</p>
            </div>
          </div>
          <div class="w-full flex justify-end">
            <span class="text-30rpx text-[#666666] relative top-[-10rpx]"
              >详情</span
            >
            <img
              src="/static/image/right_arrow.png"
              style="height: 24rpx; width: 24rpx"
            />
          </div>
        </div>
      </div>
    </scroll-view>
    <!-- 筛选 -->
    <fui-drawer :show="tools.showSide" @close="tools.showSide = false">
      <div scroll-y class="fui-scroll__view" style="width: 75vw">
        <view class="sideBar">
          <fui-input
            placeholder="搜索店招名或任务名称"
            backgroundColor="#F4F5F7"
            isFillet
            inputBorder
            v-model="tools.searchInput"
          ></fui-input>
          <div class="sideBar_time">
            <p>按检查时间搜索</p>
            <fui-list-cell @click="tools.showTimer = true">
              <view class="fui-align__center">
                <fui-icon name="calendar" @click="showSide = true"></fui-icon>
              </view>
              <text class="fui-text__explain">{{
                tools.startTime ? tools.startTime : "请选择时间区间"
              }}</text>
            </fui-list-cell>
            <fui-list-cell @click="tools.showTimer = true">
              <view class="fui-align__center">
                <fui-icon
                  name="calendar"
                  @click="toolsshowSide = true"
                ></fui-icon>
              </view>
              <text class="fui-text__explain">{{
                tools.endTime ? tools.endTime : "请选择时间区间"
              }}</text>
            </fui-list-cell>
          </div>
        </view>
        <div class="sideBar_footer">
          <fui-button
            text="重置"
            radius="0"
            color="#333"
            plain
            @click="reset"
          ></fui-button>
          <fui-button text="搜索" radius="0" @click="handleSearch"></fui-button>
        </div>
      </div>
    </fui-drawer>
    <fui-date-picker
      range
      :value="tools.timer"
      :show="tools.showTimer"
      type="3"
      @change="changeTimer"
      @cancel="cancelTimer"
    >
    </fui-date-picker>
  </div>
</template>

<script setup>
import vrFunc from "@/common/vrFunc.js";
import api from "./server/api.js";
import { ref, reactive, onMounted } from "vue";

import { onPullDownRefresh, onShow } from "@dcloudio/uni-app";

const listData = ref([]);
const loading = ref(false);
const tools = reactive({
  tabs: [{ name: "待整改" }, { name: "已整改" }],
  currentTabs: 1, // 待整改
  scrollYTop: 0,
  oldScrollYTop: 0,
  showSide: false,
  searchInput: "",
  timer: "2022-12-8",
  startTime: "",
  endTime: "",
  showTimer: false,
  pullPageNO: 1, // 下拉页数
  isPull: true, // 允许上拉加载
});

const searchForm = ref({
  pageNo: 1,
  pageSize: 20,
  rectifyStatus: 1,
});

onShow(() => {
  getReceiptPage();
});

// 下拉刷新
onPullDownRefresh(() => {
  searchForm.value.pageNo = 1;
  tools.pullPageNO = 1;
  getReceiptPage();
  uni.stopPullDownRefresh();
});

// 获取数据列表
const getReceiptPage = async () => {
  searchForm.value.pageNo = tools.pullPageNO;
  const res = await api.getReceiptPage(searchForm.value);
  if (res?.code && res.code == "00000") {
    if (tools.pullPageNO > 1 && res.data.records.length == 0) {
      vrFunc.toast("已经到底了");
      return;
    }

    // 初次加载和上拉加载的区分
    if (tools.pullPageNO > 1) {
      res.data.records.forEach((item) => {
        listData.value.push(item);
      });
    } else {
      listData.value = res.data.records;
    }
  }
  console.log(res);
};

// 上拉触底
const scrolltolower = (e) => {
  tools.pullPageNO++;
  getReceiptPage();
};

const changeTabs = (e) => {
  tools.currentTabs = e?.index + 1;
  searchForm.value.rectifyStatus = tools.currentTabs;
  searchForm.value.pageNo = 1
  tools.pullPageNO = 1
  searchForm.value. pageSize= 20
  listData.value = []
  getReceiptPage();
};
//重置
const reset = () => {
  tools.searchInput = "";
  tools.startTime = "";
  tools.endTime = "";
  tools.stateIndex = "";
};
//搜索
const handleSearch = () => {
  let obj = {};
  obj.searchInput = tools.searchInput;
  obj.startTime = tools.startTime;
  obj.endTime = tools.endTime;
  obj.stateIndex = tools.stateIndex;
  console.log(obj);
};
const changeTimer = (e) => {
  tools.showTimer = false;
  console.log(444, e.startDate.result);
  tools.startTime = e.startDate.result;
  tools.endTime = e.endDate.result;
};
const cancelTimer = () => {
  tools.showTimer = false;
};
const scroll = (e) => {
  tools.oldScrollYTop = e.target.scrollTop;
};

const toProject = (id) => {
  uni.navigateTo({
    url: `/pages/homePage/accept/acceptProject?type=${tools.currentTabs}&id=${id}`,
  });
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  // height: calc(100vh - 178rpx);
  height: calc(100vh);
  display: flex;
  flex-direction: column;
}
.list-wrap {
  padding: 0 30rpx;
  flex: 1;
  overflow: auto;
}
.box {
  background-color: #fff;
  border-radius: 10rpx;
  margin-bottom: 20rpx;
  padding: 40rpx 24rpx 30rpx;
  color: #333;
  overflow: hidden;
  align-items: center;
  justify-content: space-between;
  font-size: 32rpx;
  .box-row {
    padding-bottom: 10rpx;
    p {
      min-width: 160rpx;
      color: #666;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
.fui-scroll__view {
  height: 100%;
  padding: 88rpx 0;
  display: flex;
  flex-direction: column;
}
.sideBar {
  flex: 1;
  overflow: auto;
  background-color: #fff;
  padding: 36rpx 26rpx 40rpx;
  :deep(.fui-input__wrap) {
    padding: 16rpx 36rpx !important;
  }
}
.sideBar_time {
  background-color: #fff;
  margin: 40rpx 0rpx;
  :deep(.fui-list__cell) {
    padding: 30rpx 0 !important;
  }
  :deep(.fui-tabs__scrollbox) {
    background-color: #fff !important;
  }
  p {
    color: #333;
    font-size: 28rpx;
  }
}
.sideBar_footer {
  height: 100rpx;
  display: flex;
  align-items: center;
  margin-bottom: 40rpx;
  :deep(.fui-button) {
    width: 100% !important;
  }
}
:deep(.fui-tabs__text) {
  transform: scale(1) !important;
}
.label-text {
  color: #7f7f7f !important;
}
.fui-text__explain {
  color: #181818 !important;
}
</style>