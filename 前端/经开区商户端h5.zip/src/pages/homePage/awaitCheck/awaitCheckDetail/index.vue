<template>
  <view class="page check-detail">
    <fui-loading type="col" text="加载中" isMask v-if="loading"></fui-loading>
    <fui-empty
      v-if="isEmpty(dataList) && !loading"
      title="暂无隐患"
    ></fui-empty>
    <view class="tab-box">
      <fui-tabs
        :current="current"
        :tabs="tabs"
        scroll
        :short="false"
        @change="({ index }) => (current = index)"
      ></fui-tabs>
    </view>
    <DetailCardList
      v-if="!isEmpty(dataList)"
      class="detail-card"
      :dataList="dataList[current].hidden"
    ></DetailCardList>
    <fui-safe-area></fui-safe-area>
  </view>
</template>

<script>
import { queryListByRecord } from '@/api/awaitCheck.js'
import DetailCardList from './components/card-list.vue'
import _ from 'lodash'
export default {
  components: {
    DetailCardList
  },
  data() {
    return {
      loading: true,
      current: 0,
      tabs: [],
      dataList: [],
      isEmpty: _.isEmpty,
      inspectionRecordId: ''
    }
  },
  onLoad(options) {
    this.inspectionRecordId = options.inspectionRecordId
  },
  onShow() {
    this.current = 0
    this.getListData()
  },
  methods: {
    async getListData() {
      try {
        let { data } = await queryListByRecord({
          supervisionInspectionRecordId: this.inspectionRecordId,
          acceptanceStatus: false
        })
        this.loading = false
        this.tabs = data.map(item => {
          return { name: item.checkSpotName }
        })
        this.dataList = data
      } catch (error) {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.check-detail {
  display: flex;
  flex-direction: column;
  .detail-card {
    overflow: auto;
    background: $uni-bg-color-hover;
  }
}
</style>
