<template>
  <view>
    <fui-empty v-if="dataList.length === 0" title="暂无隐患"></fui-empty>
    <view
      class="detail-card-list"
      v-for="(item, index) in dataList"
      :key="index"
    >
      <view class="img-grop">
        <PreviewImage :imgList="item.hiddenImageUrls"></PreviewImage>
      </view>
      <view class="text-box">
        <view class="row">
          <text class="label">隐患描述：</text>
          <text class="val">{{ item.hiddenDesc }}</text>
        </view>
        <view class="row">
          <text class="label">整改建议：</text>
          <text class="val">{{ item.rectificationSuggestions }}</text>
        </view>
        <view class="row">
          <text class="label">法律法规：</text>
          <text class="val">{{ item.lawsRegulations }}</text>
        </view>
      </view>
      <view class="btn"
        ><fui-button
          text="拍照整改"
          height="70rpx"
          size="28"
          :plain="true"
          radius="48rpx"
          type="primary"
          background="#fff"
          color="#465CFF"
          borderColor="#465CFF"
          borderWidth="1"
          @click="toPictureCheckPage(item)"
        ></fui-button
      ></view>
    </view>
  </view>
</template>

<script>
import PreviewImage from '@/components/preview-image/index.vue'
export default {
  props: {
    dataList: Array
  },
  components: {
    PreviewImage
  },

  methods: {
    toPictureCheckPage({ inspectionHiddenDangerId }) {
      uni.navigateTo({
        url: `/pages/homePage/awaitCheck/pictureCheck/index?inspectionHiddenDangerId=${inspectionHiddenDangerId}`
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.detail-card-list {
  display: flex;
  flex-direction: column;
  background: #fff;
  cursor: pointer;
  margin-top: 20rpx;
  padding: 0 30rpx;
  &:first-child {
    margin: 0;
  }
  .img-grop {
    width: 100%;
    margin-top: 50rpx;
  }
  .img {
    height: 100rpx;
    border: 1px solid $uni-border-color;
    flex: 0 0 100rpx;
  }
  .text-box {
    margin-top: 50rpx;
    .row {
      & ~ .row {
        margin-top: 30rpx;
      }
      font-size: 30rpx;
      .label {
        color: #555;
      }
      .val {
        color: #333;
      }
    }
  }
  .btn {
    margin: 50rpx auto;
    width: 410rpx;
  }
}
</style>
