<template>
  <view class="page picture-check">
    <view class="picture-container">
      <fui-upload
        max="99"
        chooseMax="1"
        width="188"
        ref="upload"
        background="#f1f1f1"
        addColor="#d1d1d1"
        confirmDel
        :fileList="fileList"
        @complete="complete($event)"
      ></fui-upload>
    </view>
    <view class="bottom-btn">
      <fui-button
        radius="48rpx"
        @click="submit"
        :loading="submitLoading"
        :disabled="submitLoading"
        >提交检查</fui-button
      >
    </view>
    <fui-toast ref="toast"></fui-toast>
  </view>
</template>

<script>
import { uploadFile } from '@/api/authApi'
import { photoAcceptance } from '@/api/awaitCheck'
import _ from 'lodash'
export default {
  data() {
    return {
      //初始化已上传的图片列表
      fileList: [],
      submitLoading: false,
      inspectionHiddenDangerId: ''
    }
  },
  onLoad(options) {
    this.inspectionHiddenDangerId = options.inspectionHiddenDangerId
  },
  methods: {
    uploadError(e) {
      console.log(e)
    },
    complete(e) {
      if (e.action == 'choose') {
        this.upLoadImg(e)
      } else if (e.action == 'delete') {
        this.deleteImg(e)
      }
    },
    async upLoadImg(e) {
      try {
        let { data } = await uploadFile(e.urls[e.urls.length - 1])
        this.fileList = this.fileList.concat(data)
      } catch (error) {
        this.$refs.upload.urls.pop()
      }
    },
    async deleteImg(e) {
      this.fileList = e.urls
    },
    //提交
    async submit() {
      if (_.isEmpty(this.fileList)) {
        this.$refs.toast.show({ text: '请选择需要上传的图片' })
        return
      }
      try {
        this.submitLoading = true
        await photoAcceptance({
          inspectionHiddenDangerId: this.inspectionHiddenDangerId,
          rectificationImageUrls: this.fileList
        })
        this.submitLoading = false
        this.$refs.toast.show({ text: '提交成功' })
        uni.navigateBack()
      } catch (error) {
        this.submitLoading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.picture-check {
  position: relative;
  display: flex;
  flex-direction: column;
  .picture-container {
    flex: 0 0 calc(100% - 160rpx);
    overflow: hidden auto;
    padding: 0 61rpx;
    margin: 20rpx 0;
    :deep(.fui-upload__wrap) {
      margin-right: -32px;
      .fui-upload__item {
        margin-right: 32rpx;
        margin-bottom: 32rpx;
        background: #fff !important;
        border-radius: 20rpx;
        overflow: hidden;
      }
    }
  }
  .bottom-btn {
    z-index: 11;
    height: 140rpx;
    padding: 0 30rpx;
    width: 100%;
    box-sizing: border-box;
    bottom: 0rpx;
    left: 0;
    position: absolute;
    margin-top: 20rpx;
  }
}
</style>
