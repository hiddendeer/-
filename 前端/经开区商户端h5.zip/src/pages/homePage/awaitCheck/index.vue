<template>
  <view class="page await-check-page">
    <view>
      <view class="select-container">
        <SelectMenu
          class="select-container_item"
          placeholder="按时间筛选"
          :isActive="selectActive"
          :val="formData.dateVal"
          @selectChange="selectChange($event, 'time')"
        ></SelectMenu>
        <SelectMenu
          class="select-container_item"
          placeholder="按行政区域筛选"
          :isActive="areaActive"
          :val="formData.resultRegion"
          @selectChange="selectChange($event, 'area')"
        ></SelectMenu>
      </view>
      <view class="topSearch">
        <view class="searchInput">
          <fui-search-bar
            ref="merchantName"
            height="88"
            radius="50"
            background="#f1f1f1"
            :isLeft="true"
            :cancel="false"
            placeholder="请输入店招名进行模糊搜索"
            @search="search"
            @clear="clear"
          ></fui-search-bar>
        </view>
        <fui-button
          size="30"
          height="80rpx"
          plain
          width="120rpx"
          radius="50rpx"
          borderWidth="2px"
          borderColor="#465CFF"
          color="#465CFF"
          background="#FFFFFF"
          @click="reset"
          >重置</fui-button
        >
      </view>
    </view>
    <fui-loading type="col" text="加载中" isMask v-if="loading"></fui-loading>
    <fui-empty v-if="isEmpty(listData) && !loading"></fui-empty>
    <view class="pageDetail" v-else>
      <scroll-view
        scroll-y
        :scroll-top="scrollYTop"
        @scroll="scroll"
        class="scroll"
      >
        <view
          class="card-list"
          v-for="item in listData"
          :key="item.inspectionRecordId"
          @click="goAwaitCheckDetail(item)"
        >
          <view class="card-list__left">
            <text class="label">店招名：</text>
            <text class="val">{{ item.merchantAliasName }}</text>
            <text class="label">企业名：</text>
            <text class="val">{{ item.merchantName }}</text>
            <text class="label">整改时间：</text>
            <text class="val">{{ item.createTime }}</text>
            <text class="label">检查人：</text>
            <text class="val">{{ item.createUser }}</text>
          </view>
          <fui-icon size="48" name="arrowright" color="#b2b2b2"></fui-icon>
        </view>
      </scroll-view>
    </view>
    <fui-safe-area background="#f1f1f1"></fui-safe-area>
    <fui-bottom-popup
      class="calendar-container"
      :show="showCalendar"
      @close="calendarClose"
    >
      <view class="calendar__wrap">
        <view class="calendar__wrap-title">请选择日期</view>
        <fui-icon
          class="calendar__wrap-icon"
          name="close"
          :size="50"
          @click="calendarClose"
          color="#333"
        ></fui-icon>
        <fui-calendar
          type="3"
          showBtn
          showLunar
          @change="datePickerChange"
        ></fui-calendar>
      </view>
    </fui-bottom-popup>

    <fui-picker
      linkage
      :fields="['orgName', 'orgId', 'children']"
      :layer="2"
      :options="areaOptions"
      :show="showPicker"
      @change="pickerChange"
      @cancel="pickerCancel"
    ></fui-picker>
  </view>
</template>

<script>
import SelectMenu from '@/components/select-menu/index.vue'
import { getExpHrOrgan } from '@/api/awaitCheck.js'
import { queryRecordList } from '@/api/authApi.js'
import { mapState } from 'vuex'
import _ from 'lodash'
export default {
  components: {
    SelectMenu
  },
  data() {
    return {
      loading: true,
      showCalendar: false,
      showPicker: false,
      selectActive: false,
      areaActive: false,
      scrollYTop: 0,
      oldScrollYTop: 0,
      formData: {
        dateVal: '',
        resultRegion: '',
        searchBeginTime: '',
        searchEndTime: '',
        merchantRegion: ''
      },
      areaOptions: [],
      listData: [],
      isEmpty: _.isEmpty
    }
  },
  computed: {
    ...mapState('auth', {
      userId: state => state.userData?.userId || ''
    })
  },
  onLoad(options) {
    this.getAreaData()
  },
  onShow() {
    this.getRecordList()
  },
  methods: {
    scroll(e) {
      this.oldScrollYTop = e.target.scrollTop
    },
    reset() {
      this.formData = this.$options.data().formData
      this.$refs.merchantName.clearInput()
      this.getRecordList()
    },
    async getAreaData() {
      let { data } = await getExpHrOrgan({ startOrgLevel: 4, orgLevel: 5 })
      data.forEach(item => {
        if (!_.isEmpty(item.children)) {
          item.children.unshift({
            orgId: item.orgId,
            orgName: '全部'
          })
        } else {
          item.children = [
            {
              orgId: item.orgId,
              orgName: '全部'
            }
          ]
        }
      })
      this.areaOptions = data
    },
    async getRecordList() {
      this.scrollYTop = this.oldScrollYTop
      this.$nextTick(function () {
        this.scrollYTop = 0
      })
      let { dateVal, resultRegion, ...options } = this.formData
      let params = {
        createUser: this.userId,
        acceptanceStatus: false,
        merchantName: this.$refs.merchantName?.val || '',
        ...options
      }
      try {
        let { data } = await queryRecordList(params)
        this.listData = data
        this.loading = false
      } catch (error) {
        this.loading = false
      }
    },
    selectChange(val, t) {
      if (t === 'time') {
        this.showCalendar = val
        this.selectActive = val
      } else {
        this.showPicker = val
        this.areaActive = val
      }
    },
    datePickerChange({ value }) {
      this.formData.dateVal = value.join('至')
      this.formData.searchBeginTime = value[0] || ''
      this.formData.searchEndTime = value[1] || ''
      this.calendarClose()
      this.getRecordList()
    },
    calendarClose() {
      this.showCalendar = false
      this.selectActive = false
    },
    pickerChange(val) {
      this.formData.resultRegion = val.text[1] || ''
      this.formData.merchantRegion = val.value[1]
      this.pickerCancel()
      this.getRecordList()
    },
    pickerCancel() {
      this.showPicker = false
      this.areaActive = false
    },
    search() {
      this.getRecordList()
    },
    clear() {
      this.getRecordList()
    },
    goAwaitCheckDetail({ inspectionRecordId }) {
      uni.navigateTo({
        url: `/pages/homePage/awaitCheck/awaitCheckDetail/index?inspectionRecordId=${inspectionRecordId}`
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.await-check-page {
  display: flex;
  flex-direction: column;
  overflow: hidden !important;
  .calendar__wrap {
    padding-top: 10rpx;
    position: relative;
    &-title {
      font-size: 30rpx;
      font-weight: 700;
      text-align: center;
      padding: 10rpx;
      color: #333;
    }
    &-icon {
      position: absolute;
      top: 10rpx;
      right: 20rpx;
    }
  }
  .select-container {
    display: flex;
    justify-content: space-between;
    padding: 20rpx 30rpx;
    background: #fff;
    position: relative;
    &:first-child::after {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      content: '';
      width: 1rpx;
      height: 40rpx;
      background: #999999;
    }
    &_item {
      max-width: 48%;
      flex-shrink: 0;
      overflow: hidden;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
  .topSearch {
    margin: 20rpx;
    display: flex;
    align-items: center;
    background: #fff;
    border-radius: 50rpx;
    .searchInput {
      flex: 1;
      :deep(.fui-search__bar-wrap) {
        border-radius: 50rpx !important;
        background: #fff !important;
        padding: 0 !important;
        .fui-search__bar-btn {
          font-size: 30rpx !important;
          border: 0.5rpx solid #465cff;
          border-radius: 50rpx;
          height: 80rpx;
          width: 120rpx;
          box-sizing: initial;
          text-align: center;
          line-height: 76rpx;
        }
      }
    }
    :deep(.fui-button__wrap) {
      margin: 10rpx !important;
    }
  }
  .pageDetail {
    flex: 1;
    overflow: hidden;
    .scroll {
      height: 100%;
    }
    .card-list {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #fff;
      border-radius: 20rpx;
      padding: 30rpx;
      margin: 0 30rpx 30rpx;
      box-shadow: 0rpx 6rpx 20rpx 0rpx rgba(0, 0, 0, 0.15);
      &__left {
        display: grid;
        grid-template-columns: 160rpx 1fr;
        grid-row-gap: 10rpx;
        line-height: 1.5;
        margin: 8rpx 0;
        .label {
          color: #555555;
          font-size: 30rpx;
        }
        .val {
          color: #333333;
          font-size: 30rpx;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
    }
  }

  .fui-safe__area-wrap {
    /* #ifdef H5*/
    flex: none;
    /* #endif */
  }
}
</style>
