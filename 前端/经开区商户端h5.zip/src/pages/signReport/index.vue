<template>
    <div class="body">

        <fui-upload width="305" height="408" delColor="#1d4ad4" :isAdd="!isShow" :isDel="!isShow" name="file"
            background="#FFFFFF" addColor="#d1d1d1" :fileList="fileList" :url="url" ref="upload" @success="success"
            @error="error"></fui-upload>




        <div class="footer">
            <fui-button radius="50rpx" @click="submit">提交</fui-button>
        </div>
    </div>
</template>

<script setup>
import { ref } from "vue";
import { onLoad } from '@dcloudio/uni-app'
const url = '';
const isShow = ref(false);
//上传状态，用于保存或其他操作时做判断
const status = ref('');
//初始化已上传的图片列表
const fileList = ref(['https://res.firstui.cn/static/images/common/logo.png']);
//上传的图片地址列表
const urls = ref([]);

onLoad((params) => {
    isShow.value = params.start == 'true' ? true : false;
    if (isShow.value) {
        uni.setNavigationBarTitle({
            title: '查看签字报告'
        });
    } else {
        uni.setNavigationBarTitle({
            title: '上传签字报告'
        });
    }
})

const success = (e) => {
    console.log(e)
    //上传成功回调，处理服务器返回数据【此处根据实际返回数据进行处理】
    // let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}")
    // this.status = e.status
    // if (res.data.url) {
    //     //处理结果返回给组件 
    //     //data.url为上传成功后返回的图片地址
    //     //e.index为图片索引值
    //     this.$refs.upload.result(res.data.url, e.index)
    // }
}
const error = (e) => {
    status.value = e.status
    uni.showModal({
        content: JSON.stringify(e)
    })
}

const submit = () => {

}


</script>

<style scoped lang="scss">
.body {
    width: 100%;
    height: 100vh;
    background-color: #F4F5F7;
    padding: 30rpx;
    box-sizing: border-box;
    overflow: scroll;
    padding-bottom: 240rpx;

    :deep(.fui-upload__item) {
        margin-right: 40rpx;
        margin-bottom: 20rpx;
        border-radius: 8rpx;
        overflow: hidden;
    }

    .footer {
        width: 100%;
        height: 140rpx;
        position: absolute;
        left: 0;
        bottom: 0;
        background-color: #fff;
        padding: 20rpx;
        box-sizing: border-box;
        padding-bottom: 40rpx;
    }
}
</style>
