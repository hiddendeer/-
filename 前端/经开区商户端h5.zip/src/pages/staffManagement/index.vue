<!-- 商户端我的 -->
<template>
  <div class="page-container bg-[#f4f5f7] text-14px">
    <div class="page-body">
      <div>
        <span class="pr-[15px]">员工数量</span>
        <span>{{ tools.staffList?.length || 0 }} / 3</span>
      </div>
      <div v-if="tools.staffList?.length > 0">
        <div
          v-for="(item, index) in tools.staffList"
          :key="item.id"
          class="bg-white my-[10px] rounded p-[12px]"
        >
          <p class="pb-[8px]">姓名: {{ item?.userName }}</p>
          <p>登录手机号: {{ item?.userPhone }}</p>
          <fui-divider width="100%" height="40"></fui-divider>
          <div class="flex justify-end">
            <fui-button
              text="刪除"
              class="!mr-[10px]"
              borderColor="#FF2B2B"
              background="#fff"
              color="#FF2B2B"
              height="44rpx"
              width="100rpx"
              radius="12rpx"
              size="15"
              plain
              @click="delConfirm(item)"
            />
            <fui-button
              text="修改"
              borderColor="#465CFF"
              background="#fff"
              color="#465CFF"
              height="44rpx"
              width="100rpx"
              radius="12rpx"
              size="15"
              plain
              @click="edit(item)"
            />
          </div>
        </div>
      </div>
      <fui-empty
        v-else
        class=""
        src="/static/empty.png"
        title="您还未添加员工，点击下方添加\n每个商户最多可添加3名员工"
      ></fui-empty>
    </div>
    <div class="mt-[20rpx] flex justify-center">
      <fui-button
        background="#1D4AD4"
        :disabled="tools?.staffList?.length >= 3"
        disabledBackground="#B2B2B2"
        disabledColor="#CCCCCC"
        @click="addStaff"
        height="80rpx"
        width="100%"
        size="28"
        radius="20rpx"
        >添加员工</fui-button
      >
    </div>
  </div>
  <fui-modal
    :show="tools.showDel"
    :buttons="tools.buttons"
    title="提示"
    @click="del"
  >
    确认删除该员工？删除后将无法登录
  </fui-modal>
  <fui-toast ref="toastRef"></fui-toast>
</template>

<script setup>
import api from "./server/api.js";
import { ref, reactive, onMounted } from "vue";

const loading = ref(false);
const toastRef = ref(null);
const tools = reactive({
  showDel: false,
  currentType: "",
  currentId: "",
  staffList: [],
  buttons: [
    {
      //按钮文本，必选
      text: "取消",
      //是否为镂空按钮，即背景色为透明，可选
      plain: true
    },
    {
      //按钮文本，必选
      text: "确认",
      //是否为镂空按钮，即背景色为透明，可选
      plain: false
    }
  ]
});

onMounted(() => {
  init();
});
const init = async () => {
  const res = await api.getList();
  if (res?.code && res.code == "00000") {
    tools.staffList = res?.data || [];
  }
};
const delConfirm = (e) => {
  tools.currentId = e?.id;
  tools.showDel = true;
};
const del = async (e) => {
  tools.showDel = false;
  if (e?.index == 1) {
    const res = await api.delete({ id: tools.currentId });
    if (res?.code && res.code == "00000") {
      init();
      toastRef.value.show({ text: "操作成功" });
    } else {
      toastRef.value.show({ text: res?.message || "操作失败" });
    }
  }
};
const edit = (e) => {
  tools.currentType = "edit";
  uni.navigateTo({
    url: `/pages/staffManagement/addStaff?id=${e?.id}&name=${e?.userName}&phone=${e?.userPhone}`
  });
};
// 添加员工
const addStaff = () => {
  tools.currentType = "add";
  uni.navigateTo({
    url: `/pages/staffManagement/addStaff?type=${tools.currentType}`
  });
};
</script>

<style lang="scss" scoped>
.page-container {
  height: 100vh;
  overflow: auto !important;
  padding: 15px;
}
.page-body {
  height: calc(100vh - 160rpx);
  overflow: auto;
}
:deep(.fui-empty__title) {
  padding: 30px 50px !important;
}
</style>
