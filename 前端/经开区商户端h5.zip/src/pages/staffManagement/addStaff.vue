<!-- 商户端我的 -->
<template>
  <div class="page-container">
    <div class="page-body">
      <fui-form
        ref="formRef"
        v-model="formData"
        class="mt-[5px] bg-white rounded-[5px]"
      >
        <fui-form-item
          class="!py-[4px]"
          borderColor="#ddd"
          labelWidth="180"
          asterisk
          label="员工姓名:"
        >
          <fui-input
            :borderBottom="false"
            maxlength="20"
            v-model="formData.userName"
            placeholder="请输入员工姓名"
          ></fui-input>
        </fui-form-item>
        <fui-form-item
          class="!py-[4px]"
          borderColor="#ddd"
          labelWidth="180"
          asterisk
          label="登录手机号:"
          :bottomBorder="false"
        >
          <fui-input
            :borderBottom="false"
            maxlength="11"
            v-model="formData.userPhone"
            placeholder="请输入11位手机号"
          ></fui-input>
        </fui-form-item>
      </fui-form>
    </div>
    <div class="mt-[20rpx] flex justify-center">
      <fui-button
        @click="save"
        height="80rpx"
        width="100%"
        size="28"
        radius="20rpx"
        >保存</fui-button
      >
    </div>
  </div>
  <fui-toast ref="toastRef"></fui-toast>
</template>

<script setup>
import api from "./server/api.js";
import { ref, reactive, onMounted } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const loading = ref(false);
const toastRef = ref(null);
const formRef = ref(null);
const formData = ref({
  userName: "",
  userPhone: "",
  id: ''
});
const tools = reactive({});

const validateCode = (value) => {
  let flag = true;
  const text = /^[\u4e00-\u9fa5a-zA-Z]+$/;
  if (!text.test(value)) {
    flag = false;
  }
  return flag;
};
const rules = reactive([
  {
    name: "userName",
    rule: ["required", "maxLength: 20"],
    msg: ["请输入员工姓名", "可输入最大长度为20"],
    validator: [{ msg: "员工姓名仅允许输入汉字及大小写字母", method: validateCode }],
  },
  {
    name: "userPhone",
    rule: ["required", "isMobile"],
    msg: ["请输入登录手机号", "请输入正确格式的手机号"],
  },
]);

onMounted(() => {
  tools.type = route.query?.type
  formData.value.userName = route.query?.name || ''
  formData.value.userPhone = route.query?.phone || ''
  formData.value.id = route.query?.id || ''
  if (tools.type == 'add') {
    uni.setNavigationBarTitle({
      title: "添加员工",
    });
  } else {
    uni.setNavigationBarTitle({
      title: "修改信息",
    });
  }
});

// 添加员工
const save = async () => {
  formRef.value.validator(formData.value, rules).then(res => {
    if (res.isPassed) {
      let params = formData.value;
      let apiName = 'edit'
      if (tools.type == 'add') {
        delete params?.id;
        apiName = 'add'
      }
      api[apiName](params).then(res1 => {
        if (res1?.code && res1?.code == '00000') {
          // uni.navigateBack();
          uni.navigateTo({
            url: "/pages/staffManagement/index",
          });
        } else {
          // toastRef.value.show({text: res1?.message || '操作失败'})
        }
      }).catch(error => {
        console.log(error)
      })
    }
  }).catch(err => {
    console.log(err)
  })
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: 100vh;
  overflow: auto !important;
  padding: 15px;
}
:deep(.fui-form__item-sizing) {
  font-size: 14px !important;
}
:deep(.fui-input__placeholder) {
  font-size: 14px !important;
}
:deep(.uni-input-input) {
  font-size: 14px !important;
}
.page-body {
  height: calc(100vh - 160rpx);
  overflow: auto;
}
:deep(.fui-form__item-bottom) {
  right: 16px !important;
}
</style>
