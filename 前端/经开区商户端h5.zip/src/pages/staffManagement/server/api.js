import http from '@/utils/network.js'

export default class api {
  // 员工列表
  static getList(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/manage/staff/list',
      method: 'GET',
      data
    })
  }
  // 员工添加
  static add(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/manage/staff/add',
      method: 'POST',
      data
    })
  }
  // 员工编辑
  static edit(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/manage/staff/edit',
      method: 'POST',
      data
    })
  }
  // 员工删除
  static delete(data) {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/manage/staff/delete',
      method: 'POST',
      data
    })
  }
}

