<template>
    <div class="body">
        <fui-sticky>
            <div class="header flex justify-between algin-center">
                <fui-tabs :current="currentIndex" @change="change" :tabs="tabs" :short="false"></fui-tabs>
                <fui-icon style="padding:0 40rpx;" name="screen" @click="(showSide = true)"></fui-icon>
            </div>
        </fui-sticky>
        <div class="content">
            <div class="box" v-for="item in list" :key="item.id">
                <div class="box_row flex">
                    <p>检查内容:</p>
                    <p>{{ (item.name ?? item.name) }}</p>
                </div>
                <div class="box_row flex">
                    <p>店招名:</p>
                    <p>{{ (item.shopName ?? item.shopName) }}</p>
                </div>
                <div class="box_row flex">
                    <p>检查人:</p>
                    <p>{{ (item.checkPresion ?? item.checkPresion) }}</p>
                </div>
                <div class="box_row flex">
                    <p>检查时间:</p>
                    <p>{{ (item.checkTime ?? item.checkTime) }}</p>
                </div>


                <p class="line"></p>
                <div class="box_footer">
                    <div class="box_footer_right">
                        <fui-button class="border_right" v-if="currentIndex == 0" plain color="#666666" text="删除"
                            @click="(showModal = true)"></fui-button>
                        <fui-button v-if="currentIndex == 0" plain color="#1D4AD4" text="编辑"></fui-button>

                        <!-- <fui-button v-if="currentIndex != 0" plain color="#1D4AD4"
                            @click="handleOrder('signReport', false)" text="上传签字报告"></fui-button> -->
                        <fui-button v-if="currentIndex != 0" plain color="#1D4AD4" @click="handleOrder('signReport', true)"
                            text="查看签字报告"></fui-button>
                        <fui-button class="border_left" v-if="currentIndex != 0" plain color="#1D4AD4"
                            @click="handleOrder('checkList')" text="查看"></fui-button>
                    </div>
                </div>
                <div class="box_state">
                    已审核
                </div>
            </div>
        </div>
    </div>
    <fui-drawer :show="showSide" @close="(showSide = false)">
        <div scroll-y class="fui-scroll__view">
            <view class="sideBar">
                <fui-input placeholder="搜索店招名或任务名称" backgroundColor="#F4F5F7" isFillet inputBorder
                    v-model="searchParams.searchInput"></fui-input>
                <div class="sideBar_time">
                    <p>
                        按时间检索搜索
                    </p>
                    <fui-list-cell @click="(searchParams.showTimer = true)">
                        <view class="fui-align__center">
                            <fui-icon name="calendar" @click="(showSide = true)"></fui-icon>
                        </view>
                        <text class="fui-text__explain">{{ searchParams.startTime ? searchParams.startTime : '请选择时间区间'
                        }}</text>
                    </fui-list-cell>
                    <fui-list-cell @click="(searchParams.showTimer = true)">
                        <view class="fui-align__center">
                            <fui-icon name="calendar" @click="(showSide = true)"></fui-icon>
                        </view>
                        <text class="fui-text__explain">{{ searchParams.endTime ? searchParams.endTime : '请选择时间区间'
                        }}</text>
                    </fui-list-cell>
                </div>
                <div class="sideBar_time">
                    <p>
                        按审核状态
                    </p>
                    <p class="time_color tabs">
                        <fui-tabs :current="searchParams.stateIndex" :tabs="searchParams.state"
                            @change="changeSearchTabs"></fui-tabs>
                    </p>
                </div>
            </view>
            <div class="sideBar_footer">
                <fui-button text="重置" color="#333" plain @click="reset"></fui-button>
                <fui-button text="搜索" @click="handleSearch"></fui-button>
            </div>
        </div>
    </fui-drawer>
    <fui-modal :show="showModal" color="#000" descr="当前检查还在检查中,确定要删除吗?" maskClosable @click="(showModal = false)"
        @cancel="(showModal = false)"></fui-modal>

    <fui-date-picker range :value="searchParams.timer" :show="searchParams.showTimer" type="3" @change="changeTimer"
        @cancel="cancelTimer">
    </fui-date-picker>
</template>

<script setup>
import { ref, reactive } from "vue";

const showSide = ref(false);
const showModal = ref(false);
const currentIndex = ref(0);
const tabs = ref(['检查中', '已提交']);
const list = ref([
    {
        id: 1,
        name: '冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查冬季检查',
        shopName: '麦当劳（雪浪小镇店）',
        checkPresion: '张三',
        checkTime: '2000-12-8 20:20:20',
    },
    {
        id: 2,
        name: '任务名称2',
        shopName: '店招名',
        checkPresion: '张三',
        checkTime: '2000-12-8 20:20:20',
    },
    {
        id: 3,
        name: '任务名称3',
        shopName: '店招名',
        checkPresion: '张三',
        checkTime: '2000-12-8 20:20:20',
    },
    {
        id: 4,
        name: '任务名称4',
        shopName: '店招名',
        checkPresion: '张三',
        checkTime: '2000-12-8 20:20:20',
    },
])
const searchParams = reactive({
    searchInput: '',
    timer: '2022-12-8',
    startTime: '',
    endTime: '',
    showTimer: false,
    stateIndex: '',
    state: ['待审核', '已审核', '已完成']
})
//重置
const reset = () => {
    searchParams.searchInput = '';
    searchParams.startTime = '';
    searchParams.endTime = '';
    searchParams.stateIndex = '';
}
//搜索
const handleSearch = () => {
    let obj = {};
    obj.searchInput = searchParams.searchInput;
    obj.startTime = searchParams.startTime;
    obj.endTime = searchParams.endTime;
    obj.stateIndex = searchParams.stateIndex;
    console.log(obj);
}
const changeTimer = (e) => {
    searchParams.showTimer = false
    console.log(e.startDate.result);
    searchParams.startTime = e.startDate.result;
    searchParams.endTime = e.endDate.result;
}
const cancelTimer = () => {
    searchParams.showTimer = false
}
const change = (e) => {
    currentIndex.value = e.index;
}
const changeSearchTabs = (e) => {
    searchParams.stateIndex = e.index;
}
// 查看检查表
const handleOrder = (val, state) => {
    uni.navigateTo({
        url: `/pages/${val}/index?start=${state}`
    })
}
</script>

<style scoped lang="scss">
.header {
    margin: 20rpx 0;
    background-color: #F4F5F7 !important;
}


:deep(.fui-tabs__scrollbox) {
    background-color: #F4F5F7 !important;
}



.content {
    width: 100%;
    height: auto;
    padding: 0rpx 20rpx;
    box-sizing: border-box;
    padding-top: 10rpx;

    .box {
        width: 100%;
        background-color: #fff;
        border-radius: 10rpx;
        margin-bottom: 20rpx;
        padding: 20rpx;
        padding-top: 40rpx;
        box-sizing: border-box;
        font-size: 30rpx;
        color: #333333;
        overflow: hidden;
        position: relative;

        .box_state {
            position: absolute;
            right: 0;
            top: 0;
            border-radius: 0rpx 10rpx 0rpx 10rpx;
            background-color: red;
            color: #fff;
            text-align: center;
            width: 100rpx;
            height: 50rpx;
            line-height: 50rpx;
            font-size: 24rpx;
        }

        .border_right {
            border-radius: 0rpx !important;
            border-right: 1rpx solid #eee;
        }

        .border_left {
            border-radius: 0rpx !important;
            border-left: 1rpx solid #eee;
        }

        .box_row {
            margin: 20rpx 0;

            p {
                min-width: 160rpx;
                color: #666;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        }

        .box_row :nth-last-child(1) {
            margin-left: 10rpx;
            color: #000;
        }

        .line {
            width: 100%;
            background-color: #eee;
            height: 2rpx;

            margin: 10rpx 0rpx;
        }

        .box_footer {
            width: 100%;
            height: 100rpx;

            .box_footer_right {
                width: 100%;
                height: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;

                :deep(.fui-button__wrap) {
                    height: 60rpx !important;
                }

                :deep(.fui-button) {
                    height: 60rpx !important;
                }
            }
        }
    }
}

:deep(.fui-drawer__popup-wrap) {
    z-index: 1000 !important;

    .fui-drawer__popup {
        border-radius: 24rpx 0rpx 0rpx 24rpx;
    }
}

:deep(.fui-date__picker-content) {
    z-index: 1001 !important;
}

:deep(.fui-date__picker-header) {
    box-shadow: 0rpx -10rpx 20rpx 1rpx rgba(0, 0, 0, 0.15) !important;
}

.fui-scroll__view {
    z-index: 1000;
    width: 550rpx;
    height: 100%;
    // flex: 1;
    overflow: hidden;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    background-color: #fff;

}

.sideBar {
    width: 100%;
    height: auto;
    background-color: #fff;

    padding: 104rpx 32rpx 32rpx;
    box-sizing: border-box;
}

.sideBar_time {
    width: 100%;
    background-color: #fff;
    margin: 40rpx 0rpx;
    border-radius: 40rpx;
    padding: 20rpx;
    box-sizing: border-box;

    :deep(.fui-list__cell) {
        padding: 0rpx !important;
        // margin-bottom: 20rpx;
    }

    :deep(.fui-tabs__scrollbox) {
        background-color: #fff !important;
    }

    p {
        width: 100%;
        height: 60rpx;
        line-height: 60rpx;
        font-size: 32rpx;
        margin-bottom: 30rpx;
    }

    .time_color {
        font-weight: 500;
    }

    .tabs {
        height: auto;
    }

    :deep(.fui-tabs__ac-line) {
        display: none;
    }

    :deep(.fui-tabs__text) {
        height: 50rpx;
        border-radius: 10rpx;
        line-height: 50rpx;
        padding: 10rpx;
        color: #666666 !important;
        border: 2rpx solid #DDDDDD;
    }

    :deep(.fui-tabs__item) {
        padding: 0;
    }

    :deep(.fui-tabs__selected-color) {
        color: #1D4AD4 !important;
        height: 50rpx;
        border-radius: 10rpx;
        line-height: 50rpx;
        padding: 10rpx;
        border: 2rpx solid #1D4AD4;
    }
}

.sideBar_footer {
    width: 100%;
    display: flex;
    align-items: center;
    margin-bottom: 40rpx;

    :deep(.fui-button) {
        width: 100% !important;
    }
}



.body {
    width: 100%;
    height: 100vh;
    background-color: #F4F5F7;
    overflow-y: scroll;
    box-sizing: border-box;
    padding-bottom: 100rpx;
}



.showTab {
    width: 100%;
    height: 40rpx;
    font-size: 32rpx;
    padding: 0rpx 40rpx;
    box-sizing: border-box;
    text-align: right;
    color: #555;
    margin: 10rpx 0rpx;
}
</style>
