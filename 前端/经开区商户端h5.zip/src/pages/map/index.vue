<template>
  <div class="page-container">
    <div class="flex justify-end"></div>
    <div id="mapID" class="w-[100vw] h-[60vh]"></div>
    <div class="flex justify-center">
      <div class="h-[60rpx] pt-[80rpx] w-[45%]">
        <fui-button
          @click="submit"
          background="#07C160"
          height="60rpx"
          radius="96rpx"
          >点击保存</fui-button
        >
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import { onLoad } from "@dcloudio/uni-app";
import {
  transformFromGCJToWGS,
  transformFromWGSToGCJ,
} from "../../utils/gps.js";

onLoad((e) => {
  if (e.latitude && e.longitude) {
    const mapObj = transformFromWGSToGCJ(e.latitude, e.longitude);
    initData(mapObj.latitude, mapObj.longitude);
  } else {
    initData();
  }

  // emitsData.value.longitude = e.longitude;
  // emitsData.value.latitude = e.latitude;
  // initData();
});

const MapData = {
  markerLayer: null,
  Map: null,
};

const emitsData = ref({
  longitude: "",
  latitude: "",
});

const initData = (latitude = "", longitude = "") => {
  let en = window.navigator.userAgent.toLowerCase();
  // 是否微信
  if (en.match(/MicroMessenger/i) == "micromessenger") {
    uni.getLocation({
      type: "gcj02",
      timeout: 1,
      success: function (res) {
        emitsData.value.longitude = longitude || res.longitude;
        emitsData.value.latitude = latitude || res.latitude;
        getMapData();
      },
      fail: function (e) {
        console.log(e);
      },
    });
  } else if (en.match(/lxapp/i) == "lxapp") {
    window.ls.location(
      {
        type: "gcj02",
      },
      function (res) {
        const mapRes = JSON.parse(JSON.stringify(res));
        emitsData.value.longitude = longitude || mapRes.data.longitude;
        emitsData.value.latitude = latitude || mapRes.data.latitude;
        getMapData();
      }
    );
  } else {
    uni.getLocation({
      type: "gcj02",
      isHighAccuracy: true,
      highAccuracyExpireTime: 500000,
      altitude: true,
      success: function (res) {
        emitsData.value.longitude = longitude || res.longitude;
        emitsData.value.latitude = latitude || res.latitude;
        getMapData();
      },
      fail: function (e) {
        console.log(e);
      },
    });
  }
};

// 初始化地图
const getMapData = () => {
  let lng, lat;
  if (MapData.latitude == "" && MapData.longitude == "") {
    lat = 31.491301;
    lng = 120.312309;
  } else {
    lng = emitsData.value.longitude;
    lat = emitsData.value.latitude;
  }
  let center = new TMap.LatLng(lat, lng);
  //定义map变量，调用 TMap.Map() 构造函数创建地图
  MapData.Map = new TMap.Map(document.getElementById("mapID"), {
    center: center, //设置地图中心点坐标
    zoom: 14, //设置地图缩放级别
    pitch: 0, //设置俯仰角
    rotation: 0, //设置地图旋转角度
  });

  //初始化marker图层
  MapData.markerLayer = new TMap.MultiMarker({
    map: MapData.Map,
    //点标记数据数组
    styles: {
      //创建一个styleId为"myStyle"的样式（styles的子属性名即为styleId）
      myStyle: new TMap.MarkerStyle({
        width: 25, // 点标记样式宽度（像素）
        height: 35, // 点标记样式高度（像素）
        // "src": '../img/marker.png',  //图片路径
        //焦点在图片中的像素位置，一般大头针类似形式的图片以针尖位置做为焦点，圆形点以圆心位置为焦点
        anchor: { x: 16, y: 32 },
      }),
    },
    geometries: [
      {
        id: "makerId", //点标记唯一标识，后续如果有删除、修改位置等操作，都需要此id
        styleId: "myStyle", //指定样式id
        position: center, //点标记坐标位置
      },
    ],
  });

  MapData.Map.on("click", (e) => {
    MapData.markerLayer.updateGeometries([
      {
        id: "makerId",
        styleId: "myStyle", //指定样式id
        position: e.latLng, //点标记坐标位置
      },
    ]);
    // https://segmentfault.com/a/1190000042204050?sort=votes GCJ-02(高德) BD-09(百度) WGS-84(谷歌)坐标系之间的转换
    let obj = transformFromGCJToWGS(e.latLng.lat, e.latLng.lng);
    emitsData.value.longitude = obj.longitude;
    emitsData.value.latitude = obj.latitude;
  });
};

// 保存
const submit = () => {
  uni.$emit("mapObj", emitsData.value);
  uni.navigateBack({
    delta: 1,
  });
};
</script>

<style lang="scss" scoped>
.page-container {
  background: #f4f5f7;
  height: calc(100vh);
}
</style>