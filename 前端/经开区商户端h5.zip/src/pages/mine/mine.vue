<!-- 商户端我的 -->
<template>
  <div class="page-container">
    <div class="page-body">
      <fui-preview :previewData="preViewData" v-if="!tools.edit" />
      <fui-form ref="formRef" v-model="formData" class="mt-[5px] bg-white rounded-[5px]" v-if="tools.edit == true">
        <fui-form-item borderColor="#ddd" labelWidth=280 :asterisk="tools.edit" label="统一社会信用代码:">
          <fui-input :borderBottom="false" disabled v-model="formData.unifiedCreditCode"
            maxlength="18"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=135 :asterisk="tools.edit" label="店招名:">
          <fui-input :borderBottom="false" :disabled="!tools.edit"
            v-model="formData.merchantAliasName" maxlength="100"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=135 :asterisk="tools.edit" label="企业名:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="100"
            v-model="formData.merchantName"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit" label="注册地址:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="100"
            v-model="formData.registerAddress"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit" label="经营地址:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="100"
            v-model="formData.businessAddress"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=100 label="坐标:">
          <div class="flex">
            <fui-input :bottomLeft="0" placeholder="经度" disabled v-model="formData.longitude"></fui-input>
            <span class="mx-[10px] font-bold">:</span>
            <fui-input :bottomLeft="0" placeholder="纬度" disabled v-model="formData.latitude"></fui-input>
            <fui-button width="90%" height="48rpx" :size="28" v-if="tools.edit" @click="handleMap">拾取坐标</fui-button>
          </div>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=280 :asterisk="tools.edit" label="企业法人/负责人:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="100"
            v-model="formData.merchantLegalPerson"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit" label="联系方式:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="11"
            v-model="formData.legalPhone"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=200 label="企业联系人:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="100"
            v-model="formData.merchantContactPerson"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=250 label="企业联系人手机:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="11"
            v-model="formData.contactPhone"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 label="固定电话:">
          <div class="flex">
            <fui-input :bottomLeft="0" placeholder="请输入区号" v-model="formData.fixPhoneArea" minLength="3" maxlength="4" />
            <span class="mx-[10px] font-bold">-</span>
            <fui-input :bottomLeft="0" placeholder="请输入座机号码" v-model="formData.fixPhoneNum" minLength="7" maxlength="8" />
          </div>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=100 :asterisk="tools.edit" label="行业:"
          @click="openSelect(2)">
          <span style="font-size: 16px;">{{ handleList(formData.industryList, 'dictName') }}</span>
          <fui-select :show="tools.showSelect" :options="tools.industryList" title="请选择行业" multiple isReverse
            closeColor="#6D758A" @confirm="onConfirm" @close="onClose" />
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit" label="经营范围:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="200"
            v-model="formData.businessRange"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 label="主营业务:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="200"
            v-model="formData.mainBusiness"></fui-input>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=220 :asterisk="tools.edit" label="重点监管领域:"
          @click="openCascaser">
          <span style="font-size: 16px">{{ handleList(tools.adminSupervisionList, 'supervisionAreasName') }}</span>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 label="所属网格:" :asterisk="tools.edit"  @click="openGrid">
          <span style="font-size: 16px">{{ formData?.gridInfo?.gridFullName }}</span>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit" label="商户状态:">
          <span style="font-size: 16px;">{{ handleText(formData?.merchantStatus, 'statusList') }}</span>
        </fui-form-item>
        <fui-form-item borderColor="#ddd" labelWidth=160 :asterisk="tools.edit || tools.add" label="商户类型:">
          <span style="font-size: 16px;">{{ handleText(formData?.merchantType, 'typeList') }}</span>
        </fui-form-item>
        <fui-form-item borderColor="#fff" labelWidth=100 label="备注:">
          <fui-input :borderBottom="false" :disabled="!tools.edit" maxlength="200"
            v-model="formData.remark"></fui-input>
        </fui-form-item>
      </fui-form>
      <div class="p-[20rpx] flex justify-center bg-[#fff]" :class="tools.edit ? 'justify-around' : ''" v-if="preViewData?.list?.length > 0">
        <fui-button height="70rpx" width="200rpx" size="28" radius="96rpx" background="#fff" color="#465CFF" borderColor="#465CFF" v-if="!tools.edit" @click="clickEdit">编辑信息</fui-button>
        <fui-button height="70rpx" width="200rpx" size="28" radius="96rpx" background="#fff" color="#FF2B2B" borderColor="#FF2B2B" v-if="tools.edit" @click="cancel">取消</fui-button>
        <fui-button height="70rpx" width="200rpx" size="28" radius="96rpx" background="#fff" color="#465CFF" borderColor="#465CFF" v-if="tools.edit" @click="saveEdit">保存信息</fui-button>
      </div>
      <div class="mt-[15rpx]">
        <fui-list-cell :bottomBorder="false" arrow @click="jumpQrcode">
          <div class="flex justify-between w-full">
          <text class="text-28rpx">商户码</text>
          <text class="fui-text__explain">查看</text>
          </div>
        </fui-list-cell>
        <fui-list-cell  :bottomBorder="false" arrow @click="handleInto">
          <div class="flex  justify-between w-full">
            <text class="text-28rpx">我的消息</text>
            <text class="fui-text__explain">查看</text>
          </div>
        </fui-list-cell>
        <fui-list-cell  :bottomBorder="false" arrow @click="handleStaff">
          <div class="flex  justify-between w-full">
            <text class="text-28rpx">员工管理</text>
            <text class="fui-text__explain">设置</text>
          </div>
        </fui-list-cell>
      </div>
      <div class="mt-[20rpx] mb-[40rpx] flex justify-center">
        <fui-button
          @click="triggerLoginOut"
          height="80rpx"
          width="400rpx"
          size="28"
          radius="96rpx"
          >退出登录</fui-button
        >
      </div>
    </div>
  </div>
  <fui-bottom-popup :show="tools.showGrid" @close="closeGrid">
    <view class="fui-scroll__wrap">
      <view class="text-center font-bold m-[12px] color-[#181818]" style="font-size: 16px">选择所属网格</view>
      <scroll-view scroll-y class="fui-scroll__view">
        <cascader :options="tools.gridOptions" @change="changeGrid" @complete="completeGrid"></cascader>
      </scroll-view>
      <view class="fui-icon__close" @tap="closeGrid">
        <fui-icon name="close" :size="48"></fui-icon>
      </view>
      <view class="p-[15px]">
        <fui-button radius="96rpx" @click="saveGrid">保存</fui-button>
      </view>
    </view>
  </fui-bottom-popup>
  <!-- 重点监管领域 级联 -->
  <fui-bottom-popup :show="tools.showCascader" @close="closeCascader">
    <view class="fui-scroll__wrap">
      <view class="text-center font-bold m-[12px] color-[#181818]" style="font-size: 16px">选择重点监管领域</view>
      <scroll-view scroll-y class="fui-scroll__view">
        <div class="cas-list px-[15px]">
          <fui-tag v-for="(item, index) in adminSupervisionListCopy" :key="item.supervisionAreasId"
            :text="item.supervisionAreasName" theme="light" @click="delCascader(item, index)">
            <fui-icon name="close" :size="32" color="#1D4AD4" class="ml-[8px]"></fui-icon>
          </fui-tag>
        </div>
        <cascader :options="tools.casCaderOptions" @complete="complete"></cascader>
      </scroll-view>
      <view class="fui-icon__close" @tap="closeCascader">
        <fui-icon name="close" :size="48"></fui-icon>
      </view>
      <view class="p-[15px]">
        <fui-button radius="96rpx" @click="saveCascader">保存</fui-button>
      </view>
    </view>
  </fui-bottom-popup>
  <fui-toast ref="toastRef"></fui-toast>
</template>

<script setup>
import api from "./server/api.js";
import commonApi from '@/api/commonApi';
import cascader from './components/cascader';
import { ref, reactive, onMounted } from "vue";
import { onLoad, onShow } from "@dcloudio/uni-app";

const loading = ref(false);
const toastRef = ref(null);
// const formData = ref({});
const preViewData = ref({});
const qrcodeUrl = ref("");
const statusList = ref([]);
const adminSupervisionListCopy = ref([]);
const tools = reactive({
  edit: false,
  showCascader: false,
  showGrid: false,
  showSelect: false,
  statusList: [],
  typeList: [],
  industryList: [],
  casCaderOptions: [],
  gridOptions: [],
  adminSupervisionList: [],
});
const formRef = ref(null);
const formData = ref({
  unifiedCreditCode: '',
  merchantAliasName: '',
  merchantName: '',
  registerAddress: '',
  businessAddress: '',
  merchantLegalPerson: '',
  legalPhone: '',
  merchantContactPerson: '',
  contactPhone: '',
  fileList: [],
  longitude: '', //120.31205187390617
  latitude: '', //31.4907894002759
  fixPhoneArea: '',
  fixPhoneNum: '',
  businessRange: '',
  mainBusiness: '',
  gridName: '',
  merchantStatus: '', // 1602934097288695809
  merchantType: '',
  industryList: '',
  remark: ''
});
const validateName = (value) => {
  let flag = true;
  let regexStr = /^[0-9a-zA-Z一-龟-(：，。；：、-（）,.【】;:-@#￥%！~*&？)]*$/
  if (!regexStr.test(value)) {
    flag = false;
  }
  return flag;
}
const validateAddress = (value) => {
  let flag = true;
  const text = /^[\u4e00-\u9fa5\-\（）(.)0-9a-zA-Z]+$/;
  if (!text.test(value)) {
    flag = false;
  }
  return flag;
}
const validateAddressAddS = (value) => {
  let flag = true;
  const text = /^[\u4e00-\u9fa5\-\（）(.)0-9a-zA-Z\s]+$/;
  if (!text.test(value)) {
    flag = false;
  }
  return flag;
}
const validateCode = (value) => {
  let flag = true;
  const text = /^[A-Z0-9]+$/;
  if (!text.test(value)) {
    flag = false;
  } else {
    let arr = ['I', 'O', 'Z', 'S', 'V'];
    arr.forEach(it => {
      if (value.search(it) != -1) {
        flag = false;
      }
    })
  }
  return flag;
}
const rules = reactive([
  {
    name: "merchantAliasName", rule: ["required", "maxLength: 100"], msg: ["请输入店招名", "店招名最大输入长度为100"],
    validator: [{ msg: '店招名不可输入特殊符号', method: validateName }]
  },
  {
    name: "merchantName", rule: ["required", "maxLength: 100"], msg: ["请输入企业名", "企业名最大输入长度为100"],
    validator: [{ msg: '企业名不可输入特殊符号', method: validateName }]
  },

  {
    name: "registerAddress", rule: ["required", "maxLength: 100"], msg: ["请输入注册地址", "注册地址最大输入长度为100"],
    validator: [{ msg: '注册地址不可输入特殊符号', method: validateAddressAddS }]
  },
  {
    name: "businessAddress", rule: ["required", "maxLength: 100"], msg: ["请输入经营地址", "经营地址最大输入长度为100"],
    validator: [{ msg: '经营地址不可输入特殊符号', method: validateAddressAddS }]
  },
  {
    name: "merchantLegalPerson", rule: ["required", "maxLength: 100"], msg: ["请输入企业法人/负责人", "企业法人/负责人最大输入长度为100"],
    validator: [{ msg: '企业法人/负责人不可输入特殊符号', method: validateAddress }]
  },
  { name: "legalPhone", rule: ["required", "isMobile"], msg: ["请输入企业法人/负责人联系方式", "请输入正确格式的联系方式"] },
  {
    name: "merchantContactPerson", rule: ["maxLength: 100"], msg: ["企业联系人最大输入长度为100"],
    validator: [{ msg: '企业联系人不可输入特殊符号', method: validateName }]
  },
  { name: "contactPhone", rule: ["isMobile"], msg: ["请输入正确格式的联系方式"], },
  { name: "fixPhoneArea", rule: ["isNumber", "minLength: 3"], msg: ["请输入正确格式的区号", "请输入正确格式的区号"], },
  { name: "fixPhoneNum", rule: ["isNumber", "minLength: 7"], msg: ["请输入正确格式的座机号码", "请输入正确格式的座机号码"], },
  { name: "industryList", rule: ["required"], msg: ["请选择行业"], },
  {
    name: "businessRange", rule: ["required", "maxLength: 200"], msg: ["请输入经营范围", "经营范围最大输入长度为200"],
    validator: [{ msg: '经营范围不可输入特殊符号', method: validateName }]
  },
  { name: "gridName", rule: ["required"], msg: ["请选择所属网格"] },
  {
    name: "mainBusiness", rule: ["maxLength: 200"], msg: ["主营业务最大输入长度为200"],
    validator: [{ msg: '主营业务不可输入特殊符号', method: validateName }]
  }
])

onLoad(() => {
  uni.$on('mapObj', (data) => {
    if (data?.latitude && data?.longitude) {
      formData.value.latitude = data?.latitude;
      formData.value.longitude = data?.longitude;
    }
  })

})
onMounted(() => {
  formData.value.adminSupervisionList = []
  tools.adminSupervisionListCopy = []
  adminSupervisionListCopy.value = []
  queryDetail();
  getDicList("Merchant", "statusList"); // 商户状态
  getDicList("shlx", "typeList"); // 商户类型
  getDicList("industry", "industryList"); // 行业
  getSupervise();
  getAllTree();
});

const queryDetail = async () => {
  const dicRes = await commonApi.getDicList({ dictTypeCode: 'Merchant' });
  if (dicRes?.code && dicRes?.code == '00000') {
    statusList.value = dicRes?.data ?? [];
  }
  const res = await api.getMerchantInfo();
  if (res?.code && res.code == "00000") {
    formData.value = res?.data;
    tools.adminSupervisionList = res?.data?.adminSupervisionList
    adminSupervisionListCopy.value = formData.value?.adminSupervisionList;
    if (!res?.data?.fixPhoneArea) formData.value.fixPhoneArea = '';
    if (!res?.data?.fixPhoneNum) formData.value.fixPhoneNum = '';
    if (!res?.data?.mainBusiness) formData.value.mainBusiness = '';
    // 行业数据处理
    const industryList = formData.value?.industryList.map(
      (item) => item.dictName
    ) || [];
    const industryStr = industryList?.join(",") || '';
    formData.value.industryIdList = [];
    formData.value?.industryList?.forEach(item => {
      formData.value.industryIdList.push(item.dictId);
    })
    const adminSupervisionList = formData.value.adminSupervisionList.map(
      (item) => item.supervisionAreasName
    );
    let merchantStatus = ''
    if (formData.value?.merchantStatus) {
      merchantStatus = statusList.value?.find(it => it.dictId == formData.value?.merchantStatus)?.dictName
    }
    const adminSupervisionStr = adminSupervisionList.join("，");
    formData.value.gridName = formData.value?.gridInfo?.gridFullName;
    preViewData.value.list = [
      { label: "统一社会信用代码:", value: formData.value?.unifiedCreditCode },
      { label: "店招名:", value: formData.value?.merchantAliasName },
      { label: "企业名:", value: formData.value?.merchantName },
      { label: "注册地址:", value: formData.value?.registerAddress },
      { label: "经营地址:", value: formData.value?.businessAddress },
      { label: "坐标:", value: formData.value?.longitude ? (formData.value?.longitude + '  -  ' + formData.value?.latitude) : ''},
      { label: "企业法人/负责人:", value: formData.value?.merchantLegalPerson },
      { label: "联系方式:", value: formData.value?.legalPhone },
      { label: "企业联系人:", value: formData.value?.merchantContactPerson },
      { label: "企业联系人手机:", value: formData.value?.contactPhone },
      { label: "固定电话:", value: formData.value?.fixPhoneArea ? (formData.value?.fixPhoneArea + '  -  ' + formData.value?.fixPhoneNum) : '' },
      { label: "行业:", value: industryStr },
      { label: "经营范围:", value: formData.value?.businessRange },
      { label: "主营业务:", value: formData.value?.mainBusiness },
      { label: "重点监管领域:", value: adminSupervisionStr },
      { label: "所属网格:", value: formData.value?.gridInfo?.gridFullName },
      { label: "商户状态:", value: merchantStatus },
      { label: "商户类型:", value: formData.value?.merchantTypeName },
      { label: "备注:", value: formData.value?.remark },
    ];
  }
};
const clickEdit = () => { 
  tools.edit = true
}
// 取消保存
const cancel = () => { 
  tools.edit = false;
  queryDetail()
}
// 保存编辑/新增
const saveEdit = () => {
  formRef.value.validator(formData.value, rules).then(res => {
    if (res.isPassed) {
      if (tools?.adminSupervisionList?.length < 1) {
        return uni.showToast({
          title: '请选择重点监管领域！',
          icon: 'none',
        })
      }
      formData.value.adminSupervisionList = tools.adminSupervisionList
      // for (const item in formData.value) {
      //   if (!formData.value[item]) {
      //     delete formData.value[item]
      //   }
      // }
      let params = formData.value;
      api.merchantInfoUpdate(params).then(res => {
        if (res?.code && res?.code == '00000') {
          tools.edit = false;
          queryDetail()
        } else {
          return uni.showToast({
            title: res?.message || '操作失败',
            icon: 'none',
          })
        }
      }).catch(error => {
        console.log(error)
      })
    }
  }).catch(err => {
    console.log(err)
  })
};
// 获取字典
const getDicList = async (code, list) => {
  let res = await commonApi.getDicList({ dictTypeCode: code });
  if (res?.code && res?.code == '00000') {
    if (code == "industry") tools.industryList = [];
    res?.data?.map(it => {
      it.id = it.dictId;
      it.text = it.dictName;
      it.checked = false;
    })
    tools[list] = res?.data ?? [];
  }
}
// 获取重点监管领域
const getSupervise = async () => {
  let res = await commonApi.getAdminSupervisionList();
  if (res?.code && res?.code == "00000") {
    tools.casCaderOptions = replaceParam(res?.data);
  }
};
const handleMap = () => {
  if (formData.value?.longitude && formData.value?.latitude) {
    uni.navigateTo({
      url: "/pages/map/index?longitude=" + formData.value.longitude + '&latitude=' + formData.value.latitude,
    });
  } else {
    uni.navigateTo({
      url: "/pages/map/index",
    });
  }
}
// 获取所属网格
const getAllTree = async () => {
  let res = await commonApi.getAllTree();
  if (res?.code && res?.code == "00000") {
    tools.gridOptions = disabledOrg(res?.data);
  }
};
// 区域下不可绑定
const disabledOrg = (list) => {
  for (const item of list) {
    // type == `1` ? '区域':'网格'
    item.text = item?.name;
    item.value = item?.id;
    if (item.type == 1) {
      item.disabled = true;
    }
    if (item.children && item.children.length > 0) {
      disabledOrg(item.children);
    }
  }
  return list
}
const replaceParam = (arr) => {
  arr?.forEach(it => {
    it.text = it?.tagName;
    it.value = it?.id;
    if (it.children) {
      replaceParam(it.children)
    }
  })
  return arr
}
const handleList = (val, type) => {
  if (val && val?.length > 0) {
    let list = val?.map((it) => {
      return it?.[type]
    });
    return list.join(",");
  } else {
    return '';
  }
}
const handleText = (val, list) => {
  if (val) {
    let obj = tools[list]?.find(it => it.dictId == val)
    return obj?.dictName;
  } else {
    return "";
  }
}
const openSelect = (type, list, id) => {
  // type: 1单选 2多选
  if (!tools.edit && !tools.add) return;
  if (type == 2) {
    tools.industryList?.forEach(item => {
      formData.value.industryIdList?.forEach(it => {
        if (item.dictId == it) {
          item.checked = true;
        }
      })
    })
    tools.showSelect = true
  } else {
    tools[list]?.forEach(item => {
      if (item.dictId == id) {
        item.checked = true;
      }
    })
    if (list == 'statusList') {
      tools.showSelectStatus = true
    } else {
      tools.showSelectType = true
    }
  }
}
const onConfirm = (e) => {
  formData.value.industryIdList = [];
  e?.options?.forEach(item => {
    formData.value.industryIdList.push(item?.dictId);
  })
  formData.value.industryList = e?.options;
  onClose()
}
//关闭组件
const onClose = () => {
  tools.showSelect = false
}
const openCascaser = () => {
  if (!tools.edit && !tools.add) return;
  tools.showCascader = true;
};
const closeCascader = () => {
  tools.showCascader = false;
};
const delCascader = (e, i) => {
  adminSupervisionListCopy.value.splice(i, 1)
};
const saveCascader = () => {
  tools.adminSupervisionList = adminSupervisionListCopy.value;
  tools.showCascader = false;
}
const completeGrid = (e) => {
  tools.gridName = e?.text?.join(' / ');
}
const changeGrid = (e) => {
  tools.gridId = e?.value;
  tools.gridName = e?.text;
  tools.gridType = e?.type;
}
const saveGrid = () => {
  if (tools.gridType == 1) {
    return uni.showToast({
      title: '当前选择项为区域，请选择网格后保存！',
      icon: 'none'
    })
  }
  formData.value.regionGridId = tools.gridId;
  formData.value.gridName = tools.gridName;
  formData.value.gridInfo = {}
  formData.value.gridInfo.gridFullName = tools.gridName;
  tools.showGrid = false;
}
const openGrid = () => {
  if (!tools.edit) return;
  tools.showGrid = true;
}
const closeGrid = () => {
  tools.showGrid = false;
}
// 级联选择完成
const complete = (e) => {
  let id = e?.value[e.value?.length - 1];
  let name = e?.text?.join(' / ');
  let flag = adminSupervisionListCopy.value?.find(it => it.supervisionAreasId == id) ?? false
  if (flag) {
    // adminSupervisionListCopy.value = adminSupervisionListCopy.value.filter(it => it.supervisionAreasId != flag.supervisionAreasId)  // 把这个数组变成去除掉id相同的这一项
  } else {
    adminSupervisionListCopy.value?.push({
      supervisionAreasId: id,
      supervisionAreasName: name,
    })
  }
}

const jumpQrcode = () => {
  if (!formData.value?.qrCode?.[0]?.fileUrl) {
    toastRef.value.show({text: '暂无商户码'})
    return;
  }
  uni.navigateTo({
    url: `/pages/mine/mQrcode?url=`+formData.value.qrCode[0].fileUrl
  })
}

const  handleInto=()=>{
  uni.navigateTo({
    url: `/pages/message/index`
  })
}
// 登出
const triggerLoginOut = () => {
  uni.clearStorageSync();
  uni.redirectTo({
    url: `/pages/sign/index`,
  });
};
const handleStaff = () => {
  uni.navigateTo({
    url: `/pages/staffManagement/index`,
  });
};
</script>

<style lang="scss">
.page-container {
  background: #f4f5f7;
  height: calc(100vh - 88rpx - 50px) !important;
  padding: 15px;
}
.page-body {
  height: calc(100vh - 150rpx);
  overflow: auto;
  :deep(.fui-preview__bd) {
    background: #fff;
  }
}
:deep(.fui-form__item-wrap) {
  border-radius: 4px !important;
  // margin: 10px 0 !important;
}
.fui-text__explain {
  font-size: 28rpx;
  color: #7F7F7F;
  flex-shrink: 0;
}
.popup-title {
  padding: 36rpx 26rpx;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: wrap;

  span {
    flex: 1;
    text-align: center;
    font-size: 36rpx;
    font-weight: 500;
    color: #333;
    width: calc((100% - 52rpx) / 3); // 这里的10px = (分布个数3-1)*间
  }
}

.popup-body {
  max-height: 30vh;
  overflow: auto !important;

  .popup-text {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-size: 32rpx;
  }

  :deep(.fui-tag__wrap) {
    padding: 4rpx !important;
    position: absolute !important;
    right: 15px;
    top: 0px;
  }
}

:deep(.fui-input__wrap) {
  padding: 0 !important;
}
.cas-list :deep(.fui-tag__wrap) {
  padding: 8px !important;
  margin: 4px 8px 4px 0 !important;
}

.fui-scroll__wrap {
  position: relative;
}

.fui-icon__close {
  position: absolute;
  top: 0px;
  right: 12px;
}

.fui-scroll__view {
  width: 100%;
  height: 30vh;
}
</style>
