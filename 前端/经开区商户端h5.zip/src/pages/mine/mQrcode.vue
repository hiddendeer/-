<template>
  <div class="flex flex-col items-center justify-center relative top-[100rpx]">
    <template v-if="qrCodeUrl">
      <img class="h-[200px] w-[200px]" :src="qrCodeUrl" />
      <div class="mt-[50rpx]">
        <fui-button
          @click="saveImg"
          height="80rpx"
          width="400rpx"
          size="28"
          radius="96rpx"
          >保存图片</fui-button
        >
      </div>
    </template>
    <fui-empty title="暂无图片" v-else style="padding-bottom: 20px"></fui-empty>
  </div>
  <fui-toast ref="toastRef"></fui-toast>
</template>

<script setup>
import { onLoad } from "@dcloudio/uni-app";
import { ref } from "vue";
import api from "./server/api.js";

const toastRef = ref(null);

onLoad((e) => {
  qrCodeUrl.value = e?.url;
  getAuth();
  console.log(e);
});
const qrCodeUrl = ref("");

const getAuth = async () => {
  const res = await api.getInitCode();
  console.log(window.ls);
  if (res?.code == "00000") {
    window.ls.ready(function () {});
    window.ls.error(function (e) {
      console.log(e, "错误信息");
    });
    // 确保ready方法初始化以后调用config方法
    window.ls.config({
      debug: true,
      appId: res.data.lxAppId,
      initCode: res.data.initCode,
    });
  }
};

const saveImg = () => {
  window.ls.lsSavePhoto(
    {
      url: qrCodeUrl.value, // 图片地址
    },
    function (res) {
      toastRef.value.show({ text: "保存成功,请至相册查看" });
    }
  );
};
</script>

<style lang="scss" scoped>
</style>