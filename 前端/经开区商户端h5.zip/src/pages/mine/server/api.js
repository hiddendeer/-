import http from '@/utils/network.js'

export default class Api {
    // 获取商户信息
    static getMerchantInfo(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/getMerchantInfo',
            method: 'GET',
            data: data
        })
    }

    // 登录获取企业列表
    static getInitCode(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sys/lingxi/getInitCode',
            method: 'GET',
            data: data
        })
    }

    // 修改 商户
    static merchantInfoUpdate(data) {
        return http.request({
            url: '/tvrjet-edz-company-app/sso/user/merchantInfoUpdate',
            method: 'POST',
            data: data
        })
    }
}