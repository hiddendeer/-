<template>
  <view class="mine-page">
    <view class="header_bg"></view>
    <view class="bottom_bg"></view>
    <view class="container">
      <view class="row">
        <image class="img" src="/static/mine/name_icon.png" mode="widthFix" />
        <text class="label">姓名：</text>
        <text class="val">{{ userList.realName }}</text>
      </view>
      <view class="row">
        <image class="img" src="/static/mine/position_icon.png" mode="widthFix" />
        <text class="label">职位：</text>
        <text class="val">{{ userList.position }}</text>
      </view>
      <view class="row">
        <image class="img" src="/static/mine/area_icon.png" mode="widthFix" />
        <text class="label">管理区域：</text>
        <text class="val">{{ userList.managementArea }}</text>
      </view>
      <view class="row">
        <image class="img" src="/static/mine/tel_icon.png" mode="widthFix" />
        <text class="label">联系方式：</text>
        <text class="val">{{ userList.phone }}</text>
      </view>
    </view>
    <fui-list-cell class="tab" arrow @click="handleCheckList">
      <text>我的检查</text>
    </fui-list-cell>
  </view>
</template>

<script>
import { mapState } from 'vuex'
import { queryUserDetail } from '@/api/authApi';
export default {
  computed: {
    ...mapState('auth', {
      userId: state => state.userData?.userId || ''
    })
  },
  data() {
    return {
      userList: {}
    }
  },
  onLoad() {
    // this.getUserInfo()
    console.log(this.$IsAuth(['teastPersion']));
  },
  methods: {
    async getUserInfo() {
      let { data } = await queryUserDetail({ userId: this.userId })
      this.userList = data
    },
    handleCheckList() {
      uni.navigateTo({
        url: '/pages/checkRecord/index'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.mine-page {
  width: 100%;
  display: flex;
  flex-direction: column;
  background: #fff;
  position: relative;
  height: 100vh;
  /* #ifdef H5*/
  height: calc(100vh - 88rpx - 50px) !important;

  /* #endif */
  .container {
    position: absolute;
    width: calc(100% - 60rpx);
    box-sizing: border-box;
    top: 140rpx;
    left: 30rpx;
    background: #fff;
    padding: 58rpx;
    border-radius: 20rpx;

    .row {
      display: flex;
      align-items: center;
      font-size: 32rpx;

      &~.row {
        margin-top: 50rpx;
      }

      .img {
        width: 38rpx;
        margin-right: 28rpx;
      }

      .label {
        color: #555;
      }

      .val {
        color: #333;
      }
    }
  }

  .tab {
    width: calc(100% - 60rpx);
    height: 100rpx;
    position: absolute;
    top: 610rpx;
    left: 30rpx;
    color: #555;
    background-color: #fff;
    box-sizing: border-box;
    padding: 58rpx;
    border-radius: 20rpx !important;
    display: flex;
    justify-content: space-between;
    align-items: center;

    text {
      font-size: 32rpx;
    }
  }

  .header_bg {
    background: #465cff url('/static/mine/mine_header_bg.png') no-repeat;
    height: 320rpx;
  }

  .bottom_bg {
    flex: 0 0 calc(100% - 260rpx);
    background: $uni-bg-color-hover;
    border-radius: 24rpx;
    margin-top: -60rpx;
    padding-bottom: 60rpx;
  }
}
</style>
