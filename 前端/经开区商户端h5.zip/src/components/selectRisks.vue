<template>
  <div>
    <fui-bottom-popup :show="props.showPop" @close="closePopup">
      <div class="title">
        <span>常见隐患</span>
        <fui-icon name="close" :size="48" @click="closePopup"></fui-icon>
      </div>
      <div class="body-wrap">
        <div class="item-body" v-for="(item, index) in props?.riskList" :key="item.id">
          <div>
            <span class="label-text">隐患内容:</span>
            <span class="value-text">{{ item.describes }}</span>
          </div>
          <!-- <div>
            <span class="label-text">整改意见:</span>
            <span class="value-text">{{ item.suggest }}</span>
          </div> -->
          <div>
            <span class="label-text">隐患性质:</span>
            <span class="value-text" :style="{ color: formatState(item?.levelName).color }">{{ item.levelName }}</span>
          </div>
          <div style="display: flex;justify-content: space-between;flex-wrap:wrap;width:100%" v-if="item?.imgList">
            <div class="ex-body" v-for="(it, inx) in item.imgList" :key="inx" @click="showGallery(it.fileUrl)">
              <img :src="it.fileUrl" alt='' />
              <fui-tag :text="it.type == 1 ? '正确示例' : '错误示例'" color="#fff"
                :background="it.type == 1 ? '#13BA79' : '#F95943'" />
            </div>
          </div>
          <fui-upload-video ref="upload" :fileList="item?.videoList" isView></fui-upload-video>
          <fui-button radius="96rpx" plain color="#1D4AD4" borderColor="#1D4AD4" style="margin:0 auto"
            v-if="props.type == 2" :margin="['20rpx', '0']" width="45%" height="80rpx"
            @click="appoint(item)">引用</fui-button>
        </div>
      </div>
    </fui-bottom-popup>
    <fui-gallery :urls="tools.urls" :show="tools.show" @hide="hideGallery"></fui-gallery>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, watch } from "vue";

const props = defineProps({
  showPop: {
    type: Boolean,
    default: false
  },
  type: {
    type: Number,
    default: 2
  },
  riskList: {
    type: Array,
    default: []
  }
});
const tools = reactive({
  urls: [],
  show: false
})
const emit = defineEmits(["updateList", "update:showPop"]);
onMounted(() => {

});
const formatState = (val) => {
  let res = { name: '', color: '#13BA79' }
  switch (val) {
    case '一般隐患': res = { name: '一般隐患', color: '#13BA79' }
      break;
    case '重大隐患': res = { name: '重大隐患', color: '#F95943 ' }
      break;
  }
  return res
};
// 引用
const appoint = (e) => {
  emit('appoint', JSON.parse(JSON.stringify(e)));
};
// 大图预览
const showGallery = (e) => {
  tools.urls = [];
  tools.urls.push({
    src: e
  });
  tools.show = true;
};
// 关闭大图预览
const hideGallery = () => {
  tools.show = false;
};
const closePopup = () => {
  emit("update:showPop", false)
};
defineExpose({})
</script>
<style lang="scss" scoped>
.title {
  padding: 36rpx 26rpx;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: wrap;

  span {
    flex: 1;
    text-align: center;
    font-size: 36rpx;
    font-weight: 500;
    color: #333;
    width: calc((100% - 52rpx) / 3); // 这里的10px = (分布个数3-1)*间
  }
}

.body-wrap {
  max-height: 60vh;
  overflow: auto;
}

.item-body {
  padding: 28rpx 32rpx;
  border-top: 1px solid #eee;
}

.label-text {
  color: #333;
  font-size: 32rpx;
  font-weight: 600;
  padding-right: 20rpx;
}

.value-text {
  color: #666;
  font-size: 32rpx;
}

.ex-body {
  width: 46%;
  padding: 10rpx 0;
  position: relative;

  img {
    width: 100%;
    height: 220rpx;
    border-radius: 4px !important;
  }

  .fui-tag__wrap {
    position: absolute;
    right: 0;
    border-radius: 0 4px 0 4px !important;
  }
}
</style>