<template>
  <view
    class="content"
    :style="{ 'border-color': '' + defaultColor, background: defaultColor }"
  >
    <view
      v-for="(item, index) in switchArr"
      :key="index"
      class="switch_item"
      :class="{
        switch_selected: defaultValue == item.value ? true : false,
      }"
      @click="itemClick(item)"
      :style="{
        color: (defaultValue == item.value ? true : false)
          ? defaultColor
          : highColor,
        background: (defaultValue == item.value ? true : false)
          ? highColor
          : '',
      }"
    >
      <i v-if="switchType == 'icon'" class="uni-icon" :class="item.title"></i>
      <view
        :style="{
          color: item.value == `1` ? 'red' : '#333333',
          fontWeight: (defaultValue == item.value ? true : false) ? `bold` : '',
        }"
        v-if="switchType == 'text'"
        >{{ item.title }}</view
      >
    </view>
  </view>
</template>

<script>
export default {
  name: "YJYSwitch",
  props: {
    //默认选中的值，int类型
    defaultValue: {
      type: Number,
      default: 0,
    },
    //当前循环里的索引
    itemIndex: {
      type: Number,
      default: 0,
    },
    //选中的高亮颜色
    highColor: {
      type: String,
      default: "#FFFFFF",
    },
    //组件边框和选中的背景颜色
    defaultColor: {
      type: String,
      default: "#30C58D",
    },
    //类型，text：文本，icon：字体图标
    switchType: {
      type: String,
      default: "text",
    },
    //可用于切换的数组
    switchList: {
      type: Array,
      default: function () {
        return [];
      },
    },
  },
  data() {
    return {
      //定义个组件内的数组
      switchArr: [],
    };
  },
  methods: {
    itemClick(swithcSelectItem) {
      if (this.defaultValue != swithcSelectItem.value) {
        this.$emit("switchFunction", {
          swithcSelectItem,
          ...{ index: this.itemIndex },
        });
      }
    },
  },
  created() {
    //初始化可选择的数据
    if (this.switchList.length > 0) {
      for (let i = 0; i < this.switchList.length; i++) {
        let arrItem = {
          title: this.switchList[i].title,
          value: this.switchList[i].value,
        };
        this.switchArr.push(arrItem);
      }
    }
  },
};
</script>

<style lang="scss" scoped>
.content {
  display: flex;
  flex-direction: row;
  border-radius: 50px;

  .switch_selected {
    color: #ffffff;
    border-radius: 50px;
  }
  .switch_item {
    font-size: 14px;
    width: 50%;
    height: 86%;
    margin-top: 2px;
    margin-left: 2px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: all 0.4s ease-in-out;
  }
}
</style>