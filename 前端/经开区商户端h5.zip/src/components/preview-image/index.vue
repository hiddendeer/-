<template>
  <view class="components-preview-image-imgGroup">
    <fui-upload :isAdd="false" :isDel="false" :fileList="imgList"></fui-upload>
  </view>
</template>

<script>
export default {
  // #ifdef MP-WEIXIN
  options: {
    styleIsolation: 'shared' // 解除样式隔离
  },
  // #endif
  props: {
    imgList: {
      type: Array,
      default: []
    }
  },
  onLoad() {},
  onShow() {},
  components: {},
  data() {
    return {}
  },
  methods: {}
}
</script>
<style lang="scss" scoped>
.components-preview-image-imgGroup {
  width: 100%;
  :deep(.fui-upload__wrap) {
    width: 100%;
    height: 220rpx;
    display: flex;
    overflow-x: auto;
    flex-wrap: unset;
    .fui-upload__item {
      flex: 0 0 auto;
      border-radius: 20rpx;
      overflow: auto;
    }
  }
}
</style>
