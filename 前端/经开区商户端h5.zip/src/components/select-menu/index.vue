<template>
  <view class="select-menu-box" @click="onChange">
    <view class="left">
      <text class="places" v-if="!val">{{ placeholder }}</text>
      <text class="val" v-else>{{ val }}</text>
    </view>
    <fui-icon
      class="icon"
      :class="{ active: isActive }"
      name="arrowdown"
      color="#333333"
      size="54"
    ></fui-icon>
  </view>
</template>

<script>
export default {
  props: {
    placeholder: {
      type: String,
      default: '请选择'
    },
    val: String,
    isActive: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    onChange() {
      this.$emit('selectChange', !this.isActive)
    }
  }
}
</script>

<style lang="scss" scoped>
.select-menu-box {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 10rpx;
  background: #fff;
  border-radius: 10rpx;
  .left {
    font-size: 30rpx;
    width: 100%;
    overflow: hidden; 
    text-overflow: ellipsis;
    white-space: nowrap;
    .places {
      color: #333333;
    }
    .val {
      color: $uni-text-color;
    }
  }
  .icon {
    will-change: transform;
    transition: all 0.2s ease;
    margin-left: 20rpx;

    &.active {
      transform: rotate(-180deg);
    }
  }
}
</style>
