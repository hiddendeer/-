<template>
    <div class="pl-5">
        <fui-form ref="form" labelColor="#9a9a9a">

            <template v-for="(item, index) in fieldParams" :key="index">
                <!-- input 输入框 -->
                <view v-if="item.type == `input` || item.type == `inputNum`" :span="item.span || 10">
                    <fui-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                        <!-- {{ item[item.model] }} -->
                        <text class="text-gray-400" v-text="item[item.model]"></text>
                        <!-- <fui-input v-model="item[item.model]" :maxlength="item.maxlength"
                            :placeholder="item.placeholder || ''" :show-password="item.type == `password`"
                            :type="item.type" /> -->
                    </fui-form-item>
                </view>
                <!-- textarea 多文本框-->
                <view v-if="item.type == `textarea`" :span="item.span || 20">
                    <fui-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                        <!-- <fui-textarea v-model="item[item.model]" :maxlength="item.maxlength"
                            :placeholder="item.placeholder || ''"></fui-textarea> -->
                        <fui-textarea class="text-gray-400" v-text="item[item.model]"></fui-textarea>
                    </fui-form-item>
                </view>
                <!-- select 选择框-->
                <view v-if="item.type == `select`" :span="item.span || 10">
                    <fui-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                        <!-- <fui-select :show="show" :options="items.options" :multiple="item.multiple"
                            :title="item.placeholder" @confirm="onConfirm" @close="onClose"></fui-select> -->
                        <text class="text-gray-400">{{ item[item.model] }}</text> 
                        <!-- <template v-for="(it, id) in item[item.model]" :key="id">
                            <template v-for="(itLabel, ids) in item.options" :key="ids">
                                <text v-if="itLabel.value == it" class="text-gray-400">
                                    {{ itLabel.label + (item.options.length > 1 ? ',' : '') }}
                                </text>
                            </template>
                        </template> -->

                    </fui-form-item>
                </view>
                <!-- 日期选择期间 -->
                <view v-if="item.type == `date-picker`" :span="item.span || 10">
                    <fui-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                        <!-- <fui-date-picker :value="formObj[item.model]" range :placeholder="item.placeholder || `请选择日期`"
                            type="3" @change="changeDatePicker" /> -->
                        <template v-if="item[item.model].length == 2">
                            <view v-for="(it, id) in item[item.model]" :key="id">
                                <text class="text-gray-400" v-text="it + ','"></text>
                            </view>
                        </template>
                        <template v-else>
                            <text class="text-gray-400" v-text="item[item.model]"></text>
                        </template>
                    </fui-form-item>
                </view>
            </template>
        </fui-form>
    </div>
</template>

<script setup>
import { ref } from "vue";
const props = defineProps({
    // 字段数据
    fieldConfig: {
        type: Object,
        default: () => {
        },
    },
    disabled: {
        type: Boolean,
        default: false,
    },
});
const fieldParams = ref(props.fieldConfig?.fieldParams || []); // 配置字段






</script>

<style scoped lang="scss"></style>
