// 本文件由FirstUI授权予江苏伟岸纵横科技股份有限公司（手机号：13 02      94  5 9821，身份证尾号：    290 670）专用，请尊重知识产权，勿私下传播，违者追究法律责任。
export default class WebGLActiveInfo {
    className = 'WebGLActiveInfo';

    constructor({
        type, name, size
    }) {
        this.type = type;
        this.name = name;
        this.size = size;
    }
}