// 本文件由FirstUI授权予江苏伟岸纵横科技股份有限公司（手机号：130 2    945   98 2 1，身份证尾号： 29 0  6 70）专用，请尊重知识产权，勿私下传播，违者追究法律责任。
class FillStylePattern {
    constructor(img, pattern) {
        this._style = pattern;
        this._img = img;
    }
}

export default FillStylePattern;