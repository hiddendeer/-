<!--本文件由FirstUI授权予江苏伟岸纵横科技股份有限公司（手机号： 1 3 02 94  5  98 2 1，身份证尾号：  29 0 67 0）专用，请尊重知识产权，勿私下传播，违者追究法律责任。-->
<template>
	<view class="fui-upload__wrap">
		<view class="fui-upload__item" :style="{ width: width + 'rpx', height: height + 'rpx' }"
			v-for="(item, index) in urls" :key="index">
			<image class="fui-upload__img" :style="{ width: width + 'rpx', height: height + 'rpx' }" :src="item"
				mode="aspectFill" @tap.stop="previewImage(index)"></image>
			<view class="fui-upload__mask" v-if="status[index] !== 'success' && status[index] !== 'preupload'">
				<fui-icon name="warning-fill" color="#fff" :size="48" v-if="status[index] === 'error'"></fui-icon>
				<text class="fui-reupload__btn" @tap.stop="reUpload(index)" v-if="status[index] === 'error'">重新上传</text>
				<!-- #ifndef APP-NVUE -->
				<view class="fui-upload__loading" ref="fui_reupload_ld" v-if="status[index] === 'uploading'"></view>
				<text class="fui-upload__text" v-if="status[index] === 'uploading'">请稍候...</text>
				<!-- #endif -->
				<!-- #ifdef APP-NVUE -->
				<text class="fui-upload__text fui-upload__mtop" v-if="status[index] === 'uploading'">正在上传...</text>
				<!-- #endif -->
			</view>
			<view class="fui-upload__del" :style="{ background: delColor }" v-if="isDel" @tap.stop="deleteImage(index)">
				<fui-icon name="close" color="#fff" :size="32"></fui-icon>
			</view>
		</view>
		<view class="fui-upload__item" :style="{
			width: width + 'rpx',
			height: height + 'rpx',
			background: background,
		}" v-if="showAdd" @tap.stop="chooseImage">
			<slot>
				<fui-icon name="plus" :size="88" :color="addColor"></fui-icon>
			</slot>
		</view>
		<canvas :style="{
			width: cWidth + 'px',
			height: cHeight + 'px',
			position: 'absolute',
			'z-index': -1,
			left: '-10000rpx',
			top: '-10000rpx',
		}" canvas-id="canvas"></canvas>
	</view>
</template>
  
<script>
//非easycom模式取消注释引入字体组件，按实际路径进行调整
// import fuiIcon from "@/components/firstui/fui-icon/fui-icon.vue"
export default {
	name: "fui-upload",
	emits: ["success", "error", "complete", "preview"],
	// components:{
	// 	fuiIcon
	// },
	props: {
		width: {
			type: [Number, String],
			default: 200,
		},
		height: {
			type: [Number, String],
			default: 200,
		},
		fileList: {
			type: Array,
			default() {
				return [];
			},
		},
		max: {
			type: [Number, String],
			default: 9,
		},
		isAdd: {
			type: Boolean,
			default: true,
		},
		addColor: {
			type: String,
			default: "#333",
		},
		background: {
			type: String,
			default: "#eee",
		},
		isDel: {
			type: Boolean,
			default: true,
		},
		delColor: {
			type: String,
			default: "rgba(0,0,0,.6)",
		},
		confirmDel: {
			type: Boolean,
			default: false,
		},
		url: {
			type: String,
			default: "",
		},
		immediate: {
			type: Boolean,
			default: false,
		},
		sizeType: {
			type: Array,
			default() {
				return ["original", "compressed"];
			},
		},
		sourceType: {
			type: Array,
			default() {
				return ["album", "camera"];
			},
		},
		//图片后缀名限制
		suffix: {
			type: Array,
			default() {
				return [];
			},
		},
		//单张图片大小限制 MB
		size: {
			type: [Number, String],
			default: 10,
		},
		name: {
			type: String,
			default: "file",
		},
		header: {
			type: Object,
			default() {
				return {};
			},
		},
		formData: {
			type: Object,
			default() {
				return {};
			},
		},
		param: {
			type: [Number, String],
			default: 0,
		},
	},
	data() {
		return {
			cWidth: 480, // 最大宽
			cHeight: 640, // 最大高
			urls: [],
			//preupload、uploading、success、error
			status: [],
		};
	},
	created() {
		this.initData(this.fileList);
	},
	watch: {
		fileList(vals) {
			this.initData(vals);
		},
	},
	computed: {
		showAdd() {
			let show = true;
			let len = this.urls.length;
			if (
				!this.isAdd ||
				(this.max == -1 && len >= 9) ||
				(this.max != -1 && len >= this.max)
			) {
				show = false;
			}
			return show;
		},
	},
	methods: {
		initData(urls) {
			urls = urls || [];
			this.status = [];
			let status = [];
			urls.forEach((item) => {
				status.push("success");
			});
			this.urls = [...urls];
			this.status = status;
		},
		reUpload(index) {
			this.$set(this.status, index, "uploading");
			this.uploadImage(index, this.urls[index])
				.then((res) => {
					this._success(res);
				})
				.catch((res) => {
					this._error(res);
				});
		},
		getStatus() {
			if (this.status.length === 0) return "";
			let status = "preupload";
			if (this.status.indexOf("preupload") === -1) {
				status = ~this.status.indexOf("uploading") ? "uploading" : "success";
				if (status !== "uploading" && ~this.status.indexOf("error")) {
					// 上传失败
					status = "error";
				}
			}
			return status;
		},
		onComplete(action) {
			let status = this.getStatus();
			this.$emit("complete", {
				status: status,
				urls: this.urls,
				action: action,
				param: this.param,
			});
		},
		_success(res) {
			let status = this.getStatus();
			this.$emit("success", {
				status: status,
				...res,
				param: this.param,
			});
		},
		_error(res) {
			let status = this.getStatus();
			this.$emit("error", {
				status: status,
				...res,
				param: this.param,
			});
		},
		result(url, index) {
			if (!url || index === undefined) return;
			this.$set(this.urls, index, url);
			setTimeout(() => {
				this.onComplete("upload");
			}, 0);
		},
		toast(text) {
			text &&
				uni.showToast({
					title: text,
					icon: "none",
				});
		},
		chooseImage() {
			let max = Number(this.max);
			uni.chooseImage({
				count: max === -1 ? 9 : max - this.urls.length,
				sizeType: this.sizeType,
				sourceType: this.sourceType,
				success: (e) => {
					let imageArr = [];
					for (let i = 0; i < e.tempFiles.length; i++) {
						let len = this.urls.length;
						if (len >= max && max !== -1) {
							this.toast(`最多可上传${max}张图片`);
							break;
						}
						//过滤图片类型
						let path = e.tempFiles[i].path;

						if (this.suffix.length > 0) {
							let format = "";
							// #ifdef H5
							let type = e.tempFiles[i].type;
							format = type.split("/")[1];
							// #endif

							// #ifndef H5
							format = path.split(".")[path.split(".").length - 1];
							// #endif

							if (this.suffix.indexOf(format) == -1) {
								let text = `只能上传 ${this.suffix.join(",")} 格式图片！`;
								this.toast(text);
								continue;
							}
						}

						//过滤超出大小限制图片
						let size = e.tempFiles[i].size;

						if (Number(this.size) * 1024 * 1024 < size) {
							let err = `单张图片大小不能超过：${this.size}MB`;
							this.toast(err);
							continue;
						}
						imageArr.push(path);
						this.urls.push(path);
						this.status.push(this.immediate ? "uploading" : "preupload");
					}
					this.onComplete("choose");
					let start = this.urls.length - imageArr.length;
					if (this.immediate) {
						for (let j = 0; j < imageArr.length; j++) {
							let index = start + j;
							this.uploadImage(index, imageArr[j])
								.then((res) => {
									this._success(res);
								})
								.catch((res) => {
									this._error(res);
								});
						}
					}
				},
			});
		},

		compressionIamge(that, imageURL) {
			// 等比例压缩图片 可指定图片宽高 兼容性：微信小程序端正常，其他端未测试
			uni.showLoading({
				title: "正在压缩图片",
			});
			let result = null;
			const promise = new Promise((resolve, reject) => {
				uni.getImageInfo({
					src: imageURL,
					success: (res) => {
						let originHeight = res.height;
						let originWidth = res.width;
						let maxWidth = 480; // 最大宽
						let maxHeight = 640; // 最大高
						let targetWidth = originWidth;
						let targetHeight = originHeight;
						if (originWidth > maxWidth || originHeight > maxHeight) {
							if (originWidth / originHeight > maxWidth / maxHeight) {
								targetWidth = maxWidth;
								targetHeight = Math.round(
									maxWidth * (originHeight / originWidth)
								);
							} else {
								targetHeight = maxHeight;
								targetWidth = Math.round(
									maxHeight * (originWidth / originHeight)
								);
							}
						}

						that.cWidth = targetWidth;
						that.cHeight = targetHeight;

						let ctx = uni.createCanvasContext("canvas", that);

						ctx.clearRect(0, 0, targetWidth, targetHeight);
						ctx.drawImage(imageURL, 0, 0, targetWidth, targetHeight);
						ctx.draw(
							false,
							() => {
								setTimeout(() => {
									uni.canvasToTempFilePath(
										{
											canvasId: "canvas",
											success: (res) => {
												resolve(res.tempFilePath);
											},
											fail: (err) => {
												console.log(err);
											},
											complete: () => {
												uni.hideLoading();
											},
										},
										that
									)
								}, 1000)
							}
						);
					},
				});
			});
			return promise.then((res) => (result = res));
		},
		async uploadImage(index, imgUrl, url) {
			// const compressionPath = await this.compressionIamge(this, imgUrl);
			return new Promise((resolve, reject) => {
				uni.uploadFile({
					url: this.url || url,
					name: this.name,
					header: this.header,
					formData: this.formData,
					filePath: imgUrl,
					success: (res) => {
						if (res.statusCode === 200) {
							this.$set(this.status, index, "success");
							resolve({
								res,
								index,
							});
						} else {
							this.$set(this.status, index, "error");
							reject({
								res,
								index,
							});
						}
					},
					fail: (res) => {
						this.$set(this.status, index, "error");
						// uni.showModal({
						// 	content: JSON.stringify(res)
						// })
						reject({
							res,
							index,
						});
					},
				});
			});
		},
		deleteImage(index) {
			let status = this.getStatus();
			if (status === "uploading") {
				this.toast("请等待上传结束再进行删除！");
			} else {
				if (this.confirmDel) {
					let _this = this;
					uni.showModal({
						content: "确定将该图片删除吗？",
						showCancel: true,
						confirmText: "确定",
						success(res) {
							if (res.confirm) {
								_this.urls.splice(index, 1);
								_this.status.splice(index, 1);
								_this.onComplete("delete");
							}
						},
					});
				} else {
					this.urls.splice(index, 1);
					this.status.splice(index, 1);
					this.onComplete("delete");
				}
			}
		},
		previewImage(index) {
			// #ifndef MP-BAIDU
			if (this.status.length === 0) return;
			uni.previewImage({
				current: this.urls[index],
				loop: true,
				urls: this.urls,
			});
			// #endif
			//百度小程序使用
			this.$emit("preview", {
				index: index,
				urls: this.urls,
			});
		},
		start() {
			if (!this.url) {
				this.toast("请传入服务器接口地址！");
				return;
			}
			let urls = [...this.urls];
			const len = urls.length;
			for (let i = 0; i < len; i++) {
				if (urls[i].startsWith("https")) {
					continue;
				} else {
					this.$set(this.status, i, "uploading");
					this.uploadImage(i, urls[i], this.url)
						.then((res) => {
							this._success(res);
						})
						.catch((error) => {
							this._error(error);
						});
				}
			}
		},
	},
};
</script>
  
<style scoped>
.fui-upload__wrap {
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	flex-direction: row;
	flex-wrap: wrap;
}

.fui-upload__item {
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	align-items: center;
	justify-content: center;
	margin-right: 20rpx;
	margin-bottom: 20rpx;
	/* #ifdef H5 */
	cursor: pointer;
	/* #endif */
	position: relative;
}

.fui-upload__del {
	position: absolute;
	top: 8rpx;
	right: 8rpx;
	height: 40rpx;
	width: 40rpx;
	/* #ifndef APP-NVUE */
	border-radius: 50%;
	display: flex;
	/* #endif */

	/* #ifdef APP-NVUE */
	border-radius: 20rpx;
	/* #endif */
	align-items: center;
	justify-content: center;
	z-index: 10;
}

.fui-upload__mask {
	position: absolute;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	background: rgba(0, 0, 0, 0.6);
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	flex-direction: column;
	align-items: center;
	justify-content: center;
}

.fui-reupload__btn {
	width: 144rpx;
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	align-items: center;
	justify-content: center;
	text-align: center;
	padding: 4rpx 0;
	font-size: 24rpx;
	border: 1px solid #ffffff;
	color: #fff;
	border-radius: 32rpx;
	margin-top: 16rpx;
	font-weight: normal;
}

.fui-reupload__btn:active {
	opacity: 0.5;
}

.fui-upload__loading {
	width: 32rpx;
	height: 32rpx;
	border-width: 2px;
	border-style: solid;
	border-top-color: #ffffff;
	border-left-color: #7f7f7f;
	border-right-color: #7f7f7f;
	border-bottom-color: #7f7f7f;
	/* #ifdef APP-NVUE */
	border-radius: 20rpx;
	/* #endif */
	/* #ifndef APP-NVUE */
	border-radius: 50%;
	animation: fui-rotate 0.7s linear infinite;
	/* #endif */
	margin-bottom: 8rpx;
}

.fui-upload__text {
	font-size: 24rpx;
	color: #fff;
	margin-top: 16rpx;
	font-weight: normal;
}

/* #ifdef APP-NVUE */
.fui-upload__mtop {
	margin-top: 0;
}

/* #endif */

/* #ifndef APP-NVUE */
@keyframes fui-rotate {
	0% {
		transform: rotate(0);
	}

	100% {
		transform: rotate(360deg);
	}
}

/* #endif */
</style>