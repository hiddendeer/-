// 本文件由FirstUI授权予江苏伟岸纵横科技股份有限公司（手机号：13 02  9 459     82 1，身份证尾号：  290 6 7 0）专用，请尊重知识产权，勿私下传播，违者追究法律责任。
export default class WebGLActiveInfo {
    className = 'WebGLActiveInfo';

    constructor({
        type, name, size
    }) {
        this.type = type;
        this.name = name;
        this.size = size;
    }
}