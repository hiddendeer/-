import http from '@/utils/network.js'

export default class commonApi {
  static login(data) {
    return http.request({
      url: '/api/tvrjet-gov-system-app/loginApi',
      method: 'POST',
      data: data
    })
  }
  // 获取数据字典列
  static getDicList = (data) => {
    return http.request({
      url: `/tvrjet-edz-company-app/sys/dict/list`,
      method: 'GET',
      data: data
    })
  }
  // 获取重点监管领域
  static getAdminSupervisionList = (data) => {
    return http.request({
      url: `/tvrjet-edz-company-app/sso/base/getAdminSupervisionList`,
      method: 'GET',
      data
    })
  }
  // 获取网格信息
  static getAllTree = (data) => {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/base/getGridAllTree',
      method: 'get',
      data
    });
  }
  // 获取用户所属网格
  static getUserGrid = (data) => {
    return http.request({
      url: '/tvrjet-edz-company-app/sso/user/merchantInfoAdd',
      method: 'get',
      data
    });
  }
}