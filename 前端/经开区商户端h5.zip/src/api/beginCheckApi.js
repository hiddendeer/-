import { post, get } from '@/utils/request'

//获取全量商户列表
export const getMerchantList = data => {
    return post({
        url: '/tvrjet-edz-supervision-app/merchantManage/getMerchantList',
        data
    })
}
//获取模板
export const queryTemplateByMerchant = data => {
    return get({
        url: '/tvrjet-edz-supervision-app/supervisionInspectionRecord/queryTemplateByMerchant',
        data
    })
}
//开始检查获取主键ID
export const startInspection = data => {
    return post({
        url: '/tvrjet-edz-supervision-app/supervisionInspectionRecord/startInspection',
        data
    })
}
//暂存
export const stagingInspection = data => {
    return post({
        url: '/tvrjet-edz-supervision-app/supervisionInspectionRecord/stagingInspection',
        data
    })
}
//提交
export const submitInspection = data => {
    return post({
        url: '/tvrjet-edz-supervision-app/supervisionInspectionRecord/submitInspection',
        data
    })
}
