import { post, get } from '@/utils/request'

//获取行政区域
export const getExpHrOrgan = data => {
  return get({
    url: '/tvrjet-edz-supervision-system-custom-app/expHrOrganization/organizationTree',
    data
  })
}
//隐患列（待整改、已整改）
export const queryListByRecord = data => {
  return get({
    url: '/tvrjet-edz-supervision-app/inspectionHiddenDanger/queryListByRecord',
    data
  })
}
//拍照整改
export const photoAcceptance = data => {
  return post({
    url: '/tvrjet-edz-supervision-app/inspectionHiddenDanger/photoAcceptance',
    data
  })
}
