import {
	createSSRApp
} from "vue";
import App from "./App.vue";
import Store from './store'
import vrFunc from "@/common/vrFunc.js";
import { isAuth } from '@/utils/auth.js';
import 'uno.css';

export function createApp() {
	const app = createSSRApp(App);
	app.use(Store);

	// 挂载全局对象
	app.config.globalProperties.$vrFunc = vrFunc;
	app.config.globalProperties.$IsAuth = isAuth;
	return {
		app,
	};
}
