export default {
  namespaced: true,
  state: {
    info: null,
    quesInfo: null
  },
  getters: {},
  mutations: {
    setInfo(state, val) {
      state.info = val;
    },
    setQuesInfo(state, val) {
      state.quesInfo = val;
    },
    clearInfo(state) {
      state.info = '';
      state.quesInfo = '';
    },
    clearQuesInfo(state) {
      state.quesInfo = '';
    }
  },
  actions: {}
}