
export default {
    namespaced: true,
    state: {
        info: null,
        index: 0,
        openIndex: 0,
        editId: null,
    },
    getters: {},
    mutations: {
        setInfo(state, val) {
            state.info = val;
        },
        setIndex(state, val) {
            state.index = val;
        },
        setOpenIndex(state, val) {
            state.openIndex = val;
        },
        setEditId(state, val) {
            state.editId = val;
        },
    },
    actions: {}
}
