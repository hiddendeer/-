// import _ from "lodash";
// import sha256 from "js-sha256";
import { signIn, loginPhoneOneKey } from '@/api/authApi'
const authModule = {
  namespaced: true,
  state: {
    token: uni.getStorageSync('token') || null, //token
    signInLoading: false,
    userData: uni.getStorageSync('userData') || {}
  },
  getters: {},
  mutations: {
    //token
    setToken(state, val) {
      state.token = val
      uni.setStorageSync('token', val)
    },
    //清空
    clear(state) {
      state.token = null
      uni.removeStorageSync('token')
      state.userData = {}
      uni.removeStorageSync('userData')
    },
    setSignInLoading(state, val) {
      state.signInLoading = val
    },
    setUserData(state, data) {
      state.userData = data
      uni.setStorageSync('userData', data)
    }
  },
  actions: {
    async onSignIn({ dispatch, commit }, options) {
      try {
        let { data } = options.appId
          ? await loginPhoneOneKey(options)
          : await signIn(options)
        commit('setToken', data?.token || '')
        commit('setUserData', data?.loginUser || {})
        commit('setSignInLoading', false)
      } catch (error) {
        commit('setSignInLoading', false)
      }
    }
  }
}

export default authModule
