
export default {
    namespaced: true,
    state: {
        index: uni.getStorageSync('index') || 0,
        messageNum:0,
    },
    getters: {},
    mutations: {
        setIndex(state, val) {
            state.index = val;
            uni.setStorageSync('index', val)
        },
        setMessageNum(state, val) {
            state.messageNum = val;
            uni.setStorageSync('index', val)
        }
    },
    actions: {}
}
