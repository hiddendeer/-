<script setup>



</script>

<style>
/*每个页面公共css */
@import url("@/static/css/normal.css");
</style>
