const checkMessageUrl = (val) => {
    let type = val. extra3 == '2646430377938915330' ? '2' : '1';
    switch (val.templateCode) {
        // 检查任务（政府）
        case 'checkTaskMsg':
            return {
                url: '/',//消息详情 //首页
            }
            break;
        //检查任务（企业）
        case 'checkTaskToCompanyMsg':
            return {
                url:`/pages/selfRecords/index` //自查
            }
            break;
        //审核任务
        case 'verifyTaskMsg':
            return {
                message: '请在电脑端审核任务'//不跳转
            }
            break;
        //验收任务
        case 'reviewTaskMsg':
            return {
                url: '/', //首页
            }
            break;
        //任务通知（政府）
        case 'noticeMsg':
            return {
                url: `/pages/messageDetails/index?type=${type}&noticeObjId=${val.extra2}&noticeChildId=${val.recordId}`,//消息详情
            }
            break;
        //任务通知（企业）
        case 'noticeToCompanyMsg':
            return {
                url: `/pages/messageDetails/index?type=${type}&noticeObjId=${val.extra2}&noticeChildId=${val.recordId}`,//消息详情
            }
            break;
        //任务通知（数据上报）（政府）
        case 'noticeReportMsg':
            return {
                url: `/pages/messageDetails/index?type=${type}&noticeObjId=${val.extra2}&noticeChildId=${val.recordId}`,//消息详情
            }
            break;
        //任务通知（数据上报）（企业）
        case 'noticeReportToCompanyMsg':
            return {
                url: `/pages/messageDetails/index?type=${type}&noticeObjId=${val.extra2}&noticeChildId=${val.recordId}`,//消息详情
            }
            break;
        //系统通知（加入网格）
        case 'addGridMsg':
            return {
                message:val.content  //不跳转
            }
            break;
        //系统通知（移动网格）
        case 'changeGridMsg':
            return {
                message:val.content  //不跳转
            }
            break;
        //系统通知（移动网格）
        case 'changeGridToCompanyMsg':
            return {
                message:val.content  //不跳转
            }
            break;
        //预警消息
        case 'earlyWarningMsg':
            return {
                url: `/pages/warning/detail?id=${val.recordId}`,
            }
            break;
        //预警消息（企业）
        case 'earlyWarningToCompanyMsg':
            return {
                url: `/pages/warning/detail?id=${val.recordId}`,
            }
            break;
        //整改任务 (企业)
        case 'rectificationMsg': //-----------
            return {
                url: `/pages/homePage/accept/index`
            }
            break;
        case 'studyMsg': //学习任务
            return {
                url:`/pages/studyCenter/index?url=/pages/myStudyTask/index&id=${val.recordId}&fileUrl=${val.extra2}&fileName=${val.extra3}`
            }
            break;
        case 'examMsg': //考试任务
            return {
                url:`/pages/studyCenter/index?url=/pages/myExamTask/index&status=${val.extra4}&examId=${val.recordId}&examStartTime=${val.extra2}&examEndTime=${val.extra3}`
            }
            break;
    }


}

export {
    checkMessageUrl
}