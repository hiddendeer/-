import http from '@/components/firstui/fui-request'
import vrFunc from '@/common/vrFunc.js';
//初始化请求配置项
http.create({
    //接口域名
    host: '',
    header: {
        // 'content-type': 'application/x-www-form-urlencoded'
    }
})

//请求拦截
http.interceptors.request.use(config => {
    //请求之前可在请求头中加入token等信息
    let token = uni.getStorageSync('token') || '';
    if (token && !config.cancelToken) {
        config.header = {
            'Authorization': token
        }
    }

    return config
})

//响应拦截
http.interceptors.response.use(response => {
    //TODO
    if (response.data?.code && response.data.code != '00000') {
        vrFunc.toast(response.data.message)
    }

    // token过期处理
    if (response.data?.code && (['B0301','A0307','A10043'].includes(response.data.code))) {
        uni.clearStorage();
        uni.redirectTo({
            url: '/pages/sign/index'
        });
    }

    if (response.statusCode == '200') {
        return response.data;
    }

})

export default http
