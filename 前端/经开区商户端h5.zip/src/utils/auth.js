import { useStore } from 'vuex'

export function isAuth(arr) {
    const store = useStore();
    const authRole = store.state.auth.userData.simpleRoleInfoList;
    let hasAuth = false;
    authRole.forEach(it => {
        arr.forEach(i => {
            if (i == it.roleCode) {
                hasAuth = true;
            }
        })
    });
    return hasAuth;
}

// 使用方法 挂载全局
//<div v-if="$IsAuth(['superAdmin', 'examinePersion'])"></div> 

