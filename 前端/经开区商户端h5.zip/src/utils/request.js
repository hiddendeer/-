import store from '@/store'

// const __CONFIG = require('@/env.json')

const  SERVICE_API  = '';

let requestTasks = []

function abortRequest() {
  //此方法会打断所有发送中请求
  requestTasks.forEach(task => task.abort())
  requestTasks.length = 0
}
const request = options => {
  if (!options) return
  let config = {
    baseURL: SERVICE_API,
    header: {
      'Content-Type': 'application/json;charset=UTF-8'
    },
    data: {},
    method: 'GET',
    dataType: 'json',
    responseType: 'json',
    success() { },
    fail() { },
    complete() { },
    silence: true,
    ...options
  }
  let interceptor = {
    request: config => {
      return config
    },
    response: response => {
      console.log(response,222);
      const res = response.data
      return res
    },
    error: response => {
      console.log(response,222);
      uni.showToast({
        title: response.data ? response.data.message : '服务器异常，请稍后再试。',
        icon: 'none'
      })

      return Promise.reject(response)
    }
  }
  const token = uni.getStorageSync('token')
  options.header = {
    ...options.header,
    ...(token ? { Authorization: token } : '')
  }
  options.baseURL = options.baseURL || config.baseURL
  options.dataType = options.dataType || config.dataType
  options.url = options.baseURL + options.url
  options.method = options.method || config.method
  options.silence = options.silence || config.silence
  options.header = options.header || config.header

  return new Promise((resolve, reject) => {
    options.complete = response => {
      // console.log('response', response);
      if (response.data) {
        if (options.method === 'UPLOAD') {
          response.data = JSON.parse(response.data)
        }
        const { code } = response.data

        if (code === '00000') {
          resolve(response.data)
        } else if (code === 'D9998 ') {
          abortRequest()
          uni.reLaunch({ url: '/pages/sign/index' })
        } else if (code === 'B0301') {
          store.commit("auth/clear");
          uni.reLaunch({
            url: '/pages/sign/index'
          })
        } else if (code.includes('A')) {
          uni.showToast({
            title: response.data.message,
            icon: 'none'
          })
          reject(response)
        } else if (code.includes('B')) {
          uni.showToast({
            title: `操作失败，原因：${response.data.message}`,
            icon: 'none'
          })
          reject(response)
        } else {
          console.log('response', response)
          uni.showToast({
            title: '啊哦，小程序遇到了一些问题',
            icon: 'none'
          })
          reject(response)
        }
      } else {
        uni.showToast({
          title: '啊哦，小程序遇到了一些问题',
          icon: 'none'
        })
      }
      reject(response)

    }


    let requestTask = {}
    if (options.method === 'UPLOAD') {
      options.name = "file"
      requestTask = uni.uploadFile(options)
    } else {
      requestTask = uni.request(options)
    }

    requestTasks.push(requestTask)
  })
}

function get(options = { service, url, data }) {
  return request(options)
}

function post(options = { service, url, data }) {
  return request({ ...options, method: 'POST' })
}

function put(options = { service, url, data }) {
  return request({ ...options, method: 'PUT' })
}

function remove(options = { service, url, data }) {
  return request({ ...options, method: 'DELETE' })
}

function upload(options = { service, url, formData, filePath }) {
  return request({ ...options, method: 'UPLOAD' })
}

export { get, post, put, remove, upload }