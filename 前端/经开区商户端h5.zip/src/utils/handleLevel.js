import level from "@/common/level.js";
const func = {
  paramHandle: function (value, type, params ="levelStatus") {
    if (value) {
      return level[params]?.find((item) => item.name == value)[type];
    }
  }
}

export default func