export default {
  levelStatus: [
    {
      name: '其他',
      type: 'primary',
      value: "#3187FF"
    },
    {
      name: '一般事故',
      type: 'primary',
      value: "#3187FF"
    },
    {
      name: '较大事故',
      type: 'warning',
      value: "#FFb703"
    },
    {
      name: '重大事故',
      type: 'danger',
      value: "#FB8500"
    },
    {
      name: '特别重大事故',
      type: 'danger',
      value: "#EF4034"
    }
  ]
}