<script>
export default {
  onLaunch: function () {
    uni.hideTabBar();
    console.log("App Launch");
  },
  onShow: function () {
    console.log("App Show");
  },
  onHide: function () {
    console.log("App Hide");
  },
};
</script>

<style>
/*每个页面公共css */
@import url("@/static/css/normal.css");

.flex {
  display: flex;
}

.justifu-center {
  justify-content: center;
}

.justify-between {
  justify-content: space-between;
}

.algin-center {
  align-items: center;
}

.flex-end {
  justify-content: flex-end;
}
</style>
