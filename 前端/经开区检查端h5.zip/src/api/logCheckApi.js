import { post, get } from '@/utils/request'

//检查记录详情
export const queryRecordDetail = data => {
    return get({
        url: '/tvrjet-edz-supervision-app/supervisionInspectionRecord/detail',
        data
    })
}
