import http from '@/utils/network.js'

export default class commonApi {
  static login(data) {
    return http.request({
      url: '/api/tvrjet-gov-system-app/loginApi',
      method: 'POST',
      data: data
    })
  }
  // 文件上传
  // POST /tvrjet-edz-supervision-system-custom-app/minio/upload
  // 接口ID：52728696
  // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-52728696
  static uploadFile(data) {
    return http.request({
      url: '/tvrjet-edz-supervision-system-custom-app/minio/upload',
    })
  }
  // 上传签字文件
  static uploadSignFile(data) {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/h5/checkRecord/uploadSignFile',
      method: 'POST',
      data: data
    })
  }
  // 获取签字文件
  // GET /tvrjet-edz-supervision-app/gov/web/examineCenter/getSignFile
  // 接口ID：55134854
  // 接口地址：https://www.apifox.cn/link/project/2026198/apis/api-55134854
  static getSignFile = (data) => {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/web/examineCenter/getSignFile',
      method: 'GET',
      data
    })
  }
  // 获取用户角色
  // GET /tvrjet-edz-supervision-app/base/userRole/getUserRoles
  // 接口ID：59380472
  // 接口地址：https://www.apifox.cn/web/project/2026198/apis/api-59380472
  static getUserRoles = (data) => {
    return http.request({
      url: '/tvrjet-edz-supervision-app/base/userRole/getUserRoles',
      method: 'GET',
      data
    })
  }
  // 获取数据字典列
  static getDicList = (data) => {
    return http.request({
      url: `/tvrjet-edz-company-app/sys/dict/list`,
      method: 'GET',
      data
    })
  }
  // 获取重点监管领域
  static getAdminSupervisionList = (data) => {
    return http.request({
      url: `/tvrjet-edz-supervision-app/base/ggOperation/safeSmartLibrary/getAdminSupervisionList`,
      method: 'GET',
      data
    })
  }

  /**微信授权接口-config信息 */
  static getSignature = (data) => {
    return http.request({
      url: '/tvrjet-edz-supervision-system-custom-app/wechat/getSignature',
      method: 'get',
      data
    });
  }
  // 获取网格信息
  static getAllTree = (data) => {
    return http.request({
      url: '/tvrjet-edz-supervision-app/gov/web/grid/getAllTree',
      method: 'get',
      data
    });
  }
  // 获取用户所属网格
  static getUserGrid = (data) => {
    return http.request({
      url: '/tvrjet-edz-supervision-app/base/userRole/getUserGrid',
      method: 'get',
      data
    });
  }
  // 获取数据字典子项
  static getDictChild(data) {
    return http.request({
      url: `/tvrjet-edz-supervision-system-custom-app/dict/page`,
      method: 'get',
      data
    })
  }

}
