import { post, upload, get } from '@/utils/request'
import http from '@/utils/network.js'

export const signIn = data => {
  return http.request({
    url: '/tvrjet-edz-supervision-system-custom-app/loginApi',
    method: 'POST',
    data
  })
}
export const loginPhoneOneKey = data => {
  return http.request({
    url: '/tvrjet-edz-supervision-system-custom-app/loginPhoneOneKey',
    method: 'POST',
    data
  })
}
export const uploadFile = filePath => {
  return upload({
    url: '/tvrjet-edz-supervision-system-custom-app/minIoController/upload',
    filePath
  })
}

//检查记录(通用)
export const queryRecordList = data => {
  return http.request({
    url: '/tvrjet-edz-supervision-app/supervisionInspectionRecord/queryRecordList',
    method: 'GET',
    data
  })
}

export const queryUserDetail = data => {
  return http.request({
    url: '/tvrjet-edz-supervision-system-custom-app/expSysUser/queryDetail',
    method: 'GET',
    data
  })
}

export const queryHomeRecord = data => {
  return http.request({
    url: '/tvrjet-edz-supervision-app/home/queryHomeRecord',
    method: 'GET',
    data
  })
}