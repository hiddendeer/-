import { post, get } from '@/utils/request'

//获取行政区域
export const getExpHrOrgan = data => {
  return get({
    url: '/tvrjet-edz-supervision-system-custom-app/expHrOrganization/organizationTree',
    data
  })
}
//隐患列（待验收、已验收）
export const queryListByRecord = data => {
  return get({
    url: '/tvrjet-edz-supervision-app/inspectionHiddenDanger/queryListByRecord',
    data
  })
}
//拍照验收
export const photoAcceptance = data => {
  return post({
    url: '/tvrjet-edz-supervision-app/inspectionHiddenDanger/photoAcceptance',
    data
  })
}
