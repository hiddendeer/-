<template>
  <div class="content">
    <fui-form ref="refForm">
      <template v-for="(item, index) in fieldParamsConfig" :key="index">
        <!-- 单行文本控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `input`"
          :labelSize="props.labelSize"
        >
          <fui-input
            v-model="formObj[item.model]"
            :borderBottom="false"
            :padding="[0]"
            :placeholder="item.placeholder"
            :size="props.labelSize"
            :type="item.isNum ? `number` : `text`"
            :maxlength="item.isNum ? 20 : 50"
          >
            <fui-icon
              v-if="item.desc"
              name="help"
              color="#333"
              :size="48"
              @click="openDialog(item.desc)"
            ></fui-icon>
          </fui-input>
        </fui-form-item>
        <!-- 数字输入框控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `inputNum`"
          :labelSize="props.labelSize"
        >
          <fui-input-number
            v-model="formObj[item.model]"
            width="60rpx"
          ></fui-input-number>
        </fui-form-item>
        <!-- 多行文本控件 -->
        <fui-form-item
          v-if="item.type == `textarea`"
          :labelSize="props.labelSize"
        >
          <fui-textarea
            v-model="formObj[item.model]"
            :label="item.label"
            :labelSize="props.labelSize"
            :borderTop="false"
            :borderBottom="false"
            :flexStart="true"
            :padding="[0]"
            :placeholder="item.placeholder"
            :size="props.labelSize"
            :type="item.isNum ? `number` : `text`"
            :maxlength="item.isNum ? 20 : 300"
          >
            <fui-icon
              v-if="item.desc"
              name="help"
              color="#333"
              :size="48"
              @click="openDialog(item.desc)"
            ></fui-icon>
          </fui-textarea>
        </fui-form-item>
        <!-- 单选控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `select`"
          arrow
          highlight
          @click="openSelectPop(item, index)"
          :labelSize="props.labelSize"
        >
          <fui-input
            v-model="formObj[item.model]"
            :size="props.labelSize"
            disabled
            :borderBottom="false"
            :padding="[0]"
            :placeholder="item.placeholder"
            :textRight="true"
          >
          </fui-input>
        </fui-form-item>
        <!-- 多选控件 -->
        <fui-form-item
          :label="item.name"
          v-if="item.type == `checkbox`"
          arrow
          highlight
          @click="openSelectPop(item)"
          :labelSize="props.labelSize"
        >
          <fui-input
            v-model="formObj[item.model]"
            :size="props.labelSize"
            disabled
            :borderBottom="false"
            :padding="[0]"
            :placeholder="item.placeholder"
            :textRight="true"
          ></fui-input>
        </fui-form-item>
        <!-- 单选日期控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `date-picker` && !item.config"
          arrow
          highlight
          @click="openPicker(item)"
          :labelSize="props.labelSize"
        >
          <fui-input
            v-model="formObj[item.model]"
            :size="props.labelSize"
            :borderBottom="false"
            :padding="[0]"
            :placeholder="item.placeholder"
            :textRight="true"
          ></fui-input>
        </fui-form-item>
        <!-- 范围日期控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `date-picker` && item?.config?.type == `daterange`"
          arrow
          highlight
          @click="openPicker(item)"
          :labelSize="props.labelSize"
        >
          <fui-input
            v-model="formObj[item.model]"
            :size="props.labelSize"
            :borderBottom="false"
            :padding="[0]"
            :placeholder="item.placeholder"
            :textRight="true"
          ></fui-input>
        </fui-form-item>

        <!-- Rate评分控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `rate`"
          :labelSize="props.labelSize"
        >
          <fui-rate
            :score="formObj[item.model]"
            color="#888"
            :size="40"
            allowHalf
            @change="(e) => rateChange(e, item.model)"
          ></fui-rate>
        </fui-form-item>

        <!-- switch控件 -->
        <fui-form-item
          :label="item.label"
          v-if="item.type == `switch`"
          :labelSize="props.labelSize"
        >
          <fui-switch
            :checked="formObj[item.model] == `` ? false : true"
            :scaleRatio="0.7"
            color="#FFB703"
            @change="(e) => switchChange(e, item.model)"
          ></fui-switch>
        </fui-form-item>

        <!-- 图片上传控件 -->
        <fui-form-item v-if="item.type == `imgUpload`">
          <div class="label-class">{{ item.name }}</div>
          <fui-upload
            immediate
            :url="uploadUrl"
            ref="refUpload"
            @success="(e) => successUpload(e, item)"
            @complete="(e) => completeUpload(e, item)"
            :max="20"
          ></fui-upload>
        </fui-form-item>
        <!-- 视频上传控件 -->
        <!-- <fui-form-item v-if="item.type == `videoUpload`">
          <div class="label-class">{{ item.name }}</div>
          <fui-upload-video
            immediate
             type="video/mp4"
            :sourceType="sourceType"
            :fileList="fileList"
            :url="uploadUrl"
            ref="refVideoUpload"
            @success="(e) => successVideoUpload(e, item)"
            @complete="(e) => completeVideoUpload(e, item)"
            :max="5"
          ></fui-upload-video>
        </fui-form-item> -->
      </template>
    </fui-form>
  </div>
  <!-- 选择器控件 -->
  <fui-select
    :show="showObj.showPop"
    v-if="showObj.showPop"
    :options="selectItems"
    :title="selectTitle"
    @confirm="onConfirm"
    @close="onClose"
    :multiple="isMultiple"
    :isReverse="true"
  ></fui-select>
  <!-- 日期选择器控件 -->
  <fui-date-picker
    :value="currentDate"
    :show="showObj.showPicker"
    :range="isRange"
    type="3"
    @change="changePick"
    @cancel="cancelPick"
  ></fui-date-picker>
  <!-- 弹框 -->
  <fui-dialog
    :show="showObj.showDialog"
    title="填报描述"
    :content="dialogContent"
    maskClosable
    :buttons="buttons"
    @click="clickDialog"
  ></fui-dialog>
</template>

<script setup>
import _ from "lodash";
import { onMounted, reactive, ref, getCurrentInstance, watch } from "vue";

const { proxy } = getCurrentInstance();

const props = defineProps({
  fieldParams: {
    type: Array,
    default: () => [],
  },
  labelSize: {
    type: Number,
    default: 26,
  },
});

const sourceType = ref(["album"]);

const buttons = [
  {
    text: "确定",
    color: "#465CFF",
  },
];

/**
 * 表单变量集合
 */
const refForm = ref(null); // 表单对象
const refUpload = ref(null);
const refVideoUpload = ref(null);
const fieldParamsConfig = ref([]); // 配置字段
const formObj = ref({}); // 表单数据

/**
 * 控制显隐
 */
const showObj = reactive({
  showPop: false,
  showPicker: false,
  showDialog: false,
});

const isMultiple = ref(false); // 单多选
const isRange = ref(false); // 单多选

// 选择器的列表数据
const selectItems = ref([]); // 选择的列表数据
const selectIndex = ref(0); // 选中的索引
const currentDate = ref(proxy.$vrFunc.nowDateYmd()); // 当前时间

// 验证规则
const rules = ref([]);

const selectModel = ref(""); // 当前选中的model名称
// 上传变量集合
const uploadUrl = ref(window.location.origin + "/tvrjet-file-app/file/addFile");
// const uploadUrl = ref("https://ffa.firstui.cn/api/example/upload-file");

// 已上传文件地址集合
const fileListObj = ref({});
const fileList = [
  "http://192.168.1.240:50001/wx.hidden.dangers.report/7e62efa1f5d544578d12c184f9cd80f4.mp4",
  "http://120.48.115.253:18080/files/plan/def203ae-4a9d-4042-b2ca-5d464df0a430.mp4",
  "https://ffa.firstui.cn/uploadfile/221206131012717.mp4",
];

/**
 * 展示
 */
const selectTitle = ref("请选择"); // 弹框title
const dialogContent = ref(""); // 弹框title

onMounted(() => {});

//处理配置json数据
const handleFieldParams = () => {
  for (const item of fieldParamsConfig.value) {
    formObj.value[item.model] = "";
    // rules处理
    handleRule(item);
    // 根据类型处理数据
    if (["imgUpload", "videoUpload"].includes(item.type)) {
      fileListObj.value[item.model] = [];
    }
  }
};

// 校验自定义-不可输入特殊字符
const checkSpecial = (value) => {
  return /^[\u4E00-\u9FA5A-Za-z0-9\-\[\]@#￥%!~*&?（）(),，.。_]*$/.test(value);
};

// 处理表单验证
const handleRule = (item) => {
  let inputRule = {
    name: item.model,
    rule: [],
    msg: [],
  };

  // 自定义验证
  if (item.type == "input" || item.type == "textarea") {
    inputRule.validator = [
      {
        msg: item.label + "存在特殊字符!",
        method: checkSpecial,
      },
    ];
  }

  // 必填验证
  if (item?.rule && item?.rule.length > 0) {
    const requiredIndex = item?.rule?.findIndex((item) => item.required);
    if (requiredIndex > -1) {
      inputRule.rule.push("required");
      inputRule.msg.push(item.label + "必填");
    }
  }

  // 数字验证
  if (item.type == `inputNum`) {
    inputRule.rule.push("isNumber");
    inputRule.msg.push(item.label + "必须为数字");
  }

  rules.value.push(inputRule);
};

//提交回调时处理数据
const handleSumbitData = async () => {
  const checkRes = await refForm.value.validator(formObj.value, rules.value);

  if (!checkRes.isPassed) {
    return false;
  }

  return formObj.value;
};

// 选择器赋值
const openSelectPop = (item, index) => {
  // 当前选中的model
  selectModel.value = item.model;
  // 当前选中的表单项索引。
  selectIndex.value = index;

  if (item.type == "select" && !item.multiple) {
    selectTitle.value = "请选择(单选)";
    isMultiple.value = false;
  } else if (item.type == "select" && item.multiple) {
    item.options.forEach((item, index) => {
      item.text = item.label;
      item.index = index;
    });
    selectTitle.value = "请选择(多选)";
    isMultiple.value = true;
  }

  // 赋值+显隐
  if (Array.isArray(item.options) && item.options.length > 0) {
    let options = item.options;
    options?.forEach((item) => {
      item.text = item.label;
    });
    selectItems.value = item.options;
  }
  showObj.showPop = true;
};

// 打开日期
const openPicker = (item) => {
  selectModel.value = item.model;
  if (item.type == "date-picker" && !item?.config) {
    isRange.value = false;
  } else if (item.type == "date-picker" && item?.config?.type == `daterange`) {
    isRange.value = true;
  }
  showObj.showPicker = true;
};

//上传成功触发
const successUpload = (e) => {
  console.log(e, "图片上传");
  let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
  if (res.data) {
    //处理结果返回给组件
    console.log(refUpload.value, "refUpload.value");
    refUpload.value[0].result(res.data, e.index);
  }
};

//图片选择、上传完成、删除时触发
const completeUpload = (e, rowData) => {
  fileListObj.value[rowData.model] = e.urls;
};
//上传成功触发
const successVideoUpload = (e) => {
  console.log(e);
  let res = JSON.parse(e.res.data.replace(/\ufeff/g, "") || "{}");
  if (res.data.url) {
    //处理结果返回给组件
    console.log(refUpload.value, "refUpload.value");
    refVideoUpload.value[0].result(res.data.url, e.index);
  }
};

//图片选择、上传完成、删除时触发
const completeVideoUpload = (e, rowData) => {
  // fileListObj.value[rowData.model] = e.urls;
};

// 选择器-选中状态
const onConfirm = (e) => {
  // 通过是否数组判断单多选
  if (Array.isArray(e.options)) {
    // 选中处理
    selectItems.value.forEach((item) => {
      if (item.checked) {
        item.checked = false;
      }
    });
    e.options.forEach((item) => {
      selectItems.value[item.index].checked = true;
    });
    const dataMap = e.options.map((item) => item.text);
    formObj.value[selectModel.value] = dataMap.join(",");
  } else {
    // 数据填充(单选)
    // 选中处理
    if (fieldParamsConfig.value[selectIndex.value]?.options) {
      // 清除弹框列表之前的选中信息
      fieldParamsConfig.value[selectIndex.value]?.options.forEach((item) => {
        if (item.checked) {
          item.checked = false;
        }
      });
      // 找到索引选中当前对象
      fieldParamsConfig.value[selectIndex.value].options[
        e.index
      ].checked = true;

      formObj.value[selectModel.value] = e.options.text;
    }
  }
  showObj.showPop = false;
};
const onClose = () => {
  showObj.showPop = false;
};

// 选中日期处理
const changePick = (e) => {
  if (e.startDate) {
    formObj.value[selectModel.value] =
      e.startDate.result + " 至 " + e.endDate.result;
  } else {
    formObj.value[selectModel.value] = e.result;
  }
  showObj.showPicker = false;
};
const cancelPick = () => {
  showObj.showPicker = false;
};
const openDialog = (text) => {
  console.log(text);
  dialogContent.value = text;
  showObj.showDialog = true;
};

// 触发关闭弹框
const clickDialog = () => {
  showObj.showDialog = false;
};

// 评分触发赋值
const rateChange = (e, model) => {
  if (formObj.value.hasOwnProperty(model)) {
    formObj.value[model] = e.score;
  }
};

// switch触发赋值
const switchChange = (e, model) => {
  if (formObj.value.hasOwnProperty(model)) {
    formObj.value[model] = e.detail.value;
  }
};

// 重置表单数据
const resetData = () => {
  Object.keys(formObj.value).forEach((key) => {
    delete formObj.value[key];
  });
};

// 回显数据
const detailTrigger = (params) => {
  if (Object.keys(params).length > 0) {
    for (const obj in params) {
      formObj.value[obj] = params[obj];
    }
  }
};

// 监听配置Json
watch(
  () => props.fieldParams,
  (newVal) => {
    if (Array.isArray(newVal) && newVal.length > 0) {
      fieldParamsConfig.value = _.cloneDeep(newVal);
      handleFieldParams();
    }
  },
  {
    deep: true,
    immediate: true,
  }
);

defineExpose({
  formObj,
  handleSumbitData,
  detailTrigger,
  resetData,
});
</script>

<style lang="scss" scoped>
.label-class {
  font-size: 28rpx;
  padding-bottom: 10px;
}
</style>