import http from '@/components/firstui/fui-request'

//初始化请求配置项
http.create({
    //接口域名
    host: 'http://127.0.0.1:8000',
    header: {
        // 'content-type': 'application/x-www-form-urlencoded'
    }
})

//请求拦截
http.interceptors.request.use(config => {
    //请求之前可在请求头中加入token等信息
    let token = uni.getStorageSync('TOKEN') || '';
    if (token) {
        config.header = {
            'Authorization': 'JWT ' + token
        }
    }

    return config
})

//响应拦截
http.interceptors.response.use(response => {
    // 其它错误码判断
    if ([401, 4000].includes(response?.data?.code)) {
        uni.reLaunch({
            url: "/pages/login/login"
        });
    }
    // success response
    if (response?.data?.code == '2000') {
        return response.data;
    }

},
    error => {
        uni.reLaunch({
            url: "/pages/login/login"
        });
    }
)

export default http
