<template>
  <view>
    <fui-status-bar background="red" isFixed></fui-status-bar>
    <fui-nav-bar title="我的" size="14" splitLine> </fui-nav-bar>
    <view class="container">
      <view class="h-[280rpx] relative">
        <img
          class="w-[100%] h-[230rpx]"
          src="/static/images/me-bg.png"
        />
        <view class="absolute bottom-[10px] w-[100%] h-[140rpx]">
          <view
            class="w-[80%] m-auto h-[100%] bg-[#fff]"
            style="border-radius: 10rpx; box-shadow: 2px 2px 5px 0px rgba(60, 60, 90, 0.1);"
          >
          <view class="w-[100%] h-[100%] px-[20px] flex items-center" >
            <view>
              <img src="@/static/svg/head.svg" class="w-[40px] h-[40px]">
            </view>
            <view class="pl-[28rpx] text-28rpx">
              {{ userInfo?.name }}
            </view>
          </view>
          </view>
        </view>
      </view>
      <view class="px-[20px] flex justify-start flex-wrap">
        <view v-for="item in appList" class="flex flex-col p-[16rpx]">
          <img class="w-[35px] h-[35px]" :src="item.icon" alt="">
          <span class="text-center">{{ item.text }}</span>
        </view>
     
      </view>
    </view>
    <tabBar></tabBar>
  </view>
</template>

<script setup>
import api from "./server/api.js";
import tabBar from "@/pages/tabbar/index.vue";

import { onShow } from "@dcloudio/uni-app";
import { ref, onMounted } from "vue";

const contentHeight = ref(`100vh - 94px - ${uni.getWindowInfo().statusBarHeight+`px`}`)

const userInfo = ref({});

onShow(() => {

});

const appList = ref([
  {
    text: '打车',
    icon: '/static/svg/cz.svg',
    path: "",
  },
  {
    text: '发票',
    icon: '/static/svg/fp.svg',
    path: "",
  },
  {
    text: '打车',
    icon: '/static/svg/cz.svg',
    path: "",
  },
  {
    text: '发票',
    icon: '/static/svg/fp.svg',
    path: "",
  },
  {
    text: '打车',
    icon: '/static/svg/cz.svg',
    path: "",
  },
]);


onMounted(async () => {
  getUserInfo();
});

const getUserInfo = async() => {
  const res = await api.user_info();
  if (res?.code == 2000) {
    userInfo.value = res.data;
  } else {
  }
}
</script>

<style lang="scss" scoped>
.container{
  background-color: #f4f4f4;
  height: calc(v-bind(contentHeight));
}
</style>