import http from '@/utils/network.js'

export default class api {
    static loginIn (data) {
      return http.request({
        url: '/api/login/',
        method: 'POST',
        data: data
      })
    }
    static order_info (data) {
      return http.request({
        url: '/api/system/order_info/',
        method: 'GET',
        data
      })
    }
    static user_info () {
      return http.request({
        url: '/api/system/user/user_info/',
        method: 'GET',
      })
    }
  }