import http from '@/utils/network.js'

export default class api {
    static get_recent_info (data) {
      return http.request({
        url: '/api/system/order_info/get_recent_info/',
        method: 'GET',
        data: data
      })
    }
    static get_detail_info (data) {
      return http.request({
        url: '/api/system/order_info/get_detail_info/',
        method: 'GET',
        data: data
      })
    }
    static addOrder (data) {
      return http.request({
        url: '/api/system/order_info/',
        method: 'POST',
        data: data
      })
    }
  }