<template>
  <div>
    <fui-status-bar isFixed></fui-status-bar>
    <fui-nav-bar title="详情" size="14" splitLine> 
        <fui-icon name="arrowleft" @click="back"></fui-icon>
    </fui-nav-bar>
    <div class="p-[20px]">
      <div>
        <div class="flex py-[8px]">
          <span class="flex-[1.5] text-[#a3a3a3]">名称:</span>
          <span class="flex-[6]">{{ order_info.name }}</span>
        </div>
        <div class="flex py-[8px]">
          <span class="flex-[1.5] text-[#a3a3a3]">编码:</span>
          <span class="flex-[6]">{{ order_info.code }}</span>
        </div>
        <div class="flex py-[8px]">
          <span class="flex-[1.5] text-[#a3a3a3]">状态:</span>
          <span class="flex-[6]">{{ order_info.status_name }}</span>
        </div>
        <div class="flex py-[8px]">
          <span class="flex-[1.5] text-[#a3a3a3]">创建人:</span>
          <span class="flex-[6]">{{ order_info.creator_name }}</span>
        </div>
        <div class="flex py-[8px]">
          <span class="flex-[1.5] text-[#a3a3a3]">创建时间:</span>
          <span class="flex-[6]">{{ order_info.create_datetime }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import api from "./server/api";
import { ref, onMounted } from "vue";
import { onLoad } from "@dcloudio/uni-app";

const order_info = ref({});

onLoad((e) => {
  getDetail(e.id);
});

const getDetail = async (id) => {
  const res = await api.get_detail_info({
    id,
  });
  if (res?.code == 2000) {
    order_info.value = res?.data;
  }
};

const back = () => {
    uni.navigateBack();
}
</script>

<style lang="scss" scoped>
</style>