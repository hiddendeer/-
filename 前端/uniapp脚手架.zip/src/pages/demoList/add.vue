<template>
  <div>
    <fui-status-bar background="red" isFixed></fui-status-bar>
    <fui-nav-bar title="新增订单" size="14" splitLine> </fui-nav-bar>
    <div>
      <settingForm
        ref="settingFormRef"
        :fieldParams="fieldParams"
      ></settingForm>
      <div class="flex justify-center mt-[50px]">
        <fui-button
          type="primary"
          bold
          width="70%"
          height="55rpx"
          radius="20rpx"
          size="26"
          @click="addOrder"
        >
          新增订单
        </fui-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import settingForm from "../../components/vr-form/settingForm.vue";
import api from "./server/api";

const settingFormRef = ref(null);

const fieldParams = ref([
  {
    label: "订单名称",
    placeholder: "请填写",
    model: "name",
    type: "input",
    value: "",
    isRequired: true,
    rule: [{ required: true, message: "必填" }],
  },
  {
    label: "订单编码",
    placeholder: "请填写",
    model: "code",
    type: "input",
    value: "",
    isRequired: true,
    rule: [{ required: true, message: "必填" }],
  },
]);

const addOrder = async () => {
  let jsonData = {};
  const res = await settingFormRef.value.handleSumbitData();
  if (res) {
    jsonData = { ...res, user: uni.getStorageSync("role_info")?.[0]?.id, status: '0' };
    const addRes = await api.addOrder(jsonData);
    if (addRes?.code == 2000) {
        uni.switchTab({
            url: "/pages/demoList/index"
        })
    }
  }
};
</script>

<style lang="scss" scoped>
</style>