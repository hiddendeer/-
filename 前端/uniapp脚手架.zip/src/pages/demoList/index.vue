<template>
  <view>
    <fui-status-bar background="red" isFixed></fui-status-bar>
    <fui-nav-bar title="列表" size="14" splitLine> </fui-nav-bar>
    <div class="container">
      <div class="pt-[8px] px-[25px] flex justify-end">
        <fui-button type="link" bold  width="150rpx" height="40rpx" size="26" color="#465CFF" @click="addOrder"  >
          <template #default>
            <fui-icon size="40" name="plus" color="#465CFF"></fui-icon>新增订单
          </template>
        </fui-button>
      </div>
      <div class="my-[20px]" v-for="item in orderInfo">
        <div
          class="bg-[#fff] w-[85%] m-auto min-h-[100px] rounded-[5px] flex flex-col justify-center"
        >
        <div @click="triggerJump(item.id)">
          <div class="pl-[10px] py-[5px] text-28rpx flex">
            <span class="flex-[1.5]">订单名:</span
            ><span class="flex-[5] font-bold">{{ item.name }}</span>
          </div>
          <div class="pl-[10px] py-[5px] text-28rpx flex">
            <span class="flex-[1.5]">订单编码:</span
            ><span class="flex-[5] font-bold">{{ item.code }}</span>
          </div>
          <div class="pl-[10px] py-[5px] text-28rpx flex">
            <span class="f flex-[1.5]">状态:</span
            >
            <span v-if="item.status_name == `进行中`" class="flex-[5] font-bold text-[#16a34a]">{{ item.status_name }}</span>
            <span v-else class="flex-[5] font-bold text-[#dc2626]">{{ item.status_name }}</span>
          </div>
          <div class="pl-[10px] py-[5px] text-28rpx flex">
            <span class="flex-[1.5]">创建时间:</span
            ><span class="flex-[5] font-bold">{{ item.update_datetime }}</span>
          </div>
        </div>
        </div>
      </div>
    </div>
  </view>
  <tabBar />
</template>

<script setup>
import tabBar from "@/pages/tabbar/index.vue";
import api from "./server/api";
import { ref, onMounted } from "vue";
import { onShow } from "@dcloudio/uni-app";

const contentHeight = ref(
  `100vh - 94px - ${uni.getWindowInfo().statusBarHeight + `px`}`
);

const orderInfo = ref({});

onShow(() => {
  getList();
});

const getList = async () => {
  const res = await api.get_recent_info({page: 1, limit: 100});
  if (res?.code == 2000) {
    orderInfo.value = res.data;
  }
};

const addOrder = () => {
  uni.navigateTo({
    url: "/pages/demoList/add"
  })
}

const triggerJump = (id) => {
  uni.navigateTo({
    url: "/pages/demoList/detail?id=" + id
  })
}
</script>

<style lang="scss" scoped>
.container {
  border: 1px solid #f4f4f4;
  background-color: #f4f4f4;
  height: calc(v-bind(contentHeight));
  overflow: scroll;
}
</style>