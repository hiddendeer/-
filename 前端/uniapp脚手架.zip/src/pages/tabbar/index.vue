<template>
  <view>
    <fui-bottom-navbar
      :items="options"
      left="8"
      @click="triggerNav"
    ></fui-bottom-navbar>
  </view>
</template>

<script setup>
import { ref, onMounted } from "vue";

const contentHeight = ref(`100vh - 94px - ${uni.getWindowInfo().statusBarHeight+`px`}`)

onMounted(() => {
})
const options = ref(
  [
    {
      text: "首页",
      path: "/pages/demo/yifengDemo/index", //页面路径
      size: 24,
      src: "/static/svg/1.svg",
      width: 35,
      //图片高度，单位rpx，默认40，可选
      height: 35,
    },
    {
      text: "测试2",
      path: "/pages/demoList/index", //页面路径
      src: "/static/svg/2.svg",
      size: 24,
      width: 35,
      //图片高度，单位rpx，默认40，可选
      height: 35,
    },
    {
      text: "测试3",
      src: "/static/svg/3.svg",
      size: 24,
      width: 35,
      //图片高度，单位rpx，默认40，可选
      height: 35,
    },
    {
      text: "我的",
      path: "/pages/me/index", //页面路径
      src: "/static/svg/my.svg",
      size: 24,
      width: 35,
      //图片高度，单位rpx，默认40，可选
      height: 35,
    },
  ]
  //二级菜单
);

const triggerNav = (e) => {
  uni.switchTab({
    url: e.path,
  });
};
</script>

<style lang="scss" scoped>


</style>

<style>
.container{
  background-color: #f4f4f4;
  height: calc(v-bind(contentHeight));
}
</style>