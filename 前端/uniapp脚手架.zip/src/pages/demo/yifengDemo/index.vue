<template>
  <div class="page mine-page">
    <fui-nav-bar
      title="首页"
      @leftClick="backClick"
      @rightClick="toBarcodePage"
    >
      <!-- <fui-icon name="arrowleft"></fui-icon> -->
      <template v-slot:right>
        <fui-icon name="scan"></fui-icon>
      </template>
    </fui-nav-bar>
    <div class="allDemos">
      <div
        v-for="(item, index) in demosList"
        :key="'demo_' + index"
        class="onecDemo"
        @click="toDemo(item.url)"
      >
        <div class="demoData">
          {{ item.name }}
        </div>
      </div>
    </div>
  </div>
  <tabBar></tabBar>
</template>

<script setup>
import tabBar from "@/pages/tabbar/index.vue";
const demosList = [
  // {
  //   name: "头像选择器",
  //   url: "/pages/20221101_change-header-image/index"
  // },
  // {
  //   name: "引导遮罩",
  //   url: "/pages/20221019_guide-step/index"
  // },
  // {
  //   name: "树结构选择器(新)",
  //   url: "/pages/20221013_select-org/index"
  // },
  {
    name: "组织架构人员选择器",
    url: "/pages/demo/yifengDemo/select-user-org/index"
  },
  {
    name: "html2canvas截图",
    url: "/pages/demo/yifengDemo/html2canvas/index"
  },
  {
    name: "生成二维码",
    url: "/pages/demo/yifengDemo/qrcode/index"
  }
];

//跳转对应页面
const toDemo = (url) => {
  uni.navigateTo({
    url: url
  });
};
//扫码功能
const backClick = () => {
  uni.navigateBack();
};
//扫码功能
const toBarcodePage = () => {
  uni.scanCode({
    success: (res) => {
      let { result } = res;
      console.log("result", result);
    }
  });
};
</script>

<style lang="scss" scoped>
.mine-page {
  width: 100%;
  overflow: auto;
  padding-bottom: calc(100rpx + env(safe-area-inset-bottom));
  .allDemos {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-row-gap: 30rpx;
    grid-column-gap: 30rpx;
    margin: 20rpx;
    .onecDemo {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 10rpx;
      height: 160rpx;
      background: #fff;
      border-radius: 20rpx;
      border: 1rpx solid #999;
      .demoData {
        text-align: center;
      }
    }
  }
}
</style>
