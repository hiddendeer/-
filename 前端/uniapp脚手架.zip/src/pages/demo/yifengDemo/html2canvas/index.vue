<template>
  <div class="page qr-wrap">
    <fui-nav-bar title="html2canvas截图" @leftClick="leftClick">
      <fui-icon name="arrowleft"></fui-icon>
    </fui-nav-bar>
    <div class="detail">
      <Html2canvas
        ref="html2canvas"
        :domId="domId"
        @renderFinish="renderFinish"
      >
        <div id="detailMiddle">
          <div class="detail__middle">
            <div class="oncLine">
              <div class="title">姓名：</div>
              <div class="lable">xxxxxx</div>
            </div>
            <div class="oncLine">
              <div class="title">手机号码：</div>
              <div class="lable">151xxxx1511</div>
            </div>
            <div v-if="userCardData.userEmail" class="oncLine">
              <div class="title">邮箱：</div>
              <div class="lable">151xxxxxxx@163.com</div>
            </div>
            <div class="oncLine">
              <div class="title">所在地区：</div>
              <div class="lable">
                辽宁省/大连市/甘井子区/跨海大桥高新区上桥方向第五个桥墩
              </div>
            </div>
          </div>
          <div class="detail__qr">
            <div class="qr-box">
              <image :src="qrRBase64" />
            </div>
          </div>
        </div>
      </Html2canvas>
    </div>
    <TkiQrcode
      v-show="tkiQrcodeShow"
      ref="qrcode"
      :val="onStringify()"
      @result="getQrRBase64"
    ></TkiQrcode>
    <div class="bottom-btn">
      <div class="onceBtn" v-for="item in bottomBtnData" :key="item.type">
        <fui-button type="primary" @click="createQRImg(item.type)">
          {{ item.btnName }}
        </fui-button>
      </div>
    </div>
  </div>
</template>

<script>
import TkiQrcode from "@/components/tki-qrcode/tki-qrcode";
import Html2canvas from "@/components/html2canvas/html2canvas.vue";
import { pathToBase64 } from "@/utils/image-tools.js";
export default {
  data() {
    return {
      userCardData: {},
      userAccountId: "",
      qrcodeUrl: "一个普通的二维码",
      title: "我的名片",
      bottomBtnData: [
        {
          type: "save",
          btnName: "保存"
        },
        {
          type: "WXSceneSession",
          btnName: "微信"
        },
        {
          type: "WXSceneTimeline",
          btnName: "朋友圈"
        },
        {
          type: "phone",
          btnName: "拨打电话"
        },
        {
          type: "savePhone",
          btnName: "保存到通讯录"
        }
      ],
      domId: "",
      qrRBase64: "",
      tkiQrcodeShow: true,
      saveType: ""
    };
  },
  components: {
    TkiQrcode,
    Html2canvas
  },
  onLoad(option) {
    this.getCreateGGQrcode();
  },

  methods: {
    //传入tki-qrcode值
    onStringify() {
      return this.qrcodeUrl;
    },
    //生成二维码后的回调函数，将二维码路径转为base64
    getQrRBase64(e) {
      //二维码路径转为base64
      pathToBase64(e)
        .then((res) => {
          this.qrRBase64 = res;
          this.tkiQrcodeShow = false;
        })
        .catch((err) => {});
    },
    //点击保存后domId改变，由html2canvas触发此方法进行保存操作
    renderFinish(filePath) {
      this.domId = "";
      this.filePath = filePath;
      if (this.saveType == "save") {
        uni.saveImageToPhotosAlbum({
          filePath: filePath,
          success: function () {
            uni.showToast({
              icon: "success",
              title: "保存成功",
              duration: 1500
            });
          }
        });
      } else if (type == "phone") {
        uni.makePhoneCall({
          phoneNumber: this.userCardData.mobilePhone
        });
      } else if (type == "savePhone") {
        uni.addPhoneContact({
          firstName: this.userCardData.userName,
          mobilePhoneNumber: this.userCardData.mobilePhone,
          success: function () {
            console.log("success");
            uni.showToast({
              title: "已保存到通讯录！",
              icon: "none"
            });
          },
          fail: function () {
            console.log("fail");
            uni.showToast({
              title: "保存到通讯录失败！",
              icon: "none"
            });
          }
        });
      } else {
        try {
          uni.share({
            provider: "weixin",
            scene: this.saveType,
            type: 2,
            imageUrl: filePath,
            success: (res) => {
              uni.showToast({
                title: "分享成功",
                icon: "none"
              });
            },
            fail: function (err) {
              console.log("err", err);
              let title = "分享遇到了一些问题";
              if (
                err.errMsg.indexOf("客户端未安装") > -1 ||
                err.errMsg.indexOf("微信未安装") > -1
              ) {
                title = "尚未安装微信，请安装微信";
              }
              uni.showToast({
                title: title,
                icon: "none"
              });
            }
          });
        } catch (error) {
          console.log("error", error);
          uni.showToast({
            title: "分享遇到了一些问题",
            icon: "none"
          });
        }
      }
      this.saveType = "";
    },
    //点击底部按钮
    createQRImg(type) {
      this.saveType = type;
      setTimeout(() => {
        this.domId = "#detailMiddle";
      }, 300);
    },
    //生成二维码
    async getCreateGGQrcode() {
      let timer = setTimeout(() => {
        this.$refs.qrcode._makeCode();
        clearTimeout(timer);
      }, 30);
    },
    //返回
    leftClick() {
      uni.navigateBack();
    }
  }
};
</script>

<style lang="scss" scoped>
.qr-wrap {
  width: 100%;
  background: #fff;
  .detail {
    height: 100%;
    width: 100%;
    overflow: auto;
    padding-bottom: 200rpx;

    &__middle {
      padding: 0 116rpx;
      .oncLine {
        display: flex;
        line-height: 50rpx;
        padding: 12rpx 0;

        .title {
          min-width: 160rpx !important;
          color: #555555;
          font-size: 30rpx;
        }
        .lable {
          font-weight: bold;
          color: #222222;
          text-align: left;
          font-size: 30rpx;
        }
        .mobilePhone {
          color: #4986fb;
          text-decoration: underline;
        }
      }
    }
    &__qr {
      margin: 20rpx;
      padding: 0 30rpx;
      height: fit-content;
      background: #fff;
      padding-bottom: 100px;
      display: flex;
      align-items: center;
      justify-content: center;
      .qr-box {
        width: 367rpx;
        height: 367rpx;
        padding: 18rpx;
        margin-top: 50rpx;
        .tki-qrcode {
          width: 100%;
          height: 100%;
        }
        image {
          width: 100%;
          height: 100%;
        }
      }
    }
  }

  .bottom-btn {
    background: #fff;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-row-gap: 20rpx;
    grid-column-gap: 20rpx;
    padding-bottom: 60rpx;
    .onceBtn {
      text-align: center;
      .btnName {
        font-size: 28rpx;
        color: #555;
      }
    }
  }
  .other {
    grid-template-columns: repeat(2, 1fr) !important;
  }
}
</style>
