<template>
  <view class="page main">
    <fui-nav-bar title="组织架构人员选择器" @leftClick="backClick">
      <fui-icon name="arrowleft"></fui-icon>
    </fui-nav-bar>
    <view class="controlGroup">
      <p>
        是否开启输入框<fui-switch
          checked
          @change="inputOpen = !inputOpen"
        ></fui-switch>
        <fui-button v-if="!inputOpen" type="primary" @click="openOrgUserSelect">
          打开弹窗
        </fui-button>
      </p>
      <p>
        <view
          >主管理员是否可选<fui-switch
            checked
            @change="chooseAdmin = !chooseAdmin"
          ></fui-switch
        ></view>
        <view
          >子管理员是否可选<fui-switch
            @change="chooseSub = !chooseSub"
          ></fui-switch
        ></view>
      </p>
      <p>
        可选人数<fui-input
          type="number"
          v-model="max"
          :inputBorder="true"
        ></fui-input>
      </p>
      <p>
        是否显示已选择的人数<fui-switch
          checked
          @change="showLimit = !showLimit"
        ></fui-switch>
      </p>
      <p>
        返回数据为对象<fui-switch
          @change="returnData = !returnData"
        ></fui-switch>
      </p>
      <p>
        根节点人员是否可选<fui-switch
          checked
          @change="rootNodeOpen = !rootNodeOpen"
        ></fui-switch>
      </p>
    </view>
    <view class="pageData">
      <fui-form :model="DataForm" ref="uForm" class="container__item">
        <view class="oneCell">
          人员：
          <OrgUserSelect
            :userSelect="userSelect"
            :props="props"
            :max="max"
            :inputOpen="inputOpen"
            :chooseAdminOpen="chooseAdmin"
            :chooseSubOpen="chooseSub"
            :showLimit="showLimit"
            :returnData="returnData"
            :rootNodeOpen="rootNodeOpen"
            :checked="DataForm.userCheckedList"
            @confirm="confirms"
            @changePopupShow="changePopupShow"
          />
        </view>
      </fui-form>
      <text>
        已选人员{{ returnData ? "对象数组" : "id数组" }}
        {{ DataForm.userCheckedList }}
      </text>
    </view>
  </view>
</template>

<script>
import OrgUserSelect from "@/componentsEngineer/select-user-org/org-user-select";
export default {
  onLoad() {},
  onShow() {},
  components: {
    OrgUserSelect
  },
  data() {
    return {
      DataForm: {
        userCheckedList: []
      },
      userSelect: false,
      props: {
        label: "organName", //当前部门名字的字段名称
        children: "children", //当前部门的子部门的字段名称
        checkDataId: "organId", //部门的唯一标识的字段名称
        userId: "accountId" //人员唯一标识的字段名称
      },
      max: 99,
      chooseAdmin: true, //主管理员是否可选
      chooseSub: false, //子管理员是否可选
      inputOpen: true, //是否开启编辑
      showLimit: true, //是否开启编辑
      returnData: false, //返回数据为对象
      rootNodeOpen: true //根节点人员是否可选
    };
  },
  methods: {
    backClick() {
      uni.navigateBack();
    },
    //确定
    confirms(val) {
      console.log("val", val);
      this.DataForm.userCheckedList = val;
      this.userSelect = false;
    },
    openOrgUserSelect() {
      this.userSelect = true;
    },
    changePopupShow(val) {
      this.userSelect = val;
    }
  }
};
</script>
<style lang="scss" scoped>
.main {
  overflow: auto;
  .controlGroup {
    padding: 30rpx;
    p {
      display: flex;
      align-items: center;
      padding: 10rpx 0;
      view {
        display: flex;
        align-items: center;
      }
      .u-btn {
        flex: 1;
      }
    }
  }
  .pageData {
    margin: 20rpx;
    padding: 20rpx;
    background: #fff;
    .oneCell {
      display: flex;
      align-items: center;
    }
    text {
      padding-top: 40rpx;
    }
  }
}
</style>
