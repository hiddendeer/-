<template>
  <view>
    <fui-status-bar background="red" isFixed></fui-status-bar>
    <fui-nav-bar title="我的" size="14" splitLine> </fui-nav-bar>
    <view class="container">
   
    </view>
    <tabBar></tabBar>
  </view>
</template>

<script setup>
import tabBar from "@/pages/tabbar/index.vue";

import { onShow } from "@dcloudio/uni-app";
import { ref, onMounted } from "vue";

onShow(() => {
  uni.hideTabBar({
    animation: false,
  });
});

const contentHeight = ref(`100vh - 94px - ${uni.getWindowInfo().statusBarHeight+`px`}`); // 内容高度

onMounted(async () => {

});

</script>

<style lang="scss" scoped>
.container{
  background-color: #f4f4f4;
  height: calc(v-bind(contentHeight));
}
</style>