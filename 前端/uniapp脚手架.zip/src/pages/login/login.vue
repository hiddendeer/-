<template>
  <view class="h-[100vh]">
    <image
      class="absolute top-0 w-full h-[15vh] z-0"
      src="/static/images/login-bg.jpg"
      mode="widthFix"
    />
    <view class="bg-white z-[999] relative top-[20vh] rounded-[20rpx]">
      <view class="login-page h-[80vh]">
        <view class="login-box" v-show="showLoginBox">
          <view class="py-[50rpx] text-40rpx font-bold">
            <view>您好</view>
            <view class="pt-[15rpx]">欢迎登录系统</view>
          </view>
          <template v-if="isAccount">
            <fui-input
              required
              label="账号"
              labelSize="27"
              size="27"
              labelWidth="80"
              placeholder="请输入账号"
              v-model="formData.username"
              maxlength="20"
            ></fui-input>
            <fui-input
              v-model="formData.password"
              maxlength="20"
              label="密码"
              labelSize="27"
              size="27"
              labelWidth="80"
              required
              :padding="['20rpx', '32rpx']"
              placeholder="请输入密码"
              :password="showPassword"
              @input="passwordIpt"
            >
              <fui-icon
                :name="showPassword ? 'invisible' : 'visible'"
                color="#B2B2B2"
                :size="50"
                @click="changePassword"
              ></fui-icon>
            </fui-input>
          </template>
          <template v-else>
            <view>
              <fui-input
                placeholder="手机号"
                labelSize="27"
                size="27"
                :padding="['20rpx', '32rpx']"
              >
                <template v-slot:left>
                  <view class="fui-left__icon pr-[10rpx]">
                    <fui-icon name="mobile" color="#333" :size="48"></fui-icon>
                  </view>
                </template>
              </fui-input>
              <fui-input
                :padding="['20rpx', '32rpx']"
                placeholder="验证码"
                labelSize="27"
                size="27"
              >
                <template v-slot:left>
                  <view class="fui-left__icon pr-[10rpx]">
                    <fui-icon name="captcha" :size="48"></fui-icon>
                  </view>
                </template>
                <fui-countdown-verify
                  background="#fff"
                  borderColor="#fff"
                  color="#ffb703"
                  sent="秒后获取"
                  radius="40"
                  ref="codeRef"
                  @send="sendCode"
                >
                </fui-countdown-verify>
              </fui-input>
            </view>
          </template>
          <view class="pt-[20rpx] flex justify-end">
            <span class="text-24rpx text-[#409EFF]" @click="changeLoginMed">{{
              isAccount ? `验证码登录` : `账号密码登录`
            }}</span>
          </view>
          <view class="submit-btn">
            <fui-button
              text="登 录"
              height="80rpx"
              radius="48rpx"
              @click="submit()"
              :loading="signInLoading"
              :disabled="signInLoading"
            ></fui-button>
          </view>
          <view class="submit-btn text-center text-16px text-[#2563eb]">
            <!-- <span @click="addMerchant">注册账号</span> -->
          </view>
          <fui-divider backgroundColor="#fff" text="欢迎使用系统"></fui-divider>
        </view>
        <view class="mobile-btn" v-show="!showLoginBox">
          <fui-button
            text="手机号一键登录"
            radius="48rpx"
            openType="getPhoneNumber"
            @getphonenumber="submitP"
            :loading="signInLoading"
            :disabled="signInLoading"
          ></fui-button>
        </view>
        <view class="login-way">
          <!-- <view class="btn" @click="showLoginBox = !showLoginBox">{{
            showLoginBox ? "手机号登录" : "密码登录"
          }}</view> -->
          <fui-text
            v-if="!showLoginBox"
            @click="showLoginBox = !showLoginBox"
            :text="showLoginBox ? `一键登录` : `密码登录`"
            type="primary"
            size="27"
          >
          </fui-text>
        </view>
        <fui-toast ref="toast"></fui-toast>
        <fui-safe-area></fui-safe-area>
      </view>
    </view>
    <view
      v-if="showIntroText"
      class="absolute bottom-[25rpx] flex justify-center w-full"
    >
      <span class="text-24rpx text-[#B2B2B2]">江苏伟岸纵横提供技术服务</span>
    </view>
  </view>
  <fui-select
    :show="showSelect"
    :options="companyItems"
    title="请选择企业登录"
    @confirm="onConfirm"
    @close="showSelect = false"
  ></fui-select>
</template>

<script>
import api from "./server/api.js"
import form from "@/components/firstui/fui-validator/fui-validator";
import { Md5 } from 'ts-md5';
export default {
  data() {
    return {
      signInLoading: false,
      currentPlat: uni.getSystemInfoSync().uniPlatform,
      showSelect: false,
      showPassword: true,
      isAccount: true, // 切换账号、验证码登录
      companyItems: [],
      showLoginBox: false,
      showIntroText: true,
      clientHeight: `${uni.getWindowInfo().screenHeight}`,
      //校验规则
      rules: [
        {
          name: "username",
          rule: ["required"],
          msg: ["请输入账号"],
        },
        {
          name: "password",
          rule: ["required"],
          msg: ["请输入密码"],
        },
      ],
      //表单data数据
      formData: {
        username: "superadmin",
        password: "a66abb5684c45962d887564f08346e8d", // Md5.hashStr('admin123456')
      },
    };
  },
  mounted() {
    if (this.clientHeight > uni.getWindowInfo().screenHeight) {
      this.showIntroText = false;
    } else {
      this.showIntroText = true;
    }
  },
  watch: {
    userData: {
      handler(val) {
        if (!_.isEmpty(val)) {
          this.toHomePages();
        }
      },
      deep: true,
    },
  },
  methods: {
    passwordIpt(v) {
      this.$nextTick(() => {
        this.formData.password = v.replace(/[^\d\a-\z\A-\Z]/g, "");
      });
    },
    toHomePages() {
      uni.reLaunch({
        url: "/pages/home/index",
      });
    },
    addMerchant() {
      uni.navigateTo({
        url: "/pages/homePage/newCheck/businessDetail?type=add",
      });
    },
    changeLoginMed() {
      this.isAccount = !this.isAccount;
    },
    sendCode() {
      setTimeout(() => {
        //重置组件状态
        this.$refs.codeRef && this.$refs.codeRef.success();
      }, 200);
    },
    async submit() {
      let res = form.validator(this.formData, this.rules);
      if (res.isPassed) {
        const res = await api.loginIn(this.formData)
        if (res.code == `2000`) {
          uni.setStorageSync('TOKEN', res.data.access)
          uni.setStorageSync('role_info', res.data.role_info)
          console.log(1);
          uni.switchTab({
            url: "/pages/me/index"
          })
        }

      } else {
        this.$refs.toast.show({ text: res.errorMsg });
      }
    },
    async login(userId) {
      const loginRes = await api.login({
        userId,
        clientId: "1187303628294764583",
      });

      if (loginRes?.code && loginRes.code == "00000") {
        uni.setStorageSync("token", loginRes?.data?.otherProperties?.token);
        uni.setStorageSync(
          "merchantId",
          loginRes?.data?.otherProperties?.merchantId
        );
        uni.setStorageSync("account", loginRes?.data?.account);
        uni.setStorageSync("userId", loginRes?.data?.userId);
        this.toHomePages();
      }
    },

    async submitP(v) {
      this.$store.commit("auth/setSignInLoading", true);
      if (v.errMsg !== "getPhoneNumber:ok") {
        this.$store.commit("auth/setSignInLoading", false);
        return;
      }
      this.$store.dispatch("auth/onSignIn", {
        appId: "wxa110c4259b7e0a05",
        secret: "680d64843c09d43dd1fe331a45fa0461",
        code: v.code,
      });
    },
    onConfirm(e) {
      this.login(e.options.id);
    },
    changePassword() {
      this.showPassword = !this.showPassword;
    },
  },
};
</script>
<style lang="scss" scoped>
.login-page {
  padding: 0 32rpx;
  display: flex;
  flex-direction: column;

  .mobile-btn {
    margin-top: 130rpx;
    /* #ifdef H5*/
    display: none;
    /* #endif */
  }

  .login-box {
    margin-top: 30rpx;
    /* #ifdef H5*/
    display: block !important;

    /* #endif */
    .submit-btn {
      margin-top: 40rpx !important;
      width: 80%;
      margin: auto;
    }
  }

  .login-way {
    display: flex;
    justify-content: center;
    margin-top: 74rpx;
    /* #ifdef H5*/
    display: none;

    /* #endif */
    .btn {
      font-size: 32rpx;
      font-weight: 500;
      text-decoration: underline;
      color: #465cff;
      line-height: 45rpx;
      cursor: pointer;
    }
  }
}
</style>
