import http from '@/utils/network.js'

export default class api {
    static loginIn (data) {
      return http.request({
        url: '/api/login/',
        method: 'POST',
        data: data
      })
    }
    static order_info (params) {
      return http.request({
        url: '/api/system/order_info/',
        method: 'GET',
        params: params
      })
    }
  }