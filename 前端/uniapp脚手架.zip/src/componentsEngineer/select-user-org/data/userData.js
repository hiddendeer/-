var userDataList = [
    {
        "accountId": "bdeb6116bddf094cb1b46e306e929ea4",
        "organNames": [],
        "isMain": true,
        "prefix": "1",
        "userMobilePhone": "15542419308",
        "organId": "d5b2d6a1e9eac2f0af64253a6d22abbf",
        "isSub": false,
        "check": false,
        "userName": "155zyf2",
        "userIcon": "",
        "userId": "ca401a36f228f282f686023410add2bb"
    },
    {
        "accountId": "f629c7865f4865cdfcb68275bfdbfda9",
        "organNames": [
            "测试部门1"
        ],
        "isMain": false,
        "prefix": "C",
        "userMobilePhone": "15654874615",
        "organId": "6dc81804231a782f0d39fc8203158e56",
        "isSub": false,
        "check": false,
        "userName": "测试成员1",
        "userIcon": "",
        "userId": "1ae94362d14962b9a4ad14bb8964024a"
    },
    {
        "accountId": "11f76ea35e1a826e97e771ce5d1de668",
        "organNames": [
            "测试部门1-1"
        ],
        "isMain": false,
        "prefix": "C",
        "userMobilePhone": "16891561879",
        "organId": "3825e7e29ac373da41b91986393ba3e9",
        "isSub": false,
        "check": false,
        "userName": "测试成员2",
        "userIcon": "",
        "userId": "cdb4204eb1ae5c66a06358f79411ec4c"
    }
]



export default userDataList;