<script>
export default {
  onLaunch: function ({ path }) {
    console.log("App Launch");
    this.routerIntercept(path);
  },
  methods: {
    routerIntercept(path) {
      console.log(path);
      const whitelist = ["/", "/#/"];
      const methodToPatch = [
        "navigateTo",
        "redirectTo",
        "switchTab",
        "navigateBack",
      ];
      const thia = this;
      methodToPatch.map((type) => {
        //首次进入页面也应该进行判断
        uni.addInterceptor(type, {
          invoke(p) {
            console.log(p);
            return true;
          },
          success(args) {},
          fail(err) {},
          complete(res) {},
        });
      });
    },
  },
  onShow: function () {
    // 隐藏内置的tabBar
    uni.hideTabBar({
      animation: false,
    });
    console.log("App Show");
  },
  onHide: function () {
    console.log("App Hide");
  },
};
</script>

<style>
/*每个页面公共css */
page {
  font-size: 13px;
}
</style>
