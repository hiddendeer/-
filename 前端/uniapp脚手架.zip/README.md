
# uni-app脚手架

本次脚手架采用vue-cli方式运行，无需使用HBuilder编译器。
``` js
> npm i
> npm run dev
```

### 使用技术栈
(1) 基于Vue3版本 <br />
(2) 默认组件库 FirstUI <br />
(3) 状态管理 pinia <br />
(4) 窗口自适应 postcss-px-to-viewport <br />
(5) vite模块打包，快如风 <br />

FirstUI<a target="_blank" href="https://www.firstui.cn">使用文档</a>需要从VIP账号的个人中心进入，账号密码请联系崔蕊。


### FirstUI相关链接

官网地址：[https://www.firstui.cn](https://www.firstui.cn)

文档地址：[https://doc.firstui.cn](https://doc.firstui.cn)

GitHub地址：[https://github.com/FirstUI/FirstUI](https://github.com/FirstUI/FirstUI)

