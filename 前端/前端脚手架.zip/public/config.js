
// 此文件非必要，在生产环境下此文件配置可覆盖运行配置，开发环境下不起效
// 详情见 src/config/index.js

const APP_CONFIG = {
	//标题
	//APP_NAME: "SCUI",

	//接口地址，如遇跨域需使用nginx代理
	//API_URL: "https://www.fastmock.site/mock/5039c4361c39a7e3252c5b55971f1bd3/api"
}
