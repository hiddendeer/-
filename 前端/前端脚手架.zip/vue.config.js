const { defineConfig } = require('@vue/cli-service')

module.exports = defineConfig({
  //设置为空打包后不分更目录还是多级目录
  publicPath: '',
  //build编译后存放静态文件的目录
  //assetsDir: "static",

  // build编译后不生成资源MAP文件
  productionSourceMap: false,

  //开发服务,build后的生产模式还需nginx代理
  devServer: {
    open: false, //运行后自动打开浏览器
    port: process.env.VUE_APP_PORT, //挂载端口
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
    proxy: {
      '/api': {
        // ws: false, // 这里把ws代理关闭
        target: process.env.VUE_APP_SAFE_URL,
        changeOrigin: true,
        pathRewrite: {
          '^/api': '/api',
        },
      },
      '/baseApi': {
        // ws: false, // 这里把ws代理关闭
        target: process.env.VUE_APP_SAFE_URL,
        changeOrigin: true,
        pathRewrite: {
          '^/baseApi': '/tvrjet-government-baseline-app',
        },
      },
      '/custApi': {
        // ws: false, // 这里把ws代理关闭
        target: process.env.VUE_APP_SAFE_URL,
        changeOrigin: true,
        pathRewrite: {
          '^/custApi': '/tvrjet-government-tog-cust-app',
        },
      },
      '/baseServer': {
        // ws: false, // 这里把ws代理关闭
        target: process.env.VUE_APP_OPERATION_URL,
        changeOrigin: true,
        pathRewrite: {
          '^/baseServer': '/tvrjet-thirdParty',
        },
      },
      '/': {
        ws: false, // 这里把ws代理关闭
        target: process.env.VUE_APP_SAFE_URL,
        changeOrigin: true,
        pathRewrite: {
          '^/': '',
        },
      },
    },
  },
  lintOnSave: false,
  chainWebpack: (config) => {
    // 移除 prefetch 插件
    config.plugins.delete('preload')
    config.plugins.delete('prefetch')
    config.resolve.alias.set('vue-i18n', 'vue-i18n/dist/vue-i18n.cjs.js')
    config.resolve.extensions.add('ts').add('js').add('tsx')
    // 微前端警告处理
    config.module
      .rule('vue')
      .use('vue-loader')
      .tap((options) => {
        options.compilerOptions = {
          ...(options.compilerOptions || {}),
          isCustomElement: (tag) => /^micro-app/.test(tag),
        }
        return options
      })
  },

  configureWebpack: {
    //性能提示
    performance: {
      hints: false,
    },
    optimization: {
      splitChunks: {
        chunks: 'all',
        // chunksSortMode: 'manual',
        automaticNameDelimiter: '~',
        name: 'scuiChunks',
        cacheGroups: {
          //第三方库抽离
          vendor: {
            name: 'modules',
            test: /[\\/]node_modules[\\/]/,
            priority: -10,
          },
          elicons: {
            name: 'elicons',
            test: /[\\/]node_modules[\\/]@element-plus[\\/]icons-vue[\\/]/,
          },
          tinymce: {
            name: 'tinymce',
            test: /[\\/]node_modules[\\/]tinymce[\\/]/,
          },
          echarts: {
            name: 'echarts',
            test: /[\\/]node_modules[\\/]echarts[\\/]/,
          },
          xgplayer: {
            name: 'xgplayer',
            test: /[\\/]node_modules[\\/]xgplayer.*[\\/]/,
          },
          codemirror: {
            name: 'codemirror',
            test: /[\\/]node_modules[\\/]codemirror[\\/]/,
          },
        },
      },
    },
  },
})
