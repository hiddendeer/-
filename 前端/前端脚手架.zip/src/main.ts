import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import 'element-plus/theme-chalk/display.css'
import './assets/css/tailwindcss.css'
import vrui from './vrui.js'
import i18n from '@/locales/index.js'
import router from '@/router/index.js'
import store from '@/store/index.js'
import { createApp } from 'vue'
import App from './App.vue'
import microApp from '@micro-zoe/micro-app'
microApp.start()


const app = createApp(App);

app.use(store);
app.use(router);
app.use(ElementPlus);
app.use(i18n);
app.use(vrui);

//挂载app
app.mount('#app');
