import axios from 'axios'
import { ElMessage } from 'element-plus'
import router from '@/router/index.js'
const service = axios.create({
  baseURL: '',
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 30000, // request timeout
})

const username = JSON.parse(localStorage.getItem('loginUser'))?.simpleUserInfo?.realName || ''

service.interceptors.request.use(
  (config) => {
    // 政府端基线版header参数
    // config.headers.ProjectId = '5ce59c15d348ca1cc61ed6cd5d096aaf'
    // config.headers.SystemId = '7a269438e5b65e13742eda6447e53931'
    config.headers.AppSecretKey = '052Y2450xW0v30m60h6Q7616kB931U80'
    // // base64用户名
    // if (username) {
    //   config.headers.UserName = tool.crypto.BASE64.encrypt(username)
    // }
    // do something before request is sent
    if (localStorage.getItem('TOKEN')) {
      config.headers.Authorization = localStorage.getItem('TOKEN')
    }
    return config
  },
  (error) => {
    // do something with request error
    console.log(error) // for debug
    return Promise.reject(error)
  }
)

service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
   */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  (response) => {
    const res = response.data
    // if the custom code is not 20000, it is judged as an error.
    return res
  },
  (error) => {
    // token过期处理
    if (error?.response?.data?.code == 'B0301') {
      ElMessage({
        type: 'warning',
        message: `登录令牌过期,请重新登录`,
      })
      localStorage.clear()
      if (window.__MICRO_APP_ENVIRONMENT__) {
        window.microApp.dispatch({ type: 'tokenExceed' })
        window.microApp.clearData()
      }
      router.push('/login')
    } else {
      ElMessage({
        type: 'error',
        message: `${error?.response?.data?.message || '发生未知错误'}`,
      })
    }
  }
)

export default service
