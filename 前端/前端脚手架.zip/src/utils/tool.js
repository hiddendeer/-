/**
 * 工具集
 */

import CryptoJS from 'crypto-js'

const tool = {}


tool.cryoto = {
    AES_Encrypt: (plaintext, KEY="IfcTza8Bm9bU6dZt") => {
        const KEY = CryptoJS.enc.Utf8.parse(KEY);
        let ciphertext = CryptoJS.AES.encrypt(plaintext, KEY, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        }).toString()
        return ciphertext

    },
    AES_Decrypt: (jsonStr, KEY="IfcTza8Bm9bU6dZt") => {
        const KEY = CryptoJS.enc.Utf8.parse(KEY)
        let plaintext = CryptoJS.AES.decrypt(jsonStr, KEY, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        }).toString(CryptoJS.enc.Utf8)
        return plaintext
    }
}

/**
 * 当前URL的参数的对象
 * @param {*} url 当前url
 * @return {} 返回url上的参数
 */
tool.getURLParameters = (url) => {
        (url.match(/([^?=&]+)(=([^&]*))/g) || []).reduce(
            (a, v) => (
                (a[v.slice(0, v.indexOf('='))] = v.slice(v.indexOf('=') + 1)), a
            ),
            {}
        );
    }


/**
 * 合并对象
 * @param {*} objs 多个对象
 * @return {} 返回合并完的对象
 */
const objMerge = (...objs) =>
        [...objs].reduce(
            (acc, obj) =>
                Object.keys(obj).reduce((a, k) => {
                    acc[k] = acc.hasOwnProperty(k)
                        ? [].concat(acc[k]).concat(obj[k])
                        : obj[k];
                    return acc;
                }, {}),
            {}
        );

    /* 复制对象 */
    tool.objCopy = (obj) => {
        return JSON.parse(JSON.stringify(obj));
    }

// 复制文本
tool.copyToClipboard = str => {
        if (navigator && navigator.clipboard && navigator.clipboard.writeText)
            return navigator.clipboard.writeText(str);
        return Promise.reject('The Clipboard API is not available.');
    };

    /**
     * 随机十六进制颜色
     * @returns 
     */
    tool.randomHexColorCode = () => {
        let n = (Math.random() * 0xfffff * 1000000).toString(16);
        return '#' + n.slice(0, 6);
    };

    /**
     * 深度克隆对象
     * @param {*} obj 需要克隆的对象
     * @return {}
     */
    const deepClone = obj => {
        if (obj === null) return null;
        let clone = Object.assign({}, obj);
        Object.keys(clone).forEach(
            key =>
            (clone[key] =
                typeof obj[key] === 'object' ? deepClone(obj[key]) : obj[key])
        );
        if (Array.isArray(obj)) {
            clone.length = obj.length;
            return Array.from(clone);
        }
        return clone;
    }; 2

/* 日期格式化 */
tool.dateFormat = (date, fmt = 'yyyy-MM-dd hh:mm:ss') => {
            date = new Date(date)
            var o = {
                "M+": date.getMonth() + 1,                 //月份
                "d+": date.getDate(),                    //日
                "h+": date.getHours(),                   //小时
                "m+": date.getMinutes(),                 //分
                "s+": date.getSeconds(),                 //秒
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度
                "S": date.getMilliseconds()             //毫秒
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        }

export default tool

