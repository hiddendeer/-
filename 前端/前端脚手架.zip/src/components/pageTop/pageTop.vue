<template>
    <div class="options_area">
        <span class="title">
            <el-icon v-if="route.meta.icon != '' && route.meta.icon != 'default'">
                <component :is="route.meta.icon"></component>
            </el-icon>
            {{ route.meta.title }}
        </span>
        <slot name="actions"></slot>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from "vue-router"
const route = useRoute()
</script>
<style lang='scss' scoped>
@media (max-width: 2400px) {
    .options_area {
        margin-bottom: 24px;
    }
}
@media (max-width: 1440px) {
    .options_area {
        margin-bottom: 16px;
    }
}

.options_area {
    height: 38px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    span.title {
        height: 38px;
        line-height: 38px;
        display: flex;
        align-items: center;

        &>i {
            margin-right: 8px;
        }
    }
}
</style>