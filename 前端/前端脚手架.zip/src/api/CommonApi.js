import request from "@/utils/network.js";
export default class CommonApi {
	static login(data) {
		return request({
			url: '/api/loginApi',
			method: 'post',
			data: data
		})
	}
	static getMenu(params) {
		return request({
			url: '/api/sysMenu/getLeftMenusAntdv',
			method: 'get',
			params
		})
	}
}
