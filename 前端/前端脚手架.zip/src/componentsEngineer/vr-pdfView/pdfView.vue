<template>
  <div id="pdfvuer">
    <pdf
      :src="pdfdata"
      v-for="i in numPages"
      :key="i"
      :id="i"
      :page="i"
      style="width: 100%"
    >
      <template slot="loading"> loading content here... </template>
    </pdf>
  </div>
</template>
  
<script>
import pdfvuer from "pdfvuer";
import "pdfjs-dist/build/pdf.worker.entry"; // not needed since v1.9.1

export default {
  components: {
    pdf: pdfvuer,
  },
  props: {
    url: {
      type: String,
    },
  },
  data() {
    return {
      page: 1,
      numPages: 0,
      pdfdata: undefined,
      errors: [],
      scale: "page-width",
    };
  },
  computed: {
    formattedZoom() {
      return Number.parseInt(this.scale * 100);
    },
  },
  watch: {
    // url(oldUrl, newValue) {
    //     if (newValue) {
    //         this.getPdf()
    //     }
    // }
  },
  mounted() {
    this.getPdf();
  },
  methods: {
    getPdf() {
      let self = this;
      let url = this.url;
      self.pdfdata = pdfvuer.createLoadingTask(url);
      self.pdfdata.then((pdf) => {
        self.numPages = pdf.numPages;
      });
    },
  },
};
</script>
<style src="pdfvuer/dist/pdfvuer.css">
</style>
<style lang="css" scoped>
.content {
  padding: 16px;
}
</style>
  