<template>
  <div class="w-full">
    <el-cascader ref="cascaderRef" :disabled="props.disabled" class="w-full" v-model="cascaderModel"
      @change="superviseChange" :options="superviseList" :props="props.propsSupervise" collapse-tags
      collapse-tags-tooltip />
  </div>
</template>

<script setup>
import { ElMessage } from "element-plus";
import CommonApi from "@/api/CommonApi.js";
import { nextTick, onMounted, ref, watch } from "vue";

const props = defineProps({
  dataObj: {
    type: Array,
    default: () => []
  },
  disabled: {
    type: Boolean,
    default: false
  },
  propsSupervise: {
    type: Object,
    default: {
      label: "tagName",
      value: "id",
      multiple: false,
      checkStrictly: false,
    }
  },
  checkType: {
    type: String,
    default: '',
  },
  type: {
    type: Number,
    default: 1
  }
})

const emits = defineEmits(["change"]);

// ref 对象
const cascaderRef = ref(null);

// 组件级参数
const cascaderModel = ref([]);

// 数组列表
const superviseList = ref([]);



onMounted(() => {
  getSuperviseList();
});

// 获取列表
const getSuperviseList = async () => {
  // type =1 重点监管领域
  // type =2 组织人员
  // type =3 网格区域
  // type =4 检查分类 = (安全智库类目项)
  if (props.type == 1) {
    //重点监管领域
    const res = await CommonApi.getAdminSupervisionList();
    if (res?.code && res.code == "00000") {
      superviseList.value = res?.data;
    }
  } else if (props.type == 2) {
    //组织人员
    let res = await CommonApi.getTree();
    if (res.code == '00000' && res.data) {
      superviseList.value = res?.data;
    }
  } else if (props.type == 3) {
    // 所属网格
    const res = await CommonApi.getAllTree();
    if (res.code == '00000' && res.data) {
      superviseList.value = res?.data;
    }
  } else if (props.type == 4) {
    const res = await CommonApi.getCheckClassify();
    if (res.code == '00000' && res.data) {
      superviseList.value = res?.data;
    }
  }
};

// change事件
const superviseChange = (e) => {
  console.log(e);
  if (props.propsSupervise.multiple) {
    // 处理数据
    cascaderModel.value = [];
    e.forEach((item) => {
      if (item.length > 0) {
        const lastId = item.slice(-1);
        cascaderModel.value.push(lastId[0]);
      }
    });
    const handleList = _calcListObj();
    emits("change", handleList);
  } else {
    if (props.checkType === 'Obj') {
      cascaderModel.value = e[e.length - 1];
      const handleList = copySuper(superviseList.value, []);
      emits("change", handleList);
    } else {
      cascaderModel.value = e;
      emits("change", e[e.length - 1]);
    }
  }

};

// 递归区域取最后一层级
const copySuper = (list, arr) => {
  for (const item of list) {
    if (item.id == cascaderModel.value) {
      arr.push(item);
    } else {
      copySuper(item?.children, arr)
    }
  }
  return arr;
};


// 全选 e => bool
const triggerSuperviseAll = (e) => {
  cascaderModel.value = [];
  if (e && superviseList.value.length > 0) {
    _calcSupervise(superviseList.value);
    nextTick(() => {
      const handleList = _calcListObj();
      emits("change", handleList);
    });
  }
};

// 递归区域取最后一层级
const _calcSupervise = (param) => {
  for (const item of param) {
    if (Object.keys(item.children).length > 0) {
      _calcSupervise(item.children);
    } else {
      cascaderModel.value.push(item.id);
    }
  }
};

// 处理数据
const _calcListObj = () => {
  let handleList = [];
  // 数量要匹配上
  if (cascaderModel.value.length != cascaderRef.value.allPresentTags.length) {
    ElMessage.error("组件出现问题！无法获得数据");
    return handleList;
  }

  const allPresentTags = cascaderRef.value.allPresentTags;

  cascaderModel.value.forEach((item, index) => {
    handleList.push({
      supervisionAreasId: item,
      supervisionAreasName: allPresentTags[index].text.trim(),
    });
  });

  return handleList;
};

// 回显数据
watch(() => props.dataObj, (newVal) => {
  if (props.propsSupervise.multiple && newVal) {
    const mapRes = newVal.map(item => {
      if (item.supervisionAreasId) {
        return item.supervisionAreasId;
      } else {
        return item;
      }
    });
    cascaderModel.value = mapRes;
  } else {
    cascaderModel.value = newVal;
  }
}, {
  immediate: true,
  deep: true
})
// 重置
const reset = () => {
  if (props.propsSupervise.multiple) {
    cascaderModel.value = [];
  } else {
    cascaderModel.value = '';
  }

}
defineExpose({
  triggerSuperviseAll,
  reset
});
</script>

<style lang="scss" scoped>

</style>