import { vali } from "./validateFunc.js"; // 自定义校验方法

export default {
    buttonConfig: [
        {
            type: 'default',
            label: '取消',
        },
        {
            type: 'primary',
            label: '提交',
            hasEmit: true,
            status: 'submit'
        },
    ],
    fieldParams: [
        {
            type: "input",
            label: "名称",
            model: "name1",
            rule: [{ required: true, message: '必填' }],
            span: 10,
        },
        {
            type: "rate",
            label: "评分",
            model: "name2",

        },
        {
            type: "solt",
            label: "插槽",
            model: "soltName",
            rule: [{ validator: vali, trigger: 'blur' }],
        },
        {
            type: "solt",
            label: "插槽",
            model: "soltName1",
            rule: { required: true },
        },
        {
            type: "switch",
            label: "名称",
            model: "name5",
            rule: [{ required: true, message: '必填', trigger: 'blur' }],
        },
        {
            type: "password",
            label: "密码",
            model: "name4",
            rule: { required: true, message: '必填', trigger: 'blur' },
        },
        {
            type: "textarea",
            label: "文本",
            model: "name6",
            config: {
                row: 3
            },
            rule: { required: true, message: '必填', trigger: 'blur' },
        },
        {
            type: "date-picker",
            label: "日期",
            model: "name7",
            rule: { required: true, message: '必填', trigger: 'change' },
        },
        {
            type: "date-picker",
            label: "范围日期",
            model: "name9",
            config: {
                type: 'daterange'
            },
            rule: { required: true, message: '必填', trigger: 'change' },
        },
        {
            type: "select",
            label: "选择",
            model: "select",
            rule: { required: true, message: '必填', trigger: 'change' },
            options: [
                {
                    value: "Option1",
                    label: "Option1",
                },
            ],
        },
        {
            type: "upload-image",
            label: "图片",
            model: "image",
            config: {
                limit: 3,
            }
        },
        {
            type: "upload-video",
            label: "视频",
            model: "video",
            config: {
                limit: 3,
            }
        },
    ]



}