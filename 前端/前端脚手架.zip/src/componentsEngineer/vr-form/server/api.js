import request from "@/utils/network.js";

export default class CommonApi {
	//图片上传
	static uploadImage(data) {
		return request({
			url: "/tvrjet-operation-smart-risk-app/obs/imgTemplate/upload",
			method: "post",
			data,
		});
	}

    //视频上传
	static uploadFileVideo(data) {
		return request({
			url: "/tvrjet-operation-smart-risk-app/obs/videoTemplate/upload",
			method: "post",
			data,
		});
	}

}