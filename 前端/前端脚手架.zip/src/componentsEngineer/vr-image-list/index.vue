<template>
  <div>
    <el-dialog
      v-model="formVisible"
      v-if="formVisible"
      :title="props.dialogTitle"
      :width="props.dialogWidth"
      :top="props.dialogTop"
      @close="close"
      :close-on-click-modal="false"
    >
      <div class="min-h-[500px]">
        <div class="flex flex-wrap justify-around">
          <div
            class="flex flex-col ml-[10px] lastChild"
            v-for="item in imageList"
          >
            <img class="w-[200px] h-[200px]" :src="item.fileUrl" />
            <div class="flex justify-center">
              <el-checkbox
                v-model="item.checked"
                label="选择"
                size="large"
                @change="(e) => changeCheck(e, item)"
              />
            </div>
          </div>
        </div>
      </div>
      <template #footer>
        <div class="pr-[20px]">
          <el-button type="primary" @click="submit">确认</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ElMessage } from "element-plus";
import { ref } from "vue";

const emits = defineEmits(['imgInfo']);

const props = defineProps({
  dialogTitle: {
    type: String,
    default: "标题",
  },
  dialogWidth: {
    type: String,
    default: "60%",
  },
  dialogTop: {
    type: String,
    default: "10vh",
  },
});

const formVisible = ref(false);

const imageList = ref([]);
const currentObj = ref({});

// 改变
const changeCheck = (e, row) => {
  if (e) {
    currentObj.value = row;
    imageList.value.forEach((item) => {
      if (row.id == item.id) {
        item.checked = true;
      } else {
        item.checked = false;
      }
    });
  } else {
    currentObj.value = {};
  }
};

const close = () => {
  formVisible.value = false;
};

const fileImage = (fileList) => {
  imageList.value = fileList;
};

const submit = () => {
  if (Object.keys(currentObj.value).length == "0") {
    ElMessage.error("请选择隐患图片");
    return;
  }
  emits('imgInfo', currentObj.value)
  formVisible.value = false;
};

defineExpose({
  formVisible,
  fileImage,
});
</script>

<style lang="scss" scoped>
.lastChild:nth-last-child(1) {
  margin-right: auto;
}
</style>