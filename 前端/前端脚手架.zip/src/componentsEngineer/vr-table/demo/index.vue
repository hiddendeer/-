<template>


    <VRTable :loading="loading" :tableData="dataObj.tableData" :clomun="dataObj.clomun" @pageSizeChange="pageSizeChange"
        :pages="dataObj.pages">
        <template #criNumber="{ row }">
            <div class="complianceNum" @click="complianceNum(row)">
                {{ row.criNumber || 0 }}
            </div>
        </template>
        <template #sysTagList="{ row }">
            <div class="complianceNums">
                {{
                        RegionFormatter(
                            row.sysTagList,
                            "tagName",
                            ","
                        )
                }}
            </div>
        </template>
        <template #personTagList="scope">
            <span class="complianceNum">
                {{
                        RegionFormatter(
                            scope.row.personTagList,
                            "tagName",
                            ","
                        )
                }}
            </span>
            <el-button v-if="scope.row.personTagList.length === 0" class="tagbtn" text type="primary"
                @click="addCusLab(scope.row.id)">添加
            </el-button>
            <el-button v-else class="tagbtn" text type="primary">
                查看
            </el-button>
        </template>
        <template #status="{ row }">
            <span :class="tagStatus[row.status]" class="status_tag">{{
                    statusList[row.status]
            }}</span>
        </template>
        <template #action="{ row }">
            <el-button size="small" text type="primary" @click="preview(row.lawFileInfo)">
                预览
            </el-button>
            <el-button v-if="
                row.status == '0' ||
                row.status == '1'
            " size="small" text type="primary">
                添加业务标签
            </el-button>
            <el-button v-if="row.status == '0'" size="small" text type="primary">
                发布
            </el-button>
            <el-button v-if="
                row.status == '0' ||
                row.status == '1'
            " size="small" text type="primary" @click="setEdit(row)">
                编辑
            </el-button>
            <el-button v-if="row.status == '1'" size="small" text type="primary">
                作废
            </el-button>
            <el-button v-if="row.status == '0'" size="small" text type="danger">
                删除
            </el-button>
        </template>
    </VRTable>

</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import api from "@/views/base/plan/server/api";
import commonApi from "@/api/CommonApi.js";
import VRTable from "@/componentsEngineer/vr-table/index";


// 表格数据
const dataObj = reactive({
    tableData: [],
    clomun: [
        {
            type: 'selection',
            minWidth: '65',
            handleSelectAble: function (row) {
                return row.status == 1
            }
        },
        {
            type: 'index',
            label: '序号',
            minWidth: '65',
        },
        {
            props: 'lawName',
            label: '法律名称',
            minWidth: '200',
            // formatter: function () { },
            // slot: '',
        },
        {
            props: 'lawName',
            label: '法律名称',
            minWidth: '200',
            // formatter: function () { },
            // slot: '',
        },
        {
            props: 'executeLevel',
            label: '执行等级',
            minWidth: '100',
            formatter: function (row) {
                if (row) {
                    return regionFormatterLevel(row.executeLevel)
                }
            }
        }, {
            props: 'industryList',
            label: '适用行业',
            minWidth: '100',
            formatter: function (row) {
                if (row) {
                    return RegionFormatter(row.industryList,
                        "remark",
                        "、")
                }
            }

            // slot: '',
        }, {
            props: 'price',
            label: '适用地区',
            minWidth: '200',
            formatter: function (row) {
                if (row) {
                    return RegionFormatter(row.areaList,
                        "remark",
                        "、")
                }
            }
        }, {
            props: 'criNumber',
            label: '合规要求数量',
            minWidth: '100',
            slot: true
        },
        {
            props: 'sysTagList',
            label: '业务标签',
            minWidth: '100',
            slot: true
        },
        {
            props: 'personTagList',
            label: '自定义标签',
            minWidth: '100',
            slot: true
        },
        {
            props: 'status',
            label: '状态',
            minWidth: '100',
            slot: true,
        },
        {
            props: 'action',
            label: '操作',
            minWidth: '350',
            slot: true,
            fixed: 'right'
        },
    ],
    total: 0,
    pages: {
        totalNumber: 0,
        currentPage: 1,
        pagesize: 10,
        pageSizes: [10, 20, 30, 50],
    }
});

//页码
const pageSizeChange = (val) => {
    dataObj.pages = val;
    onSearch()
}
//执行等级
const performLevelList = ref([]);
//表格加载
const loading = ref(false);

//适用地区
const applyArea = ref([]);
//适用行业
const industryData = ref([]);
//状态
const statusList = ["暂存", "已发布", "已作废"];
//标签状态类
const tagStatus = ["temstorage", "published", "canceled"];
//搜索
const onSearch = async () => {
    loading.value = true;
    await api.getSearchList({
        pageSize: dataObj.pages.pagesize, //每条页数
        pageNo: dataObj.pages.currentPage, //页码
    }).then((res) => {
        loading.value = false;
        dataObj.tableData = res.data.records;
        dataObj.pages.totalNumber = Number(res.data.total);
    });
};
// 执行等级装换
const regionFormatterLevel = (val) => {
    if (!val) return
    let JsonValue = JSON.parse(JSON.stringify(val));
    let strName = '';
    performLevelList.value.map(it => {
        if (val && it.dictCode == JsonValue) {
            strName = it.dictName
        }
    })
    return strName;

}
//所属行业转换
const RegionFormatter = (renderList, target, point) => {
    if (!renderList) {
        return;
    }
    let JsonValue = JSON.parse(JSON.stringify(renderList));
    let areaName = "";
    JsonValue.forEach((item) => {
        if (areaName == "") {
            areaName = item[target];
        } else {
            areaName = areaName + point + item[target];
        }
    });
    return areaName;
};






//获取行政区域树
const getTreeAreaList = async () => {
    await commonApi.getTreeAreaCountry()
        .then((res) => {
            applyArea.value = res.data;
        })
        .catch(() => {
            applyArea.value = [];
        });

    await api.getIndustryList().then((res) => {
        industryData.value = res.data.filter((ele) => {
            return ele.dictTypeCode == "apply_industry";
        });
        performLevelList.value = res.data.filter((ele) => {
            return ele.dictTypeCode == "perform_level";
        });
    });

};
onMounted(() => {
    //获取适用地区、行业
    getTreeAreaList();
    //获取法律管理列表
    onSearch();
});
</script>
