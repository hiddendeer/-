<template>
    <div class="h-full">
        <div class="tableclass">
            <el-table ref="selectionTable" :data="dataObj.tableData" v-loading="dataObj.loading"
                :style="{ height: `${dataObj.height}` }" :row-key="dataObj.rowKey"
                @selection-change="handleSelectionChange">
                <el-table-column v-for="(item, index) in dataObj.clomun" :show-overflow-tooltip="item.tooltip"
                    :prop="item.props" :key="index" :fixed="item.fixed" :label="item.label" :type="item.type"
                    :min-width="item.minWidth" align="center" :sortable="item.sortable" :selectable="item.handleSelectAble"
                    :reserve-selection="true">
                    <template v-if="item.formatter" #default="scope">
                        <div v-html="item.formatter(scope.row)"></div>
                    </template>
                    <template v-if="item.slot" #default="scope">
                        <slot :name="item.props" :row="scope.row"></slot>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="tablepage">
            <el-pagination background :small="true" layout="->, total, sizes, prev, pager, next"
                :total="dataObj.pages.totalNumber" :page-sizes="dataObj.pages.pageSizes"
                v-model:current-page="dataObj.pages.currentPage" v-model:page-size="dataObj.pages.pagesize"
                @current-change="handleCurrentChange" @size-change="handleSizeChange">
            </el-pagination>
        </div>
    </div>
</template>

<script  setup>
import { ref, reactive, toRefs, watchEffect, onMounted, nextTick } from "vue";



const emits = defineEmits(['handleSelectionChange', 'pageSizeChange'])
const props = defineProps({
    loading: {
        type: Boolean,
        default: false,
    },
    rowKey: {
        type: String,
        default: 'id',
    },
    clomun: {
        type: Array || '',
        default: [],
    },
    tableData: {
        type: Array || '',
        default: [],
    },
    pages: {
        type: Object,
        default: () => ({
            totalNumber: 0,
            currentPage: 1,
            pagesize: 10,
            pageSizes: [10, 20, 30, 50],
        }),
    },
    search: {
        type: Object,
        default: {}
    },
    Api: {
        type: Function,
        default: () => { },
    },
    sizeType: {
        type: String,  // 'url'表示分页参数要拼接在url上
        default: ''
    },
    noClear: {
        type: Boolean,
        default: false
    },
    noInit: {
        type: Boolean,
        default: false
    },
    height: {
        type: String,
        default: '100%'
    }
});
// {
//                 props: '',
//                 label: '',
//                 minWidth: '',
//                 formatter: function () { },
//                 slot: '',
//             }
// const { loading, rowKey, clomun, tableData, pages, search, Api } = toRefs(props);
const dataObj = reactive({
    loading: props.loading,
    rowKey: props.rowKey,
    clomun: props.clomun,
    tableData: props.tableData,
    pages: props.pages,
    search: props.search,
    Api: props.Api,
    sizeType: props.sizeType,
    height: props.height
})
const selectionTable = ref(null);
onMounted(() => {
    if (props.tableData.length == 0 && !props.noInit) {
        refresh()
    }
})
const refresh = async () => {
    dataObj.loading = true;
    if (!props.noClear) selectionTable.value.clearSelection();
    let obj = {
        pageNo: dataObj.pages.currentPage,
        pageSize: dataObj.pages.pagesize,
    };
    let newObj = Object.assign(obj, dataObj.search)
    for (const item in newObj) {
        if (newObj[item] == '-1' || newObj[item] == '') {
            delete newObj[item]
        }
    }
    try {
        const res = dataObj.sizeType == 'url'
            ? await dataObj.Api(dataObj.pages.pagesize, dataObj.pages.currentPage, newObj)
            : await dataObj.Api(newObj)
        dataObj.tableData = res.data?.records || res?.data;
        dataObj.pages.totalNumber = Number(res.data?.total) || res.data.length;
        dataObj.loading = false;
    } catch (error) {
        dataObj.loading = false;
    }
}
//选中
const handleSelectionChange = (e) => {
    emits("handleSelectionChange", e)
}
const toggleRow = (val, status) => {
    selectionTable.value.toggleRowSelection(val, status)
};
//页码
const handleCurrentChange = (val) => {
    dataObj.pages.currentPage = val;
    if (props.tableData.length == 0) {
        refresh()
    }
    emits('pageSizeChange', dataObj.pages)
}
//页数
const handleSizeChange = (val) => {
    dataObj.pages.pagesize = val;
    if (props.tableData.length == 0) {
        refresh()
    }
    emits('pageSizeChange', dataObj.pages)

};
defineExpose({
    refresh,
    dataObj,
    toggleRow
})
</script>

<style scoped>
.tableclass {
    height: calc(100% - 60px);
}

.tablepage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-top: 20px;
    height: 40px;
    background-color: #fff;
}
</style>
