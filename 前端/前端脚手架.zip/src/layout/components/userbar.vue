<template>
  <div class="user-bar">
    <!-- <div class="screen panel-item hidden-sm-and-down" @click="screen">
			<el-icon><el-icon-full-screen /></el-icon>
		</div> -->
    <el-dropdown
      v-if="superAdmin"
      class="user panel-item !h-[50px]"
      trigger="click"
      @command="triggerApp"
    >
      <div class="user-avatar">
        <el-icon><el-icon-sort color="#fff" /></el-icon>
        <label>{{ currentSystemName }}</label>
        <el-icon class="el-icon--right"><el-icon-arrow-down /></el-icon>
      </div>
      <template #dropdown>
        <el-dropdown-menu>
          <template v-for="(item, index) in appList">
            <el-dropdown-item :divided="index != 0" :command="item.path">{{
              item.title
            }}</el-dropdown-item>
          </template>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
    <el-dropdown class="user panel-item !h-[50px]" trigger="click" @command="handleUser">
      <div class="user-avatar">
        <el-avatar :size="30">{{ userNameF }}</el-avatar>
        <label>{{ userName }}</label>
        <el-icon class="el-icon--right"><el-icon-arrow-down /></el-icon>
      </div>
      <template #dropdown>
        <el-dropdown-menu>
          <!-- <el-dropdown-item command="uc">帐号信息</el-dropdown-item> -->
          <el-dropdown-item command="clearCache">清除缓存</el-dropdown-item>
          <el-dropdown-item divided command="outLogin"
            >退出登录</el-dropdown-item
          >
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>

  <el-dialog
    v-model="searchVisible"
    :width="700"
    title="搜索"
    class="drawerBG"
    center
    destroy-on-close
  >
    <search @success="searchVisible = false"></search>
  </el-dialog>

  <el-drawer
    v-model="tasksVisible"
    :size="450"
    title="任务中心"
    class="drawerBG"
    destroy-on-close
  >
    <tasks></tasks>
  </el-drawer>
</template>

<script>
import search from "./search.vue";
import tasks from "./tasks.vue";

export default {
  components: {
    search,
    tasks,
  },
  data() {
    return {
      superAdmin: false, // 是否超级管理员
      userName: "",
      userNameF: "",
      searchVisible: false,
      tasksVisible: false,
      msg: false,
      currentSystemName:
        localStorage.getItem("currentSystemName") || "智慧安监系统",
      appList: [], // 应用列表
      msgList: [
        {
          id: 1,
          type: "user",
          avatar: "img/avatar.jpg",
          title: "Skuya",
          describe: "如果喜欢就点个星星支持一下哦",
          link: "https://gitee.com/lolicode/scui",
          time: "5分钟前",
        },
        {
          id: 2,
          type: "user",
          avatar: "img/avatar2.gif",
          title: "Lolowan",
          describe: "点进去Gitee获取最新开源版本",
          link: "https://gitee.com/lolicode/scui",
          time: "14分钟前",
        },
        {
          id: 3,
          type: "system",
          avatar: "img/logo.png",
          title: "感谢登录SCUI Admin",
          describe:
            "Vue 3.0 + Vue-Router 4.0 + ElementPlus + Axios 后台管理系统。",
          link: "https://gitee.com/lolicode/scui",
          time: "2020年7月24日",
        },
      ],
    };
  },
  created() {
    const userInfo = JSON.parse(localStorage.getItem("loginUser"));
    this.appList = JSON.parse(localStorage.getItem("menuConfig"));
    this.userName = userInfo?.simpleUserInfo?.realName || userInfo?.account;
    this.userNameF = this.userName.substring(0, 1);
    this.superAdmin = userInfo?.superAdmin;
  },
  methods: {
    // 切换应用刷新当前菜单
    triggerApp(e) {
      const findObj = this.appList.find((item) => item.path.indexOf(e) > -1);
      if (findObj) {
        // 当前应用名称
        localStorage.setItem("currentSystemName", findObj?.title);
        // 临时跳转变量
        sessionStorage.setItem("jumpRouteUrl", findObj?.path);
        // 重置菜单信息
        localStorage.setItem("MENU", JSON.stringify(findObj?.children));
      }
      // 刷新当前页
      this.$router.go(0);
    },
    //个人信息
    handleUser(command) {
      if (command == "uc") {
        this.$router.push({ path: "/usercenter" });
      }
      if (command == "cmd") {
        this.$router.push({ path: "/cmd" });
      }
      if (command == "clearCache") {
        this.$confirm(
          "清除缓存会将系统初始化，包括登录状态、主题、语言设置等，是否继续？",
          "提示",
          {
            type: "info",
          }
        )
          .then(() => {
            const loading = this.$loading();
            localStorage.clear();
            this.$router.replace({ path: "/login" });
            setTimeout(() => {
              loading.close();
              location.reload();
            }, 1000);
          })
          .catch(() => {
            //取消
          });
      }
      if (command == "outLogin") {
        this.$confirm("确认是否退出当前用户？", "提示", {
          type: "warning",
          confirmButtonText: "退出",
          // confirmButtonClass: "el-button--danger",
        })
          .then(() => {
            localStorage.clear();
            this.$router.replace({ path: "/login" });
          })
          .catch(() => {
            //取消退出
          });
      }
    },
    //全屏
    screen() {
      var element = document.documentElement;
      this.$TOOL.screen(element);
    },
    //显示短消息
    showMsg() {
      this.msg = true;
    },
    //标记已读
    markRead() {
      this.msgList = [];
    },
    //搜索
    search() {
      this.searchVisible = true;
    },
    //任务
    tasks() {
      this.tasksVisible = true;
    },
  },
};
</script>

<style scoped>
.user-bar {
  display: flex;
  align-items: center;
  height: 100%;
}
.user-bar .panel-item {
  padding: 0 10px;
  cursor: pointer;
  height: 100%;
  display: flex;
  align-items: center;
}
.user-bar .panel-item i {
  font-size: 16px;
}
.user-bar .panel-item:hover {
  background: rgba(0, 0, 0, 0.1);
}
.user-bar .user-avatar {
  height: 49px;
  display: flex;
  align-items: center;
}
.user-bar .user-avatar label {
  display: inline-block;
  margin-left: 5px;
  font-size: 12px;
  cursor: pointer;
}

.msg-list li {
  border-top: 1px solid #eee;
}
.msg-list li a {
  display: flex;
  padding: 20px;
}
.msg-list li a:hover {
  background: #ecf5ff;
}
.msg-list__icon {
  width: 40px;
  margin-right: 15px;
}
.msg-list__main {
  flex: 1;
}
.msg-list__main h2 {
  font-size: 15px;
  font-weight: normal;
  color: #333;
}
.msg-list__main p {
  font-size: 12px;
  color: #999;
  line-height: 1.8;
  margin-top: 5px;
}
.msg-list__time {
  width: 100px;
  text-align: right;
  color: #999;
}

.dark .msg-list__main h2 {
  color: #d0d0d0;
}
.dark .msg-list li {
  border-top: 1px solid #363636;
}
.dark .msg-list li a:hover {
  background: #383838;
}
</style>
