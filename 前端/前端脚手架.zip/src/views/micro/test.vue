<template>
  <micro-app style="height: 100%" :name="`my${queryName}/`" :url="`${currentUrl}/${queryName}/`" @datachange="handleDataChange">
  </micro-app>
</template>

<script setup>
import { ref, onMounted, onUnmounted, toRaw } from 'vue';
import { useRouter } from 'vue-router';
const $router = useRouter();
const queryName = ref("");
const currentLocation = ref("");
const currentUrl = ref(process.env.NODE_ENV == 'development' ? currentLocation : window.location.origin);
//  可以使用 default-page='#/danger' 跳转到子应用对应的页面   哈希路由必须添加#
//  也可以使用 microApp.router.push({name: 'my-app', path: '/danger'}) 跳转到子应用对应的页面   哈希路由必须添加#
//  也可以使用 microApp.router.push({name: 'my-app', path: 'http://localhost:2800/safe/#/danger'})
//  也可以使用  microApp.router.push({name: 'my-app', path: '/page1?id=9527'})
//  https://micro-zoe.com/docs/1.x/#/zh-cn/router
const handleDataChange = e => {
  // if (e?.detail?.data?.type == 'tokenExceed') {
  //   $router.push('/login');
  // }
};

onMounted(() => {
  let name = toRaw($router).currentRoute.value.path.split("/");
  queryName.value = name[name.length - 1];
  for( let key in process.env ) {
		if(key.indexOf(queryName.value.toUpperCase()) > -1) {
      currentLocation.value = process.env[key];
		}
	}
});

onUnmounted(() => {
  queryName.value = '';
});
</script>

<style lang="scss">

</style>