import request from "@/utils/network.js";
export default class CommonApi {
  // 用户管理获取组织树
  static getTree(params) {
    return request({
      url: `/api/hrOrganization/tree`,
      method: 'get',
      params
    })
  }
  // 重置密码
  static resetPwd(data) {
    return request({
      url: `/api/sysUser/resetPwd`,
      method: 'post',
      data
    })
  }
  // 变更用户状态
  static changeStatus(data) {
    return request({
      url: `/api/sysUser/changeStatus`,
      method: 'post',
      data
    })
  }
  // 批量删除
  static batchDelete(data) {
    return request({
      url: `/api/sysUser/batchDelete`,
      method: 'post',
      data
    })
  }
  // 删除用户
  static deleteUser(data) {
    return request({
      url: `/api/sysUser/delete`,
      method: 'post',
      data
    })
  }
  // 新增用户
  static addUser(data) {
    return request({
      url: `/api/sysUser/add`,
      method: 'post',
      data
    })
  }
  // 编辑用户
  static editUser(data) {
    return request({
      url: `/api/sysUser/edit`,
      method: 'post',
      data
    })
  }
  // 获取分配角色列表
  static getRoleList(params) {
    return request({
      url: `/api/sysRole/dropDown`,
      method: 'get',
      params
    })
  }
  // 查询用户已分配角色
  static getUserRoles(params) {
    return request({
      url: `/api/sysUser/getUserRoles`,
      method: 'get',
      params
    })
  }
  // 保存分配角色
  static grantRole(data) {
    return request({
      url: `/api/sysUser/grantRole`,
      method: 'post',
      data
    })
  }
  // 新增组织机构
  static addOrg(data) {
    return request({
      url: `/api/hrOrganization/add`,
      method: 'post',
      data
    })
  }
  // 删除组织机构
  static delOrg(data) {
    return request({
      url: `/api/hrOrganization/delete`,
      method: 'post',
      data
    })
  }
  // 获取组织详情
  static orgDetail(params) {
    return request({
      url: `/api/hrOrganization/detail`,
      method: 'get',
      params
    })
  }
  // 编辑组织机构
  static editOrg(data) {
    return request({
      url: `/api/hrOrganization/edit`,
      method: 'post',
      data
    })
  }
  // 获取职位列表
  static hrPositionList(params) {
    return request({
      url: `api/hrPosition/list`,
      method: 'get',
      params
    })
  }

   // 获取行政区树
  static sysAreaTree = (params) => {
    return request({
      url: `/api/sysArea/queryTree`,
      method: "GET",
      params,
    });
  };
  // 获取职位部门树
  static organizationTree = (params) => {
    return request({
      url: `/api/expHrOrganization/organizationTree`,
      method: "GET",
      params,
    });
  };
  // 获取内部部门树
  static insideOrganizationTree = (params) => {
    return request({
      url: `/api/expHrOrganization/querySelect`,
      method: "GET",
      params,
    });
  };
  // 获取用户列表
  static getUserList(params) {
    return request({
      url: `/api/expSysUser/pageList`,
      method: 'get',
      params
    })
  }
  // 新增用户
  static addExpSysUser(data) {
    return request({
      url: `/api/expSysUser/add`,
      method: 'post',
      data
    })
  }
   // 编辑用户
   static updateExpSysUser= (data) => {
    return request({
      url: `/api/expSysUser/update`,
      method: "put",
      data,
    });
  };
  // 获取详情
  static getExpSysUserDetail= (params) => {
    return request({
      url: `/api/expSysUser/queryDetail`,
      method: "get",
      params,
    });
  };
   // 新增部门
   static addDepartment= (data) => {
    return request({
      url: `/api/expHrOrganization/add`,
      method: "POST",
      data,
    });
  };
   // 编辑职位
   static updateDepartment= (data) => {
    return request({
      url: `/api/expHrOrganization/update`,
      method: "PUT",
      data,
    });
  };
  // 职位详情
  static detailDepartment = (params) => {
    return request({
      url: `/api/expHrOrganization/queryDetail`,
      method: "GET",
      params,
    });
  };
  // 职位下拉选
  static selectDepartment = (params) => {
    return request({
      url: `/api/hrPosition/queryPosistionSelect`,
      method: "GET",
      params,
    });
  };
  // 删除行政区树
  static deleteDepartment = (data) => {
    return request({
      url: `/api/expHrOrganization/delete`,
      method: "DELETE",
      data,
    });
  };
  // 项目字典查询通用接口
  static dictProject = (params,config) => {
    return request({
      url: `/baseServer/applicationVisionDict/queryDictForExternal`,
      method: 'GET',
      params,
      ...config
    })
  }
}
