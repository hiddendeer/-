<template>
	<el-container>
		<el-aside width="20%" v-loading="showLoadingLeft">
			<el-container>
				<el-main class="nopadding">
					<el-tree
						ref="groupRefLeft"
						class="menu"
						node-key="id"
						:data="groupDataLeft"
						highlight-current
						auto-expand-parent
						:props="defaultPropsLeft"
						:default-expand-all="true"
						:expand-on-click-node="false"
						@node-click="groupClickLeft"
					>
						<template #default="{ node, data }">
							<span class="custom-tree-node">
								<el-tooltip class="box-item" effect="dark" :content="data.label" placement="top">
                  					<span class="label">{{ data.label }}</span>
                				</el-tooltip>
							</span>
						</template>
					</el-tree>
				</el-main>
			</el-container>
		</el-aside>
		<el-aside width="21%" v-loading="showLoadingRight">
			<el-container>
				<el-header>
					<el-input
						placeholder="输入关键字进行过滤"
						v-model="groupFilterText"
						clearable
					></el-input>
				</el-header>
				<el-main class="nopadding">
					<el-tree
						ref="groupRefRight"
						class="menu"
						node-key="id"
						:data="groupDataRight"
						highlight-current
						auto-expand-parent
						:props="defaultPropsRight"
						:default-expand-all="true"
						:expand-on-click-node="false"
						:filter-node-method="groupFilterNode"
						@node-click="groupClickRight"
					>
						<template #default="{ node, data }">
							<span class="custom-tree-node">
								<el-tooltip class="box-item" effect="dark" :content="data.orgName" placement="top">
                  					<span class="label">{{ data.orgName }}</span>
                				</el-tooltip>
								<span class="do">
									<el-button
										icon="el-icon-edit"
										size="small"
										@click.stop="editOrg(data)"
									/>
									<el-button
										icon="el-icon-delete"
										type="danger"
										size="small"
										@click.stop="delOrg(node, data)"
									/>
								</span>
							</span>
						</template>
					</el-tree>
				</el-main>
				<el-footer style="height: 51px">
					<el-button
						type="primary"
						icon="el-icon-plus"
						:disabled="!regulatoryUnitId"
						style="width: 100%"
						@click="handleOrg"
						>新增部门</el-button
					>
				</el-footer>
			</el-container>
		</el-aside>
		<el-container>
			<el-header>
				<div class="left-panel">
					<el-button
						type="primary"
						icon="el-icon-plus"
						:disabled="!regulatoryUnitId"
						@click="addUserManagement"
						>新建</el-button
					>
					<el-button
						type="danger"
						plain
						icon="el-icon-delete"
						:disabled="selectionList.length == 0"
						@click="deleteUserList"
						>删除</el-button
					>
				</div>
				<div class="right-panel">
					<div class="right-panel-search">
						<el-form-item label="账号: " style="margin-bottom: 0px">
							<el-input
								v-model="accountNumber"
								placeholder="请输入账号"
								clearable
							></el-input>
						</el-form-item>
						<el-form-item label="姓名: " style="margin-bottom: 0px">
							<el-input
								v-model="userName"
								placeholder="请输入姓名"
								clearable
							></el-input>
						</el-form-item>
						<el-button type="primary" @click="handelSearch"
							>查询</el-button
						>
						<el-button @click="resetSearch">重置</el-button>
					</div>
				</div>
			</el-header>
			<el-main class="nopadding">
				<scTable
					ref="tableRef"
					:header-cell-style="{
						background: '#f5f7fa',
						color: '#606266',
					}"
					:data="dataTable"
					@selection-change="selectionChange"
					stripe
					hidePagination
					hideDo
				>
					<el-table-column
						type="selection"
						width="50"
					></el-table-column>
					<el-table-column
						label="序号"
						width="80"
						align="center"
						type="index"
					></el-table-column>
					<el-table-column
						label="账号"
						align="center"
						prop="account"
						width="150"
					></el-table-column>
					<el-table-column
						label="姓名"
						align="center"
						prop="realName"
						width="150"
					></el-table-column>
					<el-table-column
						label="部门"
						align="center"
						prop="orgName"
						width="200"
					></el-table-column>
					<el-table-column
						label="职务"
						align="center"
						prop="position"
						width="200"
					></el-table-column>
					<el-table-column
						label="手机"
						align="center"
						prop="phone"
						width="170"
					></el-table-column>
					<el-table-column
						label="状态"
						align="center"
						prop="statusFlag"
						width="170"
					>
						<template #default="scope">
							<el-switch
								v-model="scope.row.statusFlag"
								:active-value="1"
								:inactive-value="2"
								:checked="scope.row.statusFlag == 1"
								@change="
									(checked) =>
										changeStatus(checked, scope.row)
								"
							/>
						</template>
					</el-table-column>
					<el-table-column
						label="操作"
						fixed="right"
						align="center"
						width="260"
					>
						<template #default="scope">
							<el-button-group>
								<el-button
									text
									type="primary"
									size="small"
									@click="updateUserVal(scope.row)"
									>修改</el-button
								>
								<el-popconfirm
									title="确定删除吗？"
									@confirm="deleteUserVal(scope.row)"
								>
									<template #reference>
										<el-button
											text
											type="danger"
											size="small"
											>删除</el-button
										>
									</template>
								</el-popconfirm>
								<el-button
									text
									type="primary"
									size="small"
									@click="openUserRole(scope.row)"
									>分配角色</el-button
								>
								<el-button
									text
									type="primary"
									size="small"
									@click="resetPsw(scope.row)"
									>重置密码</el-button
								>
							</el-button-group>
						</template>
					</el-table-column>
				</scTable>
			</el-main>
			<el-footer class="bodyPage">
				<div class="leftButton"></div>
				<el-pagination
					@current-change="currentPageChange"
					@size-change="pageSizeChange"
					:page-size="pageSize"
					:current-page="pageNo"
					:small="true"
					:page-sizes="[10, 20, 50]"
					:total="total"
					layout="total, sizes, prev, pager, next, jumper"
				></el-pagination>
			</el-footer>
		</el-container>
	</el-container>
	<!-- 添加编辑部门弹窗 -->
	<el-dialog
		:title="orgTitle == 'add' ? '新增部门' : '编辑部门'"
		v-model="showOrgDialog"
		width="30%"
		:close-on-click-modal="false"
		@closed="close"
	>
		<el-form
			ref="ruleFormRef"
			:model="form"
			:rules="rules"
			label-width="120px"
			v-loading="loading"
		>
			<el-form-item label="上级部门：" prop="orgParentId" required>
				<el-cascader
					v-model="form.orgParentId"
					placeholder="请选择上级部门"
					:options="groupDataCenter"
					:props="defaultPropsRight"
					clearable
					style="width: 100%"
					@change="changeOrg"
				/>
			</el-form-item>
			<el-form-item label="部门名称：" prop="orgName" required>
				<el-input
					v-model="form.orgName"
					:formatter="(value) => value.replace(/^\s+|\s+$/g, '')"
					placeholder="请输入部门名称"
					maxlength="20"
					show-word-limit
				/>
			</el-form-item>
			<el-form-item
				label="监管行业："
				prop="orgRegulatoryIndustry"
				required
			>
				<el-select
					v-model="form.orgRegulatoryIndustry"
					placeholder="请选择监管行业"
					class="w-full"
				>
					<el-option
						v-for="i in industryList"
						:key="i.value"
						:label="i.label"
						:value="i.value"
					/>
				</el-select>
			</el-form-item>
			<el-form-item label="排序号：" prop="orgSort">
				<el-input-number
					placeholder="请输入排序号"
					style="text-align: left; width: 100%"
					v-model="form.orgSort"
					:min="1"
					:max="999"
					:step="1"
					step-strictly
					controls-position="right"
				/>
			</el-form-item>
			<el-form-item label="备注：" prop="orgRemark">
				<el-input v-model="form.orgRemark" placeholder="请输入备注" />
			</el-form-item>
		</el-form>
		<template #footer>
			<div class="dialog-footer">
				<el-button @click="close(ruleFormRef)">取消</el-button>
				<el-button type="primary" @click="submitForm(ruleFormRef)"
					>确认</el-button
				>
			</div>
		</template>
	</el-dialog>
	<!-- 新增、编辑用户弹窗 -->
	<el-dialog
		:title="userTitleType == 'add' ? '新建用户' : '修改用户'"
		v-model="showUserDialog"
		width="45%"
		:close-on-click-modal="false"
		@closed="userCloseDialog"
	>
		<el-form
			ref="ruleUserFormRef"
			:model="userForm"
			:rules="userRules"
			label-width="120px"
			v-loading="loading"
			class="userSty"
		>
			<div class="userLeft">
				<el-form-item label="账号：" prop="account" required>
					<el-input
						v-model="userForm.account"
						placeholder="请输入账号"
						:maxlength="20"
						show-word-limit
					/>
				</el-form-item>
				<el-form-item
					label="登录密码："
					prop="password"
					required
					v-if="userTitleType == 'add'"
				>
					<el-input
						v-model="userForm.password"
						placeholder="请输入登录密码"
						type="password"
						show-password
						:maxlength="10"
						show-word-limit
					/>
				</el-form-item>
				<el-form-item
					label="确认密码："
					prop="againPassword"
					required
					v-if="userTitleType == 'add'"
				>
					<el-input
						v-model="userForm.againPassword"
						placeholder="请输入确认密码"
						type="password"
						show-password
						:maxlength="10"
						show-word-limit
					/>
				</el-form-item>
				<el-form-item label="部门：" prop="orgId" required>
					<el-cascader
						v-model="userForm.orgId"
						placeholder="请选择上级部门"
						:options="departmentList"
						:props="defaultPropsRight"
						clearable
						style="width: 100%"
						@change="changeUserOrg"
					/>
				</el-form-item>
				<el-form-item label="职位：" prop="positionId">
					<el-select
						v-model="userForm.positionId"
						placeholder="请选择职位"
						class="w-full"
					>
						<el-option
							v-for="i in positionList"
							:key="i.value"
							:label="i.label"
							:value="i.value"
						/>
					</el-select>
				</el-form-item>
				<el-form-item label="手机号：" prop="phone">
					<el-input
						v-model="userForm.phone"
						placeholder="请输入手机号"
					/>
				</el-form-item>
				<el-form-item
					label="邮箱："
					prop="email"
					v-if="userTitleType == 'edit'"
				>
					<el-input
						v-model="userForm.email"
						placeholder="请输入邮箱"
					/>
				</el-form-item>
			</div>
			<div class="userRight">
				<el-form-item label="姓名：" prop="realName">
					<el-input
						v-model="userForm.realName"
						placeholder="请输入姓名"
						:maxlength="10"
						show-word-limit
					/>
				</el-form-item>
				<el-form-item label="昵称：" prop="nickName">
					<el-input
						v-model="userForm.nickName"
						placeholder="请输入昵称"
						:maxlength="10"
						show-word-limit
					/>
				</el-form-item>
				<el-form-item label="性别：" prop="sex">
					<el-select
						v-model="userForm.sex"
						placeholder="请选择性别"
						class="w-full"
					>
						<el-option
							v-for="i in sexType"
							:key="i.value"
							:label="i.label"
							:value="i.value"
						/>
					</el-select>
				</el-form-item>
				<el-form-item label="出生日期：" prop="birthday">
					<el-date-picker
						v-model="userForm.birthday"
						class="w-full"
						format="YYYY-MM-DD"
						value-format="YYYY-MM-DD"
						placeholder="请选择出生日期"
					/>
				</el-form-item>
				<el-form-item
					label="邮箱："
					prop="email"
					v-if="userTitleType == 'add'"
				>
					<el-input
						v-model="userForm.email"
						placeholder="请输入邮箱"
					/>
				</el-form-item>
			</div>
		</el-form>
		<template #footer>
			<div class="dialog-footer">
				<el-button @click="userCloseDialog(ruleUserFormRef)"
					>取消</el-button
				>
				<el-button
					type="primary"
					@click="submitUserForm(ruleUserFormRef)"
					>确认</el-button
				>
			</div>
		</template>
	</el-dialog>
	<!-- 分配角色弹窗 -->
	<userRole
		ref="roleRef"
		:showDialog="showUserRole"
		:userId="userValueId"
		@submit="grantRole"
		@close="closeRole"
	/>
</template>

<script setup>
import api from "./server/api.js";
import { ref, reactive, onMounted, watch, nextTick } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import userRole from "@/views/systemUser/userManagement/components/userRole";
import fieldConfig from "./config/fieldConfig.js";

//-----------------------------------------
// 初始化数据树过滤
let groupFilterText = ref("");
// 加载
let showLoadingLeft = ref(false);
let showLoadingRight = ref(false);
// 新增弹窗
let showOrgDialog = ref(false);
// 新增/编辑弹窗标题
let orgTitle = ref("");
// 树数据
let groupDataLeft = ref([]);
// 部门树数据
let groupDataRight = ref([]);
//内部部门
let groupDataCenter = ref([]);
// 部门表单ref
let ruleFormRef = ref(null);
//监管区域ID
let regulatoryUnitId = ref("");
//编辑部门ID
let editDepartmentId = ref("");
//行业列表
let industryList = ref([]);

// 新增/编辑 表单数据
const form = ref({
	orgName: "",
	orgParentId: "",
	orgRegulatoryIndustry: null,
	orgSort: null,
	orgRemark: "",
	orgRegulatoryUnit: "",
});
//正则
let rules = ref({
	orgParentId: [
		{
			required: true,
			message: "请选择上级部门",
			trigger: ["change"],
		},
	],
	orgName: [
		{
			required: true,
			message: "请输入部门名称",
			trigger: ["change"],
		},
		{
			max: 20,
			pattern: /^[\u4e00-\u9fa5a-zA-Z0-9]{1,20}$/,
			message: "请输入汉字、字母、数字",
		},
	],
	orgRegulatoryIndustry: [
		{
			required: true,
			message: "请选择监管行业",
			trigger: ["change"],
		},
	],
});
// 树ref
const groupRefLeft = ref(null);
const groupRefRight = ref(null);

//部门id
let orgId = ref("");
let positionId = ref("");
//账号
let accountNumber = ref("");
//姓名
let userName = ref("");

let pageNo = ref(1);
let pageSize = ref(10);
let total = ref(0);

//用户列表
const dataTable = ref([]);
const tableRef = ref(null);

//分配角色Ref
let roleRef = ref(null);
//批量删除用户列表
let selectionList = ref([]);
//分配角色弹窗
let showUserRole = ref(false);
//===============新建用户==============//
//用户form ref
let ruleUserFormRef = ref(null);
//新建用户标题
let userTitleType = ref("");
//新建用户显隐
let showUserDialog = ref(false);
//部门
let departmentList = ref([]);
//职位
let positionList = ref([]);
//用户ID
let userValueId = ref("");
//原始日期
let initialDate = ref("");

//新增/编辑用户数据
let userForm = ref({
	realName: "",
	nickName: "",
	account: "",
	password: "",
	againPassword: "",
	birthday: "",
	sex: "",
	email: "",
	tel: "",
	phone: "",
	positionId: "",
	orgId: "",
});
//正则
let userRules = ref({
	account: [
		{
			required: true,
			message: "请输入账号",
			trigger: ["change"],
		},
		{
			max: 20,
			pattern: /^[a-zA-Z0-9]{0,20}$/,
			message: "请输入英文、数字",
			trigger: "blur",
		},
	],
	//姓名
	realName: [
		{
			max: 10,
			min: 2,
			pattern: /^[\u4e00-\u9fa5a-zA-Z]{1,10}$/,
			message: "请输入汉字、字母",
		},
	],
	//昵称
	nickName: [
		{
			max: 10,
			min: 2,
			pattern: /^[\u4e00-\u9fa5a-zA-Z0-9]{1,10}$/,
			message: "请输入汉字、数字、字母",
		},
	],
	password: [
		{
			required: true,
			message: "请输入登录密码",
			trigger: ["change"],
		},
		{
			min: 6,
			max: 10,
			pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,10}$/,
			message: "密码长度在6-10个字符之间,字母加数字组合",
			trigger: "blur",
		},
	],
	againPassword: [
		{
			required: true,
			message: "请输入确认密码",
			trigger: ["change"],
		},
		{
			min: 6,
			max: 10,
			pattern: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,10}$/,
			message: "密码长度在6-10个字符之间,字母加数字组合",
			trigger: "blur",
		},
	],
	orgId: [
		{
			required: true,
			message: "请选择部门",
			trigger: ["change"],
		},
	],
	phone: [
		{
			pattern: /^1[3456789]\d{9}$/,
			message: "您输入的手机号格式有误",
			trigger: "blur",
		},
	],
	email: [
		{
			pattern:
				/^([a-zA-Z0-9]+[_|_|\-|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/,
			message: "您输入的邮箱格式有误",
			trigger: "blur",
		},
	],
});
//性别
const sexType = reactive([
	{
		label: "男",
		value: "M",
	},
	{
		label: "女",
		value: "F",
	},
]);

//===============新建用户==============//

watch(
	() => groupFilterText.value,
	(nVal) => {
		groupRefRight.value.filter(nVal);
	}
);

// 行政区树格式
const defaultPropsLeft = ref({
	label: "label",
	value: "value",
});
// 部门区树格式
const defaultPropsRight = ref({
	label: "orgName",
	value: "orgId",
	checkStrictly: true,
});
// 新增编辑弹窗loading
const loading = ref(false);

//过滤关键字
const groupFilterNode = (value, data) => {
	if (!value) return true;
	return data.orgName.indexOf(value) !== -1;
};
//树点击事件左侧
const groupClickLeft = (data) => {
	regulatoryUnitId.value = data.value;
	form.value.orgRegulatoryUnit = data.value;
	orgId.value = "";
	dataTable.value = [];
	getOrganizationTree(data.value);
};
//获取部门树
const getOrganizationTree = async (val) => {
	let saDetail = await api.organizationTree({ orgRegulatoryUnit: val });
	groupDataRight.value = saDetail.data;
};
//获取部门内部树
const insideOrganizationTree = async () => {
	let saDetail = await api.insideOrganizationTree({
		orgRegulatoryUnit: regulatoryUnitId.value,
	});
	groupDataCenter.value = saDetail.data;
};
//树点击事件右侧
const groupClickRight = (data) => {
	orgId.value = data.orgId;
	getUserListDate();
};
// 编辑部门
const editOrg = (data) => {
	orgTitle.value = "edit";
	editDepartmentId.value = data.orgId;
	getSysAreaDetail(data.orgId);
	showOrgDialog.value = true;
	insideOrganizationTree();
};
// 获取编辑详情
const getSysAreaDetail = async (id) => {
	let saDetail = await api.detailDepartment({ orgId: id });
	form.value = {
		orgName: saDetail?.data.orgName,
		orgParentId: saDetail?.data.orgParentId,
		orgRegulatoryUnit: saDetail?.data.orgRegulatoryUnit,
		orgRegulatoryIndustry: saDetail?.data.orgRegulatoryIndustry,
		orgSort: saDetail?.data.orgSort,
		orgRemark: saDetail?.data.orgRemark,
	};
};
// 删除部门
const delOrg = (node, data) => {
	ElMessageBox.confirm(`确定删除选中部门吗？`, "提示", {
		type: "warning",
	})
		.then(() => {
			let params = {
				orgId: data.orgId,
			};
			api.deleteDepartment(params).then((res) => {
				if (res.code == "00000") {
					ElMessage.success("删除成功");
					getOrganizationTree(regulatoryUnitId.value);
				} else {
					ElMessage.error(res.message);
				}
			});
		})
		.catch(() => {});
};
// 选择上级部门
const changeOrg = (val) => {
	if (val) form.value.orgParentId = val[val.length - 1];
};
// 关闭弹窗
const close = (formEl) => {
	if (!formEl) return;
	formEl.resetFields();
	showOrgDialog.value = false;
};
// 新增/编辑弹窗保存
const submitForm = (formEl) => {
	if (!formEl) return;
	formEl.validate((valid) => {
		if (valid) {
			if (orgTitle.value == "add") {
				api.addDepartment(form.value).then((res) => {
					if (res.code == "00000") {
						ElMessage.success("新增成功");
						showOrgDialog.value = false;
						getOrganizationTree(regulatoryUnitId.value);
						getUserListDate();
					} else {
						ElMessage.warning(res.message);
					}
				});
			} else {
				api.updateDepartment({
					...form.value,
					orgId: editDepartmentId.value,
				}).then((res) => {
					if (res.code == "00000") {
						ElMessage.success("编辑成功");
						showOrgDialog.value = false;
						getOrganizationTree(regulatoryUnitId.value);
						getUserListDate();
					} else {
						ElMessage.warning(res.message);
					}
				});
			}
		} else {
			console.log("error submit!");
			return false;
		}
	});
};
// 获取行政区数据
const getAreaTree = () => {
	api.sysAreaTree().then((res) => {
		if (res.code == "00000") {
			groupDataLeft.value = res.data;
		} else {
			console.log(res.message);
		}
	});
};
//获取部门数据
const getDepartmentList=()=>{
	api.organizationTree().then((res) => {
		if (res.code == "00000") {
			departmentList.value = res.data;
		} else {
			console.log(res.message);
		}
	});
}
// 添加部门
const handleOrg = () => {
	if (ruleFormRef.value) {
		ruleFormRef.value.resetFields();
	}
	showOrgDialog.value = true;
	orgTitle.value = "add";
	insideOrganizationTree();
};
//搜索
const handelSearch = () => {
	getUserListDate();
};
//重置
const resetSearch = () => {
	accountNumber.value = "";
	userName.value = "";
	getUserListDate();
};
//获取用户列表
const getUserListDate = () => {
	api.getUserList({
		orgId: orgId.value,
		account: accountNumber.value,
		realName: userName.value,
		pageNo: pageNo.value,
		pageSize: pageSize.value,
	}).then((res) => {
		if (res.code == "00000") {
			dataTable.value = res.data.rows;
			total.value = res.data.totalRows;
		} else {
			console.log(res.message);
		}
	});
};
//切换页数
const currentPageChange = (val) => {
	pageNo.value = Number(val.toString().split(".")[0]);
	getUserListDate();
};
//切换每页条数
const pageSizeChange = (val) => {
	pageSize.value = val;
	getUserListDate();
};
//===========================

watch(
	() => userTitleType.value,
	(newVal) => {
		newVal == "edit"
			? getDetailUser()
			: ruleUserFormRef.value?.resetFields();
	}
);
watch(
	() => userForm.value.orgId,
	(newVal) => {
		getPositionSelect(newVal);
	}
);
//获取职位下拉
const getPositionSelect = (val) => {
	api.selectDepartment({ orgId: val }).then((res) => {
		if (res.code == "00000") {
			positionList.value = res.data.data;
		} else {
			console.log("error submit!");
		}
	});
};

//添加
const addUserManagement = () => {
	positionList.value = [];
	userTitleType.value = "add";
	showUserDialog.value = true;
	getDepartmentList();
};
//编辑
const updateUserVal = (row) => {
	userTitleType.value = "edit";
	userValueId.value = row.userId;
	showUserDialog.value = true;
	getDepartmentList();
};

// 关闭新建用户
const userCloseDialog = () => {
	userTitleType.value = "";
	showUserDialog.value = false;
	ruleUserFormRef.value.resetFields();
};

//新建用户确认
const submitUserForm = async () => {
	ruleUserFormRef.value?.validate(async (valid, fields) => {
		if (valid) {
			let res;
			if (userTitleType.value == "edit") {
				ruleUserFormRef.value.clearValidate("password");
				ruleUserFormRef.value.clearValidate("againPassword");
				let obj = JSON.parse(JSON.stringify(userForm.value));
				obj.userId = userValueId.value;
				if (obj.birthday !== initialDate.value) {
					obj.birthday = obj.birthday + " 00:00:00";
				}
				res = await api.updateExpSysUser(obj);
			} else {
				if (userForm.value.password !== userForm.value.againPassword) {
					return ElMessage.error(
						"确认密码与登录密码输入不一致，请检查！"
					);
				} else {
					if (userForm.value.birthday !== "") {
						userForm.value.birthday =
							userForm.value.birthday + " 00:00:00";
					} else {
						userForm.value.birthday = "";
					}
					res = await api.addExpSysUser(userForm.value);
				}
			}
			if (res.success) {
				ElMessage.success("操作成功!");
				showUserDialog.value = false;
				orgId.value = userForm.value.orgId;
				ruleUserFormRef.value.resetFields();
				getUserListDate();
			} else {
				ElMessage.error(res.message);
			}
		} else {
			console.log("error submit!", fields);
		}
	});
};
//获取详情
const getDetailUser = () => {
	if (userTitleType.value == "edit") {
		api.getExpSysUserDetail({ userId: userValueId.value }).then((res) => {
			if (res.code == "00000") {
				userForm.value.orgId = res.data.orgId;
				userForm.value.realName = res.data.realName;
				userForm.value.nickName = res.data.nickName;
				userForm.value.account = res.data.account;
				userForm.value.birthday = res.data.birthday;
				userForm.value.sex = res.data.sex;
				userForm.value.email = res.data.email;
				userForm.value.phone = res.data.phone;
				userForm.value.positionId = res.data.positionId;
				initialDate.value = res.data.birthday;
			} else {
				console.log("error submit!");
			}
		});
	}
};
//删除
const deleteUserVal = async (row) => {
	const res = await api.deleteUser({ userId: row.userId });
	if (res.code == "00000") {
		ElMessage.success("操作成功");
		getUserListDate();
	} else {
		ElMessage.error(res.message);
	}
};
// 选择上级部门
const changeUserOrg = (val) => {
	if (val) userForm.value.orgId = val[val.length - 1];
};
// 获取查询条件字典
const getDictData = () => {
	api.dictProject(
		{ dictTypeCode: "QYJBXX", dictCode: "QYJBXX_HYLB" },
		{ headers: { EnterpriseType: "ENTERPRISE" } }
	).then((res) => {
		if (res.code == "00000") {
			industryList.value = res.data;
		}
	});
};
//-----------------------------------------
//批量删除
const deleteUserList = () => {
	ElMessageBox.confirm(
		`确定删除选中的 ${selectionList.value.length} 项用户吗？`,
		"提示",
		{
			type: "warning",
		}
	)
		.then(() => {
			let params = {
				userIds: selectionList.value.map((d) => d.userId),
			};
			api.batchDelete(params).then((res) => {
				if (res.code == "00000") {
					ElMessage.success("操作成功");
					getUserListDate();
				} else {
					ElMessage.error(res.message);
				}
			});
		})
		.catch(() => {});
};
// 分配角色
const openUserRole = (row) => {
	userValueId.value = row.userId;
	showUserRole.value = true;
	roleRef.value.queryList();
};
// 提交分配角色
const grantRole = async (val) => {
	let newList = JSON.parse(JSON.stringify(val));
	let params = {
		userId: userValueId.value,
		grantRoleIdList: newList,
	};
	const res = await api.grantRole(params);
	if (res.code == "00000") {
		ElMessage.success("操作成功");
		showUserRole.value = false;
	} else {
		ElMessage.error(res.message);
	}
};
//关闭角色
const closeRole = () => {
	showUserRole.value = false;
};
// 重置密码
const resetPsw = (row) => {
	ElMessageBox.confirm(`确定要重置此用户的密码为"123456"吗?`, "提示", {
		type: "warning",
	})
		.then(() => {
			api.resetPwd({ userId: row.userId }).then((res) => {
				if (res.code == "00000") {
					ElMessage.success("操作成功");
				} else {
					ElMessage.error(res.message);
				}
			});
		})
		.catch(() => {});
};
// 切换状态
const changeStatus = async (checked, row) => {
	let params = {
		statusFlag: row.statusFlag,
		userId: row.userId,
	};
	const res = await api.changeStatus(params);
	if (res.code == "00000") {
		ElMessage.success("操作成功");
	}
};
//表格选择后回调事件
const selectionChange = (selection) => {
	selectionList.value = selection;
};
onMounted(() => {
	getDictData();
	getAreaTree();
	getDepartmentList();
});
</script>

<style lang="scss" scoped>
.custom-tree-node {
	display: flex;
	flex: 1;
	align-items: center;
	justify-content: space-between;
	font-size: 14px;
	padding-right: 24px;
	height: 100%;
}
.custom-tree-node .do {
	display: none;
}
.custom-tree-node:hover .code {
	display: none;
}
.custom-tree-node:hover .do {
	display: inline-block;
}
.bodyPage {
	display: flex;
	justify-content: space-between;
	.leftButton {
		display: flex;
		align-items: center;
		.forbidden {
			margin-left: 20px;
		}
	}
}
.userSty {
	display: flex;
	.userLeft {
		width: 50%;
	}
	.userRight {
		width: 50%;
	}
}
.label {
  width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
