<template>
	<el-container>
		<el-aside width="20%" v-loading="showLoadingLeft">
			<el-container>
				<el-main class="nopadding">
					<el-tree
						ref="groupRefLeft"
						class="menu"
						node-key="id"
						:data="groupDataLeft"
						highlight-current
						auto-expand-parent
						:props="defaultPropsLeft"
						:default-expand-all="true"
						:expand-on-click-node="false"
						@node-click="groupClickLeft"
					>
						<template #default="{ node, data }">
							<span class="custom-tree-node">
								<el-tooltip class="box-item" effect="dark" :content="data.label" placement="top">
                  					<span class="label">{{ data.label }}</span>
                				</el-tooltip>
							</span>
						</template>
					</el-tree>
				</el-main>
			</el-container>
		</el-aside>
		<el-aside width="21%" v-loading="showLoadingRight">
			<el-container>
				<el-header>
					<el-input
						placeholder="输入关键字进行过滤"
						v-model="groupFilterText"
						clearable
					></el-input>
				</el-header>
				<el-main class="nopadding">
					<el-tree
						ref="groupRefRight"
						class="menu"
						node-key="id"
						:data="groupDataRight"
						highlight-current
						auto-expand-parent
						:props="defaultPropsRight"
						:default-expand-all="true"
						:expand-on-click-node="false"
						:filter-node-method="groupFilterNode"
						@node-click="groupClickRight"
					>
						<template #default="{ node, data }">
							<span class="custom-tree-node">
								<el-tooltip class="box-item" effect="dark" :content="data.orgName" placement="top">
                  					<span class="label">{{ data.orgName }}</span>
                				</el-tooltip>
								<span class="do">
									<el-button
										icon="el-icon-edit"
										size="small"
										@click.stop="editOrg(data)"
									/>
									<el-button
										icon="el-icon-delete"
										type="danger"
										size="small"
										@click.stop="delOrg(node, data)"
									/>
								</span>
							</span>
						</template>
					</el-tree>
				</el-main>
				<el-footer style="height: 51px">
					<el-button
						type="primary"
						icon="el-icon-plus"
						:disabled="!regulatoryUnitId"
						style="width: 100%"
						@click="handleOrg"
						>新增部门</el-button
					>
				</el-footer>
			</el-container>
		</el-aside>
		<el-container>
			<el-header>
				<div
					style="
						width: 48%;
						height: 100%;
						display: flex;
						justify-content: space-between;
						align-items: center;
					"
				>
					<el-form-item label="职位名称: " style="margin-bottom: 0px">
						<el-input
							v-model="positionName"
							placeholder="请输入职位名称"
							clearable
						></el-input>
					</el-form-item>
					<el-button type="primary" @click="handelSearch"
						>查询</el-button
					>
					<el-button @click="resetSearch">重置</el-button>
				</div>
				<div>
					<el-button type="primary" :disabled="!orgId" @click="department">
						新建职位
					</el-button>
				</div>
			</el-header>

			<el-main class="nopadding">
				<scTable
					ref="tableRef"
					:data="dataTable"
					row-key="id"
					stripe
					hidePagination
					hideDo
				>
					<el-table-column
						type="index"
						width="50"
						label="序号"
						align="center"
					></el-table-column>
					<el-table-column
						label="部门名称"
						prop="orgName"
						align="center"
					></el-table-column>
					<el-table-column
						label="职位名称"
						prop="positionName"
						align="center"
						sortable
					></el-table-column>
					<el-table-column
						label="职位排序"
						prop="positionSort"
						align="center"
						sortable
					></el-table-column>
					<el-table-column label="操作" fixed="right" align="center">
						<template #default="scope">
							<el-button-group>
								<el-button
									text
									type="warning"
									size="small"
									@click="editDepartment(scope.row)"
									>编辑</el-button
								>
								<el-popconfirm
									title="确定删除吗？"
									@confirm="deleteDepartment(scope.row)"
								>
									<template #reference>
										<el-button
											text
											type="danger"
											size="small"
											>删除</el-button
										>
									</template>
								</el-popconfirm>
							</el-button-group>
						</template>
					</el-table-column>
				</scTable>
			</el-main>
			<el-footer class="bodyPage">
				<div class="leftButton"></div>
				<el-pagination
					@current-change="currentPageChange"
					@size-change="pageSizeChange"
					:page-size="pageSize"
					:current-page="pageNo"
					:small="true"
					:page-sizes="[10, 20, 50]"
					:total="total"
					layout="total, sizes, prev, pager, next, jumper"
				></el-pagination>
			</el-footer>
		</el-container>
	</el-container>
	<!-- 添加编辑部门弹窗 -->
	<el-dialog
		:title="orgTitle == 'add' ? '新增部门' : '编辑部门'"
		v-model="showOrgDialog"
		width="30%"
		:close-on-click-modal="false"
		@closed="close"
	>
		<el-form
			ref="ruleFormRef"
			:model="form"
			:rules="rules"
			label-width="120px"
			v-loading="loading"
		>
			<el-form-item label="上级部门：" prop="orgParentId" required>
				<el-cascader
					v-model="form.orgParentId"
					placeholder="请选择上级部门"
					:options="groupDataCenter"
					:props="defaultPropsRight"
					clearable
					style="width: 100%"
					@change="changeOrg"
				/>
			</el-form-item>
			<el-form-item label="部门名称：" prop="orgName" required>
				<el-input
					v-model="form.orgName"
					:formatter="(value) => value.replace(/^\s+|\s+$/g, '')"
					placeholder="请输入部门名称"
					maxlength="20"
					show-word-limit
				/>
			</el-form-item>
			<el-form-item
				label="监管行业："
				prop="orgRegulatoryIndustry"
				required
			>
				<el-select
					v-model="form.orgRegulatoryIndustry"
					placeholder="请选择监管行业"
					class="w-full"
				>
					<el-option
						v-for="i in industryList"
						:key="i.value"
						:label="i.label"
						:value="i.value"
					/>
				</el-select>
			</el-form-item>
			<el-form-item label="排序号：" prop="orgSort">
				<el-input-number
					placeholder="请输入排序号"
					style="text-align: left; width: 100%"
					v-model="form.orgSort"
					:min="1"
					:max="999"
					:step="1"
					step-strictly
					controls-position="right"
				/>
			</el-form-item>
			<el-form-item label="备注：" prop="orgRemark">
				<el-input v-model="form.orgRemark" placeholder="请输入备注" />
			</el-form-item>
		</el-form>
		<template #footer>
			<div class="dialog-footer">
				<el-button @click="close(ruleFormRef)">取消</el-button>
				<el-button type="primary" @click="submitForm(ruleFormRef)"
					>确认</el-button
				>
			</div>
		</template>
	</el-dialog>
	<AddRole
		ref="addRoleRef"
		:showDialog="showDialog"
		:departmentTitle="departmentTitle"
		:orgId="orgId"
		:positionId="positionId"
		@closePositionDialog="closePositionDialog"
	/>
</template>

<script setup>
import { ref, reactive, onMounted, watch } from "vue";
import CommonApi from "./server/api";
import { ElMessage, ElMessageBox } from "element-plus";
import AddRole from "./components/addRole.vue";

//----------------------------------------
// 初始化数据树过滤
let groupFilterText = ref("");
// 加载
let showLoadingLeft = ref(false);
let showLoadingRight = ref(false);
// 新增弹窗
let showOrgDialog = ref(false);
// 新增/编辑弹窗标题
let orgTitle = ref("");
// 树数据
let groupDataLeft = ref([]);
// 部门树数据
let groupDataRight = ref([]);
//内部部门
let groupDataCenter=ref([]);
// 表单ref
let ruleFormRef = ref(null);
//监管区域ID
let regulatoryUnitId = ref("");
//编辑部门ID
let editDepartmentId = ref("");
//行业列表
let industryList = ref([]);

//职位显隐
let showDialog = ref(false);
let departmentTitle = ref("");
let addRoleRef = ref(null);
// 新增/编辑 表单数据
const form = ref({
	orgName: "",
	orgParentId: "",
	orgRegulatoryIndustry: null,
	orgSort: null,
	orgRemark: "",
	orgRegulatoryUnit: "",
});
//正则
let rules = ref({
	orgParentId: [
		{
			required: true,
			message: "请选择上级部门",
			trigger: ["change"],
		},
	],
	orgName: [
		{
			required: true,
			message: "请输入部门名称",
			trigger: ["change"],
		},
		{
			max: 20,
			pattern: /^[\u4e00-\u9fa5a-zA-Z0-9]{1,20}$/,
			message: "请输入汉字、字母、数字",
		},
	],
	orgRegulatoryIndustry: [
		{
			required: true,
			message: "请选择监管行业",
			trigger: ["change"],
		},
	],
});
// 树ref
const groupRefLeft = ref(null);
const groupRefRight = ref(null);

//部门id
let orgId = ref("");
let positionId = ref("");
//职位名称
let positionName = ref("");

let pageNo = ref(1);
let pageSize = ref(10);
let total = ref(0);


//职位列表
const dataTable = ref([]);
const tableRef = ref(null);

watch(
	() => groupFilterText.value,
	(nVal) => {
		groupRefRight.value.filter(nVal);
	}
);
// 行政区树格式
const defaultPropsLeft = ref({
	label: "label",
	value: "value",
});
// 部门区树格式
const defaultPropsRight = ref({
	label: "orgName",
	value: "orgId",
	checkStrictly: true,
});
// 新增编辑弹窗loading
const loading = ref(false);
//过滤关键字
const groupFilterNode = (value, data) => {
	if (!value) return true;
	return data.orgName.indexOf(value) !== -1;
};
//树点击事件左侧
const groupClickLeft = (data) => {
	regulatoryUnitId.value = data.value;
	form.value.orgRegulatoryUnit = data.value;
  orgId.value=''
  dataTable.value=[]
	getOrganizationTree(data.value);
};
//获取部门树
const getOrganizationTree = async (val) => {
	let saDetail = await CommonApi.organizationTree({ orgRegulatoryUnit: val });
  groupDataRight.value = saDetail.data;
};
//获取部门内部树
const insideOrganizationTree = async () => {
	let saDetail = await CommonApi.insideOrganizationTree({ orgRegulatoryUnit: regulatoryUnitId.value });
  groupDataCenter.value = saDetail.data;
};
//树点击事件右侧
const groupClickRight = (data) => {
	console.log(data);
	orgId.value = data.orgId;
	getPositionList();
};
// 编辑部门
const editOrg = (data) => {
	orgTitle.value = "edit";
	editDepartmentId.value = data.orgId;
	getSysAreaDetail(data.orgId);
	showOrgDialog.value = true;
  insideOrganizationTree();
};
// 获取编辑详情
const getSysAreaDetail = async (id) => {
	let saDetail = await CommonApi.detailDepartment({ orgId: id });
	form.value = {
		orgName: saDetail?.data.orgName,
		orgParentId: saDetail?.data.orgParentId,
		orgRegulatoryUnit: saDetail?.data.orgRegulatoryUnit,
		orgRegulatoryIndustry: saDetail?.data.orgRegulatoryIndustry,
		orgSort: saDetail?.data.orgSort,
		orgRemark: saDetail?.data.orgRemark,
	};
};
// 删除部门
const delOrg = (node, data) => {
	ElMessageBox.confirm(`确定删除选中部门吗？`, "提示", {
		type: "warning",
	})
		.then(() => {
			let params = {
				orgId: data.orgId,
			};
			CommonApi.deleteDepartment(params).then((res) => {
				if (res.code == "00000") {
					ElMessage.success("删除成功");
					getOrganizationTree(regulatoryUnitId.value);
				} else {
					ElMessage.error(res.message);
				}
			});
		})
		.catch(() => {});
};
// 选择上级行政区
const changeOrg = (val) => {
	if (val) form.value.orgParentId = val[val.length - 1];
};
// 关闭弹窗
const close = (formEl) => {
	if (!formEl) return;
	formEl.resetFields();
	showOrgDialog.value = false;
};
// 新增/编辑弹窗保存
const submitForm = (formEl) => {
	if (!formEl) return;
	formEl.validate((valid) => {
		if (valid) {
			if (orgTitle.value == "add") {
				CommonApi.addDepartment(form.value).then((res) => {
					if (res.code == "00000") {
						ElMessage.success("新增成功");
						showOrgDialog.value = false;
						getOrganizationTree(regulatoryUnitId.value);
						getPositionList();
					} else {
						ElMessage.warning(res.message);
					}
				});
			} else {
				CommonApi.updateDepartment({
					...form.value,
					orgId: editDepartmentId.value,
				}).then((res) => {
					if (res.code == "00000") {
						ElMessage.success("编辑成功");
						showOrgDialog.value = false;
						getOrganizationTree(regulatoryUnitId.value);
						getPositionList();
					} else {
						ElMessage.warning(res.message);
					}
				});
			}
			// formEl.resetFields()
		} else {
			console.log("error submit!");
			return false;
		}
	});
};
// 获取行政区数据
const getAreaTree = () => {
	CommonApi.sysAreaTree().then((res) => {
		if (res.code == "00000") {
			groupDataLeft.value = res.data;
		} else {
			console.log(res.message);
		}
	});
};
// 添加部门
const handleOrg = () => {
	if (ruleFormRef.value) {
		ruleFormRef.value.resetFields();
	}
	showOrgDialog.value = true;
	orgTitle.value = "add";
  insideOrganizationTree();
};

//新建职位
const department = () => {
	showDialog.value = true;
	departmentTitle.value = "add";
};
//编辑职位
const editDepartment = (val) => {
	showDialog.value = true;
	departmentTitle.value = "edit";
	positionId.value = val.positionId;
};
//关闭弹窗
const closePositionDialog = (data) => {
	showDialog.value = false;
	departmentTitle.value = "";
	if (data) {
		getPositionList();
	}
};
//搜索
const handelSearch = () => {
	getPositionList();
};
//重置
const resetSearch=()=>{
  positionName.value='';
  getPositionList();
}

//获取职位列表
const getPositionList = () => {
	CommonApi.getHrPosition({
		orgId: orgId.value,
		positionName: positionName.value,
		pageNo: pageNo.value,
		pageSize: pageSize.value,
	}).then((res) => {
		if (res.code == "00000") {
			dataTable.value = res.data.rows;
			total.value = res.data.totalRows;
		} else {
			console.log(res.message);
		}
	});
};
//删除职位
const deleteDepartment = async (e) => {
	const res = await CommonApi.deletePosition({ positionId: e.positionId });
	if (res) {
		ElMessage.success("删除成功!");
		handelSearch();
	}
};
//切换页数
const currentPageChange = (val) => {
	pageNo.value = Number(val.toString().split(".")[0]);
	getPositionList();
};
//切换每页条数
const pageSizeChange = (val) => {
	pageSize.value = val;
	getPositionList();
};
// 获取查询条件字典
const getDictData = () => {
	CommonApi.dictProject(
		{ dictTypeCode: "QYJBXX", dictCode: "QYJBXX_HYLB" },
		{ headers: { EnterpriseType: "ENTERPRISE" } }
	).then((res) => {
		if (res.code == "00000") {
			industryList.value = res.data;
		}
	});
};
//----------------------------------------
onMounted(() => {
	getDictData();
	getAreaTree();
	// getPositionList();
});
</script>

<style scoped lang="scss">
.custom-tree-node {
	display: flex;
	flex: 1;
	align-items: center;
	justify-content: space-between;
	font-size: 14px;
	padding-right: 24px;
	height: 100%;
}
.custom-tree-node .do {
	display: none;
}
.custom-tree-node:hover .code {
	display: none;
}
.custom-tree-node:hover .do {
	display: inline-block;
}
.bodyPage {
	display: flex;
	justify-content: space-between;
	.leftButton {
		display: flex;
		align-items: center;
		.forbidden {
			margin-left: 20px;
		}
	}
}
.label {
  width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
