<template>
    <div>
        <el-dialog v-model="showDialog" :title="departmentTitle=='add'?'新建职位':'编辑职位'" @closed="close" width="30vw" :close-on-click-modal="false">
            <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px">
                <el-form-item label="职位名称: " prop="positionName" required>
                    <el-input v-model="form.positionName" :formatter="(value) => value.replace(/^\s+|\s+$/g, '')"
                        placeholder="请输入职位名称" />
                </el-form-item>
                <el-form-item label="职位编码: " prop="positionCode" required>
                    <el-input v-model="form.positionCode" :formatter="(value) => value.replace(/^\s+|\s+$/g, '')"
                        placeholder="请输入职位编码" />
                </el-form-item>
                <el-form-item label="职位排序: " prop="positionSort" required>
                    <el-input-number placeholder="请输入职位排序" style="text-align: left;width: 100%;" v-model="form.positionSort"
                        :min="1" :step="1" step-strictly controls-position="right" />
                </el-form-item>
                 <el-form-item label="备注信息: " prop="positionRemark">
                   <el-input v-model="form.positionRemark" placeholder="请输入备注信息" />
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="close">取消</el-button>
                    <el-button type="primary" @click="submitForm">
                        保存
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
import {  ref, reactive, watch} from "vue";
import { ElMessage } from "element-plus";
import api from "../server/api";

const emits = defineEmits(['closePositionDialog', "close"]);
const props = defineProps({
    showDialog: {
        type: Boolean,
        default: false
    },
    departmentTitle:{
        type: String,
        default: ''
    },
    orgId:{
        type: String,
        default: ''
    },
    positionId:{
        type: String,
        default: ''
    },
});
watch(
    ()=>props.departmentTitle,
    (newVal)=>{
        newVal=='edit'?getDetailPosition():ruleFormRef.value?.resetFields();
    }
)
const ruleFormRef = ref(null);
const form = ref({
    orgId:'',
    positionName: '',
    positionCode: '',
    positionSort: '&nbsp;',
    positionRemark:'',
    statusFlag:1,
});
const rules = reactive({
    positionName: [
        { required: true, message: '请输入职位名称', trigger: 'blur' },
    ],
    positionCode: [
        { required: true, message: '请输入职位编码', trigger: 'blur' },
    ],
    positionSort: [
        { required: true, message: '请输入职位排序', trigger: ['change', 'blur'] },
    ],
})

const close = () => {
    emits("closePositionDialog");
}
const submitForm = async () => {
    ruleFormRef.value?.validate(async (valid, fields) => {
        if (valid) {
            let res;
            if (props.departmentTitle=='edit') {
                let obj = JSON.parse(JSON.stringify(form.value));
                delete obj.orgId
                obj.positionId=props.positionId
                res = await api.updatePosition(obj);
            } else {
                form.value.orgId=props.orgId;
                res = await api.addPosition(form.value);
            }
            if (res.success) {
                ElMessage.success('操作成功!');
                ruleFormRef.value?.resetFields();
                emits("closePositionDialog", true);
            }
            else {
                ElMessage.error(res.message)
            }
        } else {
            console.log('error submit!', fields)
        }
    })
}
//获取详情
const getDetailPosition=  ()=>{
    if(props.departmentTitle=='edit'){
         api.detailPosition({positionId:props.positionId}).then((res)=>{
            if(res.code=='00000'){
                form.value.orgId=res.data.orgId;
                form.value.positionName=res.data.positionName;
                form.value.positionCode=res.data.positionCode;
                form.value.positionSort=res.data.positionSort;
                form.value.positionRemark=res.data.positionRemark;
                form.value.statusFlag=res.data.statusFlag;
            }else{
                console.log('error submit!')
            }
        })
    }
}
</script>

<style scoped lang="scss">
::v-deep(.el-input-number .el-input__inner) {
    text-align: left;
}
</style>
