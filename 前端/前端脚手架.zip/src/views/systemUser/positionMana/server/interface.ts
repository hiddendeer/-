export interface paramsType {
    roleName?: string,
    roleCode?: string,
    pageNo: number,
    pageSize: number
}
export interface table_item {
    createTime?: string,
    createUser?: string,
    dataScopeType?: number,
    roleCode?: string,
    roleName?: string,
    roleSort?: number,
    [name: string]: any,
}


export type dataFrom = {
    dataTable: Array<table_item> | undefined,
    search: {
        resourceName: string,
        resourceUrl: string,
    },
    apiObj: Function,
    selectionTable?: Array<table_item>,
}

export type role = {
    roleCode: string | undefined,
    roleName: string | undefined,
    roleSort: number | string | undefined,
    roleId?: string,
}

export type roleIdType = {
    roleId?: string
}

export type menuProps = {
    label: string,
    children: string
}
export type treeItem = {
    checked: boolean,
    code: string,
    id: string,
    name: string,
    nodeId: string,
    nodeParentId: string,
    pid: string,
    [props: string]: any | null | undefined,
}

export type treeItemChildren = treeItem & {
    children?: treeItem
}

export type setMenusRole = {
    roleId: string,
    grantAddMenuFlag: boolean,
    grantMenuId: string
}
// get接口请求参数
export interface paramType {
    pageNo?: number
    pageSize?: number
  }
  // 行政区域参数类型
  export type sysAreaType = {
    areaId?: string
    parentId: string
    fullName: string
    areaCode: string
    areaSort: number
    remark: string
  }
  // 删除行政区域参数类型 deleteSysType
  export type areaIdType = {
    areaId: string
  }
export type addPositionType = {
    orgId:string,
    positionName: string,
    positionCode: string,
    positionSort: number,
    positionRemark:string,
    statusFlag:number,
}


  