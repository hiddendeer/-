import request from "@/utils/network.js";
import {
  paramType,
  sysAreaType,
  areaIdType,
  addPositionType
} from "./interface";

export default class CommonApi {
  // 获取行政区树
  static sysAreaTree = (params: paramType) => {
    return request({
      url: `/api/sysArea/queryTree`,
      method: "GET",
      params,
    });
  };
  // 新增行政区域
  static addSysArea = (data: sysAreaType) => {
    return request({
      url: `/api/sysArea/add`,
      method: "POST",
      data,
    });
  };
  // 编辑行政区域
  static updateSysArea = (data: sysAreaType) => {
    return request({
      url: `/api/sysArea/update`,
      method: "PUT",
      data,
    });
  };
  // 删除行政区树
  static deleteSysArea = (data: areaIdType) => {
    return request({
      url: `/api/sysArea/delete`,
      method: "DELETE",
      data,
    });
  };
  // 查看行政区域
  static sysAreaDetail = (params: areaIdType) => {
    return request({
      url: `/api/sysArea/queryDetail`,
      method: "GET",
      params,
    });
  };
  //获取职位分页
  static getHrPosition = (params: paramType) => {
    return request({
      url: `/api/hrPosition/page`,
      method: "GET",
      params,
    });
  };
  // 新增职位
  static addPosition= (data: addPositionType) => {
    return request({
      url: `/api/hrPosition/add`,
      method: "POST",
      data,
    });
  };
   // 编辑职位
   static updatePosition= (data: addPositionType) => {
    return request({
      url: `/api/hrPosition/edit`,
      method: "PUT",
      data,
    });
  };
  // 职位详情
  static detailPosition = (params: paramType) => {
    return request({
      url: `/api/hrPosition/detail`,
      method: "GET",
      params,
    });
  };
   // 删除行政区树
   static deletePosition = (data: paramType) => {
    return request({
      url: `/api/hrPosition/delete`,
      method: "DELETE",
      data,
    });
  };
   // 获取职位部门树
   static organizationTree = (params: paramType) => {
    return request({
      url: `/api/expHrOrganization/organizationTree`,
      method: "GET",
      params,
    });
  };
  // 获取内部部门树
  static insideOrganizationTree = (params: paramType) => {
    return request({
      url: `/api/expHrOrganization/querySelect`,
      method: "GET",
      params,
    });
  };
   // 新增部门
   static addDepartment= (data: paramType) => {
    return request({
      url: `/api/expHrOrganization/add`,
      method: "POST",
      data,
    });
  };
   // 编辑职位
   static updateDepartment= (data: paramType) => {
    return request({
      url: `/api/expHrOrganization/update`,
      method: "PUT",
      data,
    });
  };
  // 职位详情
  static detailDepartment = (params: paramType) => {
    return request({
      url: `/api/expHrOrganization/queryDetail`,
      method: "GET",
      params,
    });
  };
   // 删除行政区树
   static deleteDepartment = (data: paramType) => {
    return request({
      url: `/api/expHrOrganization/delete`,
      method: "DELETE",
      data,
    });
  };
  // 项目字典查询通用接口
  static dictProject = (params: paramType,config:object) => {
    return request({
      url: `/baseServer/applicationVisionDict/queryDictForExternal`,
      method: 'GET',
      params,
      ...config
    })
  }
}
