<template>
	<el-container>
		<el-aside width="300px" v-loading="tools.showGrouploading">
			<el-container>
				<el-header>
					<el-input placeholder="输入关键字进行过滤" v-model="tools.groupFilterText" clearable></el-input>
				</el-header>
				<el-main class="nopadding">
					<el-tree ref="groupRef" class="menu" node-key="id" :data="treeData" highlight-current auto-expand-parent :props="defaultProps"
            :default-expand-all="true" :expand-on-click-node="false" :filter-node-method="groupFilterNode" @node-click="groupClick">
            <template #default="{ node, data }">
              <span class="custom-tree-node">
                <span class="label">{{ data.name }}</span>
                <span class="do">
                  <el-button icon="el-icon-edit" size="small" @click.stop="editOrg(data)" />
                  <el-button icon="el-icon-delete" type="danger" size="small" @click.stop="delOrg(node, data)" />
                </span>
              </span>
            </template>
          </el-tree>
				</el-main>
        <el-footer style="height: 51px">
          <el-button
            type="primary"
            icon="el-icon-plus"
            style="width: 100%"
            @click="handleOrg"
            >新增组织机构</el-button
          >
        </el-footer>
			</el-container>
		</el-aside>
		<el-container>
      <el-header>
        <div class="left-panel">
          <el-button type="primary" icon="el-icon-plus" @click="add">新建</el-button>
          <el-button type="danger" plain icon="el-icon-delete" :disabled="tools.selection.length==0" @click="batch_del">删除</el-button>
        </div>
        <div class="right-panel">
          <div class="right-panel-search ">
            <el-form-item label="角色名称: " style="margin-bottom: 0px;">
              <el-input v-model="searchForm.realName" placeholder="请输入姓名" clearable></el-input>
            </el-form-item>
            <el-form-item label="角色编码: " style="margin-bottom: 0px;">
              <el-input v-model="searchForm.account" placeholder="请输入账号" clearable></el-input>
            </el-form-item>
            <el-button type="primary" @click="upsearch">查询</el-button>
            <el-button @click="reset">重置</el-button>
          </div>
        </div>
      </el-header>
      <el-main class="nopadding">
        <scTable ref="tableRef" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" :apiObj="tools.apiObj"
          :params="searchForm" @selection-change="selectionChange" stripe remoteSort remoteFilter>
          <el-table-column type="selection" width="50"></el-table-column>
          <el-table-column width="80" align="center" type="index"></el-table-column>
          <el-table-column label="账号" align="center" prop="account" width="150"></el-table-column>
          <el-table-column label="姓名" align="center" prop="realName" width="150"></el-table-column>
          <el-table-column label="职务" align="center" prop="positionName" width="200"></el-table-column>
          <el-table-column label="电话" align="center" prop="phone" width="170"></el-table-column>
          <el-table-column label="性别" align="center" prop="sex" width="170">
            <template #default="scope">
              {{ scope.row.sex == 'M' ? '男' : '女' }}
            </template>
          </el-table-column>
          <el-table-column label="邮箱" align="center" prop="email" width="170"></el-table-column>
          <el-table-column label="状态" align="center" prop="statusFlag" width="170">
            <template #default="scope">
              <el-switch v-model="scope.row.statusFlag" :active-value='1' :inactive-value='2'
                :checked="scope.row.statusFlag == 1" @change="checked => changeStatus(checked, scope.row)" />
            </template>
          </el-table-column>
          <el-table-column label="操作" fixed="right" align="center" width="260">
            <template #default="scope">
              <el-button-group>
                <el-button text type="primary" size="small" @click="table_edit(scope.row)">修改</el-button>
                <el-popconfirm title="确定删除吗？" @confirm="table_del(scope.row)">
                  <template #reference>
                    <el-button text type="danger" size="small">删除</el-button>
                  </template>
                </el-popconfirm>
                <el-button text type="primary" size="small" @click="openRole(scope.row)">分配角色</el-button>
                <el-button text type="primary" size="small" @click="resetPsw(scope.row)">重置密码</el-button>
              </el-button-group>
            </template>
          </el-table-column>
        </scTable>
      </el-main>
		</el-container>
	</el-container>
  <!-- 新增、编辑人员弹窗 -->
  <formContainer v-model:formVisible="tools.formVisible" :title="tools.title"
    :fieldConfig="fieldConfig" ref="refFormContainer" @change="formChange" />
  <!-- 分配角色弹窗 -->
  <userRole ref="roleRef" v-model:showDialog="tools.showUserRole"
    :userId="tools.currentId" @submit="grantRole" />
  <!-- 新增、编辑组织弹窗 -->
  <addOrg ref="addOrgRef" v-model:showAdd="tools.showOrgDialog" :title="tools.orgTitle"
    :editId="tools.currentOrgId" @updateOrg="getGroup" />
</template>

<script setup>
	import api from './server/api.js';
  import { ref, reactive, onMounted, watch, nextTick } from "vue";
  import { ElMessage, ElMessageBox } from "element-plus";
  import userRole from '@/views/systemSetting/userManagement/components/userRole';
  import formContainer from '@/componentsEngineer/vr-form/formContainer.vue';
  import addOrg from '@/views/systemSetting/userManagement/components/addOrg.vue';
  import fieldConfig from './config/fieldConfig.js';

  const tools = reactive({
    showGrouploading: false,
    groupFilterText: '',
    userList: [],
    selection: [],
    apiObj: api.getuserList,
    search: {
      name: null
    },
    formVisible: false,
    title: '',
    showUserRole: false,
    showOrgDialog: false
  });
  const searchForm = reactive({
    orgId: '',
    account: '',
    realName: '',
    // pageNo: 1,
    // pageSize: 10
  });
  // 组织树格式
  const defaultProps = reactive({
    id: "id",
    label: "name",
  });
  const treeData = ref([]);
  const tableRef = ref(null);
  const groupRef = ref(null);
  const refFormContainer = ref(null);
  const roleRef = ref(null);
  const addOrgRef = ref(null);
  watch(() => tools.groupFilterText, (newValue, oldValue) => {
  	groupRef.value.filter(newValue);
  });
  onMounted(() => {
    hrPositionList();
    getGroup();
    upsearch();
  });
  // 获取职位列表
  const hrPositionList = async () => {
    let res = await api.hrPositionList();
    if (res.code == '00000' && res.data) {
      fieldConfig.fieldParams.forEach(item => {
        if (item.model == "positionId") {
          item.options = res.data;
        }
			})
    } else {
      ElMessage.error(res.message);
    }
  };
  // 添加组织
  const handleOrg = () => {
    tools.showOrgDialog = true;
    tools.orgTitle = '新增机构';
    tools.currentOrgId = '';
  };
  // 添加组织
  const editOrg = (data) => {
    if (data?.id) {
      tools.orgTitle = '编辑机构';
      addOrgRef.value.queryDetail(data?.id);
      tools.currentOrgId = data.id;
      tools.showOrgDialog = true;
    }
  };
  // 删除组织
  const delOrg = (node, data) => {
    ElMessageBox.confirm(`确定删除选中组织机构吗？`, '提示', {
      type: 'warning',
    }).then(() => {
      let params = {
        orgId: data.id
      }
      api.delOrg(params).then(res => {
        if (res.code == '00000') {
          ElMessage.success('操作成功');
          getGroup();
          upsearch();
        } else {
          ElMessage.error(res.message);
        }
      })
    }).catch(() => { })
  };
  //添加
  const add = () => {
    nextTick(() => {
      fieldConfig.fieldParams.forEach(item => {
        if (item.model == "password" || item.model == "repeatPassword") {
          item.type = "password";
        }
			})
      tools.title = '新建用户';
      tools.type = 'add';
      tools.formVisible = true;
    })
  };
  //编辑
  const table_edit = (row) => {
    nextTick(() => {
      fieldConfig.fieldParams.forEach(item => {
        if (item.model == "password" || item.model == "repeatPassword") {
          item.type = "";
        }
			})
      tools.title = '修改用户';
      tools.type = 'edit';
      tools.formVisible = true;
      refFormContainer.value.detailTrigger(row);
    })
  };
  //删除
  const table_del = async(row) => {
    const res = await api.deleteUser({ userId: row.userId });
    if (res.code == '00000') {
      ElMessage.success('操作成功');
      upsearch();
    } else {
      ElMessage.error(res.message);
    }
  };
  //批量删除
  const batch_del = () => {
    ElMessageBox.confirm(`确定删除选中的 ${tools.selection.length} 项用户吗？`, '提示', {
      type: 'warning',
    }).then(() => {
      let params = {
        userIds: tools.selection.map(d => d.userId)
      }
      api.batchDelete(params).then(res => {
        if (res.code == '00000') {
          ElMessage.success('操作成功');
          upsearch();
        } else {
          ElMessage.error(res.message);
        }
      })
    }).catch(() => { })
  };
  // 分配角色
  const openRole = (row) => {
    tools.currentId = row.userId;
    roleRef.value.queryList();
    tools.showUserRole = true;
  };
  // 提交分配角色
  const grantRole = async (val) => {
    let newList = JSON.parse(JSON.stringify(val));
    let params = {
      userId: tools.currentId,
      grantRoleIdList: newList
    }
    const res = await api.grantRole(params);
    if (res.code == '00000') {
      ElMessage.success('操作成功');
      tools.showUserRole = false;
    } else {
      ElMessage.error(res.message);
    }
  };
  // 重置密码
  const resetPsw = (row) => {
    ElMessageBox.confirm(`确定要重置此用户的密码为"123456"吗?`, '提示', {
      type: 'warning',
    }).then(() => {
      api.resetPwd({ userId: row.userId }).then(res => {
        if (res.code == '00000') {
          ElMessage.success('操作成功');
        } else {
          ElMessage.error(res.message);
        }
      })
    }).catch(() => { })
  };
  // 切换状态
  const changeStatus = async (checked,row) => {
    let params = {
      statusFlag: row.statusFlag,
      userId: row.userId
    }
    const res = await api.changeStatus(params);
    if (res.code == '00000') {
      ElMessage.success('操作成功');
      upsearch();
    }
  };
  //表格选择后回调事件
  const selectionChange = (selection) => {
    tools.selection = selection;
  };
  //加载树数据
  const getGroup = async () => {
    tools.showGrouploading = true;
    let res = await api.getTree();
    tools.showGrouploading = false;
    if (res.code == '00000' && res.data) {
      treeData.value = res.data;
      fieldConfig.fieldParams.forEach(item => {
        if (item.model == "orgId") {
          item.options = res.data;
        }
			})
    }
  };
  //树过滤
  const groupFilterNode = (value, data) => {
    if (!value) return true;
    return data.name.indexOf(value) !== -1;
	};
  //树点击事件
  const groupClick = (data) => {
    searchForm.orgId = data.id;
    upsearch();
  };
  // 新增、编辑
  const formChange = async (obj) => {
    if (tools.type != 'edit' && obj?.formObj?.repeatPassword != obj?.formObj?.password) {
      return ElMessage.error('确认密码与登录密码输入不一致，请检查！');
    }
    let apiName = 'addUser';
    if ( tools.type == 'edit' ) apiName = 'editUser';
    const res = await api[`${ apiName }`](obj.formObj)
    if (res.code == '00000') {
      ElMessage.success('操作成功');
      tools.formVisible = false;
      upsearch();
    }
  };
  //搜索
  const upsearch = async () => {
    if (tableRef.value) {
      tableRef.value.refresh();
    }
  };
  // 重置
  const reset = () => {
    Object.keys(searchForm).forEach( key => { searchForm[key] = '' });
    upsearch();
  };
</script>

<style scoped>
.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node:hover .code {
  display: none;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
</style>
