import request from "@/utils/network.js";
export default class CommonApi {
  // 用户管理获取组织树
  static getTree(params) {
    return request({
      url: `/api/hrOrganization/tree`,
      method: 'get',
      params
    })
  }
  // 获取用户列表
  static getuserList(params) {
    return request({
      url: `/api/sysUser/page`,
      method: 'get',
      params
    })
  }
  // 重置密码
  static resetPwd(data) {
    return request({
      url: `/api/sysUser/resetPwd`,
      method: 'post',
      data
    })
  }
  // 变更用户状态
  static changeStatus(data) {
    return request({
      url: `/api/sysUser/changeStatus`,
      method: 'post',
      data
    })
  }
  // 批量删除
  static batchDelete(data) {
    return request({
      url: `/api/sysUser/batchDelete`,
      method: 'post',
      data
    })
  }
  // 删除用户
  static deleteUser(data) {
    return request({
      url: `/api/sysUser/delete`,
      method: 'post',
      data
    })
  }
  // 新增用户
  static addUser(data) {
    return request({
      url: `/api/sysUser/add`,
      method: 'post',
      data
    })
  }
  // 编辑用户
  static editUser(data) {
    return request({
      url: `/api/sysUser/edit`,
      method: 'post',
      data
    })
  }
  // 获取分配角色列表
  static getRoleList(params) {
    return request({
      url: `/api/sysRole/dropDown`,
      method: 'get',
      params
    })
  }
  // 查询用户已分配角色
  static getUserRoles(params) {
    return request({
      url: `/api/sysUser/getUserRoles`,
      method: 'get',
      params
    })
  }
  // 保存分配角色
  static grantRole(data) {
    return request({
      url: `/api/sysUser/grantRole`,
      method: 'post',
      data
    })
  }
  // 新增组织机构
  static addOrg(data) {
    return request({
      url: `/api/hrOrganization/add`,
      method: 'post',
      data
    })
  }
  // 删除组织机构
  static delOrg(data) {
    return request({
      url: `/api/hrOrganization/delete`,
      method: 'post',
      data
    })
  }
  // 获取组织详情
  static orgDetail(params) {
    return request({
      url: `/api/hrOrganization/detail`,
      method: 'get',
      params
    })
  }
  // 编辑组织机构
  static editOrg(data) {
    return request({
      url: `/api/hrOrganization/edit`,
      method: 'post',
      data
    })
  }
  // 获取职位列表
  static hrPositionList(params) {
    return request({
      url: `api/hrPosition/list`,
      method: 'get',
      params
    })
  }
}