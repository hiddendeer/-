<template>
    <el-container>

        <el-header>
            <div>
                <el-button type="primary" icon="el-icon-plus" @click="() => { roleTitle = '新建应用'; showDialog = true }">新建
                </el-button>
            </div>
            <div style="width:60%;height: 100%;display: flex;justify-content: space-between;align-items: center;">
                <el-form-item label="应用名称: " style="margin-bottom: 0px;">
                    <el-input v-model="data.search.appName" placeholder="应用名称" clearable></el-input>
                </el-form-item>
                <el-form-item label="应用编码: " style="margin-bottom: 0px;">
                    <el-input v-model="data.search.appCode" placeholder="应用编码" clearable></el-input>
                </el-form-item>
                <el-button type="primary" icon="el-icon-search" @click="handelSearch">搜索</el-button>
            </div>
        </el-header>

        <el-main class="nopadding">


            <scTable ref="table" @selection-change="selectionChange" :apiObj="data.apiObj" :params="data.search"
                :data="data.dataTable" row-key="id">
                <el-table-column type="index" width="50" align="center"></el-table-column>
                <el-table-column label="应用名称" prop="appName" align="center"></el-table-column>
                <el-table-column label="应用编码" prop="appCode" align="center"></el-table-column>
                <el-table-column label="应用图标" prop="appIcon" align="center"></el-table-column>
                <el-table-column label="是否激活" align="center">
                    <template #default="scope">
                        <el-switch @change="changeSwitch($event, scope.row.appId)"
                            :model-value="scope.row.activeFlag == 'Y'" class="ml-2" inline-prompt
                            style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" active-text="是"
                            inactive-text="否" />
                    </template>
                </el-table-column>
                <el-table-column label="操作" fixed="right" align="center">
                    <template #default="scope">
                        <el-button-group>
                            <el-button text type="warning" size="small" @click="table_edit(scope.row)">修改
                            </el-button>
                            <el-popconfirm title="确定删除吗？" @confirm="table_del(scope.row)">
                                <template #reference>
                                    <el-button text type="danger" size="small">删除</el-button>
                                </template>
                            </el-popconfirm>
                        </el-button-group>
                    </template>
                </el-table-column>
            </scTable>
        </el-main>
    </el-container>
    <AddRole ref="addRoleRef" v-model:showDialog="showDialog" :title="roleTitle" @close="handelSearch" />
</template>


<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue';
import { paramsType, roleIdType, menuProps as menuPropsType, table_item, dataFrom, treeItemChildren } from "./server/interface";
import CommonApi from "./server/api";
import { ElMessage } from "element-plus";
import AddRole from './components/addRole.vue';

const table = ref<any>(null);
const showDialog = ref<boolean>(false);
const roleTitle = ref<string>('');
const addRoleRef = ref<null | undefined | any>(null);
const data = reactive<dataFrom>({
    dataTable: [],
    search: {
        appName: "",
        appCode: '',
    },
    apiObj: CommonApi.get,
    selectionTable: [],
})
const menuList = ref<any>(null);
const selectionTreeId = ref<string[]>([]);
const roleId = ref<string>('');
const drawerTree = ref(false);
const menuProps = ref<menuPropsType | undefined>({
    label: "name",
    children: 'children',
})
onMounted(() => {
    handelSearch();
})
const handelSearch = async () => {
    table.value?.refresh();
}

const selectionChange = (e: table_item[]) => {
    data.selectionTable = e;
}
const table_edit = (e: table_item) => {
    let obj = {
        appCode: e.appCode,
        appName: e.appName,
        appIcon: e.appIcon,
        appId: e.appId,
    }
    roleTitle.value = '修改应用';
    addRoleRef.value.edit(JSON.parse(JSON.stringify(obj)))
}
const table_del = async (e: table_item) => {
    const res = await CommonApi.deleteDictTree({ appId: e.appId })
    if (res) {
        ElMessage.success('删除成功!')
        handelSearch()
    }
}
const changeSwitch = async (e: boolean, id: string) => {
    if (!e) return;
    const res = await CommonApi.updateActiveFlag({
        activeFlag: e ? 'Y' : 'N',
        appId: id
    })
    if (res) {
        ElMessage.success('切换成功!')
        handelSearch()
    }
}
</script>

<style scoped lang="scss">

</style>
