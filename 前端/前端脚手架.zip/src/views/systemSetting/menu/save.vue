<template>
  <el-row :gutter="50">
    <el-col v-if="!hasShow">
      <el-empty description="请选择左侧菜单后操作" :image-size="100"></el-empty>
    </el-col>
    <template v-else>
      <el-col :lg="12">
        <h2>{{ form.menuName || "新增菜单" }}</h2>
        <el-form
          :model="form"
          :rules="rules"
          ref="dialogForm"
          label-width="80px"
          label-position="left"
        >
          <el-form-item label="菜单名称" prop="menuName">
            <el-input
              v-model="form.menuName"
              clearable
              placeholder="菜单显示名字"
            ></el-input>
          </el-form-item>
          <el-form-item label="菜单编号" prop="menuCode">
            <el-input
              v-model="form.menuCode"
              clearable
              placeholder="请输入菜单编号"
            ></el-input>
          </el-form-item>
          <div class="flex justify-between">
            <el-form-item label="所属应用" prop="appCode">
              <el-select v-model="form.appCode" placeholder="请选择所属应用">
                <el-option
                  v-for="item in menuAppOptions"
                  :key="item.appCode"
                  :label="item.appName"
                  :value="item.appCode"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="上级菜单">
              <el-cascader
                v-model="form.menuParentId"
                :options="menuOptions"
                :props="menuProps"
                :show-all-levels="false"
                placeholder="顶级菜单"
                clearable
                disabled
              ></el-cascader>
            </el-form-item>
          </div>
          <el-form-item label="类型" prop="antdvLinkOpenType">
            <el-radio-group v-model="form.antdvLinkOpenType">
              <el-radio-button label="0">菜单</el-radio-button>
              <!-- <el-radio-button label="1">整页</el-radio-button> -->
              <!-- <el-radio-button label="2">外链</el-radio-button> -->
            </el-radio-group>
          </el-form-item>
          <el-form-item label="菜单图标" prop="antdvIcon">
            <sc-icon-select v-model="form.antdvIcon"></sc-icon-select>
          </el-form-item>
          <el-form-item label="路由地址" prop="antdvRouter">
            <el-input
              v-model="form.antdvRouter"
              clearable
              placeholder=""
            ></el-input>
            <div class="el-form-item-msg">路由地址必须以`/`开头</div>
          </el-form-item>
          <el-form-item label="视图路径" prop="antdvComponent">
            <el-input v-model="form.antdvComponent" clearable placeholder="">
              <template #prepend>views/</template>
            </el-input>
            <div class="el-form-item-msg">
              不能有斜线`/`、中横线-
            </div>
          </el-form-item>
          <el-form-item label="菜单排序" prop="menuSort">
            <el-input
              v-model="form.menuSort"
              type="number"
              placeholder="请输入菜单排序"
            ></el-input>
          </el-form-item>
          <el-form-item label="是否可见" prop="isShow">
            <el-checkbox v-model="form.isShow">是</el-checkbox>
            <div class="el-form-item-msg">
              菜单不显示在导航中，但用户依然可以访问，例如详情页
            </div>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              @click="save"
              :loading="loading"
              :disabled="loading"
              >保 存</el-button
            >
          </el-form-item>
        </el-form>
      </el-col>
    </template>
  </el-row>
</template>

<script>
import api from "./server/api.js";
import scIconSelect from "@/scComponents/scIconSelect";
import { ElMessage } from "element-plus";

export default {
  components: {
    scIconSelect,
  },
  props: {
    menu: { type: Object, default: () => {} },
  },
  data() {
    return {
      hasShow: false,
      form: {
        antdvComponent: "",
        antdvRouter: "",
        antdvIcon: "",
        antdvLinkOpenType: 0,
        isShow: true,
        appCode: "",
        menuCode: "",
        menuName: "",
        menuParentId: "",
        menuSort: "",
        visible: "Y",
      },
      menuOptions: [],
      menuProps: {
        value: "title",
        label: "title",
        checkStrictly: true,
      },
      menuAppOptions: [],
      rules: {
        // menuParentId: [
        //   {
        //     required: true,
        //     type: "string",
        //     message: "请选择上级菜单",
        //     trigger: "blur",
        //   },
        // ],
        appCode: [
          {
            required: true,
            type: "string",
            message: "请选择所属应用",
            trigger: "blur",
          },
        ],
        menuCode: [
          {
            required: true,
            type: "string",
            message: "请输入菜单编号",
            trigger: "blur",
          },
          {
            pattern: /^[0-9a-zA-Z,.。，_-]*$/,
            message: "请输入英文或数字",
            trigger: "blur",
          },
          { min: 1, max: 30, message: "不能超过30个字符", trigger: "blur" },
        ],
        menuName: [
          {
            required: true,
            type: "string",
            message: "请输入菜单名",
            trigger: "blur",
          },
          {
            pattern: /^[0-9a-zA-Z一-龟,.。，]*$/,
            message: "不能输入特殊字符",
            trigger: "blur",
          },
          { min: 1, max: 30, message: "不能超过30个字符", trigger: "blur" },
        ],
        // antdvComponent: [
        //   {
        //     required: true,
        //     type: "string",
        //     message: "请输入视图路径",
        //     trigger: "blur",
        //   },
        //   {
        //     pattern: /^[0-9a-zA-Z/_]*$/,
        //     message: "请检查路径格式",
        //     trigger: "blur",
        //   },
        // ],
        // antdvRouter: [
        //   {
        //     required: true,
        //     type: "string",
        //     message: "请输入路由地址",
        //     trigger: "blur",
        //   },
        //   {
        //     pattern: /^[0-9a-zA-Z/]*$/,
        //     message: "请检查地址格式",
        //     trigger: "blur",
        //   },
        // ],
        menuSort: [
          {
            required: true,
            message: "请输入排序号",
            trigger: "blur",
          },
        ],
      },
      loading: false,
    };
  },
  watch: {
    menu: {
      handler() {
        this.menuOptions = this.treeToMap(this.menu);
      },
      deep: true,
    },
  },
  mounted() {
    this.getAppList();
  },
  methods: {
    // 获取所用应用列表
    async getAppList() {
      const res = await api.getAppList();
      if (res.code == "00000") {
        this.menuAppOptions = res.data;
      }
    },
    //简单化菜单
    treeToMap(tree) {
      const map = [];
      if (!Array.isArray(tree)) {
        return;
      }
      tree.forEach((item) => {
        var obj = {
          id: item.menuId,
          parentId: item.menuParentId,
          menuName: item.menuName,
          children:
            item.children && item.children.length > 0
              ? this.treeToMap(item.children)
              : null,
        };
        map.push(obj);
      });
      return map;
    },
    //保存
    async save() {
      this.$refs.dialogForm.validate(async (valid) => {
        if (valid) {
          this.loading = true;

          /**
           * 表单数据处理
           */
          // 是否可见
          this.form.visible = this.form.isShow ? "Y" : "N";
          setTimeout(() => {
            this.loading = false;
          }, 1500);
          if (this.form?.menuId) {
            this.form.antdvVisible = this.form.visible;
            const res = await api.editMenu(this.form);
            if (res.code == "00000") {
              ElMessage({
                type: "success",
                message: "保存成功",
              });
            }
          } else {
            const res = await api.addMenu(this.form);
            if (res.code == "00000") {
              this.$emit("success", this.form.menuName);
              ElMessage({
                type: "success",
                message: "保存成功",
              });
            }
          }
        }
      });
      // var res = await this.$API.demo.post.post(this.form);
      // if (res.code == 200) {
      //   this.$message.success("保存成功");
      // } else {
      //   this.$message.warning(res.message);
      // }
    },
    //表单注入数据
    setData(data, menuId, hasShow) {
      this.hasShow = hasShow;
      if (menuId) {
        this.form = data;
        // 子节点新增(有父节点新增及编辑两种分支)
        if (!data.antdvRouter) {
          //父节点新增
          this.form.antdvLinkOpenType = 0;
          this.form.isShow = true;
        } else {
          //编辑
          this.form.isShow = this.form.antdvVisible == "Y" ? true : false;
        }
        console.log(this.form);
        // 数据处理
        this.initRef();
      } else {
        //新增根节点
        this.form = {
          antdvComponent: "",
          antdvRouter: "",
          antdvIcon: "",
          antdvLinkOpenType: 0,
          isShow: true,
          appCode: "",
          menuCode: "",
          menuName: data?.menuName,
          menuSort: "",
          menuParentId: -1,
        };
      }
    },
    // 清除验证信息
    initRef() {
      if (this.$refs.dialogForm) {
        for (const item of [
          "menuName",
          "menuCode",
          "antdvComponent",
          "antdvRouter",
        ])
          this.$refs.dialogForm.clearValidate(item);
      }
    },
  },
};
</script>

<style scoped>
h2 {
  font-size: 17px;
  color: #3c4a54;
  padding: 0 0 30px 0;
}
.apilist {
  border-left: 1px solid #eee;
}

[data-theme="dark"] h2 {
  color: #fff;
}
[data-theme="dark"] .apilist {
  border-color: #434343;
}
</style>
