import request from "@/utils/network.js";
import { paramsType, role, roleIdType, setMenusRole, roleId, grantDataScopeData } from "./interface";

export default class CommonApi {

    static get(params: paramsType) {
        return request({
            url: `/api/sysRole/page`,
            method: 'get',
            params
        })
    }

    static addDictTree(data: role) {
        return request({
            url: `/api/sysRole/add`,
            method: 'post',
            data
        })
    }
    static editDictTree(data: role) {
        return request({
            url: `/api/sysRole/edit`,
            method: 'post',
            data
        })
    }
    static deleteDictTree(data: roleIdType) {
        return request({
            url: `/api/sysRole/delete`,
            method: 'post',
            data
        })
    }
    static menuAndButtonTreeChildrenV2(params: roleIdType) {
        return request({
            url: `/api/sysMenu/menuAndButtonTreeChildrenV2`,
            method: 'get',
            params
        })
    }
    static grantMenu(data: setMenusRole) {
        return request({
            url: `/api/sysRole/grantMenu`,
            method: 'post',
            data
        })
    }
    static getRangeData(params: roleId) {
        return request({
            url: `api/hrOrganization/roleBindOrgScopeAntdv`,
            method: 'get',
            params
        })
    }
    // 角色管理 -- 修改授权数据范围
    static grantDataScope(data: grantDataScopeData) {
        return request({
            url: 'api/sysRole/grantDataScope',
            method: 'post',
            data
        })
    }
}






