<template>
    <div>
        <el-dialog v-model="showDialog" :title="editId ? '编辑角色' : '新建角色'" @closed="close" width="30vw"
            :close-on-click-modal="false">
            <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px">
                <el-form-item label="角色名称: " prop="roleName" required>
                    <el-input v-model="form.roleName" :formatter="(value: string) => value.replace(/^\s+|\s+$/g, '')"
                        placeholder="请输入角色名称" />
                </el-form-item>
                <el-form-item label="角色编码: " prop="roleCode" required>
                    <el-input v-model="form.roleCode" :formatter="(value: string) => value.replace(/^\s+|\s+$/g, '')"
                        placeholder="请输入角色编码" />
                </el-form-item>
                <el-form-item label="排序号: " prop="roleSort" required>
                    <el-input-number placeholder="请输入排序号" style="text-align: left;width: 100%;" v-model="form.roleSort"
                        :min="5" :step="1" step-strictly controls-position="right" />
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="close">取消</el-button>
                    <el-button type="primary" @click="submitForm" :loading="submitLoading">
                        保存
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup lang="ts">
import {nextTick, reactive, ref, toRefs} from "vue";
import {role} from "../server/interface";
import type {FormInstance, FormRules} from 'element-plus';
import {ElMessage} from "element-plus";
import api from "../server/api";

const emits = defineEmits(['update:showDialog', "close"]);
const props = defineProps({
	showDialog: {
		type: Boolean,
		default: false
	},

}); // 表单
const editId = ref<string | undefined | null>('');
const { showDialog } = toRefs(props);
const ruleFormRef = ref<FormInstance | null | undefined>(null);
const submitLoading=ref(false);
const form = ref<role>({
    roleName: '',
    roleCode: '',
    roleSort: '',
});
const rules = reactive<FormRules>({
    roleName: [
        { required: true, message: '请输入角色名称', trigger: 'blur' },
    ],
    roleCode: [
        { required: true, message: '请输入角色编码', trigger: 'blur' },
    ],
    roleSort: [
        { required: true, message: '请输入排序号', trigger: ['change', 'blur'] },
    ],
})

const close = () => {
    editId.value = null;
    ruleFormRef.value?.resetFields();
    form.value.roleName = '';
    form.value.roleCode = '';
    form.value.roleSort = '';
    emits("update:showDialog", false);
}
const submitForm = async () => {
    ruleFormRef.value?.validate(async (valid, fields) => {
        if (valid) {
            let res;
			submitLoading.value=true;
            if (editId.value) {
                let obj = form.value;
                obj.roleId = editId.value;
                res = await api.editDictTree(obj);
            } else {
				res = await api.addDictTree(form.value);
            }
            if (res.success) {
                ElMessage.success('操作成功!');
                close()
                emits('close')
            }
            else {
                ElMessage.error(res.message)
            }
			submitLoading.value=false;
        } else {
            console.log('error submit!', fields)
        }
    })
}
const edit = (e: role) => {
    nextTick(() => {
		editId.value = e.roleId;
		delete e.roleId;
		form.value = JSON.parse(JSON.stringify(e))
		for (const i in form.value, e) {
			form.value[i] = e[i];
		}
		emits("update:showDialog", true);
	})
}
defineExpose({
    edit
})
</script>

<style scoped lang="scss">
::v-deep(.el-input-number .el-input__inner) {
    text-align: left;
}
</style>
