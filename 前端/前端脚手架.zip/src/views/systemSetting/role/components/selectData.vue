<template>
    <div>
        <el-dialog v-model="dialogVisible" title="授权范围" @closed="close" width="30vw" :close-on-click-modal="false">
            <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px">
                <el-form-item label="数据范围: " prop="dataRange" required>
                    <el-select v-model="form.dataRange" placeholder="请选择" @change="handleChangeData">
                        <el-option v-for="item in scopeData" :key="item.code" :label="item.name" :value="item.code" />
                    </el-select>
                </el-form-item>
                <el-form-item v-if="(form.dataRange == '40')" label="机构范围: " prop="classRange">
                    <el-tree v-loading="treeLoading" ref="treeRef" node-key="id" :default-expand-all="true"
                        show-checkbox :data="form.data" :default-checked-keys="selectedIds" :props="{
                            children: 'children',
                            label: 'name',
                        }"></el-tree>
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="close">取消</el-button>
                    <el-button v-loading="submitLoading" type="primary" @click="submitForm">
                        保存
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup lang="ts">
import { toRefs, ref, reactive, watch, onMounted } from "vue";
import { role, roleId } from "../server/interface";
import { FormInstance, FormRules, messageConfig } from 'element-plus';
import { ElMessage } from "element-plus";
import api from "../server/api";
import { isDayjs } from "dayjs";
const emits = defineEmits(['update:dialogVisible', "close"]);
const props = defineProps({
    dialogVisible: {
        type: Boolean,
        default: false
    },
    data: {
        type: Object,
        default: {}
    }

}); // 表单

interface Tree {
    label: string
    children?: Tree[],
    [props: string]: any
}

const { dialogVisible, data } = toRefs(props);
watch(() => props.data, (newValue, oldValue) => {
    if (newValue) {
        form.value.dataRange = newValue.dataScopeType
        if (form.value.dataRange == '40') {
            getGangeData(props.data.roleId)
        }
    }
});
const selectedIds = <any>ref([]);
const treeRef = ref();
const scopeData = [
    { code: 10, name: "仅本人数据" },
    { code: 20, name: "本部门数据" },
    { code: 30, name: "本部门及以下数据" },
    { code: 40, name: "指定部门数据" },
    { code: 50, name: "全部数据" },
]
const form = ref({
    dataRange: '',
    mechanism: '',
    selected: <never>[],
    data: []
});
const treeLoading = ref<boolean>(false);
const submitLoading = ref<boolean>(false);
const rules = reactive({
    dataRange: [
        { required: true, message: '请选择', trigger: 'blur' },
    ]
})
const close = () => {

    emits("update:dialogVisible", false);
}

//提交
const submitForm = async () => {
    submitLoading.value = true
    let ids: string[] = [];
    let arrs = treeRef.value?.getCheckedNodes();
    arrs?.forEach((it: { id: any; }) => ids.push(it.id))

    api.grantDataScope({
        roleId: props.data.roleId,
        grantOrgIdList: ids,
        dataScopeType: form.value.dataRange,
    }).then((res: { code: string; }) => {
        if (res && res.code == "00000") {
            ElMessage.success('修改成功!')
        }
        submitLoading.value = false
        close();
    }).catch(() => {
        submitLoading.value = false
    })
}

const handleChangeData = (e: string | number) => {
    if (e == 40) {
        getGangeData(props.data.roleId)
    }
}
const getGangeData = async (e: string) => {
    treeLoading.value = true;
    const res = await api.getRangeData({ roleId: e })
    form.value.data = res.data;
    selectedIds.value = getTreeData(res.data, []);
    treeLoading.value = false;
}
const getTreeData = (data: any[], arr: any[]) => {
    let ars: any[] = arr;
    data.forEach((it: { checked: any; id: any; children: any; }) => {
        if (it.checked) {
            ars.push(it.id);
        }
        if (it.children) {
            getTreeData(it.children, ars)
        }
    })
    console.log(ars);

    return ars;
}
</script>

<style scoped lang="scss">
::v-deep(.el-input-number .el-input__inner) {
    text-align: left;
}
</style>
