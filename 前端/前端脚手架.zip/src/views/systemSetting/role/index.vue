<template>
    <el-container>

        <el-header>
            <el-row :gutter="20" style="width: 100%;">
                <el-col :span="6">
                    <el-form-item label="角色名称: " style="margin-bottom: 0px;">
                        <el-input v-model="data.search.roleName" placeholder="角色名称" clearable></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="角色编码: " style="margin-bottom: 0px;">
                        <el-input v-model="data.search.roleCode" placeholder="角色编码" clearable></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-button type="primary" icon="el-icon-search" @click="handelSearch">搜索</el-button>
                    <el-button @click="reset">重置</el-button>
                    <el-button type="primary" icon="el-icon-plus" @click="() => { showDialog = true }">新建</el-button>
                </el-col>
            </el-row>
        </el-header>

        <el-main class="nopadding">


            <scTable ref="table" @selection-change="selectionChange" :apiObj="data.apiObj" :params="data.search"
                :data="data.dataTable" row-key="id">
                <el-table-column type="index" width="50" align="center"></el-table-column>
                <el-table-column label="角色名称" prop="roleName" align="center"></el-table-column>
                <el-table-column label="角色编码" prop="roleCode" align="center"></el-table-column>
                <el-table-column label="数据范围" prop="dataScopeType" align="center"></el-table-column>
                <el-table-column label="排序" prop="roleSort" sortable align="center"></el-table-column>
                <el-table-column label="操作" fixed="right" align="left">
                    <template #default="scope">
                        <el-button-group style="display: flex;align-content: center">
                            <el-button v-fixedRole="scope.row.roleCode" text type="warning" size="small"
                                @click="table_edit(scope.row)">编辑
                            </el-button>
                            <el-popconfirm title="确定删除吗？" @confirm="table_del(scope.row,scope.row.delLoading=true)">
                                <template #reference>
                                    <el-button :loading="scope.row.delLoading" v-fixedRole="scope.row.roleCode" text type="danger"
                                        size="small">删除</el-button>
                                </template>
                            </el-popconfirm>
                            <el-dropdown
                                @command="(command: string | number | object) => handleCommand(command, scope.row)">
                                <span class="el-dropdown-link">
                                    <el-button text size="small" type="primary">
                                        更多<el-icon class="el-icon--right">
                                            <ArrowDown />
                                        </el-icon>
                                    </el-button>
                                    <!-- <el-icon class="el-icon--right">
                                        <arrow-down />
                                    </el-icon> -->
                                </span>
                                <template #dropdown>
                                    <el-dropdown-menu>
                                        <el-dropdown-item command="edit_menu">授权菜单</el-dropdown-item>
                                        <!-- <el-dropdown-item command="edit_api">授权接口</el-dropdown-item> -->
                                        <el-dropdown-item command="edit_data">授权范围</el-dropdown-item>
                                    </el-dropdown-menu>
                                </template>
                            </el-dropdown>
                        </el-button-group>
                    </template>
                </el-table-column>
            </scTable>
        </el-main>
    </el-container>

    <el-drawer v-model="drawerTree" :with-header="false" @close="closeDrawer">
        <el-container style="padding:20px 20px 40px 40px;" v-loading="treeLoading">
            <el-tree ref="menu" class="menu" highlight-current node-key="id" default-expand-all show-checkbox
                :data="menuList" :props="menuProps" :default-checked-keys="selectionTreeId" @check="handleChangeTree"
                check-strictly :expand-on-click-node="false">
            </el-tree>
        </el-container>
    </el-drawer>
    <AddRole ref="addRoleRef" v-model:showDialog="showDialog" @close="handelSearch" />

    <SelectData ref="addRoleRefs" v-model:dialogVisible="dialogVisible" :data="selectData" />
</template>


<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue';
import { paramsType, roleIdType, menuProps as menuPropsType, table_item, dataFrom, treeItemChildren } from "./server/interface";
import CommonApi from "./server/api";
import { ElMessage } from "element-plus";
import AddRole from './components/addRole.vue';
import { ArrowDown } from '@element-plus/icons-vue';
import SelectData from './components/selectData.vue';

const table = ref<any>(null);
const treeLoading = ref<boolean>(false);
const showDialog = ref<boolean>(false);
const dialogVisible = ref<boolean>(false);
const addRoleRef = ref<null | undefined | any>(null);
const selectData = ref<table_item | any>(null);

const data = reactive<dataFrom>({
    dataTable: [],
    search: {
        roleName: "",
        roleCode: '',
    },
    apiObj: CommonApi.get,
    selectionTable: [],
})
const menuList = ref<any>(null);
const selectionTreeId = ref<string[]>([]);
const roleId = ref<string>('');
const drawerTree = ref(false);
const menuProps = ref<menuPropsType | undefined>({
    label: "name",
    children: 'children',
})
onMounted(() => {
    // handelSearch();
})
const reset = () => {
    data.search.roleName = '';
    data.search.roleCode = '';
    handelSearch();
}

const handelSearch = async () => {
    table.value?.refresh();
}
const handleCommand = (command: string | number | object, row: table_item) => {
    console.log(command);
    switch (command) {
        case 'edit_menu':
            edit_menu(row)
            break;
        case 'edit_api':
            edit_api(row)
            break;
        case 'edit_data':
            edit_data(row)
            break;
    }
}
// 数据范围
const edit_data = async (e: table_item) => {
    console.log(e);

    selectData.value = JSON.parse(JSON.stringify(e));
    dialogVisible.value = true;
}
// 授权接口
const edit_api = async (e: table_item) => {
    const res = await CommonApi.menuAndButtonTreeChildrenV2({ roleId: e.roleId })
    nextTick(() => {
        menuList.value = res.data;
        roleId.value = e.roleId
        selectedTree(menuList.value);
    })
}
const selectionChange = (e: table_item[]) => {
    data.selectionTable = e;
}
const table_edit = (e: table_item) => {
    let obj = {
        roleCode: e.roleCode,
        roleId: e.roleId,
        roleName: e.roleName,
        roleSort: e.roleSort
    }
    addRoleRef.value.edit(JSON.parse(JSON.stringify(obj)))
}
const table_del = async (e: table_item,b:Boolean) => {
    const res = await CommonApi.deleteDictTree({ roleId: e.roleId })
    if (res) {
		await 	handelSearch()
        ElMessage.success('删除成功!')
    }else {
		await 	handelSearch();
		ElMessage.error(res.message)
	}
}
const edit_menu = async (e: table_item) => {
    drawerTree.value = true;
    treeLoading.value = true;
    selectionTreeId.value = [];
    const res = await CommonApi.menuAndButtonTreeChildrenV2({ roleId: e.roleId })
    nextTick(() => {
        menuList.value = res?.data;
        roleId.value = e.roleId
        selectedTree(menuList.value);
    })
}

const selectedTree = (menuList: treeItemChildren) => {
    menuList.forEach((item: treeItemChildren) => {
        if (item.checked === true) {
            selectionTreeId.value?.push(item.id)
        }
        if (item.children && item.children.length != 0) {
            selectedTree(item.children);
        }
    })
    treeLoading.value = false;
}
const closeDrawer = () => {
    menuList.value = [];
    selectionTreeId.value = [];
    roleId.value = '';
}
const handleChangeTree = async (e: treeItemChildren, v: boolean) => {
    const res = await CommonApi.grantMenu({ roleId: roleId.value, grantAddMenuFlag: !e.checked, grantMenuId: e.id });
    if (res.success) {
        ElMessage.success('配置菜单成功!')
        edit_menu({
            roleId: roleId.value
        })
    } else {
        ElMessage.error('配置菜单失败!')
    }
}
</script>

<style scoped lang="scss">
.el-dropdown-link {
    cursor: pointer;
    color: var(--el-color-primary);
    display: flex;
    align-items: center;
}
</style>
