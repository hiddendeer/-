<template>
  <el-dialog
    :title="titleMap[mode]"
    v-model="visible"
    width="35%"
    destroy-on-close
    @closed="$emit('closed')"
  >
    <el-form
      :model="form"
      :rules="rules"
      ref="dialogForm"
      label-width="100px"
      label-position="left"
    >
      <el-form-item label="字典项名称" prop="dictName">
        <el-input v-model="form.dictName"></el-input>
      </el-form-item>
      <el-form-item label="字典项编码" prop="dictCode">
        <el-input
          v-model="form.dictCode"
          :disabled="mode == `edit` ? true : false"
        ></el-input>
      </el-form-item>
      <el-form-item label="字典项排序" prop="dictSort">
        <el-input v-model="form.dictSort" type="number"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取 消</el-button>
      <el-button type="primary" :loading="isSaveing" @click="submit()"
        >保 存</el-button
      >
    </template>
  </el-dialog>
</template>

<script>
import api from "./server/api.js";
export default {
  emits: ["success", "closed"],
  data() {
    return {
      mode: "add",
      titleMap: {
        add: "新增项",
        edit: "编辑项",
      },
      visible: false,
      isSaveing: false,
      form: {
        dictName: "",
        dictCode: "",
        dictSort: "",
        dictTypeCode: "",
      },
      rules: {
        dictName: [
          { required: true, message: "请输入字典项名称" },
          {
            pattern: /^[0-9a-zA-Z一-龟,.。，]*$/,
            message: "不能输入特殊字符",
            trigger: "blur",
          },
          { min: 1, max: 10, message: "不能超过10个字符", trigger: "blur" },
        ],
        dictCode: [
          { required: true, message: "请输入字典项编码" },
          { min: 1, max: 10, message: "不能超过10个字符", trigger: "blur" },
          {
            pattern: /^[0-9a-zA-Z,.。，]*$/,
            message: "请输入英文或数字",
            trigger: "change",
          },
        ],
        dictSort: [{ required: true, message: "请输入字典项排序" }],
      },
      dic: [],
      dicProps: {
        value: "id",
        label: "name",
        emitPath: false,
        checkStrictly: true,
      },
    };
  },
  mounted() {
    if (this.params) {
      this.form.dic = this.params.code;
    }
    // this.getDic()
  },
  methods: {
    //显示
    open(mode = "add") {
      this.mode = mode;
      this.visible = true;
      return this;
    },
    // //获取字典列表
    // async getDic(){
    // 	var res = await this.$API.system.dic.tree.get();
    // 	this.dic = res.data;
    // },
    //表单提交方法
    submit() {
      this.$refs.dialogForm.validate(async (valid) => {
        if (valid) {
          this.isSaveing = true;
          // var res = await this.$API.demo.post.post(this.form);
          if (this.mode == "add") {
            const res = await api.addDictChild(this.form);
            if (res.code == "00000") {
              this.$emit("success", this.form, this.mode);
              this.visible = false;
              this.$message.success("新增成功");
            } else {
              this.$alert(res.message, "提示", { type: "error" });
            }
          } else {
            const res = await api.editDictChild(this.form);
            if (res.code == "00000") {
              this.$emit("success", this.form, this.mode);
              this.visible = false;
              this.$message.success("编辑成功");
            } else {
              this.$alert(res.message, "提示", { type: "error" });
            }
          }
          this.isSaveing = false;
        }
      });
    },
    //表单注入数据
    setData(dictTypeCode, row = {}) {
      console.log(row);
      console.log(this.form);
      if (this.mode == "edit") {
        this.form.dictName = row?.dictName;
        this.form.dictCode = row?.dictCode;
        this.form.dictSort = row?.dictSort;
        this.form.dictId = row?.dictId;
        this.form.dictTypeCode = dictTypeCode;
      } else {
        this.form.dictTypeCode = dictTypeCode;
      }
    },
  },
};
</script>

<style>
</style>
