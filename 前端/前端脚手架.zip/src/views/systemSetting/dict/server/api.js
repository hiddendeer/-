import request from "@/utils/network.js";
export default class CommonApi {
    static getDictTree(params) {
        return request({
            url: `/api/dictType/page`,
            method: 'get',
            params
        })
    }
    static addDictTree(data) {
        return request({
            url: `/api/dictType/add`,
            method: 'post',
            data
        })
    }
    static deleteDictTree(data) {
        return request({
            url: `/api/dictType/delete`,
            method: 'post',
            data
        })
    }

    static getDictChild(params) {
        return request({
            url: `/api/dict/page`,
            method: 'get',
            params
        })
    }
    static addDictChild(data) {
        return request({
            url: `/api/dict/add`,
            method: 'post',
            data
        })
    }
    static editDictChild(data) {
        return request({
            url: `/api/dict/edit`,
            method: 'post',
            data
        })
    }
    static deleteDictChild(data) {
        return request({
            url: `/api/dict/delete`,
            method: 'post',
            data
        })
    }


}