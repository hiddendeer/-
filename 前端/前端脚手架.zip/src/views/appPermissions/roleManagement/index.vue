<template>
	<el-container>
		<el-header>
			<div
				style="
					width: 100%;
					height: 100%;
					display: flex;
					justify-content: space-between;
					align-items: center;
				"
			>
				<div class="left-panel">
					<el-button
						type="primary"
						icon="el-icon-plus"
						@click="
							() => {
								showDialog = true;
							}
						"
					>
						新建
					</el-button>
					<el-form-item
						label="角色名称: "
						label-width="120"
						style="margin-bottom: 0px"
					>
						<el-input
							v-model="data.search.roleName"
							placeholder="角色名称"
							clearable
						></el-input>
					</el-form-item>
					<el-form-item
						label="角色编码: "
						label-width="120"
						style="margin-bottom: 0px"
					>
						<el-input
							v-model="data.search.roleCode"
							placeholder="角色编码"
							clearable
						></el-input>
					</el-form-item>
				</div>
				<div class="right-panel">
					<el-button
						type="primary"
						icon="el-icon-search"
						@click="handelSearch"
						>搜索</el-button
					>
					<el-button @click="reset">重置</el-button>
				</div>
			</div>
		</el-header>

		<el-main class="nopadding">
			<scTable
				ref="table"
				@selection-change="selectionChange"
				:apiObj="data.apiObj"
				:params="data.search"
				:data="data.dataTable"
				row-key="id"
			>
				<el-table-column
					type="index"
					width="50"
					align="center"
				></el-table-column>
				<el-table-column
					label="角色名称"
					prop="roleName"
					align="center"
				></el-table-column>
				<el-table-column
					label="角色编码"
					prop="roleCode"
					align="center"
				></el-table-column>
				<el-table-column
					label="数据范围"
					prop="dataScopeType"
					align="center"
				></el-table-column>
				<el-table-column
					label="排序"
					prop="roleSort"
					sortable
					align="center"
				></el-table-column>
				<el-table-column label="操作" fixed="right" align="center">
					<template #default="scope">
						<el-button-group>
							<el-button
								text
								type="warning"
								size="small"
								@click="table_edit(scope.row)"
								>编辑</el-button
							>
							<el-popconfirm
								title="确定删除吗？"
								@confirm="table_del(scope.row)"
							>
								<template #reference>
									<el-button text type="danger" size="small"
										>删除</el-button
									>
								</template>
							</el-popconfirm>
							<!-- 更多下拉 -->
							<el-dropdown trigger="click">
								<div>
									<el-button text type="primary" size="small">
										更多
										<el-icon class="el-icon--right"
											><el-icon-arrow-down
										/></el-icon>
									</el-button>
								</div>
								<template #dropdown>
									<el-dropdown-menu>
										<el-dropdown-item>
											<el-button
												text
												size="small"
												@click="edit_menu(scope.row)"
												>授权菜单</el-button
											>
										</el-dropdown-item>
										<el-dropdown-item>
											<el-button
												text
												size="small"
												@click="
													set_insideData(scope.row)
												"
												>授权内部数据</el-button
											>
										</el-dropdown-item>
										<el-dropdown-item>
											<el-button
												text
												size="small"
												@click="
													set_outSideData(scope.row)
												"
												>授权外部数据</el-button
											>
										</el-dropdown-item>
									</el-dropdown-menu>
								</template>
							</el-dropdown>
						</el-button-group>
					</template>
				</el-table-column>
			</scTable>
		</el-main>
	</el-container>
	<!-- 授权菜单树 抽屉 -->
	<el-drawer v-model="drawerTree" :with-header="false" @close="closeDrawer">
		<el-container style="padding: 20px 20px 40px 40px">
			<el-tree
				ref="menu"
				class="menu"
				highlight-current
				node-key="id"
				default-expand-all
				show-checkbox
				:data="menuList"
				:props="menuProps"
				:default-checked-keys="selectionTreeId"
				@check="handleChangeTree"
				check-strictly
				:expand-on-click-node="false"
			></el-tree>
		</el-container>
	</el-drawer>
	<!-- 新增编辑角色弹窗组件 -->
	<AddRole
		ref="addRoleRef"
		v-model:showDialog="showDialog"
		@close="handelSearch"
	/>
	<!-- 授权内部数据弹窗 -->
	<el-dialog
		v-model="insideDataWindow"
		:close-on-click-modal="false"
		width="40%"
		@closed="insideClose(insideRef)"
	>
		<template #header>
			<h1>授权内部数据范围</h1>
		</template>
		<el-form
			ref="insideRef"
			:model="insideForm"
			:rules="insideRules"
			label-width="140px"
			v-if="insideDataWindow"
		>
			<el-form-item label="数据范围：" prop="dataGround">
				<el-select
					v-model="insideForm.dataGround"
					clearable
					placeholder="请选择数据范围"
					@change="dataGroundChange"
				>
					<el-option
						v-for="item in scopeData"
						:key="item.dictCode"
						:label="item.dictName"
						:value="item.dictCode"
					/>
				</el-select>
			</el-form-item>
			<el-form-item
				label="部门范围："
				v-if="insideForm.dataGround == 'DATA_SPOCE_ZDBMSJ'"
			>
				<div class="setTreeSty">
					<div class="setTreeSty_left">
						<el-container>
							<el-main class="nopadding">
								<el-tree
									ref="groupRefLeft"
									class="menu"
									node-key="value"
									:data="groupDataLeft"
									highlight-current
									auto-expand-parent
									:props="defaultPropsLeft"
									:default-expand-all="true"
									:expand-on-click-node="false"
									@node-click="groupClickLeft"
								>
								</el-tree>
							</el-main>
						</el-container>
					</div>
					<div class="setTreeSty_right">
						<el-container>
							<el-main class="nopadding">
								<el-tree
									ref="groupRefRight"
									class="menu"
									node-key="orgId"
									:data="groupDataRight"
									highlight-current
									auto-expand-parent
									show-checkbox
									:props="defaultPropsRight"
									:default-expand-all="true"
									:expand-on-click-node="false"
									:default-checked-keys="defaultCheckedKeys"
									@check="groupClickRight"
								>
								</el-tree>
							</el-main>
						</el-container>
					</div>
				</div>
			</el-form-item>
			<el-form-item label="编辑删除权限：" prop="deleteAuth">
				<el-radio-group v-model="insideForm.deleteAuth">
					<el-radio
						:label="haveUpdateData[0].dictCode"
						size="small"
						>{{ haveUpdateData[0].dictName }}</el-radio
					>
					<el-radio
						:label="haveUpdateData[1].dictCode"
						size="small"
						:disabled="insideForm.dataGround == 'DATA_SPOCE_JBRSJ'"
						>{{ haveUpdateData[1].dictName }}</el-radio
					>
				</el-radio-group>
			</el-form-item>
		</el-form>
		<template #footer>
			<div class="dialog-footer">
				<el-button @click="insideClose(insideRef)">取消</el-button>
				<el-button type="primary" @click="insideSubmitForm(insideRef)"
					>确认</el-button
				>
			</div>
		</template>
	</el-dialog>
	<!-- 授权外部数据弹窗 -->
	<el-dialog
		v-model="outsideDataWindow"
		:close-on-click-modal="false"
		@closed="externalClose"
		width="40%"
		top="5%"
	>
		<template #header>
			<h1>授权外部数据范围</h1>
		</template>
		<el-form ref="externalRef" :model="outsideDataForm" label-width="140px">
			<el-form-item label="外部数据内容：" prop="outsideDataContent">
				<el-checkbox-group v-model="outsideDataForm.outsideDataContent">
					<el-checkbox
						v-for="item in externalList"
						:label="item.value"
						:key="item.value"
						@change="externalDateContent"
					>
						{{ item.label }}
					</el-checkbox>
				</el-checkbox-group>
			</el-form-item>
			<template v-if="outsideDataShow">
				<el-form-item label="外部数据范围：" prop="outsideDataScope">
					<el-checkbox-group
						v-model="outsideDataForm.outsideDataScope"
					>
						<el-checkbox
							v-for="item in rangeList"
							:label="item.value"
							:key="item.value"
						>
							{{ item.label }}
						</el-checkbox>
					</el-checkbox-group>
				</el-form-item>
				<el-form-item
					label="监管单位："
					prop="regulatoryUnit"
					v-if="
						!outsideDataForm.outsideDataScope.length ||
						outsideDataForm.outsideDataScope.includes(
							rangeList[0].value
						)
					"
				>
					<el-main class="nopadding unitSupervision">
						<el-tree
							ref="supervisionRef"
							class="menu"
							node-key="value"
							:data="groupDataLeft"
							highlight-current
							auto-expand-parent
							show-checkbox
							:props="defaultPropsLeft"
							:default-expand-all="true"
							:expand-on-click-node="false"
							:default-checked-keys="
								outsideDataForm.regulatoryUnit
							"
							@check="groupSupervision"
						>
						</el-tree>
					</el-main>
				</el-form-item>
				<el-form-item
					label="行业："
					prop="industry"
					v-if="
						!outsideDataForm.outsideDataScope.length ||
						outsideDataForm.outsideDataScope.includes(
							rangeList[1].value
						)
					"
				>
					<el-select
						v-model="outsideDataForm.industry"
						placeholder="请选择行业"
						class="w-full"
						multiple
						collapse-tags
					>
						<el-option
							v-for="i in industryList"
							:key="i.value"
							:label="i.label"
							:value="i.value"
						/>
					</el-select>
				</el-form-item>
				<el-form-item
					label="国民经济分类："
					prop="entNature"
					v-if="
						!outsideDataForm.outsideDataScope.length ||
						outsideDataForm.outsideDataScope.includes(
							rangeList[2].value
						)
					"
				>
					<el-select
						v-model="outsideDataForm.entNature"
						placeholder="请选择国民经济分类"
						class="w-full"
						multiple
						collapse-tags
					>
						<el-option
							v-for="i in economicClassification"
							:key="i.value"
							:label="i.label"
							:value="i.value"
						/>
					</el-select>
				</el-form-item>
				<el-form-item
					label="风险标签："
					prop="entRiskTag"
					v-if="
						!outsideDataForm.outsideDataScope.length ||
						outsideDataForm.outsideDataScope.includes(
							rangeList[3].value
						)
					"
				>
					<div class="riskLabel">
						<el-checkbox-group v-model="outsideDataForm.entRiskTag">
							<el-checkbox
								v-for="item in riskLabelList"
								:label="item.value"
								:key="item.value"
							>
								{{ item.label }}
							</el-checkbox>
						</el-checkbox-group>
					</div>
				</el-form-item>
			</template>
		</el-form>
		<template #footer>
			<div class="dialog-footer">
				<el-button @click="externalClose(externalRef)">取消</el-button>
				<el-button
					type="primary"
					@click="externalSubmitForm(externalRef)"
					>确认</el-button
				>
			</div>
		</template>
	</el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick, watch } from "vue";
import {
	menuProps as menuPropsType,
	table_item,
	dataFrom,
	treeItemChildren,
} from "./server/interface";
import { Edit } from "@element-plus/icons-vue";
import CommonApi from "./server/api";
import { ElMessage } from "element-plus";
import AddRole from "./components/addRole.vue";

const table = ref<any>(null);
const showDialog = ref<boolean>(false);
const addRoleRef = ref<null | undefined | any>(null);
const data = reactive<dataFrom>({
	dataTable: [],
	search: {
		roleName: "",
		roleCode: "",
	},
	apiObj: CommonApi.get,
	selectionTable: [],
});

const menuList = ref<any>(null);
const selectionTreeId = ref<string[]>([]);
const defaultCheckedKeys = ref<string[]>([]);
const roleId = ref<string>("");
const drawerTree = ref(false);
const menuProps = ref<menuPropsType | undefined>({
	label: "name",
	children: "children",
});
const handelSearch = async () => {
	table.value?.refresh();
};

const selectionChange = (e: table_item[]) => {
	data.selectionTable = e;
};
const table_edit = (e: table_item) => {
	let obj = {
		roleCode: e.roleCode,
		roleId: e.roleId,
		roleName: e.roleName,
		roleSort: e.roleSort,
	};
	addRoleRef.value.edit(JSON.parse(JSON.stringify(obj)));
};
const table_del = async (e: table_item) => {
	const res = await CommonApi.deleteDictTree({ roleId: e.roleId });
	if (res) {
		ElMessage.success("删除成功!");
		handelSearch();
	}
};
const edit_menu = async (e: table_item) => {
	const res = await CommonApi.menuAndButtonTreeChildrenV2({
		roleId: e.roleId,
	});
	nextTick(() => {
		menuList.value = res.data;
		roleId.value = e.roleId;
		selectedTree(menuList.value);
	});
};

const selectedTree = (menuList: treeItemChildren) => {
	menuList.forEach((item: treeItemChildren) => {
		if (item.checked === true) {
			selectionTreeId.value?.push(item.id);
		}
		if (item.children && item.children.length != 0) {
			selectedTree(item.children);
		}
	});
	drawerTree.value = true;
};

const closeDrawer = () => {
	menuList.value = [];
	selectionTreeId.value = [];
	roleId.value = "";
};
const handleChangeTree = async (e: treeItemChildren, v: boolean) => {
	const res = await CommonApi.grantMenu({
		roleId: roleId.value,
		grantAddMenuFlag: !e.checked,
		grantMenuId: e.id,
	});
	if (res.success) {
		ElMessage.success("配置菜单成功!");
	}
};
// 重置按钮
const reset = () => {
	data.search.roleName = "";
	data.search.roleCode = "";
	handelSearch();
};
// 。。。。。。。。。。内部数据。。。。。。。。。。
// 内部数据弹窗标识
let insideDataWindow = ref<boolean>(false);
// 内部数据表单ref
let insideRef = ref<null>(null);
// 内部数据表单初始化
let insideForm = ref<table_item>({
	dataGround: "",
	deleteAuth: "",
});
//外部数据
let externalRef = ref<null>(null);
//外部数据内容
let outsideDataForm = ref<table_item>({
	outsideDataContent: [],
	outsideDataScope: [],
	regulatoryUnit: [],
	industry: [],
	entNature: [],
	entRiskTag: [],
});
//地区树
let groupDataLeft = ref<Array<object>>([]);
let groupDataRight = ref<Array<object>>([]);
let groupRefLeft = ref<null>(null);
let groupRefRight = ref<null>(null);
let supervisionRef = ref<null>(null);

//已选择部门数据
let departmentList = ref<any>([]);
// 行政区树格式
const defaultPropsLeft = ref<object>({
	label: "label",
	value: "value",
});
// 部门区树格式
const defaultPropsRight = ref<object>({
	label: "orgName",
	value: "orgId",
	checkStrictly: true,
});
let leftTreeObj = reactive<any>({});
//返现树组
let rightTreeId = ref<any>([]);

//外部数据内容数组
let externalList = ref<Array<object>>([
	{
		label: "企业",
		value: "ENTERPRISE",
	},
	{
		label: "机构",
		value: "MECHANISM",
	},
]);
//外部数据范围列表
let rangeList = ref<Array<object>>([
	{
		label: "监管单位",
		value: "regulatoryUnit",
	},
	{
		label: "行业",
		value: "industry",
	},
	{
		label: "国民经济分类",
		value: "entNature",
	},
	{
		label: "风险标签",
		value: "entRiskTag",
	},
]);
//行业列表
let industryList = ref<Array<object>>([]);
//经济分类
let economicClassification = ref<Array<object>>([]);
//风险标签
let riskLabelList = ref<Array<object>>([]);

//勾选企业底部显隐
let outsideDataShow = ref<boolean>(false);

// 内部数据表单校验规则
let insideRules = ref({
	dataGround: [
		{
			required: true,
			message: "请选择数据范围",
			trigger: ["change", "blur"],
		},
	],
	deleteAuth: [
		{
			required: true,
			message: "请选择编辑删除权限",
			trigger: ["change", "blur"],
		},
	],
});
// 内部数据范围定义
let scopeData = ref<Array<object>>([]);
// 编辑权限列表
let haveUpdateData = ref<Array<object>>([]);
// 授权内部数据按钮
const set_insideData = (data: any) => {
	insideDataWindow.value = true;
	roleId.value = data.roleId;
	CommonApi.getRoleDataDetails({ roleId: data.roleId }).then((res: any) => {
		if (res.code == "00000") {
			insideForm.value.dataGround = res.data.dataScope;
			insideForm.value.deleteAuth = res.data.haveUpdate;
			defaultCheckedKeys.value = res.data.orgIds;
			leftTreeObj = res.data.orgObject||{};
		}
	});
};
// 内部数据弹窗取消按钮
const insideClose = (formEl: any) => {
	if (!formEl) return;
	formEl.resetFields();
	groupDataRight.value = [];
	roleId.value = "";
	insideDataWindow.value = false;
};
// 新增/编辑弹窗保存
const insideSubmitForm = (formEl: any) => {
	if (!formEl) return;
	formEl.validate((valid: boolean) => {
		if (valid) {
			CommonApi.operateDataScope({
				roleId: roleId.value,
				dataScope: insideForm.value.dataGround,
				haveUpdate: insideForm.value.deleteAuth,
				orgIds: departmentList.value,
			}).then((res: any) => {
				if (res.code == "00000") {
					ElMessage.success("操作成功!");
					groupDataRight.value = [];
					handelSearch();
					insideRef.value.resetFields();
					insideDataWindow.value = false;
				}
			});
		} else {
			console.log("error submit!");
			return false;
		}
	});
};
// 内部数据范围变化回调
const dataGroundChange = () => {
	if (insideForm.value.dataGround == "DATA_SPOCE_JBRSJ") {
		insideForm.value.deleteAuth = haveUpdateData.value[0].dictCode;
	} else {
		departmentList.value = [];
	}
};
// 。。。。。。。。。。外部数据。。。。。。。。。。
// 外部部数据弹窗标识
let outsideDataWindow = ref<boolean>(false);
// 授权外部数据按钮
const set_outSideData = (data: object) => {
	getAreaTree();
	outsideDataWindow.value = true;
	roleId.value = data.roleId;
	CommonApi.getRoleDataDetails({ roleId: data.roleId }).then((res: any) => {
		if (res.code == "00000") {
			outsideDataForm.value.outsideDataContent =
				res.data.outsideDataContent == null
					? []
					: res.data.outsideDataContent;
			outsideDataShow.value =
				outsideDataForm.value.outsideDataContent.includes(
					externalList.value[0].value
				);
			outsideDataForm.value.outsideDataScope =
				res.data.outsideDataScope == null
					? []
					: res.data.outsideDataScope;
			outsideDataForm.value.regulatoryUnit =
				res.data.regulatoryUnit == null ? [] : res.data.regulatoryUnit;
			outsideDataForm.value.industry =
				res.data.industry == null ? [] : res.data.industry;
			outsideDataForm.value.entNature =
				res.data.entNature == null ? [] : res.data.entNature;
			outsideDataForm.value.entRiskTag =
				res.data.entRiskTag == null ? [] : res.data.entRiskTag;
		}
	});
};
// 获取行政区数据
const getAreaTree = () => {
	CommonApi.sysAreaTree().then((res: any) => {
		if (res.code == "00000") {
			groupDataLeft.value = res.data;
		} else {
			console.log(res.message);
		}
	});
};

//树点击事件左侧
const groupClickLeft = (data: any) => {
	if(leftTreeObj){
	if (!Reflect.has(leftTreeObj, data?.value)) {
		leftTreeObj[data.value] = [];
	}
	defaultCheckedKeys.value = leftTreeObj[data.value];
	}
	getOrganizationTree(data.value);
};
//获取部门树
const getOrganizationTree = async (val: any) => {
	let saDetail = await CommonApi.organizationTree({ orgRegulatoryUnit: val });
	groupDataRight.value = saDetail.data;
};
//树点击事件右侧
const groupClickRight = (data: any) => {
	leftTreeObj[data.orgRegulatoryUnit] = groupRefRight.value.getCheckedKeys();
	departmentList.value = Object.values(leftTreeObj).flat(Infinity);
};

//角色外部数据范围
const groupSupervision = () => {
	outsideDataForm.value.regulatoryUnit =
	supervisionRef.value.getCheckedKeys();
};
//选择外部数据内容
const externalDateContent = () => {
	outsideDataShow.value = outsideDataForm.value.outsideDataContent.includes(
		externalList.value[0].value
	);
};
//外部取消
const externalClose = (val: any) => {
	outsideDataWindow.value = false;
	supervisionRef.value?.setCheckedKeys([]);
};
//外部确认
const externalSubmitForm = () => {
	if (outsideDataForm.value.outsideDataScope.length > 0) {
		outsideDataForm.value.regulatoryUnit =
			outsideDataForm.value.outsideDataScope.includes(
				rangeList.value[0].value
			)
				? outsideDataForm.value.regulatoryUnit
				: [];

		outsideDataForm.value.industry =
			outsideDataForm.value.outsideDataScope.includes(
				rangeList.value[1].value
			)
				? outsideDataForm.value.industry
				: [];

		outsideDataForm.value.entNature =
			outsideDataForm.value.outsideDataScope.includes(
				rangeList.value[2].value
			)
				? outsideDataForm.value.entNature
				: [];

		outsideDataForm.value.entRiskTag =
			outsideDataForm.value.outsideDataScope.includes(
				rangeList.value[3].value
			)
				? outsideDataForm.value.entRiskTag
				: [];
	}
	CommonApi.operateDataScope({
		roleId: roleId.value,
		...outsideDataForm.value,
	}).then((res: any) => {
		if (res.code == "00000") {
			ElMessage.success("操作成功!");
			handelSearch();
			groupDataLeft.value = [];
			outsideDataWindow.value = false;
		}
	});
};
// 获取查询条件字典
const getDictData = () => {
	CommonApi.dictionaryDate({ dictTypeCode: "ROLE_DATA_SPOCE" }).then(
		(res: any) => {
			if (res.code == "00000") {
				scopeData.value = res.data.rows;
			} else {
				scopeData.value = [];
			}
		}
	);
	CommonApi.dictionaryDate({ dictTypeCode: "ROLE_DATA_OPERATE" }).then(
		(res: any) => {
			if (res.code == "00000") {
				haveUpdateData.value = res.data.rows;
			} else {
				haveUpdateData.value = [];
			}
		}
	);
	CommonApi.dictProject({ dictTypeCode: "GMJJFL" }).then((res: any) => {
		if (res.code == "00000") {
			economicClassification.value = res.data;
		} else {
			economicClassification.value = [];
		}
	});
	CommonApi.dictProject(
		{ dictTypeCode: "QYJBXX", dictCode: "QYJBXX_HYLB" },
		{ headers: { EnterpriseType: "ENTERPRISE" } }
	).then((res: any) => {
		if (res.code == "00000") {
			industryList.value = res.data;
		} else {
			industryList.value = [];
		}
	});
	CommonApi.dictProjectRisk({ dictTypeCode: "QYFXBQ" }).then((res: any) => {
		if (res.code == "00000") {
			riskLabelList.value = res.data;
		} else {
			riskLabelList.value = [];
		}
	});
};
onMounted(() => {
	handelSearch();
	getAreaTree();
	getDictData();
});
</script>

<style scoped lang="scss">
.tagList {
	width: 100%;
	height: 10vh;
	border-radius: 0px 4px 4px 0px;
	border: 1px solid #dcdfe6;
	background: #ffffff;
}
.setTreeSty {
	display: flex;
	&_left {
		width: 13vw;
		border-right: 1px solid #eaeaea;
		max-height: 44vh;
	}
	&_right {
		width: 13vw;
		max-height: 44vh;
	}
}
.unitSupervision {
	max-height: 200px;
}
.riskLabel {
	max-height: 200px;
	overflow-y: scroll;
}
</style>
