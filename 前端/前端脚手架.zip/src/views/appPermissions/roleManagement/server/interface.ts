export interface paramsType {
  roleName?: string
  roleCode?: string
  pageNo: number
  pageSize: number
}
// get接口请求参数
export interface paramType {
  pageNo?: number
  pageSize?: number
}
export interface table_item {
  createTime?: string
  createUser?: string
  dataScopeType?: number
  roleCode?: string
  roleName?: string
  roleSort?: number
  [name: string]: any
}

export type dataFrom = {
  dataTable: Array<table_item> | undefined
  search: {
    roleName: string
    roleCode: string
  }
  apiObj: Function
  selectionTable?: Array<table_item>
}

export type role = {
  roleCode: string | undefined
  roleName: string | undefined
  roleSort: number | string | undefined
  roleId?: string
}

export type roleIdType = {
  roleId?: string
}

export type menuProps = {
  label: string
  children: string
}
export type treeItem = {
  checked: boolean
  code: string
  id: string
  name: string
  nodeId: string
  nodeParentId: string
  pid: string
  [props: string]: any | null | undefined
}

export type treeItemChildren = treeItem & {
  children?: treeItem
}

export type setMenusRole = {
  roleId: string
  grantAddMenuFlag: boolean
  grantMenuId: string
}

export type sysTreeType = {
  roleId: string
}

export type sysAreaType = {
  roleId: string
  areaIds: string
}
