import request from '@/utils/network.js'
import { paramsType, paramType, role, roleIdType, setMenusRole, sysTreeType, sysAreaType } from './interface'

export default class CommonApi {
  static get(params: paramsType) {
    return request({
      url: `/api/sysRole/page`,
      method: 'get',
      params,
    })
  }

  static addDictTree(data: role) {
    return request({
      url: `/api/sysRole/add`,
      method: 'post',
      data,
    })
  }
  static editDictTree(data: role) {
    return request({
      url: `/api/sysRole/edit`,
      method: 'post',
      data,
    })
  }
  static deleteDictTree(data: roleIdType) {
    return request({
      url: `/api/sysRole/delete`,
      method: 'post',
      data,
    })
  }
  static menuAndButtonTreeChildrenV2(params: roleIdType) {
    return request({
      url: `/api/sysMenu/menuAndButtonTreeChildrenV2`,
      method: 'get',
      params,
    })
  }
  static grantMenu(data: setMenusRole) {
    return request({
      url: `/api/sysRole/grantMenu`,
      method: 'post',
      data,
    })
  }
  // 查看数据权限

  static getRoleDataDetails(params: roleIdType) {
    return request({
      url: `/api/sysRoleDataScope/detail`,
      method: 'get',
      params,
    })
  }
   // 获取行政区树
   static sysAreaTree = (params:paramType) => {
    return request({
      url: `/api/sysArea/queryTree`,
      method: "GET",
      params,
    });
  };
   // 获取职位部门树
   static organizationTree = (params: paramType) => {
    return request({
      url: `/api/expHrOrganization/organizationTree`,
      method: "GET",
      params,
    });
  };
  //授权内部数据范围
  static operateDataScope(data: paramType) {
    return request({
      url: `/api/sysRoleDataScope/operateDataScope`,
      method: 'post',
      data,
    })
  }
  // 项目字典查询通用接口
  static dictionaryDate = (params: paramType) => {
    return request({
      url: `/api/dict/page`,
      method: 'GET',
      params,
    })
  }
  // 获取风险标签
  static dictProjectRisk = (params: paramType) => {
    return request({
      url: `/baseServer/projectManage/queryDictTreeByProject`,
      method: 'GET',
      params,
    })
  }
   // 项目字典查询通用接口
   static dictProject = (params: paramType,config:object) => {
    return request({
      url: `/baseServer/applicationVisionDict/queryDictForExternal`,
      method: 'GET',
      params,
      ...config
    })
  }
}
