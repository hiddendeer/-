<template>
  <el-container>
    <el-header>
      <div class="left-panel">
        <el-form-item label="资源名称: " label-width="120px">
          <el-input v-model="data.search.resourceName" placeholder="资源名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="资源url: " label-width="120px">
          <el-input v-model="data.search.url" placeholder="资源url" clearable></el-input>
        </el-form-item>
      </div>
      <div class="right-panel">
        <el-button type="primary" icon="el-icon-search" @click="handelSearch">搜索</el-button>
        <el-button @click="reset">重置</el-button>
      </div>
    </el-header>

    <el-main class="nopadding">
      <scTable ref="table" :apiObj="data.apiObj" :params="data.search" :data="data.dataTable" row-key="id">
        <el-table-column type="index" width="50" align="center"></el-table-column>
        <el-table-column label="资源名称" prop="resourceName" align="center" min-width="150"></el-table-column>
        <el-table-column label="资源编码" prop="resourceCode" align="center" min-width="200"></el-table-column>
        <el-table-column label="模块名称" prop="methodName" align="center"></el-table-column>
        <el-table-column label="是否视图" prop="viewFlag" align="center">
          <template #default="scope">
            <div>
              <el-tag class="ml-2" v-if="scope.row.viewFlag === 'Y'">是</el-tag>
              <el-tag class="ml-2" type="danger" v-else>否</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="请求url" prop="url" align="center" min-width="200"></el-table-column>
        <el-table-column label="http方法" prop="httpMethod" align="center"></el-table-column>
        <el-table-column label="需要登录" prop="requiredLoginFlag" align="center">
          <template #default="scope">
            <div>
              <el-tag class="ml-2" v-if="scope.row.requiredLoginFlag === 'Y'">是</el-tag>
              <el-tag class="ml-2" type="danger" v-else>否</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="需要权限验证" prop="requiredPermissionFlag" align="center">
          <template #default="scope">
            <div>
              <el-tag class="ml-2" v-if="scope.row.requiredPermissionFlag === 'Y'">是</el-tag>
              <el-tag class="ml-2" type="danger" v-else>否</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right" align="center">
          <template #default="scope">
            <el-button text type="primary" size="small" @click="table_details(scope.row)">详情</el-button>
          </template>
        </el-table-column>
      </scTable>
    </el-main>
  </el-container>
  <el-dialog v-model="detailsWindow" width="40%" :close-on-click-modal="false">
    <template #header>
      <h1>资源详情</h1>
    </template>
    <el-form-item>
      <!-- 应用标识 -->
      <el-form-item label="应用标识: " label-width="120px">
        <el-input v-model="detailsForm.appCode" placeholder="请填写应用标识"></el-input>
      </el-form-item>
      <!-- 资源标识 -->
      <el-form-item label="资源标识: " label-width="120px">
        <el-input v-model="detailsForm.resourceCode" placeholder="请填写资源标识"></el-input>
      </el-form-item>
    </el-form-item>
    <el-form-item>
      <!-- 资源名称 -->
      <el-form-item label="资源名称: " label-width="120px">
        <el-input v-model="detailsForm.resourceName" placeholder="请填写资源名称"></el-input>
      </el-form-item>
      <!-- 项目编码 -->
      <el-form-item label="项目编码: " label-width="120px">
        <el-input v-model="detailsForm.projectCode" placeholder="请填写项目编码"></el-input>
      </el-form-item>
    </el-form-item>
    <el-form-item>
      <!-- 控制器类名 -->
      <el-form-item label="控制器类名: " label-width="120px">
        <el-input v-model="detailsForm.className" placeholder="请填写控制器类名"></el-input>
      </el-form-item>
      <!-- 方法名称 -->
      <el-form-item label="方法名称: " label-width="120px">
        <el-input v-model="detailsForm.methodName" placeholder="请填写方法名称"></el-input>
      </el-form-item>
    </el-form-item>
    <el-form-item>
      <!-- 所属模块 -->
      <el-form-item label="所属模块: " label-width="120px">
        <el-input v-model="detailsForm.modularCode" placeholder="请填写所属模块"></el-input>
      </el-form-item>
      <el-form-item label="模块名称: " label-width="120px">
        <el-input v-model="detailsForm.modularName" placeholder="请填写模块名称"></el-input>
      </el-form-item>
    </el-form-item>
    <el-form-item>
      <!-- 初始化地址 -->
      <el-form-item label="初始化地址: " label-width="120px">
        <el-input v-model="detailsForm.ipAddress" placeholder="请填写初始化地址"></el-input>
      </el-form-item>
      <!-- 是否视图 -->
      <el-form-item label="是否视图: " label-width="120px">
        <el-switch v-model="detailsForm.viewFlag" active-value="Y" inactive-value="N" inline-prompt active-text="是" inactive-text="否" />
      </el-form-item>
    </el-form-item>
    <el-form-item>
      <!-- 请求路径 -->
      <el-form-item label="请求路径: " label-width="120px">
        <el-input v-model="detailsForm.url" placeholder="请填写请求路径"></el-input>
      </el-form-item>
      <!-- 是否需登录 -->
      <el-form-item label="是否需登录: " label-width="120px">
        <el-switch v-model="detailsForm.requiredLoginFlag" active-value="Y" inactive-value="N" inline-prompt active-text="是" inactive-text="否" />
      </el-form-item>
    </el-form-item>
    <el-form-item>
      <!-- 请求方法 -->
      <el-form-item label="请求方法: " label-width="120px">
        <el-input v-model="detailsForm.httpMethod" placeholder="请填写请求方法"></el-input>
      </el-form-item>
      <!-- 是否需权限验证 -->
      <el-form-item label="是否需权限验证: " label-width="120px">
        <el-switch v-model="detailsForm.requiredPermissionFlag" active-value="Y" inactive-value="N" inline-prompt active-text="是" inactive-text="否" />
      </el-form-item>
    </el-form-item>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue'
import { table_item, dataFrom } from './server/interface'
import CommonApi from './server/api'
import { ElMessage } from 'element-plus'

const table = ref<any>(null)
const data = reactive<dataFrom>({
  dataTable: [],
  search: {
    resourceName: '',
    url: '',
  },
  apiObj: CommonApi.get,
})
// 资源详情弹窗
const detailsWindow = ref(false)
// 资源详情弹窗表单初始化
let detailsForm = ref<table_item>({
  appCode: '',
  resourceName: '',
  className: '',
  modularCode: '',
  ipAddress: '',
  url: '',
  httpMethod: '',
  resourceCode: '',
  projectCode: '',
  methodName: '',
  modularName: '',
  viewFlag: '',
  requiredLoginFlag: '',
  requiredPermissionFlag: '',
})
const handelSearch = async () => {
  table.value?.refresh()
}
// 查看详情按钮
const table_details = (e: table_item) => {
  detailsForm.value = e
  detailsWindow.value = true
}
// 重置按钮
const reset = () => {
  data.search.resourceName = ''
  data.search.url = ''
  handelSearch()
}
onMounted(() => {
  handelSearch()
})
</script>

<style scoped lang="scss">
.topSearch {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
:deep(.el-form-item) {
  margin-bottom: 0px;
}
</style>
