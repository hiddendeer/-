import request from '@/utils/network.js'
import { paramsType } from './interface'

export default class CommonApi {
  // v1资源查看接口 /resourceManage/queryList
  static get(params: paramsType) {
    return request({
      url: `/api/resource/pageList`,
      method: 'get',
      params,
    })
  }
}
