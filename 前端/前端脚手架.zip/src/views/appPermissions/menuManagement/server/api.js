import request from "@/utils/network.js";
export default class api {
    static getMenuList(params) {
        return request({
            url: `/api/sysMenu/list`,
            method: 'get',
            params
        })
    }
    static getAppList(params) {
        return request({
            url: `/api/sysApp/list`,
            method: 'get',
            params
        })
    }
    static addMenu(data) {
        return request({
            url: `/api/sysMenu/add`,
            method: 'post',
            data
        })
    }
    static editMenu(data) {
        return request({
            url: `/api/sysMenu/edit`,
            method: 'post',
            data
        })
    }
    static deleteMenu(data) {
        return request({
            url: `/api/sysMenu/delete`,
            method: 'post',
            data
        })
    }
}