<template>
  <el-container>
    <el-aside width="400px" v-loading="menuloading">
      <el-container>
        <el-header>
          <el-input
            placeholder="输入关键字进行过滤"
            v-model="menuFilterText"
            clearable
          ></el-input>
        </el-header>
        <el-main class="nopadding">
          <el-tree
            ref="menu"
            class="menu"
            node-key="menuName"
            :data="menuList"
            :props="menuProps"
            highlight-current
            :expand-on-click-node="false"
            check-strictly
            :filter-node-method="menuFilterNode"
            @node-click="menuClick"
          >
            <template #default="{ node, data }">
              <span class="custom-tree-node el-tree-node__label">
                <span class="label">
                  {{ data.menuName }}
                </span>
                <span class="code">{{ data.menuCode }}</span>
                <span class="do">
                  <el-button
                    icon="el-icon-plus"
                    size="small"
                    @click.stop="addMenuNode(node, data)"
                  ></el-button>
                  <el-button
                    icon="el-icon-delete"
                    type="danger"
                    size="small"
                    @click.stop="deleteMenu(node, data)"
                  ></el-button>
                </span>
              </span>
            </template>
          </el-tree>
        </el-main>
        <el-footer style="height: 51px; text-align: center">
          <!-- <el-button type="primary" size="small" icon="el-icon-plus" @click="add()"></el-button> -->
          <!-- <el-button type="danger" size="small" plain icon="el-icon-delete" @click="delMenu"></el-button> -->
         <el-button
            type="primary"
            icon="el-icon-plus"
            style="width: 80%"
            @click="addMenuNode()"
            >新增菜单</el-button
          >
        </el-footer>
      </el-container>
    </el-aside>
    <el-container>
      <el-main class="nopadding" style="padding: 20px" ref="main">
        <save ref="save" :menu="menuList" @success="emitSaveSuccess"></save>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import api from "./server/api.js";
import save from "./save";

let newMenuIndex = 1;
export default {
  name: "settingMenu",
  components: {
    save,
  },
  data() {
    return {
      menuloading: false,
      menuList: [],
      menuProps: {
        label: "menuName",
      },
      menuFilterText: "",
      setMenuNameNode: "",
    };
  },
  watch: {
    menuFilterText(val) {
      this.$refs.menu.filter(val);
    },
  },
  mounted() {
    this.getMenu();
  },
  methods: {
    emitSaveSuccess(menuName) {
      this.setMenuNameNode = menuName;
      this.getMenu();
    },
    //加载树数据
    async getMenu() {
      this.menuloading = true;
      // var res = await this.$API.system.menu.list.get();
      const res = await api.getMenuList();
      this.menuloading = false;
      this.menuList = res?.data;

      if (this.setMenuNameNode) {
        this.$nextTick(() => {
          this.$refs.menu.setCurrentKey(this.setMenuNameNode);
        });
      }
    },
    //树点击
    menuClick(data, node) {
      //   var menuId = node.level == 1 ? undefined : node.parent.data.menuId;
      const menuId = data?.menuId ? data?.menuId : "";
      this.$refs.save.setData(data, menuId, true);
      this.$refs.main.$el.scrollTop = 0;
    },
    //树过滤
    menuFilterNode(value, data) {
      if (!value) return true;
      var targetText = data.menuName + data.menuCode;
      return targetText.indexOf(value) !== -1;
    },

    // 新增根节点 menuId  menuName menuParentId
    addMenuNode(node, data) {
      var newMenuName = "未命名" + newMenuIndex++;
      var newMenuData = {
        menuParentId: data ? data?.menuId : "",
        menuName: newMenuName,
        path: "",
        component: "",
      };
      this.$refs.menu.append(newMenuData, node);
      this.$refs.menu.setCurrentKey(newMenuData.menuName);
      const menuId = node ? node.data.menuId : "";
      this.$refs.save.setData(newMenuData, menuId,true);
    },

    async deleteMenu(node, data) {
      if (data?.menuId) {
        this.$confirm(`确定删除 ${data.menuName} 菜单吗？`, "提示", {
          type: "warning",
        }).then(async () => {
          const delRes = await api.deleteMenu({ menuId: data.menuId });
          if (delRes.code == "00000") {
            this.$refs.menu.remove(data);
            this.$message.success("删除成功!");
          }
        });
      } else {
        this.$refs.menu.remove(data);
      }
    },
  },
};
</script>

<style scoped>
.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .label {
  display: flex;
  align-items: center;
  height: 100%;
}
.custom-tree-node .code {
  font-size: 12px;
  color: #999;
}
.custom-tree-node .label .el-tag {
  margin-left: 5px;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node .do i {
  margin-left: 5px;
  color: #999;
}
.custom-tree-node .do i:hover {
  color: #333;
}

.custom-tree-node:hover .do {
  display: inline-block;
}
</style>
