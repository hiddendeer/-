import request from "@/utils/network.js";
import { paramsType, roleApp, appIdType, setMenusRole } from "./interface";

export default class CommonApi {

    static get(params: paramsType) {
        return request({
            url: `/api/sysApp/page`,
            method: 'get',
            params
        })
    }

    static addDictTree(data: roleApp) {
        return request({
            url: `/api/sysApp/add`,
            method: 'post',
            data
        })
    }
    static deleteDictTree(data: appIdType) {
        return request({
            url: `/api/sysApp/delete`,
            method: 'post',
            data
        })
    }
    static editDictTree(data: roleApp) {
        return request({
            url: `/api/sysApp/edit`,
            method: 'post',
            data
        })
    }

    static updateActiveFlag(data: roleApp) {
        return request({
            url: `/api/sysApp/updateActiveFlag`,
            method: 'post',
            data
        })
    }


}






