

export interface paramsType {
    roleName?: string,
    roleCode?: string,
    pageNo: number,
    pageSize: number
}
export interface table_item {
    activeFlag?: string,
    appCode?: string,
    appIcon?: string,
    appId?: string,
    appName?: string,
    createTime?: string,
    createUser?: string,
    delFlag?: string,
    statusFlag?: string,
    [props: string]: string | undefined | null,
}


export type dataFrom = {
    dataTable: Array<table_item> | undefined,
    search: {
        appName: string,
        appCode: string,
    },
    apiObj: Function,
    selectionTable?: Array<table_item>,
}

export type roleApp = {
    appCode?: string | undefined,
    appName?: string | undefined,
    appIcon?: string | undefined,
    appId?: string,
    activeFlag?: string
}

export type appIdType = {
    appId?: string
}

export type menuProps = {
    label: string,
    children: string
}
export type treeItem = {
    checked: boolean,
    code: string,
    id: string,
    name: string,
    nodeId: string,
    nodeParentId: string,
    pid: string,
    [props: string]: any | null | undefined,
}

export type treeItemChildren = treeItem & {
    children?: treeItem
}

export type setMenusRole = {
    roleId: string,
    grantAddMenuFlag: boolean,
    grantMenuId: string
}