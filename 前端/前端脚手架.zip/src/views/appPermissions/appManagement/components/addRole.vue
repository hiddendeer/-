<template>
    <div>
        <el-dialog v-model="showDialog" :title="props.title" @closed="close" width="30vw" :close-on-click-modal="false">
            <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px">
                <el-form-item label="应用名称: " prop="appName" required>
                    <el-input v-model="form.appName" :formatter="(value: string) => value.replace(/^\s+|\s+$/g, '')"
                        placeholder="请输入应用名称" />
                </el-form-item>
                <el-form-item label="应用编码: " prop="appCode" required>
                    <el-input v-model="form.appCode" :formatter="(value: string) => value.replace(/^\s+|\s+$/g, '')"
                        :disabled="props.title == '修改应用'" placeholder="请输入应用编码" />
                </el-form-item>
                <el-form-item label="应用图标: " prop="appIcon" required>
                    <sc-icon-select v-model:modelValue="form.appIcon"></sc-icon-select>
                </el-form-item>

            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="close">取消</el-button>
                    <el-button type="primary" @click="submitForm">
                        保存
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup lang="ts">
import { toRefs, ref, reactive, nextTick } from "vue";
import { roleApp } from "../server/interface";
import scIconSelect from "@/scComponents/scIconSelect";
import type { FormInstance, FormRules } from 'element-plus';
import { ElMessage } from "element-plus";
import api from "../server/api";


const emits = defineEmits(['update:showDialog', "close"]);
const props = defineProps({
    showDialog: {
        type: Boolean,
        default: false
    },
    title: {
        type: String,
    }
}); // 表单
const editId = ref<string | undefined | null>('');
const { showDialog } = toRefs(props);
const ruleFormRef = ref<FormInstance | null | undefined>(null);
const form = ref<roleApp>({
    appName: '',
    appCode: '',
});
const rules = reactive<FormRules>({
    appName: [
        { required: true, message: '请输入应用名称', trigger: 'blur' },
    ],
    appCode: [
        { required: true, message: '请输入应用编码', trigger: 'blur' },
    ],
    appIcon: [
        { required: true, message: '请选择应用图标', trigger: ['change', 'blur'] },
    ],
})

const close = () => {
    editId.value = null;
    ruleFormRef.value?.resetFields();
    emits("update:showDialog", false);
}
const submitForm = async () => {
    ruleFormRef.value?.validate(async (valid, fields) => {
        if (valid) {
            let res;
            if (editId.value) {
                let obj = form.value;
                obj.appId = editId.value;
                res = await api.editDictTree(obj);
            } else {
                res = await api.addDictTree(form.value);
            }
            if (res.success) {
                ElMessage.success('操作成功!');
                close()
                emits('close')
            }
            else {
                ElMessage.error(res.message)
            }
        } else {
            console.log('error submit!', fields)
        }
    })
}
const edit = (e: roleApp) => {
    nextTick(() => {
        editId.value = e.appId;
        delete e.appId;
        form.value = e;
        emits("update:showDialog", true);
    })
}
defineExpose({
    edit
})
</script>

<style scoped lang="scss">
::v-deep(.el-input-number .el-input__inner) {
    text-align: left;
}
</style>
