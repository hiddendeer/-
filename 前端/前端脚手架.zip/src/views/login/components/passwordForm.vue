<template>
  <el-form
    ref="loginForm"
    :model="form"
    :rules="rules"
    label-width="0"
    size="large"
    @keyup.enter="login"
  >
    <el-form-item prop="user">
      <el-input
        v-model="form.user"
        prefix-icon="el-icon-user"
        :placeholder="$t('login.userPlaceholder')"
      >
      </el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input
        v-model="form.password"
        prefix-icon="el-icon-lock"
        show-password
        :placeholder="$t('login.PWPlaceholder')"
      ></el-input>
    </el-form-item>
    <el-form-item style="margin-bottom: 20px">
      <!-- <el-col :span="12">
        <el-checkbox
          :label="$t('login.rememberMe')"
          v-model="form.autologin"
        ></el-checkbox>
      </el-col> -->
      <!-- <el-col :span="12" class="login-forgot">
        <router-link to="/reset_password"
          >{{ $t("login.forgetPassword") }}？</router-link
        >
      </el-col> -->
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        style="width: 100%"
        :loading="islogin"
        round
        @click="login"
        >{{ $t("login.signIn") }}</el-button
      >
    </el-form-item>
    <!-- <div class="login-reg">
      {{ $t("login.noAccount") }}
      <router-link to="/user_register">{{
        $t("login.createAccount")
      }}</router-link>
    </div> -->
  </el-form>
</template>

<script>
import config from "@/config/index.js";
import CommonApi from "@/api/CommonApi.js";
export default {
  data() {
    return {
      userType: "admin",
      form: {
        user: "admin",
        password: "GuanSafety@admin1",
        autologin: false,
      },
      rules: {
        user: [
          {
            required: true,
            message: this.$t("login.userError"),
            trigger: "blur",
          },
        ],
        password: [
          {
            required: true,
            message: this.$t("login.PWError"),
            trigger: "blur",
          },
        ],
      },
      islogin: false,
      menuList: [],
    };
  },
  watch: {
    userType(val) {
      if (val == "admin") {
        this.form.user = "admin";
        this.form.password = "admin";
      } else if (val == "user") {
        this.form.user = "user";
        this.form.password = "user";
      }
    },
  },
  mounted() {
    localStorage.clear();
  },
  methods: {
    calcMenu(menuData) {
      if (!menuData) {
        return;
      }
      for (const [index, item] of menuData.entries()) {
        console.log(item);
        item.name = item?.path?.split("/")?.join("");
        item.path = item.path ? item.path : "/systemSetting";
        item.component = item.component;
        item.meta = {
          title: item.title,
          icon: item.icon,
          hidden: item.hide,
          type: "menu",
        };
        if (item.children && item.children.length > 0) {
          this.calcMenu(item.children);
        }
      }
      return menuData;
    },
    async login() {
      var validate = await this.$refs.loginForm.validate().catch(() => {});
      if (!validate) {
        return false;
      }

      this.islogin = true;
      const data = {
        account: this.form.user,
        password: this.form.password,
        remember: true,
        tenantCode: "master",
      };
      //获取token
      const loginRes = await CommonApi.login(data);
      this.islogin = false;
      if (loginRes?.code == "00000") {
        localStorage.setItem("TOKEN", loginRes?.data?.token);
        localStorage.setItem(
          "loginUser",
          JSON.stringify(loginRes?.data?.loginUser)
        );

        // 获取菜单
        const menuRes = await CommonApi.getMenu();

        if (menuRes?.code == "00000") {
          if (menuRes?.data && menuRes.data.length == 0) {
            this.$message.error("用户没有菜单权限，请联系管理员");
            return;
          }

          menuRes?.data.forEach((item) => {
            if (item.children) {
              item.children = this.calcMenu(item.children);
            }
          });

          localStorage.setItem(
            "menuConfig",
            JSON.stringify(menuRes?.data || [])
          );

          // 优先跳转到系统应用
          const menuObj = menuRes?.data.find(
            (item) => item?.path.indexOf(config?.DEFAULT_MENU_APP) > -1
          );
          const menuInfo = menuObj?.children;
          localStorage.setItem(
            "MENU",
            JSON.stringify(this.calcMenu(menuInfo) || [])
          );

        }
      } else {
        this.islogin = false;
        // this.$message.warning(loginRes?.message || "服务器错误");
        return false;
      }

      // this.$TOOL.data.set("PERMISSIONS", menuJson.data.permissions);
      this.$router.replace({
        path: "/dashboard",
      });
      this.$message.success("Login Success 登录成功");
    },
  },
};
</script>

<style>
</style>
