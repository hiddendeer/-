<template>
  <el-container>
    <el-header>
      <div>
        <el-button type="danger" @click="deleteAllLog">清空日志</el-button>
      </div>
      <div style="width: 60%; height: 100%; display: flex; justify-content: space-between; align-items: center">
        <el-form-item label="角色名称: " style="margin-bottom: 0px">
          <el-input v-model="data.search.roleName" placeholder="角色名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="角色编码: " style="margin-bottom: 0px">
          <el-input v-model="data.search.roleCode" placeholder="角色编码" clearable></el-input>
        </el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="handelSearch">搜索</el-button>
      </div>
    </el-header>

    <el-main class="nopadding">
      <scTable ref="table" @selection-change="selectionChange" :apiObj="data.apiObj" :params="data.search" :data="data.dataTable" row-key="id">
        <el-table-column type="index" width="50" align="center"></el-table-column>
        <el-table-column label="用户名" prop="userName" align="center">
          <template #default="scope">
            <div>
              {{ scope.row.userName || '-' }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="日志名称" prop="llgName" align="center"></el-table-column>
        <el-table-column label="执行结果" prop="llgSucceed" align="center"></el-table-column>
        <el-table-column label="时间" prop="createTime" align="center"></el-table-column>
        <el-table-column label="具体消息" prop="llgMessage" align="center"></el-table-column>
        <el-table-column label="IP" prop="llgIpAddress" align="center"></el-table-column>
      </scTable>
    </el-main>
  </el-container>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue'
import { paramsType, table_item, dataFrom } from './server/interface'
import CommonApi from './server/api'
import { ElMessage, ElMessageBox } from 'element-plus'

const table = ref<any>(null)
const data = reactive<dataFrom>({
  dataTable: [],
  search: {},
  apiObj: CommonApi.get,
  selectionTable: [],
})
onMounted(() => {
  handelSearch()
})
const handelSearch = async () => {
  table.value?.refresh()
}

const selectionChange = (e: table_item[]) => {
  data.selectionTable = e
}

// 清空所有日志
const deleteAllLog = () => {
  ElMessageBox.confirm(`确定要清空日志吗？`, '提示', {
    type: 'warning',
  })
    .then(() => {
      CommonApi.deleteAll().then((res: any) => {
        if (res.code == '00000') {
          ElMessage.success('情况成功')
          handelSearch()
        } else {
          ElMessage.error(res.message)
        }
      })
    })
    .catch(() => {})
}
</script>

<style scoped lang="scss"></style>
