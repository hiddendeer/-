import request from '@/utils/network.js'
import { paramsType } from './interface'

export default class CommonApi {
  static get(params: paramsType) {
    // v1 登录日志接口 /loginLog/page
    return request({
      url: `/api/loginLog/page`,
      method: 'get',
      params,
    })
  }

  static deleteAll(params?: paramsType) {
    // v1 登录日志接口 /loginLog/page
    return request({
      url: `/api/loginLog/deleteAll`,
      method: 'get',
      params,
    })
  }
}
