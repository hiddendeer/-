export interface paramsType {
  roleName?: string
  roleCode?: string
  pageNo: number
  pageSize: number
}
export interface table_item {
  createTime?: string
  createUser?: string
  dataScopeType?: number
  roleCode?: string
  roleName?: string
  roleSort?: number
  [name: string]: any
}

export type dataFrom = {
  dataTable: Array<table_item> | undefined
  search: {
    roleName?: string
    roleCode?: string
  }
  apiObj: Function
  selectionTable?: Array<table_item>
}
