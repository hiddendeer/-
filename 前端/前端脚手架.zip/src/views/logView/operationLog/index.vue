<template>
  <el-container>
    <el-header>
      <div>
        <el-button type="danger">清空日志</el-button>
      </div>
      <div style="width: 60%; height: 100%; display: flex; justify-content: space-between; align-items: center">
        <el-form-item label="角色名称: " style="margin-bottom: 0px">
          <el-input v-model="searchParams.roleName" placeholder="角色名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="角色编码: " style="margin-bottom: 0px">
          <el-input v-model="searchParams.roleCode" placeholder="角色编码" clearable></el-input>
        </el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="getOperationLog">搜索</el-button>
        <el-button>重置</el-button>
      </div>
    </el-header>
    <el-main class="nopadding">
      <scTable ref="table" :data="tableData" row-key="id">
        <el-table-column type="index" width="50" align="center"></el-table-column>
        <el-table-column label="角色名称" prop="roleName" align="center"></el-table-column>
        <el-table-column label="角色名称" prop="roleName" align="center"></el-table-column>
        <el-table-column label="角色编码" prop="roleCode" align="center"></el-table-column>
        <el-table-column label="数据范围" prop="dataScopeType" align="center"></el-table-column>
        <el-table-column label="排序" prop="roleSort" sortable align="center"></el-table-column>
        <el-table-column label="操作" fixed="right" align="center">
          <template #default="scope">
            <el-button-group>
              <el-button text type="warning" size="small" @click="toDetails(scope.row)">详情</el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </scTable>
    </el-main>
  </el-container>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue'
import { searchParam } from './server/interface'
import CommonApi from './server/api'
import { ElMessage } from 'element-plus'

const table = ref<any>(null)
const addRoleRef = ref<null | undefined | any>(null)
// 搜索条件数据初始化
let searchParams = ref<searchParam>({
  roleName: '',
  roleCode: '',
})
// 列表数据初始化
let tableData = ref([])
// 获取操作日志列表
const getOperationLog = () => {
  let params = {
    pageNo: 1,
    pageSize: 20,
  }
  CommonApi.get(params).then((res: any) => {
    console.log(res)
  })
}
// 跳转详情
const toDetails = (data: object) => {
  console.log('详情', data)
}
onMounted(() => {
  getOperationLog()
})
</script>

<style scoped lang="scss"></style>
