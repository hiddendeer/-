import request from '@/utils/network.js'
import { paramsType } from './interface'

export default class CommonApi {
  static get(params: paramsType) {
    // v1 操作日志接口 /logManager/page
    return request({
      url: `/api/logManager/page`,
      method: 'get',
      params,
    })
  }
}
