export interface paramsType {
  pageNo: number
  pageSize: number
}

export interface clickParam {
  data: Object
}
export type searchParam = {
  roleName: string
  roleCode: string
}
