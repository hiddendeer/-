import { reactive } from "vue"

export const state = reactive({
    title: "欢迎",
    content: ""
})

export const change = (e) => {
    state.title = e
}