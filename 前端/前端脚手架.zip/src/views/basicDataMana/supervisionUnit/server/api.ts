import request from '@/utils/network.js'
import { paramType, sysAreaType, areaIdType } from './interface'

export default class CommonApi {
  // 获取监管单位树
  static sysAreaTree = (params: paramType) => {
    return request({
      url: `/api/sysArea/queryTree`,
      method: 'GET',
      params,
    })
  }
  // 获取监管单位列表
  static sysAreaPage = (params: paramType) => {
    return request({
      url: `/api/sysArea/page`,
      method: 'GET',
      params,
    })
  }
  // 新增行政区域
  static addSysArea = (data: sysAreaType) => {
    return request({
      url: `/api/sysArea/add`,
      method: 'POST',
      data,
    })
  }
  // 编辑行政区域
  static updateSysArea = (data: sysAreaType) => {
    return request({
      url: `/api/sysArea/update`,
      method: 'PUT',
      data,
    })
  }
  // 删除行政区树
  static deleteSysArea = (data: areaIdType) => {
    return request({
      url: `/api/sysArea/delete`,
      method: 'DELETE',
      data,
    })
  }
  // 查看行政区域
  static sysAreaDetail = (params: areaIdType) => {
    return request({
      url: `/api/sysArea/queryDetail`,
      method: 'GET',
      params,
    })
  }
}
