import request from '@/utils/network.js'
import { paramType, sysAreaType, areaIdType } from './interface'

export default class CommonApi {
  // 获取行政区树
  static sysAreaTree = (params: paramType) => {
    return request({
      url: `/api/sysRegion/queryTree`,
      method: 'GET',
      params,
    })
  }

  // 获取行政区列表
  static sysAreaPage = (params: paramType) => {
    return request({
      url: `/api/sysRegion/page`,
      method: 'GET',
      params,
    })
  }
  // 新增行政区域
  static addSysArea = (data: sysAreaType) => {
    return request({
      url: `/api/sysRegion/add`,
      method: 'POST',
      data,
    })
  }
  // 编辑行政区域
  static updateSysArea = (data: sysAreaType) => {
    return request({
      url: `/api/sysRegion/update`,
      method: 'PUT',
      data,
    })
  }
  // 删除行政区树
  static deleteSysArea = (data: areaIdType) => {
    return request({
      url: `/api/sysRegion/delete`,
      method: 'DELETE',
      data,
    })
  }
  // 查看行政区域
  static sysAreaDetail = (params: areaIdType) => {
    return request({
      url: `/api/sysRegion/queryDetail`,
      method: 'GET',
      params,
    })
  }
}
