// get接口请求参数
export interface paramType {
  pageNo?: number
  pageSize?: number
}
// 行政区域参数类型
export type sysAreaType = {
  areaId?: string
  parentId: string
  fullName: string
  areaCode: string
  areaSort: number
  remark: string
}
// 删除行政区域参数类型 deleteSysType
export type areaIdType = {
  areaId: string
}
