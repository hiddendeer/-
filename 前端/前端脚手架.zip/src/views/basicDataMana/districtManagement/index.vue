<template>
  <el-container>
    <el-aside width="25%" v-loading="showGrouploading">
      <el-container>
        <el-header>
          <el-input placeholder="输入关键字进行过滤" v-model="groupFilterText" clearable></el-input>
        </el-header>
        <el-main class="nopadding">
          <el-tree
            ref="groupRef"
            class="menu"
            node-key="value"
            :data="groupData"
            :props="defaultProps"
            highlight-current
            auto-expand-parent
            :default-expanded-keys="['10']"
            :expand-on-click-node="false"
            :filter-node-method="groupFilterNode"
            @node-click="groupClick"
          >
            <template #default="{ node, data }">
              <span class="custom-tree-node">
                <el-tooltip class="box-item" effect="dark" :content="data.label" placement="top">
                  <span class="label">{{ data.label }}</span>
                </el-tooltip>
                <span class="do">
                  <el-button icon="el-icon-edit" size="small" v-if="node.level > 3" @click.stop="editOrg(data, 'edit')" />
                  <el-button icon="el-icon-delete" type="danger" v-if="node.level > 3" size="small" @click.stop="delOrg(node, data)" />
                </span>
              </span>
            </template>
          </el-tree>
        </el-main>
        <el-footer style="height: 51px">
          <el-button type="primary" icon="el-icon-plus" style="width: 100%" @click="handleOrg">新增行政区域</el-button>
        </el-footer>
      </el-container>
    </el-aside>
    <el-container>
      <el-header>
        <div class="region_title">行政区域管理</div>
        <div class="region_search">
          <el-input class="region_search_content" v-model="searchForm.unitName" placeholder="请输入行政区名称进行模糊搜索" clearable></el-input>
          <div class="region_search_btn">
            <div class="region_search_btn_left">
              <el-button type="primary" @click="handelSearch">搜索</el-button>
              <el-button @click="handelReset">重置</el-button>
            </div>
          </div>
        </div>
      </el-header>
      <el-main class="nopadding">
        <scTable ref="tableRef" :data="tableData" row-key="id" hidePagination hideDo>
          <el-table-column label="序号" type="index" width="100" align="center"></el-table-column>
          <el-table-column label="行政区名称" prop="fullName" align="center"></el-table-column>
          <el-table-column label="排序号" prop="areaSort" min-width="100" align="center">
            <template #default="scope">
              <div>
                {{ scope.row.areaSort || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="操作" fixed="right" align="center" width="300">
            <template #default="scope">
              <el-button-group>
                <el-button text type="primary" size="small" @click="editOrg(scope.row, 'edit')">编辑</el-button>
                <el-button text type="primary" size="small" @click="editOrg(scope.row, 'adjNode')">调整节点</el-button>
                <el-popconfirm title="确定删除吗？" @confirm="delOrg(scope.row)">
                  <template #reference>
                    <el-button text type="danger" size="small">删除</el-button>
                  </template>
                </el-popconfirm>
              </el-button-group>
            </template>
          </el-table-column>
        </scTable>
      </el-main>
      <el-footer class="bodyPage">
        <div class="leftButton"></div>
        <el-pagination
          background
          @current-change="currentPageChange"
          @size-change="pageSizeChange"
          :page-size="pageSize"
          :current-page="page"
          :small="true"
          :page-sizes="[10, 20, 30, 40, 50]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </el-footer>
    </el-container>
  </el-container>
  <!-- 添加编辑行政区弹窗 -->
  <el-dialog :title="orgTitle" v-model="showOrgDialog" width="30%" :close-on-click-modal="false" @closed="close">
    <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px" v-loading="loading">
      <el-form-item label="上级行政区：" prop="parentId" required>
        <el-cascader v-model="form.parentId" placeholder="请选择上级行政区" :options="groupData" :props="deptsProps" clearable style="width: 100%" @change="changeOrg" />
      </el-form-item>
      <el-form-item label="行政区名称：" prop="fullName" required>
        <el-input v-model="form.fullName" :formatter="(value) => value.replace(/^\s+|\s+$/g, '')" placeholder="请输入行政区名称" />
      </el-form-item>
      <el-form-item label="行政区编号：" prop="areaCode" required>
        <el-input v-model="form.areaCode" :formatter="(value) => value.replace(/^\s+|\s+$/g, '')" placeholder="请输入行政区编号" />
      </el-form-item>
      <el-form-item label="排序号：" prop="areaSort">
        <el-input-number placeholder="请输入排序号" style="text-align: left; width: 100%" v-model="form.areaSort" :min="1" :step="1" step-strictly controls-position="right" />
      </el-form-item>
      <el-form-item label="备注：" prop="remark">
        <el-input v-model="form.remark" placeholder="请输入备注" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="close(ruleFormRef)">取消</el-button>
        <el-button type="primary" @click="submitForm(ruleFormRef)">确认</el-button>
      </div>
    </template>
  </el-dialog>
  <!-- 调节节点弹窗 -->
  <el-dialog :title="orgTitle" v-model="adjustingNodeDialog" width="30%" :close-on-click-modal="false" @closed="close">
    <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px" v-loading="loading">
      <el-form-item label="上级行政区：" prop="parentId" required>
        <el-cascader v-model="form.parentId" placeholder="请选择上级行政区" :options="groupData" :props="deptsProps" clearable style="width: 100%" @change="changeOrg" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="closeAdj(ruleFormRef)">取消</el-button>
        <el-button type="primary" @click="submitFormAdj(ruleFormRef)">确认</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, onMounted, watch, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import CommonApi from './server/api'

// 初始化数据树过滤
let groupFilterText = ref('')
// 加载
let showGrouploading = ref(false)
// 新增弹窗
let showOrgDialog = ref(false)
// 调节节点弹窗
let adjustingNodeDialog = ref(false)
// 新增/编辑弹窗标题
let orgTitle = ref('')
// 编辑弹窗的ID
let currentOrgId = ref('')
// 树数据
let groupData = ref([])
// 表单ref
let ruleFormRef = ref(null)
// 新增/编辑 表单数据
const form = ref({
  areaId: '',
  parentId: '',
  fullName: '',
  areaCode: '',
  areaSort: 0,
  remark: '',
})
// 树ref
const groupRef = ref(null)
watch(
  () => groupFilterText.value,
  (nVal) => {
    groupRef.value.filter(nVal)
  }
)
// 行政区树格式
const defaultProps = ref({
  label: 'label',
  value: 'value',
})
// 新增编辑弹窗loading
const loading = ref(false)
// 新增编辑弹窗
const deptsProps = ref({
  value: 'value',
  label: 'label',
  checkStrictly: true,
})
// 新增编辑表单校验规则
const rules = ref({
  parentId: [{ required: true, message: '请选择上级行政区', trigger: ['change', 'blur'] }],
  fullName: [{ required: true, message: '请输入行政区名称', trigger: ['change', 'blur'] }],
  areaCode: [{ required: true, message: '请输入行政区编码', trigger: ['change', 'blur'] }],
})
let tableData = ref([])
//树过滤
const groupFilterNode = (value, data) => {
  if (!value) return true
  return data.label.indexOf(value) !== -1
}
//树点击事件
const groupClick = (data) => {
  if (data) {
    searchForm.value.unitParentId = data.value
    tableDetails()
  }
}
// 添加行政区
const handleOrg = () => {
  if (ruleFormRef.value) {
    ruleFormRef.value.resetFields()
  }
  showOrgDialog.value = true
  orgTitle.value = '新增行政区'
  currentOrgId.value = ''
}
// 编辑行政区
const editOrg = (data, type) => {
  if (type == 'edit') {
    if (data?.value || data?.areaId) {
      orgTitle.value = '编辑行政区'
      currentOrgId.value = data.value || data?.areaId
      getSysAreaDetail(currentOrgId.value)
      showOrgDialog.value = true
    }
  } else {
    orgTitle.value = '调节节点'
    currentOrgId.value = data.value || data?.areaId
    getSysAreaDetail(currentOrgId.value)
    adjustingNodeDialog.value = true
  }
}
// 获取编辑详情
const getSysAreaDetail = async (id) => {
  let saDetail = await CommonApi.sysAreaDetail({ areaId: id })
  form.value = {
    parentId: saDetail?.data.parentId,
    fullName: saDetail?.data.fullName,
    areaCode: saDetail?.data.areaCode,
    areaSort: saDetail?.data.areaSort,
    remark: saDetail?.data.remark,
  }
}
// 删除行政区
const delOrg = (node, data) => {
  ElMessageBox.confirm(`确定删除选中行政区吗？`, '提示', {
    type: 'warning',
  })
    .then(() => {
      let params = {
        areaId: data.value || data.areaId,
      }
      CommonApi.deleteSysArea(params).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('删除成功')
          getAreaTree()
        } else {
          ElMessage.error(res.message)
        }
      })
    })
    .catch(() => {})
}
// 选择上级行政区
const changeOrg = (val) => {
  if (val) form.value.parentId = val[val.length - 1]
}
// 关闭弹窗
const close = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
  showOrgDialog.value = false
}
// 新增/编辑弹窗保存
const submitForm = (formEl) => {
  if (!formEl) return
  formEl.validate((valid) => {
    if (valid) {
      if (!currentOrgId.value) {
        form.value.areaId = ''
        CommonApi.addSysArea(form.value).then((res) => {
          if (res.code == '00000') {
            ElMessage.success('新增成功')
            showOrgDialog.value = false
            getAreaTree()
          } else {
            ElMessage.warning(res.message)
          }
        })
      } else {
        form.value.areaId = currentOrgId.value
        CommonApi.updateSysArea(form.value).then((res) => {
          if (res.code == '00000') {
            ElMessage.success('编辑成功')
            showOrgDialog.value = false
            getAreaTree()
          } else {
            ElMessage.warning(res.message)
          }
        })
      }
      // formEl.resetFields()
    } else {
      console.log('error submit!')
      return false
    }
  })
}
// 调节节点弹窗取消按钮
const closeAdj = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
  adjustingNodeDialog.value = false
}
// 调节节点弹窗确认按钮
const submitFormAdj = (formEl) => {
  if (!formEl) return
  formEl.validate((valid) => {
    // 调整节点调用updata接口
    if (valid) {
      console.log(form.value)
      form.value.areaId = currentOrgId.value
      CommonApi.updateSysArea(form.value).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('编辑成功')
          showOrgDialog.value = false
          getAreaTree()
        } else {
          ElMessage.warning(res.message)
        }
      })
    } else {
      console.log('error submit!')
      return false
    }
  })
}
// 获取行政区数据
const getAreaTree = () => {
  CommonApi.sysAreaTree().then((res) => {
    if (res.code == '00000') {
      groupData.value = res.data
    } else {
      console.log(res.message)
    }
  })
}
//---------------------------------------------
// 列表table搜索框
let searchForm = ref({
  unitParentId: '10',
  unitName: '',
})
//搜索
const handelSearch = () => {
  tableDetails()
}
//重置
const handelReset = () => {
  searchForm.value = {
    unitParentId: '10',
    unitName: '',
  }
  tableDetails()
  getAreaTree()
}

//当前页数
let page = ref(1)
//一页多少条
let pageSize = ref(20)
//总条数
let total = ref(0)
//切换页数
const currentPageChange = (val) => {
  page.value = Number(val.toString().split('.')[0])
  tableDetails()
}
//切换每页条数
const pageSizeChange = (val) => {
  pageSize.value = val
  tableDetails()
}
// ---------------------------------------------

// 查看行政区域详情
const tableDetails = () => {
  let params = {
    pageNo: page.value,
    pageSize: pageSize.value,
    parentId: searchForm.value.unitParentId,
    fullName: searchForm.value.unitName,
  }
  CommonApi.sysAreaPage({ ...params }).then((res) => {
    tableData.value = res.data.rows
    total.value = res.data.totalRows
  })
}
onMounted(() => {
  getAreaTree()
  tableDetails()
})
</script>
<style lang="scss" scoped>
.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node:hover .code {
  display: none;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
.region_title {
  font-size: 18px;
  padding: 10px 5px 10px 20px;
}
.region_search {
  display: flex;
  &_content {
    width: 380px;
    height: 32px;
    padding-left: 20px;
  }
  &_btn {
    display: flex;
    padding: 0 20px;
  }
}
.label {
  width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bodyPage {
  display: flex;
  justify-content: space-between;
  .leftButton {
    display: flex;
    align-items: center;
    .forbidden {
      margin-left: 20px;
    }
  }
}
</style>
