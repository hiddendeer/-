<template>
  <el-container>
    <!-- 左侧列表配置信息 -->
    <el-aside width="450px">
      <el-container>
        <el-header>
          <div class="left-panel">
            <el-button type="primary" icon="el-icon-plus" @click="addConfigItem">新建</el-button>
            <el-button type="danger" icon="el-icon-delete" plain @click="delConfigItem">删除</el-button>
          </div>
        </el-header>
        <el-main class="nopadding">
          <scTable ref="tableRef" :data="configTypeTableData" highlight-current-row @current-change="chooseRow" hidePagination hideDo>
            <el-table-column label=" " width="50" align="center">
              <template #default="scope">
                <el-radio :label="scope.row.dictId" v-model="activedRow">&nbsp;</el-radio>
              </template>
            </el-table-column>
            <el-table-column label="配置类型" align="center" prop="dictName"></el-table-column>
            <el-table-column label="字典编码" align="center" prop="dictCode"></el-table-column>
          </scTable>
        </el-main>
        <el-footer class="bodyPage">
          <div class="leftButton"></div>
          <el-pagination
            background
            @current-change="currentPageChange"
            @size-change="pageSizeChange"
            :page-size="pageSize"
            :current-page="page"
            :small="true"
            :page-sizes="[10, 20, 30, 40, 50]"
            :total="total"
            layout="total, sizes, prev, pager, next, jumper"
          ></el-pagination>
        </el-footer>
      </el-container>
    </el-aside>
    <!-- 右侧列表详细信息 -->
    <el-container>
      <el-header>
        <div class="left-panel">
          <el-button type="primary" icon="el-icon-plus" @click="add">新建</el-button>
        </div>
        <div class="right-panel">
          <div class="right-panel-search">
            <el-form-item label="配置名称: " style="margin-bottom: 0px">
              <el-input v-model="searchForm.configName" placeholder="请输入姓名" clearable></el-input>
            </el-form-item>
            <el-form-item label="配置编码: " style="margin-bottom: 0px">
              <el-input v-model="searchForm.configCode" placeholder="请输入账号" clearable></el-input>
            </el-form-item>
            <el-button type="primary" @click="upsearch">查询</el-button>
            <el-button @click="reset">重置</el-button>
          </div>
        </div>
      </el-header>
      <el-main class="nopadding">
        <scTable ref="tableRef" :data="configListTableData" stripe remoteSort remoteFilter hidePagination hideDo>
          <el-table-column width="80" align="center" type="index"></el-table-column>
          <el-table-column label="配置名称" align="center" prop="configName" width="200"></el-table-column>
          <el-table-column label="配置编码" align="center" prop="configCode" width="200"></el-table-column>
          <el-table-column label="属性值" align="center" prop="configValue" width="200" show-overflow-tooltip></el-table-column>
          <el-table-column label="系统类型" align="center" width="100">
            <template #default="scope">
              <div>
                <el-tag class="ml-2" v-if="scope.row.sysFlag === 'Y'">是</el-tag>
                <el-tag class="ml-2" type="danger" v-else>否</el-tag>
              </div>
            </template>
          </el-table-column>
          <el-table-column label="备注" align="center" prop="remark" width="200" show-overflow-tooltip>
            <template #default="scope">
              <div class="showTooltip">
                {{ scope.row.remark || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="操作" fixed="right" align="center">
            <template #default="scope">
              <el-button-group>
                <el-button text type="primary" size="small" @click="table_edit(scope.row)">修改</el-button>
                <el-popconfirm title="确定删除吗？" @confirm="table_del(scope.row)">
                  <template #reference>
                    <el-button text type="danger" size="small">删除</el-button>
                  </template>
                </el-popconfirm>
              </el-button-group>
            </template>
          </el-table-column>
        </scTable>
      </el-main>
      <el-footer class="bodyPage">
        <div class="leftButton"></div>
        <el-pagination
          background
          @current-change="OPcurrentPageChange"
          @size-change="OPpageSizeChange"
          :page-size="OPpageSize"
          :current-page="OPpage"
          :small="true"
          :page-sizes="[10, 20, 30, 40, 50]"
          :total="OPtotal"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </el-footer>
    </el-container>
  </el-container>
  <!-- 新增配置类型表单弹窗 -->
  <el-dialog v-model="tools.showAddConfigDialog" width="30%" :close-on-click-modal="false" @closed="resetConfigForm(configRuleForm)">
    <template #header>
      <h1>{{ tools.addConfigDialogTitle }}</h1>
    </template>
    <el-form ref="configRuleForm" :model="configFrom" :rules="addconfigTypeFormRules" label-width="150px" class="demo-ruleForm" status-icon>
      <el-form-item label="类型名称：" prop="dictName">
        <el-input v-model="configFrom.dictName" placeholder="请输入类型名称" />
      </el-form-item>
      <el-form-item label="类型编码：" prop="dictCode">
        <el-input v-model="configFrom.dictCode" placeholder="请输入类型编码" />
      </el-form-item>
      <el-form-item label="排序号：" prop="dictSort">
        <el-input v-model="configFrom.dictSort" placeholder="请输入排序号" />
      </el-form-item>
      <el-form-item>
        <el-button @click="resetConfigForm(configRuleForm)">取消</el-button>
        <el-button type="primary" @click="submitConfigForm(configRuleForm)">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
  <!-- 新增/修改 配置表单弹窗 -->
  <el-dialog v-model="showSetConfigFlag" width="30%" :close-on-click-modal="false" @closed="resetSetConfigForm(configRuleForm)">
    <template #header>
      <h1>{{ setConfigTitle }}</h1>
    </template>
    <el-form ref="configRuleForm" :model="setConfigFrom" :rules="setConfigFromRules" label-width="150px" class="demo-ruleForm" status-icon>
      <el-form-item label="配置名称：" prop="configName">
        <el-input v-model="setConfigFrom.configName" placeholder="请输入配置名称" />
      </el-form-item>
      <el-form-item label="配置编码：" prop="configCode">
        <el-input v-model="setConfigFrom.configCode" placeholder="请输入配置编码" />
      </el-form-item>
      <el-form-item label="系统配置：" prop="sysFlag">
        <el-switch v-model="setConfigFrom.sysFlag" active-value="Y" inactive-value="N" inline-prompt active-text="是" inactive-text="否" />
      </el-form-item>
      <el-form-item label="配置值：" prop="configValue">
        <el-input v-model="setConfigFrom.configValue" placeholder="请输入配置值" />
      </el-form-item>
      <el-form-item label="备注：" prop="remark">
        <el-input v-model="setConfigFrom.remark" type="textarea" placeholder="请输入备注" />
      </el-form-item>
      <el-form-item>
        <el-button @click="resetSetConfigForm(configRuleForm)">取消</el-button>
        <el-button type="primary" @click="submitSetConfigForm(configRuleForm)">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script setup>
import api from './server/api.js'
import { ref, reactive, onMounted, watch, nextTick } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import fieldConfig from './config/fieldConfig.js'

const tools = reactive({
  formVisible: false,
  title: '',
  // 新增配置弹窗
  showAddConfigDialog: false,
  addConfigDialogTitle: '',
})
// 配置类型列表数据初始化
let configTypeTableData = ref([])
// 配置列表数据初始化
let configListTableData = ref([])
// 新增编辑表单ref
const configRuleForm = ref(null)
// 新增表单校验规则
const addconfigTypeFormRules = ref({
  dictName: [{ required: true, message: '请输入类型名称', trigger: 'blur' }],
  dictCode: [{ required: true, message: '请输入类型编码', trigger: 'blur' }],
  dictSort: [{ required: true, message: '请输入排序号', trigger: 'blur' }],
})
// 新增配置类型
const addConfigItem = () => {
  configRuleForm.value?.resetFields()
  tools.addConfigDialogTitle = '新增配置类型'
  tools.showAddConfigDialog = true
}
// 新增配置类型表单
const configFrom = ref({
  dictName: '',
  dictCode: '',
  dictSort: null,
  dictTypeCode: 'config_group',
  dictTypeId: '1353547215422132226',
  dictTypeName: '系统配置分组',
})
// 新增配置类型表单确认按钮
const submitConfigForm = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      api.addConfigType(configFrom.value).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('新增成功')
          tools.showAddConfigDialog = false
          getConfigTypeData()
        } else {
          ElMessage.warning(res.message)
        }
      })
    } else {
      console.log('error submit!', fields)
    }
  })
}
// 新增配置类型表单取消按钮
const resetConfigForm = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
  tools.showAddConfigDialog = false
}
// 删除配置类型
const delConfigItem = () => {
  ElMessageBox.confirm(`确定要删除选中的类型吗？`, '提示', {
    type: 'warning',
  })
    .then(() => {
      let params = {
        dictId: activedRowData.value.dictId,
      }
      api.deleteConfigType(params).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('删除成功')
          getConfigTypeData()
        } else {
          ElMessage.error(res.message)
        }
      })
    })
    .catch(() => {})
}
// 配置列表搜索条件
const searchForm = reactive({
  groupCode: '',
  configName: '',
  configCode: '',
})
// 已选中选中行
let activedRow = ref('')
// 已选中行数据
let activedRowData = ref({})
// 选中行
const chooseRow = (val) => {
  if (val) {
    activedRowData.value = val
    activedRow.value = val.dictId
    getConfigData()
  }
}
const tableRef = ref(null)
const refFormContainer = ref(null)
const addOrgRef = ref(null)

// //////////////////// 新增\编辑 配置弹窗 ////////////////////
// 弹窗标识
let showSetConfigFlag = ref(false)
// 弹窗标题
let setConfigTitle = ref('')
// 弹窗表单初始化
let setConfigFrom = ref({
  configName: '',
  configCode: '',
  configValue: '',
  sysFlag: '',
  groupCode: '',
  remark: '',
})
// 新增\编辑 配置表单校验规则
let setConfigFromRules = ref({
  configName: [{ required: true, message: '请输入类型名称', trigger: 'blur' }],
  configCode: [{ required: true, message: '请输入类型编码', trigger: 'blur' }],
  configValue: [{ required: true, message: '请输入排序号', trigger: 'blur' }],
})
// 配置新增按钮
const add = () => {
  setConfigTitle.value = '添加系统配置'
  // 新增弹窗数据装填
  setConfigFrom.value = {
    configId: '',
    configName: '',
    configCode: '',
    configValue: '',
    sysFlag: '',
    remark: '',
  }
  showSetConfigFlag.value = true
}
// 弹窗确认提交按钮
const submitSetConfigForm = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    setConfigFrom.value.groupCode = activedRowData.value.dictCode
    if (valid) {
      // 新增调用新增接口
      if (setConfigTitle.value == '添加系统配置') {
        api.addSetConfig(setConfigFrom.value).then((res) => {
          if (res.code == '00000') {
            ElMessage.success('新增成功')
            showSetConfigFlag.value = false
            getConfigData()
          } else {
            ElMessage.warning(res.message)
          }
        })
      } else {
        api.editSetConfig(setConfigFrom.value).then((res) => {
          if (res.code == '00000') {
            ElMessage.success('编辑成功')
            showSetConfigFlag.value = false
            getConfigData()
          } else {
            ElMessage.warning(res.message)
          }
        })
      }
    } else {
      console.log('error submit!', fields)
    }
  })
}
// 弹窗取消按钮
const resetSetConfigForm = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
  showSetConfigFlag.value = false
}
// 修改按钮弹窗控制
const table_edit = (row) => {
  setConfigTitle.value = '修改系统配置'
  // 修改弹窗数据装填
  setConfigFrom.value = {
    configId: row.configId,
    configName: row.configName,
    configCode: row.configCode,
    configValue: row.configValue,
    sysFlag: row.sysFlag,
    remark: row.remark,
  }
  showSetConfigFlag.value = true
}
// 列表删除方法
const table_del = (row) => {
  api.deleteSetConfig({ configId: row.configId }).then((res) => {
    if (res.code == '00000') {
      ElMessage.success('删除成功')
      getConfigData()
    } else {
      ElMessage.warning(res.message)
    }
  })
}

// /////////////////配置类型列表分页数据/////////////////

//当前页数
let page = ref(1)
//一页多少条
let pageSize = ref(20)
//总条数
let total = ref(0)
//切换页数
const currentPageChange = (val) => {
  page.value = Number(val.toString().split('.')[0])
  getConfigTypeData()
}
//切换每页条数
const pageSizeChange = (val) => {
  pageSize.value = val
  getConfigTypeData()
}

// 获取配置类型列表数据
const getConfigTypeData = () => {
  let params = {
    pageNo: page.value,
    pageSize: pageSize.value,
  }
  api.getConfigTypeList({ ...params }).then((res) => {
    configTypeTableData.value = res.data.rows
    // 设置配置类型默认值
    activedRow.value = configTypeTableData.value[0].dictId || ''
    // 设置配置默认列表
    activedRowData.value = configTypeTableData.value[0]
    total.value = res.data.totalRows
  })
}
// 👇👇👇👇👇👇👇👇👇配置列表分页数据👇👇👇👇👇👇👇👇👇👇👇
// 操作记录分页当前页数
let OPpage = ref(1)
// 操作记录分页一页多少条
let OPpageSize = ref(20)
// 操作记录分页总条数
let OPtotal = ref(0)
// 操作记录分页切换页数
const OPcurrentPageChange = (val) => {
  OPpage.value = Number(val.toString().split('.')[0])
  getConfigData()
}
// 操作记录分页切换每页条数
const OPpageSizeChange = (val) => {
  OPpageSize.value = val
  getConfigData()
}
// 👆👆👆👆👆👆👆👆👆操作记录分页数据👆👆👆👆👆👆👆👆👆👆👆
// 获取配置列表数据
const getConfigData = () => {
  let params = {
    pageNo: OPpage.value,
    pageSize: OPpageSize.value,
  }
  // 数据装填
  searchForm.groupCode = activedRowData.value.dictCode
  api.getConfigList({ ...params, ...searchForm }).then((res) => {
    configListTableData.value = res.data.rows
    OPtotal.value = res.data.totalRows
  })
}
// 搜索按钮
const upsearch = () => {
  getConfigData()
}
// 重置按钮
const reset = () => {
  searchForm.groupCode = ''
  searchForm.configName = ''
  getConfigData()
}

onMounted(() => {
  getConfigTypeData()
  setTimeout(() => {
    getConfigData()
  }, 300)
})
</script>

<style scoped lang="scss">
.showTooltip {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.bodyPage {
  display: flex;
  justify-content: space-between;
  .leftButton {
    display: flex;
    align-items: center;
    .forbidden {
      margin-left: 20px;
    }
  }
}
</style>
