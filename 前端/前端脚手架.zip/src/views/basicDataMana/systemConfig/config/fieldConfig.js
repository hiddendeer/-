import { vali } from "./validateFunc.js"; // 自定义校验方法

export default {
    buttonConfig: [
        {
            type: 'default',
            label: '取消',
        },
        {
            type: 'primary',
            label: '确定',
            hasEmit: true,
            status: 'submit'
        },
    ],
    fieldParams: [
        {
            type: "input",
            label: "账号",
            model: "account",
            placeholder: "请输入账号",
            rule: [{ required: true, message: '请输入账号' }],
            span: 12
        },
        {
            type: "input",
            label: "姓名",
            model: "realName",
            placeholder: "请输入姓名",
            span: 12
        },
        // 编辑隐藏
        {
            type: "password",
            label: "登录密码",
            model: "password",
            placeholder: "请输入登录密码",
            rule: { required: true, message: '请输入登录密码', trigger: ['blur', 'change'] },
            span: 12
        },
        {
            type: "input",
            label: "昵称",
            model: "nickName",
            placeholder: "请输入昵称",
            span: 12
        },
        // 编辑隐藏
        {
            type: "password",
            label: "确认密码",
            model: "repeatPassword",
            placeholder: "请输入确认密码",
            rule: { required: true, message: '请输入确认密码', trigger: ['blur', 'change'] },
            span: 12
        },
        {
            type: "select",
            label: "性别",
            model: "sex",
            placeholder: "请选择性别",
            options: [
                {
                    value: "M",
                    label: "男",
                },
                {
                    value: "F",
                    label: "女",
                }
            ],
            span: 12
        },
        {
            type: "cascader",
            label: "机构",
            model: "orgId",
            placeholder: "请选择上级机构",
            options: [],
            props: {
                value: "id",
                label: "name",
                checkStrictly: true
            },
            rule: { required: true, message: '请选择上级机构', trigger: ['blur','change'] },
            data: [],
            span: 12
        },
        {
            type: "date-picker",
            label: "出生日期",
            model: "birthday",
            placeholder: "请选择出生日期",
            span: 12
        },
        {
            type: "select",
            label: "职位",
            model: "positionId",
            placeholder: "请选择职务",
            options: [],
            span: 12
        },
        {
            type: "input",
            label: "邮箱",
            model: "email",
            placeholder: "请输入邮箱",
            span: 12
        },
        {
            type: "input",
            label: "手机号",
            model: "phone",
            placeholder: "请输入手机号",
            span: 12
        }
    ]
}