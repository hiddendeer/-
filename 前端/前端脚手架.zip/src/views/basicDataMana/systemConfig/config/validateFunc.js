// 自定义校验必填项
export const vali = (rule, value, callback) => {
    if (!value)  return callback(new Error('请输入内容'))
}
