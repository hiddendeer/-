<template>
  <div>
    <el-dialog v-model="props.showDialog" title="用户分配角色" @closed="close" width="30vw" :close-on-click-modal="false">
      <el-tree ref="treeRef" class="menu" node-key="id" :data="treeData" :props="defaultProps" show-checkbox
        :default-checked-keys="selected" highlight-current :expand-on-click-node="false" @check-change="handleCheckChange" />
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="close">取消</el-button>
          <el-button type="primary" @click="submitForm">保存</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { toRefs, ref, reactive, nextTick } from "vue";
import { ElMessage } from "element-plus";
import api from "../server/api";

const emits = defineEmits(['update:showDialog', "submit", "close"]);
const props = defineProps({
  showDialog: {
    type: Boolean,
    default: false
  },
  userId: {
    type: String,
    default: ''
  }
});
const treeRef = ref(null);
// 组织树格式
const defaultProps = reactive({
  id: "id",
  label: "name",
});
const treeData = ref([]);
const selected = ref([]);

const queryList = async () => {
  const res = await api.getRoleList();
  if ( res.code == "00000" && res.data ) {
    treeData.value = res.data;
  }
  const selectRes = await api.getUserRoles({ userId: props.userId });
  if ( selectRes.code == "00000" && selectRes.data ) {
    selected.value = selectRes.data.map( item => item.roleId );
    treeRef.value.setCheckedKeys(selected.value);
  }
}

const handleCheckChange = (data,checked) => {
  if(checked){
    selected.value.push( data.id );
  }else{
    selected.value = selected.value.filter(item => item != data.id);
  }
}

const close = () => {
  emits("update:showDialog", false);
}
const submitForm = async () => {
  emits("submit",selected.value)
}
defineExpose({
  queryList
})
</script>

<style scoped lang="scss">
  ::v-deep(.el-dialog__body) {
    max-height: 200px !important;
    overflow: auto;
  }
</style>
