<template>
  <div>
    <el-dialog
      :title="props.title"
      v-model="props.showAdd"
      width="30vw"
      :close-on-click-modal="false" 
      @closed="close"
    >
      <el-form ref="ruleFormRef" :model="form" :rules="rules" label-width="120px" v-loading="loading">
        <el-form-item label="上级机构: " prop="orgParentId" required>
          <el-cascader v-model="form.orgParentId" placeholder="请选择上级机构" :options="depts"
            :props="deptsProps" clearable style="width: 100%;" @change="changeOrg" />
        </el-form-item>
        <el-form-item label="机构名称: " prop="orgName" required>
          <el-input v-model="form.orgName" :formatter="(value) => value.replace(/^\s+|\s+$/g, '')"
            placeholder="请输入机构名称" />
        </el-form-item>
        <el-form-item label="机构编码: " prop="orgCode" required>
          <el-input v-model="form.orgCode" :formatter="(value) => value.replace(/^\s+|\s+$/g, '')"
            placeholder="请输入机构编码" />
        </el-form-item>
        <el-form-item label="排序号: " prop="orgSort">
          <el-input-number placeholder="请输入排序号" style="text-align: left;width: 100%;" v-model="form.orgSort"
            :min="1" :step="1" step-strictly controls-position="right" />
        </el-form-item>
        <el-form-item label="备注: " prop="orgRemark">
          <el-input v-model="form.orgRemark" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="close">取消</el-button>
          <el-button type="primary" @click="submitForm">保存</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import api from "../server/api";

const emits = defineEmits(['update:showAdd', "updateOrg"]);
const props = defineProps({
  showAdd: {
    type: Boolean,
    default: false
  },
  title: {
    type: String,
    default: ''
  },
  editId: {
    type: String,
    default: ''
  },
});
const form = ref({
  orgParentId: '',
  orgName: '',
  orgCode: '',
  orgSort: '',
  orgRemark: ''
});
const loading = ref(false);
const deptsProps = reactive({
  value: "id",
	label: "name",
  checkStrictly: true
});
const ruleFormRef = ref(null);
const depts = ref([]);
const rules = reactive({
  orgParentId: [
    { required: true, message: '请选择上级机构', trigger: ['change', 'blur'] },
  ],
  orgName: [
    { required: true, message: '请输入机构名称', trigger: ['change', 'blur'] },
  ],
  orgCode: [
    { required: true, message: '请输入机构编码', trigger: ['change', 'blur'] },
  ],
})
onMounted(() => {
  getOrg();
});
const getOrg = async () => {
  let res = await api.getTree();
  if (res.code == '00000' && res.data) {
    depts.value = res.data;
  }
};
// 选择上级机构
const changeOrg = (val) => {
	if (val) form.value.orgParentId = val[val.length - 1];
};
// 获取详情
const queryDetail = async(val) => {
  loading.value = true;
  let res = await api.orgDetail({ orgId: val });
  loading.value = false;
  if (res.code == '00000' && res.data) {
    form.value = res.data;
  }
};
const submitForm = async () => {         
  ruleFormRef.value?.validate(async (valid, fields) => {
    if (valid) {
      loading.value = true;
      let apiName = 'addOrg';
      if ( props.editId ) apiName = 'editOrg';
      let res = await api[`${apiName}`](form.value);
      if (res.success) {
        loading.value = false;
        ElMessage.success('操作成功!');
        close();
        emits("updateOrg");
      }
      else {
        loading.value = false;
        ElMessage.error(res.message)
      }
    }
  })
};
const close = () => {
  ruleFormRef.value?.resetFields();
  emits("update:showAdd", false);
};
defineExpose({
  queryDetail
})
</script>

<style scoped lang="scss">
</style>

