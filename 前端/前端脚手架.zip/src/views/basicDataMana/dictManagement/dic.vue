<template>
  <el-dialog
    v-bind="$attrs"
    v-model="visible"
    width="35%"
    destroy-on-close
    @closed="$emit('closed')"
  >
  <!-- label-width="80px" -->
    <el-form
      :model="form"
      :rules="rules"
      ref="dialogForm"
      v-bind="$attrs"
      label-position="right"
    >
      <el-form-item label="字典名称" prop="dictTypeName">
        <el-input v-model="form.dictTypeName" placeholder="字典名称"></el-input>
      </el-form-item>
      <el-form-item label="字典编码" prop="dictTypeCode">
        <el-input v-model="form.dictTypeCode" placeholder="字典编码"></el-input>
      </el-form-item>
      <el-form-item label="字典排序" prop="dictTypeSort">
        <el-input
          v-model="form.dictTypeSort"
          type="number"
          placeholder="字典排序"
        ></el-input>
      </el-form-item>
      <el-form-item label="字典描述" prop="dictTypeDesc">
        <el-input
          v-model="form.dictTypeDesc"
          clearable
          placeholder="字典描述"
        ></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取 消</el-button>
      <el-button type="primary" :loading="isSaveing" @click="submit()"
        >保 存</el-button
      >
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import api from "./server/api.js";
import { reactive, ref } from "vue";
import { ElMessage } from "element-plus";

const emits = defineEmits(["success", "closed"]);
// //表单接口
interface Form {
  id: string;
  dictTypeName: string;
  dictTypeCode: string;
  dictTypeClass: number;
  dictTypeDesc: string;
  dictTypeSort: string;
}

// 表单数据
const form = ref<Form>({
  id: "",
  dictTypeName: "",
  dictTypeCode: "",
  dictTypeClass: 1,
  dictTypeDesc: "",
  dictTypeSort: "",
});

// 控制显隐
const visible = ref<Boolean>(false);
const isSaveing = ref<Boolean>(false);

// ref dom
const dialogForm = ref<any>(null);

// rule
const rules = reactive<Object>({
  dictTypeName: [
    { required: true, message: "请输入字典名称", trigger: "blur" },
    {
      pattern: /^[0-9a-zA-Z一-龟,.。，]*$/,
      message: "不能输入特殊字符",
      trigger: "blur",
    },
    { min: 1, max: 10, message: "不能超过10个字符", trigger: "blur" },
  ],
  dictTypeCode: [
    { required: true, message: "请输入字典编码", trigger: "blur" },
    { min: 1, max: 10, message: "不能超过10个字符", trigger: "blur" },
    {
      pattern: /^[0-9a-zA-Z,.。，]*$/,
      message: "请输入英文或数字",
      trigger: "change",
    },
  ],
  dictTypeSort: [
    { required: true, message: "请输入字典排序", trigger: "blur" },
    { min: 1, max: 10, message: "不能超过10个字符", trigger: "blur" },
  ],
});

// 组件级参数
const dicProps = ref<Object>({
  value: "id",
  label: "name",
  emitPath: false,
  checkStrictly: true,
});
const mode = ref<string>("add");

const open = (modeType: string) => {
  mode.value = modeType;
  visible.value = true;
};

const submit = async () => {
  dialogForm.value.validate(async (valid: Boolean) => {
    if (valid) {
      isSaveing.value = true;
      const res = await api.addDictTree(form.value);
      isSaveing.value = false;
      if (res.code == "00000") {
        emits("success", form.value, mode.value);
        visible.value = false;
        ElMessage({
          type: "success",
          message: "操作成功",
        });
      } else {
        ElMessage({
          type: "error",
          message: res?.message,
        });
      }
    }
  });
};

const setData = (data: Form) => {
  form.value.id = data.id;
  form.value.dictTypeName = data.dictTypeName;
  form.value.dictTypeCode = data.dictTypeCode;
};

defineExpose({
  open,
  setData,
});
</script>


