export default {
    "buttonConfig": [
        {
            "type": "default",
            "label": "取消"
        },
        {
            "type": "primary",
            "label": "提交",
            "hasEmit": true,
            "status": "submit"
        }
    ],
    "useConfig": {
        "viewStatus": true
    },
    "fieldParams": [
        {
            "type": "input",
            "label": "姓名：",
            "model": "userName",
            "placeholder": "请输入人员姓名",
            "rule": [
                {
                    "required": true,
                    "message": "请输入人员姓名",
                    "trigger": "blur"
                }
            ],
            "span": 12,
            "inputlimit": true,
            "regExp": "/[^\\u4E00-\\u9FA5A-Za-z（）()]/g"
        },
        {
            "type": "solt",
            "label": "性别：",
            "model": "userSex",
            "span": 12
        },
        {
            "type": "soltV2",
            "label": "手机号码：",
            "model": "mobile",
            "placeholder": "请输入手机号码",
            "span": 12
        },
        {
            "type": "soltV2",
            "label": "密码：",
            "model": "password",
            "span": 12
        },
        {
            "type": "soltV2",
            "label": "擅长领域：",
            "model": "domain",
            "span": 12
        },
        {
            "type": "cascader",
            "label": "部门：",
            "model": "dept",
            "placeholder": "请选择部门",
            "rule": [
                {
                    "required": true,
                    "message": "请选择部门",
                    "trigger": "change"
                }
            ]
        },
        {
            "type": "soltV2",
            "label": "主要负责人：",
            "model": "role",
            "span": 12
        },
        {
            "type": "soltV2",
            "label": "岗位：",
            "model": "station",
            "span": 12
        },
        {
            "type": "select",
            "label": "专家库：",
            "model": "expertDb",
            "span": 12,
            "rule": [
                {
                    "required": true,
                    "message": "请选择填报人（机构联系人）",
                    "trigger": "change"
                }
            ],
            "placeholder": "请选择专家库",
            "apiOptions": true,
            "optionstype": "dict",
            "apiconfig": {
                "url": process.env.VUE_APP_MASK_BASE+"/baseAgency/codeValue/RYZZXX_ZJK",
                "method": "get",
                "headers": {
                    "ProjectId": "5ce59c15d348ca1cc61ed6cd5d096aaf"
                }
            },
            "openlocalstorage": true,
            "storagename": "expertDb"
        },
        {
            "type": "select",
            "label": "职称：",
            "model": "title",
            "placeholder": "请选择员工职称",
            "rule": [
                {
                    "required": true,
                    "message": "请选择员工职称",
                    "trigger": "blur"
                }
            ],
            "span": 12,
            "apiOptions": true,
            "optionstype": "dict",
            "apiconfig": {
                "url": process.env.VUE_APP_MASK_BASE+"/baseAgency/codeValue/RYZZXX_ZC",
                "method": "get",
                "headers": {
                    "ProjectId": "5ce59c15d348ca1cc61ed6cd5d096aaf"
                }
            },
            "openlocalstorage": true,
            "storagename": "title"
        },
        {
            "type": "solt",
            "label": "地区：",
            "model": "region",
            "span": 12,
            "rule": [
                {
                    "required": true,
                    "message": "请选择地区",
                    "trigger": [
                        "blur"
                    ]
                }
            ]
        },
        {
            "type": "input",
            "label": "常住所在地市：",
            "model": "residentAddr",
            "placeholder": "请填写常住所在地市",
            "span": 12,
            "inputlimit": true,
            "regExp": "/[^\\u4E00-\\u9FA5A-Za-z\\d]/g",
            "maxlength": 50
        },
        {
            "type": "select",
            "label": "政治面貌：",
            "model": "politics",
            "span": 12,
            "apiOptions": true,
            "optionstype": "dict",
            "apiconfig": {
                "url": process.env.VUE_APP_MASK_BASE+"/baseAgency/codeValue/RYZZXX_ZZMM",
                "method": "get",
                "headers": {
                    "ProjectId": "5ce59c15d348ca1cc61ed6cd5d096aaf"
                }
            },
            "openlocalstorage": true,
            "storagename": "politics"
        },
        {
            "type": "input",
            "label": "电子邮箱：",
            "model": "email",
            "placeholder": "请输入电子邮箱",
            "rule": [
                {
                    "required": true,
                    "message": "请输入电子邮箱",
                    "trigger": "blur"
                },
                {
                    "pattern": "/^[A-Za-z0-9\\u4e00-\\u9fa5]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$/",
                    "message": "格式错误",
                    "trigger": [
                        "blur"
                    ]
                }
            ],
            "inputlimit": true,
            "regExp": "/[^A-Za-z\\d@.]/g",
            "span": 12
        },
        {
            "type": "solt",
            "label": "最高学历：",
            "model": "education",
            "span": 24
        },
        {
            "type": "solt",
            "label": "资质证书：",
            "model": "aptitudeCrt",
            "span": 24
        },
        {
            "type": "solt",
            "label": "执业证：",
            "model": "license",
            "span": 24
        },
        {
            "type": "solt",
            "label": "在本单位参保：",
            "model": "insured",
            "span": 24
        },
        {
            "type": "solt",
            "label": "单位参保证明：",
            "model": "unitInsuranceProve",
            "span": 24
        }
    ]
}