<template>
  <!-- 标题 -->
  <el-col v-if="item.type == `title` && aliasItem(item)" :span="item.span || 10">
    <div class="pl-5 mb-3 font-bold text-xl text-slate-900">
      {{ item.label }}
    </div>
  </el-col>
  <!-- input 输入框 -->
  <el-col v-if="(item.type == `input` || item.type == `password`) && aliasItem(item)" :span="item.span || 10">
    <el-form-item :prop="item.model" :label="item.label">
      <el-input
        v-model="formObj[item.model]"
        :type="item.type"
        :clearable="item.clearable"
        :style="item.classStyle || { width: '300px' }"
        :show-password="item.type == `password`"
        :placeholder="!formEditStatus ? ' ' : item.placeholder || ''"
        :disabled="!formEditStatus"
        :readonly="item?.readonly"
        :maxlength="item.maxlength || 9999999"
        @input="
          () => {
            item.inputlimit ? (formObj[item.model] = formObj[item.model].replace(getRegExp(item.regExp), '')) : ''
          }
        "
      />
    </el-form-item>
  </el-col>
  <!-- textarea 多文本框-->
  <el-col v-if="item.type == `textarea` && aliasItem(item)" :span="item.span || 20">
    <el-form-item :label="item.label" :prop="!formEditStatus ? item.model : ''">
      <el-input
        v-model="formObj[item.model]"
        type="textarea"
        :disabled="!formEditStatus"
        :resize="!formEditStatus ? 'none' : 'both'"
        :rows="item.config && item.config.row ? item.config.row : 5"
        :clearable="item.clearable"
      />
    </el-form-item>
  </el-col>
  <!-- select 选择框-->
  <el-col v-if="item.type == `select` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-select
        v-model="formObj[item.model]"
        :placeholder="!formEditStatus ? ' ' : item.placeholder || ''"
        class="w-full"
        v-if="formEditStatus"
        :clearable="item.clearable"
        :multiple="!!item.multiple"
        :style="item.classStyle || { width: '300px' }"
      >
        <el-option v-for="i in item.options" :key="i.value" :label="i?.label ? i?.label : i[item?.props?.label]" :value="item.checkSelf ? i : i[item?.props?.value || 'value']"></el-option>
      </el-select>
      <span v-else>{{ textComputed(item) }}</span>
    </el-form-item>
  </el-col>
  <!-- tree-select 选择框-->
  <el-col v-if="item.type == `tree-select` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-tree-select
        :disabled="!formEditStatus"
        v-model="formObj[item.model]"
        :placeholder="!formEditStatus ? ' ' : item.placeholder || ''"
        class="w-full"
        :data="item.data"
        check-strictly
        :render-after-expand="false"
        :clearable="item.clearable"
      />
    </el-form-item>
  </el-col>
  <!-- switch -->
  <el-col v-if="item.type == `switch` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-switch :disabled="!formEditStatus" v-model="formObj[item.model]" inline-prompt active-text="是" inactive-text="否" />
    </el-form-item>
  </el-col>
  <!-- upload image 上传图片 -->
  <el-col v-if="item.type == `upload-image` && aliasItem(item)" :span="item.span || 24">
    <el-form-item :label="item.label" :prop="item.model">
      <el-upload
        v-model:file-list="imageObj.imageList"
        :disabled="!formEditStatus"
        :class="{
          hiddenUploadImage: item.config && item.config.limit ? imageObj.imageList.length >= item.config.limit : imageObj.imageList.length >= 5,
        }"
        :on-change="_uploadImage"
        :on-remove="_removeImage"
        :limit="item.config && item.config.limit ? item.config.limit : 5"
        accept=".jpg,.JPG,.png,.PNG"
        :auto-upload="false"
        list-type="picture-card"
      >
        <template #trigger>
          <el-icon class="avatar-uploader-icon" size="3em">
            <Plus />
          </el-icon>
        </template>
      </el-upload>
    </el-form-item>
  </el-col>
  <!-- upload video 上传视频 -->
  <el-col v-if="item.type == `upload-video` && aliasItem(item)" :span="item.span || 24">
    <el-form-item :label="item.label" :prop="item.model">
      <el-upload
        v-model:file-list="videoObj.videoList"
        :before-upload="_beforeVideoUpload"
        :disabled="!formEditStatus"
        :on-remove="_removeVideo"
        :class="{
          hiddenUploadVideo: item.config && item.config.limit ? videoObj.videoList.length >= item.config.limit : videoObj.videoList.length >= 5,
        }"
        :http-request="_uploadVideo"
        :limit="item.config && item.config.limit ? item.config.limit : 5"
        accept=".mp4,.MP4"
        action=""
      >
        <template #trigger>
          <el-button type="primary" :icon="Upload">本地上传</el-button>
        </template>
      </el-upload>
    </el-form-item>
  </el-col>
  <!-- date-picker -->
  <el-col v-if="item.type == `date-picker` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-date-picker
        v-model="formObj[item.model]"
        @change="_changeDatePicker"
        :clearable="item.clearable"
        :type="item.config && item.config.type ? item.config.type : `date`"
        :format="item.format || 'YYYY-MM-DD'"
        :value-format="item.valueformat || 'YYYY-MM-DD HH:mm:ss'"
        :placeholder="!formEditStatus ? ' ' : item.placeholder || `请选择日期`"
        :style="item.classStyle || { width: '300px' }"
        :disabled="!formEditStatus"
      />
    </el-form-item>
  </el-col>
  <!-- 评分 -->
  <el-col v-if="item.type == `rate` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-rate :disabled="!formEditStatus" v-model="formObj[item.model]" />
    </el-form-item>
  </el-col>
  <!-- 级联选择器 -->
  <el-col v-if="item.type == `cascader` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-cascader
        :disabled="!formEditStatus"
        v-model="formObj[item.model]"
        :placeholder="!formEditStatus ? ' ' : item.placeholder || `请选择`"
        :props="item.props"
        :options="item.options"
        clearable
        :show-all-levels="!!item?.alllevel"
        :clearable="item.clearable"
        @change="(val) => _changeCascader(val, item.model)"
        :style="item.classStyle || { width: '300px' }"
      />
    </el-form-item>
  </el-col>
  <!-- 单选框 -->
  <el-col v-if="item.type == `radio` && aliasItem(item)" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <div v-if="formEditStatus">
        <el-radio-group v-if="!item.toObject" v-model="formObj[item.model]" :disabled="!formEditStatus">
          <el-radio v-for="i in item.options" :key="i[item?.props?.value || 'value']" :label="i[item?.props?.value || 'value']">{{ i[item?.props?.label || 'label'] }}</el-radio>
        </el-radio-group>
        <el-radio-group v-else v-model="formObj[item.model][item.bindvalue]" :disabled="!formEditStatus">
          <el-radio
            v-for="i in item.options"
            :key="i[item?.props?.value || 'value']"
            :label="i[item?.props?.value || 'value']"
            @change="
              (label) => {
                toFnc(label, item)
              }
            "
          >
            {{ i[item?.props?.label || 'label'] }}
          </el-radio>
        </el-radio-group>
      </div>
      <span v-else>{{ textComputed(item) }}</span>
    </el-form-item>
  </el-col>
  <!-- 多选框 -->
  <el-col v-if="item.type == `checkbox`" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <el-checkbox-group v-model="formObj[item.model]" v-if="formEditStatus">
        <el-checkbox v-for="i in item.options" :key="item.checkSelf ? i : i[item?.props?.label || 'label']" :label="item.checkSelf ? i : i[item?.props?.value || 'value']">
          {{ i[item?.props?.label || 'label'] }}
        </el-checkbox>
      </el-checkbox-group>
      <span v-else>{{ textComputed(item) }}</span>
    </el-form-item>
  </el-col>
  <!-- 插槽 -->
  <el-col v-if="item.type == `solt`" :span="item.span || 10">
    <el-form-item :label="item.label" :prop="item.model">
      <slot :name="item.model"></slot>
    </el-form-item>
  </el-col>
  <!-- 插槽V2 -->
  <el-col v-if="item.type == `soltV2` && aliasItem(item)" :span="item.span || 10">
    <slot :name="item.model"></slot>
  </el-col>
</template>
<script setup>
import { ref, computed, watchEffect, watch } from 'vue'
let props = defineProps({
  item: {
    type: Object,
    default: () => {
      return {}
    },
  },
  totalitem: {
    type: Object,
    default: () => {
      return {}
    },
  },
  formObj: {
    type: Object,
  },
  editstatus: {
    type: Boolean,
    default: true,
  },
  stringToFnc: {
    type: Function,
    default: () => {
      return () => {}
    },
  },
})
const emits = defineEmits(['keyEmits'])
let item = ref(props.item)
let totalitem = ref(props.totalitem)
let valueCallback = new Map([
  ['radio', null],
  ['checkbox', []],
])
let formObj = ref(null)
function getValueByType(type) {
  if (type === 'radio' && !!item.value?.toObject) {
    return {}
  } else if (type === 'checkbox' || (type === 'select' && item.value.multiple)) {
    return []
  } else {
    return null
  }
}
watch(
  () => props.formObj,
  (nval) => {
    formObj.value = {
      [item.value.model]: nval != null && nval != undefined ? nval : getValueByType(item.value.type),
    }
  },
  { immediate: true, deep: true }
)
watch(
  () => formObj.value,
  (nval) => {
    let returndata
    if (!!totalitem.value?.model) {
      returndata = {}
      if (item.value.type == 'radio' || item.value.type == 'checkbox') {
        returndata = nval[item.value.model]
      }
    } else {
      returndata = _.cloneDeep(nval)
    }
    emits('keyEmits', item.value.model, returndata, totalitem.value)
  },
  { immediate: true, deep: true }
)
const toFnc = (label, item) => {
  if (!item.cusfnc) {
    formObj.value[item.model] = label
    return
  }
  const code = item.cusfnc
  const myFunc = eval(`(${code})`)
  myFunc(label, item)
}
let formEditStatus = computed(() => {
  return props.editstatus
})
const aliasItem = (curItem) => {
  let { alias, aliasconfig } = curItem
  if (!alias) return true
  if (!!alias) {
    let { aliasTarget: target, aliasShowValue: value, hasSubAlias } = aliasconfig || {}
    if (!target) return true
    if ((value == null || value == undefined) && !!hasSubAlias) {
      let { aliasconfig: subconfig } = aliasconfig
      let { aliasTarget: subTarget, aliasShowValue: subValue } = subconfig || {}
      return formObj.value[target][subTarget] == subValue
    }
  }
  return true
}
const getRegExp = (str) => {
  return eval(str)
}
// 文本回显
const textComputed = (item, concatCode = '、') => {
  let { props, checkSelf, model, options, type, multiple } = item
  if (!model || !options) return ''
  let arr = []
  if ((type == 'select' && !!multiple) || type == 'checkbox') {
    let looparr = []
    if (Array.isArray(formObj.value[model])) {
      looparr = _.cloneDeep(formObj.value[model])
    }
    options.forEach((ele) => {
      if (
        looparr?.some((inner) => {
          return !!checkSelf ? inner[props?.value || 'value'] == ele.value : inner == ele.value
        })
      ) {
        arr.push(ele[props?.label || 'label'])
      }
    })
    return arr.length ? arr.join(concatCode) : '未选择'
  } else if (type == 'radio') {
    if (!!item?.toObject) {
      return formObj?.value[model]?.text || '未选择'
    } else {
      let existItem = item?.options.find((i) => i.value == formObj?.value[model])
      return existItem?.label || '未选择'
    }
  }
  let tempdata = formObj.value[model] || {}
  if (tempdata.hasOwnProperty(props?.label || 'label')) {
    return tempdata[props?.label || 'label']
  } else {
    return ''
  }
}
</script>
