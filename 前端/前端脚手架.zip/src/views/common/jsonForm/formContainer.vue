<template>
  <el-dialog v-model="formVisible" :title="props.dialogTitle" :width="props.dialogWidth" :top="dialogTop" @close="close"
    :close-on-click-modal="false">
    <div class="p-5">
      <el-form ref="refForm" :model="formObj" :rules="rules" :label-width="props.labelWidth"
        :label-position="labelPosition">
        <el-row :gutter="20">
          <template v-for="(item, index) in fieldParams" :key="index">
            <!-- 标题 -->
            <el-col v-if="item.type == `title`" :span="item.span || 10">
              <div class="pl-5 mb-3 font-bold text-xl text-slate-900">
                {{ item.label }}
              </div>
            </el-col>
            <!-- input 输入框 -->
            <el-col v-if="item.type == `input` || item.type == `password`" :span="item.span || 10">
              <el-form-item :prop="item.rule ? item.model : ''" :label="item.label">
                <el-input v-model="formObj[item.model]" :type="item.type" :show-password="item.type == `password`"
                  :placeholder="formViewStatus ? '' : item.placeholder || ''" :disabled="item.disabled" 
                  @input="() => {item.inputlimit ? formObj[item.model] = formObj[item.model].replace(getRegExp(item.regExp), '') : ''}" />
              </el-form-item>
            </el-col>

            <!-- textarea 多文本框-->
            <el-col v-if="item.type == `textarea`" :span="item.span || 20">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-input v-model="formObj[item.model]" type="textarea"
                  :rows="item.config && item.config.row ? item.config.row : 5" />
              </el-form-item>
            </el-col>
            <!-- select 选择框-->
            <el-col v-if="item.type == `select`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-select v-model="formObj[item.model]" :placeholder="formViewStatus ? '' : item.placeholder || ''" class="w-full">
                  <el-option v-for="i in item.options" :key="i.code"
                    :label="i?.label ? i?.label : i[item?.props?.label]"
                    :value="i?.value ? i?.value : i[item?.props?.value]" />
                </el-select>
              </el-form-item>
            </el-col>
            <!-- tree-select 选择框-->
            <el-col v-if="item.type == `tree-select`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-tree-select v-model="formObj[item.model]" :placeholder="formViewStatus ? '' : item.placeholder || ''" class="w-full"
                  :data="item.data" check-strictly :render-after-expand="false" />
              </el-form-item>
            </el-col>
            <!-- switch -->
            <el-col v-if="item.type == `switch`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-switch v-model="formObj[item.model]" inline-prompt active-text="是" inactive-text="否" />
              </el-form-item>
            </el-col>
            <!-- upload image 上传图片 -->
            <el-col v-if="item.type == `upload-image`" :span="item.span || 24">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-upload v-model:file-list="imageObj.imageList" :class="{
                  hiddenUploadImage:
                    item.config && item.config.limit
                      ? imageObj.imageList.length >= item.config.limit
                      : imageObj.imageList.length >= 5,
                }" :on-change="_uploadImage" :on-remove="_removeImage" :limit="
                  item.config && item.config.limit ? item.config.limit : 5
                " accept=".jpg,.JPG,.png,.PNG" :auto-upload="false" list-type="picture-card">
                  <template #trigger>
                    <el-icon class="avatar-uploader-icon" size="3em">
                      <Plus />
                    </el-icon>
                  </template>
                </el-upload>
              </el-form-item>
            </el-col>
            <!-- upload video 上传视频 -->
            <el-col v-if="item.type == `upload-video`" :span="item.span || 24">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-upload v-model:file-list="videoObj.videoList" :before-upload="_beforeVideoUpload"
                  :on-remove="_removeVideo" :class="{
                  hiddenUploadVideo:
                    item.config && item.config.limit
                      ? videoObj.videoList.length >= item.config.limit
                      : videoObj.videoList.length >= 5,
                }" :http-request="_uploadVideo" :limit="
                  item.config && item.config.limit ? item.config.limit : 5
                " accept=".mp4,.MP4" action="">
                  <template #trigger>
                    <el-button type="primary" :icon="Upload">本地上传
                    </el-button>
                  </template>
                </el-upload>
              </el-form-item>
            </el-col>
            <!-- date-picker -->
            <el-col v-if="item.type == `date-picker`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-date-picker v-model="formObj[item.model]" @change="_changeDatePicker" 
                  :type="item.config && item.config.type ? item.config.type : `date`" 
                  format="YYYY-MM-DD" value-format="YYYY-MM-DD" :placeholder="formViewStatus ? '' : item.placeholder || `请选择日期`"
                  style="width: 100%" />
              </el-form-item>
            </el-col>
            <!-- 评分 -->
            <el-col v-if="item.type == `rate`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-rate v-model="formObj[item.model]" />
              </el-form-item>
            </el-col>
            <!-- 级联选择器 -->
            <el-col v-if="item.type == `rate`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-rate v-model="formObj[item.model]" />
              </el-form-item>
            </el-col>
            <el-col v-if="item.type == `cascader`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-cascader v-model="formObj[item.model]" :placeholder="formViewStatus ? '' : item.placeholder || `请选择`" :props="item.props"
                  :options="item.options" clearable style="width: 100%"
                  @change="(val) => _changeCascader(val, item.model)" />
              </el-form-item>
            </el-col>
            <!-- 单选框 -->
            <el-col v-if="item.type == `radio`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-radio-group v-model="formObj[item.model]">
                  {{ item.options }}
                  <el-radio v-for="i in item.options" :label="i.code">{{
                      i.label
                  }}</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <!-- 多选框 -->
            <el-col v-if="item.type == `checkbox`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <el-checkbox-group v-model="formObj[item.model]">
                  <el-checkbox v-for="i in item.options" :label="i.code">{{
                      i.name
                  }}</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
            </el-col>
            <!-- 插槽 -->
            <el-col v-if="item.type == `solt`" :span="item.span || 10">
              <el-form-item :label="item.label" :prop="item.rule ? item.model : ''">
                <slot :name="item.model"></slot>
              </el-form-item>
            </el-col>
            <!-- 插槽V2 -->
            <el-col v-if="item.type == `soltV2`" :span="item.span || 10">
              <slot :name="item.model"></slot>
            </el-col>
          </template>
        </el-row>
      </el-form>
    </div>
    <template #footer>
      <div class="flex justify-end">
        <span class="btnGroup" v-for="(item, index) in fieldConfig?.buttonConfig">
          <el-button :type="item.type" @click="triggerBtn(item)">
            {{ item.label }}
          </el-button>
        </span>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import api from "./server/api.js";
import { ElMessage } from "element-plus";
import { Upload } from "@element-plus/icons-vue";
import { onMounted, reactive, ref, watch } from "vue";

// props
const props = defineProps({
  // 弹框显隐
  formVisible: {
    type: Boolean,
    default: true,
  },
  // 字段数据
  fieldConfig: {
    type: Object,
    default: () => { },
  },
  // 弹框标题
  dialogTitle: {
    type: String,
    default: "",
  },
  // 弹框高度
  dialogTop: {
    type: String,
    default: "10vh",
  },
  // 弹框宽度
  dialogWidth: {
    type: String,
    default: "50vw",
  },
  // 表单label宽度
  labelWidth: {
    type: String,
    default: "120px",
  },
  // 表单对齐方式
  labelPosition: {
    type: String,
    default: "left",
  },
});
// 获取正则表达式
const getRegExp = (str) => {
  return eval(str)
}
let formVisible = ref(true)
const emits = defineEmits(["update:formVisible", "change"]);

//form ref
const refForm = ref(null);

/**
 * 表单变量集合
 */
const formViewStatus = ref(props.useConfig?.viewStatus || false)
const fieldParams = ref(props.fieldConfig?.fieldParams || []); // 配置字段
const formObj = ref({
}); // 表单数据
const rules = reactive({}); // 表单验证

/**
 * 组件级变量集合
 */

const paramsConfig = reactive({
  title: "新增",
});

// 上传图片变量集合
const imageObj = reactive({
  imageList: [],
});

// 上传视频变量集合
const videoObj = reactive({
  videoList: [],
});

// rule数据处理
const _handleFieldRules = (fieldParams) => {
  // rule校验
  for (const item of fieldParams.value) {
    if (
      item.rule &&
      (Object.keys(item.rule).length > 0 || item.rule.length > 0)
    ) {
      rules[item.model] = item.rule;
    }
  }
};

/**
 * 触发按钮
 */
const triggerBtn = async (params) => {
  if (!params.hasEmit) {
    close();
    return;
  }
  refForm.value.validate((valid, fields) => {
    if (valid) {
      emits("change", { formObj: formObj.value, config: params });
    }
  });
};

/**
 * 处理配置字段rule
 */
_handleFieldRules(fieldParams);

// 上传图片处理
const _uploadImage = async (file, fileList) => {
  imageObj.imageList.forEach((item) => {
    if (item.name == file.name) {
      ElMessage.error("已上传该图片！");
      fileList.pop();
    }
  });

  // 限制大小
  const isLt = file.size / 1024 / 1024 < 2;
  if (!isLt) {
    ElMessage.error("单个文件大小不超过2MB!");
    fileList.pop();
    return false;
  }

  // 写入文件
  let formData = new FormData();
  formData.append(
    "file",
    new File([file.raw], file.name, {
      type: file.raw.type,
    })
  );

  // 处理已上传的数据
  const uploadRes = await api.uploadImage(formData);
  if (uploadRes?.code !== "00000") {
    ElMessage.error("上传API请求失败!");
    return;
  }
  if (!formObj.value.hasOwnProperty("imageList")) {
    formObj.value.imageList = [];
  }
  formObj.value.imageList.push({
    fileType: uploadRes?.data?.fileType,
    fileName: uploadRes?.data?.objectKey,
    fileUrl: uploadRes?.data?.objectUrl,
  });
};

//移除图片处理
const _removeImage = (file) => {
  formObj.value.imageList = formObj.value.imageList.filter(
    (item) => item.fileName != file.name
  );
};

/**
 * 视频处理
 */

// 上传视频前触发
const _beforeVideoUpload = (file) => {
  // 判断同视频上传
  let simStatus = true;
  for (const item of videoObj.videoList) {
    if (item.name == file.name) {
      simStatus = false;
    }
  }
  if (!simStatus) {
    ElMessage.error("已上传该视频！");
    return false;
  }

  // 限制大小
  const isLt = file.size / 1024 / 1024 < 5;
  if (!isLt) {
    ElMessage.error("单个文件大小不超过5MB!");
    return false;
  }

  // 文件名数量
  const fileName = file.name.substring(0, file.name.lastIndexOf("."));
  if (fileName.length > 50) {
    ElMessage.error("文件名限制50字符!");
    return false;
  }

  return true;
};

// 上传视频
const _uploadVideo = async (fileObj) => {
  let formData = new FormData();
  formData.append("file", fileObj.file);
  const uploadRes = await api.uploadFileVideo(formData);
  if (uploadRes?.code !== "00000") {
    ElMessage.error("上传API请求失败!");
    return;
  }
  if (!formObj.value.hasOwnProperty("videoList")) {
    formObj.value.videoList = [];
  }
  formObj.value.videoList.push({
    fileType: uploadRes?.data?.fileType,
    fileName: uploadRes?.data?.objectKey,
    fileUrl: uploadRes?.data?.objectUrl,
  });
};

// 移除视频
const _removeVideo = (file) => {
  formObj.value.videoList = formObj.value.videoList.filter(
    (item) => item.fileName != file.name
  );
};

// 获取日期 -暂无处理
const _changeDatePicker = (date) => {
  // console.log(date, '打印日期');
};

// 级联数据处理
const _changeCascader = (val, modelName) => {
  if (val) formObj.value[modelName] = val[val.length - 1];
};

/**
 * slot 传参处理
 * params {slotName: {key: val}}
 */
const slotTrigger = (params) => {
  if (Object.keys(params).length > 0) {
    for (const obj in params) {
      formObj.value[obj] = params[obj];
    }
  }
};
const resetData = () => {
  Object.keys(formObj.value).forEach((key) => {
    delete formObj.value[key];
  });
};

// 回显数据
const detailTrigger = (params) => {
  if (Object.keys(params).length > 0) {
    for (const obj in params) {
      formObj.value[obj] = params[obj];
    }
  }
};

// 监听配置参数
watch(
  () => props.fieldConfig,
  (newVal) => {
    fieldParams.value = newVal?.fieldParams;
  },
  {
    deep: true,
  }
);

//关闭弹框 & 重置表单
const close = () => {
  refForm.value.resetFields();
  emits("update:formVisible", false);
};

// 对外暴露变量方法
defineExpose({
  slotTrigger,
  detailTrigger,
  resetData,
});
</script>

<style lang="scss" scoped>
.w-full {
  width: 100%;
}

.flex {
  display: flex;
}

.justify-center {
  justify-content: center;
}

.btnGroup {
  :deep(.el-button) {
    margin-right: 20px;
  }
}

.hiddenUploadImage {
  :deep(.el-upload--picture-card) {
    display: none;
  }
}

:deep(.el-button--primary) {
  background-image: linear-gradient(to bottom,
      rgba($color: #2d69ff, $alpha: 0.7) 0%,
      rgba($color: #2d69ff, $alpha: 0) 100%);
}
</style>