<template>
  <div class="p-5">
    <el-form ref="activeFormRef" :model="formObj" :rules="rules" :label-width="props.labelWidth" :label-position="labelPosition">
      <el-row :gutter="20">
        <template v-for="(item, index) in renderFormParams" :key="index">
          <!-- 标题 -->
          <el-col v-if="item.type == `title` && aliasItem(item)" :span="item.span || 10">
            <div class="pl-5 mb-3 font-bold text-xl text-slate-900">
              {{ item.label }}
            </div>
          </el-col>
          <!-- input 输入框 -->
          <el-col v-if="(item.type == `input` || item.type == `password`) && aliasItem(item)" :span="item.span || 10">
            <el-form-item :prop="item.model" :label="item.label">
              <el-input
                v-model="formObj[item.model]"
                :type="item.type"
                :clearable="item.clearable"
                :style="item.classStyle || { width: '300px' }"
                :show-password="item.type == `password`"
                :placeholder="!formEditStatus ? ' ' : item.placeholder || ''"
                :disabled="!formEditStatus"
                :readonly="item?.readonly"
                :maxlength="item.maxlength || 9999999"
                @input="
                  () => {
                    item.inputlimit ? (formObj[item.model] = formObj[item.model].replace(getRegExp(item.regExp), '')) : ''
                  }
                "
              />
            </el-form-item>
          </el-col>
          <!-- textarea 多文本框-->
          <el-col v-if="item.type == `textarea` && aliasItem(item)" :span="item.span || 20">
            <el-form-item :label="item.label" :prop="!formEditStatus ? item.model : ''">
              <el-input
                v-model="formObj[item.model]"
                type="textarea"
                :disabled="!formEditStatus"
                :resize="!formEditStatus ? 'none' : 'both'"
                :rows="item.config && item.config.row ? item.config.row : 5"
                :clearable="item.clearable"
              />
            </el-form-item>
          </el-col>
          <!-- select 选择框-->
          <el-col v-if="item.type == `select` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-select
                v-model="formObj[item.model]"
                :placeholder="!formEditStatus ? ' ' : item.placeholder || ''"
                class="w-full"
                v-if="formEditStatus"
                :clearable="item.clearable"
                :multiple="!!item.multiple"
                :style="item.classStyle || { width: '300px' }"
              >
                <el-option v-for="i in item.options" :key="i.value" :label="i?.label ? i?.label : i[item?.props?.label]" :value="item.checkSelf ? i : i[item?.props?.value || 'value']"></el-option>
              </el-select>
              <span v-else>{{ textComputed(item) }}</span>
            </el-form-item>
          </el-col>
          <!-- tree-select 选择框-->
          <el-col v-if="item.type == `tree-select` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-tree-select
                :disabled="!formEditStatus"
                v-model="formObj[item.model]"
                :placeholder="!formEditStatus ? ' ' : item.placeholder || ''"
                class="w-full"
                :data="item.data"
                check-strictly
                :render-after-expand="false"
                :clearable="item.clearable"
              />
            </el-form-item>
          </el-col>
          <!-- switch -->
          <el-col v-if="item.type == `switch` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-switch :disabled="!formEditStatus" v-model="formObj[item.model]" inline-prompt active-text="是" inactive-text="否" />
            </el-form-item>
          </el-col>
          <!-- upload image 上传图片 -->
          <el-col v-if="item.type == `upload-image` && aliasItem(item)" :span="item.span || 24">
            <el-form-item :label="item.label" :prop="item.model">
              <el-upload
                v-model:file-list="imageObj.imageList"
                :disabled="!formEditStatus"
                :class="{
                  hiddenUploadImage: item.config && item.config.limit ? imageObj.imageList.length >= item.config.limit : imageObj.imageList.length >= 5,
                }"
                :on-change="_uploadImage"
                :on-remove="_removeImage"
                :limit="item.config && item.config.limit ? item.config.limit : 5"
                accept=".jpg,.JPG,.png,.PNG"
                :auto-upload="false"
                list-type="picture-card"
              >
                <template #trigger>
                  <el-icon class="avatar-uploader-icon" size="3em">
                    <Plus />
                  </el-icon>
                </template>
              </el-upload>
            </el-form-item>
          </el-col>
          <!-- upload video 上传视频 -->
          <el-col v-if="item.type == `upload-video` && aliasItem(item)" :span="item.span || 24">
            <el-form-item :label="item.label" :prop="item.model">
              <el-upload
                v-model:file-list="videoObj.videoList"
                :before-upload="_beforeVideoUpload"
                :disabled="!formEditStatus"
                :on-remove="_removeVideo"
                :class="{
                  hiddenUploadVideo: item.config && item.config.limit ? videoObj.videoList.length >= item.config.limit : videoObj.videoList.length >= 5,
                }"
                :http-request="_uploadVideo"
                :limit="item.config && item.config.limit ? item.config.limit : 5"
                accept=".mp4,.MP4"
                action=""
              >
                <template #trigger>
                  <el-button type="primary" :icon="Upload">本地上传</el-button>
                </template>
              </el-upload>
            </el-form-item>
          </el-col>
          <!-- date-picker -->
          <el-col v-if="item.type == `date-picker` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-date-picker
                v-model="formObj[item.model]"
                @change="_changeDatePicker"
                :clearable="item.clearable"
                :type="item.config && item.config.type ? item.config.type : `date`"
                :format="item.format || 'YYYY-MM-DD'"
                :value-format="item.valueformat || 'YYYY-MM-DD HH:mm:ss'"
                :placeholder="!formEditStatus ? ' ' : item.placeholder || `请选择日期`"
                :style="item.classStyle || { width: '300px' }"
                :disabled="!formEditStatus"
              />
            </el-form-item>
          </el-col>
          <!-- 评分 -->
          <el-col v-if="item.type == `rate` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-rate :disabled="!formEditStatus" v-model="formObj[item.model]" />
            </el-form-item>
          </el-col>
          <!-- 级联选择器 -->
          <el-col v-if="item.type == `cascader` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-cascader
                :disabled="!formEditStatus"
                v-model="formObj[item.model]"
                :placeholder="!formEditStatus ? ' ' : item.placeholder || `请选择`"
                :props="item.props"
                :options="item.options"
                clearable
                :show-all-levels="!!item?.alllevel"
                :clearable="item.clearable"
                @change="(val) => _changeCascader(val, item.model)"
                :style="item.classStyle || { width: '300px' }"
              />
            </el-form-item>
          </el-col>
          <!-- 单选框 -->
          <el-col v-if="item.type == `radio` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <div v-if="formEditStatus">
                <el-radio-group v-if="!item.toObject" v-model="formObj[item.model]" :disabled="!formEditStatus">
                  <el-radio
                    v-for="i in item.options"
                    :key="i[item?.props?.value || 'value']"
                    :label="i[item?.props?.value || 'value']"
                    @change="
                      (label) => {
                        toFnc(label, item)
                      }
                    "
                  >
                    {{ i[item?.props?.label || 'label'] }}
                  </el-radio>
                </el-radio-group>
                <el-radio-group v-else v-model="formObj[item.model][item.bindvalue]" :disabled="!formEditStatus">
                  <el-radio
                    v-for="i in item.options"
                    :key="i[item?.props?.value || 'value']"
                    :label="i[item?.props?.value || 'value']"
                    @change="
                      (label) => {
                        toFnc(label, item)
                      }
                    "
                  >
                    {{ i[item?.props?.label || 'label'] }}
                  </el-radio>
                </el-radio-group>
              </div>
              <span v-else>{{ textComputed(item) }}</span>
            </el-form-item>
          </el-col>
          <!-- 多选框 -->
          <el-col v-if="item.type == `checkbox` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <el-checkbox-group v-model="formObj[item.model]" v-if="formEditStatus">
                <el-checkbox v-for="i in item.options" :key="item.checkSelf ? i : i[item?.props?.label || 'label']" :label="item.checkSelf ? i : i[item?.props?.value || 'value']">
                  {{ i[item?.props?.label || 'label'] }}
                </el-checkbox>
              </el-checkbox-group>
              <span v-else>{{ textComputed(item) }}</span>
            </el-form-item>
          </el-col>
          <!-- 插槽 -->
          <el-col v-if="item.type == `solt` && aliasItem(item)" :span="item.span || 10">
            <el-form-item :label="item.label" :prop="item.model">
              <slot :name="item.model"></slot>
            </el-form-item>
          </el-col>
          <!-- 插槽V2 -->
          <el-col v-if="item.type == `soltV2` && aliasItem(item)" :span="item.span || 10">
            <slot :name="item.model"></slot>
          </el-col>
          <el-col v-if="item.type == 'card-group'">
            <el-card>
              <div class="group-header">
                <formitems
                  v-if="item.model"
                  :item="item.header"
                  :totalitem="item"
                  :formObj="formObj[item.model][item.header.model]"
                  :editstatus="formEditStatus"
                  :stringToFnc="toFnc"
                  @keyEmits="renewKey"
                ></formitems>
                <formitems v-else :item="item.header" :formObj="formObj[item.header.model]" :editstatus="formEditStatus" :stringToFnc="toFnc" @keyEmits="renewKey"></formitems>
              </div>
              <div v-if="aliasItem(item)" class="group-body">
                <span v-for="(child, index) in item.children">
                  <formitems
                    v-if="item.model"
                    :item="child"
                    :totalitem="item"
                    :formObj="formObj[item.model][child.model]"
                    :editstatus="formEditStatus"
                    :stringToFnc="toFnc"
                    @keyEmits="renewKey"
                  ></formitems>
                  <formitems v-else :item="child" :formObj="formObj[child.model]" :editstatus="formEditStatus" :stringToFnc="toFnc" @keyEmits="renewKey"></formitems>
                </span>
              </div>
            </el-card>
          </el-col>
        </template>
      </el-row>
    </el-form>
  </div>
</template>

<script setup>
import api from './server/api.js'
import { ElMessage, ElCard } from 'element-plus'
import { Upload } from '@element-plus/icons-vue'
import formitems from '@/views/common/jsonForm/formitems.vue'
import { onMounted, onBeforeMount, reactive, ref, watch, computed, toRef, getCurrentInstance, nextTick } from 'vue'
import _ from 'lodash'
import request from '@/utils/network.js'
const emits = defineEmits(['updateOriData'])
let proxy = getCurrentInstance().proxy
// props
const props = defineProps({
  postFormData: {
    type: Object,
    default: () => {},
  },
  // 字段数据
  fieldConfig: {
    type: Object,
    default: () => {},
  },
  // 表单label宽度
  labelWidth: {
    type: String,
    default: '120px',
  },
  // 表单对齐方式
  labelPosition: {
    type: String,
    default: 'left',
  },
  formEdit: {
    type: Boolean,
    default: false,
  },
})
/**
 * 表单变量集合
 */
// 配置字段
let fieldParams = ref(props.fieldConfig || [])
// 表单数据
let formObj = ref()
watch(
  () => props.postFormData,
  (nval) => {
    formObj.value = props.postFormData
  },
  { immediate: true }
)
// 表单验证
const rules = ref({})
// 获取正则表达式
const getRegExp = (str) => {
  return eval(str)
}
// 文本回显
const textComputed = (item, concatCode = '、') => {
  let { props, checkSelf, model, options, type, multiple } = item
  if (!model || !options) return ''
  let arr = []
  if ((type == 'select' && !!multiple) || type == 'checkbox') {
    let looparr = []
    if (Array.isArray(formObj.value[model])) {
      looparr = _.cloneDeep(formObj.value[model])
    }
    options.forEach((ele) => {
      if (
        looparr?.some((inner) => {
          return !!checkSelf ? inner[props?.value || 'value'] == ele.value : inner == ele.value
        })
      ) {
        arr.push(ele[props?.label || 'label'])
      }
    })
    return arr.join(concatCode)
  } else if (type == 'radio') {
    return formObj?.value[model]?.text || ''
  }
  let tempdata = formObj.value[model] || {}
  if (tempdata.hasOwnProperty(props?.label || 'label')) {
    return tempdata[props?.label || 'label']
  } else {
    return ''
  }
}
const toFnc = (label, item) => {
  if (!item.cusfnc) {
    formObj.value[item.model] = label
    return
  }
  const code = item.cusfnc
  const myFunc = eval(`(${code})`)
  myFunc(label, item)
}

// 表单状态
let formEditStatus = computed(() => props.formEdit)
// 表单元素
const activeFormRef = ref(null)
const aliasItem = (curItem) => {
  let { alias, aliasconfig } = curItem
  if (!alias) return true
  if (!!alias) {
    let { aliasTarget: target, aliasShowValue: value, hasSubAlias } = aliasconfig || {}
    if (!target) return true
    if ((value == null || value == undefined) && !!hasSubAlias) {
      let { aliasconfig: subconfig } = aliasconfig
      let { aliasTarget: subTarget, aliasShowValue: subValue } = subconfig || {}
      if (!!curItem?.model && curItem.type == 'card-group') {
        if (!formObj.value[curItem.model] || !formObj.value[curItem.model][target]) return false
        return formObj.value[curItem.model][target][subTarget] == subValue
      } else {
        if (!formObj.value[target]) return false
        return formObj.value[target][subTarget] == subValue
      }
    }
  }
  return true
}
const radioGroupCheck = (data, item, i) => {
  data.value = i.value
  data.text = i.label
  formObj.value[item.model] = data
}
const handleFieldParams = async (params) => {
  const paramArray = Array.isArray(params) ? params : []
  const clonedParams = _.cloneDeep(paramArray)
  await Promise.all(
    clonedParams.map(async (ele) => {
      if (ele.hasOwnProperty('apiOptions')) {
        const { apistatus } = await processApiOptions(ele)
        if (apistatus) {
          ele.options = await requestApiOptions(ele)
        }
      }
      if (ele.hasOwnProperty('children') && !!ele.children.length) {
        let innerchild = _.cloneDeep(ele.children)
        await Promise.all(
          innerchild.map(async (inner) => {
            if (inner.hasOwnProperty('apiOptions')) {
              const { apistatus } = await processApiOptions(inner)
              if (apistatus) {
                inner.options = await requestApiOptions(inner)
              }
            }
          })
        )
        ele.children = innerchild
      }
      if (!!ele.toObject && Object.prototype.toString.call(formObj.value[ele.model]) !== '[object Object]') {
      }
      ele = initializeObject(ele)
    })
  )
  renderFormParams.value = clonedParams
}

async function processApiOptions(ele) {
  let apistatus = true
  let storagestatus = false
  if (ele.hasOwnProperty('openlocalstorage') && ele?.openlocalstorage) {
    const localOptions = localStorage.getItem(ele.storagename)
    if (localOptions) {
      switch (ele.optionstype) {
        case 'list':
          let totalDicts = JSON.parse(localOptions)
          ele.options = subDistHandle(ele, totalDicts || [])
          break
        default:
          ele.options = JSON.parse(localOptions)
      }
      apistatus = !ele.options.length
    } else {
      apistatus = true
    }
    storagestatus = ele.openlocalstorage
  }
  return { apistatus, storagestatus }
}

async function requestApiOptions(eledata) {
  let ele = _.cloneDeep(eledata)
  if (ele.hasOwnProperty('localheaders')) {
    if (!ele.apiconfig?.headers) {
      ele.apiconfig.headers = {}
    }
    for (let key in ele.localheaders) {
      const value = localStorage.getItem(ele.localheaders[key]) || ''
      ele.apiconfig.headers[key] = value
    }
  }
  const res = await request(ele.apiconfig)
  if (res?.code == '00000') {
    switch (ele.optionstype) {
      case 'dict':
        ele.options = await processDictOptions(ele, res.data)
        if (ele.openlocalstorage) {
          localStorage.setItem(ele.storagename, JSON.stringify(ele.options))
        }
        break
      case 'list':
        ele.options = subDistHandle(ele, res.data)
        break
      default:
        ele.options = res.data
        if (ele.openlocalstorage) {
          localStorage.setItem(ele.storagename, JSON.stringify(ele.options))
        }
    }
  }
  return ele.options
}
// 递归查找树节点
// 递归查找树节点
// 递归查找树节点
function findNode(arr, target) {
  const node = arr.find((node) => node.dictCode === target) // 使用 find 方法查找目标节点
  if (node) {
    return node // 如果找到目标节点，返回当前节点
  }
  for (const element of arr) {
    const children = element?.children
    if (children && children.length > 0) {
      const result = findNode(children, target) // 递归查找子节点
      if (!!result) {
        return result // 如果在子节点中找到目标节点，返回结果
      }
    }
  }
  return null // 在数组及其子节点中未找到目标节点，返回 null
}

function subDistHandle(ele, handledata) {
  let emptydata = []
  localStorage.setItem(ele.storagename, JSON.stringify(handledata))
  let data = findNode(handledata, ele.substoragename)?.children || []
  data.forEach((inner) => {
    emptydata.push({
      text: inner.label,
      value: inner.dictCode,
    })
  })
  return _.cloneDeep(emptydata)
}

async function processDictOptions(ele, data) {
  const hasProps = ele.hasOwnProperty('props')
  const optionList = []
  for (let key in data) {
    let option = {}
    if (hasProps) {
      //if there is a "props" object, then it is a sub-option and it is not a dict.
      option[ele?.props['label'] || 'label'] = data[key]
      option[ele?.props['value'] || 'value'] = key
    } else {
      option.label = data[key]
      option.value = key
    }
    optionList.push(option)
  }
  return optionList
}

function initializeObject(eledata) {
  let ele = _.cloneDeep(eledata)
  if (!!ele.toObject && ele.type == 'radio') {
    if (Object.prototype.toString.call(formObj.value[ele.model]) !== '[object Object]') {
      let editData = {}
      editData[ele.bindvalue || 'value'] = ''
      editData[ele.props?.label || 'label'] = ''
      formObj.value[ele.model] = editData
      emits('updateOriData', ele.model, _.cloneDeep(editData))
    }
  }
  if (ele.type == 'checkbox' && !Array.isArray(formObj.value[ele.model])) {
    formObj.value[ele.model] = []
    emits('updateOriData', ele.model, _.cloneDeep([]))
  }
  if (!!ele?.defaultValue && !formObj.value[ele.model]) {
    formObj.value[ele.model] = ele.defaultValue
    emits('updateOriData', ele.model, _.cloneDeep(ele.defaultValue))
  }
  return ele
}
const dataFormat = () => {
  renderFormParams.value.forEach((ele) => {
    if (!!ele.toObject && ele.type == 'radio') {
      if (Object.prototype.toString.call(formObj.value[ele.model]) !== '[object Object]') {
        let editData = {}
        editData[ele.bindvalue || 'value'] = ''
        editData[ele.props?.label || 'label'] = ''
        formObj.value[ele.model] = editData
        emits('updateOriData', ele.model, _.cloneDeep(editData))
      }
    }
    if (!!ele.type == 'checkbox' && !Array.isArray(formObj.value[ele.model])) {
      formObj.value[ele.model] = []
      emits('updateOriData', ele.model, _.cloneDeep([]))
    }
    if (!!ele?.defaultValue) {
      formObj.value[ele.model] = ele.defaultValue
      emits('updateOriData', ele.model, _.cloneDeep(ele.defaultValue))
    }
  })
}
const renewKey = (key, data, totalItem) => {
  if (!!totalItem) {
    formObj.value[totalItem.model][key] = data
  } else {
    formObj.value[key] = data
  }
}
//
let paramshandling = ref(false)
//
let renderFormParams = ref([])
watch(
  fieldParams,
  (_nval, _oldval) => {
    _handleFieldRules(_nval)
    handleFieldParams(_nval)
    // renderFormParams.value =
  },
  {
    deep: true,
  }
)
watch(formEditStatus, () => {
  _handleFieldRules(fieldParams.value)
})

/**
 * 组件级变量集合
 */

const paramsConfig = reactive({
  title: '新增',
})

// 上传图片变量集合
const imageObj = reactive({
  imageList: [],
})

// 上传视频变量集合
const videoObj = reactive({
  videoList: [],
})

// rule数据处理
const _handleFieldRules = (paramsdata) => {
  if (!Array.isArray(paramsdata)) {
    paramsdata = []
  }
  // rule校验
  for (const item of paramsdata) {
    if (item.rule && (Object.keys(item.rule).length > 0 || item.rule.length > 0)) {
      rules.value[item.model] = item.rule
      let temrule = _.cloneDeep(item.rule)
      temrule.forEach((ele) => {
        if (ele.hasOwnProperty('pattern')) {
          ele.pattern = eval(ele.pattern)
        }
        if (ele.hasOwnProperty('required')) {
          ele.required = formEditStatus.value
        }
      })
      rules.value[item.model] = temrule
    }
  }
}

/**
 * 触发按钮
 */
const triggerBtn = async (params) => {
  if (!params.hasEmit) {
    return
  }
  activeFormRef.value.validate((valid, fields) => {
    if (valid) {
      emits('change', { formObj: formObj.value, config: params })
    }
  })
}

/**
 * 处理配置字段rule
 */
_handleFieldRules(fieldParams.value)

// 上传图片处理
const _uploadImage = async (file, fileList) => {
  imageObj.imageList.forEach((item) => {
    if (item.name == file.name) {
      ElMessage.error('已上传该图片！')
      fileList.pop()
    }
  })

  // 限制大小
  const isLt = file.size / 1024 / 1024 < 2
  if (!isLt) {
    ElMessage.error('单个文件大小不超过2MB!')
    fileList.pop()
    return false
  }

  // 写入文件
  let formData = new FormData()
  formData.append(
    'file',
    new File([file.raw], file.name, {
      type: file.raw.type,
    })
  )

  // 处理已上传的数据
  const uploadRes = await api.uploadImage(formData)
  if (uploadRes?.code !== '00000') {
    ElMessage.error('上传API请求失败!')
    return
  }
  if (!formObj.value.hasOwnProperty('imageList')) {
    formObj.value.imageList = []
  }
  formObj.value.imageList.push({
    fileType: uploadRes?.data?.fileType,
    fileName: uploadRes?.data?.objectKey,
    fileUrl: uploadRes?.data?.objectUrl,
  })
}

//移除图片处理
const _removeImage = (file) => {
  formObj.value.imageList = formObj.value.imageList.filter((item) => item.fileName != file.name)
}

/**
 * 视频处理
 */

// 上传视频前触发
const _beforeVideoUpload = (file) => {
  // 判断同视频上传
  let simStatus = true
  for (const item of videoObj.videoList) {
    if (item.name == file.name) {
      simStatus = false
    }
  }
  if (!simStatus) {
    ElMessage.error('已上传该视频！')
    return false
  }

  // 限制大小
  const isLt = file.size / 1024 / 1024 < 5
  if (!isLt) {
    ElMessage.error('单个文件大小不超过5MB!')
    return false
  }

  // 文件名数量
  const fileName = file.name.substring(0, file.name.lastIndexOf('.'))
  if (fileName.length > 50) {
    ElMessage.error('文件名限制50字符!')
    return false
  }

  return true
}

// 上传视频
const _uploadVideo = async (fileObj) => {
  let formData = new FormData()
  formData.append('file', fileObj.file)
  const uploadRes = await api.uploadFileVideo(formData)
  if (uploadRes?.code !== '00000') {
    ElMessage.error('上传API请求失败!')
    return
  }
  if (!formObj.value.hasOwnProperty('videoList')) {
    formObj.value.videoList = []
  }
  formObj.value.videoList.push({
    fileType: uploadRes?.data?.fileType,
    fileName: uploadRes?.data?.objectKey,
    fileUrl: uploadRes?.data?.objectUrl,
  })
}

// 移除视频
const _removeVideo = (file) => {
  formObj.value.videoList = formObj.value.videoList.filter((item) => item.fileName != file.name)
}

// 获取日期 -暂无处理
const _changeDatePicker = (date) => {}

// 级联数据处理
const _changeCascader = (val, modelName) => {
  if (val) formObj.value[modelName] = val[val.length - 1]
}

/**
 * slot 传参处理
 * params {slotName: {key: val}}
 */
const slotTrigger = (params) => {
  if (Object.keys(params).length > 0) {
    for (const obj in params) {
      formObj.value[obj] = params[obj]
    }
  }
}

// 回显数据
const detailTrigger = (params) => {
  if (Object.keys(params).length > 0) {
    for (const obj in params) {
      formObj.value[obj] = params[obj]
    }
  }
}

// 监听配置参数
watch(
  () => props.fieldConfig,
  (newVal) => {
    fieldParams.value = newVal
  },
  {
    deep: true,
  }
)

const formReset = () => {
  activeFormRef.value.resetFields()
}
const dataExpose = (data) => {
  return formObj.value
}
// 对外暴露变量方法
defineExpose({
  slotTrigger,
  detailTrigger,
  formReset,
  dataExpose,
  activeFormRef,
  formObj,
  dataFormat,
})
</script>

<style lang="scss" scoped>
.w-full {
  width: 100%;
}

.flex {
  display: flex;
}

.justify-center {
  justify-content: center;
}

.btnGroup {
  ::v-deep(.el-button) {
    margin-right: 20px;
  }
}

.hiddenUploadImage {
  ::v-deep(.el-upload--picture-card) {
    display: none;
  }
}

::v-deep(.el-button--primary) {
  background-image: linear-gradient(to bottom, rgba($color: #2d69ff, $alpha: 0.7) 0%, rgba($color: #2d69ff, $alpha: 0) 100%);
}

::v-deep(.el-input.is-disabled) {
  cursor: default;
}

::v-deep(.el-input.is-disabled .el-input__inner) {
  color: #606266;
  -webkit-text-fill-color: #606266;
  cursor: default;
}

::v-deep(.el-textarea.is-disabled .el-input__wrapper:hover) {
  background-color: transparent;
  box-shadow: none;
  cursor: default;
}

::v-deep(.el-textarea.is-disabled .el-textarea__inner) {
  background-color: transparent;
  box-shadow: none;
  cursor: default;
}

::v-deep(.el-textarea.is-disabled .el-textarea__inner:hover) {
  background-color: transparent;
  box-shadow: none;
  cursor: default;
}

::v-deep(.el-select .el-input.is-disabled .el-input__wrapper:hover) {
  background-color: transparent;
  box-shadow: none;
  cursor: default;
}

::v-deep(.el-input.is-disabled .el-input__wrapper) {
  background-color: transparent;
  box-shadow: none;
}

::v-deep(.el-textarea.is-disabled .el-input__wrapper) {
  background-color: transparent;
  box-shadow: none;
}

::v-deep(.el-input.is-disabled .el-input__icon) {
  cursor: default;
  display: none;
}

::v-deep(.el-select .el-input.is-disabled .el-select__caret) {
  display: none;
}

::v-deep(.el-select--disabled.w-full .el-tag.el-tag--info) {
  background-color: rgba($color: #000000, $alpha: 0);
  cursor: default;
  font-size: 14px;
  color: #000;
}

::v-deep(.el-card__body) {
  padding: 0;
}
.group-header {
  background-color: #ddd;
  padding: 4px 8px;
  display: flex;
  height: 100%;
  flex-direction: column;
  justify-content: center;
}
</style>
