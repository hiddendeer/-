<template>
  <div style="width: 100%">
    <el-input
      style="width: 100%"
      v-model="value"
      @input="change"
      placeholder="请输入"
    ></el-input>
  </div>
</template>

<script setup>
import { ref } from "vue";
const value = ref("");
const emits = defineEmits(["change"]);


const change = (e) => {
  console.log(e);
  emits("change", e);
};
</script>