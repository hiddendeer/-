<template>
  <el-container>
    <!-- <el-aside width="200px">
      <el-container>
        <el-header>
          <el-input placeholder="输入关键字进行过滤" v-model="groupFilterText" clearable></el-input>
        </el-header>
        <el-main class="nopadding">
          <el-tree
            ref="group"
            class="menu"
            node-key="value"
            :data="groupData"
            default-expand-all
            :current-node-key="''"
            :highlight-current="true"
            :expand-on-click-node="false"
            :filter-node-method="groupFilterNode"
            @node-click="groupClick"
          ></el-tree>
        </el-main>
      </el-container>
    </el-aside> -->
    <el-container>
      <!-- <div class="topBtn">
        <el-button @click="tanchaung">弹窗</el-button>
        <el-button @click="showOperationRecord">操作记录</el-button>
      </div> -->
      <el-header style="height: 35%">
        <div class="search">
          <el-form-item label="机构专业资质：" label-width="120px">
            <div class="search_param">
              <el-radio-group v-model="searchParams.qualifications" size="small">
                <el-radio-button v-for="(item, index) in qualificationsArray" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-radio-button>
              </el-radio-group>
            </div>
          </el-form-item>
          <el-form-item label="服务内容：" label-width="120px">
            <div class="search_param">
              <el-checkbox-group v-model="searchParams.serviceType" size="small">
                <el-checkbox-button v-for="(item, index) in serviceTypeList" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-checkbox-button>
              </el-checkbox-group>
            </div>
          </el-form-item>
          <el-form-item label="执业状态：" label-width="120px">
            <div class="search_param">
              <el-radio-group v-model="searchParams.agencyStatus" size="small">
                <el-radio-button v-for="(item, index) in agencyStatusArray" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-radio-button>
              </el-radio-group>
            </div>
          </el-form-item>
          <el-form-item>
            <el-form-item label="机构名称：" label-width="120px">
              <el-input v-model="searchParams.agencyName" placeholder="请输入机构名称" clearable style="width: 200px" />
            </el-form-item>

            <el-button type="primary" class="sibmitBtn" style="margin-left: 10px" @click="selectInstitution">查询</el-button>
            <el-button type="primary" @click="reload">重置</el-button>
          </el-form-item>
        </div>
        <div class="right-panel">
          <el-button type="primary" class="sibmitBtn" @click="addIns('add')">+新增</el-button>
          <el-button type="primary" class="sibmitBtn" @click="batchImport">批量导入</el-button>
          <el-button type="primary" class="sibmitBtn" @click="toExamine" v-if="orgSwitch">审核</el-button>
        </div>
      </el-header>
      <el-main class="nopadding">
        <scTable ref="table" :data="tableData" row-key="id" stripe hidePagination hideDo>
          <el-table-column label="序号" align="center" type="index" width="50" />
          <el-table-column label="执业状态" align="center" prop="agencyStatus" width="100">
            <template #default="scope">
              <div>
                {{ getAgencyStatus(scope.row.agencyStatus, scope.row.deleted) }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="机构名称" align="center" prop="agencyName" width="200"></el-table-column>
          <el-table-column label="社会信用代码" align="center" prop="unifiedCreditCode" width="200"></el-table-column>
          <el-table-column label="服务内容" align="center" prop="serviceType" width="200" show-overflow-tooltip>
            <template #default="scope">
              <div class="showTooltip">
                {{ getServiceType(scope.row.serviceType) }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="机构填报人" align="center" prop="agyContact" width="100">
            <template #default="scope">
              <div>
                {{ scope.row.agyContact || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="联系方式" align="center" prop="agyContactMobile" width="100">
            <template #default="scope">
              <div>
                {{ scope.row.agyContactMobile || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="操作" fixed="right" align="center">
            <template #default="scope">
              <el-button-group class="deleted" v-if="scope.row.agencyStatus == 'JGJBXX_ZYZT_ZX'">
                <el-button text type="danger" disabled size="small">已注销</el-button>
              </el-button-group>
              <el-button-group v-else>
                <el-button text type="primary" size="small" @click="addIns('updata', scope.row)">修改</el-button>
                <el-button text type="primary" size="small" @click="showService('1', scope.row)">注销</el-button>
                <el-button text type="primary" size="small" @click="showService('2', scope.row)" v-if="scope.row.agencyStatus == 'JGJBXX_ZYZT_ZC'">暂停</el-button>
                <el-button text type="primary" size="small" @click="showService('3', scope.row)" v-else>恢复</el-button>
                <el-button text type="primary" size="small" @click="jumpToInsInfo(scope.row.companyId)">机构履历</el-button>
              </el-button-group>
            </template>
          </el-table-column>
        </scTable>
      </el-main>
      <el-footer class="bodyPage">
        <div class="leftButton"></div>
        <el-pagination
          background
          @current-change="currentPageChange"
          @size-change="pageSizeChange"
          :page-size="pageSize"
          :current-page="page"
          :small="true"
          :page-sizes="[10, 20, 30, 40, 50]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </el-footer>
    </el-container>
  </el-container>
  <!-- 操作记录列表弹窗 -->
  <el-drawer v-model="operationWindow" title="操作记录" direction="rtl" size="40%">
    <el-container>
      <el-main class="nopadding">
        <el-table ref="table" :data="operationTable" height="100%" style="width: 100%">
          <el-table-column label="操作人" align="center" prop="createUserName" min-width="200"></el-table-column>
          <el-table-column label="操作内容" align="center" prop="operationRecordContent" min-width="300"></el-table-column>
          <el-table-column label="操作时间" align="center" prop="createTime" min-width="200"></el-table-column>
        </el-table>
      </el-main>
      <el-footer class="bodyPage">
        <div class="leftButton"></div>
        <el-pagination
          background
          @current-change="OPcurrentPageChange"
          @size-change="OPpageSizeChange"
          :page-size="OPpageSize"
          :current-page="OPpage"
          :small="true"
          :page-sizes="[10, 20, 30, 40, 50]"
          :total="OPtotal"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </el-footer>
    </el-container>
  </el-drawer>
  <!-- 新增弹窗 -->
  <el-dialog v-model="addInsWindow" width="40%" :close-on-click-modal="false" @closed="resetForm(insRuleFrom)">
    <template #header>
      <div class="z_title">{{ insWinFlag === 'add' ? '新增' : '编辑' }}</div>
    </template>
    <el-form ref="insRuleFrom" :model="insForm" :rules="insSetFormRules" label-width="150px" class="demo-ruleForm" status-icon>
      <el-form-item label="机构名称：" prop="agencyName">
        <el-input v-model="insForm.agencyName" placeholder="请输入机构名称" maxlength="32" show-word-limit clearable />
      </el-form-item>
      <el-form-item label="社会信用代码：" prop="unifiedCreditCode">
        <el-input
          v-model="insForm.unifiedCreditCode"
          placeholder="请输入社会信用代码"
          @input="
            () => {
              insForm.unifiedCreditCode = insForm.unifiedCreditCode.replace(/[^\w]/g, '')
            }
          "
          maxlength="18"
          show-word-limit
          clearable
        />
      </el-form-item>
      <el-form-item label="机构填报人：" prop="agyContact">
        <el-input v-model="insForm.agyContact" placeholder="请输入机构填报人姓名" maxlength="20" show-word-limit clearable />
      </el-form-item>
      <el-form-item label="联系方式：" prop="agyContactMobile">
        <el-input
          v-model="insForm.agyContactMobile"
          placeholder="请输入机构填报人手机号"
          @input="
            () => {
              insForm.agyContactMobile = insForm.agyContactMobile.replace(/[^\d]/g, '')
            }
          "
          maxlength="11"
          show-word-limit
          clearable
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="resetForm(insRuleFrom)">取消</el-button>
        <el-button type="primary" @click="submitForm(insRuleFrom)" :loading="submitLoading">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
  <!-- 查看证书弹窗 -->
  <el-dialog v-model="certInfoWindow" width="40%" :close-on-click-modal="false">
    <template #header>
      <div class="z_title">证书信息</div>
    </template>
    <template #default>
      <div class="cert">
        <div class="certArray">
          <div class="certInfo" v-for="(item, index) in certUrl" :key="index">
            <img class="certInfoStyle" :src="item" alt="" />
          </div>
        </div>
      </div>
    </template>
  </el-dialog>
  <!-- 注销 / 暂停 / 恢复 弹窗-->
  <el-dialog v-model="serviceWindow" width="20%" :close-on-click-modal="false">
    <template #header>
      <div class="z_title">{{ serviceTitle }}</div>
    </template>
    {{ '确定进行' + serviceTitle + '操作？' }}
    <template #footer>
      <el-button @click="cancelService">取消</el-button>
      <el-button type="primary" @click="confrimService">确认</el-button>
    </template>
  </el-dialog>
  <!-- 批量导入弹窗 -->
  <el-dialog v-model="batchImportState" :close-on-click-modal="false" width="40%">
    <template #header>
      <div class="import_title">批量导入</div>
    </template>
    <div class="button_style">
      <div class="upload">
        <el-upload
          class="uploadStyle"
          :disabled="uploadLoading"
          ref="upload"
          action="/host/tvrjet-pinganfu-cust-app/organImport/organization"
          accept=".xlsx, .xls"
          :on-change="handleChange"
          :before-remove="removeFlie"
          :auto-upload="false"
          :file-list="uploadFileList"
        >
          <el-button type="primary" :loading="uploadLoading">上传文件</el-button>
        </el-upload>
      </div>
      <div class="download">
        <el-button :loading="downLoading" @click="downLoadTem">下载模板</el-button>
      </div>
      <div class="direction">
        <p>说明：</p>
        <p>1. 请使用模板编辑组织架构人员清单，文件格式保存为.xlsx。</p>
        <p>2. 上传自动进行去重校检，新增数据与原有数据冲突则无法导入成功。</p>
        <p>3. 上传数据存在错误数据将无法导入成功。</p>
      </div>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="uploadingCancel">取消</el-button>
        <el-button class="commitImport" type="primary" @click="uploadingCommit">确认导入</el-button>
      </span>
    </template>
  </el-dialog>
  <!-- 错误列表 -->
  <importOrganization v-model="errorTableVisible" :tableData="wrongTableData" :passDialogFlag="passDialogFlag" @getQueryComListPage="getGoverList" @updateTableData="updateTableData" />
  <!-- 选择弹窗 -->
  <selectDialog :showSelectDialog="showSelectDialog" :tabsType="tabsType" v-if="showSelectDialog" @closeDialog="closeDialog"></selectDialog>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import router from '@/router'
import CommonApi from './server/api'
import { ElMessage, ElLoading } from 'element-plus'
import lodash from 'lodash'
import importOrganization from './components/import-organization-business.vue' // 批量导入错误列表
// import selectDialog from '@/components/selectDialog/index'

let showSelectDialog = ref(false)
let tabsType = ref(1)
const tanchaung = () => {
  showSelectDialog.value = true
}
const closeDialog = () => {
  showSelectDialog.value = false
}
// 批量导入弹窗
let errorTableVisible = ref(false)
// 下载按钮loading
let downLoading = ref(false)
// 上传按钮loading
let uploadLoading = ref(false)
// 上传文件列表
const uploadFileList = ref([])
// 批量导入
let batchImportState = ref(false)
// 错误数据列表
let wrongTableData = ref([])
// 跳过弹窗锁
let passDialogFlag = ref(true)
// 上传文件的属性接收
const fileAttribute = ref([])
// 机构库审核按钮开关
let orgSwitch = ref(false)
//上传.校验.赋值
const handleChange = async (file, fileList) => {
  uploadLoading.value = true
  const isFileType = file.raw.type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.raw.type == 'application/vnd.ms-excel'
  const isLt100KB = file.size / 1024 < 300
  // 上传文件列表控制
  uploadFileList.value.push(file)
  if (!isFileType) {
    ElMessage.error('只能上传Excel格式，如.xlsx、.xls')
    uploadFileList.value.splice(-1, 1)
    uploadLoading.value = false
    return
  }
  if (!isLt100KB) {
    ElMessage.error('超出文件大小限制300kb，无法导入')
    uploadFileList.value.splice(-1, 1)
    uploadLoading.value = false
    return
  }
  if (uploadFileList.value.length > 1) {
    uploadFileList.value.splice(0, 1)
  }
  // 把文件数据接到中转位置
  fileAttribute.value = uploadFileList.value
  uploadLoading.value = false
}
// 删除文件列表中的文件
const removeFlie = () => {
  uploadFileList.value = []
}
// 批量导入确认
const uploadingCommit = async () => {
  if (uploadFileList.value.length == 0) {
    ElMessage.warning('请上传文件后导入')
    return
  }
  const loading = ElLoading.service({
    lock: true,
    text: '导入中',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  let dataParam = new File([fileAttribute.value[0].raw], fileAttribute.value[0].name, { type: fileAttribute.value[0].raw.type })
  let param = new FormData()
  param.append('file', dataParam)
  // 调用批量导入接口,返回错误数据
  try {
    await CommonApi.importMechanism(param, { headers: { EnterpriseType: 'MECHANISM' } }).then((res) => {
      if (res.code == '00000') {
        loading.close()
        batchImportState.value = false
        uploadLoading.value = false
        errorTableVisible.value = true
        wrongTableData.value = res.data
        wrongTableData.value.failedResult.length == 0 ? (passDialogFlag.value = false) : (passDialogFlag.value = true)
      } else {
        loading.close()
      }
    })
  } catch (error) {
    loading.close()
    uploadFileList.value = []
    uploadLoading.value = false
  }
}
/**
 * 批量导入弹窗
 */
const batchImport = () => {
  uploadFileList.value = []
  batchImportState.value = true
}
// 批量导入取消
const uploadingCancel = () => {
  batchImportState.value = false
}
// 后端地址
const host = process.env.VUE_APP_SAFE_URL
// 动态获取下载模板地址
const downloadUrl = ref('')
//下载模板
const downLoadTem = async () => {
  let data = await CommonApi.parameterConfigList()
  downloadUrl.value = data.data.mechanismLibraryImport
  try {
    downLoading.value = true
    let response = await fetch(downloadUrl.value)
    // 内容转变成blob地址
    let blob = await response.blob()
    // 创建隐藏的可下载链接
    let objectUrl = window.URL.createObjectURL(blob)
    let a = document.createElement('a')
    //地址
    a.href = objectUrl
    //修改文件名
    a.download = '机构批量导入模板.xlsx'
    // 触发点击
    document.body.appendChild(a)
    a.click()
    //移除
    setTimeout(() => document.body.removeChild(a), 1000)
    downLoading.value = false
  } catch (error) {
    downLoading.value = false
  }
}
// 导入错误更新tableData
const updateTableData = (d) => {
  try {
    let { updataArray, multipleIndex } = d
    //克隆上一次错误的列表数据 先把选中要导入的删除
    let tableDataClone = lodash.cloneDeep(wrongTableData.value.failedResult)
    lodash.pullAt(tableDataClone, multipleIndex)
    //拼入上传导入剩下的数据和本次导入失败的数据
    wrongTableData.value.failedResult = [...tableDataClone, ...updataArray.failedResult]
    if (wrongTableData.value.failedResult.length === 0) {
      errorTableVisible.value = false
      passDialogFlag.value = false
    } else {
      passDialogFlag.value = true
    }
  } catch (error) {
    console.log(error)
  }
}
// 新增编辑表单ref
const insRuleFrom = ref(null)
// 新增表单校验规则
const insSetFormRules = ref({
  agencyName: [{ required: true, message: '请输入机构名称', trigger: 'blur' }],
  unifiedCreditCode: [
    { required: true, message: '请输入社会信用代码', trigger: 'blur' },
    {
      pattern: /^[^_IOZSVa-z\W]{2}\d{6}[^_IOZSVa-z\W]{10}$/,
      message: '请输入正确的统一信用代码',
      trigger: 'blur',
    },
  ],
  agyContact: [{ required: true, message: '请输入机构填报人姓名', trigger: 'blur' }],
  agyContactMobile: [
    { required: true, message: '请输入机构填报人手机号', trigger: 'blur' },
    {
      pattern: /^(?:(?:\+|00)86)?1[3-9]\d{9}$/,
      message: '请输入正确手机号',
      trigger: 'blur',
    },
  ],
})
// 查看证书信息弹窗
let certInfoWindow = ref(false)
// 操作列 弹窗
let serviceWindow = ref(false)
// 操作列弹窗标题
let serviceTitle = ref('')
// 操作弹窗标识
let operationWindow = ref(false)
// 搜索项初始化
const searchParams = ref({
  agencyName: '', // 条件筛选 机构名称
  qualifications: '', // 条件筛选 机构专业资质
  agencyStatus: '', // 条件筛选 执业状态
  serviceType: [], // 条件筛选 服务内容
})
// 新增弹窗标识
let addInsWindow = ref(false)
// 新增/编辑 按钮标识
let insWinFlag = ref('')
// 机构等级数据
const insLevelList = ref([
  {
    value: 'A级',
    label: 'A',
  },
  {
    value: 'B级',
    label: 'B',
  },
  {
    value: 'C级',
    label: 'C',
  },
  {
    value: 'D级',
    label: 'D',
  },
])
// 新增/编辑表单初始化
const insForm = ref({
  agencyName: '',
  unifiedCreditCode: '',
  agyContact: '',
  agyContactMobile: '',
})
// 树ref
let group = ref(null)
// 表ref
let table = ref(null)
// 列表数据
const tableData = ref([])
// 初始化数据树过滤
let groupFilterText = ref('')
// 树数据
let groupData = ref([])
// 列表搜索关键字
let search = ref({
  keyword: '',
})
watch(
  () => groupFilterText.value,
  (nVal) => {
    group.value.filter(nVal)
  }
)
//当前页数
let page = ref(1)
//一页多少条
let pageSize = ref(10)
//总条数
let total = ref(0)
//切换页数
const currentPageChange = (val) => {
  page.value = Number(val.toString().split('.')[0])
  getGoverList()
}
//切换每页条数
const pageSizeChange = (val) => {
  pageSize.value = val
  getGoverList()
}
// 👇👇👇👇👇👇👇👇👇操作记录分页数据👇👇👇👇👇👇👇👇👇👇👇
// 操作记录分页当前页数
let OPpage = ref(1)
// 操作记录分页一页多少条
let OPpageSize = ref(10)
// 操作记录分页总条数
let OPtotal = ref(0)
// 操作记录分页切换页数
const OPcurrentPageChange = (val) => {
  OPpage.value = Number(val.toString().split('.')[0])
  getOperationData()
}
// 操作记录分页切换每页条数
const OPpageSizeChange = (val) => {
  OPpageSize.value = val
  getOperationData()
}
// 👆👆👆👆👆👆👆👆👆操作记录分页数据👆👆👆👆👆👆👆👆👆👆👆
// 操作记录按钮
const showOperationRecord = () => {
  operationWindow.value = true
  getOperationData()
}
// 操作记录表格数据初始化
let operationTable = ref([])
// 获取操作记录列表数据
const getOperationData = () => {
  let params = {
    pageNo: OPpage.value,
    pageSize: OPpageSize.value,
  }
  CommonApi.getOperationRecord(params).then((res) => {
    if (res.code == '00000') {
      operationTable.value = res.data.rows
      OPtotal.value = res.data.totalRows
    } else {
      ElMessage(res.message)
    }
  })
}
//树过滤
const groupFilterNode = (value, data) => {
  if (!value) return true
  return data.label.indexOf(value) !== -1
}
//树点击事件
const groupClick = (data) => {
  searchParams.value.area = data.value
  getGoverList()
}
// 条件筛选查询
const selectInstitution = () => {
  getGoverList()
}
// 重置按钮
const reload = () => {
  searchParams.value = {
    agencyName: '', // 条件筛选 机构名称
    qualifications: '', // 条件筛选 机构专业资质
    agencyStatus: '', // 条件筛选 执业状态
    serviceType: [], // 条件筛选 服务内容
  }
  getAreaTree()
  getGoverList()
}
const insCompanyId = ref('')
// 新增
const addIns = (data, row) => {
  insRuleFrom.value?.resetFields()
  insWinFlag.value = data
  addInsWindow.value = true
  // 编辑时回显数据
  if (data == 'updata') {
    updataWindow(row)
    insCompanyId.value = row.companyId
  } else {
    insForm.value = {
      id: '',
      agencyName: '',
      unifiedCreditCode: '',
      agyContact: '',
      agyContactMobile: '',
    }
  }
}
// 窗口状态为编辑时, 内容回显
const updataWindow = (row) => {
  insForm.value = {
    id: row.id,
    agencyName: row.agencyName,
    unifiedCreditCode: row.unifiedCreditCode,
    agyContact: row.agyContact,
    agyContactMobile: row.agyContactMobile,
  }
}
// 证书路径中转
let certUrl = ref([])
/**
 * 查看证书按钮
 * @param {*传入的当前行证书图片路径} url
 */
const checkCertInfo = (url) => {
  certUrl.value = []
  let imageArray = JSON.parse(url)
  if (url) {
    imageArray.forEach((item) => {
      certUrl.value.push(item.attachment)
    })
  }
  certInfoWindow.value = true
}
// 弹窗分类中转 1/注销 2/暂停 3/恢复
let tempServiceFlag = ref('')
// 机构主键
let tempMechanismId = ref('')
// 机构名称
let tempMechanismName = ref('')
// 机构状态修改参数初始化
let serviceForm = ref({
  agencyId: '', // 机构主键
  agencyStatus: '', // 状态字典 JGJBXX_ZYZT_ZT 暂停；JGJBXX_ZYZT_ZX 注销；JGJBXX_ZYZT_ZC：正常
  mechanismName: '', // 机构名称
})
/**
 * 操作列弹窗
 * @param {*按钮分类 1/注销 2/暂停 3/恢复} flag
 * @param {*所在行id} row
 */
const showService = (flag, row) => {
  switch (flag) {
    case '1':
      serviceTitle.value = '注销'
      break
    case '2':
      serviceTitle.value = '暂停'
      break
    case '3':
      serviceTitle.value = '恢复'
      break
    default:
      break
  }
  tempServiceFlag.value = flag
  serviceForm.value.agencyId = row.agencyId
  insCompanyId.value = row.companyId
  serviceWindow.value = true
}
// 跳转至机构履历
const jumpToInsInfo = (val) => {
  router.push({ path: '/institutionReview/insBasicInfo', query: { companyId: val } })
}
// 操作列弹窗确认按钮  1/注销 2/暂停 3/恢复
const confrimService = () => {
  switch (tempServiceFlag.value) {
    case '1':
      serviceForm.value.agencyStatus = 'JGJBXX_ZYZT_ZX'
      break
    case '2':
      serviceForm.value.agencyStatus = 'JGJBXX_ZYZT_ZT'
      break
    case '3':
      serviceForm.value.agencyStatus = 'JGJBXX_ZYZT_ZC'
      break
    default:
      break
  }
  // 注销调用注销接口
  if (tempServiceFlag.value == 1) {
    CommonApi.logoutMechanism(
      {
        agyOrEnt: 'MECHANISM',
        agencyId: serviceForm.value.agencyId,
      },
      { headers: { EnterpriseType: 'MECHANISM' } }
    ).then((res) => {
      if (res.code == '00000') {
        ElMessage.success('操作成功')
        serviceWindow.value = false
        getGoverList()
      } else {
        ElMessage.warning(res.message)
      }
    })
  } else {
    // 暂停/恢复 调用改状态接口
    CommonApi.changeStatus(serviceForm.value, { headers: { EnterpriseType: 'MECHANISM', companyId: insCompanyId.value } }).then((res) => {
      if (res.code == '00000') {
        ElMessage.success('操作成功')
        serviceWindow.value = false
        getGoverList()
      } else {
        ElMessage.warning(res.message)
      }
    })
  }
}
// 操作列弹窗取消按钮
const cancelService = () => {
  serviceWindow.value = false
}
// 审核
const toExamine = () => {
  router.push('/institutionReview/auditPage')
}
// 新增/编辑 弹窗按钮loading状态
const submitLoading = ref(false)
// 新增编辑 提交按钮
const submitForm = async (formEl) => {
  submitLoading.value = true
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      insForm.value.agyOrEnt = 'MECHANISM'
      if (insWinFlag.value == 'add') {
        CommonApi.addMechanism(insForm.value, { headers: { EnterpriseType: 'MECHANISM' } }).then((res) => {
          if (res.code == '00000') {
            ElMessage.success('新增成功')
            addInsWindow.value = false
            submitLoading.value = false
            getGoverList()
          } else {
            ElMessage.warning(res.message)
            submitLoading.value = false
          }
        })
      } else {
        CommonApi.updateMechanism(insForm.value, { headers: { EnterpriseType: 'MECHANISM', CompanyId: insCompanyId.value } }).then((res) => {
          if (res.code == '00000') {
            ElMessage.success('编辑成功')
            addInsWindow.value = false
            submitLoading.value = false
            getGoverList()
          } else {
            ElMessage.warning(res.message)
            submitLoading.value = false
          }
        })
      }
    } else {
      console.log('error submit!', fields)
      submitLoading.value = false
    }
  })
}
// 新增编辑 取消按钮
const resetForm = (formEl) => {
  if (!formEl) return
  insRuleFrom.value.resetFields()
  addInsWindow.value = false
}
// 执业状态MAP枚举
let agencyStatusMap = new Map([
  ['JGJBXX_ZYZT_ZT', '暂停'],
  ['JGJBXX_ZYZT_ZX', '注销'],
  ['JGJBXX_ZYZT_ZC', '正常'],
])
/**
 * 职业状态格式化 JGJBXX_ZYZT_ZT 暂停；JGJBXX_ZYZT_ZX 注销；JGJBXX_ZYZT_ZC：正常
 * @param {*行内执业状态字典} data
 */
const getAgencyStatus = (data, status) => {
  if (status) {
    return '注销'
  } else {
    if (!data) return '-'
    return agencyStatusMap.get(data) || '-'
  }
}
// 获取服务内容
const getServiceType = (val) => {
  if (!val) return '-'
  let tempStatus = JSON.parse(val)
  if (tempStatus.length > 0) {
    return tempStatus
      .map((i) => {
        return i.text
      })
      .join('、')
  } else {
    return '-'
  }
}

// 获取政府端机构列表数据
const getGoverList = () => {
  let params = {
    pageNo: page.value,
    pageSize: pageSize.value,
    agyOrEnt: 'MECHANISM',
  }
  CommonApi.GoverList({ ...params, ...searchParams.value }, { headers: { agyOrEnt: 'MECHANISM' } }).then((res) => {
    if (res.code == '00000') {
      tableData.value = res.data.records
      total.value = res.data.total
    } else {
      ElMessage.warning(res.message)
    }
  })
}
// 获取无锡的地址数据
const getAreaTree = () => {
  CommonApi.areaTree_WUXI({ areaId: '3202' }).then((res) => {
    if (res.code == '00000') {
      groupData.value = res.data
    } else {
      console.log(res.message)
    }
  })
}
//所属地区转换
const RegionFormatter = (row, column, cellValue) => {
  try {
    let JsonVlaue = null
    if (typeof cellValue == 'string') {
      JsonVlaue = JSON.parse(cellValue)
    } else {
      JsonVlaue = cellValue
    }
    let areaName = ''
    JsonVlaue.forEach((item) => {
      if (areaName == '') {
        areaName = item.label
      } else {
        areaName = areaName + '/' + item.label
      }
    })
    return areaName
  } catch (e) {
    return cellValue || '-'
  }
}
// 获取机构库审核按钮开关
const getOrgSwitch = async () => {
  let data = await CommonApi.parameterConfigList()
  orgSwitch.value = data?.data.mechanismLibraryExamine
}

// 机构专业资质初始化
let qualificationsArray = ref([])
// 服务类型数据初始化
let serviceTypeList = ref([])
// 执业状态初始化
let agencyStatusArray = ref([])
// 获取查询条件字典
const getdictData = () => {
  CommonApi.dictProject({ dictTypeCode: 'JGJBXX' }, { headers: { EnterpriseType: 'MECHANISM' } }).then((res) => {
    if (res.code == '00000') {
      let resultData = res.data
      qualificationsArray.value = resultData.find((item) => item.dictCode == 'JGJBXX_JGZYZZ')?.children
      serviceTypeList.value = resultData.find((item) => item.dictCode == 'JGJBXX_FWLXJS')?.children
      agencyStatusArray.value = resultData.find((item) => item.dictCode == 'JGJBXX_ZYZT')?.children
    }
  })
}
onMounted(() => {
  getdictData()
  getGoverList()
  getOrgSwitch()
  getAreaTree()
})
</script>
<style lang="scss" scoped>
.topBtn {
  padding: 13px 15px 0 0;
  background-color: #fff;
  display: flex;
  justify-content: right;
}
.z_title {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 10px;
  font-size: 22px;
  color: #000000;
}
.showTooltip {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.search_param {
  .el-checkbox-button {
    margin: 2px;
  }
  :deep(.el-checkbox-button__inner) {
    border: 1px solid #dcdfe6;
    border-radius: 4px;
  }
  .el-radio-button {
    margin: 2px;
  }
  :deep(.el-radio-button__inner) {
    border: 1px solid #dcdfe6;
    border-radius: 4px;
  }
}
:deep(.el-form-item__content) {
  line-height: 0;
}
.cert {
  display: flex;
  justify-content: center;
  height: 600px;
  overflow: auto;
  .certArray {
    display: flex;
    flex-direction: column;
    .certInfo {
      width: 500px;
      .certInfoStyle {
        padding: 20px;
        width: 100%;
        border-bottom: 1px solid #000000;
      }
    }
  }
}
.import_title {
  font-size: 22px;
  padding: 0 10px;
  border-left: 3px solid #409eff;
}
.button_style {
  margin-top: 30px;
  margin-right: 40%;
  .upload {
    height: 80px;
    .uploadStyle {
      display: flex;
    }
    .el-button {
      width: 150px;
    }
  }
  .download {
    height: 80px;
    .el-button {
      width: 150px;
    }
  }
  .direction {
    margin-top: 40px;
    width: 500px;
  }
}
.el-header {
  align-items: end;
  .right-panel {
    margin-bottom: 18px;
  }
}
.bodyPage {
  display: flex;
  justify-content: space-between;
  .leftButton {
    display: flex;
    align-items: center;
    .forbidden {
      margin-left: 20px;
    }
  }
}
</style>
