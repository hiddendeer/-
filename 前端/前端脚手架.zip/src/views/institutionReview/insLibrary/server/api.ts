import request from '@/utils/network.js'
import { paramType, auditType, statusType, logoutType, mechanismType, repeatType, queryType } from './interface'

export default class CommonApi {
  // 机构信息列表
  static GoverList = (data: paramType, config: object) => {
    return request({
      url: `/custApi/government/goverQueryPageList`,
      method: 'POST',
      data,
      ...config,
    })
  }

  // 项目字典查询通用接口
  static dictProject = (params: paramType, config: object) => {
    return request({
      url: `/baseServer/projectManage/queryDictTreeByProject`,
      method: 'GET',
      params,
      ...config,
    })
  }

  // 审核记录列表
  static auditRecordList = (params: paramType) => {
    return request({
      url: `/baseApi/auditRecord/pageList`,
      method: 'GET',
      params,
    })
  }

  // 审核
  static auditExamine = (data: auditType) => {
    return request({
      url: `/baseApi/auditRecord/examine`,
      method: 'PUT',
      data,
    })
  }
  // 部分地区树
  static areaTree_WUXI = (params: paramType) => {
    return request({
      url: `/baseServer/area/getTree`,
      method: 'GET',
      params,
    })
  }
  // 修改机构状态（暂停、注销、恢复）
  static changeStatus = (data: statusType, config: object) => {
    return request({
      url: `/custApi/government/changeStatus`,
      method: 'PUT',
      data,
      ...config,
    })
  }
  // 注销机构
  static logoutMechanism = (data: logoutType, config: object) => {
    return request({
      url: `/custApi/government/delete`,
      method: 'DELETE',
      data,
      ...config,
    })
  }
  // 获取操作记录
  static getOperationRecord = (params: paramType) => {
    return request({
      url: `/baseApi/operationRecord/page`,
      method: 'GET',
      params,
    })
  }
  // 新增机构
  static addMechanism = (data: mechanismType, config: object) => {
    return request({
      url: `/custApi/government/add`,
      method: 'POST',
      data,
      ...config,
    })
  }
  // 编辑
  static updateMechanism = (data: mechanismType, config: object) => {
    return request({
      url: `/custApi/government/update`,
      method: 'PUT',
      data,
      ...config,
    })
  }

  // 获取操作记录
  static getInsDetails = (params: paramType, config: object) => {
    return request({
      url: `/custApi/government/queryDetail`,
      method: 'GET',
      params,
      ...config,
    })
  }

  // 批量导入（机构库）
  static importMechanism = (data: FormData, config: object) => {
    return request({
      url: `/custApi/government/importMechanism`,
      method: 'POST',
      data,
      ...config,
    })
  }
  // 编辑后重新导入
  static repeatImportMechanism = (data: repeatType, config: object) => {
    return request({
      url: `/custApi/government/repeat`,
      method: 'POST',
      data,
      ...config,
    })
  }
  // 获取配置详情
  static parameterConfigList = (data: paramType) => {
    return request({
      url: `/baseApi/parameterConfig/queryDetail`,
      method: 'GET',
      data,
    })
  }
  // 查询字典
  static queryTreeCode = (data: queryType) => {
    return request({
      url: `/baseServer/applicationVisionDict/queryTreeCode`,
      method: 'GET',
      data,
    })
  }
  // 获取动态表单模板
  static getTemplateByProject = (data: paramType, config: object) => {
    return request({
      url: `/baseServer/projectManage/queryTemplateByProject`,
      method: 'GET',
      params: data,
      ...config,
    })
  }
  static DicInterface = (dicvalue: paramType) => {
    return request({
      url: `/tvrjet-base-tog-cust-app/baseAgency/codeValue/${dicvalue}`,
    })
  }
}
