<template>
  <el-dialog v-model="errorTableVisible" :close-on-click-modal="false" width="80%" @close="closeWrongData">
    <template #header>
      <div>导入结果</div>
    </template>
    <h3 class="titleTips">成功导入机构共 {{ tableData.successCount }} 个，无法导入机构共 {{ tableData.failedCount }} 个，请进行确认：</h3>
    <div class="error-table-container">
      <el-table :row-class-name="tableRowClassName" @selection-change="tableCheckBoxChange($event)" :data="tableData.failedResult" border style="width: 100%">
        <el-table-column align="center" type="selection" width="55"></el-table-column>
        <el-table-column label="序号" align="center" type="index" width="50" />
        <el-table-column align="center" prop="agencyName.value" label="企业名称" min-width="200">
          <template #default="scope">
            <el-tooltip :content="scope.row.agencyName.errorMarks?.join('/')" placement="bottom" :disabled="scope.row.agencyName.errorMarks.length === 0">
              <div :class="{ 'td-red': scope.row.agencyName.errorMarks.length > 0 }">
                <el-input
                  v-model="scope.row.agencyName.value"
                  show-word-limit
                  clearable
                  maxlength="32"
                  @focus="scope.row.agencyName.errorMarks.length = 0"
                  @input="
                    () => {
                      scope.row.agencyName.value = scope.row.agencyName.value.replace(/[^\u4E00-\u9FA5A-Za-z0-9（）()]/g, '')
                    }
                  "
                ></el-input>
              </div>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="unifiedCreditCode.value" label="社会信用代码" min-width="200">
          <template #default="scope">
            <el-tooltip :content="scope.row.unifiedCreditCode.errorMarks?.join('/')" placement="bottom" :disabled="scope.row.unifiedCreditCode.errorMarks.length === 0">
              <div :class="{ 'td-red': scope.row.unifiedCreditCode.errorMarks.length > 0 }">
                <el-input
                  v-model="scope.row.unifiedCreditCode.value"
                  show-word-limit
                  clearable
                  maxlength="18"
                  @focus="scope.row.unifiedCreditCode.errorMarks.length = 0"
                  placeholder="请输入社会信用代码"
                  @input="
                    () => {
                      scope.row.unifiedCreditCode.value = scope.row.unifiedCreditCode.value.replace(/[^\w]/g, '')
                    }
                  "
                ></el-input>
              </div>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="agyMainPerson.value" label="主要负责人" min-width="150">
          <template #default="scope">
            <el-tooltip :content="scope.row.agyMainPerson.errorMarks?.join('/')" placement="bottom" :disabled="scope.row.agyMainPerson.errorMarks.length === 0">
              <div :class="{ 'td-red': scope.row.agyMainPerson.errorMarks.length > 0 }">
                <el-input v-model="scope.row.agyMainPerson.value" show-word-limit clearable maxlength="20" @focus="scope.row.agyMainPerson.errorMarks.length = 0"></el-input>
              </div>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="agyMainPersonMobile.value" label="联系方式" min-width="150">
          <template #default="scope">
            <el-tooltip :content="scope.row.agyMainPersonMobile.errorMarks?.join('/')" placement="bottom" :disabled="scope.row.agyMainPersonMobile.errorMarks.length === 0">
              <div :class="{ 'td-red': scope.row.agyMainPersonMobile.errorMarks.length > 0 }">
                <el-input
                  v-model="scope.row.agyMainPersonMobile.value"
                  show-word-limit
                  clearable
                  maxlength="11"
                  @focus="scope.row.agyMainPersonMobile.errorMarks.length = 0"
                  @input="
                    () => {
                      scope.row.agyMainPersonMobile.value = scope.row.agyMainPersonMobile.value.replace(/[^\d]/g, '')
                    }
                  "
                ></el-input>
              </div>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="error-table-footer">
      <el-button type="primary" @click="onSubmitTable" :loading="loading">导 入</el-button>
      <el-button class="passImport" @click="passWrongData" type="primary" text size="small">跳过</el-button>
    </div>
  </el-dialog>
  <el-dialog v-model="passImportConfirm" :close-on-click-modal="false" width="30%" @close="passclose" :show-close="false">
    <template #header>
      <div>跳过确认</div>
    </template>
    <h3>跳过后无法导入机构将不再导入，是否确认跳过？</h3>
    <div class="error-table-footer">
      <el-button @click="cancelPass">取消</el-button>
      <el-button type="primary" @click="commitPass">确认</el-button>
    </div>
  </el-dialog>
  <el-dialog v-model="importCompleted" :close-on-click-modal="false" width="30%" @close="colsedialogall">
    <template #header>
      <div>导入完成提示</div>
    </template>
    <h3>导入完成，本次导入成功机构{{ tableData.successCount }}个。</h3>
    <div class="error-table-footer">
      <el-button type="primary" @click="colsedialogall">我知道了</el-button>
    </div>
  </el-dialog>
</template>

<script setup>
import { ElMessage } from 'element-plus'
import { watch, ref, nextTick, onMounted } from 'vue'
import CommonApi from '../server/api.ts'

let errorTableVisible = ref(false)
let passImportConfirm = ref(false) // 跳过确认
let importCompleted = ref(false) // 导入完成
let loading = ref(false)
let multipleSelection = ref([])
let emits = defineEmits(['update:modelValue', 'updateTableData', 'getQueryComListPage'])
let props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  tableData: {
    type: Object,
    default() {
      return [
        {
          successCount: '',
          failedResult: [],
          failedCount: '',
        },
      ]
    },
  },
  passDialogFlag: {
    type: Boolean,
    default: true,
  },
})
let allCountImport = ref('') // 上传文件总数
watch(
  () => props.modelValue,
  (nVal) => {
    errorTableVisible.value = nVal
  },
  { immediate: true }
)

watch(
  () => props.tableData,
  (nVal) => {
    if (nVal.successCount) {
      nextTick(() => {
        allCountImport.value = nVal.successCount
      })
    }
  }
)

// 监听错误列表，如果传入的值为空，则表示无错误选项即导入成功
watch(
  () => props.tableData.failedResult,
  (nVal) => {
    if (nVal.length == '0') {
      errorTableVisible.value = false // 错误数据弹窗隐藏
      passImportConfirm.value = false // 跳过弹窗隐藏
      importCompleted.value = true // 导入完成弹窗显示
    }
  }
)

const Base64 = {
  _keyStr: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
  encode: function (e) {
    var t = ''
    var n, r, i, s, o, u, a
    var f = 0
    e = Base64._utf8_encode(e)
    while (f < e.length) {
      n = e.charCodeAt(f++)
      r = e.charCodeAt(f++)
      i = e.charCodeAt(f++)
      s = n >> 2
      o = ((n & 3) << 4) | (r >> 4)
      u = ((r & 15) << 2) | (i >> 6)
      a = i & 63
      if (isNaN(r)) {
        u = a = 64
      } else if (isNaN(i)) {
        a = 64
      }
      t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
    }
    return t
  },
  decode: function (e) {
    var t = ''
    var n, r, i
    var s, o, u, a
    var f = 0
    e = e.replace(/[^A-Za-z0-9+/=]/g, '')
    while (f < e.length) {
      s = this._keyStr.indexOf(e.charAt(f++))
      o = this._keyStr.indexOf(e.charAt(f++))
      u = this._keyStr.indexOf(e.charAt(f++))
      a = this._keyStr.indexOf(e.charAt(f++))
      n = (s << 2) | (o >> 4)
      r = ((o & 15) << 4) | (u >> 2)
      i = ((u & 3) << 6) | a
      t = t + String.fromCharCode(n)
      if (u != 64) {
        t = t + String.fromCharCode(r)
      }
      if (a != 64) {
        t = t + String.fromCharCode(i)
      }
    }
    t = Base64._utf8_decode(t)
    return t
  },
  _utf8_encode: function (e) {
    e = e.replace(/rn/g, 'n')
    var t = ''
    for (var n = 0; n < e.length; n++) {
      var r = e.charCodeAt(n)
      if (r < 128) {
        t += String.fromCharCode(r)
      } else if (r > 127 && r < 2048) {
        t += String.fromCharCode((r >> 6) | 192)
        t += String.fromCharCode((r & 63) | 128)
      } else {
        t += String.fromCharCode((r >> 12) | 224)
        t += String.fromCharCode(((r >> 6) & 63) | 128)
        t += String.fromCharCode((r & 63) | 128)
      }
    }
    return t
  },
  _utf8_decode: function (e) {
    var t = ''
    var n = 0
    var r = (c1 = c2 = 0)
    while (n < e.length) {
      r = e.charCodeAt(n)
      if (r < 128) {
        t += String.fromCharCode(r)
        n++
      } else if (r > 191 && r < 224) {
        c2 = e.charCodeAt(n + 1)
        t += String.fromCharCode(((r & 31) << 6) | (c2 & 63))
        n += 2
      } else {
        c2 = e.charCodeAt(n + 1)
        c3 = e.charCodeAt(n + 2)
        t += String.fromCharCode(((r & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63))
        n += 3
      }
    }
    return t
  },
}

// 设置每行的index
const tableRowClassName = ({ row, rowIndex }) => {
  row.row_index = rowIndex
}
//选择表格checkbox事件
const tableCheckBoxChange = (e) => {
  multipleSelection.value = e
}
//表格数据导入
const onSubmitTable = async () => {
  if (multipleSelection.value.length === 0) {
    ElMessage.error('请选择要导入的数据')
    return
  }
  let params = multipleSelection.value.map((i) => {
    return {
      agencyName: i.agencyName.value,
      unifiedCreditCode: i.unifiedCreditCode.value,
      agyMainPerson: i.agyMainPerson.value,
      agyMainPersonMobile: i.agyMainPersonMobile.value,
    }
  })
  try {
    loading.value = true
    let { data } = await CommonApi.repeatImportMechanism(
      {
        base64Json: Base64.encode(JSON.stringify(params)),
      },
      { headers: { EnterpriseType: 'MECHANISM' } }
    )
    loading.value = false
    if (data.length < params.length) {
      //返回数据长度小于原来的长度 认为有导入成功的数据，要重新刷组织架构数据
      emits('getQueryComListPage')
    }
    //选中要导入的数组索引
    let multipleIndex = multipleSelection.value.map((item) => item.row_index)
    //更新错误数据表格
    let updataArray = data
    emits('updateTableData', { updataArray, multipleIndex })
  } catch (error) {
    console.log(error)
    loading.value = false
  }
}
/**
 * 跳过错误项弹窗
 */
const passWrongData = async () => {
  passImportConfirm.value = true
}
// 确认跳过
const commitPass = () => {
  passImportConfirm.value = false
  errorTableVisible.value = false
  importCompleted.value = true
}
// 取消跳过
const cancelPass = () => {
  passImportConfirm.value = false
  errorTableVisible.value = true
}
// 跳过弹窗关闭
const passclose = () => {
  passImportConfirm.value = false
}
// 导入完成提示
const colsedialogall = () => {
  emits('getQueryComListPage')
  importCompleted.value = false
  emits('update:modelValue', false)
}
const closeWrongData = () => {
  // emits('update:modelValue', false)
  if (props.passDialogFlag) {
    // 跳过弹窗控制
    passImportConfirm.value = true
  }
}

onMounted(() => {})
</script>

<style lang="scss" scoped>
.titleTips {
  margin: 10px 50% 10px 0;
}
.error-table-container {
  max-height: 50vh;
  overflow: auto;
  .td-red {
    ::v-deep(.el-input__inner) {
      color: red;
      border-color: red;
    }
  }
}

.error-table-footer {
  display: flex;
  justify-content: center;
  margin-top: 30px;
  align-items: center;
  .passImport {
    text-decoration: underline;
  }
  .el-button {
    width: 120px;
    font-size: 14px;
  }
}
.el-select-dropdown__item {
  padding: 0 32px 0 20px !important;
}
</style>
