<template>
  <div class="topBtnStyle">
    <div class="rightBtn">
      <el-button v-for="(item, index) in btnArray" :key="index" @click="changeView(item.btnUrl)" :type="currentUrl == item.btnUrl ? 'primary' : ''">{{ item.btnName }}</el-button>
    </div>
    <el-button type="primary" @click="router.go(-1)">返回</el-button>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
const router = useRouter()

const btnArray = ref([
  { btnName: '企业基本信息', btnUrl: '/institutionReview/entBasicInfo' },
  { btnName: '安全生产基本信息', btnUrl: '/institutionReview/safetyProductionBasicInfo' },
  { btnName: '风险标签', btnUrl: '/institutionReview/riskLabel' },
  { btnName: '上报汇总信息', btnUrl: '/institutionReview/summaryInfo' },
])

// 获取当前页面路由
const currentUrl = computed(() => {
  return router.currentRoute.value.path
})
// 按钮页面跳转
const changeView = (url) => {
  router.push(url)
}

onMounted(() => {})
</script>
<style lang="scss" scoped>
.topBtnStyle {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 100%;
}
</style>
