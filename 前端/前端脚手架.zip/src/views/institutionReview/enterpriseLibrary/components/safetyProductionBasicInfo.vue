<!-- 安全生产基本信息 -->
<template>
  <el-container>
    <el-header>
      <top_btn></top_btn>
    </el-header>
    <el-main>
      <div class="top_title">
        <h2 class="safetyTitle">安全生产基本信息</h2>
        <el-icon size="large" class="editIcon" @click="editBasic"><el-icon-edit /></el-icon>
      </div>
      <!-- 安全生产基本信息表单 -->
      <activeForm ref="formRef" :fieldConfig="formConfig" :postFormData="formData" :form-edit="editTarget" :labelWidth="'280px'" labelPosition="right" @updateOriData="updateOriData"></activeForm>
    </el-main>
    <el-footer align="center">
      <div v-if="editTarget">
        <el-button type="primary" @click="saveToUpdata(formRef)">保存并更新</el-button>
        <el-button @click="cancelBtn(formRef)">取消</el-button>
      </div>
    </el-footer>
  </el-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElLoading } from 'element-plus'
import CommonApi from '../server/api'
import activeForm from '@/views/common/jsonForm/activeForm.vue'
import top_btn from './topBtn'

const safetyFromData = ref({
  name: '',
})
let formData = ref({})
let formConfig = ref({})
// 表单元素
let formRef = ref(null)
const fieldConfig = ref({})
let editTarget = ref(false)
// 编辑按钮
const editBasic = () => {
  editTarget.value = true
}
// 表单原始数据
let orgData = ref({})
const updateOriData = (key, data) => {
  orgData.value[key] = data
}
// 获取安全生产基本信息动态表单数据
const getTemplate = () => {
  // 获取动态模板信息 企业人员信息：ENTERPRISE_PERSON，企业基本信息：ENTERPRISE_INFO，机构人员信息：MECHANISM_PERSON，机构基本信息：MECHANISM_INFO
  CommonApi.getTemplateByProject(
    { templateType: 'ENTERPRISE_INFO', EnterpriseType: 'ENTERPRISE' },
    { headers: { AppSecretKey: '9189oX20o6DP98691EX1R0PI19NV6w49', ProjectId: 'd3eff06d88f90fb5b8ea44439aa3d8c0', EnterpriseType: 'ENTERPRISE' } }
  ).then((res) => {
    let temconfig = res?.data?.templateFileUrl ? JSON.parse(window.decodeURIComponent(res?.data?.templateFileUrl)) : {}
    fieldConfig.value = temconfig?.web?.baseSafetyInfo || {}
    formConfig.value = _.cloneDeep(fieldConfig.value)
  })
}
// 保存并刷新
const saveToUpdata = (formEl) => {
  if (!formEl.activeFormRef) return
  formEl.activeFormRef.validate((valid) => {
    if (valid) {
      let params = {
        ProjectId: localStorage.getItem('currentCompanyId'),
      }
      CommonApi.entUpdate({ ...params, ...formData.value }).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('修改成功')
          getEnterBaseInfo()
        } else {
          ElMessage.warning(res.message)
        }
      })
    }
  })
}
// 取消按钮
const cancelBtn = (formEl) => {
  formRef.value.activeFormRef.resetFields()
  formRef.value.dataFormat()
  editTarget.value = false
}
// 获取基本应用数据
const getEnterBaseInfo = () => {
  CommonApi.enterDetail({ agyOrEnt: 'ENTERPRISE' }, { headers: { CompanyId: localStorage.getItem('currentCompanyId') } }).then((res) => {
    if (res.code == '00000') {
      formData.value = res.data
    }
  })
}
onMounted(() => {
  getEnterBaseInfo()
  getTemplate()
})
</script>
<style lang="scss" scoped>
.top_title {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  .editIcon {
    cursor: pointer;
  }
}
.safetyFrom {
  .safetyTitle {
    padding-bottom: 20px;
  }
}
.bottomBtn {
  text-align: center;
}
.el-input {
  width: 300px;
}
</style>
