<!-- 企业基本信息 -->
<template>
  <el-container>
    <el-header>
      <top_btn></top_btn>
    </el-header>
    <el-main>
      <!-- 顶部图片区域基本信息 -->
      <div class="pictrue">
        <div class="right-p">
          <!-- <div class="pictrue_img">
            <img src="@/assets/images/1.png" alt="" />
          </div>
          <div class="pictrue_info">
            <h2>{{ formData.entName }}</h2>
            <p>
              2016-11-28&nbsp;&nbsp;|&nbsp;&nbsp;纺织行业,橡胶和塑料制品业
              <el-button size="small" type="primary">切换行业</el-button>
            </p>
            <p>人民大道2525号</p>
          </div> -->
        </div>
        <el-icon size="large" class="editIcon" @click="editBasic"><el-icon-edit /></el-icon>
      </div>
      <!-- 下部正文基本信息 -->
      <div class="basicInfoFrom">
        <activeForm ref="formRef" :fieldConfig="formConfig" :postFormData="formData" :form-edit="editTarget" :labelWidth="'260px'" labelPosition="right">
          <template #entLogo>
            <el-upload
              action="#"
              :disabled="!editTarget"
              :auto-upload="false"
              :on-change="logoFileLoad"
              :show-file-list="true"
              v-model:file-list="fileList"
              :on-remove="fileTemRemove"
              :on-preview="fileDownload"
            >
              <el-button>
                <el-icon><el-icon-folder-opened /></el-icon>
                点击上传
              </el-button>
            </el-upload>
          </template>
          <template #agyMainPerson>
            <div>
              {{ formData.agyMainPerson }}
            </div>
          </template>
          <template #agyContact>
            <div :class="editTarget ? 'pers-select' : ''">
              {{ formData?.agyContact }}
            </div>
          </template>
          <template #entContact>
            <div :class="editTarget ? 'pers-select' : ''">
              {{ formData?.entContact }}
            </div>
          </template>
          <template #techPerson>
            <div :class="editTarget ? 'pers-select' : ''">
              {{ formData?.techPerson }}
            </div>
          </template>
          <template #bizRange>
            <el-cascader
              ref="cascRef"
              v-model="formData.bizRange"
              v-if="editTarget"
              :disabled="!editTarget"
              clearable
              :placeholder="editTarget ? '请选择服务内容' : ' '"
              :options="cascData"
              :props="{ multiple: true }"
              collapse-tags
              style="width: 300px"
              collapse-tags-tooltip
            ></el-cascader>
            <div v-if="!editTarget">
              <div v-for="item of callbackRange()" :key="item">
                <span>{{ item[0] }}:{{ item[1] }}</span>
              </div>
            </div>
          </template>
          <template #registerDate>
            <el-date-picker
              ref="dateRef"
              v-model="formData.dateValue"
              placeholder=" "
              :disabled-date="disabledDate"
              :disabled="!editTarget"
              @change="dateChange"
              :format="'YYYY-MM-DD'"
              :value-format="'YYYY-MM-DD'"
            ></el-date-picker>
          </template>
          <template #agencyAptitude>
            <div>
              <el-radio-group v-model="formData.agencyAptitude.status" v-if="editTarget" @change="agencyyAptitudeChange">
                <el-radio :label="true">是</el-radio>
                <el-radio :label="false">否</el-radio>
              </el-radio-group>
              <div v-else>{{ formData.agencyAptitude?.status ? '是' : '否' }}</div>
              <div class="file-load-container">
                <div class="uploader-container" v-if="editTarget && formData.agencyAptitude.status">
                  <el-upload action="" :auto-upload="false" :on-change="agencyAptitudeFileLoad" :show-file-list="false">
                    <el-button>上传附件</el-button>
                  </el-upload>
                  <span class="files-limit">可上传 .pdf .docx .doc .png .jpg .jpeg</span>
                </div>
                <div class="file-container" v-if="!!formData.agencyAptitude.cert.length">
                  <div class="file-item" v-for="(item, index) of formData.agencyAptitude.cert" :key="item">
                    <span class="file-name" :title="urlToFileName(item)">{{ urlToFileName(item) }}</span>
                    <span class="close-icon" v-if="editTarget" @click="agencyAptitudeItemDel(index)">
                      <el-icon>
                        <el-icon-CircleClose />
                      </el-icon>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </template>
          <template #adminRegion>
            <el-cascader
              v-if="editTarget"
              :options="areaOptions"
              v-model="formData.regionValue"
              ref="regionRef"
              placeholder=" "
              @change="regionChange"
              :disabled="!editTarget"
              :clearable="true"
            ></el-cascader>
            <span v-else>{{ formData.regionText }}</span>
          </template>
          <template #workAddress>
            <el-button type="primary" v-if="editTarget" @click="addressEditShow('add')">添加办公地址</el-button>
            <el-table :data="formData.workAddress" border>
              <el-table-column type="index" label="序号" width="60"></el-table-column>
              <el-table-column label="生产场所详细地址" prop="pSiteFullAddr"></el-table-column>
              <el-table-column label="操作" v-if="editTarget">
                <template #default="scope">
                  <div class="fnc-btn-container">
                    <span class="fnc-btn" @click="addressEditShow('edit', scope)">编辑</span>
                    <el-popconfirm title="你确定要删除这行内容吗？" @confirm="certiDel(formData.workAddress, scope.$index)">
                      <template #reference>
                        <span class="del-btn fnc-btn">删除</span>
                      </template>
                    </el-popconfirm>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </template>
          <!-- 诚信承诺书 -->
          <template #promise>
            <div class="file-load-container">
              <div class="uploader-container" v-if="editTarget">
                <el-upload action="" :disabled="!!formData.promise" :auto-upload="false" :on-change="promiseFileLoad" :show-file-list="false">
                  <el-button :disabled="!!formData.promise">上传附件</el-button>
                </el-upload>
                <span class="files-limit">可上传 .pdf .docx .doc .png .jpg .jpeg</span>
              </div>
              <div class="file-container">
                <div class="file-item" v-if="formData.promise">
                  <span class="file-name" :title="urlToFileName(formData.promise)">{{ urlToFileName(formData.promise) }}</span>
                  <span class="close-icon" v-if="editTarget" @click="promiseCertClear">
                    <el-icon>
                      <el-icon-CircleClose />
                    </el-icon>
                  </span>
                </div>
              </div>
            </div>
          </template>
          <!-- 营业执照 -->
          <template #businessLicence>
            <div class="file-load-container">
              <div class="uploader-container" v-if="editTarget">
                <el-upload action="" :disabled="!!formData.businessLicence" :auto-upload="false" :on-change="businessLicenceFileLoad" :show-file-list="false">
                  <el-button :disabled="!!formData.businessLicence">上传附件</el-button>
                </el-upload>
                <span class="files-limit">可上传 .pdf .docx .doc .png .jpg .jpeg</span>
              </div>
              <div class="file-container">
                <div class="file-item" v-for="(item, index) in formData.businessLicence" :key="item">
                  <span class="file-name" :title="urlToFileName(item)">{{ urlToFileName(item) }}</span>
                  <span class="close-icon" v-if="editTarget" @click="certLetterDelItem(index)">
                    <el-icon>
                      <el-icon-CircleClose />
                    </el-icon>
                  </span>
                </div>
              </div>
            </div>
          </template>
          <!-- 认证公函 -->
          <template #certLetter>
            <div class="file-load-container">
              <div class="uploader-container" v-if="editTarget">
                <el-upload action="" :disabled="formData.certLetter?.length == 2" :auto-upload="false" :on-change="certLetterFileLoad" :show-file-list="false">
                  <el-button :disabled="formData.certLetter?.length == 2">上传附件</el-button>
                </el-upload>
                <span class="files-limit">可上传 .pdf .docx .doc .png .jpg .jpeg</span>
              </div>
              <div class="file-container" v-if="formData.certLetter">
                <div class="file-item" v-for="(item, index) in formData.certLetter" :key="item">
                  <span class="file-name" :title="urlToFileName(item)">{{ urlToFileName(item) }}</span>
                  <span class="close-icon" v-if="editTarget" @click="certLetterDelItem(index)">
                    <el-icon>
                      <el-icon-CircleClose />
                    </el-icon>
                  </span>
                </div>
              </div>
            </div>
          </template>
          <template #agencyCert>
            <el-button type="primary" v-if="editTarget" @click="addcerfnc('add')">添加证书信息</el-button>
            <el-table :data="formData.agencyCert" border>
              <el-table-column type="index" label="序号" width="60"></el-table-column>
              <el-table-column label="资质名称" prop="name"></el-table-column>
              <el-table-column label="资质编号" prop="no"></el-table-column>
              <el-table-column label="截至有效期" prop="expire"></el-table-column>
              <el-table-column label="附件">
                <template #default="scope">
                  {{ urlToFileName(scope.row.attachment) }}
                </template>
              </el-table-column>
              <el-table-column label="操作" v-if="editTarget">
                <template #default="scope">
                  <div class="fnc-btn-container">
                    <span class="fnc-btn" @click="addcerfnc('edit', scope)">编辑</span>
                    <el-popconfirm title="你确定要删除这行内容吗？" @confirm="certiDel(formData.agencyCert, scope.$index)">
                      <template #reference>
                        <span class="del-btn fnc-btn">删除</span>
                      </template>
                    </el-popconfirm>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </template>
        </activeForm>
      </div>
    </el-main>
    <el-footer align="center">
      <div v-if="editTarget">
        <el-button type="primary" @click="saveToUpdata(formRef)">保存并更新</el-button>
        <el-button @click="cancelBtn(formRef)">取消</el-button>
      </div>
    </el-footer>
  </el-container>
</template>

<script setup>
import { ref, onMounted, getCurrentInstance } from 'vue'
import { ElMessage, ElLoading } from 'element-plus'
import top_btn from './topBtn'
import CommonApi from '../server/api'
import activeForm from '@/views/common/jsonForm/activeForm.vue'
// 获取proxy实例
const { proxy } = getCurrentInstance()

// 编辑按钮
const editBasic = () => {
  editTarget.value = true
}
// 获取基本应用数据
const getEnterBaseInfo = () => {
  CommonApi.enterDetail({ agyOrEnt: 'ENTERPRISE' }, { headers: { CompanyId: localStorage.getItem('currentCompanyId') } }).then((res) => {
    if (res.code == '00000') {
      formData.value = res.data
    }
  })
}
let areaOptions = ref([])
// 时间范围显示
let disabledDate = (time) => {
  return time.getTime() > Date.now()
}
// 时间选择器组件
let dateRef = ref(null)
// 时间改变
const dateChange = (_val) => {
  const date = new Date(proxy.$TOOL.dateFormat(_val, 'yyyy-MM-dd'))
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  formData.value.dateText = `${year}年${month}月${day}日`
  formData.value.registerDate.text = formData.value.dateText
  formData.value.registerDate.value = formData.value.dateValue
}
// 编辑状态
let editTarget = ref(false)
// 动态表单数据初始化
let formConfig = ref({})
// 表单元素
let formRef = ref(null)
// 表单数据
let formData = ref({})
//
const fieldConfig = ref({})
let loading = ref(false)
// 获取动态表单模板
const getTemplate = () => {
  // 获取动态模板信息 企业人员信息：ENTERPRISE_PERSON，企业基本信息：ENTERPRISE_INFO，机构人员信息：MECHANISM_PERSON，机构基本信息：MECHANISM_INFO
  CommonApi.getTemplateByProject(
    { templateType: 'ENTERPRISE_INFO', EnterpriseType: 'ENTERPRISE' },
    { headers: { AppSecretKey: '9189oX20o6DP98691EX1R0PI19NV6w49', ProjectId: 'd3eff06d88f90fb5b8ea44439aa3d8c0', EnterpriseType: 'ENTERPRISE' } }
  ).then((res) => {
    let temconfig = res?.data?.templateFileUrl ? JSON.parse(window.decodeURIComponent(res?.data?.templateFileUrl)) : {}
    fieldConfig.value = temconfig?.web?.baseInfo || {}
    formConfig.value = _.cloneDeep(fieldConfig.value)
  })
  CommonApi.getTreeAreaPC().then((res) => {
    if (res?.code == '00000') {
      areaOptions.value = res.data
    }
    loading.value = false
  })
}

// 文件上传列表
let fileList = ref([])
// 文件上传钩子
const logoFileLoad = async (files) => {
  if (Array.isArray(formData.value.entLogo) && formData.value.entLogo.length > 0) {
    ElMessage({
      type: 'warning',
      message: '只能上传一份文件',
    })
    fileList.value.length = 1
    return
  }
  if (!fileValid(files, ['png', 'jpg', 'jpeg'], '图片格式错误')) {
    fileList.value = []
    return
  }
  let paramFile = new FormData()
  paramFile.append('file', new File([files.raw], files.name, { type: files.raw.type }))
  await CommonApi.fileUpload(paramFile)
    .then((res) => {
      if (res && res?.code == '00000' && res?.data) {
        formData.value.entLogo = []
        formData.value.entLogo[0] = res?.data[0] || ''
        fileList.value[0] = {
          name: 'logo',
          url: res?.data[0],
        }
      }
    })
    .catch((err) => {
      console.log(err)
    })
}
// 文件移除钩子函数
const fileTemRemove = () => {
  fileList.value = []
  formData.value[proxy.$globalconfig.APP_TYPE == 'ENTERPRISE' ? 'entLogo' : 'agencyLogo'] = ''
}
// 利用fetch进行文件下载
const fileDownload = () => {
  let fileurl = formData.value[proxy.$globalconfig.APP_TYPE == 'ENTERPRISE' ? 'entLogo' : 'agencyLogo'][0]
  const aLink = document.createElement('a')
  aLink.style.display = 'none'
  fetch(fileurl)
    .then((res) => res.blob())
    .then((blob) => {
      aLink.href = window.URL.createObjectURL(blob)
      aLink.download = urlToFileName(fileurl)
      document.body.appendChild(aLink)
      aLink.click()
      URL.revokeObjectURL(aLink.href)
      document.body.removeChild(aLink)
    })
}
let regionRef = ref(null)
const regionChange = (val) => {
  let checkedNodes = regionRef.value?.getCheckedNodes()[0]
  if (!checkedNodes) {
    formData.value.adminRegion = {
      text: '',
      value: [],
    }
    return
  }
  let { pathLabels, pathValues } = checkedNodes
  formData.value.regionText = pathLabels.join('/')
  formData.value.regionValue = pathValues
  formData.value.adminRegion = {
    text: formData.value.regionText,
    value: formData.value.regionValue,
  }
}
// 营业执照文件上传
const businessLicenceFileLoad = async (files) => {
  if (Array.isArray(formData.value.businessLicence) && formData.value.businessLicence.length > 0) {
    ElMessage.warning('最多上传一个文件')
    return false
  }
  if (!fileValid(files)) return
  let paramFile = new FormData()
  paramFile.append('file', new File([files.raw], files.name, { type: files.raw.type }))
  await CommonApi.fileUpload(paramFile)
    .then((res) => {
      if (res && res?.code == '00000' && res?.data) {
        formData.value.businessLicence = []
        formData.value.businessLicence[0] = res.data[0]
        formRef.value.activeFormRef.validateField('businessLicence')
      }
    })
    .catch(() => {})
}
// 认证公函上传
const certLetterFileLoad = async (files) => {
  if (!Array.isArray(formData.value.certLetter)) {
    formData.value.certLetter = []
  }
  if (formData.value.certLetter?.length == 2) {
    ElMessage.warning('最多上传两个文件')
    return false
  }
  if (!fileValid(files)) return
  let paramFile = new FormData()
  paramFile.append('file', new File([files.raw], files.name, { type: files.raw.type }))
  await CommonApi.fileUpload(paramFile)
    .then((res) => {
      if (res && res?.code == '00000' && res?.data) {
        formData.value.certLetter.push(res.data[0])
        formRef.value.activeFormRef.validateField('certLetter')
      }
    })
    .catch((err) => {
      console.log(err)
    })
}
// 保存并刷新
const saveToUpdata = (formEl) => {
  if (!formEl.activeFormRef) return
  formEl.activeFormRef.validate((valid) => {
    if (valid) {
      let params = {
        ProjectId: localStorage.getItem('currentCompanyId'),
      }
      CommonApi.entUpdate({ ...params, ...formData.value }).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('修改成功')
          getEnterBaseInfo()
        } else {
          ElMessage.warning(res.message)
        }
      })
    }
  })
}
// 取消按钮
const cancelBtn = (formEl) => {
  formRef.value.activeFormRef.resetFields()
  formRef.value.dataFormat()
  editTarget.value = false
}
onMounted(() => {
  getEnterBaseInfo()
  getTemplate()
})
</script>
<style lang="scss" scoped>
.pictrue {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  .right-p {
    display: flex;
    flex-direction: row;
  }
  .pictrue_img {
    width: 120px;
    height: 120px;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .pictrue_info {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    margin-left: 20px;
  }
  .editIcon {
    cursor: pointer;
  }
}
.basicInfoFrom {
  padding: 5px 0;
}
.el-input {
  width: 300px;
}
</style>
