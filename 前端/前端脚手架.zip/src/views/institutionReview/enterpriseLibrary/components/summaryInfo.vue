上报汇总信息
<template>
  <el-container>
    <el-header>
      <top_btn></top_btn>
    </el-header>
    <el-main>
      <div class="topBox">
        <h2>上报汇总信息</h2>
        <el-button type="primary" @click="showOperationLog">操作记录</el-button>
      </div>
    </el-main>
    <el-footer></el-footer>
  </el-container>
  <!-- 操作记录列表弹窗 -->
  <el-drawer v-model="operationWindow" title="操作记录" direction="rtl" size="40%">
    <el-container>
      <el-main class="nopadding">
        <el-table ref="table" :data="operationTable" height="100%" style="width: 100%">
          <el-table-column label="操作人" align="center" prop="createUserName" min-width="200"></el-table-column>
          <el-table-column label="操作内容" align="center" prop="operationRecordContent" min-width="300"></el-table-column>
          <el-table-column label="操作时间" align="center" prop="createTime" min-width="200"></el-table-column>
        </el-table>
      </el-main>
      <el-footer class="bodyPage">
        <div class="leftButton"></div>
        <el-pagination
          background
          @current-change="OPcurrentPageChange"
          @size-change="OPpageSizeChange"
          :page-size="OPpageSize"
          :current-page="OPpage"
          :small="true"
          :page-sizes="[10, 20, 30, 40, 50]"
          :total="OPtotal"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </el-footer>
    </el-container>
  </el-drawer>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElLoading } from 'element-plus'
import top_btn from './topBtn'
import CommonApi from '../server/api'

// 👇👇👇👇👇👇👇👇👇操作记录分页数据👇👇👇👇👇👇👇👇👇👇👇
// 操作记录分页当前页数
let OPpage = ref(1)
// 操作记录分页一页多少条
let OPpageSize = ref(10)
// 操作记录分页总条数
let OPtotal = ref(0)
// 操作记录分页切换页数
const OPcurrentPageChange = (val) => {
  OPpage.value = Number(val.toString().split('.')[0])
  getOperationData()
}
// 操作记录分页切换每页条数
const OPpageSizeChange = (val) => {
  OPpageSize.value = val
  getOperationData()
}
// 👆👆👆👆👆👆👆👆👆操作记录分页数据👆👆👆👆👆👆👆👆👆👆👆
// 操作弹窗标识
let operationWindow = ref(false)
const showOperationLog = () => {
  operationWindow.value = true
  getOperationData()
}
// 操作记录表格数据初始化
let operationTable = ref([])
// 获取操作记录列表数据
const getOperationData = () => {
  let params = {
    pageNo: OPpage.value,
    pageSize: OPpageSize.value,
  }
  CommonApi.getOperationRecord(params).then((res) => {
    if (res.code == '00000') {
      operationTable.value = res.data.rows
      OPtotal.value = res.data.totalRows
    } else {
      ElMessage(res.message)
    }
  })
}
onMounted(() => {})
</script>
<style lang="scss" scoped>
.topBox {
  display: flex;
  justify-content: space-between;
  padding: 15px 0;
  border-bottom: 1px solid #e9e9eb;
}
</style>
