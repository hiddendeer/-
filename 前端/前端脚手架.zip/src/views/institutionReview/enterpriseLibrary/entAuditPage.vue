<template>
  <el-container>
    <el-header>
      <div class="left-panel">
        <el-button type="primary" @click="router.back()">返回</el-button>
      </div>
      <div class="right-panel">
        <el-button @click="reloadBtn">刷新</el-button>
      </div>
    </el-header>
    <el-main class="nopadding">
      <scTable ref="table" :data="tableData" row-key="id" stripe hidePagination hideDo>
        <el-table-column label="序号" align="center" type="index" width="100" :index="indexMethod" />
        <el-table-column label="企业名称" align="center" prop="mechanismName" min-width="300"></el-table-column>
        <el-table-column label="社会信用代码" align="center" prop="unifiedCreditCode" width="200"></el-table-column>
        <el-table-column label="企业填报人" align="center" prop="responsiblePerson" width="200"></el-table-column>
        <el-table-column label="联系方式" align="center" prop="phone" width="200"></el-table-column>
        <el-table-column label="申请时间" align="center" prop="createDate" min-width="300"></el-table-column>
        <el-table-column label="操作" fixed="right" align="center" min-width="150">
          <template #default="scope">
            <el-button-group>
              <el-button text type="primary" size="small" @click="showAuditWindow(scope.row.auditRecordId)" v-if="scope.row.isNotAppRoved">审核</el-button>
              <el-button text size="small" disabled v-else>已审核</el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </scTable>
    </el-main>
    <el-footer class="bodyPage">
      <div class="leftButton"></div>
      <el-pagination
        background
        @current-change="currentPageChange"
        @size-change="pageSizeChange"
        :page-size="pageSize"
        :current-page="page"
        :small="true"
        :page-sizes="[10, 20, 30, 40, 50]"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
      ></el-pagination>
    </el-footer>
  </el-container>
  <!-- 审核结果弹窗 -->
  <el-dialog v-model="auditResultWindow" width="20%" :close-on-click-modal="false">
    <template #header>
      <div class="z_title">审核结果</div>
    </template>
    <div class="btnBox">
      <el-button type="danger" @click="confirmBtn('FAILED')">未通过</el-button>
      <el-button type="primary" @click="confirmBtn('PASSED')">通过</el-button>
    </div>
    <div class="failBox">
      <el-input v-model="auditContent" :rows="3" type="textarea" placeholder="此处可填写审核未通过原因" />
    </div>
  </el-dialog>
  <!-- 审核确认弹窗 -->
  <el-dialog v-model="commitWindow" width="20%" :close-on-click-modal="false">
    <template #header>
      <div class="z_title">确认审核</div>
    </template>
    <div class="btnBox">
      <el-button type="danger" @click="cancelAudit">取消</el-button>
      <el-button type="primary" @click="commitAudit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import router from '@/router'
import CommonApi from './server/api'
import { ElMessage } from 'element-plus'
//当前页数
let page = ref(1)
//一页多少条
let pageSize = ref(10)
//总条数
let total = ref(0)
//序号计算
const indexMethod = (index) => {
  return (page.value - 1) * pageSize.value + index + 1
}
// 不用过原因
let auditContent = ref('')
// 审核结果弹窗标识
let auditResultWindow = ref(false)
// 二次确认弹窗标识
let commitWindow = ref(false)
// 审核ID接收中转
let auditIdTemp = ref('')
// 审核结果中转
let auditResultTemp = ref('')
// 审核结果弹窗按钮
const showAuditWindow = (data) => {
  // 清空未通过原因
  auditContent.value = ''
  auditResultWindow.value = true
  auditIdTemp.value = data
}
//切换页数
const currentPageChange = (val) => {
  page.value = Number(val.toString().split('.')[0])
  getAuditRecordList()
}
//切换每页条数
const pageSizeChange = (val) => {
  pageSize.value = val
  getAuditRecordList()
}
// 列表数据
const tableData = ref([])
// 刷新列表
const reloadBtn = () => {
  getAuditRecordList()
}
/**
 * 审核弹窗按钮
 * @param {未通过/通过 按钮传值} data
 */
const confirmBtn = (data) => {
  if (data === 'FAILED' && auditContent.value.length == 0) {
    ElMessage('请填写未通过原因')
    return false
  }
  auditResultTemp.value = data
  commitWindow.value = true
}
// 二次确认弹窗取消按钮
const cancelAudit = () => {
  commitWindow.value = false
}
// 二次确认弹窗确认按钮
const commitAudit = () => {
  CommonApi.auditExamine({
    auditRecordId: auditIdTemp.value,
    auditStatus: auditResultTemp.value,
    auditDesc: auditContent.value,
  }).then((res) => {
    if (res.code == '00000') {
      ElMessage.success('操作成功')
      auditResultWindow.value = false
      commitWindow.value = false
      getAuditRecordList()
    } else {
      ElMessage(res.message)
      auditResultWindow.value = false
      commitWindow.value = false
      getAuditRecordList()
    }
  })
}
// 获取审核机构列表
const getAuditRecordList = () => {
  let params = {
    pageNo: page.value,
    pageSize: pageSize.value,
    businessType: 'ENTERPRISE',
  }
  CommonApi.auditRecordList({ ...params }).then((res) => {
    if (res.code == '00000') {
      tableData.value = res.data.list
      total.value = res.data.total
    } else {
      ElMessage.warning(res.message)
    }
  })
}
onMounted(() => {
  getAuditRecordList()
})
</script>
<style lang="scss" scoped>
.z_title {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 10px;
  font-size: 18px;
  color: #000000;
}
.btnBox {
  display: flex;
  align-items: center;
  justify-content: center;
  .el-button.el-button--danger {
    width: 120px;
  }
  .el-button.el-button--primary {
    width: 120px;
  }
}
.failBox {
  padding: 20px 10px;
}
.bodyPage {
  display: flex;
  justify-content: space-between;
  .leftButton {
    display: flex;
    align-items: center;
    .forbidden {
      margin-left: 20px;
    }
  }
}
</style>
