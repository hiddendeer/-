<template>
  <el-container>
    <el-aside width="300px">
      <el-container>
        <el-header>
          <el-input placeholder="输入关键字进行过滤" v-model="groupFilterText" clearable></el-input>
        </el-header>
        <el-main class="nopadding">
          <el-tabs type="border-card" @tab-change="tabChange">
            <el-tab-pane label="行政划分">
              <el-tree
                ref="group"
                class="menu"
                node-key="value"
                accordion
                :data="groupData"
                :default-expanded-keys="['10']"
                :highlight-current="true"
                :expand-on-click-node="false"
                :filter-node-method="groupFilterNode"
                @node-click="groupClick"
              >
                <template #default="{ node, data }">
                  <span class="custom-tree-node">
                    <el-tooltip class="box-item" effect="dark" :content="data.label" placement="top-start">
                      <span class="label">{{ data.label }}</span>
                    </el-tooltip>
                  </span>
                </template>
              </el-tree>
            </el-tab-pane>
            <el-tab-pane label="监管划分">
              <el-tree
                ref="group"
                class="menu"
                accordion
                node-key="value"
                :data="groupData"
                :current-node-key="''"
                :highlight-current="true"
                :expand-on-click-node="false"
                :filter-node-method="groupFilterNode"
                @node-click="groupClick"
              >
                <template #default="{ node, data }">
                  <span class="custom-tree-node">
                    <el-tooltip class="box-item" effect="dark" :content="data.label" placement="top-start">
                      <span class="label">{{ data.label }}</span>
                    </el-tooltip>
                  </span>
                </template>
              </el-tree>
            </el-tab-pane>
          </el-tabs>
        </el-main>
      </el-container>
    </el-aside>
    <el-container>
      <el-header style="height: 35%">
        <div class="search">
          <el-form-item label="经营许可状态：" label-width="120px">
            <div class="search_param">
              <el-checkbox-group v-model="searchParams.bizLicenseStatus" size="small">
                <el-checkbox-button v-for="(item, index) in bizLicenseState" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-checkbox-button>
              </el-checkbox-group>
            </div>
          </el-form-item>
          <el-form-item label="企业生产状态：" label-width="120px">
            <div class="search_param">
              <el-radio-group v-model="searchParams.bizLicenseState" size="small">
                <el-radio-button v-for="(item, index) in bizLicenseArray" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-radio-button>
              </el-radio-group>
            </div>
          </el-form-item>
          <el-form-item label="监管等级：" label-width="120px">
            <div class="search_param">
              <el-radio-group v-model="searchParams.custodyGrade" size="small">
                <el-radio-button v-for="(item, index) in custodyGradeArray" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-radio-button>
              </el-radio-group>
            </div>
          </el-form-item>
          <el-form-item label="风险点类型：" label-width="120px">
            <div class="search_param">
              <el-checkbox-group v-model="searchParams.entRiskTag" size="small">
                <el-checkbox-button v-for="(item, index) in entRiskTagArray" :key="index" :label="item.dictCode">
                  {{ item.label }}
                </el-checkbox-button>
              </el-checkbox-group>
            </div>
          </el-form-item>
          <el-form-item>
            <el-form-item label="企业名称：" label-width="120px">
              <el-input v-model="searchParams.entName" placeholder="请输入企业名称" clearable />
            </el-form-item>
            <el-button type="primary" style="margin-left: 10px" @click="selectEnter">查询</el-button>
            <el-button type="primary" @click="reload">重置</el-button>
          </el-form-item>
        </div>
        <div class="right-panel">
          <el-button type="primary" @click="addEnter('add')">+新增</el-button>
          <el-button @click="reloading">刷新</el-button>
          <el-button type="primary" @click="toExamine" v-if="orgSwitch">审核</el-button>
        </div>
      </el-header>
      <el-main class="nopadding">
        <scTable ref="table" :data="tableData" row-key="id" stripe hidePagination hideDo>
          <el-table-column label="监管单位" align="center" prop="unifiedCreditCode" width="100">{{ '-' }}</el-table-column>
          <el-table-column label="企业名称" align="center" prop="entName" width="200"></el-table-column>
          <el-table-column label="行业" align="center" prop="entRiskTag" width="200">{{ '-' }}</el-table-column>
          <el-table-column label="地址" align="center" prop="serviceType" width="200">
            <template #default="scope">
              <div>
                {{ formatText(scope.row.adminRegion) }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="企业生产状态" align="center" prop="bizLicenseState" min-width="100">
            <template #default="scope">
              <div>
                {{ formatText(scope.row.bizLicenseState) }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="经营许可状态" align="center" prop="bizLicenseStatus" width="200">
            <template #default="scope">
              <div>
                {{ formatStatus(scope.row.bizLicenseStatus) }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="火灾防范重点行业" align="center" prop="entMainPerson" width="200">{{ '-' }}</el-table-column>
          <el-table-column label="厂房权属" align="center" prop="entMainPersonMobile" width="100">{{ '-' }}</el-table-column>
          <el-table-column label="安全管理员" align="center" prop="entSafetyPerson" width="100"></el-table-column>
          <el-table-column label="安全负责人" align="center" prop="entMainPerson" width="100"></el-table-column>
          <el-table-column label="单位账号" align="center" prop="agencyPersonCnt" width="100">{{ '-' }}</el-table-column>
          <el-table-column label="创建时间" align="center" prop="createDate" width="150"></el-table-column>
          <el-table-column label="操作" fixed="right" align="center" width="200">
            <template #default="scope">
              <el-dropdown>
                <el-button text type="primary" size="small">
                  更多操作
                  <el-icon class="el-icon--right"><el-icon-arrow-down /></el-icon>
                </el-button>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item>调整组织</el-dropdown-item>
                    <el-dropdown-item>重置管理员密码</el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
              <el-button text type="primary" size="small" @click="jumpToBasicInfo(scope.row.companyId)">企业履历</el-button>
            </template>
          </el-table-column>
        </scTable>
      </el-main>
      <el-footer class="bodyPage">
        <div class="leftButton"></div>
        <el-pagination
          background
          @current-change="currentPageChange"
          @size-change="pageSizeChange"
          :page-size="pageSize"
          :current-page="page"
          :small="true"
          :page-sizes="[10, 20, 30, 40, 50]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </el-footer>
    </el-container>
  </el-container>
  <!-- 新增弹窗 -->
  <el-dialog v-model="addEnterFlag" width="40%" :close-on-click-modal="false" @closed="resetForm(insRuleFrom)">
    <template #header>
      <div class="z_title">新增</div>
    </template>
    <el-form ref="insRuleFrom" :model="enterForm" :rules="insSetFormRules" label-width="150px" class="demo-ruleForm" status-icon>
      <el-form-item label="企业名称：" prop="entName">
        <el-input v-model="enterForm.entName" placeholder="请输入企业名称" maxlength="32" show-word-limit clearable />
      </el-form-item>
      <el-form-item label="社会信用代码：" prop="unifiedCreditCode">
        <el-input
          v-model="enterForm.unifiedCreditCode"
          placeholder="请输入社会信用代码"
          @input="
            () => {
              enterForm.unifiedCreditCode = enterForm.unifiedCreditCode.replace(/[^\w]/g, '')
            }
          "
          maxlength="18"
          show-word-limit
          clearable
        />
      </el-form-item>
      <el-form-item label="主要填报人：" prop="entContact">
        <el-input v-model="enterForm.entContact" placeholder="请输入主要填报人姓名" maxlength="20" show-word-limit clearable />
      </el-form-item>
      <el-form-item label="联系方式：" prop="entContactMobile">
        <el-input
          v-model="enterForm.entContactMobile"
          placeholder="请输入主要填报人手机号"
          @input="
            () => {
              enterForm.entContactMobile = enterForm.entContactMobile.replace(/[^\d]/g, '')
            }
          "
          maxlength="11"
          show-word-limit
          clearable
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="resetForm(insRuleFrom)">取消</el-button>
        <el-button type="primary" @click="submitForm(insRuleFrom)" :loading="submitLoading">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import CommonApi from './server/api'
import { ElMessage, ElLoading } from 'element-plus'
import router from '@/router'

// 列表数据
const tableData = ref([])
// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 列表数据格式化 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
// 获取所属镇/街道
const formatText = (val) => {
  if (val) {
    return JSON.parse(val).text
  } else {
    return '-'
  }
}
// 获取经营许可状态
const formatStatus = (val) => {
  if (!val) return '-'
  let tempStatus = JSON.parse(val)
  if (tempStatus.length > 0) {
    return tempStatus
      .map((i) => {
        return i.text
      })
      .join('、')
  } else {
    return '-'
  }
}
// 新增表单数据
let enterForm = ref({
  entName: '',
  unifiedCreditCode: '',
  entContact: '',
  entContactMobile: '',
})
// 新增编辑表单ref
const insRuleFrom = ref(null)
// 新增表单校验规则
const insSetFormRules = ref({
  entName: [{ required: true, message: '请输入机构名称', trigger: 'blur' }],
  unifiedCreditCode: [
    { required: true, message: '请输入社会信用代码', trigger: 'blur' },
    {
      pattern: /^[^_IOZSVa-z\W]{2}\d{6}[^_IOZSVa-z\W]{10}$/,
      message: '请输入正确的统一信用代码',
      trigger: 'blur',
    },
  ],
  entContact: [{ required: true, message: '请输入主要填报人姓名', trigger: 'blur' }],
  entContactMobile: [
    { required: true, message: '请输入主要填报人手机号', trigger: 'blur' },
    {
      pattern: /^(?:(?:\+|00)86)?1[3-9]\d{9}$/,
      message: '请输入正确手机号',
      trigger: 'blur',
    },
  ],
})

// 机构库审核按钮开关
let orgSwitch = ref(false)
// 新增企业弹窗标识
let addEnterFlag = ref(false)
// 新增企业弹窗
const addEnter = (val) => {
  addEnterFlag.value = true
}
// 新增/编辑 弹窗按钮loading状态
const submitLoading = ref(false)
// 新增编辑 提交按钮
const submitForm = async (formEl) => {
  submitLoading.value = true
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      enterForm.value.agyOrEnt = 'ENTERPRISE'
      CommonApi.addEnter(enterForm.value, { headers: { EnterpriseType: 'ENTERPRISE' } }).then((res) => {
        if (res.code == '00000') {
          ElMessage.success('新增成功')
          formEl.resetFields()
          addEnterFlag.value = false
          submitLoading.value = false
          getGoverList()
        } else {
          ElMessage.warning(res.message)
          submitLoading.value = false
        }
      })
    } else {
      console.log('error submit!', fields)
      submitLoading.value = false
    }
  })
}
// 新增编辑 取消按钮
const resetForm = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
  addEnterFlag.value = false
}

let currentTab = ref('0')
// tabchange事件
const tabChange = (tab) => {
  currentTab.value = tab
  getTreeData()
}
// 初始化数据树过滤
let groupFilterText = ref('')
// 树数据
let groupData = ref([])
// 列表搜索关键字
let search = ref({
  keyword: '',
})
watch(
  () => groupFilterText.value,
  (nVal) => {
    group.value.filter(nVal)
  }
)
//当前页数
let page = ref(1)
//一页多少条
let pageSize = ref(10)
//总条数
let total = ref(0)
//切换页数
const currentPageChange = (val) => {
  page.value = Number(val.toString().split('.')[0])
  getGoverList()
}
//切换每页条数
const pageSizeChange = (val) => {
  pageSize.value = val
  getGoverList()
}
// 搜索项初始化
const searchParams = ref({
  adminRegion: '', // 行政区域
  entName: '', // 企业名称
  bizLicenseStatus: [], // 经营许可状态
  bizLicenseState: '', // 企业经营状态
  custodyGrade: '', // 监管等级
  entRiskTag: [], // 企业风险标签
  superviseUnit: '', // 监管单位
})
//树过滤
const groupFilterNode = (value, data) => {
  if (!value) return true
  return data.label.indexOf(value) !== -1
}
//树点击事件
const groupClick = (data) => {
  searchParams.value.adminRegion = data.value
  getGoverList()
}
// 条件筛选查询
const selectEnter = () => {
  getGoverList()
}
// 重置按钮
const reload = () => {
  searchParams.value = {
    adminRegion: '', // 行政区域
    entName: '', // 企业名称
    bizLicenseStatus: [], // 经营许可状态
    bizLicenseState: '', // 企业经营状态
    custodyGrade: '', // 监管等级
    entRiskTag: [], // 企业风险标签
    superviseUnit: '', // 监管单位
  }
  getGoverList()
  getTreeData()
}
// 刷新页面
const reloading = () => {
  getGoverList()
}
// 审核
const toExamine = () => {
  router.push('/institutionReview/entAuditPage')
}
// 企业履历
const jumpToBasicInfo = (val) => {
  localStorage.setItem('currentCompanyId', val)
  router.push('/institutionReview/entBasicInfo')
}
// 获取政府端机构列表数据
const getGoverList = () => {
  let params = {
    pageNo: page.value,
    pageSize: pageSize.value,
    agyOrEnt: 'ENTERPRISE',
  }

  CommonApi.GoverList({ ...params, ...searchParams.value }, { headers: { agyOrEnt: 'ENTERPRISE' } }).then((res) => {
    if (res.code == '00000') {
      tableData.value = res.data.records
      total.value = res.data.total
    } else {
      ElMessage.warning(res.message)
    }
  })
}
const getTreeData = () => {
  if (currentTab.value == '0') {
    // 行政划分树
    CommonApi.getSysRegion().then((res) => {
      groupData.value = res.data
    })
  } else {
    // 监管划分树
    CommonApi.getSysArea().then((res) => {
      groupData.value = res.data
    })
  }
}
// 经营许可状态初始化
let bizLicenseArray = ref([])
// 企业生产状态初始化
let bizLicenseState = ref('')
// 监管等级初始化
let custodyGradeArray = ref([])
// 风险点类型初始化
let entRiskTagArray = ref('')
// 获取查询条件字典
const getdictData = () => {
  CommonApi.dictProject({ dictTypeCode: 'AQSCJBXX' }, { headers: { EnterpriseType: 'ENTERPRISE' } }).then((res) => {
    if (res.code == '00000') {
      let resultData = res.data
      // 风险点类型初始化
      custodyGradeArray.value = resultData.find((item) => item.dictCode == 'AQSCJBXX_JGDJ')?.children
      // custodyGradeArray.value = [{ dictCode: '-1', label: '不限' }, ...custodyGradeArray.value]
    }
  })
  CommonApi.dictProject({ dictTypeCode: 'QYJBXX' }, { headers: { EnterpriseType: 'ENTERPRISE' } }).then((res) => {
    if (res.code == '00000') {
      let resultData = res.data
      // 经营许可状态初始化
      bizLicenseArray.value = resultData.find((item) => item.dictCode == 'QYJBXX_JYXKZT')?.children
      // bizLicenseArray.value = [{ dictCode: '-1', label: '不限' }, ...bizLicenseArray.value]
      // 企业生产状态初始化
      bizLicenseState.value = resultData.find((item) => item.dictCode == 'QYJBXX_QYJYZTJS')?.children
      // bizLicenseState.value = [{ dictCode: '-1', label: '不限' }, ...bizLicenseState.value]
      // 监管等级初始化
      entRiskTagArray.value = resultData.find((item) => item.dictCode == 'QYJBXX_FXFJJS')?.children
      // entRiskTagArray.value = [{ dictCode: '-1', label: '不限' }, ...entRiskTagArray.value]
    }
  })
}
// 获取机构库审核按钮开关
const getOrgSwitch = async () => {
  let data = await CommonApi.parameterConfigList()
  orgSwitch.value = data?.data.enterpriseLibraryExamine
}
onMounted(() => {
  getdictData()
  getGoverList()
  getOrgSwitch()
  getTreeData()
})
</script>
<style lang="scss" scoped>
.search {
  &_param {
    .el-checkbox-button {
      margin: 2px;
    }
    :deep(.el-checkbox-button__inner) {
      border: 1px solid #dcdfe6;
      border-radius: 4px;
    }
    .el-radio-button {
      margin: 2px;
    }
    :deep(.el-radio-button__inner) {
      border: 1px solid #dcdfe6;
      border-radius: 4px;
    }
  }
}
:deep(.el-form-item__content) {
  line-height: 0;
}
.el-header {
  align-items: end;
}
.right-panel {
  margin-bottom: 18px;
}
.z_title {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 10px;
  font-size: 22px;
  color: #000000;
}
.label {
  width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bodyPage {
  display: flex;
  justify-content: space-between;
  .leftButton {
    display: flex;
    align-items: center;
    .forbidden {
      margin-left: 20px;
    }
  }
}
.el-tabs--border-card {
  border: 0px;
}
:deep(.el-tabs__content) {
  height: 600px;
  overflow-y: auto;
}
.custom-tree-node {
  width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
