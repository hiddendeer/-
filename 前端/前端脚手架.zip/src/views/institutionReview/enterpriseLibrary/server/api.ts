import request from '@/utils/network.js'
import { paramType, auditType, statusType, logoutType, mechanismType, repeatType } from './interface'

export default class CommonApi {
  // 企业信息列表
  static GoverList = (data: paramType, config: object) => {
    return request({
      url: `/custApi/government/goverQueryPageList`,
      method: 'POST',
      data,
      ...config,
    })
  }

  // 新增企业
  static addEnter = (data: mechanismType, config: object) => {
    return request({
      url: `/custApi/government/add`,
      method: 'POST',
      data,
      ...config,
    })
  }
  // 企业详情
  static enterDetail = (params: paramType, config: object) => {
    return request({
      url: `/custApi/government/queryDetail`,
      method: 'GET',
      params,
      ...config,
    })
  }

  // 项目字典查询通用接口
  static dictProject = (params: paramType, config: object) => {
    return request({
      url: `/baseServer/projectManage/queryDictTreeByProject`,
      method: 'GET',
      params,
      ...config,
    })
  }

  // 获取审核列表查询
  static auditRecordList = (params: paramType, config: object) => {
    return request({
      url: `/baseApi/auditRecord/pageList`,
      method: 'GET',
      params,
      ...config,
    })
  }

  // 审核接口
  static auditExamine = (data: auditType) => {
    return request({
      url: `/baseApi/auditRecord/examine`,
      method: 'PUT',
      data,
    })
  }

  // 行政区域管理树
  static getSysRegion = (params: paramType) => {
    return request({
      url: `/api/sysRegion/queryTree`,
      method: 'GET',
      params,
    })
  }
  // 监管单位管理树
  static getSysArea = (params: paramType) => {
    return request({
      url: `/api/sysArea/queryTree`,
      method: 'GET',
      params,
    })
  }

  // 获取操作记录
  static getOperationRecord = (params: paramType) => {
    return request({
      url: `/baseApi/operationRecord/page`,
      method: 'GET',
      params,
    })
  }
  // 新增机构
  static addMechanism = (data: mechanismType) => {
    return request({
      url: `/baseApi/wuxiGovernment/addMechanism`,
      method: 'POST',
      data,
    })
  }
  // 编辑
  static entUpdate = (data: mechanismType) => {
    return request({
      url: `/custApi/government/update`,
      method: 'PUT',
      data,
    })
  }

  // 获取动态表单模板
  static getTemplateByProject = (data: paramType, config: object) => {
    return request({
      url: `/baseServer/projectManage/queryTemplateByProject`,
      method: 'GET',
      params: data,
      ...config,
    })
  }

  // 获取地址
  static getTreeAreaPC = (data: paramType) => {
    return request({
      url: '/tvrjet-pinganfu-cust-app/area/getTreeAreaPC',
      method: 'post',
      data,
    })
  }
  // 获取配置详情
  static parameterConfigList = (data: paramType) => {
    return request({
      url: `/baseApi/parameterConfig/queryDetail`,
      method: 'GET',
      data,
    })
  }
}
