// get接口请求参数
export interface paramType {
  pageNo?: number
  pageSize?: number
}
// 审核参数类型
export type auditType = {
  auditRecordId: string
  auditStatus: string
  auditDesc: string
}
// 修改机构状态参数类型
export type statusType = {
  mechanismId: string // 机构主键
  mechanismStatus: string // 状态字典 JGJBXX_ZYZT_ZT 暂停；JGJBXX_ZYZT_ZX 注销；JGJBXX_ZYZT_ZC：正常
  mechanismName: string // 机构名称
}
// 注销接口参数类型
export type logoutType = {
  agencyId: string // 机构主键
}
// 新增机构参数类型
export type mechanismType = {
  id?: string
  agencyName: string
  unifiedCreditCode: string
  agyMainPerson: string
  agyMainPersonMobile: string
}
// 错误数据重新导入参数类型
export type repeatType = {
  base64Json: string
}
