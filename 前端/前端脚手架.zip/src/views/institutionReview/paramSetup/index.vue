<!-- 数据管理 -- 参数设置 -->
<template>
  <el-main>
    <div class="main-page">
      <h2>数据管理参数配置</h2>
      <h3 style="margin-top: 18px">开关配置</h3>
      <el-form-item label="企业库审核按钮：">
        <el-switch v-model="paramFormData.enterpriseLibraryExamine" class="ml-2" inline-prompt active-text="开" inactive-text="关" />
      </el-form-item>
      <el-form-item label="机构库审核按钮：">
        <el-switch v-model="paramFormData.mechanismLibraryExamine" class="ml-2" inline-prompt active-text="开" inactive-text="关" />
      </el-form-item>
      <!-- <el-form-item label="专家库审核按钮：">
        <el-switch v-model="paramFormData.specialistLibraryExamine" class="ml-2" inline-prompt active-text="开" inactive-text="关" />
      </el-form-item> -->
      <el-divider />
      <h3>模板配置</h3>
      <el-form-item label="机构库批量导入模板：">
        <el-upload class="upload-demo" action="" :on-change="handleChangeVIdeo" :before-remove="beforeRemoveVideo" :multiple="false" :limit="1" :auto-upload="false" :file-list="paramfileList">
          <el-button type="primary" :loading="loading2" :disabled="disabled2">上传模板</el-button>
          <template #tip>
            <div class="el-upload__tip"></div>
          </template>
        </el-upload>
      </el-form-item>
      <el-button type="primary" @click="submitParamConfig" :loading="loading2" :disabled="disabled2">保存</el-button>
    </div>
  </el-main>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import CommonApi from './server/api'
import { ElMessage } from 'element-plus'

//按钮
let disabled2 = ref(false)
//按钮
let loading2 = ref(false)
//视频数据
let paramfileList = ref([])
// 提交数据初始化
let paramFormData = ref({
  parameterConfigId: '',
  enterpriseLibraryExamine: false, // 企业库
  mechanismLibraryExamine: false, // 机构库
  specialistLibraryExamine: false, // 专家库
  mechanismLibraryImport: '',
})
//↓↓↓↓↓↓↓视频处理↓↓↓↓↓↓↓
const handleChangeVIdeo = async (files, fileList) => {
  buttonLoading2()
  //视频判断处理
  let testmsg = files.name.substring(files.name.lastIndexOf('.') + 1)

  let type = ['xls', 'XLS', 'xlsx', 'XLSX']
  let isPdf = type.includes(testmsg)

  if (!isPdf) {
    ElMessage.warning('仅支持.xls、.xlsx类型文件')
    fileList.pop()
    buttonLoading2()
    return false
  }
  if (files.size / 1024 / 1024 > 60) {
    ElMessage.warning('上传视频大小不超过60MB')
    fileList.pop()
    buttonLoading2()
    return false
  }
  //--视频--判断处理定义FormData
  let paramVideo = new FormData()
  paramVideo.append('file', new File([files.raw], files.name, { type: files.raw.type }))
  await CommonApi.uploadAttachments(paramVideo)
    .then((res) => {
      paramFormData.value.mechanismLibraryImport = res.data[0]
      buttonLoading2()
    })
    .catch(() => {
      buttonLoading2()
    })
}
//删除
const beforeRemoveVideo = (file, fileValue) => {
  paramFormData.value.mechanismLibraryImport = ''
  paramfileList.value = []
}
//上传按钮loading
const buttonLoading2 = () => {
  loading2.value = !loading2.value
  disabled2.value = !disabled2.value
}
// 获取参数配置详情
const getParamData = () => {
  paramfileList.value = []
  CommonApi.parameterConfigList().then((res) => {
    paramFormData.value = {
      parameterConfigId: res.data.parameterConfigId, // updata用的Id
      enterpriseLibraryExamine: res.data.enterpriseLibraryExamine, // 企业库开关
      mechanismLibraryExamine: res.data.mechanismLibraryExamine, // 机构库开关
      specialistLibraryExamine: res.data.specialistLibraryExamine, // 专家库开关
      mechanismLibraryImport: res.data.mechanismLibraryImport, // 模板开关
    }
    let mli = res.data.mechanismLibraryImport?.split('/')
    paramfileList.value.push({
      name: mli[mli.length - 1],
    })
  })
}
// 保存参数设置
const submitParamConfig = () => {
  // 点击保存
  buttonLoading2()
  if (!paramFormData.value.mechanismLibraryImport) {
    ElMessage.warning('请上传导入模板')
    return
  }
  try {
    CommonApi.updateParameterConfig(paramFormData.value).then((res) => {
      if (res.code == '00000') {
        ElMessage.success('保存成功')
        buttonLoading2()
        getParamData()
      } else {
        ElMessage.warning(res.message)
        buttonLoading2()
      }
    })
  } catch (error) {
    buttonLoading2()
  }
}
onMounted(() => {
  getParamData()
})
</script>
<style lang="scss" scoped>
.main-page {
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  .upload-demo {
    width: 500px;
  }
  .el-form-item--default {
    margin: 18px;
  }
}
</style>
