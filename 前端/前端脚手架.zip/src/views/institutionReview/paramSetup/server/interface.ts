// get接口请求参数
export interface paramType {
  pageNo?: number
  pageSize?: number
}
// 审核参数类型
export type paramConfigType = {
  parameterConfigId: string
  enterpriseLibraryExamine: boolean // 企业库
  mechanismLibraryExamine: boolean // 机构库
  specialistLibraryExamine?: boolean // 专家库
  mechanismLibraryImport: string
}
