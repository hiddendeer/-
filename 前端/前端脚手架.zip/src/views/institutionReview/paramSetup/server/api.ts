import request from '@/utils/network.js'
import { paramType, paramConfigType } from './interface'

export default class CommonApi {
  // 获取配置详情
  static parameterConfigList = (data: paramType) => {
    return request({
      url: `/baseApi/parameterConfig/queryDetail`,
      method: 'GET',
      data,
    })
  }
  // 参数配置保存
  static updateParameterConfig = (data: paramConfigType) => {
    return request({
      url: `/baseApi/parameterConfig/update`,
      method: 'PUT',
      data,
    })
  }
}
