<template>
  <div>专家库</div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
const something = ref()

onMounted(() => {})
</script>
<style lang="scss" scoped></style>
