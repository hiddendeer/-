<template>
  <div>
    <el-button type="primary" @click="trggerOpen">打开画板</el-button>
    <imagePainter ref="imageRef" @saveImg="saveImg" :painterVisible1="true" ></imagePainter>
  </div>
</template>

<script setup>
import imageUrl from "@/assets/images/1.png";
import imagePainter from "@/components/vr-image-painter/index.vue"
import { onMounted, ref } from "vue";
const imageRef = ref(null);

const saveImg = (e) => {
  console.log(e);
}

const trggerOpen = () => {
  imageRef.value.open(imageUrl);
}
</script>

<style lang="scss" scoped>


</style>