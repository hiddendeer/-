<template>
	<el-empty :image-size="200" :description="title"></el-empty>
</template>

<script>
	export default {
		name: 'blank',
		data() {
			return {
				title: "BLANK PAGE :)"
			}
		}
	}
</script>

<style>
</style>
