<template>
	<el-dialog :title="titleMap[mode]" v-model="visible" width="35%" destroy-on-close @closed="$emit('closed')">
		<el-form :model="form" :rules="rules" ref="dialogForm" label-width="100px" label-position="left">
			<el-form-item label="字典项名称" prop="dictName">
				<el-input v-model="form.dictName" clearable></el-input>
			</el-form-item>
			<el-form-item label="字典项编码" prop="dictCode">
				<el-input v-model="form.dictCode" clearable></el-input>
			</el-form-item>
			<el-form-item label="字典项排序" prop="dictSort">
				<el-input v-model="form.dictSort" clearable></el-input>
			</el-form-item>
		</el-form>
		<template #footer>
			<el-button @click="visible=false" >取 消</el-button>
			<el-button type="primary" :loading="isSaveing" @click="submit()">保 存</el-button>
		</template>
	</el-dialog>
</template>

<script>
import api from './server/api.js'
	export default {
		emits: ['success', 'closed'],
		data() {
			return {
				mode: "add",
				titleMap: {
					add: '新增项',
					edit: '编辑项'
				},
				visible: false,
				isSaveing: false,
				form: {
					dictName: "",
					dictCode: "",
					dictSort: "",
					dictTypeCode: ""
				},
				rules: {
					dictName: [
						{required: true, message: '请输入字典项名称'}
					],
					dictCode: [
						{required: true, message: '请输入字典项编码'}
					],
					dictSort: [
						{required: true, message: '请输入字典项排序'}
					]
				},
				dic: [],
				dicProps: {
					value: "id",
					label: "name",
					emitPath: false,
					checkStrictly: true
				}
			}
		},
		mounted() {
			if(this.params){
				this.form.dic = this.params.code
			}
			this.getDic()
		},
		methods: {
			//显示
			open(mode='add'){
				this.mode = mode;
				this.visible = true;
				return this;
			},
			//获取字典列表
			async getDic(){
				var res = await this.$API.system.dic.tree.get();
				this.dic = res.data;
			},
			//表单提交方法
			submit(){
				this.$refs.dialogForm.validate(async (valid) => {
					if (valid) {
						this.isSaveing = true;
						// var res = await this.$API.demo.post.post(this.form);
						const res = await api.addDictChild(this.form);
						this.isSaveing = false;
						if(res.code == '00000'){
							this.$emit('success', this.form, this.mode)
							this.visible = false;
							this.$message.success("操作成功")
						}else{
							this.$alert(res.message, "提示", {type: 'error'})
						}
					}
				})
			},
			//表单注入数据
			setData(dictTypeCode){
				this.form.dictTypeCode = dictTypeCode
			}
		}
	}
</script>

<style>
</style>
