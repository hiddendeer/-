import request from "@/utils/network.js";
export default class CommonApi {
    // static addDict(data) {
    //     return http.post('/api/tvrjet-gov-system-app/dictType/add', data);
    // }
    // static delDict(data) {
    //     return http.post('/api/tvrjet-gov-system-app/dictType/delete', data);
    // }
    // static addDictChild(data) {
    //     return http.post('/api/tvrjet-gov-system-app/dict/add', data);
    // }
    // static delDictChild(data) {
    //     return http.post('/api/tvrjet-gov-system-app/dict/delete', data);
    // }
}