<template>
  <el-container>
    <el-header>
      <div class="left-panel">
        <el-button type="primary" icon="el-icon-plus"></el-button>
        <el-button type="danger" plain icon="el-icon-delete"></el-button>
      </div>
    </el-header>
    <el-main class="nopadding">
      <scTable ref="table" :data="data" row-key="id" stripe>
        <el-table-column type="selection" width="50"></el-table-column>
        <el-table-column label="姓名" prop="name" width="150"></el-table-column>
        <el-table-column
          label="性别"
          prop="sex"
          width="150"
          :filters="sexFilters"
          :filter-method="filterHandler"
        >
          <template #default="scope">
            <el-tag v-if="scope.row.sex == '男'">{{ scope.row.sex }}</el-tag>
            <el-tag v-if="scope.row.sex == '女'" type="success">{{
              scope.row.sex
            }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column
          label="邮箱"
          prop="email"
          width="250"
        ></el-table-column>
        <el-table-column
          label="评分"
          prop="num"
          width="150"
          sortable
        ></el-table-column>
        <el-table-column label="进度" prop="progress" width="250" sortable>
          <template #default="scope">
            <el-progress :percentage="scope.row.progress" />
          </template>
        </el-table-column>
        <el-table-column
          label="注册时间"
          prop="datetime"
          width="150"
          sortable
        ></el-table-column>
      </scTable>
    </el-main>
  </el-container>
</template>

<script>
export default {
  name: "tableBase",
  data() {
    return {
      data: [
        {
          id: "130000199708279482",
          name: "Thomas Robinson",
          email: "f.naxmms@kgnaewm.vg",
          ip: "223.70.103.226",
          datetime: "2007-01-02 06:14:03",
          boolean: false,
          type: "0",
          sex: "女",
          progress: 2,
          num: 809,
        },
        {
          id: "350000201805172688",
          name: "Lisa Clark",
          email: "l.gwcyovf@xryfllj.fm",
          ip: "215.118.186.8",
          datetime: "2002-06-27 05:48:04",
          boolean: false,
          type: "1",
          sex: "男",
          progress: 67,
          num: 424,
        },
        {
          id: "320000200809225572",
          name: "Jennifer Brown",
          email: "y.ewlwky@blxpxe.ke",
          ip: "117.56.177.79",
          datetime: "1988-07-13 17:44:52",
          boolean: true,
          type: "1",
          sex: "男",
          progress: 31,
          num: 954,
        },
        {
          id: "530000200009050734",
          name: "Larry Lee",
          email: "x.hhittxnq@pdjcrfoteh.sh",
          ip: "13.182.34.163",
          datetime: "2018-09-11 15:21:53",
          boolean: false,
          type: "0",
          sex: "男",
          progress: 72,
          num: 754,
        },
        {
          id: "640000199805116829",
          name: "Ruth Hernandez",
          email: "q.nphut@pxyksomrxq.my",
          ip: "197.49.98.99",
          datetime: "1992-05-30 10:26:06",
          boolean: false,
          type: "1",
          sex: "男",
          progress: 75,
          num: 80,
        },
      ],
      sexFilters: [
        { text: "男", value: "男" },
        { text: "女", value: "女" },
      ],
      list: {
        apiObj: this.$API.demo.list,
      },
    };
  },
  methods: {
    filterHandler(value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },
  },
};
</script>

<style>
</style>
