// 静态路由配置
// 书写格式与动态路由格式一致，全部经由框架统一转换
// 比较动态路由在meta中多加入了role角色权限，为数组类型。一个菜单是否有权限显示，取决于它以及后代菜单是否有权限。
// routes 显示在左侧菜单中的路由(显示顺序在动态路由之前)

const routes = [
    {
        "path": "/other/about",
        "name": "about",
        "meta": {
            "title": "demo",
            "icon": "el-icon-info-filled",
            "type": "menu"
        },
        "children": [
            {
                "path": "/image-painter",
                "name": "painter",
                "meta": {
                    "title": "画板",
                    "icon": "el-icon-tools",
                    "type": "menu"
                },
                "component": "scDemo/vrImagePainter/index"
            },
            {
                "path": "/setting/system",
                "name": "system",
                "meta": {
                    "title": "系统设置",
                    "icon": "el-icon-tools",
                    "type": "menu"
                },
                "component": "scDemo/setting/system"
            },
            {
                "path": "/vab/qrcode",
                "name": "qrcode",
                "meta": {
                    "title": "二维码",
                    "type": "menu"
                },
                "component": "scDemo/vab/qrcode"
            },
            {
                "path": "/vab/tableselect",
                "name": "tableselect",
                "meta": {
                    "title": "表格选择器",
                    "type": "menu"
                },
                "component": "scDemo/vab/tableselect"
            },
            {
                "path": "/vab/formtable",
                "name": "formtable",
                "meta": {
                    "title": "表单表格",
                    "type": "menu"
                },
                "component": "scDemo/vab/formtable"
            },
            {
                "path": "/vab/selectFilter",
                "name": "selectFilter",
                "meta": {
                    "title": "分类筛选器",
                    "type": "menu"
                },
                "component": "scDemo/vab/selectFilter"
            },
            {
                "path": "/vab/iconselect",
                "name": "iconSelect",
                "meta": {
                    "title": "图标选择器",
                    "type": "menu"
                },
                "component": "scDemo/vab/iconselect"
            },
            {
                "path": "/vab/editor",
                "name": "editor",
                "meta": {
                    "title": "富文本编辑器",
                    "type": "menu"
                },
                "component": "scDemo/vab/editor"
            },
            {
                "path": "/vab/contextmenu",
                "name": "contextmenu",
                "meta": {
                    "title": "右键菜单",
                    "type": "menu"
                },
                "component": "scDemo/vab/contextmenu"
            },
            {
                "path": "/vab/cropper",
                "name": "cropper",
                "meta": {
                    "title": "图像剪裁",
                    "type": "menu"
                },
                "component": "scDemo/vab/cropper"
            },
            {
                "path": "/vab/watermark",
                "name": "watermark",
                "meta": {
                    "title": "水印",
                    "type": "menu"
                },
                "component": "scDemo/vab/watermark"
            },
            {
                "path": "/vab/table/base",
                "name": "tableBase",
                "meta": {
                    "title": "基础数据列表",
                    "type": "menu"
                },
                "component": "scDemo/vab/table/base"
            },
            {
                "path": "/vab/table/remote",
                "name": "tableRemote",
                "meta": {
                    "title": "远程排序过滤",
                    "type": "menu"
                },
                "component": "scDemo/vab/table/remote"
            },

            {
                "path": "/template/list/crud",
                "name": "listCrud",
                "meta": {
                    "title": "CRUD",
                    "type": "menu"
                },
                "component": "scDemo/template/list/crud"
            },
            {
                "path": "/template/list/tree",
                "name": "listTree",
                "meta": {
                    "title": "左树右表",
                    "type": "menu"
                },
                "component": "scDemo/template/list/tree"
            },
            {
                "path": "/template/list/tab",
                "name": "listTab",
                "meta": {
                    "title": "分类表格",
                    "type": "menu"
                },
                "component": "scDemo/template/list/tab"
            },
            {
                "path": "/setting/table",
                "name": "tableSetting",
                "meta": {
                    "title": "表格列管理",
                    "icon": "el-icon-scale-to-original",
                    "type": "menu"
                },
                "component": "scDemo/setting/table"
            },
            {
                "path": "/other/directive",
                "name": "directive",
                "meta": {
                    "title": "指令",
                    "icon": "el-icon-price-tag",
                    "type": "menu"
                },
                "component": "scDemo/other/directive"
            },
            {
                "path": "/other/viewTags",
                "name": "viewTags",
                "meta": {
                    "title": "标签操作",
                    "icon": "el-icon-files",
                    "type": "menu"
                },
                "component": "scDemo/other/viewTags",
                "children": [
                    {
                        "path": "/other/fullpage",
                        "name": "fullpage",
                        "meta": {
                            "title": "整页路由",
                            "icon": "el-icon-monitor",
                            "fullpage": true,
                            "hidden": true,
                            "type": "menu"
                        },
                        "component": "scDemo/other/fullpage"
                    }
                ]
            },
            {
                "path": "/other/verificate",
                "name": "verificate",
                "meta": {
                    "title": "表单验证",
                    "icon": "el-icon-open",
                    "type": "menu"
                },
                "component": "scDemo/other/verificate"
            },
            {
                "path": "/test/codebug",
                "name": "codebug",
                "meta": {
                    "title": "异常处理",
                    "icon": "sc-icon-bug-line",
                    "type": "menu"
                },
                "component": "scDemo/test/codebug"
            },
            {
                "path": "/vab/workflow",
                "name": "workflow",
                "meta": {
                    "title": "工作流设计器",
                    "icon": "el-icon-share",
                    "type": "menu"
                },
                "component": "scDemo/vab/workflow"
            },
            {
                "path": "/vab/formrender",
                "name": "formRender",
                "meta": {
                    "title": "动态表单(Beta)",
                    "icon": "el-icon-message-box",
                    "type": "menu"
                },
                "component": "scDemo/vab/form"
            },
            {
                "path": "/setting/log",
                "name": "log",
                "meta": {
                    "title": "系统日志",
                    "icon": "el-icon-warning",
                    "type": "menu"
                },
                "component": "scDemo/setting/log"
            }

        ]
    }
]

export default routes;
