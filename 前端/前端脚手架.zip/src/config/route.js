// 静态路由配置
// 书写格式与动态路由格式一致，全部经由框架统一转换
// 比较动态路由在meta中多加入了role角色权限，为数组类型。一个菜单是否有权限显示，取决于它以及后代菜单是否有权限。
// routes 显示在左侧菜单中的路由(显示顺序在动态路由之前)

const routes = [
    {
        name: "home",
        path: "/home",
        meta: {
            title: "首页",
            icon: "el-icon-HomeFilled",
            type: "menu"
        },
        children: [
            {
                name: "dashboard",
                path: "/dashboard",
                meta: {
                    title: "控制台",
                    icon: "el-icon-menu",
                    affix: true
                },
                component: "home/index"
            }
        ]
    },
    {
        name: "setting",
        path: "/setting",
        meta: {
            title: "配置",
            icon: "el-icon-tools",
            type: "menu",
        },
        children: [
            {
                path: "/setting/dict",
                name: "dict",
                meta: {
                    title: "数据字典",
                    icon: "el-icon-reading",
                    type: "menu",
                },
                component: "systemSetting/dict/index",
            },
            {
                path: "/setting/role",
                name: "role",
                meta: {
                    title: "角色管理",
                    icon: "el-icon-user",
                    type: "menu",
                },
                component: "systemSetting/role/index",
            },
            {
                path: "/setting/app",
                name: "app",
                meta: {
                    title: "应用管理",
                    icon: "el-icon-Shop",
                    type: "menu",
                },
                component: "systemSetting/app/index",
            },
            {
                path: "/setting/menu",
                name: "menu",
                meta: {
                    title: "菜单管理",
                    icon: "el-icon-fold",
                    type: "menu",
                },
                component: "systemSetting/menu/index",
            },
            {
                path: "/setting/user",
                name: "user",
                meta: {
                    title: "用户管理",
                    icon: "el-icon-tools",
                    type: "menu",
                },
                component: "systemSetting/userManagement/index",
            }
        ]

    },
]

export default routes;
