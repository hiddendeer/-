export default {
    mounted(el, binding) {
        if (el) {
            el.onwheel = (e) => {
              const { maxScale = 5, minScale = 0.5 } = binding.arg || {}
              const cssVarName = "--scale"
              let _scale = el.style.getPropertyValue(cssVarName) || 1
              if (e.wheelDelta > 0) {
                _scale = _scale * 1 + 0.1
              } else {
                _scale = _scale * 1 - 0.1
              }
              if (_scale > maxScale) {
                _scale = maxScale
              } else if (_scale < minScale) {
                _scale = minScale
              }
              const setVarScale = (el, cssVarName) => {
                let cssText = el.style.cssText
                let cssTextList = cssText.split(";")
                let isExist = false
                let isExistIndex = -1
                for (let index = 0; index < cssTextList.length; index++) {
                  const element = cssTextList[index]
                  if (element.includes(cssVarName + ":")) {
                    isExist = true
                    isExistIndex = index
                    break
                  }
                }
                if (isExist) {
                  cssTextList[isExistIndex] = `--scale: ${_scale}`
                } else {
                  cssTextList.push(`--scale: ${_scale}`)
                }
                cssText = cssTextList.join(";")
                el.style.cssText = cssText
              }
              const setTransformCss = (el, cssVarName) => {
                let transformCssString = el.style.transform
                let regScaleGlobal = /scale\(.*?[ )]*[)]+[ ]*/g 
                if (regScaleGlobal.test(transformCssString)) {
                  transformCssString = transformCssString.replace(
                    regScaleGlobal,
                    ` scale(var(${cssVarName})) `
                  )
                } else {
                  transformCssString += " " + `scale(var(${cssVarName}))`
                }
                el.style.transform = transformCssString
              }
              setVarScale(el, cssVarName)
              setTransformCss(el, cssVarName)
            }
          }
    }
}