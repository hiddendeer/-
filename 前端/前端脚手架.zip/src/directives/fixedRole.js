
// 固定角色不能删除
let arr = [
    'superAdmin',
    'checkPersion',
    'examinePersion',
    'testPersion'
]
export default {
    mounted(el, binding) {
        const { value } = binding
        let ishas = false;
        ishas = !arr.includes(value);
        if (!ishas) {
            el.parentNode.removeChild(el)
        }

    }
};
